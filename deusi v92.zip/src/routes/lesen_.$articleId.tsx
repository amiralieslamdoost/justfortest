import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { motion, AnimatePresence } from "@/lib/motion-lite";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Heart,
  Volume2,
  Languages,
  StickyNote,
  VolumeX,
  Highlighter,
  Focus,
  Sparkles,
  BookOpen,
  Trophy,
  X,
  Bookmark,
  Minus,
  Plus,
  Clock,
  Share2,
  Layers,
} from "lucide-react";
import { getArticle, articles, type VocabItem } from "@/lib/deusi/mockReading";
import { InteractiveText } from "@/components/deusi/reading/InteractiveText";
import { WordPopup } from "@/components/deusi/reading/WordPopup";
import { QuestionPanel } from "@/components/deusi/reading/QuestionPanel";
import { ArticleCard } from "@/components/deusi/reading/ArticleCard";
import { Flashcards } from "@/components/deusi/reading/Flashcards";
import { useInteractions } from "@/lib/deusi/interactions";
import { useArticle, useArticleProgress, useArticles } from "@/lib/api/useReading";

export const Route = createFileRoute("/lesen_/$articleId")({
  head: ({ params }) => {
    const a = getArticle(params.articleId);
    return {
      meta: [
        { title: a ? `${a.title} — DEUSI` : "Text — DEUSI" },
        { name: "description", content: a?.description ?? "Deutsch lesen mit DEUSI." },
        ...(a ? [{ property: "og:image", content: a.cover }] : []),
      ],
    };
  },
  component: LesenDetail,
});

type Stage = "read" | "questions" | "results" | "flashcards";

function LesenDetail() {
  const { articleId } = useParams({ from: "/lesen_/$articleId" });
  const { article } = useArticle(articleId);
  const [stage, setStage] = useState<Stage>("read");
  const [fontSize, setFontSize] = useState(17);
  const [focusMode, setFocusMode] = useState(false);
  const [popup, setPopup] = useState<VocabItem | null>(null);
  const [seconds, setSeconds] = useState(0);
  const [ttsPlaying, setTtsPlaying] = useState(false);
  const [result, setResult] = useState<{ correct: number; wrong: number; total: number } | null>(
    null,
  );
  const [scrollPct, setScrollPct] = useState(0);
  const [state, patchState] = useArticleProgress(articleId);
  const readerRef = useRef<HTMLDivElement>(null);
  const { isBookmarked, toggleBookmark: globalToggleBookmark } = useInteractions();
  const bookmarked = isBookmarked("article", articleId);

  useEffect(() => {
    const t = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    function onScroll() {
      const h = document.documentElement;
      const total = h.scrollHeight - h.clientHeight;
      const pct = total > 0 ? Math.min(100, Math.round((h.scrollTop / total) * 100)) : 0;
      setScrollPct(pct);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Persist progress from scroll (only while reading)
  useEffect(() => {
    if (stage !== "read") return;
    const t = setTimeout(() => {
      if (scrollPct > state.progress) patchState({ progress: scrollPct });
    }, 800);
    return () => clearTimeout(t);
  }, [scrollPct, stage, state.progress, patchState]);

  const { articles: allArticles } = useArticles({ perPage: 12 });
  const suggested = useMemo(
    () => allArticles.filter((a) => a.id !== articleId).slice(0, 3),
    [allArticles, articleId],
  );

  if (!article) {
    return (
      <div className="neu-card p-8 text-center">
        <div className="text-lg font-bold">Text nicht gefunden</div>
        <Link
          to="/lesen"
          className="mt-3 inline-block text-sm font-semibold text-[var(--flag-red)]"
        >
          Zurück zur Bibliothek
        </Link>
      </div>
    );
  }

  const timerLabel = `${Math.floor(seconds / 60)
    .toString()
    .padStart(2, "0")}:${(seconds % 60).toString().padStart(2, "0")}`;
  const savedWords = state.savedWords ?? [];

  function toggleBookmark() {
    patchState({ bookmarked: !bookmarked });
    globalToggleBookmark("article", article!.id, {
      title: article!.title,
      sub: article!.description,
      level: article!.level,
      to: `/lesen/${article!.id}`,
    });
  }
  function saveWord(v: VocabItem) {
    const set = new Set(savedWords);
    set.add(v.word);
    patchState({ savedWords: [...set] });
    setPopup(null);
  }
  function toggleTTS() {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    if (ttsPlaying) {
      window.speechSynthesis.cancel();
      setTtsPlaying(false);
      return;
    }
    const text = article!.content
      .map((p) => p.text.replace(/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g, "$2$1"))
      .join(" ");
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "de-DE";
    u.onend = () => setTtsPlaying(false);
    u.onerror = () => setTtsPlaying(false);
    window.speechSynthesis.speak(u);
    setTtsPlaying(true);
  }
  async function shareArticle() {
    try {
      if (
        typeof navigator !== "undefined" &&
        (navigator as Navigator & { share?: (d: ShareData) => Promise<void> }).share
      ) {
        await (navigator as Navigator & { share: (d: ShareData) => Promise<void> }).share({
          title: article!.title,
          text: article!.description,
          url: typeof location !== "undefined" ? location.href : "",
        });
      } else if (typeof navigator !== "undefined" && navigator.clipboard) {
        await navigator.clipboard.writeText(typeof location !== "undefined" ? location.href : "");
      }
    } catch {
      /* noop */
    }
  }

  return (
    <div className={`space-y-5 pb-16 animate-fade ${focusMode ? "mx-auto max-w-3xl" : ""}`}>
      {/* Thin scroll progress bar at very top of page */}
      <div className="pointer-events-none fixed inset-x-0 top-0 z-40 h-1 bg-transparent">
        <div
          className="h-full bg-[var(--flag-red)] transition-[width] duration-150"
          style={{ width: `${scrollPct}%` }}
        />
      </div>

      {/* Top bar — sticky and mobile-first */}
      <div className="sticky top-1 z-30 -mx-2 rounded-2xl border border-border bg-card/80 px-2 py-2 shadow-sm backdrop-blur-md sm:top-2 sm:px-3">
        <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 sm:gap-3">
          <Link
            to="/lesen"
            className="inline-flex h-10 shrink-0 items-center gap-1 rounded-full bg-secondary px-3 text-sm font-semibold hover:bg-muted"
          >
            <ArrowLeft className="h-4 w-4" /> <span className="hidden sm:inline">Zurück</span>
          </Link>
          <div className="min-w-0">
            <div className="truncate text-sm font-black sm:text-base md:text-lg">
              {stage === "read"
                ? article.title
                : stage === "questions"
                  ? `Test: ${article.title}`
                  : stage === "flashcards"
                    ? `Wörter · ${article.title}`
                    : `Ergebnisse · ${article.title}`}
            </div>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[10px] sm:text-[11px]">
              <span className="rounded-full bg-[var(--flag-red)]/10 px-2 py-0.5 font-bold text-[var(--flag-red)]">
                {article.level}
              </span>
              <span className="inline-flex items-center gap-1 text-muted-foreground">
                <Clock className="h-3 w-3" /> {article.minutes} Min · {article.words} W
              </span>
              <span className="hidden text-muted-foreground sm:inline">· {timerLabel}</span>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <IconBtn
              title="Speichern"
              onClick={toggleBookmark}
              active={bookmarked}
              activeStyle={{ color: "var(--flag-red)" }}
            >
              <Bookmark className={`h-4 w-4 ${bookmarked ? "fill-current" : ""}`} />
            </IconBtn>
            <IconBtn title="Teilen" onClick={shareArticle}>
              <Share2 className="h-4 w-4" />
            </IconBtn>
            <IconBtn title="Fokusmodus" active={focusMode} onClick={() => setFocusMode((f) => !f)}>
              <Focus className="h-4 w-4" />
            </IconBtn>
            <IconBtn title="Verlassen" as={Link} to="/lesen">
              <X className="h-4 w-4" />
            </IconBtn>
          </div>
        </div>
      </div>

      {/* Stepper */}
      <div className="neu-card -mx-1 flex items-center gap-1 overflow-x-auto p-2 text-xs font-semibold text-muted-foreground sm:text-sm">
        <Step
          active={stage === "read"}
          done={stage !== "read"}
          label="Artikel"
          icon={<BookOpen className="h-4 w-4" />}
          onClick={() => setStage("read")}
        />
        <Arrow />
        <Step
          active={stage === "questions"}
          done={stage === "results" || stage === "flashcards"}
          label="Test"
          icon={<Sparkles className="h-4 w-4" />}
          onClick={() => setStage("questions")}
        />
        <Arrow />
        <Step
          active={stage === "results"}
          done={stage === "flashcards"}
          label="Ergebnisse"
          icon={<Trophy className="h-4 w-4" />}
          onClick={() => result && setStage("results")}
        />
        <Arrow />
        <Step
          active={stage === "flashcards"}
          done={false}
          label="Wörter"
          icon={<Layers className="h-4 w-4" />}
          onClick={() => setStage("flashcards")}
        />
      </div>

      <div className={`grid gap-5 ${focusMode ? "" : "lg:grid-cols-[minmax(0,1fr)_320px]"}`}>
        {/* Main content */}
        <div className="min-w-0 space-y-5" ref={readerRef}>
          {stage === "read" && (
            <>
              <div className="neu-card overflow-hidden">
                <div className="relative">
                  <img
                    loading="lazy"
                    decoding="async"
                    src={article.cover}
                    alt=""
                    className="h-56 w-full object-cover sm:h-72"
                  />
                  <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/70 to-transparent" />
                  <div className="absolute inset-x-4 bottom-4 text-white sm:inset-x-6">
                    <div className="text-[10px] font-bold uppercase tracking-widest opacity-90 sm:text-xs">
                      {article.category} · {article.level}
                    </div>
                    <div className="mt-1 text-xl font-black sm:text-2xl md:text-3xl">
                      {article.title}
                    </div>
                    <div className="mt-1 text-xs opacity-90">{article.description}</div>
                  </div>
                </div>

                <div className="p-4 sm:p-6 md:p-8">
                  {/* Reading tools */}
                  <div className="mb-5 flex flex-wrap items-center gap-2 border-b border-border pb-4">
                    <div className="inline-flex items-center gap-1 rounded-full bg-secondary p-1">
                      <button
                        onClick={() => setFontSize((s) => Math.max(13, s - 1))}
                        className="grid h-8 w-8 place-items-center rounded-full hover:bg-muted"
                        aria-label="Kleiner"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="min-w-8 text-center text-xs font-bold tabular-nums">
                        {fontSize}px
                      </span>
                      <button
                        onClick={() => setFontSize((s) => Math.min(26, s + 1))}
                        className="grid h-8 w-8 place-items-center rounded-full hover:bg-muted"
                        aria-label="Größer"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <ToolButton
                      icon={
                        ttsPlaying ? (
                          <VolumeX className="h-4 w-4" />
                        ) : (
                          <Volume2 className="h-4 w-4" />
                        )
                      }
                      label={ttsPlaying ? "Stopp" : "Vorlesen"}
                      onClick={toggleTTS}
                      active={ttsPlaying}
                    />
                    <ToolButton icon={<Languages className="h-4 w-4" />} label="Übersetzen" />
                    <ToolButton icon={<Highlighter className="h-4 w-4" />} label="Markieren" />
                    <ToolButton icon={<StickyNote className="h-4 w-4" />} label="Notizen" />
                    <div className="ml-auto text-xs text-muted-foreground">
                      <span className="tabular-nums">{scrollPct}%</span> gelesen
                    </div>
                  </div>

                  <InteractiveText
                    content={article.content}
                    vocab={article.vocab}
                    fontSize={fontSize}
                    onWordClick={setPopup}
                  />

                  <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4 text-xs text-muted-foreground">
                    <div>
                      Autor: <b className="text-foreground">{article.author}</b>
                    </div>
                    <button
                      onClick={() => setStage("questions")}
                      className="inline-flex items-center gap-2 rounded-2xl bg-[var(--flag-red)] px-5 py-2.5 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5"
                    >
                      Zum Test <Sparkles className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* AI Summary */}
              <div
                className="neu-card p-5"
                style={{ background: "linear-gradient(160deg,#F3ECFF,#EDE4FF)" }}
              >
                <div className="mb-2 inline-flex items-center gap-2 text-sm font-bold text-[#6D28D9]">
                  <Sparkles className="h-4 w-4" /> KI-Zusammenfassung
                </div>
                <p className="text-sm leading-relaxed">{article.aiSummary}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {[
                    "Grammatik erklären",
                    "Schwierige Sätze",
                    "Flashcards generieren",
                    "Ähnliche Artikel",
                  ].map((t) => (
                    <button
                      key={t}
                      className="rounded-full bg-white/70 px-3 py-1.5 text-xs font-semibold hover:bg-white"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Grammar notes */}
              {article.grammarNotes && article.grammarNotes.length > 0 && (
                <div className="neu-card p-5">
                  <div className="mb-3 flex items-center gap-2 font-bold">
                    <BookOpen className="h-4 w-4 text-[var(--flag-red)]" /> Grammatik im Text
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {article.grammarNotes.map((g, idx) => (
                      <div key={idx} className="rounded-2xl bg-secondary/60 p-4">
                        <div className="text-sm font-bold">{g.title}</div>
                        <div className="mt-1 text-xs text-muted-foreground">{g.body}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {stage === "questions" && (
            <QuestionPanel
              questions={article.questions}
              onFinish={(r) => {
                setResult(r);
                setStage("results");
                patchState({ progress: 100 });
              }}
            />
          )}

          {stage === "results" && result && (
            <ResultCard
              article={article}
              result={result}
              timerLabel={timerLabel}
              savedCount={savedWords.length}
              suggested={suggested}
              onLearnWords={() => setStage("flashcards")}
              onRestart={() => {
                setResult(null);
                setStage("questions");
              }}
            />
          )}

          {stage === "flashcards" && (
            <Flashcards
              vocab={[
                ...article.vocab.filter((v) => savedWords.includes(v.word)),
                ...article.vocab.filter((v) => !savedWords.includes(v.word)),
              ]}
              onFinish={() => setStage("results")}
            />
          )}
        </div>

        {/* Sidebar */}
        {!focusMode && (
          <aside className="min-w-0 space-y-4">
            {/* Progress ring — meaning depends on stage */}
            <div className="neu-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <div className="font-bold">
                  {stage === "questions" || stage === "results"
                    ? "Test-Fortschritt"
                    : "Lese-Fortschritt"}
                </div>
                <div className="text-xs text-muted-foreground">{timerLabel}</div>
              </div>
              <ProgressRing
                value={
                  result
                    ? Math.round((result.correct / result.total) * 100)
                    : stage === "read"
                      ? scrollPct
                      : 0
                }
              />
              <div className="mt-4 space-y-2 text-sm">
                <Row
                  label="Richtige Antworten"
                  value={result?.correct ?? 0}
                  tone="text-green-600"
                />
                <Row label="Falsche Antworten" value={result?.wrong ?? 0} tone="text-red-600" />
                <Row
                  label="Unbeantwortet"
                  value={
                    result ? result.total - result.correct - result.wrong : article.questions.length
                  }
                  tone="text-muted-foreground"
                />
              </div>
            </div>

            {/* Saved / all vocab */}
            <div className="neu-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <div className="font-bold">Wortschatz im Text</div>
                <span className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold">
                  {savedWords.length}/{article.vocab.length} gespeichert
                </span>
              </div>
              <div className="space-y-1">
                {article.vocab.slice(0, 6).map((v) => {
                  const isSaved = savedWords.includes(v.word);
                  return (
                    <button
                      key={v.word}
                      onClick={() => setPopup(v)}
                      className="flex w-full items-center justify-between rounded-2xl p-2 text-left transition hover:bg-secondary"
                    >
                      <div className="min-w-0">
                        <div className="truncate text-sm font-bold">
                          {v.article && (
                            <span className="mr-1 text-xs text-muted-foreground">{v.article}</span>
                          )}
                          {v.word}
                        </div>
                        <div className="truncate text-xs text-muted-foreground">
                          {v.translation}
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-1">
                        {isSaved && (
                          <Bookmark className="h-4 w-4 fill-current text-[var(--flag-red)]" />
                        )}
                        <Volume2 className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </button>
                  );
                })}
              </div>
              <button
                onClick={() => setStage("flashcards")}
                className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--flag-black)] px-4 py-2 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5"
              >
                <Layers className="h-4 w-4" /> Karteikarten üben
              </button>
            </div>

            <div
              className="neu-card p-5"
              style={{ background: "linear-gradient(160deg,#FFF8E6,#FEF0D8)" }}
            >
              <div className="flex items-center gap-2 text-sm font-bold">💡 Lesetipp</div>
              <p className="mt-2 text-xs text-muted-foreground">
                Lies den Text zweimal: einmal für das Gesamtverständnis, einmal um die markierten
                Wörter zu verstehen.
              </p>
            </div>
          </aside>
        )}
      </div>

      <AnimatePresence>
        {popup && <WordPopup vocab={popup} onClose={() => setPopup(null)} onSave={saveWord} />}
      </AnimatePresence>
    </div>
  );
}

/* ---------- Helper components ---------- */

function IconBtn({
  children,
  title,
  onClick,
  active,
  activeStyle,
  as,
  to,
}: {
  children: React.ReactNode;
  title: string;
  onClick?: () => void;
  active?: boolean;
  activeStyle?: React.CSSProperties;
  as?: typeof Link;
  to?: string;
}) {
  const cls = `grid h-10 w-10 place-items-center rounded-full ring-1 ring-border transition hover:bg-secondary ${active ? "bg-[var(--flag-red)]/10" : "bg-card"}`;
  if (as && to)
    return (
      <Link to={to} title={title} className={cls}>
        {children}
      </Link>
    );
  return (
    <button
      title={title}
      onClick={onClick}
      className={cls}
      style={active ? activeStyle : undefined}
    >
      {children}
    </button>
  );
}

function Step({
  active,
  done,
  label,
  icon,
  onClick,
}: {
  active: boolean;
  done: boolean;
  label: string;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1.5 transition ${
        active
          ? "bg-[var(--accent)] text-[var(--accent-foreground)]"
          : done
            ? "text-foreground"
            : "hover:bg-secondary"
      }`}
    >
      <span
        className={`grid h-6 w-6 shrink-0 place-items-center rounded-full ${
          active
            ? "bg-[var(--flag-red)] text-white"
            : done
              ? "bg-green-500 text-white"
              : "bg-secondary"
        }`}
      >
        {done && !active ? "✓" : icon}
      </span>
      <span>{label}</span>
    </button>
  );
}
function Arrow() {
  return <span className="text-muted-foreground">→</span>;
}

function ToolButton({
  icon,
  label,
  onClick,
  active,
}: {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
        active ? "bg-[var(--flag-red)] text-white" : "bg-secondary hover:bg-muted"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function Row({ label, value, tone }: { label: string; value: number | string; tone: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-bold tabular-nums ${tone}`}>{value}</span>
    </div>
  );
}

function ProgressRing({ value }: { value: number }) {
  return (
    <div className="relative mx-auto grid h-32 w-32 place-items-center">
      <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
        <circle cx="50" cy="50" r="42" stroke="var(--secondary)" strokeWidth="8" fill="none" />
        <circle
          cx="50"
          cy="50"
          r="42"
          stroke="url(#tpGrad)"
          strokeWidth="8"
          fill="none"
          strokeDasharray={2 * Math.PI * 42}
          strokeDashoffset={2 * Math.PI * 42 * (1 - value / 100)}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 700ms" }}
        />
        <defs>
          <linearGradient id="tpGrad" x1="0" x2="1" y1="0" y2="1">
            <stop offset="0%" stopColor="#22C55E" />
            <stop offset="100%" stopColor="#F7C948" />
          </linearGradient>
        </defs>
      </svg>
      <div className="text-center">
        <div className="text-2xl font-black tabular-nums">{value}%</div>
        <div className="text-[10px] text-muted-foreground">abgeschlossen</div>
      </div>
    </div>
  );
}

function ResultCard({
  article,
  result,
  timerLabel,
  savedCount,
  suggested,
  onLearnWords,
  onRestart,
}: {
  article: NonNullable<ReturnType<typeof getArticle>>;
  result: { correct: number; wrong: number; total: number };
  timerLabel: string;
  savedCount: number;
  suggested: ReturnType<typeof getArticle>[];
  onLearnWords: () => void;
  onRestart: () => void;
}) {
  const score = Math.round((result.correct / result.total) * 100);
  const rating = score >= 80 ? "Ausgezeichnet!" : score >= 60 ? "Gut gemacht!" : "Weiter üben!";
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-5"
    >
      <div className="neu-card relative overflow-hidden p-6 text-center sm:p-8">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-40 blur-3xl"
          style={{ background: "radial-gradient(circle, #FFD1CC, transparent 60%)" }}
        />
        <div className="relative">
          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-[#FEE9E7] text-[#DD2222]"
          >
            <Trophy className="h-9 w-9" />
          </motion.div>
          <div className="mt-4 text-2xl font-black sm:text-3xl">{rating}</div>
          <div className="mt-1 text-sm text-muted-foreground">
            Dein Ergebnis für „{article.title}"
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <ResultStat label="Punktzahl" value={`${score}%`} tone="#22C55E" />
            <ResultStat
              label="Richtig"
              value={`${result.correct}/${result.total}`}
              tone="#3B82F6"
            />
            <ResultStat
              label="Neue Wörter"
              value={String(savedCount || article.vocab.length)}
              tone="#F7C948"
            />
            <ResultStat label="Zeit" value={timerLabel} tone="#8B5CF6" />
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={onLearnWords}
              className="inline-flex items-center gap-2 rounded-2xl bg-[var(--flag-black)] px-5 py-2.5 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5"
            >
              <Layers className="h-4 w-4" /> Wörter lernen
            </button>
            <button
              onClick={onRestart}
              className="inline-flex items-center gap-2 rounded-2xl bg-secondary px-5 py-2.5 text-sm font-bold shadow-sm transition hover:bg-muted"
            >
              Test wiederholen
            </button>
          </div>
        </div>
      </div>

      <div
        className="neu-card p-5"
        style={{ background: "linear-gradient(160deg,#F3ECFF,#EDE4FF)" }}
      >
        <div className="inline-flex items-center gap-2 text-sm font-bold text-[#6D28D9]">
          <Sparkles className="h-4 w-4" /> KI-Feedback
        </div>
        <p className="mt-2 text-sm leading-relaxed">
          Dein Verständnis liegt bei {score}%.{" "}
          {score >= 80
            ? "Sehr stark! Versuche einen Text auf dem nächsten Niveau."
            : score >= 60
              ? "Solide Leistung — achte besonders auf trennbare Verben und Präpositionen mit Dativ."
              : "Lies den Text noch einmal in Ruhe und wiederhole die markierten Wörter, bevor du den Test wiederholst."}
        </p>
      </div>

      <div className="neu-card p-5">
        <div className="mb-3 flex items-center gap-2 font-bold">
          <Heart className="h-4 w-4 text-[var(--flag-red)]" /> Empfohlene Artikel
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          {suggested.map((a) => a && <ArticleCard key={a.id} article={a} variant="grid" />)}
        </div>
      </div>
    </motion.div>
  );
}
function ResultStat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-2xl bg-secondary/60 p-3">
      <div className="text-xl font-black tabular-nums sm:text-2xl" style={{ color: tone }}>
        {value}
      </div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}
