import { createFileRoute, Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import { useCallback, useEffect, useRef, useState, type ReactElement } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { relativeDay } from "@/lib/deusi/kiCoachHistory";
import { useAiCoach, type CoachUiThread } from "@/lib/api/useAiCoach";
import { AI_ENABLED } from "@/lib/api/config";
import { useProfile } from "@/lib/api/useProfile";

export const Route = createFileRoute("/ki-coach")({
  validateSearch: (search: Record<string, unknown>) => ({
    c: typeof search.c === "string" ? search.c : undefined,
  }),
  head: () => ({
    meta: [
      { title: "KI-Coach — DEUSI" },
      {
        name: "description",
        content: "Dein persönlicher KI-Coach für Deutsch: Fragen stellen, üben, Feedback bekommen.",
      },
      { property: "og:title", content: "KI-Coach — DEUSI" },
      {
        property: "og:description",
        content: "Dein persönlicher KI-Coach für Deutsch: Fragen stellen, üben, Feedback bekommen.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: KICoachPage,
});

const QUICK_PROMPTS = [
  {
    icon: "📘",
    label: "Grammatik erklären",
    prompt: 'Erkläre mir den Unterschied zwischen „seit" und „vor".',
  },
  {
    icon: "✍️",
    label: "Text korrigieren",
    prompt: 'Bitte korrigiere: „Ich bin gestern in Berlin gefahrt."',
  },
  {
    icon: "📚",
    label: "Vokabeln üben",
    prompt: 'Lass uns 5 neue Wörter zum Thema „Arbeit" lernen.',
  },
  {
    icon: "🎤",
    label: "Sprechen üben",
    prompt: "Lass uns ein kurzes Gespräch über meine Hobbys führen.",
  },
];

function KICoachPage() {
  const { currentUser, hydrated } = useDeusi();
  const navigate = useNavigate({ from: "/ki-coach" });
  const { c: routeThreadId } = Route.useSearch();
  // گارد ورود در `__root.tsx` انجام می‌شود (با returnTo). اینجا فقط مطمئن می‌شویم
  // وقتی مسیر فعال دیگر /ki-coach نیست، هیچ ناوبری‌ای از این صفحه اجرا نشود؛
  // در غیر این صورت با گارد ریشه یک حلقهٔ بی‌پایان ناوبری ایجاد می‌شد.
  const onThisRoute = useRouterState({ select: (s) => s.location.pathname === "/ki-coach" });
  const canNavigate = Boolean(currentUser) && hydrated && onThisRoute;

  const firstName = currentUser?.username?.split(" ")[0] ?? "Freund";
  const greeting = `Hallo ${firstName}! 😊 Woran möchtest du heute arbeiten?`;

  const { profile } = useProfile();
  const [historyOpen, setHistoryOpen] = useState(false);
  const [input, setInput] = useState("");
  const scrollerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const openThread = useCallback(
    (id: string) => {
      if (!canNavigate) return;
      navigate({ search: { c: id } });
      setHistoryOpen(false);
    },
    [navigate, canNavigate],
  );

  const coach = useAiCoach({
    greeting,
    level: profile?.level ?? "unknown",
    threadId: routeThreadId,
    onOpen: openThread,
  });

  const { activeId, messages, threads, typing, error } = coach;
  const activeTitle = threads.find((t) => t.id === activeId)?.title ?? "Neuer Chat";

  // Keep the URL in sync with the active thread so reloads restore it.
  useEffect(() => {
    if (canNavigate && activeId && routeThreadId !== activeId) {
      navigate({ search: { c: activeId }, replace: true });
    }
  }, [canNavigate, activeId, routeThreadId, navigate]);

  useEffect(() => {
    scrollerRef.current?.scrollTo({ top: scrollerRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [activeId]);

  const newChat = () => {
    coach.newChat();
    setHistoryOpen(false);
    setInput("");
  };

  const send = (raw?: string) => {
    const text = (raw ?? input).trim();
    if (!text || typing) return;
    coach.send(text);
    setInput("");
  };

  if (!currentUser || !coach.ready) return null;

  const historyList = (
    <HistoryList
      threads={threads}
      activeId={activeId}
      onOpen={openThread}
      onDelete={coach.deleteChat}
      onNew={newChat}
    />
  );

  return (
    <div className="flex h-[100dvh] gap-4 lg:h-auto lg:pb-10">
      {/* History sidebar (desktop) */}
      <aside className="hidden w-64 shrink-0 flex-col rounded-3xl border border-border/60 bg-[color:var(--card)] p-3 lg:flex">
        {historyList}
      </aside>

      {/* History drawer (mobile) */}
      <AnimatePresence>
        {historyOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setHistoryOpen(false)}
              className="fixed inset-0 z-40 bg-black/40 lg:hidden"
            />
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 34 }}
              className="fixed inset-y-0 left-0 z-50 flex w-72 flex-col bg-[color:var(--card)] p-3 shadow-2xl lg:hidden"
            >
              <button
                onClick={() => setHistoryOpen(false)}
                aria-label="Schließen"
                className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-secondary text-sm"
              >
                ✕
              </button>
              {historyList}
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Header */}
        <header className="flex shrink-0 items-center gap-3 border-b border-border/60 bg-[color:var(--card)] px-4 py-3 lg:rounded-3xl lg:border lg:px-5">
          <Link
            to="/dashboard"
            aria-label="Zurück"
            className="grid h-9 w-9 place-items-center rounded-full bg-secondary text-foreground transition hover:bg-accent lg:hidden"
          >
            ‹
          </Link>
          <button
            onClick={() => setHistoryOpen(true)}
            aria-label="Chat-Verlauf"
            className="grid h-9 w-9 place-items-center rounded-full bg-secondary text-foreground transition hover:bg-accent lg:hidden"
          >
            <svg
              viewBox="0 0 24 24"
              width="16"
              height="16"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            >
              <path d="M4 6h16M4 12h16M4 18h10" />
            </svg>
          </button>
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[color:var(--flag-red)]/20 to-[color:var(--flag-gold)]/20 text-lg">
            ✨
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-base font-bold">KI-Coach</h1>
            <p className="truncate text-[11px] text-muted-foreground">{activeTitle}</p>
          </div>
          <button
            onClick={newChat}
            className="hidden shrink-0 rounded-full bg-secondary px-3 py-1.5 text-[11px] font-semibold transition hover:bg-accent lg:block"
          >
            + Neuer Chat
          </button>
        </header>

        {/* Chat */}
        <div
          ref={scrollerRef}
          className="min-h-0 flex-1 space-y-4 overflow-y-auto px-4 py-5 lg:mt-4 lg:max-h-[62vh] lg:rounded-3xl lg:border lg:border-border/60 lg:bg-[color:var(--card)] lg:px-6"
        >
          <AnimatePresence initial={false}>
            {messages.map((m) => (
              <ChatBubble key={m.id} msg={m} />
            ))}
          </AnimatePresence>
          {typing && (
            <div className="flex items-end gap-2">
              <AiAvatar />
              <div className="glass flex items-center gap-1.5 rounded-2xl rounded-bl-md px-4 py-3">
                <Dot delay={0} />
                <Dot delay={0.15} />
                <Dot delay={0.3} />
              </div>
            </div>
          )}
          {error && (
            <div
              dir="rtl"
              role="alert"
              className="mx-auto flex max-w-md items-center justify-between gap-3 rounded-2xl border border-[color:var(--flag-red)]/30 bg-[color:var(--flag-red)]/10 px-4 py-3 text-xs"
            >
              <span className="min-w-0 flex-1">{error}</span>
              <button
                onClick={coach.retry}
                className="shrink-0 rounded-full bg-[color:var(--flag-red)] px-3 py-1 font-bold text-white"
              >
                تلاش دوباره
              </button>
            </div>
          )}
          {coach.busy && AI_ENABLED && (
            <div className="flex justify-center">
              <button
                onClick={coach.stop}
                className="rounded-full bg-secondary px-4 py-1.5 text-[11px] font-semibold transition hover:bg-accent"
              >
                ■ Stopp
              </button>
            </div>
          )}
        </div>

        {/* Quick prompts + input */}
        <div className="shrink-0 border-t border-border/60 bg-[color:var(--card)] px-3 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] lg:mt-4 lg:rounded-3xl lg:border lg:px-4 lg:pb-4">
          <div className="mb-2 flex gap-2 overflow-x-auto pb-1">
            {QUICK_PROMPTS.map((q) => (
              <button
                key={q.label}
                onClick={() => send(q.prompt)}
                className="shrink-0 whitespace-nowrap rounded-full bg-secondary px-3 py-1.5 text-[11px] font-semibold transition hover:bg-accent"
              >
                <span aria-hidden className="mr-1">
                  {q.icon}
                </span>
                {q.label}
              </button>
            ))}
          </div>
          <div className="flex items-end gap-2 rounded-3xl bg-secondary/60 p-2">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              rows={1}
              placeholder="Frage stellen…"
              className="max-h-32 min-h-[40px] min-w-0 flex-1 resize-none bg-transparent px-3 py-2 text-sm outline-none placeholder:text-muted-foreground"
            />
            <button
              onClick={() => send()}
              disabled={!input.trim() || coach.busy}
              aria-label="Senden"
              className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[color:var(--flag-red)] text-white shadow-md transition hover:opacity-95 disabled:opacity-40"
            >
              <svg
                viewBox="0 0 24 24"
                width="16"
                height="16"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M22 2 11 13" />
                <path d="M22 2l-7 20-4-9-9-4 20-7z" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function HistoryList({
  threads,
  activeId,
  onOpen,
  onDelete,
  onNew,
}: {
  threads: CoachUiThread[];
  activeId: string;
  onOpen: (id: string) => void;
  onDelete: (id: string) => void;
  onNew: () => void;
}) {
  return (
    <>
      <div className="mb-2 px-1 pt-1 text-xs font-bold text-muted-foreground">Chat-Verlauf</div>
      <button
        onClick={onNew}
        className="mb-3 w-full rounded-2xl bg-[color:var(--flag-red)] px-3 py-2 text-xs font-bold text-white shadow-sm transition hover:opacity-95"
      >
        + Neuer Chat
      </button>
      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto">
        {threads.map((t) => (
          <div
            key={t.id}
            className={`group flex items-center gap-1 rounded-2xl px-2 py-2 transition ${
              t.id === activeId ? "bg-secondary" : "hover:bg-secondary/60"
            }`}
          >
            <button onClick={() => onOpen(t.id)} className="min-w-0 flex-1 text-left">
              <div className="truncate text-xs font-semibold">{t.title}</div>
              <div className="text-[10px] text-muted-foreground">
                {relativeDay(t.updatedAt)} · {t.messageCount} Nachrichten
              </div>
            </button>
            <button
              onClick={() => onDelete(t.id)}
              aria-label="Chat löschen"
              className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-muted-foreground opacity-0 transition hover:bg-accent hover:text-foreground focus:opacity-100 group-hover:opacity-100"
            >
              🗑
            </button>
          </div>
        ))}
      </div>
    </>
  );
}

function AiAvatar() {
  return (
    <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[color:var(--flag-red)]/20 to-[color:var(--flag-gold)]/20 text-sm ring-1 ring-[color:var(--flag-red)]/30">
      ✨
    </div>
  );
}

function Dot({ delay }: { delay: number }) {
  return (
    <motion.span
      className="inline-block h-1.5 w-1.5 rounded-full bg-muted-foreground"
      animate={{ y: [0, -3, 0], opacity: [0.4, 1, 0.4] }}
      transition={{ duration: 0.9, repeat: Infinity, delay, ease: "easeInOut" }}
    />
  );
}

function renderMarkdownLite(text: string) {
  return text.split("\n").map((line, i) => {
    const nodes: (string | ReactElement)[] = [];
    const re = /(\*\*[^*]+\*\*|_[^_]+_)/g;
    let last = 0;
    let match: RegExpExecArray | null;
    let idx = 0;
    while ((match = re.exec(line))) {
      if (match.index > last) nodes.push(line.slice(last, match.index));
      const token = match[0];
      if (token.startsWith("**"))
        nodes.push(<strong key={`b${i}-${idx++}`}>{token.slice(2, -2)}</strong>);
      else nodes.push(<em key={`i${i}-${idx++}`}>{token.slice(1, -1)}</em>);
      last = match.index + token.length;
    }
    if (last < line.length) nodes.push(line.slice(last));
    return (
      <span key={i} className="block">
        {nodes.length ? nodes : "\u00A0"}
      </span>
    );
  });
}

function ChatBubble({
  msg,
}: {
  msg: { id: string; role: "user" | "ai"; text: string; time: string };
}) {
  const isUser = msg.role === "user";
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.2, 0.8, 0.2, 1] }}
      className={`flex items-end gap-2 ${isUser ? "flex-row-reverse" : ""}`}
    >
      {!isUser && <AiAvatar />}
      <div
        className={`flex min-w-0 max-w-[85%] flex-col sm:max-w-[75%] ${isUser ? "items-end" : "items-start"}`}
      >
        <div
          className={`rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
            isUser
              ? "rounded-br-md bg-[color:var(--flag-red)]/10 text-foreground ring-1 ring-[color:var(--flag-red)]/20"
              : "glass rounded-bl-md"
          }`}
        >
          <div className="whitespace-pre-wrap break-words">{renderMarkdownLite(msg.text)}</div>
        </div>
        <span className="mt-1 px-1 text-[10px] text-muted-foreground">{msg.time}</span>
      </div>
    </motion.div>
  );
}
