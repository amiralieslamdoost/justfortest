import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import type { Rating } from "@/lib/deusi/fsrs";
import { LeitnerBoxBar } from "@/components/deusi/learn/LeitnerBoxBar";
import { FaHint } from "@/components/deusi/FaHint";
import { accentColor } from "@/components/deusi/learn/learnHelpers";
import { RateBtn } from "@/components/deusi/learn/RateBtn";
import { CenterStage } from "@/components/deusi/learn/CenterStage";
import { SideColumn } from "@/components/deusi/learn/SideColumn";
import { LeitnerWordDetails } from "@/components/deusi/learn/LeitnerWordDetails";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "Lernen — DEUSI" },
      {
        name: "description",
        content: "Vokabeln mit Karteikarten und Spaced Repetition effektiv lernen.",
      },
      { property: "og:title", content: "Lernen — DEUSI" },
      {
        property: "og:description",
        content: "Vokabeln mit Karteikarten und Spaced Repetition effektiv lernen.",
      },
    ],
  }),
  component: Learn,
});

/* -------------- page -------------- */

function Learn() {
  const { currentUser, hydrated, dueCards, rate, ensureDeckFor } = useDeusi();
  const router = useRouter();
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [hoverRating, setHoverRating] = useState<Rating | null>(null);

  useEffect(() => {
    if (!hydrated) return;
    if (!currentUser) router.navigate({ to: "/login" });
    else ensureDeckFor(currentUser.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, currentUser?.id]);

  const queue = dueCards();
  const current = queue[0];
  const total = currentUser?.deck.length ?? 0;
  const done = total - queue.length;

  useEffect(() => {
    setRevealed(false);
    setHoverRating(null);
  }, [current?.word.id]);

  const onRate = (r: Rating) => {
    if (!current) return;
    if (!revealed) {
      setRevealed(true);
      return;
    }
    setRevealed(false);
    setTimeout(() => rate(current.word.id, r), 220);
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (detailsOpen) return;
      if (!current) return;
      if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        setRevealed((v) => !v);
        return;
      }
      if (e.key === "1") onRate("again");
      if (e.key === "2") onRate("hard");
      if (e.key === "3") onRate("good");
      if (e.key === "4") onRate("easy");
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.word.id, detailsOpen, revealed]);

  if (!currentUser) return null;

  if (!current) {
    return (
      <div className="mx-auto mt-16 max-w-xl neu-card p-10 text-center animate-fade">
        <div className="mb-3 text-5xl">🎉</div>
        <h1 className="mb-2 text-2xl font-bold">Fantastisch — alles erledigt!</h1>
        <FaHint size="sm" className="!mb-2 block">
          عالی بود — کارِ امروز تمام شد!
        </FaHint>
        <p className="mb-6 text-muted-foreground">
          Alle heutigen Karten sind wiederholt. Komm morgen wieder oder füge neue Vokabeln hinzu.
        </p>
        <FaHint size="sm" className="!mb-4 block">
          همهٔ کارت‌های امروز مرور شدند. فردا برگرد یا واژهٔ جدید اضافه کن.
        </FaHint>
        <div className="flex justify-center gap-3">
          <Link
            to="/dashboard"
            className="rounded-xl border border-border bg-card px-5 py-2.5 font-semibold hover:bg-secondary"
          >
            Zum Dashboard
          </Link>
          <Link
            to="/dictionary"
            className="rounded-xl px-5 py-2.5 font-semibold text-white"
            style={{ background: "var(--flag-black)" }}
          >
            + Neue Vokabel
          </Link>
        </div>
      </div>
    );
  }

  const w = current.word;
  const pct = Math.round(((done + 1) / (total || 1)) * 100);
  const accent = accentColor(w);

  return (
    <div className="learn-session-page relative isolate mx-auto flex min-h-[calc(100dvh-2.5rem)] max-w-6xl flex-col gap-2 py-1 sm:gap-5 sm:py-2 lg:h-[calc(100dvh-2.5rem)] lg:overflow-hidden lg:gap-5">
      <h1 className="sr-only">Lernen — Karteikarten wiederholen</h1>
      {/* Desktop composition: return control and progress share one compact top rail. */}
      <header className="learn-session-header flex shrink-0 items-center gap-3 lg:gap-4">
        <Link to="/dashboard" className="btn-back learn-compact-back">
          <span aria-hidden>←</span>
          <span className="learn-back-label">Zurück</span>
        </Link>
        <div className="learn-progress-panel flex flex-1 items-center gap-2 sm:gap-3">
          <div className="h-1 flex-1 overflow-hidden rounded-full bg-secondary sm:h-1.5">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${pct}%`, background: accent }}
            />
          </div>
          <div className="text-[11px] font-semibold text-muted-foreground tabular-nums whitespace-nowrap sm:text-xs">
            {done + 1} / {total}
          </div>
        </div>
      </header>

      {/* Live Leitner box overview */}
      <div className="learn-box-rail mx-auto w-full max-w-[54rem] lg:max-w-[50rem]">
        <LeitnerBoxBar
          deck={currentUser.deck}
          current={current.card}
          previewRating={revealed ? hoverRating : null}
        />
      </div>

      {/* Stage: on mobile pin to top so the card never shifts when content grows below.
          On desktop keep it visually centered. */}
      <div className="learn-session-stage flex min-h-0 flex-1 flex-col items-center justify-start lg:justify-center">
        <div className="relative flex min-h-0 w-full flex-1">
          {/* Desktop (≥lg): 3 Spalten mit Verbindungslinien */}
          <div className="hidden w-full lg:grid lg:grid-cols-[minmax(170px,1fr)_minmax(360px,500px)_minmax(170px,1fr)] lg:items-center lg:gap-x-6 xl:grid-cols-[minmax(200px,1fr)_minmax(390px,500px)_minmax(200px,1fr)] xl:gap-x-10">
            <SideColumn side="left" word={w} revealed={revealed} accent={accent} />
            <CenterStage
              word={w}
              revealed={revealed}
              onFlip={() => setRevealed((v) => !v)}
              onOpenDetails={() => setDetailsOpen(true)}
            />
            <SideColumn side="right" word={w} revealed={revealed} accent={accent} />
          </div>

          {/* Mobile & Tablet: Karte und Aktion bleiben im Viewport; Metadaten nur auf Desktop. */}
          <div className="learn-mobile-card-column flex h-full w-full min-h-0 flex-col items-center lg:hidden">
            <div className="flex min-h-0 flex-1 items-center justify-center">
              <CenterStage
                word={w}
                revealed={revealed}
                onFlip={() => setRevealed((v) => !v)}
                onOpenDetails={() => setDetailsOpen(true)}
              />
            </div>

            {/* Aktionszone mit stabiler Höhe, damit die Karte beim Umdrehen nicht springt */}
            <div className="learn-mobile-action mt-auto w-full shrink-0 pb-[max(0.25rem,env(safe-area-inset-bottom))]">
              {!revealed ? (
                <button
                  onClick={() => setRevealed(true)}
                  className="group relative mx-auto block w-full max-w-sm overflow-hidden rounded-xl px-5 py-2.5 text-sm font-bold text-white shadow-lg transition-transform duration-200 active:scale-[0.98] sm:rounded-2xl sm:px-6 sm:py-4 sm:text-base"
                  style={{
                    background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 70%, #000))`,
                    boxShadow: `0 14px 32px -12px ${accent}88`,
                  }}
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    <span>Antwort zeigen</span>
                    <span aria-hidden className="text-lg">
                      ↻
                    </span>
                  </span>
                </button>
              ) : (
                <div className="grid w-full grid-cols-4 gap-1 sm:gap-2">
                  <RateBtn
                    kind="again"
                    title="Nochmal"
                    onClick={() => onRate("again")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="hard"
                    title="Schwer"
                    onClick={() => onRate("hard")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="good"
                    title="Gut"
                    onClick={() => onRate("good")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="easy"
                    title="Einfach"
                    onClick={() => onRate("easy")}
                    onHover={setHoverRating}
                    compact
                  />
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* Reveal button or Rating pills — nur Desktop (≥lg) */}
      {!revealed ? (
        <div className="mx-auto hidden w-full max-w-2xl flex-col items-center gap-2 lg:flex">
          <button
            onClick={() => setRevealed(true)}
            className="group relative w-full max-w-sm overflow-hidden rounded-2xl px-6 py-4 text-base font-bold text-white shadow-lg transition hover:-translate-y-0.5 hover:shadow-xl active:scale-[0.98]"
            style={{
              background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 65%, #000))`,
              boxShadow: `0 18px 40px -12px ${accent}88`,
            }}
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              <span>Antwort zeigen</span>
              <span aria-hidden className="text-lg transition group-hover:translate-x-0.5">
                ↻
              </span>
            </span>
            <span
              aria-hidden
              className="absolute inset-0 bg-white/10 opacity-0 transition group-hover:opacity-100"
            />
          </button>
          <p className="sr-only">
            Tippe die Karte oder <b>Leertaste</b> zum Umdrehen
          </p>
        </div>
      ) : (
        <div className="mx-auto hidden w-full max-w-2xl flex-col items-center gap-2 lg:flex">
          <div className="flex w-full flex-wrap items-center justify-center gap-3">
            <RateBtn
              kind="again"
              title="Nochmal"
              onClick={() => onRate("again")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="hard"
              title="Schwer"
              onClick={() => onRate("hard")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="good"
              title="Gut"
              onClick={() => onRate("good")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="easy"
              title="Einfach"
              onClick={() => onRate("easy")}
              onHover={setHoverRating}
            />
          </div>
          <p className="sr-only">
            Bewerte, wie gut du dich erinnert hast · Tasten <b>1–4</b>
          </p>
        </div>
      )}

      {detailsOpen && <LeitnerWordDetails word={w} onClose={() => setDetailsOpen(false)} />}
    </div>
  );
}
