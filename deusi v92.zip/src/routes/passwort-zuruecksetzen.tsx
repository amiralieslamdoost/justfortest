import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import { CheckCircle2, Eye, EyeOff, KeyRound, Loader2, Lock } from "lucide-react";
import { AuthShell, AuthField } from "@/components/deusi/AuthShell";
import { useDeusi } from "@/lib/deusi/store";

type Search = { token?: string };

export const Route = createFileRoute("/passwort-zuruecksetzen")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    token: typeof search.token === "string" ? search.token : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Neues Passwort · DEUSI" },
      {
        name: "description",
        content: "Lege ein neues Passwort für dein DEUSI-Konto fest und melde dich wieder an.",
      },
      { property: "og:title", content: "Neues Passwort · DEUSI" },
      {
        property: "og:description",
        content: "Lege ein neues Passwort für dein DEUSI-Konto fest.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const { token } = Route.useSearch();
  const { confirmPasswordReset } = useDeusi();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (password.length < 8) return setErr("Das Passwort braucht mindestens 8 Zeichen.");
    if (password !== confirm) return setErr("Die Passwörter stimmen nicht überein.");
    setLoading(true);
    const res = await confirmPasswordReset(token ?? "", password);
    setLoading(false);
    if (!res.ok) return setErr(res.error ?? "Zurücksetzen fehlgeschlagen");
    setDone(true);
  };

  return (
    <AuthShell
      side="login"
      title="Neues Passwort"
      subtitle="Wähle ein sicheres Passwort für dein Konto."
      footer={
        <>
          Kein Link erhalten?{" "}
          <Link
            to="/passwort-vergessen"
            className="font-semibold hover:underline"
            style={{ color: "var(--flag-red)" }}
          >
            Neu anfordern
          </Link>
        </>
      }
    >
      <AnimatePresence mode="wait">
        {done ? (
          <motion.div
            key="done"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4 text-center"
          >
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-500/10 text-emerald-600">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <p className="text-sm text-muted-foreground">
              Dein Passwort wurde geändert. Du kannst dich jetzt wieder anmelden.
            </p>
            <p className="text-xs text-muted-foreground" dir="rtl">
              رمز عبور با موفقیت تغییر کرد. حالا می‌توانی وارد شوی.
            </p>
            <Link
              to="/login"
              className="inline-flex w-full items-center justify-center rounded-2xl px-4 py-3 text-sm font-bold text-white shadow-lg"
              style={{
                background: "linear-gradient(135deg, #1a1a1a 0%, #DD2222 60%, #F7C948 130%)",
              }}
            >
              Zur Anmeldung
            </Link>
          </motion.div>
        ) : (
          <motion.form
            key="form"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            onSubmit={submit}
            className="space-y-4"
          >
            <AuthField label="Neues Passwort">
              <div className="group relative">
                <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
                <input
                  type={show ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mind. 8 Zeichen"
                  autoComplete="new-password"
                  className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-11 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
                />
                <button
                  type="button"
                  onClick={() => setShow((s) => !s)}
                  aria-label={show ? "Passwort verbergen" : "Passwort anzeigen"}
                  className="absolute right-3 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-muted-foreground transition hover:text-foreground"
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </AuthField>

            <AuthField label="Passwort bestätigen">
              <div className="group relative">
                <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
                <input
                  type={show ? "text" : "password"}
                  required
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="Passwort wiederholen"
                  autoComplete="new-password"
                  className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-3 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
                />
              </div>
            </AuthField>

            {!token && (
              <p className="rounded-2xl border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-700">
                Kein gültiger Zurücksetz-Link erkannt. Fordere bitte einen neuen Link an.
              </p>
            )}

            {err && (
              <p className="rounded-2xl border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs font-semibold text-red-600">
                {err}
              </p>
            )}

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.98 }}
              className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl px-4 py-3 text-sm font-bold text-white shadow-lg transition disabled:opacity-60"
              style={{
                background: "linear-gradient(135deg, #1a1a1a 0%, #DD2222 60%, #F7C948 130%)",
                boxShadow: "0 20px 40px -18px rgba(221,34,34,0.65)",
              }}
            >
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Lock className="h-4 w-4" />
              )}
              <span className="relative">{loading ? "Speichere…" : "Passwort speichern"}</span>
            </motion.button>

            <p className="text-center text-xs text-muted-foreground" dir="rtl">
              رمز عبور جدیدت را دو بار وارد کن.
            </p>
          </motion.form>
        )}
      </AnimatePresence>
    </AuthShell>
  );
}
