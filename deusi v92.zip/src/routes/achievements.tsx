import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "@/lib/motion-lite";
import { useMemo, useState } from "react";
import {
  ArrowLeft,
  Trophy,
  Sparkles,
  Lock,
  Share2,
  Flame,
  Target,
  Zap,
  Copy,
  Check,
  X,
} from "lucide-react";
import {
  ACHIEVEMENTS,
  ACHIEVEMENT_CATEGORIES,
  type Achievement,
  type AchievementCategory,
} from "@/lib/deusi/achievements";
import {
  LEVEL,
  LEVEL_PCT,
  LEVEL_TITLE,
  LEVEL_XP_IN,
  LEVEL_XP_NEED,
  NEXT_LEVEL_TITLE,
  TOTAL_XP,
  RARITY_META,
  rarityOf,
  ownersPctOf,
  myRank,
  DAILY_XP_OPEN,
  RARITY_SUMMARY,
} from "@/lib/deusi/gamification";
import { useAchievements, useGamification, useMissions } from "@/lib/api/useGamification";
import { useWeekXp } from "@/lib/api/useStats";
import { Leaderboard } from "@/components/deusi/achievements/Leaderboard";
import { StreakWeekCard } from "@/components/deusi/achievements/StreakWeekCard";
import { RarityBar } from "@/components/deusi/achievements/RarityBar";
import { Fa } from "@/components/deusi/Fa";
import {
  FloatingDot,
  HeroChip,
  XpRing,
  HeroKpi,
} from "@/components/deusi/achievements/AchievementsHero";
import {
  NextUpCard,
  FunTile,
  LatestUnlockedCard,
} from "@/components/deusi/achievements/AchievementFunCards";
import { AchievementCard } from "@/components/deusi/achievements/AchievementCard";
import { ShareModal } from "@/components/deusi/achievements/ShareModal";

export const Route = createFileRoute("/achievements")({
  head: () => ({
    meta: [
      { title: "Deine Erfolge — DEUSI" },
      {
        name: "description",
        content:
          "Alle DEUSI-Erfolge auf einen Blick: Serien, Wortschatz, Grammatik, Hören, Lesen und Prüfungen.",
      },
      { property: "og:title", content: "Deine Erfolge — DEUSI" },
      {
        property: "og:description",
        content: "Sammle Abzeichen für jede Etappe deiner Deutschreise mit DEUSI.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AchievementsPage,
});

type Filter = "Alle" | "Freigeschaltet" | "Gesperrt" | AchievementCategory;

const FILTERS: Filter[] = ["Alle", "Freigeschaltet", "Gesperrt", ...ACHIEVEMENT_CATEGORIES];

function AchievementsPage() {
  const [filter, setFilter] = useState<Filter>("Alle");
  const [shareTarget, setShareTarget] = useState<Achievement | "all" | null>(null);

  /* سشن ۹: دستاوردها، سطح و مأموریت‌ها از بک‌اند (با fallback به mock). */
  const { achievements } = useAchievements();
  const { summary } = useGamification();
  const { daily } = useMissions();
  const { weekXp } = useWeekXp();

  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const totalCount = achievements.length;
  const progressPct = Math.round((unlockedCount / Math.max(totalCount, 1)) * 100);
  const latestUnlocked = useMemo<Achievement | undefined>(
    () =>
      [...achievements]
        .filter((a) => a.unlocked && a.unlockedAt)
        .sort((a, b) => (a.unlockedAt! < b.unlockedAt! ? 1 : -1))[0],
    [achievements],
  );

  const level = summary?.level ?? LEVEL;
  const levelPct = summary?.levelPct ?? LEVEL_PCT;
  const xpIn = summary?.xpInLevel ?? LEVEL_XP_IN;
  const xpNeed = summary?.xpNeeded ?? LEVEL_XP_NEED;
  const totalXp = summary?.xp ?? TOTAL_XP;
  const dailyDone = daily.filter((m) => m.current >= m.target).length;
  const rarityRows = useMemo(
    () =>
      RARITY_SUMMARY.map((r) => {
        const group = achievements.filter((a) => rarityOf(a.id) === r.rarity);
        return group.length
          ? { ...r, total: group.length, unlocked: group.filter((a) => a.unlocked).length }
          : r;
      }),
    [achievements],
  );

  const visible = useMemo(() => {
    if (filter === "Alle") return achievements;
    if (filter === "Freigeschaltet") return achievements.filter((a) => a.unlocked);
    if (filter === "Gesperrt") return achievements.filter((a) => !a.unlocked);
    return achievements.filter((a) => a.category === filter);
  }, [filter, achievements]);

  // Next achievement to unlock — the one closest to completion.
  const nextUp = useMemo<Achievement | undefined>(() => {
    const locked = achievements.filter((a) => !a.unlocked && a.progress);
    if (!locked.length) return undefined;
    return [...locked].sort((a, b) => {
      const pa = a.progress!.current / a.progress!.target;
      const pb = b.progress!.current / b.progress!.target;
      return pb - pa;
    })[0];
  }, [achievements]);

  const nextLevelIn = Math.max(1, 3 - (unlockedCount % 3));
  const rank = myRank("Woche");

  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 pb-16 sm:space-y-8">
      {/* Back link */}
      <Link
        to="/dashboard"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground transition hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
        <span>Dashboard</span>
      </Link>

      {/* Hero */}
      <header
        className="relative overflow-hidden rounded-[1.75rem] p-5 text-white shadow-2xl sm:rounded-[2rem] sm:p-8"
        style={{
          backgroundImage:
            "radial-gradient(120% 120% at 85% -10%, #FDE68A 0%, transparent 45%), radial-gradient(100% 100% at 0% 110%, #DB2777 0%, transparent 50%), linear-gradient(135deg, #7C2D12 0%, #EA580C 45%, #F59E0B 100%)",
        }}
      >
        {/* Ambient shapes */}
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/15 blur-3xl" />
          <div className="absolute -bottom-24 -left-10 h-56 w-56 rounded-full bg-yellow-200/30 blur-3xl" />
          <motion.div
            className="absolute -inset-x-1/2 -top-1/2 h-[200%] w-[60%] rotate-12 bg-gradient-to-r from-transparent via-white/12 to-transparent"
            animate={{ x: ["-20%", "220%"] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", repeatDelay: 2 }}
          />
          {/* Floating frosted dots (decorative) */}
          <FloatingDot size={7} className="left-[6%] top-[16%]" delay={0} opacity={0.55} />
          <FloatingDot size={7} className="left-[18%] top-[62%]" delay={0.4} opacity={0.45} />
          <FloatingDot size={7} className="left-[31%] top-[28%]" delay={0.8} opacity={0.5} />
          <FloatingDot size={7} className="left-[46%] top-[9%]" delay={1.2} opacity={0.45} />
          <FloatingDot size={7} className="left-[55%] top-[72%]" delay={1.6} opacity={0.5} />
          <FloatingDot size={7} className="right-[30%] bottom-[18%]" delay={2} opacity={0.5} />
          <FloatingDot size={7} className="right-[18%] top-[36%]" delay={2.4} opacity={0.45} />
          <FloatingDot size={7} className="right-[8%] top-[62%]" delay={2.8} opacity={0.5} />
          <FloatingDot size={7} className="left-[68%] bottom-[30%]" delay={3.2} opacity={0.45} />
          <FloatingDot size={7} className="left-[12%] bottom-[14%]" delay={3.6} opacity={0.5} />
        </div>

        <div className="relative grid gap-5 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center lg:gap-8">
          <div className="min-w-0">
            <div className="flex min-w-0 items-start gap-3 sm:gap-4">
              <XpRing pct={levelPct} level={level} />
              <div className="min-w-0 flex-1 lg:max-w-xl">
                <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.14em] backdrop-blur sm:text-[10px]">
                  <Sparkles className="h-3 w-3 shrink-0" aria-hidden />
                  Level {level} · {LEVEL_TITLE.de}
                </div>
                <h1 className="mt-2 text-[1.6rem] font-black leading-[1.05] sm:text-4xl">
                  Deine{" "}
                  <span className="bg-gradient-to-r from-white via-yellow-100 to-amber-200 bg-clip-text text-transparent">
                    Ruhmeshalle
                  </span>
                </h1>
                <Fa className="fa-hint-xs !text-white/85">تالار افتخارات تو</Fa>
                <p className="mt-2 max-w-lg text-[13px] leading-relaxed text-white/85 sm:text-sm">
                  Noch <b className="text-white tabular-nums">{Math.max(xpNeed - xpIn, 0)} XP</b>{" "}
                  bis Level {level + 1} — «{NEXT_LEVEL_TITLE.de}». Du bist Platz{" "}
                  <b className="text-white">#{rank}</b> diese Woche! <span aria-hidden>🔥</span>
                </p>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-1.5 sm:gap-2">
              <HeroChip>⚡ {totalXp.toLocaleString("de-DE")} XP gesamt</HeroChip>
              <HeroChip>
                🎯 {dailyDone}/{daily.length} Tagesmissionen
              </HeroChip>
              <HeroChip>🎁 +{DAILY_XP_OPEN} XP heute</HeroChip>
            </div>
          </div>

          <div className="grid w-full grid-cols-3 gap-2 lg:w-auto lg:min-w-[300px]">
            <HeroKpi value={unlockedCount} label="frei" icon="🏅" />
            <HeroKpi value={totalCount} label="gesamt" icon="🎯" />
            <HeroKpi value={`${progressPct}%`} label="Fortschritt" icon="⚡" />
          </div>
        </div>

        {/* Wide progress bar */}
        <div className="relative mt-6">
          <div className="h-3 w-full overflow-hidden rounded-full bg-black/25 ring-1 ring-white/25 sm:h-3.5">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPct}%` }}
              transition={{ duration: 1.1, ease: "easeOut" }}
              className="relative h-full rounded-full bg-gradient-to-r from-white via-yellow-100 to-amber-300 shadow-[0_0_22px_rgba(255,255,255,0.65)]"
            >
              <motion.span
                className="absolute right-0 top-1/2 hidden -translate-y-1/2 translate-x-1/2 text-lg sm:block"
                aria-hidden
                animate={{ y: [-1, -5, -1] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
              >
                🚀
              </motion.span>
            </motion.div>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-semibold text-white/85">
            <span>
              {unlockedCount} / {totalCount} Abzeichen
            </span>
            <span className="tabular-nums">{progressPct}%</span>
          </div>
        </div>

        {/* Share hero */}
        <div className="relative mt-5 flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShareTarget("all")}
            className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-sm font-black text-orange-600 shadow-lg ring-1 ring-white/60 transition hover:-translate-y-0.5 hover:shadow-xl active:translate-y-0"
          >
            <Share2 className="h-4 w-4" aria-hidden />
            Fortschritt teilen
          </button>
          <span className="text-[11px] font-semibold text-white/75">
            Zeig deinen Freunden, wie weit du bist!
          </span>
        </div>
      </header>

      {/* Fun bar: next up + streak + reward */}
      <div className="grid gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-3">
        {nextUp && <NextUpCard achievement={nextUp} />}
        <FunTile
          icon={<Flame className="h-5 w-5" />}
          gradient="linear-gradient(135deg, #F97316, #EF4444)"
          title="14-Tage-Serie"
          fa="سری ۱۴ روزه"
          hint="Bleib dran — jeder Tag zählt!"
          highlight="🔥 aktiv"
        />
        <FunTile
          icon={<Zap className="h-5 w-5" />}
          gradient="linear-gradient(135deg, #8B5CF6, #EC4899)"
          title="Nächste Belohnung"
          fa="جایزه بعدی"
          hint="Level up und schalte einen neuen Titel frei."
          highlight={`+${nextLevelIn * 50} XP`}
        />
      </div>

      {/* Weekly streak + rarity side by side */}
      <div className="grid gap-3 sm:gap-4 lg:grid-cols-2">
        <StreakWeekCard
          streakDays={summary?.streak.current}
          bestStreak={summary?.streak.longest}
          freezes={summary?.streak.freezesLeft}
          weekXp={weekXp}
        />
        <RarityBar summary={rarityRows} />
      </div>

      {/* Latest unlocked highlight */}
      {latestUnlocked && (
        <LatestUnlockedCard
          achievement={latestUnlocked}
          onShare={() => setShareTarget(latestUnlocked ?? null)}
        />
      )}

      {/* Collection header + filters */}
      <div className="flex flex-wrap items-end justify-between gap-2 pt-1">
        <div>
          <h2 className="text-lg font-black leading-tight sm:text-xl">Deine Sammlung</h2>
          <Fa className="fa-hint-xs">مجموعه نشان‌های تو</Fa>
        </div>
        <span className="rounded-full bg-secondary px-3 py-1 text-[11px] font-bold tabular-nums text-muted-foreground ring-1 ring-border">
          {visible.length} / {totalCount}
        </span>
      </div>
      <div className="-mx-1 -mt-3 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:flex-wrap sm:overflow-visible">
        {FILTERS.map((f) => {
          const active = f === filter;
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition ring-1 ${
                active
                  ? "bg-foreground text-background ring-foreground shadow-md"
                  : "bg-card text-muted-foreground ring-border hover:text-foreground hover:ring-foreground/40"
              }`}
            >
              {f}
            </button>
          );
        })}
      </div>

      {/* Grid */}
      {visible.length === 0 ? (
        <div className="neu-card p-10 text-center text-sm text-muted-foreground">
          Keine Erfolge in dieser Kategorie.
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
          {visible.map((a, i) => (
            <AchievementCard
              key={a.id}
              achievement={a}
              index={i}
              onShare={() => setShareTarget(a)}
            />
          ))}
        </div>
      )}

      {/* Leaderboard — نفرات برتر */}
      <Leaderboard />

      {shareTarget && (
        <ShareModal
          target={shareTarget}
          onClose={() => setShareTarget(null)}
          unlockedCount={unlockedCount}
          totalCount={totalCount}
          progressPct={progressPct}
        />
      )}
    </div>
  );
}
