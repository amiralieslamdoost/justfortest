import { createFileRoute, useRouter, Link, useNavigate } from "@tanstack/react-router";
import { HeroSearch } from "@/components/deusi/HeroSearch";
import { motion } from "@/lib/motion-lite";
import { useEffect, useMemo, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { GrammarCard } from "@/components/deusi/grammar/GrammarCard";
import { FaHint } from "@/components/deusi/FaHint";
import { SectionHero } from "@/components/deusi/SectionHero";
import {
  aiSuggestions,
  grammarCategories,
  grammarStats,
  type CEFR,
  type GrammarCategoryKey,
} from "@/lib/deusi/mockGrammar";
import { useGrammarTopics } from "@/lib/api/useGrammar";

export const Route = createFileRoute("/grammatik/")({
  head: () => ({
    meta: [
      { title: "Grammatik – DEUSI" },
      {
        name: "description",
        content: "Interaktive Grammatiklektionen: Fälle, Zeitformen, Konjunktiv und mehr.",
      },
    ],
  }),
  component: GrammarHome,
});

const LEVELS: (CEFR | "Alle")[] = ["Alle", "A1", "A2", "B1", "B2", "C1", "C2"];

// Persian translations for common grammar topic names / subtitles shown in headers.
const TOPIC_NAME_FA: Record<string, string> = {
  Nominativ: "حالت فاعلی — کی/چی؟",
  Akkusativ: "حالت مفعولی مستقیم — چه‌کسی/چه‌چیزی را؟",
  Dativ: "حالت مفعولی غیرمستقیم — به‌ چه‌کسی؟",
  Genitiv: "حالت اضافی — مالِ چه‌کسی؟",
  Präsens: "زمان حال",
  Perfekt: "گذشتهٔ نقلی (گفتاری)",
  Präteritum: "گذشتهٔ ساده (نوشتاری)",
  Plusquamperfekt: "گذشتهٔ بعید",
  "Futur I": "آینده و احتمال",
  "Futur II": "آیندهٔ کامل",
  "der, die, das": "حروف تعریف معین",
  "ein / eine / ein": "حروف تعریف نامعین",
  "kein & Nullartikel": "منفی‌سازی و بدون حرف تعریف",
  Artikeldeklination: "صرف کامل حروف تعریف",
};
function topicFa(name: string, _subtitle: string): string {
  return TOPIC_NAME_FA[name] ?? "درس گرامری";
}

function GrammarHome() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  const [level, setLevel] = useState<CEFR | "Alle">("Alle");
  const [category, setCategory] = useState<GrammarCategoryKey | "all">("all");
  const [search, setSearch] = useState("");

  const { topics: grammarTopics, stats: liveStats } = useGrammarTopics();

  const stats = useMemo(() => ({ ...grammarStats(), ...liveStats }), [liveStats]);
  const cont = useMemo(
    () => grammarTopics.find((t) => t.completion > 0 && t.completion < 100) ?? grammarTopics[0],
    [grammarTopics],
  );
  const recs = useMemo(
    () => grammarTopics.filter((t) => t.completion < 60).slice(0, 4),
    [grammarTopics],
  );
  const recent = useMemo(
    () => grammarTopics.filter((t) => t.completion > 0).slice(0, 3),
    [grammarTopics],
  );
  const ai = aiSuggestions();

  const filtered = useMemo(() => {
    return grammarTopics.filter((t) => {
      if (level !== "Alle" && t.difficulty !== level) return false;
      if (category !== "all" && t.category !== category) return false;
      if (search && !`${t.name} ${t.subtitle}`.toLowerCase().includes(search.toLowerCase()))
        return false;
      return true;
    });
  }, [grammarTopics, level, category, search]);

  const navigate = useNavigate();
  const suggestions = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [];
    return grammarTopics
      .filter((t) => `${t.name} ${t.subtitle}`.toLowerCase().includes(q))
      .slice(0, 6);
  }, [grammarTopics, search]);

  if (!currentUser) return null;

  return (
    <div className="w-full space-y-8 animate-fade">
      {/* Unified section header */}
      <SectionHero
        sectionKey="grammar"
        allowOverflow
        right={
          <HeroSearch
            value={search}
            onValueChange={setSearch}
            placeholder="Grammatik suchen…"
            ariaLabel="Grammatikthemen durchsuchen"
            emptyText="Keine Themen"
            className="w-full sm:w-80"
            items={suggestions.map((t) => ({
              id: t.id,
              title: t.name,
              sub: t.subtitle,
              badge: t.difficulty,
              glyph: t.emoji,
              color: t.accent,
            }))}
            totalCount={filtered.length}
            onSelect={(id) => navigate({ to: "/grammatik/$topicId", params: { topicId: id } })}
            onSubmit={() =>
              document
                .getElementById("grammatik-results")
                ?.scrollIntoView({ behavior: "smooth", block: "start" })
            }
          />
        }
      />

      {/* Stats */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <StatCard
          label="Gesamtfortschritt"
          fa="پیشرفت کلی"
          value={`${stats.avgCompletion}%`}
          sub={`+${stats.weekProgress}% diese Woche`}
          accent="#7c5cff"
        />
        <StatCard
          label="Grammatikpunkte"
          fa="امتیاز گرامر"
          value={`${stats.xp} XP`}
          sub={`Level ${stats.level}`}
          accent="#f59e0b"
        />
        <StatCard
          label="Lektionen"
          fa="درس‌ها"
          value={`${stats.doneLessons}/${stats.totalLessons}`}
          sub="abgeschlossen"
          accent="#22c55e"
        />
        <StatCard
          label="Genauigkeit"
          fa="دقت"
          value={`${stats.accuracy}%`}
          sub="letzte 7 Tage"
          accent="#0ea5e9"
        />
        <StatCard
          label="Streak"
          fa="روزهای پیاپی"
          value={`${stats.streak} Tage`}
          sub="🔥 dranbleiben!"
          accent="#ef4444"
        />
        <StatCard
          label="Zeit investiert"
          fa="زمان صرف‌شده"
          value={stats.timeSpent}
          sub="gesamt"
          accent="#ec4899"
        />
      </section>

      {/* Continue + AI */}
      <section className="grid gap-5 lg:grid-cols-5">
        {/* Continue Learning Hero */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:col-span-3"
        >
          <div className="glass group relative flex h-full flex-col gap-4 overflow-hidden rounded-3xl p-6 transition-shadow hover:shadow-xl md:p-8">
            <div
              aria-hidden
              className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full opacity-40 blur-3xl transition-opacity group-hover:opacity-70"
              style={{ background: cont.accent }}
            />

            <div className="relative flex items-start justify-between gap-3">
              <div
                className="grid h-20 w-20 shrink-0 place-items-center rounded-3xl text-4xl shadow-inner"
                style={{ background: `${cont.accent}22`, color: cont.accent }}
              >
                {cont.emoji}
              </div>
              <div className="flex flex-wrap items-center justify-end gap-1.5">
                <span
                  className="rounded-full px-2.5 py-1 text-[11px] font-semibold"
                  style={{ background: `${cont.accent}22`, color: cont.accent }}
                >
                  {cont.difficulty}
                </span>
                <span className="rounded-full border border-border/60 bg-card/70 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground backdrop-blur">
                  Weiterlernen
                </span>
              </div>
            </div>

            <div className="relative min-w-0">
              <h2 className="text-2xl font-black leading-tight md:text-3xl">{cont.name}</h2>
              <p className="mt-1 text-sm text-muted-foreground md:text-base">{cont.subtitle}</p>
              <FaHint size="sm" className="mt-1.5 !opacity-100">
                {topicFa(cont.name, cont.subtitle)}
              </FaHint>
            </div>

            <div className="relative mt-auto space-y-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground md:text-sm">
                <span>⏱ {cont.duration} Min</span>
                <span className="font-semibold text-foreground">{cont.completion}%</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${cont.completion}%` }}
                  transition={{ duration: 0.9, ease: "easeOut" }}
                  className="h-full rounded-full"
                  style={{ background: cont.accent }}
                />
              </div>
            </div>

            <div className="relative flex flex-wrap items-center gap-3">
              <Link
                to="/grammatik/$topicId"
                params={{ topicId: cont.id }}
                className="group/btn inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold text-white transition-all hover:-translate-y-0.5"
                style={{
                  background: `linear-gradient(135deg, ${cont.accent}, ${cont.accent}cc)`,
                  boxShadow: `0 10px 30px -8px ${cont.accent}80`,
                }}
              >
                <span>Lektion fortsetzen</span>
                <span className="transition-transform group-hover/btn:translate-x-1">→</span>
              </Link>
              <Link
                to="/grammatik/$topicId"
                params={{ topicId: cont.id }}
                className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-card/70 px-4 py-2.5 text-sm font-semibold text-foreground backdrop-blur transition hover:bg-accent"
              >
                Details
              </Link>
            </div>
          </div>
        </motion.div>

        {/* AI Recommendations */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-2"
        >
          <div className="relative h-full overflow-hidden rounded-[28px] p-[1.5px] bg-gradient-to-br from-[#7c5cff] via-[#ec4899] to-[#f59e0b]">
            <div className="relative h-full overflow-hidden rounded-[26px] bg-background p-5 md:p-6">
              <div
                aria-hidden
                className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-gradient-to-br from-[#7c5cff]/40 to-[#ec4899]/20 blur-3xl"
              />

              <div className="relative mb-4 flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <motion.span
                    animate={{ rotate: [0, 8, -6, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-[#7c5cff] to-[#ec4899] text-lg text-white shadow-lg shadow-[#7c5cff]/30"
                  >
                    ✨
                  </motion.span>
                  <div>
                    <h3 className="text-base font-black leading-tight">KI-Empfehlungen</h3>
                    <FaHint size="sm" inline>
                      پیشنهادهای هوش مصنوعی
                    </FaHint>
                  </div>
                </div>
                <span className="rounded-full bg-gradient-to-r from-[#7c5cff]/10 to-[#ec4899]/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-[#7c5cff]">
                  Live
                </span>
              </div>

              <ul className="relative space-y-2">
                {ai.map((t, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 + i * 0.07 }}
                    className="group/item relative flex items-start gap-3 rounded-2xl border border-border/50 bg-background/60 p-3 text-sm transition-all hover:border-[#7c5cff]/40 hover:bg-accent/40 hover:shadow-md"
                  >
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-[#7c5cff]/15 to-[#ec4899]/15 text-[11px] font-black text-[#7c5cff]">
                      {i + 1}
                    </span>
                    <span className="leading-snug text-foreground">{t}</span>
                    <span className="ml-auto self-center opacity-0 transition-opacity group-hover/item:opacity-100 text-[#ec4899]">
                      →
                    </span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Filters */}
      <section className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          {LEVELS.map((l) => (
            <button
              key={l}
              onClick={() => setLevel(l)}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${level === l ? "bg-foreground text-background" : "bg-muted text-muted-foreground hover:bg-accent"}`}
            >
              {l}
            </button>
          ))}
          <div className="mx-2 h-4 w-px bg-border" />
          <button
            onClick={() => setCategory("all")}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold ${category === "all" ? "bg-foreground text-background" : "bg-muted text-muted-foreground"}`}
          >
            Alle Kategorien
          </button>
          {grammarCategories.map((c) => (
            <button
              key={c.key}
              onClick={() => setCategory(c.key)}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${category === c.key ? "text-white" : "bg-muted text-muted-foreground hover:bg-accent"}`}
              style={category === c.key ? { background: c.color } : undefined}
            >
              <span>{c.emoji}</span>
              {c.name}
            </button>
          ))}
        </div>
      </section>

      {/* Grid */}
      <section id="grammatik-results" className="scroll-mt-24">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">
              Alle Themen{" "}
              <span className="text-sm font-normal text-muted-foreground">({filtered.length})</span>
            </h2>
            <FaHint size="sm">همه موضوعات</FaHint>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((t, i) => (
            <GrammarCard key={t.id} topic={t} index={i} />
          ))}
        </div>
      </section>

      {/* Recommended */}
      <section>
        <h2 className="text-xl font-bold">Empfohlen für dich</h2>
        <FaHint className="mb-3" size="sm">
          پیشنهاد شده برای تو
        </FaHint>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {recs.map((t, i) => (
            <GrammarCard key={t.id} topic={t} index={i} />
          ))}
        </div>
      </section>

      {/* Recent */}
      <section>
        <h2 className="text-xl font-bold">Zuletzt gelernt</h2>
        <FaHint className="mb-3" size="sm">
          آخرین درس‌های خوانده‌شده
        </FaHint>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {recent.map((t, i) => (
            <GrammarCard key={t.id} topic={t} index={i} />
          ))}
        </div>
      </section>
    </div>
  );
}

function StatCard({
  label,
  fa,
  value,
  sub,
  accent,
}: {
  label: string;
  fa?: string;
  value: string;
  sub: string;
  accent: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="glass relative overflow-hidden rounded-2xl p-4"
    >
      <div
        className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-30 blur-2xl"
        style={{ background: accent }}
      />
      <div className="break-words text-[11px] font-semibold uppercase leading-tight tracking-wider text-muted-foreground">
        {label}
      </div>

      {fa && (
        <FaHint size="sm" inline>
          {fa}
        </FaHint>
      )}
      <div className="mt-1 text-2xl font-black text-foreground">{value}</div>
      <div className="text-xs text-muted-foreground">{sub}</div>
    </motion.div>
  );
}
