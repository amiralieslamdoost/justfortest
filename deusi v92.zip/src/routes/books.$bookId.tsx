import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "@/lib/motion-lite";
import { ArrowLeft, BookOpen, ChevronDown, Plus, Sparkles } from "lucide-react";

import { useDeusi } from "@/lib/deusi/store";
import { useInteractions } from "@/lib/deusi/interactions";
import { useLeitnerQueue } from "@/lib/deusi/dictionary/leitnerQueue";
import { LEARNING_BOOKS } from "@/lib/deusi/dictionary/books";
import { useBook, useMediaProgress } from "@/lib/api/useMedia";
import { ALL_WORDS, findById } from "@/lib/deusi/dictionary/mockWords";
import { FaHint } from "@/components/deusi/FaHint";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import { WordCard } from "@/components/deusi/dictionary/WordCard";
import { WordDetailPanel } from "@/components/deusi/dictionary/WordDetailPanel";

export const Route = createFileRoute("/books/$bookId")({
  component: BookVocabulary,
  head: ({ params }) => {
    const book = LEARNING_BOOKS.find((b) => b.id === params.bookId);
    const title = book ? `${book.title} — Wortschatz` : "Wortschatz";
    return {
      meta: [
        { title },
        {
          name: "description",
          content: book
            ? `${book.wordCount} Vokabeln aus ${book.title} (${book.publisher}) — Lektion für Lektion lernen.`
            : "Buchvokabeln lernen.",
        },
        { property: "og:title", content: title },
      ],
    };
  },
});

const LESSON_COUNT = 12;
const PAGE_SIZE = 10;

/* Deterministic pseudo-shuffle so lessons are stable across renders */
function seededShuffle<T>(arr: T[], seed: number): T[] {
  const out = arr.slice();
  let s = seed;
  for (let i = out.length - 1; i > 0; i--) {
    s = (s * 9301 + 49297) % 233280;
    const j = Math.floor((s / 233280) * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function hashString(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h) || 1;
}

function BookVocabulary() {
  const { bookId } = Route.useParams();
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  const { isBookmarked, isFavorited, toggleBookmark, toggleFavorite } = useInteractions();
  const leitner = useLeitnerQueue();

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  // کتاب از لایهٔ API (بک‌اند یا fallback محلی) — سشن ۵.
  const { book } = useBook(bookId);
  const { state: bookProgress, patch: patchBookProgress } = useMediaProgress("book", bookId);
  const [activeLesson, setActiveLesson] = useState(1);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [activeLesson, bookId]);

  // Build the full ordered vocabulary pool for this book: curated ids first, then a
  // deterministic shuffle of the remaining ALL_WORDS to simulate the book's list.
  const bookWords: DictWord[] = useMemo(() => {
    if (!book) return [];
    const curated = book.wordIds.map((id) => findById(id)).filter(Boolean) as DictWord[];
    const remaining = ALL_WORDS.filter((w) => !book.wordIds.includes(w.id));
    const shuffled = seededShuffle(remaining, hashString(book.id));
    // Repeat pool if needed so every lesson has at least 10 words
    const needed = LESSON_COUNT * 15;
    const pool: DictWord[] = [...curated, ...shuffled];
    while (pool.length < needed) pool.push(...shuffled);
    return pool.slice(0, needed);
  }, [book]);

  const lessons = useMemo(() => {
    const perLesson = Math.max(10, Math.ceil(bookWords.length / LESSON_COUNT));
    return Array.from({ length: LESSON_COUNT }, (_, i) =>
      bookWords.slice(i * perLesson, (i + 1) * perLesson),
    );
  }, [bookWords]);

  if (!currentUser || !book) {
    if (!book && typeof window !== "undefined") {
      // silently redirect on invalid id
    }
    return book ? null : (
      <div className="mx-auto max-w-2xl p-8 text-center">
        <div className="text-6xl">📕</div>
        <h1 className="mt-4 text-xl font-semibold">Buch nicht gefunden</h1>
        <Link
          to="/dictionary"
          className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
        >
          <ArrowLeft className="h-4 w-4" /> Zurück zum Wörterbuch
        </Link>
      </div>
    );
  }

  const lessonWords = lessons[activeLesson - 1] ?? [];
  const visibleWords = lessonWords.slice(0, visibleCount);
  const hasMore = visibleCount < lessonWords.length;

  const selectedWord = selectedId ? (findById(selectedId) ?? null) : null;

  /**
   * «positionSec» برای کتاب شمارهٔ درس جاری است. درصد از تعداد درس‌های دیده‌شده
   * و واژه‌های نمایش‌داده‌شده محاسبه می‌شود تا هم در Mock و هم در PocketBase
   * بدون نیاز به مدل دادهٔ جداگانه برای درس‌ها ذخیره و همگام شود.
   */
  const recordLessonProgress = (lesson: number, shownWords: number) => {
    const totalWords = lessons[lesson - 1]?.length ?? 0;
    const lessonPart = totalWords ? Math.min(1, shownWords / totalWords) : 0;
    const percent = Math.min(100, Math.round(((lesson - 1 + lessonPart) / LESSON_COUNT) * 100));
    patchBookProgress({
      positionSec: lesson,
      progress: Math.max(bookProgress.progress, percent),
      finished: percent >= 100,
      plays: Math.max(bookProgress.plays, 1),
    });
  };

  const selectLesson = (lesson: number) => {
    setActiveLesson(lesson);
    recordLessonProgress(lesson, 0);
  };

  const detailPortal =
    typeof document === "undefined"
      ? null
      : createPortal(
          <AnimatePresence>
            {selectedWord && (
              <motion.div
                key="book-detail"
                initial={{ opacity: 0, y: -14, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -14, scale: 0.98 }}
                transition={{ type: "spring", stiffness: 280, damping: 28 }}
                className="fixed inset-x-2 top-16 bottom-2 z-50 overflow-hidden rounded-3xl bg-card shadow-2xl ring-1 ring-border/70 sm:inset-x-4 lg:hidden"
              >
                <WordDetailPanel
                  word={selectedWord}
                  favorite={isFavorited("word", selectedWord.id)}
                  bookmarked={isBookmarked("word", selectedWord.id)}
                  inLeitner={leitner.has(selectedWord.id)}
                  onClose={() => setSelectedId(null)}
                  onToggleFavorite={() =>
                    toggleFavorite("word", selectedWord.id, selectedWord.headword)
                  }
                  onToggleBookmark={() =>
                    toggleBookmark("word", selectedWord.id, selectedWord.headword)
                  }
                  onToggleLeitner={() => leitner.toggle(selectedWord.id, selectedWord.headword)}
                  onOpenWord={(id) => setSelectedId(id)}
                />
              </motion.div>
            )}
          </AnimatePresence>,
          document.body,
        );

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_420px] animate-fade">
      <div className="space-y-5">
        {/* Header hero */}
        <section
          className="glass relative overflow-hidden rounded-3xl p-6"
          style={{
            background: `linear-gradient(135deg, ${book.color}22, ${book.color}08)`,
          }}
        >
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 overflow-hidden rounded-3xl"
          >
            <div
              className="absolute -right-20 -top-20 h-64 w-64 rounded-full opacity-40 blur-3xl"
              style={{ background: `radial-gradient(circle, ${book.color}66, transparent 60%)` }}
            />
            <div
              className="absolute -bottom-24 -left-10 h-56 w-56 rounded-full opacity-30 blur-3xl"
              style={{ background: `radial-gradient(circle, ${book.color}55, transparent 60%)` }}
            />
          </div>

          <div className="relative z-10 flex items-start gap-4">
            <Link
              to="/dictionary"
              className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-border/70 bg-card/80 text-muted-foreground shadow-sm backdrop-blur transition hover:bg-card hover:text-foreground"
              aria-label="Zurück"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>

            <div className="flex flex-1 flex-wrap items-center gap-5">
              {/* Cover */}
              <div
                className="relative flex h-28 w-20 shrink-0 items-center justify-center overflow-hidden rounded-xl text-4xl shadow-lg sm:h-32 sm:w-24"
                style={{ background: `linear-gradient(160deg, ${book.color}55, ${book.color}22)` }}
              >
                {book.coverUrl ? (
                  <img
                    loading="lazy"
                    decoding="async"
                    src={book.coverUrl}
                    alt={book.title}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span>{book.cover}</span>
                )}
                <span
                  className="absolute left-1 top-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold text-white shadow"
                  style={{ background: book.color }}
                >
                  {book.level}
                </span>
              </div>

              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                  {book.publisher}
                </div>
                <h1 className="mt-1 truncate text-2xl font-bold tracking-tight sm:text-3xl">
                  {book.title}
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  Lektion für Lektion — {book.wordCount} Vokabeln entdecken.
                </p>
                <FaHint size="sm">درس‌به‌درس — {book.wordCount} واژه رو کشف کن</FaHint>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <Stat
                    icon={<BookOpen className="h-3.5 w-3.5" />}
                    label={`${LESSON_COUNT} Lektionen`}
                    color={book.color}
                  />
                  <Stat
                    icon={<Sparkles className="h-3.5 w-3.5" />}
                    label={`${book.wordCount} Wörter`}
                    color={book.color}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Lesson tabs */}
        <section className="neu-card p-4 sm:p-5">
          <div className="mb-3 flex items-center justify-between gap-2">
            <h2 className="text-sm font-semibold">Lektionen</h2>
            <span className="text-xs text-muted-foreground">
              Wähle eine Lektion ·{" "}
              <FaHint size="sm" inline>
                یک درس انتخاب کن
              </FaHint>
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {Array.from({ length: LESSON_COUNT }, (_, i) => i + 1).map((n) => {
              const active = n === activeLesson;
              return (
                <button
                  key={n}
                  type="button"
                  onClick={() => selectLesson(n)}
                  className={`relative rounded-xl px-3 py-2 text-xs font-semibold transition ${
                    active
                      ? "text-white shadow-md"
                      : "border border-border/70 bg-card text-foreground hover:-translate-y-0.5 hover:shadow"
                  }`}
                  style={active ? { background: book.color } : undefined}
                >
                  Lektion {n}
                </button>
              );
            })}
          </div>
        </section>

        {/* Words for the active lesson */}
        <section className="neu-card p-5">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-2">
              <span
                className="grid h-8 w-8 place-items-center rounded-full text-xs font-bold text-white shadow"
                style={{ background: book.color }}
              >
                {activeLesson}
              </span>
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold">Lektion {activeLesson}</div>
                <div className="text-[11px] text-muted-foreground">
                  {visibleWords.length} von {lessonWords.length} Wörtern
                </div>
              </div>
            </div>
            <span className="shrink-0 rounded-full border border-border/60 bg-muted/50 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
              10er-Pakete
            </span>
          </div>

          {lessonWords.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border/70 bg-muted/30 p-8 text-center text-sm text-muted-foreground">
              Keine Wörter für diese Lektion.
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <AnimatePresence initial={false}>
                  {visibleWords.map((w, idx) => (
                    <motion.div
                      key={w.id + "-" + idx}
                      layout
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.25, delay: Math.min(idx % PAGE_SIZE, 9) * 0.03 }}
                    >
                      <WordCard
                        word={w}
                        bookmarked={isBookmarked("word", w.id)}
                        inLeitner={leitner.has(w.id)}
                        onOpen={() => {
                          recordLessonProgress(activeLesson, visibleWords.length);
                          setSelectedId(w.id);
                        }}
                        onToggleBookmark={() => toggleBookmark("word", w.id, w.headword)}
                        onToggleLeitner={() => leitner.toggle(w.id, w.headword)}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              <div className="mt-6 flex flex-col items-center justify-center gap-2">
                {hasMore ? (
                  <button
                    type="button"
                    onClick={() =>
                      setVisibleCount((current) => {
                        const next = Math.min(current + PAGE_SIZE, lessonWords.length);
                        recordLessonProgress(activeLesson, next);
                        return next;
                      })
                    }
                    className="group inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold text-white shadow-lg transition hover:-translate-y-0.5 hover:shadow-xl active:translate-y-0"
                    style={{
                      background: `linear-gradient(135deg, ${book.color}, ${book.color}cc)`,
                    }}
                  >
                    <Plus className="h-4 w-4 transition group-hover:rotate-90" />
                    10 weitere Wörter laden
                    <ChevronDown className="h-4 w-4" />
                  </button>
                ) : (
                  <div className="rounded-full border border-border/60 bg-muted/40 px-4 py-2 text-xs font-medium text-muted-foreground">
                    ✓ Alle Wörter dieser Lektion sind sichtbar
                  </div>
                )}
                <div className="text-[11px] text-muted-foreground">
                  {visibleWords.length} / {lessonWords.length}
                </div>
              </div>
            </>
          )}
        </section>
      </div>

      {/* Desktop side panel */}
      <div className="sticky top-5 hidden h-[calc(100vh-2.5rem)] self-start lg:block">
        {selectedWord ? (
          <WordDetailPanel
            word={selectedWord}
            favorite={isFavorited("word", selectedWord.id)}
            bookmarked={isBookmarked("word", selectedWord.id)}
            inLeitner={leitner.has(selectedWord.id)}
            onClose={() => setSelectedId(null)}
            onToggleFavorite={() => toggleFavorite("word", selectedWord.id, selectedWord.headword)}
            onToggleBookmark={() => toggleBookmark("word", selectedWord.id, selectedWord.headword)}
            onToggleLeitner={() => leitner.toggle(selectedWord.id, selectedWord.headword)}
            onOpenWord={(id) => setSelectedId(id)}
          />
        ) : (
          <div className="glass flex h-full flex-col items-center justify-center gap-3 rounded-3xl p-8 text-center text-muted-foreground">
            <span className="text-5xl">👉</span>
            <div className="text-sm font-medium text-foreground">Klicke auf ein Wort</div>
            <div className="text-xs">Details, Beispiele und Grammatik erscheinen hier.</div>
          </div>
        )}
      </div>

      {detailPortal}
    </div>
  );
}

function Stat({ icon, label, color }: { icon: React.ReactNode; label: string; color: string }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-card/70 px-2.5 py-1 text-[11px] font-semibold backdrop-blur"
      style={{ color }}
    >
      {icon} {label}
    </span>
  );
}
