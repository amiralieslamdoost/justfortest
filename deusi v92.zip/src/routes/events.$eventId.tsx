import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import { Users } from "lucide-react";
import { useMemo, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { type LevelBand } from "@/lib/deusi/events/mockEvents";
import { loadEvent } from "@/lib/api/events";
import { totalStats, useEventState } from "@/lib/deusi/events/store";
import { TableDiagram } from "@/components/deusi/events/TableDiagram";
import { ErrorCard } from "@/components/deusi/ErrorCard";
import { FaHint } from "@/components/deusi/FaHint";

export const Route = createFileRoute("/events/$eventId")({
  component: EventDetailPage,
  loader: async ({ params }) => {
    const event = await loadEvent(params.eventId);
    if (!event) throw notFound();
    return { event };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Event nicht gefunden — DEUSI" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.event.title} — Event | DEUSI`;
    const desc = `${loaderData.event.title}: Deutsch sprechen und üben mit anderen Lernenden.`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
      ],
    };
  },
  errorComponent: ({ error, reset }) => <ErrorCard error={error} reset={reset} />,
  notFoundComponent: () => (
    <div className="grid min-h-[50vh] place-items-center text-center">
      <div>
        <div className="text-4xl">🫥</div>
        <h2 className="mt-3 text-xl font-bold">Event nicht gefunden</h2>
        <Link to="/events" className="mt-4 inline-block text-sm font-semibold underline">
          Zurück zu allen Events
        </Link>
      </div>
    </div>
  ),
});

function EventDetailPage() {
  const { event } = Route.useLoaderData();
  const { currentUser } = useDeusi();
  const router = useRouter();
  const state = useEventState(event);
  const stats = useMemo(() => totalStats(event, state.groups), [event, state.groups]);
  const [levelFilter, setLevelFilter] = useState<LevelBand | "Alle">("B1-B2");
  const [orderDraft, setOrderDraft] = useState("");
  const [justRegistered, setJustRegistered] = useState(false);

  const myReg = state.myRegistration;
  const attendeeName = currentUser?.username?.trim() || "DEUSI Lernende:r";
  const myGroup = state.groups.find((g) => g.id === myReg?.groupId);
  const myOrder = myGroup?.reservations.find((r) => r.seat === myReg?.seat)?.order;

  const visibleGroups =
    levelFilter === "Alle" ? state.groups : state.groups.filter((g) => g.level === levelFilter);

  return (
    <div className="space-y-6 pb-16">
      {/* Back */}
      <div className="flex items-center justify-between">
        <button onClick={() => router.history.back()} className="btn-back">
          <span aria-hidden>←</span> Zurück
        </button>
        <div className="text-xs text-muted-foreground">
          Events / <span className="text-foreground">{event.title}</span>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
        {/* Main column */}
        <div className="space-y-6">
          {/* Hero */}
          <motion.section
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="neu-card overflow-hidden p-5 md:p-6"
          >
            <div className="grid gap-6 md:grid-cols-[280px_1fr]">
              <div className="relative aspect-square overflow-hidden rounded-3xl">
                <img
                  loading="lazy"
                  decoding="async"
                  src={event.cover}
                  alt={event.title}
                  width={1024}
                  height={1024}
                  className="h-full w-full object-cover"
                />
                <span className="glass absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-wider">
                  🍽 Deutsch Café
                </span>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-2xl font-bold tracking-tight md:text-3xl">{event.title}</h1>
                  <span
                    className="rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-widest"
                    style={{ background: "color-mix(in oklab, var(--foreground) 8%, transparent)" }}
                  >
                    {event.organizer.name}
                  </span>
                </div>
                <p className="mt-2 max-w-lg text-sm text-muted-foreground">
                  {event.shortDescription}
                </p>

                <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <MetaTile icon="📅" label={event.weekday} value={event.dateShort} />
                  <MetaTile icon="⏱" label={event.time} value={event.duration} />
                  <MetaTile
                    icon="📍"
                    label={event.locationName}
                    value={event.locationAddress}
                    small
                  />
                  <MetaTile icon="📶" label="Niveau" value={event.levelSummary} />
                </div>

                <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <MetaTile
                    icon="👥"
                    label={`${event.groupsCount} Gruppen`}
                    value={`${event.seatsPerGroup} Personen pro Gruppe`}
                    small
                  />
                  <MetaTile icon="🎚" label="Zwei Niveaus" value={event.bands.join(" & ")} small />
                  <MetaTile
                    icon="💬"
                    label={`${event.themesCount} Themen`}
                    value="Jeden Level zwei Themen"
                    small
                  />
                  <MetaTile
                    icon="☕"
                    label="Café Bestellung"
                    value="Mindestens 1 Bestellung"
                    small
                  />
                </div>
              </div>
            </div>
          </motion.section>

          {/* Groups / Seats */}
          <motion.section
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="neu-card p-5 md:p-6"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div>
                  <h2 className="text-lg font-bold">Wähle deinen Platz</h2>
                  <FaHint size="sm">جای خودت رو انتخاب کن</FaHint>
                </div>
                <p className="text-xs text-muted-foreground">
                  Wir suchen automatisch einen passenden Sitz für dich.
                </p>
              </div>
              <div className="glass inline-flex rounded-full p-1 text-xs font-semibold">
                {(["B1-B2", "C1-C2", "Alle"] as const).map((b) => (
                  <button
                    key={b}
                    onClick={() => setLevelFilter(b)}
                    className={`rounded-full px-3 py-1.5 transition ${
                      levelFilter === b
                        ? "bg-foreground text-background"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 grid gap-5 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
              {visibleGroups.map((g) => {
                const isMine = myReg?.groupId === g.id;
                const taken = g.reservations.length;
                return (
                  <div
                    key={g.id}
                    className={`rounded-2xl border p-4 transition ${
                      isMine
                        ? "border-transparent shadow-[0_16px_40px_-16px_rgba(139,92,246,.45)]"
                        : "border-border bg-secondary/40 hover:bg-secondary/60"
                    }`}
                    style={
                      isMine
                        ? { background: "color-mix(in oklab, #8B5CF6 8%, var(--card))" }
                        : undefined
                    }
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-bold">{g.name}</div>
                        <div className="text-[11px] text-muted-foreground">{g.level}</div>
                      </div>
                      {isMine && (
                        <span className="rounded-full bg-foreground px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-background">
                          Dein Platz
                        </span>
                      )}
                    </div>
                    <div className="mt-3 grid place-items-center">
                      <TableDiagram
                        group={g}
                        mySeat={isMine ? myReg?.seat : undefined}
                        size={200}
                      />
                    </div>
                    <div className="mt-3 space-y-1 text-[11px] text-muted-foreground">
                      <div className="flex items-center gap-1.5">
                        <Users className="h-3.5 w-3.5 shrink-0" aria-hidden />
                        <span className="tabular-nums">
                          {taken} / {g.seats}
                        </span>
                        <span className="opacity-60">Plätze</span>
                      </div>
                      <div className="truncate">
                        {g.leader.role}:{" "}
                        <span className="font-medium text-foreground/80">
                          {g.leader.name.split(" ")[0]}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <Legend />
          </motion.section>

          {/* Weekly topics */}
          <motion.section
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="neu-card p-5 md:p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <div>
                  <h2 className="text-lg font-bold">Themen dieser Woche</h2>
                  <FaHint size="sm">موضوع‌های این هفته</FaHint>
                </div>
                <p className="text-xs text-muted-foreground">
                  {event.weekly?.weekLabel ?? "Wöchentliche Konversationsthemen"} · von{" "}
                  {event.organizer.name}
                </p>
              </div>
              <span className="glass rounded-full px-3 py-1 text-[11px] font-semibold">
                Jede Woche neu
              </span>
            </div>

            <div className="mt-4 grid gap-4 md:grid-cols-2">
              {event.weekly &&
                (Object.entries(event.weekly.topics) as [LevelBand, string[]][]).map(
                  ([band, topics]) => (
                    <div
                      key={band}
                      className="rounded-2xl border border-border/60 p-4"
                      style={{
                        background: `linear-gradient(135deg, ${band === "B1-B2" ? "#8B5CF6" : "#22C55E"}12, transparent 60%)`,
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className="rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wider"
                          style={{
                            background: band === "B1-B2" ? "#8B5CF622" : "#22C55E22",
                            color: band === "B1-B2" ? "#8B5CF6" : "#22C55E",
                          }}
                        >
                          {band}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {topics.length} Themen
                        </span>
                      </div>
                      <ul className="mt-3 space-y-2">
                        {topics.map((t) => (
                          <li key={t} className="flex items-center gap-2 text-sm font-medium">
                            <span
                              className="h-1.5 w-1.5 rounded-full"
                              style={{ background: band === "B1-B2" ? "#8B5CF6" : "#22C55E" }}
                            />
                            {t}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ),
                )}
            </div>
          </motion.section>

          {/* Registration + Café Order */}
          <motion.section
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="grid gap-4 md:grid-cols-3"
          >
            {/* Your seat */}
            <div className="neu-card p-5">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Dein Platz
              </div>
              {myReg && myGroup ? (
                <div className="mt-3 flex items-center gap-3">
                  <div
                    className="grid h-14 w-14 place-items-center rounded-2xl text-lg font-bold text-white"
                    style={{ background: myGroup.level === "B1-B2" ? "#8B5CF6" : "#22C55E" }}
                  >
                    {myGroup.id}
                    {myReg.seat}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-bold">
                      {myGroup.name} · Tisch {myReg.tableNumber}
                    </div>
                    <div className="text-xs text-muted-foreground">Niveau: {myReg.level}</div>
                    <div className="mt-1 text-xs">
                      {myGroup.leader.role}:{" "}
                      <span className="font-semibold">{myGroup.leader.name}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="mt-3 text-sm text-muted-foreground">
                  Noch nicht angemeldet. Klicke auf „Jetzt anmelden“, wir weisen dir automatisch
                  einen Platz zu.
                </p>
              )}
            </div>

            {/* Café order */}
            <div className="neu-card p-5">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Deine Bestellung im Café
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Jeder Teilnehmer muss mindestens eine Bestellung aufgeben.
              </p>
              <div className="glass mt-3 flex items-center gap-2 rounded-full px-4 py-2">
                <span aria-hidden>☕</span>
                <input
                  disabled={!myReg}
                  value={orderDraft}
                  onChange={(e) => setOrderDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && orderDraft.trim()) {
                      state.submitOrder(orderDraft);
                      setOrderDraft("");
                    }
                  }}
                  placeholder={
                    myReg ? "Cappuccino, Latte, Käsekuchen…" : "Erst anmelden, um zu bestellen"
                  }
                  className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                />
                <button
                  disabled={!myReg || !orderDraft.trim()}
                  onClick={() => {
                    state.submitOrder(orderDraft);
                    setOrderDraft("");
                  }}
                  className="rounded-full bg-foreground px-3 py-1 text-[11px] font-bold text-background disabled:opacity-40"
                >
                  Senden
                </button>
              </div>
              {myOrder && (
                <div className="mt-3 text-xs text-muted-foreground">
                  Aktuell bestellt: <span className="font-semibold text-foreground">{myOrder}</span>
                </div>
              )}
              <p className="mt-3 text-[11px] text-muted-foreground">
                Du kannst deine Bestellung bis 30 Minuten vor Beginn ändern.
              </p>
            </div>

            {/* Notes */}
            <div className="neu-card p-5">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Event Hinweise
              </div>
              <ul className="mt-3 space-y-2 text-sm">
                {event.notes.map((n: string, i: number) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="mt-0.5">✓</span>
                    <span>{n}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.section>

          {/* Booking summary + CTA */}
          <motion.section
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="neu-card p-5 md:p-6"
          >
            <div className="flex flex-wrap items-center gap-4">
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Zusammenfassung deiner Buchung
                </div>
                <div className="mt-3 grid gap-3 md:grid-cols-4">
                  <Summary
                    icon="🎓"
                    label={event.title}
                    value={event.organizer.name.toUpperCase()}
                  />
                  <Summary icon="📅" label={event.dateShort} value={`${event.time} Uhr`} />
                  <Summary icon="📍" label={event.locationName} value={event.locationAddress} />
                  <Summary
                    icon="🪑"
                    label={myReg ? `${myGroup?.name}` : "Gruppe wird zugewiesen"}
                    value={
                      myReg ? `Tisch ${myReg.tableNumber}, Platz ${myReg.seat}` : "automatisch"
                    }
                  />
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                {myReg ? (
                  <>
                    <div className="glass rounded-full px-4 py-2 text-xs font-semibold text-foreground">
                      ✓ Angemeldet als {myGroup?.id}
                      {myReg.seat}
                    </div>
                    <button
                      onClick={state.cancelRegistration}
                      className="text-[11px] font-semibold text-muted-foreground underline"
                    >
                      Anmeldung stornieren
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => {
                      const reg = state.register(attendeeName);
                      if (reg) {
                        setJustRegistered(true);
                        setTimeout(() => setJustRegistered(false), 4000);
                      }
                    }}
                    className="rounded-full px-6 py-3 text-sm font-bold text-white shadow-lg transition hover:brightness-110"
                    style={{ background: "linear-gradient(135deg,#8B5CF6,#6D28D9)" }}
                  >
                    Jetzt anmelden
                  </button>
                )}
                {state.error && (
                  <div
                    role="alert"
                    className="rounded-full bg-red-500/10 px-4 py-2 text-[11px] font-semibold text-red-600 dark:text-red-400"
                  >
                    {state.error}
                  </div>
                )}
                <div className="text-[11px] text-muted-foreground">
                  Kostenlos · Nur Café-Bestellung vor Ort bezahlen
                </div>
              </div>
            </div>

            <AnimatePresence>
              {justRegistered && myReg && (
                <motion.div
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="mt-4 rounded-2xl border p-4 text-sm"
                  style={{
                    background: "color-mix(in oklab, #22C55E 10%, var(--card))",
                    borderColor: "color-mix(in oklab, #22C55E 30%, var(--border))",
                  }}
                >
                  🎉 <strong>Herzlichen Glückwunsch!</strong> Dir wurde automatisch{" "}
                  <strong>
                    {myGroup?.name} · Tisch {myReg.tableNumber} · Sitz {myGroup?.id}
                    {myReg.seat}
                  </strong>{" "}
                  zugewiesen. Vergiss nicht, deine Café-Bestellung aufzugeben!
                </motion.div>
              )}
            </AnimatePresence>
          </motion.section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          {/* Organizer */}
          <div className="neu-card p-5">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Veranstalter
            </div>
            <div className="mt-3 flex items-center gap-3">
              <div
                className="grid h-12 w-12 place-items-center rounded-2xl text-lg font-bold text-white"
                style={{ background: "linear-gradient(135deg,#1a1a1a,#DD2222)" }}
              >
                {event.organizer.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1 text-sm font-bold">
                  {event.organizer.name}
                  {event.organizer.verified && <span className="text-blue-500">✓</span>}
                </div>
                <div className="text-[11px] text-muted-foreground line-clamp-2">
                  {event.organizer.tagline}
                </div>
                <div className="mt-1 text-[11px] font-semibold">
                  ★ {event.organizer.rating}{" "}
                  <span className="font-normal text-muted-foreground">
                    ({event.organizer.reviews} Bewertungen)
                  </span>
                </div>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <MiniStat value={String(event.organizer.events)} label="Events" />
              <MiniStat value={event.organizer.participants} label="Teilnehmer" />
              <MiniStat value={event.organizer.satisfaction} label="Zufriedenheit" />
            </div>
          </div>

          {/* Orders per table */}
          <div className="neu-card p-5">
            <div className="flex items-center justify-between">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Bestellungen an deinem Tisch
              </div>
              {myGroup && (
                <span
                  className="rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider"
                  style={{
                    background: myGroup.level === "B1-B2" ? "#8B5CF622" : "#22C55E22",
                    color: myGroup.level === "B1-B2" ? "#8B5CF6" : "#22C55E",
                  }}
                >
                  {myGroup.name} · Tisch {myGroup.tableNumber}
                </span>
              )}
            </div>

            <div className="mt-3 max-h-[520px] space-y-2 overflow-y-auto pr-1">
              {(myGroup ?? state.groups[1]).reservations
                .slice()
                .sort((a, b) => a.seat - b.seat)
                .map((r) => (
                  <div
                    key={r.seat}
                    className="flex items-center gap-3 rounded-xl bg-secondary/50 p-2.5"
                  >
                    <div className="grid h-8 w-8 place-items-center rounded-lg bg-card text-[11px] font-bold">
                      {String(r.seat).padStart(2, "0")}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-xs font-semibold">{r.participantName}</div>
                      <div className="truncate text-[11px] text-muted-foreground">
                        {r.order ?? "Noch keine Bestellung"}
                      </div>
                    </div>
                    <span
                      className={`text-[11px] font-semibold ${
                        r.order ? "text-emerald-500" : "text-muted-foreground"
                      }`}
                    >
                      {r.order ? "✓ Bestellt" : "Ausstehend"}
                    </span>
                  </div>
                ))}
              {(myGroup ?? state.groups[1]).reservations.length === 0 && (
                <div className="rounded-xl bg-secondary/50 p-4 text-center text-xs text-muted-foreground">
                  Noch keine Bestellungen an diesem Tisch.
                </div>
              )}
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500" /> Bestellt
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-orange-400" /> Ausstehend
              </span>
            </div>
          </div>

          {/* Live stats */}
          <div className="neu-card p-5">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Live Statistik
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <MiniStat value={String(stats.participants)} label="Teilnehmer" />
              <MiniStat value={String(stats.groups)} label="Gruppen" />
              <MiniStat value={String(stats.remaining)} label="Freie Sitze" />
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ------------ tiny helpers ------------ */

function MetaTile({
  icon,
  label,
  value,
  small,
}: {
  icon: string;
  label: string;
  value: string;
  small?: boolean;
}) {
  return (
    <div className="rounded-2xl bg-secondary/60 p-3">
      <div className="flex items-center gap-2 text-[11px] font-semibold text-foreground">
        <span aria-hidden>{icon}</span>
        <span className="truncate">{label}</span>
      </div>
      <div className={`mt-1 truncate text-muted-foreground ${small ? "text-[11px]" : "text-xs"}`}>
        {value}
      </div>
    </div>
  );
}

function MiniStat({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-xl bg-secondary/60 p-2">
      <div className="text-sm font-bold">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}

function Summary({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3 rounded-2xl bg-secondary/50 p-3">
      <span className="text-lg">{icon}</span>
      <div className="min-w-0">
        <div className="truncate text-sm font-bold">{label}</div>
        <div className="truncate text-[11px] text-muted-foreground">{value}</div>
      </div>
    </div>
  );
}

function Legend() {
  const items = [
    { color: "#8B5CF6", label: "Dein Platz", filled: true },
    { color: "var(--border)", label: "Verfügbar" },
    { color: "#8B5CF6", label: "Reserviert", soft: true },
    { color: "var(--muted-foreground)", label: "Voll" },
  ];
  return (
    <div className="mt-6 flex flex-wrap items-center justify-center gap-4 rounded-full bg-secondary/50 py-3 text-xs">
      {items.map((it) => (
        <div key={it.label} className="inline-flex items-center gap-2">
          <span
            className="h-3 w-3 rounded-full"
            style={{
              background: it.filled ? it.color : it.soft ? `${it.color}22` : "transparent",
              border: `1.5px solid ${it.color}`,
            }}
          />
          <span className="font-medium">{it.label}</span>
        </div>
      ))}
    </div>
  );
}
