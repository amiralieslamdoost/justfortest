/**
 * motion-lite — a tiny, dependency-free stand-in for the subset of
 * `framer-motion` that DEUSI's app pages use (fade/slide-in on mount,
 * simple presence toggles, tap/hover feedback).
 *
 * Why: on mid-range phones the JS animation loop of a full animation
 * library is one of the biggest sources of jank. Every app screen here only
 * needs "appear softly" — which CSS does for free on the compositor.
 *
 * Motion props are accepted and dropped; a light CSS entrance animation is
 * applied instead. Pages that genuinely need physics (drag, scroll-linked
 * parallax on the landing page) keep importing `framer-motion` directly.
 */
import type * as React from "react";
import {
  createElement,
  forwardRef,
  type ComponentPropsWithoutRef,
  type ElementType,
  type ReactNode,
} from "react";

const MOTION_PROPS = new Set([
  "initial",
  "animate",
  "exit",
  "transition",
  "variants",
  "whileHover",
  "whileTap",
  "whileFocus",
  "whileDrag",
  "whileInView",
  "viewport",
  "custom",
  "layout",
  "layoutId",
  "layoutScroll",
  "layoutDependency",
  "drag",
  "dragConstraints",
  "dragElastic",
  "dragMomentum",
  "dragSnapToOrigin",
  "dragTransition",
  "onDrag",
  "onDragStart",
  "onDragEnd",
  "onAnimationStart",
  "onAnimationComplete",
  "onUpdate",
  "onHoverStart",
  "onHoverEnd",
  "onTapStart",
  "onTapCancel",
  "transformTemplate",
  "style_motion",
]);

type AnyProps = Record<string, unknown>;

function clean(props: AnyProps) {
  const out: AnyProps = {};
  for (const key in props) {
    if (MOTION_PROPS.has(key)) continue;
    out[key] = props[key];
  }
  return out;
}

/** Elements that should get the soft entrance animation. */
function entranceClass(props: AnyProps) {
  const hasEntrance = "initial" in props || "animate" in props || "whileInView" in props;
  if (!hasEntrance) return "";
  return "m-in";
}

function createMotionComponent(tag: string) {
  const Component = forwardRef<unknown, AnyProps>(function MotionLite(props, ref) {
    const rest = clean(props);
    const extra = entranceClass(props);
    if (extra) {
      rest["className"] = [rest["className"], extra].filter(Boolean).join(" ");
    }
    return createElement(tag, { ...rest, ref });
  });
  Component.displayName = `motion.${tag}`;
  return Component;
}

const cache = new Map<string, ElementType>();

/** Motion-ish props accepted (and ignored) on every element. */
type LiteMotionProps = {
  initial?: unknown;
  animate?: unknown;
  exit?: unknown;
  transition?: unknown;
  variants?: unknown;
  whileHover?: unknown;
  whileTap?: unknown;
  whileFocus?: unknown;
  whileInView?: unknown;
  viewport?: unknown;
  custom?: unknown;
  layout?: unknown;
  layoutId?: string;
  onAnimationComplete?: () => void;
};

type MotionComponents = {
  [K in keyof React.JSX.IntrinsicElements]: (
    props: React.JSX.IntrinsicElements[K] & LiteMotionProps,
  ) => ReactNode;
};

export const motion = new Proxy({} as MotionComponents, {
  get(_target, tag: string) {
    let comp = cache.get(tag);
    if (!comp) {
      comp = createMotionComponent(tag) as ElementType;
      cache.set(tag, comp);
    }
    return comp;
  },
});

/** Presence without exit animations: children simply mount/unmount. */
export function AnimatePresence({ children }: { children?: ReactNode; [key: string]: unknown }) {
  return <>{children}</>;
}

export type MotionProps = ComponentPropsWithoutRef<"div">;
