/* Design: Quiet Leitner Studio — preserve the semantic colour halo while making the card itself a warm, focused bilingual study page. */
import type { Word, VerbWord, NounWord, AdjectiveWord, PrepositionWord } from "@/lib/deusi/types";
import { studyEnrichmentFor } from "@/lib/deusi/seed";
import {
  POS_DE,
  accentColor,
  primaryOf,
  articleColor,
  discClass,
  prepPattern,
  speak,
  CaseShape,
  SpeakerIcon,
} from "@/components/deusi/learn/learnHelpers";

interface CenterStageProps {
  word: Word;
  revealed: boolean;
  onFlip: () => void;
  onOpenDetails: () => void;
}

export function CenterStage({ word, revealed, onFlip, onOpenDetails }: CenterStageProps) {
  const article = word.pos === "noun" ? word.article : undefined;
  const accent = accentColor(word);
  const enrichment = studyEnrichmentFor(word.id);
  const englishMeaning = word.englishTranslation ?? enrichment.englishTranslation ?? "—";
  const exampleTranslation =
    word.exampleTranslation ?? enrichment.exampleTranslation ?? "ترجمهٔ جمله در دسترس نیست.";

  const grammarLine = () => {
    if (word.pos === "noun") return `Plural · die ${(word as NounWord).plural}`;
    if (word.pos === "verb") return `${(word as VerbWord).praeteritum} · ${(word as VerbWord).perfekt}`;
    if (word.pos === "adjective") {
      return `${(word as AdjectiveWord).comparative} · ${(word as AdjectiveWord).superlative}`;
    }
    return `Kasus · ${(word as PrepositionWord).cases.join(" / ")}`;
  };

  const grammarRows = () => {
    if (word.pos === "noun") return [{ label: "Plural", value: `die ${(word as NounWord).plural}` }];
    if (word.pos === "verb") {
      const verb = word as VerbWord;
      return [
        { label: "Präteritum", value: verb.praeteritum },
        { label: "Perfekt", value: verb.perfekt },
        ...(verb.governedPreposition
          ? [{ label: "Präposition", value: `+ ${verb.governedPreposition.text} · ${verb.governedPreposition.case}` }]
          : []),
      ];
    }
    if (word.pos === "adjective") {
      const adjective = word as AdjectiveWord;
      return [
        { label: "Komparativ", value: adjective.comparative },
        { label: "Superlativ", value: adjective.superlative },
        { label: "Gegenteil", value: `${adjective.antonym} · ${adjective.antonymTranslation}` },
      ];
    }
    return [{ label: "Kasus", value: (word as PrepositionWord).cases.join(" / ") }];
  };

  return (
    <div className="leitner-card-shell relative isolate mx-auto w-full max-w-[390px] sm:max-w-[500px]">
      <div aria-hidden className="leitner-card-halo">
        <div className="relative h-full w-full">
          <div className={`pos-disc ${discClass(word)}`} />
          <div className={`pos-disc b2 ${discClass(word)}`} />
        </div>
      </div>
      <div className="flip-scene relative z-10">
        <div
          className={`flip-card ${revealed ? "is-flipped" : ""}`}
          onClick={onFlip}
          role="button"
          tabIndex={0}
          aria-label="Karte umdrehen"
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onFlip();
            }
          }}
        >
          {/* FRONT */}
          <div
            className="flip-face front leitner-card-face leitner-card-face-front min-h-[clamp(20.5rem,calc(100dvh-16rem),27rem)] w-full sm:min-h-[29rem] lg:min-h-[27rem]"
            style={{ "--leitner-accent": accent } as React.CSSProperties}
          >
            <div className="leitner-card-content text-center">
              <div className="flex flex-wrap items-center justify-between gap-2 text-left">
                <div className="flex items-center gap-2">
                  {article && (
                    <span className="leitner-article-chip" style={{ color: articleColor(article) }}>
                      {article}
                    </span>
                  )}
                  <span className="leitner-pos-chip">{POS_DE[word.pos]}</span>
                </div>
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    onOpenDetails();
                  }}
                  className="leitner-detail-icon"
                  aria-label="Alle Wortdetails anzeigen"
                  title="Alle Wortdetails"
                >
                  <DetailsIcon />
                </button>
              </div>

              <div className="my-auto flex flex-col items-center py-5 sm:py-10">
                <h2 className="leitner-card-word" lang="de">{primaryOf(word)}</h2>
                <div className="mt-4 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.15em] text-muted-foreground sm:text-xs">
                  <span className="h-px w-7 bg-border" />
                  <span>{word.pos === "noun" ? `Plural · die ${(word as NounWord).plural}` : grammarLine()}</span>
                  <span className="h-px w-7 bg-border" />
                </div>
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    speak(primaryOf(word));
                  }}
                  className="leitner-speech-button"
                  aria-label="Aussprache"
                >
                  <SpeakerIcon />
                </button>
              </div>

              <div className="flex items-center justify-between border-t border-black/6 pt-4 text-xs text-muted-foreground dark:border-white/10">
                <span className="inline-flex items-center gap-2 font-semibold">
                  <span className="leitner-flip-symbol" aria-hidden="true">↻</span> Karte umdrehen
                </span>
                <span className="leitner-key-cap">Leertaste</span>
              </div>
            </div>
          </div>

          {/* BACK */}
          <div
            className="flip-face back leitner-card-face leitner-card-face-back min-h-[clamp(20.5rem,calc(100dvh-16rem),27rem)] w-full sm:min-h-[29rem] lg:min-h-[27rem]"
            style={{ "--leitner-accent": accent } as React.CSSProperties}
          >
            <div className="leitner-card-content">
              <div className="leitner-sample-topline" style={{ background: accent }} />
              <div className="mt-4 flex items-center justify-between gap-3">
                <div className="leitner-back-kicker">{POS_DE[word.pos]}</div>
                <div className="flex items-center gap-2">
                  {article && <span className="leitner-article-chip" style={{ color: articleColor(article) }}>{article}</span>}
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      onOpenDetails();
                    }}
                    className="leitner-detail-icon"
                    aria-label="Alle Wortdetails anzeigen"
                    title="Alle Wortdetails"
                  >
                    <DetailsIcon />
                  </button>
                </div>
              </div>

              <div className="mt-1 border-b border-black/8 pb-4 text-center dark:border-white/10">
                <h2 className="leitner-back-word" lang="de">{primaryOf(word)}</h2>
              </div>

              <div className="leitner-sample-meaning fa" dir="rtl" lang="fa">
                <strong>{word.translation}</strong>
                <span lang="en" dir="ltr">{englishMeaning}</span>
              </div>

              <dl className="leitner-grammar-rows">
                {grammarRows().map((row) => (
                  <div key={row.label}>
                    <dt>{row.label}</dt>
                    <dd>{row.value}</dd>
                  </div>
                ))}
              </dl>

              {word.pos === "preposition" && (() => {
                const pattern = prepPattern(word as PrepositionWord);
                return <div className="leitner-prep-note" style={{ color: pattern.color }}><CaseShape shape={pattern.shape} color={pattern.color} tint={pattern.tint} size={22} />{pattern.label}</div>;
              })()}

              {word.example && (
                <div className="leitner-sample-example mt-4" lang="de">
                  <p>„{word.example}“</p>
                </div>
              )}
              {word.example && (
                <div className="leitner-sample-example leitner-sample-example-fa fa mt-1.5" dir="rtl" lang="fa">
                  <p>{exampleTranslation}</p>
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DetailsIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 10.5v5" strokeLinecap="round" />
      <path d="M12 7.4h.01" strokeLinecap="round" strokeWidth="3" />
    </svg>
  );
}
