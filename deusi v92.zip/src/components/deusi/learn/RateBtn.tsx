import type { Rating } from "@/lib/deusi/fsrs";

interface RateBtnProps {
  kind: Rating;
  title: string;
  onClick: () => void;
  onHover?: (r: Rating | null) => void;
  compact?: boolean;
}

export function RateBtn({ kind, title, onClick, onHover, compact = false }: RateBtnProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      onPointerEnter={(event) => event.pointerType === "mouse" && onHover?.(kind)}
      onPointerLeave={(event) => event.pointerType === "mouse" && onHover?.(null)}
      onFocus={() => onHover?.(kind)}
      onBlur={() => onHover?.(null)}
      className={`rate-pill rate-pill--${kind}${compact ? " rate-pill--compact" : ""}`}
      aria-label={title}
    >
      <span className="rate-pill__dot" aria-hidden />
      <span>{title}</span>
    </button>
  );
}
