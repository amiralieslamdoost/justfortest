/* Design: Quiet Leitner Studio — reuse the dictionary’s full word-detail panel inside the focused review flow. */
import { createPortal } from "react-dom";
import { useEffect, useMemo, useState } from "react";
import { motion } from "@/lib/motion-lite";
import { WordDetailPanel } from "@/components/deusi/dictionary/WordDetailPanel";
import { ALL_WORDS } from "@/lib/deusi/dictionary/mockWords";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import type { NounWord, PrepositionWord, VerbWord, Word } from "@/lib/deusi/types";
import { primaryOf } from "@/components/deusi/learn/learnHelpers";

const EMPTY_FAMILY = {
  synonyms: [],
  antonyms: [],
  similar: [],
  compounds: [],
  relatedVerbs: [],
  relatedNouns: [],
  relatedAdjectives: [],
};

const FAVORITES_KEY = "deusi.leitner.word-favorites";
const BOOKMARKS_KEY = "deusi.leitner.word-bookmarks";

function loadIds(key: string) {
  if (typeof window === "undefined") return new Set<string>();
  try {
    const raw = localStorage.getItem(key);
    return new Set<string>(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set<string>();
  }
}

function makeDictionaryFallback(word: Word): DictWord {
  const headword = primaryOf(word);
  const base: DictWord = {
    id: `leitner-${word.id}`,
    headword,
    lemma: headword.toLocaleLowerCase("de-DE"),
    pos: word.pos,
    cefr: "A2",
    category: "lernen",
    frequency: 50,
    ipa: "—",
    shortMeaning: word.translation,
    meanings: [{ de: headword, en: word.englishTranslation, fa: word.translation }],
    difficulty: 2,
    examples: word.example
      ? [{ id: `${word.id}-example`, de: word.example, en: word.exampleTranslation ?? "", fa: word.exampleTranslation }]
      : [],
    family: EMPTY_FAMILY,
  };

  if (word.pos === "noun") {
    const noun = word as NounWord;
    return {
      ...base,
      nounGrammar: {
        article: noun.article,
        gender: noun.article === "der" ? "m" : noun.article === "die" ? "f" : "n",
        plural: noun.plural,
        genitive: `${noun.article} ${noun.singular}`,
        declension: "regulär",
      },
    };
  }
  if (word.pos === "verb") {
    const verb = word as VerbWord;
    return {
      ...base,
      verbGrammar: {
        separable: false,
        regular: true,
        aux: verb.aux,
        praeteritum: verb.praeteritum,
        perfekt: verb.perfekt,
        partizipII: verb.perfekt.split(" ").at(-1) ?? verb.perfekt,
        praesens: verb.praesens,
        praeteritumConj: verb.praeteritumConj,
        perfektConj: verb.perfektConj,
        governedPreposition: verb.governedPreposition,
      },
    };
  }
  if (word.pos === "adjective") {
    return {
      ...base,
      adjectiveGrammar: {
        comparative: word.comparative,
        superlative: word.superlative,
        attributive: { nom: "—", akk: "—", dat: "—", gen: "—" },
        collocations: [],
      },
    };
  }
  const preposition = word as PrepositionWord;
  return {
    ...base,
    prepositionGrammar: { cases: preposition.cases, examples: word.example ? [word.example] : [] },
  };
}

function resolveDictionaryWord(word: Word) {
  const target = primaryOf(word).toLocaleLowerCase("de-DE");
  return (
    ALL_WORDS.find(
      (candidate) =>
        candidate.headword.toLocaleLowerCase("de-DE") === target ||
        candidate.lemma.toLocaleLowerCase("de-DE") === target,
    ) ?? makeDictionaryFallback(word)
  );
}

export function LeitnerWordDetails({ word, onClose }: { word: Word; onClose: () => void }) {
  const fallback = useMemo(() => resolveDictionaryWord(word), [word]);
  const [activeWord, setActiveWord] = useState<DictWord>(fallback);
  const [favorites, setFavorites] = useState<Set<string>>(() => loadIds(FAVORITES_KEY));
  const [bookmarks, setBookmarks] = useState<Set<string>>(() => loadIds(BOOKMARKS_KEY));

  useEffect(() => setActiveWord(fallback), [fallback]);
  useEffect(() => localStorage.setItem(FAVORITES_KEY, JSON.stringify([...favorites])), [favorites]);
  useEffect(() => localStorage.setItem(BOOKMARKS_KEY, JSON.stringify([...bookmarks])), [bookmarks]);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  if (typeof document === "undefined") return null;

  return createPortal(
    <>
      <motion.div
        className="fixed inset-0 z-40 bg-black/45 backdrop-blur-[2px]"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.18, ease: "easeOut" }}
        onClick={onClose}
      />
      <motion.div
        role="dialog"
        aria-modal="true"
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", stiffness: 460, damping: 42, mass: 0.7 }}
        className="fixed inset-y-0 right-0 z-50 flex w-full max-w-[520px] flex-col overflow-hidden bg-card shadow-2xl ring-1 ring-border/70 [&>aside]:!rounded-none [&>aside]:!bg-card [&>aside]:!backdrop-blur-none [&>aside]:!border-border [&>aside]:!shadow-none"
        style={{ touchAction: "pan-y" }}
      >
        <div aria-hidden className="pointer-events-none absolute left-1.5 top-1/2 z-20 h-14 w-1 -translate-y-1/2 rounded-full bg-foreground/15" />
        <WordDetailPanel
          word={activeWord}
          favorite={favorites.has(activeWord.id)}
          bookmarked={bookmarks.has(activeWord.id)}
          onClose={onClose}
          onToggleFavorite={() => setFavorites((previous) => {
            const next = new Set(previous);
            next.has(activeWord.id) ? next.delete(activeWord.id) : next.add(activeWord.id);
            return next;
          })}
          onToggleBookmark={() => setBookmarks((previous) => {
            const next = new Set(previous);
            next.has(activeWord.id) ? next.delete(activeWord.id) : next.add(activeWord.id);
            return next;
          })}
          onOpenWord={(id) => {
            const next = ALL_WORDS.find((candidate) => candidate.id === id);
            if (next) setActiveWord(next);
          }}
        />
      </motion.div>
    </>,
    document.body,
  );
}
