import type { VerbWord } from "@/lib/deusi/types";

interface ConjTableProps {
  v: VerbWord;
}

export function ConjTable({ v }: ConjTableProps) {
  const pronouns: Array<keyof VerbWord["praesens"]> = ["ich", "du", "er", "wir", "ihr", "sie"];
  const label: Record<string, string> = {
    ich: "ich",
    du: "du",
    er: "er / sie / es",
    wir: "wir",
    ihr: "ihr",
    sie: "sie / Sie",
  };
  const auxCls = v.aux === "sein" ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-700";
  return (
    <div>
      <div className="mb-3 text-center">
        <div className="text-4xl font-bold">{v.infinitive}</div>
        <div className="mt-1 text-sm text-muted-foreground">
          Hilfsverb:{" "}
          <span className={`inline-block rounded-md px-1.5 py-0.5 font-semibold ${auxCls}`}>
            {v.aux}
          </span>
        </div>
      </div>
      <div className="grid gap-2 sm:hidden">
        {pronouns.map((p) => {
          const [auxW, ...rest] = String(v.perfektConj[p]).split(" ");
          return (
            <article key={p} className="rounded-xl border border-border bg-card p-3">
              <div className="mb-2 text-xs font-black text-muted-foreground">{label[p]}</div>
              <dl className="grid grid-cols-3 gap-2 text-xs">
                <div><dt className="text-[10px] text-muted-foreground">Präsens</dt><dd className="mt-0.5 font-semibold">{v.praesens[p]}</dd></div>
                <div><dt className="text-[10px] text-muted-foreground">Prät.</dt><dd className="mt-0.5 font-semibold">{v.praeteritumConj[p]}</dd></div>
                <div><dt className="text-[10px] text-muted-foreground">Perfekt</dt><dd className="mt-0.5 font-semibold"><span className={`inline-block rounded px-1 py-0.5 ${auxCls}`}>{auxW}</span> {rest.join(" ")}</dd></div>
              </dl>
            </article>
          );
        })}
      </div>
      <div className="hidden overflow-hidden rounded-2xl border border-border bg-card sm:block">
        <table className="w-full text-start text-sm">
          <thead className="text-xs text-muted-foreground">
            <tr>
              <th className="p-3 text-start font-medium">Person</th>
              <th className="p-3 text-start font-medium">Präsens</th>
              <th className="p-3 text-start font-medium">Präteritum</th>
              <th className="p-3 text-start font-medium">Perfekt</th>
            </tr>
          </thead>
          <tbody>
            {pronouns.map((p) => {
              const [auxW, ...rest] = String(v.perfektConj[p]).split(" ");
              return (
                <tr key={p} className="border-t border-border">
                  <td className="p-3 text-muted-foreground">{label[p]}</td>
                  <td className="p-3 font-semibold">{v.praesens[p]}</td>
                  <td className="p-3 font-semibold">{v.praeteritumConj[p]}</td>
                  <td className="p-3 font-semibold">
                    <span className={`inline-block rounded-md px-1.5 py-0.5 ${auxCls}`}>
                      {auxW}
                    </span>{" "}
                    {rest.join(" ")}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
