import { AnimatePresence, motion } from "@/lib/motion-lite";
import { useEffect, useState } from "react";
import { WifiOff, Wifi } from "lucide-react";
import { toast } from "sonner";

/**
 * Non-intrusive offline indicator. Displays a glass banner while the browser
 * reports offline and shows a success toast when the connection returns.
 */
export function OfflineBanner() {
  const [online, setOnline] = useState(true);
  const [justRecovered, setJustRecovered] = useState(false);

  useEffect(() => {
    if (typeof navigator === "undefined") return;
    setOnline(navigator.onLine);

    const goOffline = () => setOnline(false);
    const goOnline = () => {
      setOnline(true);
      setJustRecovered(true);
      toast.success("Wieder online", { description: "Verbindung wurde wiederhergestellt." });
      window.setTimeout(() => setJustRecovered(false), 2400);
    };
    window.addEventListener("offline", goOffline);
    window.addEventListener("online", goOnline);
    return () => {
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("online", goOnline);
    };
  }, []);

  return (
    <AnimatePresence>
      {(!online || justRecovered) && (
        <motion.div
          key={online ? "online" : "offline"}
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -40, opacity: 0 }}
          transition={{ type: "spring", stiffness: 380, damping: 30 }}
          role="status"
          aria-live="polite"
          className="fixed left-1/2 top-3 z-[60] -translate-x-1/2"
        >
          <div
            className={
              "flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-semibold shadow-[var(--elev-2)] backdrop-blur-xl " +
              (online
                ? "border-emerald-500/25 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                : "border-amber-500/25 bg-amber-500/15 text-amber-700 dark:text-amber-300")
            }
          >
            {online ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
            {online ? "Wieder online" : "Offline — einige Aktionen sind deaktiviert"}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
