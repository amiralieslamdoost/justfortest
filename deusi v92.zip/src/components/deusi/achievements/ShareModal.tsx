import { useState } from "react";
import { motion } from "@/lib/motion-lite";
import { Copy, Check, X, Share2 } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import type { Achievement } from "@/lib/deusi/achievements";

export interface ShareModalProps {
  target: Achievement | "all";
  onClose: () => void;
  unlockedCount: number;
  totalCount: number;
  progressPct: number;
}

export function ShareModal({
  target,
  onClose,
  unlockedCount,
  totalCount,
  progressPct,
}: ShareModalProps) {
  const [copied, setCopied] = useState(false);
  const url =
    typeof window !== "undefined" ? window.location.href : "https://deusi.app/achievements";

  const text =
    target === "all"
      ? `Ich habe ${unlockedCount} von ${totalCount} DEUSI-Abzeichen (${progressPct}%) freigeschaltet! 🎉 Lern mit mir Deutsch:`
      : `Neues Abzeichen freigeschaltet: ${target.emoji} ${target.labelDe} bei DEUSI! 🎉 Lern mit mir Deutsch:`;

  const encoded = encodeURIComponent(`${text} ${url}`);
  const links = [
    {
      name: "WhatsApp",
      color: "#25D366",
      href: `https://wa.me/?text=${encoded}`,
      emoji: "💬",
    },
    {
      name: "Telegram",
      color: "#0088CC",
      href: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`,
      emoji: "✈️",
    },
    {
      name: "X / Twitter",
      color: "#000000",
      href: `https://twitter.com/intent/tweet?text=${encoded}`,
      emoji: "𝕏",
    },
    {
      name: "Facebook",
      color: "#1877F2",
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
      emoji: "📘",
    },
  ];

  async function handleNative() {
    if (
      typeof navigator !== "undefined" &&
      (navigator as Navigator & { share?: (d: ShareData) => Promise<void> }).share
    ) {
      try {
        await (navigator as Navigator & { share: (d: ShareData) => Promise<void> }).share({
          title: "DEUSI",
          text,
          url,
        });
      } catch {
        /* user cancelled */
      }
    }
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(`${text} ${url}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* noop */
    }
  }

  const heroColor = target === "all" ? "#F97316" : target.color;
  const heroEmoji = target === "all" ? "🏆" : target.emoji;
  const heroTitle = target === "all" ? "Mein Fortschritt" : target.labelDe;
  const heroFa = target === "all" ? "پیشرفت من" : target.labelFa;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md overflow-hidden rounded-3xl bg-card shadow-2xl ring-1 ring-border"
      >
        {/* Header preview card */}
        <div
          className="relative overflow-hidden p-6 text-white"
          style={{
            backgroundImage: `linear-gradient(135deg, ${heroColor}, color-mix(in oklab, ${heroColor} 60%, #000))`,
          }}
        >
          <button
            onClick={onClose}
            aria-label="Schließen"
            className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-white/20 text-white backdrop-blur transition hover:bg-white/30"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
          <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
            <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/25 blur-3xl" />
            <div className="absolute -bottom-10 -left-8 h-32 w-32 rounded-full bg-white/10 blur-3xl" />
          </div>
          <div className="relative flex items-center gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-white/95 text-4xl shadow ring-1 ring-white/40">
              <span aria-hidden>{heroEmoji}</span>
            </div>
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-widest text-white/85">
                DEUSI · Erfolg
              </div>
              <div className="text-xl font-black leading-tight">{heroTitle}</div>
              <div className="text-xs text-white/85">{heroFa}</div>
              {target === "all" && (
                <div className="mt-1 text-[11px] font-black">
                  {unlockedCount} / {totalCount} · {progressPct}%
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-4 p-6">
          <div>
            <div className="text-sm font-black">Mit Freunden teilen</div>
            <Fa className="fa-hint-xs">با دوستان به اشتراک بگذار</Fa>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {links.map((l) => (
              <a
                key={l.name}
                href={l.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col items-center gap-1 rounded-2xl bg-secondary p-3 text-center transition hover:-translate-y-0.5 hover:shadow-md"
              >
                <div
                  className="grid h-10 w-10 place-items-center rounded-full text-lg text-white shadow"
                  style={{ backgroundColor: l.color }}
                >
                  <span aria-hidden>{l.emoji}</span>
                </div>
                <div className="text-[10px] font-bold">{l.name}</div>
              </a>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex flex-1 items-center justify-center gap-2 rounded-full bg-foreground px-4 py-2.5 text-sm font-black text-background transition hover:opacity-90"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4" aria-hidden /> Kopiert
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" aria-hidden /> Link kopieren
                </>
              )}
            </button>
            <button
              onClick={handleNative}
              className="grid h-11 w-11 place-items-center rounded-full bg-secondary text-foreground transition hover:bg-secondary/70"
              aria-label="Mit Gerät teilen"
              title="Mit Gerät teilen"
            >
              <Share2 className="h-4 w-4" aria-hidden />
            </button>
          </div>

          <p className="text-[11px] text-muted-foreground">
            Motiviere deine Freunde mit — gemeinsam macht Lernen mehr Spaß!{" "}
            <span aria-hidden>🎉</span>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
