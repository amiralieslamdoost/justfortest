import { motion } from "@/lib/motion-lite";
import { useMemo } from "react";

const COLORS = ["#F97316", "#F59E0B", "#22C55E", "#0EA5E9", "#8B5CF6", "#EC4899"];

/**
 * Lightweight confetti burst — decorative only.
 * Rendered on demand (mission complete, level ring click, share).
 */
export function Confetti({ pieces = 42 }: { pieces?: number }) {
  const bits = useMemo(
    () =>
      Array.from({ length: pieces }, (_, i) => ({
        id: i,
        x: (Math.random() - 0.5) * 520,
        y: 260 + Math.random() * 360,
        rotate: Math.random() * 720 - 360,
        delay: Math.random() * 0.25,
        duration: 1.5 + Math.random() * 1.1,
        color: COLORS[i % COLORS.length],
        size: 6 + Math.random() * 8,
        round: Math.random() > 0.6,
      })),
    [pieces],
  );

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[60] overflow-hidden">
      {bits.map((b) => (
        <motion.span
          key={b.id}
          initial={{ opacity: 1, x: 0, y: 0, rotate: 0 }}
          animate={{ opacity: [1, 1, 0], x: b.x, y: b.y, rotate: b.rotate }}
          transition={{ duration: b.duration, delay: b.delay, ease: "easeOut" }}
          style={{
            position: "absolute",
            left: "50%",
            top: "18%",
            width: b.size,
            height: b.size * (b.round ? 1 : 1.6),
            borderRadius: b.round ? 999 : 2,
            background: b.color,
          }}
        />
      ))}
    </div>
  );
}
