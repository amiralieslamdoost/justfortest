import { motion } from "@/lib/motion-lite";
import { Lock, Sparkles, Share2 } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import type { Achievement } from "@/lib/deusi/achievements";
import { RARITY_META, rarityOf, ownersPctOf } from "@/lib/deusi/gamification";
import { formatDate } from "@/components/deusi/achievements/formatDate";

export interface AchievementCardProps {
  achievement: Achievement;
  index: number;
  onShare: () => void;
}

export function AchievementCard({ achievement, index, onShare }: AchievementCardProps) {
  const a = achievement;
  const pct = a.progress
    ? Math.min(100, Math.round((a.progress.current / a.progress.target) * 100))
    : a.unlocked
      ? 100
      : 0;
  const remaining = a.progress ? Math.max(0, a.progress.target - a.progress.current) : 0;
  const rarity = RARITY_META[rarityOf(a.id)];

  // Medal ring geometry
  const R = 30;
  const C = 2 * Math.PI * R;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.035 * index, duration: 0.35 }}
      whileHover={{ y: -6 }}
      className="group relative flex flex-col items-center overflow-hidden rounded-[1.5rem] p-4 text-center ring-1 transition-shadow duration-300"
      style={{
        backgroundImage: a.unlocked
          ? `radial-gradient(120% 90% at 50% -10%, color-mix(in oklab, ${a.color} 55%, transparent) 0%, transparent 62%), linear-gradient(160deg, #12131A 0%, #1B1D28 60%, #0C0D12 100%)`
          : `radial-gradient(120% 90% at 50% -20%, color-mix(in oklab, ${rarity.color} 16%, transparent) 0%, transparent 60%), linear-gradient(160deg, color-mix(in oklab, var(--secondary) 92%, transparent), var(--secondary))`,
        boxShadow: a.unlocked
          ? `0 18px 40px -22px color-mix(in oklab, ${a.color} 85%, transparent), inset 0 1px 0 rgba(255,255,255,.14)`
          : "inset 0 1px 0 rgba(255,255,255,.05)",
        ...({
          "--tw-ring-color": a.unlocked
            ? `color-mix(in oklab, ${a.color} 45%, transparent)`
            : "color-mix(in oklab, var(--border) 90%, transparent)",
        } as React.CSSProperties),
      }}
    >
      {/* Sheen sweep on hover */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-1/2 top-0 h-full w-1/2 -skew-x-12 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 transition-all duration-700 group-hover:left-[130%] group-hover:opacity-100" />
      </div>

      {/* Rarity ribbon */}
      <span
        className="absolute left-3 top-3 rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.14em]"
        style={{
          background: a.unlocked
            ? "rgba(255,255,255,.16)"
            : `color-mix(in oklab, ${rarity.color} 18%, transparent)`,
          color: a.unlocked ? "#fff" : rarity.color,
        }}
      >
        {rarity.de}
      </span>
      <span
        className={`absolute right-3 top-3 inline-flex items-center gap-1 text-[9px] font-black tabular-nums ${
          a.unlocked ? "text-white/80" : "text-muted-foreground"
        }`}
      >
        {a.unlocked ? (
          <Sparkles className="h-3 w-3" aria-hidden />
        ) : (
          <Lock className="h-3 w-3" aria-hidden />
        )}
        +{rarity.xp} XP
      </span>

      {/* Medallion */}
      <div className="relative mt-7 grid h-[98px] w-[98px] place-items-center">
        <svg
          viewBox="-11 -11 98 98"
          className="absolute inset-0 h-full w-full -rotate-90 overflow-visible"
        >
          <circle
            cx="38"
            cy="38"
            r={R}
            fill="none"
            strokeWidth="5"
            stroke={
              a.unlocked
                ? "rgba(255,255,255,.14)"
                : "color-mix(in oklab, var(--border) 90%, transparent)"
            }
          />
          <motion.circle
            cx="38"
            cy="38"
            r={R}
            fill="none"
            strokeWidth="5"
            strokeLinecap="round"
            stroke={a.color}
            strokeDasharray={C}
            initial={{ strokeDashoffset: C }}
            animate={{ strokeDashoffset: C - (C * pct) / 100 }}
            transition={{ duration: 0.9, delay: 0.05 * index, ease: "easeOut" }}
            style={{
              filter: a.unlocked ? `drop-shadow(0 0 6px ${a.color})` : undefined,
            }}
          />
        </svg>
        <motion.div
          whileHover={{ rotate: [-8, 8, 0], scale: 1.06 }}
          transition={{ duration: 0.5 }}
          className="grid h-14 w-14 place-items-center rounded-full text-2xl ring-1"
          style={{
            background: a.unlocked
              ? `linear-gradient(150deg, color-mix(in oklab, ${a.color} 92%, #fff) 0%, color-mix(in oklab, ${a.color} 55%, #000) 100%)`
              : "color-mix(in oklab, var(--background) 88%, transparent)",
            boxShadow: a.unlocked
              ? `0 8px 22px -8px ${a.color}, inset 0 2px 6px rgba(255,255,255,.35)`
              : "inset 0 2px 6px rgba(0,0,0,.12)",
            ["--tw-ring-color" as never]: a.unlocked
              ? "rgba(255,255,255,.45)"
              : "color-mix(in oklab, var(--border) 90%, transparent)",
          }}
        >
          <span
            aria-hidden
            className={a.unlocked ? "" : "opacity-45 grayscale"}
            style={a.unlocked ? { filter: "drop-shadow(0 1px 2px rgba(0,0,0,.35))" } : undefined}
          >
            {a.emoji}
          </span>
        </motion.div>
        {!a.unlocked && (
          <span className="absolute -bottom-1 rounded-full bg-background px-1.5 py-0.5 text-[9px] font-black tabular-nums text-muted-foreground ring-1 ring-border">
            {pct}%
          </span>
        )}
      </div>

      {/* Text */}
      <div className="relative mt-3 w-full min-w-0 flex-1">
        <div
          className={`line-clamp-2 text-[13px] font-black leading-tight sm:text-sm ${
            a.unlocked ? "text-white" : "text-foreground"
          }`}
        >
          {a.labelDe}
        </div>
        <Fa className={`fa-hint-xs !text-[10px] ${a.unlocked ? "!text-white/75" : ""}`}>
          {a.labelFa}
        </Fa>

        {a.unlocked ? (
          <div className="mt-2 inline-flex max-w-full items-center gap-1 truncate rounded-full bg-white/12 px-2.5 py-1 text-[10px] font-bold text-white/85 ring-1 ring-white/15">
            ✓ {a.unlockedAt ? formatDate(a.unlockedAt) : "freigeschaltet"} · nur {ownersPctOf(a.id)}
            %
          </div>
        ) : a.progress ? (
          <div className="mt-2 rounded-xl bg-background/60 px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground ring-1 ring-border/60">
            noch{" "}
            <span className="tabular-nums" style={{ color: a.color }}>
              {remaining}
            </span>{" "}
            bis zum Abzeichen
          </div>
        ) : (
          <div className="mt-2 text-[10px] font-semibold text-muted-foreground">{a.sub}</div>
        )}
      </div>

      {a.unlocked && (
        <button
          onClick={onShare}
          aria-label={`${a.labelDe} teilen`}
          className="relative mt-3 inline-flex items-center gap-1 rounded-full bg-white/20 px-3 py-1 text-[10px] font-black text-white backdrop-blur transition hover:bg-white/35"
        >
          <Share2 className="h-3 w-3" aria-hidden />
          Teilen
        </button>
      )}
    </motion.div>
  );
}
