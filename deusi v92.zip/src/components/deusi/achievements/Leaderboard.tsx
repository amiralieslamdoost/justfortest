import { motion } from "@/lib/motion-lite";
import { useState } from "react";
import { ArrowDown, ArrowUp, Crown, Medal, Minus, Users } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import {
  leaderboardFor,
  myRank,
  SEASON,
  type LeaderboardRange,
  type LeaderRow,
} from "@/lib/deusi/gamification";

const RANGES: LeaderboardRange[] = ["Woche", "Monat", "Gesamt"];

export function Leaderboard() {
  const [range, setRange] = useState<LeaderboardRange>("Woche");
  const rows = leaderboardFor(range);
  const rank = myRank(range);
  const podium = rows.slice(0, 3);
  const rest = rows.slice(3);
  const toPromote = rows[SEASON.promoteRank - 1];
  const gap = Math.max(0, (rows[rank - 2]?.xp ?? 0) - (rows[rank - 1]?.xp ?? 0));

  return (
    <section className="neu-card relative overflow-hidden p-4 sm:p-6">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-24 -top-24 h-56 w-56 rounded-full bg-amber-400/10 blur-3xl"
      />
      <div className="relative flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <h2 className="flex items-center gap-2 text-base font-black leading-tight sm:text-lg">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-primary/12 text-primary">
              <Users className="h-4 w-4" aria-hidden />
            </span>
            Bestenliste
          </h2>
          <Fa className="fa-hint-xs">نفرات برتر</Fa>
        </div>
        <div className="flex rounded-full bg-secondary p-1">
          {RANGES.map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`rounded-full px-3 py-1 text-[11px] font-bold transition sm:text-xs ${
                range === r
                  ? "bg-foreground text-background shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Podium */}
      <div
        className="relative mt-5 grid grid-cols-3 items-end gap-2 rounded-3xl p-3 pt-6 sm:gap-4 sm:p-4 sm:pt-8"
        style={{
          backgroundImage:
            "radial-gradient(90% 120% at 50% 0%, color-mix(in oklab, #F59E0B 14%, transparent), transparent 70%)",
        }}
      >
        <PodiumStep row={podium[1]} place={2} height="h-16 sm:h-20" />
        <PodiumStep row={podium[0]} place={1} height="h-24 sm:h-28" />
        <PodiumStep row={podium[2]} place={3} height="h-12 sm:h-16" />
      </div>

      {/* My rank strip */}
      <div className="relative mt-5 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-x-3 gap-y-2 rounded-2xl bg-secondary/70 p-3 text-xs font-semibold ring-1 ring-border/60 sm:flex sm:flex-nowrap">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-foreground text-xs font-black text-background shadow">
          #{rank}
        </span>
        <div className="min-w-0 flex-1 leading-snug">
          <span className="text-foreground">Dein Platz diese Runde</span>
          {rank > 1 && (
            <span className="text-muted-foreground">
              {" "}
              · nur <b className="text-foreground tabular-nums">{gap} XP</b> bis Platz {rank - 1}
            </span>
          )}
          <Fa className="fa-hint-xs">
            {rank <= SEASON.promoteRank
              ? "در منطقه صعود هستی، همین‌طور ادامه بده"
              : "کمی تلاش بیشتر تا ورود به منطقه صعود"}
          </Fa>
        </div>
        <span
          className={`col-span-2 justify-self-start rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-widest sm:col-auto ${
            rank <= SEASON.promoteRank
              ? "bg-primary text-primary-foreground"
              : "bg-background text-muted-foreground ring-1 ring-border"
          }`}
        >
          {rank <= SEASON.promoteRank ? "Aufstiegszone" : `Top ${SEASON.promoteRank} = Aufstieg`}
        </span>
      </div>

      {/* Rest of the table */}
      <ul className="relative mt-3 space-y-1.5">
        {rest.map((r, i) => (
          <LeaderItem
            key={r.id}
            row={r}
            place={i + 4}
            isPromoteEdge={i + 4 === SEASON.promoteRank}
          />
        ))}
      </ul>

      <p className="relative mt-3 text-[11px] font-semibold leading-relaxed text-muted-foreground">
        Die Top {SEASON.promoteRank} steigen am Saisonende auf — noch {SEASON.daysLeft} Tage.
        {toPromote?.isMe && " Du bist dabei!"}
      </p>
    </section>
  );
}

function PodiumStep({ row, place, height }: { row?: LeaderRow; place: 1 | 2 | 3; height: string }) {
  if (!row) return <div />;
  const medal = place === 1 ? "🥇" : place === 2 ? "🥈" : "🥉";
  const ring = place === 1 ? "#F59E0B" : place === 2 ? "#94A3B8" : "#B45309";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: place * 0.08, type: "spring", stiffness: 140, damping: 14 }}
      className="flex min-w-0 flex-col items-center text-center"
    >
      <div className="relative">
        {place === 1 && (
          <motion.span
            aria-hidden
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -top-5 left-1/2 -translate-x-1/2"
          >
            <Crown className="h-5 w-5 drop-shadow" style={{ color: "#F59E0B" }} />
          </motion.span>
        )}
        <div
          className="grid place-items-center rounded-full p-[3px]"
          style={{
            background: `conic-gradient(from 180deg, ${ring}, transparent 55%, ${ring})`,
            boxShadow:
              place === 1 ? `0 0 22px color-mix(in oklab, ${ring} 55%, transparent)` : undefined,
          }}
        >
          <div
            className="grid h-12 w-12 place-items-center rounded-full text-sm font-black text-white ring-2 ring-card sm:h-14 sm:w-14"
            style={{
              backgroundImage: `linear-gradient(135deg, ${row.gradient[0]}, ${row.gradient[1]})`,
            }}
          >
            {row.initials}
          </div>
        </div>
        <span className="absolute -bottom-1 -right-1 text-base" aria-hidden>
          {medal}
        </span>
      </div>
      <div className="mt-2 w-full truncate text-[11px] font-black sm:text-xs">{row.name}</div>
      <div className="text-[10px] font-bold tabular-nums text-muted-foreground sm:text-[11px]">
        {row.xp.toLocaleString("de-DE")} XP
      </div>
      <div
        className={`mt-2 grid w-full place-items-start justify-center rounded-t-xl pt-1.5 ${height} ring-1 ring-border/70`}
        style={{
          backgroundImage: `linear-gradient(180deg, color-mix(in oklab, ${ring} 45%, transparent), transparent)`,
        }}
      >
        <span className="text-sm font-black text-foreground/70 sm:text-base">{place}</span>
      </div>
    </motion.div>
  );
}

function LeaderItem({
  row,
  place,
  isPromoteEdge,
}: {
  row: LeaderRow;
  place: number;
  isPromoteEdge: boolean;
}) {
  return (
    <li
      className={`flex items-center gap-2 rounded-xl px-2.5 py-2 ring-1 transition sm:gap-3 sm:px-3 ${
        row.isMe
          ? "bg-primary/10 ring-primary/40 shadow-sm"
          : "bg-card ring-border hover:-translate-y-px hover:ring-foreground/30"
      } ${isPromoteEdge ? "border-b-2 border-dashed border-primary/40" : ""}`}
    >
      <span className="w-5 shrink-0 text-center text-xs font-black tabular-nums text-muted-foreground sm:w-6">
        {place}
      </span>
      <div
        className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-[10px] font-black text-white sm:h-9 sm:w-9 sm:text-[11px]"
        style={{
          backgroundImage: `linear-gradient(135deg, ${row.gradient[0]}, ${row.gradient[1]})`,
        }}
      >
        {row.initials}
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-[11px] font-black sm:text-xs">
          {row.name} <span aria-hidden>{row.country}</span>
          {row.isMe && (
            <span className="ml-1.5 rounded-full bg-primary px-1.5 py-0.5 text-[9px] font-black uppercase text-primary-foreground">
              Du
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 text-[10px] font-semibold text-muted-foreground">
          <span className="inline-flex items-center gap-0.5">
            <Medal className="h-3 w-3" aria-hidden /> {row.badges}
          </span>
          <span>🔥 {row.streak}</span>
        </div>
      </div>
      <Delta value={row.delta} />
      <span className="w-12 shrink-0 text-right text-[11px] font-black tabular-nums sm:w-16 sm:text-xs">
        {row.xp.toLocaleString("de-DE")}
      </span>
    </li>
  );
}

function Delta({ value }: { value: number }) {
  if (value === 0)
    return <Minus className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden />;
  const up = value > 0;
  return (
    <span
      className={`inline-flex shrink-0 items-center text-[10px] font-black ${
        up ? "text-good" : "text-destructive"
      }`}
    >
      {up ? (
        <ArrowUp className="h-3.5 w-3.5" aria-hidden />
      ) : (
        <ArrowDown className="h-3.5 w-3.5" aria-hidden />
      )}
      {Math.abs(value)}
    </span>
  );
}
