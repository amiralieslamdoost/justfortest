import { motion } from "@/lib/motion-lite";
import { Gem } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import { RARITY_META, RARITY_SUMMARY } from "@/lib/deusi/gamification";

/** سشن ۹: خلاصهٔ کمیابی می‌تواند از دادهٔ زندهٔ دستاوردها بیاید. */
export interface RarityBarProps {
  summary?: typeof RARITY_SUMMARY;
}

export function RarityBar({ summary }: RarityBarProps = {}) {
  const rows = summary?.length ? summary : RARITY_SUMMARY;
  return (
    <section className="neu-card p-4 sm:p-6">
      <div>
        <h2 className="flex items-center gap-2 text-base font-black leading-tight sm:text-lg">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-primary/12 text-primary">
            <Gem className="h-4 w-4" aria-hidden />
          </span>
          Seltenheit deiner Sammlung
        </h2>
        <Fa className="fa-hint-xs">کمیابی نشان‌های تو</Fa>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2.5 sm:gap-3">
        {rows.map((r, i) => {
          const meta = RARITY_META[r.rarity];
          const pct = Math.round((r.unlocked / Math.max(r.total, 1)) * 100);
          return (
            <motion.div
              key={r.rarity}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="rounded-2xl p-3 ring-1 ring-border"
              style={{
                backgroundImage: `linear-gradient(135deg, color-mix(in oklab, ${meta.color} 14%, transparent), transparent)`,
              }}
            >
              <div className="flex items-center justify-between">
                <span
                  className="rounded-full px-2 py-0.5 text-[10px] font-black uppercase tracking-widest"
                  style={{
                    background: `color-mix(in oklab, ${meta.color} 22%, transparent)`,
                    color: meta.color,
                  }}
                >
                  {meta.de}
                </span>
                <span className="text-[10px] font-bold tabular-nums text-muted-foreground">
                  +{meta.xp} XP
                </span>
              </div>
              <div className="mt-2 text-xl font-black tabular-nums">
                {r.unlocked}
                <span className="text-sm text-muted-foreground">/{r.total}</span>
              </div>
              <Fa className="fa-hint-xs">{meta.fa}</Fa>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%` }}
                  transition={{ duration: 0.7, delay: i * 0.06 }}
                  className="h-full rounded-full"
                  style={{ background: meta.color }}
                />
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
