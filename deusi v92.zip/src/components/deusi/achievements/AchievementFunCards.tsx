import { motion } from "@/lib/motion-lite";
import { Target, Sparkles, Share2 } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import type { Achievement } from "@/lib/deusi/achievements";
import { formatDate } from "@/components/deusi/achievements/formatDate";

export interface NextUpCardProps {
  achievement: Achievement;
}

export function NextUpCard({ achievement }: NextUpCardProps) {
  const pct = achievement.progress
    ? Math.min(100, Math.round((achievement.progress.current / achievement.progress.target) * 100))
    : 0;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-2xl p-5 shadow-lg ring-1 ring-border md:col-span-1"
      style={{
        backgroundImage:
          "linear-gradient(135deg, color-mix(in oklab, var(--card) 96%, transparent), var(--card))",
      }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-40 blur-3xl"
        style={{ background: `radial-gradient(circle, ${achievement.color}, transparent 70%)` }}
      />
      <div className="relative flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
        <Target className="h-3.5 w-3.5" aria-hidden />
        Fast geschafft
        <Fa className="fa-hint-xs" inline>
          نزدیک به موفقیت
        </Fa>
      </div>
      <div className="relative mt-3 flex items-center gap-3">
        <div
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-2xl ring-1 ring-border"
          style={{
            backgroundImage: `linear-gradient(135deg, ${achievement.color}, color-mix(in oklab, ${achievement.color} 60%, #fff))`,
            color: "#fff",
          }}
        >
          <span aria-hidden>{achievement.emoji}</span>
        </div>
        <div className="min-w-0">
          <div className="truncate text-sm font-black leading-tight">{achievement.labelDe}</div>
          <Fa className="fa-hint-xs">{achievement.labelFa}</Fa>
        </div>
      </div>
      <div className="relative mt-3">
        <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.7 }}
            className="h-full rounded-full"
            style={{
              background: `linear-gradient(90deg, ${achievement.color}, color-mix(in oklab, ${achievement.color} 60%, #fff))`,
            }}
          />
        </div>
        <div className="mt-1 flex items-center justify-between text-[11px] font-bold tabular-nums text-muted-foreground">
          <span>
            {achievement.progress?.current} / {achievement.progress?.target}
          </span>
          <span>{pct}%</span>
        </div>
      </div>
    </motion.div>
  );
}

export interface FunTileProps {
  icon: React.ReactNode;
  gradient: string;
  title: string;
  fa: string;
  hint: string;
  highlight: string;
}

export function FunTile({ icon, gradient, title, fa, hint, highlight }: FunTileProps) {
  return (
    <div
      className="relative overflow-hidden rounded-2xl p-5 text-white shadow-lg ring-1 ring-white/20"
      style={{ backgroundImage: gradient }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-white/20 blur-2xl"
      />
      <div className="relative flex items-center justify-between">
        <div className="grid h-9 w-9 place-items-center rounded-xl bg-white/20 backdrop-blur">
          {icon}
        </div>
        <span className="rounded-full bg-white/25 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest backdrop-blur">
          {highlight}
        </span>
      </div>
      <div className="relative mt-3 text-base font-black leading-tight">{title}</div>
      <Fa className="fa-hint-xs !text-white/85">{fa}</Fa>
      <p className="mt-1 text-xs text-white/85">{hint}</p>
    </div>
  );
}

export interface LatestUnlockedCardProps {
  achievement: Achievement;
  onShare: () => void;
}

export function LatestUnlockedCard({ achievement, onShare }: LatestUnlockedCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="neu-card relative overflow-hidden p-5 sm:p-6"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full opacity-40 blur-3xl"
        style={{ background: `radial-gradient(circle, ${achievement.color}, transparent 70%)` }}
      />
      <div className="relative grid gap-4 sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center">
        <motion.div
          initial={{ scale: 0.6, rotate: -12 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 180 }}
          className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-3xl shadow-lg ring-1 ring-white/40"
          style={{
            backgroundImage: `linear-gradient(135deg, ${achievement.color}, color-mix(in oklab, ${achievement.color} 70%, #000))`,
            color: "#fff",
          }}
        >
          <span aria-hidden>{achievement.emoji}</span>
        </motion.div>
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
            <Sparkles className="h-3 w-3" aria-hidden />
            zuletzt freigeschaltet
          </div>
          <h2 className="mt-1.5 text-lg font-black leading-tight sm:text-xl">
            {achievement.labelDe}
          </h2>
          <Fa className="fa-hint-xs">{achievement.labelFa}</Fa>
          <p className="mt-1 text-xs text-muted-foreground">
            {achievement.sub}
            {achievement.unlockedAt && ` · ${formatDate(achievement.unlockedAt)}`}
          </p>
        </div>
        <button
          onClick={onShare}
          className="inline-flex items-center gap-1.5 rounded-full bg-foreground px-3.5 py-2 text-xs font-black text-background shadow-sm transition hover:opacity-90"
        >
          <Share2 className="h-3.5 w-3.5" aria-hidden />
          Teilen
        </button>
      </div>
    </motion.div>
  );
}
