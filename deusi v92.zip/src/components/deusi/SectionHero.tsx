import type { CSSProperties, ReactNode } from "react";
import { Fa } from "@/components/deusi/Fa";
import { SECTION_THEME, type SectionKey } from "@/lib/deusi/sectionTheme";

type SectionHeroProps = {
  sectionKey: SectionKey;
  /** Override German title */
  titleDe?: string;
  /** Farsi hint line under H1 */
  titleFa?: string;
  /** German paragraph */
  descDe?: string;
  descFa?: string;
  /** Portion of the H1 that gets the bright gradient (defaults to theme.highlight) */
  highlight?: string;
  /** Right-hand slot: search, filter, action buttons, KPI chips… */
  right?: ReactNode;
  /** Optional full-width content rendered below the title row */
  children?: ReactNode;
  /** Let children overflow the header (e.g. a search dropdown) */
  allowOverflow?: boolean;
  className?: string;
};

/**
 * Unified section header — the single "hero card" every screen starts with.
 *
 * Mobile-first: one flat gradient in the section's own palette, a compact
 * icon + title block and a wrap-friendly action row. No blurred blobs, no
 * layered radial gradients — those are what make mid-range phones stutter.
 */
export function SectionHero({
  sectionKey,
  titleDe,
  titleFa,
  descDe,
  descFa,
  highlight,
  right,
  children,
  allowOverflow = false,
  className = "",
}: SectionHeroProps) {
  const theme = SECTION_THEME[sectionKey];
  const Icon = theme.Icon;

  const de = titleDe ?? theme.titleDe;
  const fa = titleFa ?? theme.titleFa;
  const description = descDe ?? theme.descDe;
  const descriptionFa = descFa ?? theme.descFa;
  const highlightWord = highlight ?? theme.highlight;

  let before: string = de;
  let mid: string = "";
  let after: string = "";
  if (highlightWord) {
    const idx = de.indexOf(highlightWord);
    if (idx >= 0) {
      before = de.slice(0, idx);
      mid = de.slice(idx, idx + highlightWord.length);
      after = de.slice(idx + highlightWord.length);
    }
  }

  const style: CSSProperties = {
    ["--section-base" as never]: theme.base,
    ["--section-primary" as never]: theme.primary,
    ["--section-accent" as never]: theme.accent,
  };

  return (
    <header
      style={style}
      className={`app-hero ${allowOverflow ? "!overflow-visible" : ""} ${className}`}
    >
      <div className="relative grid gap-3 sm:gap-4 xl:grid-cols-[minmax(0,1fr)_auto] xl:items-center">
        <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3">
          <div
            aria-hidden
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white sm:h-14 sm:w-14"
            style={{ color: theme.primary }}
          >
            <Icon size={23} strokeWidth={2} className="sm:hidden" />
            <Icon size={30} strokeWidth={2} className="hidden sm:block" />
          </div>
          <div className="min-w-0">
            <div className="app-hero-chip">{theme.label}</div>
            <h1 className="text-balance text-xl font-black leading-tight mt-1 sm:mt-1.5 sm:text-3xl">
              {before}
              {mid && <span className="text-white/85">{mid}</span>}
              {after}
            </h1>
            {fa && <Fa className="fa-hint-xs !text-white/85">{fa}</Fa>}
            {description && (
              <p className="mt-1.5 hidden max-w-2xl text-sm text-white/75 sm:block">{description}</p>
            )}
            {descriptionFa && (
              <Fa className="fa-hint-xs !hidden !text-white/65 sm:!block">{descriptionFa}</Fa>
            )}
          </div>
        </div>

        {right && (
          <div className="flex w-full min-w-0 flex-wrap items-center gap-1.5 sm:gap-2 xl:w-auto">
            {right}
          </div>
        )}
      </div>
      {children && <div className="relative mt-2.5 sm:mt-5">{children}</div>}

    </header>
  );
}
