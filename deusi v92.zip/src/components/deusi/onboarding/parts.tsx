import type { ReactNode } from "react";
import { motion } from "@/lib/motion-lite";
import { Check, Info } from "lucide-react";
import { cn } from "@/lib/utils";

/** Segmentierte Fortschritts-Anzeige — ein Balken-Stück pro Schritt. */
export function OnboardingProgress({
  current,
  total,
  accent = "var(--section-primary)",
  labels,
}: {
  current: number;
  total: number;
  accent?: string;
  labels?: string[];
}) {
  const pct = Math.round(((current + 1) / total) * 100);
  return (
    <div className="flex flex-col gap-1.5">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-2 text-[11px] font-semibold text-muted-foreground">
        <span className="min-w-0 truncate">
          Schritt {current + 1}/{total}
          {labels?.[current] ? (
            <span className="ml-1.5 text-foreground/70">· {labels[current]}</span>
          ) : null}
        </span>
        <span className="shrink-0 tabular-nums" style={{ color: accent }}>
          {pct}%
        </span>
      </div>
      <div
        className="flex w-full gap-1"
        role="progressbar"
        aria-valuemin={1}
        aria-valuemax={total}
        aria-valuenow={current + 1}
        aria-label="Fortschritt im Lernprofil"
      >
        {Array.from({ length: total }).map((_, i) => {
          const done = i < current;
          const active = i === current;
          return (
            <span
              key={i}
              className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-muted"
              title={labels?.[i]}
            >
              <motion.span
                className="absolute inset-y-0 left-0 rounded-full"
                style={{
                  background:
                    done || active
                      ? `linear-gradient(90deg, ${accent}, color-mix(in oklab, ${accent} 55%, white))`
                      : "transparent",
                }}
                initial={false}
                animate={{ width: done ? "100%" : active ? "55%" : "0%" }}
                transition={{ duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
              />
            </span>
          );
        })}
      </div>
    </div>
  );
}

/** Große Antwort-Karte — Touch-freundlich, klarer Auswahl-Zustand, farbiger Akzent. */
export function OptionCard({
  active,
  onClick,
  title,
  desc,
  descFa,
  multi,
  compact,
  accent = "var(--section-primary)",
  icon,
}: {
  active: boolean;
  onClick: () => void;
  title: ReactNode;
  desc?: string;
  descFa?: string;
  multi?: boolean;
  compact?: boolean;
  accent?: string;
  icon?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      role={multi ? "checkbox" : "radio"}
      aria-checked={active}
      style={
        active
          ? {
              borderColor: accent,
              backgroundColor: `color-mix(in oklab, ${accent} 9%, transparent)`,
              boxShadow: `0 10px 26px -18px ${accent}`,
            }
          : undefined
      }
      className={cn(
        "group relative flex h-full w-full items-center gap-3 rounded-2xl border p-3 text-left outline-none transition-all sm:p-3.5",
        "min-h-[3.25rem] focus-visible:ring-4 focus-visible:ring-[color:var(--section-primary)]/25",
        active
          ? "shadow-sm"
          : "border-border/70 bg-card hover:-translate-y-px hover:border-border hover:bg-muted/40",
      )}
    >
      {icon ? (
        <span
          aria-hidden
          style={{
            backgroundColor: `color-mix(in oklab, ${accent} ${active ? 18 : 10}%, transparent)`,
            color: accent,
          }}
          className={cn(
            "grid shrink-0 place-items-center rounded-xl transition-colors",
            compact ? "h-8 w-8" : "h-9 w-9",
          )}
        >
          {icon}
        </span>
      ) : null}

      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-baseline gap-x-2 text-[14px] font-bold leading-tight tracking-tight text-foreground">
          {title}
        </span>
        {desc ? (
          <span className="mt-0.5 block text-[11px] leading-snug text-muted-foreground">
            {desc}
          </span>
        ) : null}
        {descFa ? (
          <span
            lang="fa"
            dir="rtl"
            className="mt-0.5 block text-right text-[11px] leading-relaxed text-muted-foreground/90"
          >
            {descFa}
          </span>
        ) : null}
      </span>

      <span
        aria-hidden
        style={active ? { backgroundColor: accent, borderColor: "transparent" } : undefined}
        className={cn(
          "grid h-5 w-5 shrink-0 place-items-center border transition-colors",
          multi ? "rounded-md" : "rounded-full",
          active ? "text-white" : "border-border bg-background",
        )}
      >
        {active ? <Check className="h-3.5 w-3.5" /> : null}
      </span>
    </button>
  );
}

/** Zusammenfassungs-Kachel im Profil-Review. */
export function SummaryTile({
  label,
  labelFa,
  value,
  accent = "var(--section-primary)",
  icon,
}: {
  label: string;
  labelFa?: string;
  value: ReactNode;
  accent?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border/70 bg-card p-4">
      <span
        aria-hidden
        className="absolute inset-x-0 top-0 h-1"
        style={{
          background: `linear-gradient(90deg, ${accent}, color-mix(in oklab, ${accent} 40%, white))`,
        }}
      />
      <div className="flex items-start gap-3">
        {icon ? (
          <span
            aria-hidden
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl"
            style={{
              backgroundColor: `color-mix(in oklab, ${accent} 12%, transparent)`,
              color: accent,
            }}
          >
            {icon}
          </span>
        ) : null}
        <div className="min-w-0">
          <div className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/80">
            {label}
            {labelFa ? (
              <span lang="fa" dir="rtl" className="ml-1.5 normal-case tracking-normal">
                · {labelFa}
              </span>
            ) : null}
          </div>
          <div className="mt-0.5 text-balance text-[15px] font-black leading-tight tracking-tight">
            {value}
          </div>
        </div>
      </div>
    </div>
  );
}

/** Rahmen einer Onboarding-Frage inkl. Überschrift und zweisprachigem Hinweis. */
export function QuestionShell({
  title,
  fa,
  hint,
  hintFa,
  accent = "var(--section-primary)",
  icon,
  children,
}: {
  title: string;
  fa: string;
  hint?: string;
  hintFa?: string;
  accent?: string;
  icon?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start gap-3">
        {icon ? (
          <span
            aria-hidden
            className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl sm:h-11 sm:w-11"
            style={{
              backgroundColor: `color-mix(in oklab, ${accent} 13%, transparent)`,
              color: accent,
            }}
          >
            {icon}
          </span>
        ) : null}
        <div className="min-w-0 flex-1">
          <h1 className="text-balance text-lg font-black leading-tight tracking-tight sm:text-2xl">
            {title}
          </h1>
          <p
            lang="fa"
            dir="rtl"
            className="mt-0.5 text-[13px] font-bold sm:text-sm"
            style={{ color: accent }}
          >
            {fa}
          </p>
        </div>
      </div>

      {hint ? (
        <p className="-mt-1 hidden text-[12.5px] leading-snug text-muted-foreground sm:block">
          {hint}
        </p>
      ) : null}

      {hintFa ? (
        <p
          lang="fa"
          dir="rtl"
          className="flex items-start gap-2 rounded-2xl border px-3 py-2 text-right text-[12px] leading-6 text-foreground/80"
          style={{
            borderColor: `color-mix(in oklab, ${accent} 28%, transparent)`,
            backgroundColor: `color-mix(in oklab, ${accent} 7%, transparent)`,
          }}
        >
          <Info aria-hidden className="mt-1 h-3.5 w-3.5 shrink-0" style={{ color: accent }} />
          <span className="min-w-0 flex-1">{hintFa}</span>
        </p>
      ) : null}

      <div className="flex flex-col gap-4">{children}</div>
    </div>
  );
}

/** Einheitliche, logische Farben der Selbsteinschätzung. */
const RATING_COLOR: Record<"weak" | "ok" | "strong", string> = {
  weak: "#ef4444",
  ok: "#f59e0b",
  strong: "#22c55e",
};

/** Dreistufige Selbsteinschätzung einer Fertigkeit. */
export function SkillRatingRow({
  label,
  labelFa,
  color,
  value,
  onChange,
  icon,
}: {
  label: string;
  labelFa: string;
  color: string;
  value: "weak" | "ok" | "strong";
  onChange: (v: "weak" | "ok" | "strong") => void;
  icon?: ReactNode;
}) {
  const options: { value: "weak" | "ok" | "strong"; de: string; fa: string }[] = [
    { value: "weak", de: "Schwach", fa: "ضعیف" },
    { value: "ok", de: "Geht so", fa: "متوسط" },
    { value: "strong", de: "Stark", fa: "قوی" },
  ];
  return (
    <div className="flex h-full flex-col justify-between gap-2.5 rounded-2xl border border-border/70 bg-card p-3">
      <div className="flex min-w-0 items-center gap-2">
        {icon ? (
          <span
            aria-hidden
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg"
            style={{ backgroundColor: `color-mix(in oklab, ${color} 14%, transparent)`, color }}
          >
            {icon}
          </span>
        ) : (
          <span
            aria-hidden
            className="h-2.5 w-2.5 shrink-0 rounded-full"
            style={{ background: color }}
          />
        )}
        <span className="truncate text-sm font-bold tracking-tight">{label}</span>
        <span lang="fa" dir="rtl" className="ml-auto shrink-0 text-xs text-muted-foreground">
          {labelFa}
        </span>
      </div>
      <div
        role="radiogroup"
        aria-label={label}
        className="grid grid-cols-3 gap-1 rounded-full bg-muted/70 p-1"
      >
        {options.map((o) => {
          const active = o.value === value;
          const tone = RATING_COLOR[o.value];
          return (
            <button
              key={o.value}
              type="button"
              role="radio"
              aria-checked={active}
              aria-label={`${label}: ${o.de}`}
              onClick={() => onChange(o.value)}
              style={
                active
                  ? {
                      background: `linear-gradient(180deg, color-mix(in oklab, ${tone} 78%, white), ${tone})`,
                      boxShadow: `0 6px 16px -10px ${tone}`,
                    }
                  : undefined
              }
              className={cn(
                "rounded-full px-2 py-2 text-center text-[11px] font-bold transition-colors",
                active ? "text-white" : "text-muted-foreground hover:text-foreground",
              )}
            >
              <span lang="fa" dir="rtl">
                {o.fa}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
