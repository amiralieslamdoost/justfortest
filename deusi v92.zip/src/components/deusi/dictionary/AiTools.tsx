import { useState } from "react";
import { motion, AnimatePresence } from "@/lib/motion-lite";
import type { DictWord } from "@/lib/deusi/dictionary/types";

type ToolId = "explain" | "persian" | "examples" | "grammar" | "memory" | "flashcards" | "compare";

const TOOLS: { id: ToolId; label: string; icon: string; color: string }[] = [
  { id: "explain", label: "Wort erklären", icon: "💡", color: "#8B5CF6" },
  { id: "persian", label: "Auf Persisch", icon: "🌐", color: "#EC4899" },
  { id: "examples", label: "Mehr Beispiele", icon: "✍️", color: "#3B82F6" },
  { id: "grammar", label: "Grammatik erklären", icon: "📖", color: "#22C55E" },
  { id: "memory", label: "Merktipps", icon: "🧠", color: "#F59E0B" },
  { id: "flashcards", label: "Karteikarten", icon: "🃏", color: "#EF4444" },
  { id: "compare", label: "Mit ähnlichen vergleichen", icon: "⚖️", color: "#0EA5E9" },
];

export function AiToolsPanel({ word }: { word: DictWord }) {
  const [active, setActive] = useState<ToolId | null>(null);
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  const run = (id: ToolId) => {
    setActive(id);
    setLoading(true);
    setResponse(null);
    setTimeout(() => {
      setLoading(false);
      setResponse(mockResponse(id, word));
    }, 700);
  };

  return (
    <div className="rounded-3xl border border-purple-200/40 bg-gradient-to-br from-purple-50/70 to-pink-50/70 p-4 dark:from-purple-950/30 dark:to-pink-950/20">
      <div className="mb-3 flex items-center gap-2">
        <span
          className="grid h-7 w-7 place-items-center rounded-full text-white shadow"
          style={{ background: "linear-gradient(135deg, #8B5CF6, #EC4899)" }}
        >
          <SparkIcon />
        </span>
        <div className="text-sm font-semibold">AI-Werkzeuge</div>
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        {TOOLS.map((t) => (
          <button
            key={t.id}
            onClick={() => run(t.id)}
            className={`flex items-center gap-2 rounded-2xl border px-3 py-2 text-left text-xs transition ${
              active === t.id
                ? "border-transparent text-white shadow-lg"
                : "border-border/60 bg-white/70 hover:-translate-y-0.5 hover:shadow dark:bg-white/5"
            }`}
            style={
              active === t.id
                ? { background: `linear-gradient(135deg, ${t.color}, ${t.color}cc)` }
                : undefined
            }
          >
            <span>{t.icon}</span>
            <span className="font-medium">{t.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence>
        {(loading || response) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 overflow-hidden"
          >
            <div className="rounded-2xl border border-border/60 bg-white/80 p-3 text-xs dark:bg-white/5">
              {loading ? (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <span className="inline-block h-3 w-3 animate-pulse rounded-full bg-purple-500" />
                  KI denkt nach…
                </div>
              ) : (
                <p className="whitespace-pre-line leading-relaxed">{response}</p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SparkIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2l1.6 5.2L19 9l-5.4 1.8L12 16l-1.6-5.2L5 9l5.4-1.8L12 2zM19 14l.9 2.7 2.7.8-2.7.9-.9 2.6-.9-2.6-2.7-.9 2.7-.8L19 14z" />
    </svg>
  );
}

function mockResponse(id: ToolId, w: DictWord): string {
  switch (id) {
    case "explain":
      return `„${w.headword}" bedeutet: ${w.meanings[0]?.de}\n\nDieses Wort gehört zur Wortart ${w.pos} und wird häufig im Alltag verwendet. Es ist auf Niveau ${w.cefr} eingestuft.`;
    case "persian":
      return `«${w.headword}» به فارسی: ${w.meanings.find((m) => m.fa)?.fa ?? "معنی این کلمه"}\n\nاین کلمه در آلمانی بسیار پرکاربرد است و در سطح ${w.cefr} قرار دارد.`;
    case "examples":
      return `Weitere Beispielsätze mit „${w.headword}":\n\n1. Heute möchte ich ${w.headword} genauer kennenlernen.\n2. In der Prüfung kam das Wort „${w.headword}" mehrmals vor.\n3. Kannst du „${w.headword}" in einem eigenen Satz benutzen?`;
    case "grammar":
      if (w.verbGrammar)
        return `„${w.headword}" ist ein ${w.verbGrammar.regular ? "regelmäßiges" : "unregelmäßiges"} Verb mit dem Hilfsverb „${w.verbGrammar.aux}". Partizip II: ${w.verbGrammar.partizipII}.`;
      if (w.nounGrammar)
        return `„${w.headword}" ist ein ${{ m: "maskulines", f: "feminines", n: "neutrales" }[w.nounGrammar.gender]} Substantiv. Artikel: ${w.nounGrammar.article}. Plural: ${w.nounGrammar.plural}.`;
      if (w.adjectiveGrammar)
        return `Adjektiv „${w.headword}" — Steigerung: ${w.headword} / ${w.adjectiveGrammar.comparative} / ${w.adjectiveGrammar.superlative}.`;
      return `Zu „${w.headword}" gibt es keine speziellen Grammatikregeln.`;
    case "memory":
      return `🧠 Merktipp:\n${w.memoryTip ?? `Verbinde „${w.headword}" mit einem persönlichen Bild oder einer Erinnerung. Sprich es laut aus und schreibe drei Beispielsätze.`}`;
    case "flashcards":
      return `🃏 3 Karteikarten wurden erstellt:\n\n• Vorderseite: ${w.headword} → Rückseite: ${w.meanings[0]?.en}\n• Vorderseite: ${w.examples[0]?.de} → Rückseite: ${w.examples[0]?.en}\n• Vorderseite: Synonym? → Rückseite: ${w.family.synonyms[0] ?? "—"}`;
    case "compare": {
      const synonyms = w.family.synonyms.slice(0, 2);
      return `Vergleich mit ähnlichen Wörtern:\n\n${synonyms.map((s) => `• „${s}" — bedeutet Ähnliches, wird aber in einem etwas anderen Kontext verwendet.`).join("\n") || "Keine ähnlichen Wörter zum Vergleichen."}`;
    }
  }
}
