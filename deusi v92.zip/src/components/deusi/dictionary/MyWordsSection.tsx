import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "@/lib/motion-lite";
import type { KeyboardEvent, MouseEvent } from "react";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import { WordCard } from "./WordCard";
import { useCustomWords, type NewWordInput } from "@/lib/deusi/dictionary/customWords";
import { AddWordModal } from "./AddWordModal";
import { useInteractions } from "@/lib/deusi/interactions";

type OpenEvent = MouseEvent<HTMLElement> | KeyboardEvent<HTMLElement>;

type Tab = "all" | "own" | "bookmarks" | "favorites";
const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "all", label: "Alle", icon: "📚" },
  { id: "own", label: "Eigene", icon: "✍️" },
  { id: "bookmarks", label: "Lesezeichen", icon: "🔖" },
  { id: "favorites", label: "Favoriten", icon: "❤️" },
];

interface Props {
  masterWords: DictWord[];
  findById: (id: string) => DictWord | undefined;
  onOpen: (id: string, event?: OpenEvent) => void;
  onToggleBookmark: (id: string) => void;
  bookmarks: (id: string) => boolean;
  progress?: Record<string, number>;
  inLeitner?: (id: string) => boolean;
  onToggleLeitner?: (id: string, label?: string) => void;
  /** Kompakter Teaser: nur so viele Karten zeigen, kein „mehr laden". */
  previewLimit?: number;
  /** Ziel für „Alle anzeigen" (aktiviert die Teaser-Fußzeile). */
  moreTo?: string;
}

export function MyWordsSection({
  masterWords,
  findById,
  onOpen,
  onToggleBookmark,
  bookmarks,
  progress = {},
  inLeitner,
  onToggleLeitner,
  previewLimit,
  moreTo,
}: Props) {
  const [tab, setTab] = useState<Tab>("all");
  const [modalOpen, setModalOpen] = useState(false);
  const PAGE_SIZE = 10;
  const [visible, setVisible] = useState(PAGE_SIZE);
  const { words: customWords, add, remove } = useCustomWords();
  const { bookmarks: bmState, favorites: fvState } = useInteractions();

  // Merge master + custom so we can look up custom words in bookmarks/favorites too
  const wordById = useMemo(() => {
    const map = new Map<string, DictWord>();
    for (const w of masterWords) map.set(w.id, w);
    for (const w of customWords) map.set(w.id, w);
    return map;
  }, [masterWords, customWords]);

  const bookmarkWords = useMemo(
    () => (bmState.word ?? []).map((e) => wordById.get(e.id)).filter(Boolean) as DictWord[],
    [bmState.word, wordById],
  );
  const favoriteWords = useMemo(
    () => (fvState.word ?? []).map((e) => wordById.get(e.id)).filter(Boolean) as DictWord[],
    [fvState.word, wordById],
  );

  const totalUnique = useMemo(() => {
    const ids = new Set<string>();
    customWords.forEach((w) => ids.add(w.id));
    bookmarkWords.forEach((w) => ids.add(w.id));
    favoriteWords.forEach((w) => ids.add(w.id));
    return ids.size;
  }, [customWords, bookmarkWords, favoriteWords]);

  const list: DictWord[] =
    tab === "own"
      ? customWords
      : tab === "bookmarks"
        ? bookmarkWords
        : tab === "favorites"
          ? favoriteWords
          : (() => {
              const seen = new Set<string>();
              const out: DictWord[] = [];
              for (const w of [...customWords, ...favoriteWords, ...bookmarkWords]) {
                if (!seen.has(w.id)) {
                  seen.add(w.id);
                  out.push(w);
                }
              }
              return out;
            })();

  const handleAdd = (input: NewWordInput) => {
    add(input);
    setTab("own");
    setVisible(PAGE_SIZE);
  };
  const isCustom = (id: string) => customWords.some((w) => w.id === id);

  // Reset pagination when the visible tab changes.
  useEffect(() => {
    setVisible(PAGE_SIZE);
  }, [tab]);

  const shown = list.slice(0, previewLimit ?? visible);

  return (
    <section className="relative overflow-hidden rounded-3xl border-2 border-purple-300/70 bg-card shadow-[0_8px_30px_-8px_rgba(139,92,246,0.35)] ring-1 ring-purple-200/50 dark:border-purple-500/40 dark:ring-purple-900/40">
      {/* Accent stripe on the left edge to strongly separate this section */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 left-0 w-1.5 bg-gradient-to-b from-purple-500 via-fuchsia-500 to-pink-500"
      />
      {/* Header */}
      <div className="relative overflow-hidden bg-[linear-gradient(135deg,#EEF2FF,#FDF2F8)] px-5 py-4 dark:bg-[linear-gradient(135deg,rgba(76,29,149,0.35),rgba(131,24,67,0.35))]">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-6 -top-8 h-32 w-32 rounded-full bg-purple-300/40 blur-3xl dark:bg-purple-500/20"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -left-8 bottom-0 h-24 w-24 rounded-full bg-pink-300/40 blur-3xl dark:bg-pink-500/20"
        />

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className="grid h-11 w-11 place-items-center rounded-2xl text-xl text-white shadow-lg"
              style={{ background: "linear-gradient(135deg, #8B5CF6, #EC4899)" }}
            >
              ✨
            </div>
            <div>
              <div className="mb-0.5 flex items-center gap-1.5">
                <span className="rounded-full bg-purple-600/15 px-1.5 py-px text-[9px] font-black tracking-widest text-purple-700 dark:text-purple-300">
                  03
                </span>
                <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                  Abschnitt
                </span>
              </div>
              <h2 className="text-base font-black tracking-tight sm:text-lg">Meine Wörter</h2>
              <p className="text-xs text-muted-foreground">
                {totalUnique} Wörter · deine persönliche Sammlung
              </p>
            </div>
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="group flex items-center gap-1.5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-2 text-sm font-semibold text-white shadow-md transition hover:shadow-xl active:scale-95"
          >
            <span className="text-base leading-none transition group-hover:rotate-90">＋</span>
            Neues Wort
          </button>
        </div>

        {/* Tabs */}
        <div className="sidebar-scroll relative z-10 mt-4 flex gap-1 overflow-x-auto rounded-2xl bg-white/70 p-1 backdrop-blur sm:flex-wrap sm:rounded-full dark:bg-slate-900/60">
          {TABS.map((t) => {
            const count =
              t.id === "own"
                ? customWords.length
                : t.id === "bookmarks"
                  ? bookmarkWords.length
                  : t.id === "favorites"
                    ? favoriteWords.length
                    : totalUnique;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex shrink-0 items-center justify-center gap-1 whitespace-nowrap rounded-xl px-2.5 py-1.5 text-[11px] font-semibold transition sm:gap-1.5 sm:rounded-full sm:px-3.5 sm:text-xs ${
                  tab === t.id
                    ? "bg-white text-foreground shadow-sm dark:bg-slate-800"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <span className="text-sm sm:text-base">{t.icon}</span>
                <span>{t.label}</span>
                <span
                  className={`ml-0.5 shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                    tab === t.id ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Body */}
      <div className="p-5">
        {list.length === 0 ? (
          <EmptyState tab={tab} onAdd={() => setModalOpen(true)} />
        ) : (
          <>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              <AnimatePresence>
                {shown.map((w) => (
                  <motion.div
                    key={w.id}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="relative"
                  >
                    <WordCard
                      word={w}
                      progress={progress[w.id] ?? Math.min(80, w.frequency)}
                      bookmarked={bookmarks(w.id)}
                      inLeitner={inLeitner?.(w.id)}
                      onOpen={(event) => onOpen(w.id, event)}
                      onToggleBookmark={() => onToggleBookmark(w.id)}
                      onToggleLeitner={
                        onToggleLeitner ? () => onToggleLeitner(w.id, w.headword) : undefined
                      }
                    />
                    {isCustom(w.id) && (
                      <>
                        <span className="pointer-events-none absolute left-2 top-2 z-10 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white shadow">
                          Eigen
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`„${w.headword}" löschen?`)) remove(w.id);
                          }}
                          className="absolute bottom-2 right-2 z-10 grid h-9 w-9 place-items-center rounded-full bg-white/95 text-red-500 shadow-md transition hover:bg-red-500 hover:text-white"
                          aria-label="Löschen"
                        >
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.2"
                          >
                            <path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m2 0v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6" />
                          </svg>
                        </button>
                      </>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
            {moreTo ? (
              <div className="mt-5 flex flex-col items-center gap-2">
                <div className="text-xs text-muted-foreground">
                  {shown.length} von {list.length}
                </div>
                <Link
                  to={moreTo}
                  className="rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:shadow-lg active:scale-[0.98]"
                >
                  Alle meine Wörter ansehen →
                </Link>
              </div>
            ) : (
              visible < list.length && (
                <div className="mt-5 flex flex-col items-center gap-2">
                  <div className="text-xs text-muted-foreground">
                    {Math.min(visible, list.length)} von {list.length}
                  </div>
                  <button
                    onClick={() => setVisible((v) => v + PAGE_SIZE)}
                    className="rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:shadow-lg active:scale-[0.98]"
                  >
                    {PAGE_SIZE} weitere laden
                  </button>
                </div>
              )
            )}
          </>
        )}
      </div>

      <AddWordModal open={modalOpen} onClose={() => setModalOpen(false)} onSubmit={handleAdd} />
    </section>
  );
}

function EmptyState({ tab, onAdd }: { tab: Tab; onAdd: () => void }) {
  const copy: Record<Tab, { icon: string; title: string; desc: string; cta?: string }> = {
    all: {
      icon: "🌱",
      title: "Deine Sammlung ist noch leer",
      desc: "Speichere Wörter, markiere Favoriten oder erstelle eigene Einträge.",
      cta: "Erstes Wort hinzufügen",
    },
    own: {
      icon: "✍️",
      title: "Noch keine eigenen Wörter",
      desc: "Erstelle dein erstes persönliches Wort mit vollständiger Grammatik.",
      cta: "Wort erstellen",
    },
    bookmarks: {
      icon: "🔖",
      title: "Keine Lesezeichen",
      desc: "Tippe auf das Lesezeichen-Symbol eines Wortes, um es hier zu speichern.",
    },
    favorites: {
      icon: "❤️",
      title: "Keine Favoriten",
      desc: "Tippe auf das Herz in der Detailansicht, um Favoriten zu sammeln.",
    },
  };
  const c = copy[tab];
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border/60 bg-muted/30 px-6 py-10 text-center">
      <div className="text-5xl">{c.icon}</div>
      <div>
        <h3 className="text-sm font-bold">{c.title}</h3>
        <p className="mt-1 max-w-sm text-xs text-muted-foreground">{c.desc}</p>
      </div>
      {c.cta && (
        <button
          onClick={onAdd}
          className="mt-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-2 text-xs font-semibold text-white shadow-md transition hover:shadow-lg"
        >
          {c.cta}
        </button>
      )}
    </div>
  );
}
