/** Route-level presentational helpers extracted from /dictionary. */
import type React from "react";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import { Link } from "@tanstack/react-router";
import { PROVERBS } from "@/lib/deusi/dictionary/proverbs";
import { CATEGORIES } from "@/lib/deusi/dictionary/categories";
import { FEATURED_WORDS, VOCAB_STATS } from "@/lib/deusi/dictionary/mockWords";
import { LEARNING_BOOKS } from "@/lib/deusi/dictionary/books";
import { ProverbCard } from "@/components/deusi/dictionary/ProverbCard";
import { WordDetailPanel } from "@/components/deusi/dictionary/WordDetailPanel";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import { Fa } from "@/components/deusi/Fa";
import { SectionShell } from "@/components/deusi/dictionary/SectionShell";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";

export function Chip({
  children,
  active,
  onClick,
  accent,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
  accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${
        active
          ? accent
            ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md"
            : "bg-primary text-primary-foreground shadow-md"
          : "border border-border/60 bg-card hover:bg-muted"
      }`}
    >
      {children}
    </button>
  );
}

export function hexToRgb(hex: string): string {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `${r} ${g} ${b}`;
}

export function SearchIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      className="text-muted-foreground"
    >
      <circle cx="11" cy="11" r="7" />
      <path d="M20 20l-3.5-3.5" />
    </svg>
  );
}
export function ClockIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      className="text-muted-foreground"
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </svg>
  );
}

/* ============ Proverbs & Idioms (Teaser) ============ */
export function ProverbsSection({ accent, anchorId }: { accent: string; anchorId: string }) {
  const preview = PROVERBS.slice(0, 3);
  const sprichwoerter = PROVERBS.filter((p) => p.kind === "sprichwort").length;
  const redewendungen = PROVERBS.length - sprichwoerter;
  return (
    <SectionShell
      anchorId={anchorId}
      index={5}
      icon="💬"
      accent={accent}
      title="Sprichwörter & Redewendungen"
      subtitle={`${sprichwoerter} Sprichwörter · ${redewendungen} Redewendungen`}
      action={
        <Link
          to="/dictionary/sprichwoerter"
          className="shrink-0 rounded-full px-3.5 py-1.5 text-xs font-bold text-white shadow-sm transition hover:-translate-y-0.5"
          style={{ background: `linear-gradient(135deg, ${accent}, ${accent}cc)` }}
        >
          Alle ansehen →
        </Link>
      }
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {preview.map((p) => (
          <ProverbCard key={p.id} p={p} />
        ))}
      </div>
      <div className="mt-5 flex justify-center">
        <Link
          to="/dictionary/sprichwoerter"
          className="rounded-2xl border border-border/60 bg-card px-5 py-2 text-sm font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground"
        >
          Alle {PROVERBS.length} Ausdrücke auf einer eigenen Seite
        </Link>
      </div>
    </SectionShell>
  );
}

function MiniStat({
  icon,
  label,
  value,
  delta,
  accent,
}: {
  icon: string;
  label: string;
  value: number;
  delta?: number;
  tint?: string;
  accent: string;
}) {
  return (
    <div
      className="group relative flex min-w-0 items-center gap-2.5 overflow-hidden rounded-2xl border border-border/60 bg-card p-3 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
      style={{
        backgroundImage: `linear-gradient(135deg, color-mix(in oklab, ${accent} 8%, transparent), transparent 60%)`,
      }}
    >
      {/* top accent bar */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[3px]"
        style={{
          background: `linear-gradient(90deg, ${accent}, color-mix(in oklab, ${accent} 30%, transparent))`,
        }}
      />
      {/* soft corner glow */}
      <span
        aria-hidden
        className="pointer-events-none absolute -right-8 -top-8 h-20 w-20 rounded-full opacity-40 blur-2xl"
        style={{ background: `radial-gradient(circle, ${accent}66, transparent 70%)` }}
      />
      <span
        className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl text-base ring-1"
        style={{
          background: `linear-gradient(135deg, color-mix(in oklab, ${accent} 22%, transparent), color-mix(in oklab, ${accent} 8%, transparent))`,
          color: accent,
          boxShadow: `0 6px 16px -8px ${accent}80`,
          // @ts-expect-error CSS custom prop
          "--tw-ring-color": `${accent}33`,
        }}
      >
        {icon}
      </span>
      <div className="relative min-w-0 flex-1">
        <div className="truncate text-[9px] font-semibold uppercase tracking-widest text-muted-foreground">
          {label}
        </div>
        <div className="flex items-baseline gap-1.5">
          <span className="text-lg font-black leading-none tabular-nums text-foreground">
            {value.toLocaleString("de")}
          </span>
          {typeof delta === "number" && (
            <span
              className="rounded-full px-1.5 py-px text-[9px] font-bold"
              style={{ background: "rgba(16,185,129,0.12)", color: "#059669" }}
            >
              +{delta}%
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

const CEFR_SPLIT = [
  { lvl: "A1", pct: 26, color: "#10B981" }, // emerald
  { lvl: "A2", pct: 22, color: "#22C55E" }, // green
  { lvl: "B1", pct: 20, color: "#3B82F6" }, // blue
  { lvl: "B2", pct: 16, color: "#6366F1" }, // indigo
  { lvl: "C1", pct: 10, color: "#A855F7" }, // purple
  { lvl: "C2", pct: 6, color: "#EC4899" }, // pink
] as const;

export function WortschatzHero({
  bookmarksCount,
  customCount,
  leitnerCount,
}: {
  bookmarksCount: number;
  customCount: number;
  leitnerCount: number;
}) {
  const t = SECTION_THEME.dictionary;
  const active = bookmarksCount + customCount;
  const accent = "#2563EB"; // blue-forward
  const remaining = 100 - VOCAB_STATS.levelProgress;

  return (
    <section className="neu-card relative overflow-hidden p-4 sm:p-6">
      {/* Left accent stripe — matches SectionShell */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-y-6 left-0 w-1 rounded-r-full"
        style={{ background: `linear-gradient(180deg, ${accent}, ${accent}55)` }}
      />
      {/* Soft accent glow in the top-right */}
      <span
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-30 blur-3xl"
        style={{ background: `radial-gradient(circle, ${accent}80, transparent 70%)` }}
      />

      {/* Header — mirrors SectionShell layout */}
      <header className="relative mb-5 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-xl shadow-sm ring-1"
            style={{
              background: `linear-gradient(135deg, ${accent}22, ${accent}0d)`,
              color: accent,
              boxShadow: `0 6px 18px -8px ${accent}80`,
              // @ts-expect-error CSS custom prop
              "--tw-ring-color": `${accent}40`,
            }}
          >
            <span aria-hidden>📊</span>
          </span>
          <div className="min-w-0">
            <div className="mb-0.5 flex items-center gap-1.5">
              <span
                className="rounded-full px-1.5 py-px text-[9px] font-black tracking-widest"
                style={{ background: `${accent}1a`, color: accent }}
              >
                02
              </span>
              <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                Abschnitt
              </span>
            </div>
            <h2 className="truncate text-base font-black tracking-tight sm:text-lg">
              Dein Wortschatz
            </h2>
            <p className="mt-0.5 truncate text-[11px] text-muted-foreground sm:text-xs">
              Fortschritt, Niveau und Verteilung deiner Wörter
            </p>
          </div>
        </div>
        <div
          className="flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold tracking-wide"
          style={{
            background: `${accent}0d`,
            borderColor: `${accent}33`,
            color: accent,
          }}
        >
          <span
            aria-hidden
            className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.7)]"
          />
          <span className="tabular-nums">{VOCAB_STATS.streak}</span>
          <span className="text-muted-foreground">Tage-Serie</span>
        </div>
      </header>

      {/* Level + active words summary */}
      <div className="relative grid gap-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
        <div className="min-w-0">
          <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
            Aktiver Wortschatz
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span
              className="text-4xl font-black leading-none tracking-tight tabular-nums sm:text-5xl"
              style={{ color: accent }}
            >
              {active.toLocaleString("de")}
            </span>
            <span className="text-sm font-medium text-muted-foreground">Wörter</span>
          </div>
          <p className="mt-2 text-xs leading-snug text-muted-foreground">
            Noch <span className="font-bold text-foreground tabular-nums">{remaining}%</span> bis
            zum nächsten Niveau.
          </p>
        </div>

        {/* Level ring */}
        <div className="relative grid h-24 w-24 shrink-0 place-items-center sm:h-28 sm:w-28">
          <svg viewBox="0 0 40 40" className="absolute inset-0 -rotate-90">
            <defs>
              <linearGradient id="wsRing" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#60A5FA" />
                <stop offset="100%" stopColor="#2563EB" />
              </linearGradient>
            </defs>
            <circle
              cx="20"
              cy="20"
              r="17"
              fill="none"
              stroke="currentColor"
              className="text-muted"
              strokeWidth="2.6"
            />
            <circle
              cx="20"
              cy="20"
              r="17"
              fill="none"
              stroke="url(#wsRing)"
              strokeWidth="2.6"
              strokeDasharray={`${VOCAB_STATS.levelProgress}, 100`}
              pathLength={100}
              strokeLinecap="round"
            />
          </svg>
          <div className="text-center leading-none">
            <div className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
              Niveau
            </div>
            <div
              className="mt-1 text-2xl font-black tracking-tight sm:text-3xl"
              style={{ color: accent }}
            >
              {VOCAB_STATS.level}
            </div>
            <div className="mt-1 text-[10px] font-semibold tabular-nums text-muted-foreground">
              {VOCAB_STATS.levelProgress}%
            </div>
          </div>
        </div>
      </div>

      {/* Progress rail */}
      <div className="relative mt-5">
        <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          <span>Fortschritt</span>
          <span className="tabular-nums text-foreground">{VOCAB_STATS.levelProgress} / 100</span>
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full transition-[width] duration-700"
            style={{
              width: `${VOCAB_STATS.levelProgress}%`,
              background: "linear-gradient(90deg, #60A5FA 0%, #3B82F6 55%, #2563EB 100%)",
              boxShadow: "0 0 12px rgba(59,130,246,0.45)",
            }}
          />
        </div>
      </div>

      {/* ── Stat grid ── */}
      <div className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-3">
        <MiniStat icon="📚" label="Gesamt" value={VOCAB_STATS.total} accent={accent} />
        <MiniStat
          icon="✅"
          label="Bekannt"
          value={VOCAB_STATS.known}
          delta={VOCAB_STATS.knownDelta}
          accent="#10B981"
        />
        <MiniStat
          icon="📖"
          label="Am Lernen"
          value={VOCAB_STATS.learning}
          delta={VOCAB_STATS.learningDelta}
          accent="#F59E0B"
        />
        <MiniStat icon="🔖" label="Lesezeichen" value={bookmarksCount} accent={t.accent} />
        <MiniStat icon="🎴" label="Leitner" value={leitnerCount} accent="#059669" />
        <MiniStat icon="✨" label="Eigene" value={customCount} accent="#EC4899" />
      </div>

      {/* ── CEFR distribution — colorful per level ── */}
      <div className="mt-5 rounded-2xl border border-border/60 bg-card/60 p-3 sm:p-4">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
            Verteilung nach Niveau
          </div>
          <div
            className="rounded-full px-2 py-0.5 text-[10px] font-bold"
            style={{ background: `${accent}14`, color: accent }}
          >
            Ziel: B2
          </div>
        </div>
        <div className="flex h-3 w-full gap-[3px] overflow-hidden rounded-full bg-muted p-[2px]">
          {CEFR_SPLIT.map(({ lvl, pct, color }) => (
            <div
              key={lvl}
              title={`${lvl} · ${pct}%`}
              style={{
                width: `${pct}%`,
                background: color,
              }}
              className="rounded-full transition hover:brightness-110"
            />
          ))}
        </div>

        <div className="mt-3 grid grid-cols-3 gap-x-3 gap-y-1.5 sm:grid-cols-6">
          {CEFR_SPLIT.map(({ lvl, pct, color }) => (
            <div key={lvl} className="flex items-center gap-1.5">
              <span
                className="h-2.5 w-2.5 rounded-full ring-2"
                style={{
                  background: color,
                  // @ts-expect-error CSS custom prop
                  "--tw-ring-color": `${color}33`,
                }}
              />
              <span className="text-[11px] font-bold text-foreground">{lvl}</span>
              <span className="text-[10px] tabular-nums text-muted-foreground">{pct}%</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function TextbookVocabulary({ icon, accent }: { icon: string; accent: string }) {
  return (
    <SectionShell
      anchorId="sec-books"
      index={6}
      icon={icon}
      accent={accent}
      title="Wortschatz aus Lehrbüchern"
      subtitle="Wichtige Vokabeln pro Kursbuch"
      action={
        <Link
          to="/books"
          className="rounded-full border border-border/60 bg-card px-2.5 py-1 text-[10px] font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground"
        >
          Alle Bücher →
        </Link>
      }
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {LEARNING_BOOKS.map((b) => (
          <Link
            key={b.id}
            to="/books/$bookId"
            params={{ bookId: b.id }}
            className="group flex flex-col overflow-hidden rounded-2xl border border-border/70 bg-card text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg"
            aria-label={`${b.title} — Vokabeln öffnen`}
          >
            <div
              className="relative aspect-[3/4] w-full overflow-hidden"
              style={{ background: `linear-gradient(160deg, ${b.color}33, ${b.color}11)` }}
            >
              {b.coverUrl ? (
                <img
                  loading="lazy"
                  decoding="async"
                  src={b.coverUrl}
                  alt={b.title}
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
                />
              ) : (
                <div className="grid h-full w-full place-items-center text-5xl opacity-80">
                  {b.cover}
                </div>
              )}
              <span
                className="absolute left-2 top-2 rounded-md px-1.5 py-0.5 text-[10px] font-bold text-white shadow"
                style={{ background: b.color }}
              >
                {b.level}
              </span>
            </div>

            <div className="flex flex-col gap-0.5 p-3">
              <div className="truncate text-sm font-semibold">{b.title}</div>
              <div className="truncate text-[11px] text-muted-foreground">{b.publisher}</div>
              <div className="mt-1 text-[11px] font-medium" style={{ color: b.color }}>
                {b.wordCount} Wörter →
              </div>
            </div>
          </Link>
        ))}
      </div>
    </SectionShell>
  );
}

export function CategorySection({
  category,
  onCategoryChange,
  onPickCategory,
  getCategoryCount,
  icon,
  accent,
}: {
  category: string;
  onCategoryChange: (value: string) => void;
  onPickCategory: (value: string) => void;
  getCategoryCount: (value: string) => number;
  icon: string;
  accent: string;
}) {
  return (
    <SectionShell
      anchorId="sec-categories"
      index={7}
      icon={icon}
      accent={accent}
      title="Wortschatz nach Kategorien"
      subtitle={`Tippe eine Kategorie, um „Alle Wörter" zu filtern`}
      action={
        category !== "all" ? (
          <button
            onClick={() => onCategoryChange("all")}
            className="rounded-full border border-border/60 bg-card px-2.5 py-1 text-[10px] font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground"
          >
            Zurücksetzen
          </button>
        ) : (
          <span className="hidden text-[10px] text-muted-foreground sm:inline">
            Tippe zum Filtern ↓
          </span>
        )
      }
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
        {CATEGORIES.slice(0, 12).map((c) => {
          const active = category === c.id;
          return (
            <button
              key={c.id}
              onClick={() => onPickCategory(c.id)}
              title={c.label}
              className={`neu-card cat-glow relative flex min-w-0 flex-col items-center gap-2 overflow-hidden p-3 text-center transition sm:p-4 ${
                active ? "ring-2 -translate-y-0.5 shadow-lg" : ""
              }`}
              style={{
                ["--cat-rgb" as never]: hexToRgb(c.color),
                ...(active
                  ? { boxShadow: `0 12px 30px -12px ${c.color}66`, borderColor: c.color }
                  : {}),
              }}
            >
              <span className="cat-icon shrink-0 text-xl" style={{ background: c.color + "22" }}>
                {c.icon}
              </span>
              <div className="w-full min-w-0">
                <div className="line-clamp-2 hyphens-auto break-words text-[11px] font-semibold leading-snug sm:text-xs">
                  {c.label}
                </div>
                <div className="mt-0.5 truncate text-[10px] text-muted-foreground">
                  {getCategoryCount(c.id)} Wörter
                </div>
              </div>
              {active && (
                <span
                  className="absolute right-1.5 top-1.5 rounded-full px-1.5 py-0.5 text-[9px] font-bold text-white shadow"
                  style={{ background: c.color }}
                >
                  aktiv
                </span>
              )}
            </button>
          );
        })}
      </div>
    </SectionShell>
  );
}

export function DictionaryDetailPanel({
  word,
  isFavorite,
  inLeitner,
  isBookmarked,
  onClose,
  onToggleFavorite,
  onToggleLeitner,
  onToggleBookmark,
  onOpenWord,
}: {
  word: DictWord | null;
  isFavorite: (id: string) => boolean;
  inLeitner: (id: string) => boolean;
  isBookmarked: (id: string) => boolean;
  onClose: () => void;
  onToggleFavorite: () => void;
  onToggleLeitner: () => void;
  onToggleBookmark: () => void;
  onOpenWord: (id: string, event?: React.MouseEvent<HTMLElement>) => void;
}) {
  return (
    <div className="sticky top-5 hidden h-[calc(100vh-2.5rem)] self-start lg:block">
      <AnimatePresence mode="wait">
        {word ? (
          <WordDetailPanel
            word={word}
            favorite={isFavorite(word.id)}
            inLeitner={inLeitner(word.id)}
            bookmarked={isBookmarked(word.id)}
            onClose={() => onClose()}
            onToggleFavorite={() => onToggleFavorite()}
            onToggleLeitner={() => onToggleLeitner()}
            onToggleBookmark={() => onToggleBookmark()}
            onOpenWord={onOpenWord}
          />
        ) : (
          <motion.div
            key="placeholder"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="glass flex h-full flex-col items-center justify-center gap-4 rounded-3xl p-8 text-center"
          >
            <div className="text-6xl">📖</div>
            <div>
              <h3 className="text-lg font-semibold">Wähle ein Wort</h3>
              <Fa className="fa-hint-xs">یک واژه را انتخاب کن</Fa>
              <p className="mt-1 text-sm text-muted-foreground">
                Tippe auf ein Wort links, um Übersetzung, Grammatik, Beispiele und KI-Tipps zu
                sehen.
              </p>
              <Fa className="fa-hint-xs">
                روی هر واژه بزنید تا ترجمه، گرامر، مثال‌ها و راهنمای هوشمند را ببینید.
              </Fa>
            </div>
            <div className="mt-2 flex flex-wrap justify-center gap-1.5">
              {FEATURED_WORDS.slice(0, 5).map((w) => (
                <button
                  key={w.id}
                  onClick={(event) => onOpenWord(w.id, event)}
                  className="rounded-full bg-card px-3 py-1 text-xs font-medium shadow-sm hover:bg-muted"
                >
                  {w.headword}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
