import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import type { KeyboardEvent, MouseEvent } from "react";
import {
  BookmarkCheck,
  CheckSquare,
  Heart,
  LayoutGrid,
  Layers,
  List,
  PenLine,
  Plus,
  Rows3,
  Search,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import type { CEFR, DictPos, DictWord } from "@/lib/deusi/dictionary/types";
import { WordCard } from "./WordCard";
import { AddWordModal } from "./AddWordModal";
import { useCustomWords, type NewWordInput } from "@/lib/deusi/dictionary/customWords";
import { useInteractions } from "@/lib/deusi/interactions";

type OpenEvent = MouseEvent<HTMLElement> | KeyboardEvent<HTMLElement>;
type Tab = "all" | "own" | "bookmarks" | "favorites";
type ViewMode = "grid" | "list" | "compact";
type SortKey = "recent" | "az" | "za" | "level" | "pos";

const TABS: { id: Tab; label: string; fa: string; Icon: typeof Heart }[] = [
  { id: "all", label: "Alle", fa: "همه", Icon: Layers },
  { id: "own", label: "Eigene", fa: "خودم", Icon: PenLine },
  { id: "bookmarks", label: "Lesezeichen", fa: "نشان‌ها", Icon: BookmarkCheck },
  { id: "favorites", label: "Favoriten", fa: "علاقه‌مندی", Icon: Heart },
];

const LEVELS: CEFR[] = ["A1", "A2", "B1", "B2", "C1", "C2"];
const POS_LABEL: Record<DictPos, string> = {
  noun: "Nomen",
  verb: "Verb",
  adjective: "Adjektiv",
  adverb: "Adverb",
  preposition: "Präposition",
  conjunction: "Konjunktion",
  pronoun: "Pronomen",
};
const SORTS: { id: SortKey; label: string }[] = [
  { id: "recent", label: "Zuletzt hinzugefügt" },
  { id: "az", label: "A → Z" },
  { id: "za", label: "Z → A" },
  { id: "level", label: "Niveau" },
  { id: "pos", label: "Wortart" },
];

const LEVEL_ORDER: Record<string, number> = { A1: 1, A2: 2, B1: 3, B2: 4, C1: 5, C2: 6 };
const PAGE_SIZE = 12;

interface Props {
  masterWords: DictWord[];
  onOpen: (id: string, event?: OpenEvent) => void;
  bookmarks: (id: string) => boolean;
  onToggleBookmark: (id: string) => void;
  inLeitner?: (id: string) => boolean;
  onToggleLeitner?: (id: string, label?: string) => void;
  progress?: Record<string, number>;
}

export function MyWordsWorkspace({
  masterWords,
  onOpen,
  bookmarks,
  onToggleBookmark,
  inLeitner,
  onToggleLeitner,
  progress = {},
}: Props) {
  const [tab, setTab] = useState<Tab>("all");
  const [view, setView] = useState<ViewMode>("grid");
  const [sort, setSort] = useState<SortKey>("recent");
  const [query, setQuery] = useState("");
  const [levels, setLevels] = useState<CEFR[]>([]);
  const [posFilter, setPosFilter] = useState<DictPos[]>([]);
  const [grouped, setGrouped] = useState(false);
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [visible, setVisible] = useState(PAGE_SIZE);
  const [modalOpen, setModalOpen] = useState(false);

  const { words: customWords, add, remove } = useCustomWords();
  const { bookmarks: bmState, favorites: fvState } = useInteractions();

  const wordById = useMemo(() => {
    const map = new Map<string, DictWord>();
    for (const w of masterWords) map.set(w.id, w);
    for (const w of customWords) map.set(w.id, w);
    return map;
  }, [masterWords, customWords]);

  const addedAt = useMemo(() => {
    const map = new Map<string, number>();
    customWords.forEach((w, i) => map.set(w.id, 1_000_000_000 + i));
    for (const list of [bmState.word ?? [], fvState.word ?? []]) {
      for (const e of list) {
        const t = Date.parse(e.at) || 0;
        map.set(e.id, Math.max(map.get(e.id) ?? 0, t));
      }
    }
    return map;
  }, [customWords, bmState.word, fvState.word]);

  const bookmarkWords = useMemo(
    () => (bmState.word ?? []).map((e) => wordById.get(e.id)).filter(Boolean) as DictWord[],
    [bmState.word, wordById],
  );
  const favoriteWords = useMemo(
    () => (fvState.word ?? []).map((e) => wordById.get(e.id)).filter(Boolean) as DictWord[],
    [fvState.word, wordById],
  );

  const allWords = useMemo(() => {
    const seen = new Set<string>();
    const out: DictWord[] = [];
    for (const w of [...customWords, ...favoriteWords, ...bookmarkWords]) {
      if (!seen.has(w.id)) {
        seen.add(w.id);
        out.push(w);
      }
    }
    return out;
  }, [customWords, favoriteWords, bookmarkWords]);

  const base =
    tab === "own"
      ? customWords
      : tab === "bookmarks"
        ? bookmarkWords
        : tab === "favorites"
          ? favoriteWords
          : allWords;

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    let out = base.filter((w) => {
      if (levels.length && !levels.includes(w.cefr)) return false;
      if (posFilter.length && !posFilter.includes(w.pos)) return false;
      if (!q) return true;
      return (
        w.headword.toLowerCase().includes(q) ||
        w.lemma?.toLowerCase().includes(q) ||
        w.shortMeaning?.toLowerCase().includes(q) ||
        w.meanings?.some(
          (m) =>
            m.fa?.toLowerCase().includes(q) ||
            m.en?.toLowerCase().includes(q) ||
            m.de?.toLowerCase().includes(q),
        )
      );
    });
    out = [...out].sort((a, b) => {
      switch (sort) {
        case "az":
          return a.headword.localeCompare(b.headword, "de");
        case "za":
          return b.headword.localeCompare(a.headword, "de");
        case "level":
          return (LEVEL_ORDER[a.cefr] ?? 9) - (LEVEL_ORDER[b.cefr] ?? 9);
        case "pos":
          return a.pos.localeCompare(b.pos) || a.headword.localeCompare(b.headword, "de");
        default:
          return (addedAt.get(b.id) ?? 0) - (addedAt.get(a.id) ?? 0);
      }
    });
    return out;
  }, [base, query, levels, posFilter, sort, addedAt]);

  useEffect(() => {
    setVisible(PAGE_SIZE);
  }, [tab, query, levels, posFilter, sort]);

  const shown = list.slice(0, visible);
  const isCustom = (id: string) => customWords.some((w) => w.id === id);
  const leitnerCount = allWords.filter((w) => inLeitner?.(w.id)).length;
  const activeFilters = levels.length + posFilter.length + (query.trim() ? 1 : 0);

  const toggleSelect = (id: string) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const groups = useMemo(() => {
    if (!grouped) return null;
    const map = new Map<string, DictWord[]>();
    for (const w of shown) {
      const key = (w.headword[0] ?? "#").toUpperCase();
      map.set(key, [...(map.get(key) ?? []), w]);
    }
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0], "de"));
  }, [grouped, shown]);

  const handleAdd = (input: NewWordInput) => {
    add(input);
    setTab("own");
    setQuery("");
    setVisible(PAGE_SIZE);
  };

  const renderCard = (w: DictWord) => (
    <motion.div
      key={w.id}
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="relative min-w-0"
    >
      {view === "compact" ? (
        <button
          onClick={(e) => (selectMode ? toggleSelect(w.id) : onOpen(w.id, e))}
          className={`flex w-full min-w-0 items-center gap-2 rounded-2xl border bg-card px-3 py-2.5 text-left shadow-sm transition hover:border-primary/40 hover:shadow-md ${
            selected.includes(w.id) ? "border-primary ring-2 ring-primary/30" : "border-border/70"
          }`}
        >
          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-muted text-[10px] font-black uppercase text-muted-foreground">
            {w.cefr}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-bold">{w.headword}</span>
            <span dir="rtl" className="fa-inline block truncate text-[11px] text-muted-foreground">
              {w.meanings?.[0]?.fa ?? w.meanings?.[0]?.en ?? POS_LABEL[w.pos]}
            </span>
          </span>
        </button>
      ) : (
        <WordCard
          word={w}
          variant={view === "list" ? "row" : "grid"}
          progress={progress[w.id] ?? Math.min(80, w.frequency)}
          bookmarked={bookmarks(w.id)}
          inLeitner={inLeitner?.(w.id)}
          onOpen={(event) => (selectMode ? toggleSelect(w.id) : onOpen(w.id, event))}
          onToggleBookmark={() => onToggleBookmark(w.id)}
          onToggleLeitner={onToggleLeitner ? () => onToggleLeitner(w.id, w.headword) : undefined}
        />
      )}

      {isCustom(w.id) && view !== "compact" && (
        <span className="pointer-events-none absolute -top-1.5 left-3 z-10 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white shadow">
          Eigen
        </span>
      )}

      {selectMode && (
        <button
          onClick={() => toggleSelect(w.id)}
          aria-label="Auswählen"
          className={`absolute right-2 top-2 z-20 grid h-7 w-7 place-items-center rounded-full border-2 transition ${
            selected.includes(w.id)
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border bg-card/90 text-transparent"
          }`}
        >
          <CheckSquare className="h-3.5 w-3.5" />
        </button>
      )}
    </motion.div>
  );

  return (
    <section className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        <StatCard
          label="Gesamt"
          fa="کل واژه‌ها"
          value={allWords.length}
          Icon={Layers}
          tone="#8B5CF6"
        />
        <StatCard
          label="Eigene"
          fa="ساختهٔ من"
          value={customWords.length}
          Icon={PenLine}
          tone="#EC4899"
        />
        <StatCard
          label="Lesezeichen"
          fa="نشان‌شده"
          value={bookmarkWords.length}
          Icon={BookmarkCheck}
          tone="#0EA5E9"
        />
        <StatCard
          label="Im Leitner"
          fa="در لایتنر"
          value={leitnerCount}
          Icon={Sparkles}
          tone="#22C55E"
        />
      </div>

      {/* Toolbar */}
      <div className="space-y-3 rounded-3xl border border-border/70 bg-card p-3 shadow-sm sm:p-4">
        <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
          <div className="relative min-w-0">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Wort, Bedeutung oder معنی فارسی suchen…"
              className="h-11 w-full rounded-2xl border border-border/70 bg-background pl-9 pr-9 text-sm outline-none transition focus:border-primary/60 focus:ring-2 focus:ring-primary/20"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                aria-label="Suche leeren"
                className="absolute right-2 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-muted-foreground hover:bg-muted"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="inline-flex h-11 items-center justify-center gap-1.5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 px-4 text-sm font-semibold text-white shadow-md transition hover:shadow-lg active:scale-95"
          >
            <Plus className="h-4 w-4" /> Neues Wort
          </button>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-2 gap-1.5 rounded-2xl bg-muted/60 p-1 sm:grid-cols-4">
          {TABS.map((t) => {
            const count =
              t.id === "own"
                ? customWords.length
                : t.id === "bookmarks"
                  ? bookmarkWords.length
                  : t.id === "favorites"
                    ? favoriteWords.length
                    : allWords.length;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex min-w-0 items-center justify-center gap-1.5 rounded-xl px-2 py-2 text-[11px] font-semibold transition sm:text-xs ${
                  active
                    ? "bg-card text-foreground shadow-sm ring-1 ring-border/70"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <t.Icon className="h-3.5 w-3.5 shrink-0" />
                <span className="truncate">{t.label}</span>
                <span
                  className={`shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                    active ? "bg-primary/10 text-primary" : "bg-background text-muted-foreground"
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* View + sort */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 rounded-2xl border border-border/70 bg-background p-1">
            {(
              [
                { id: "grid", Icon: LayoutGrid, label: "Raster" },
                { id: "list", Icon: List, label: "Liste" },
                { id: "compact", Icon: Rows3, label: "Kompakt" },
              ] as const
            ).map((v) => (
              <button
                key={v.id}
                onClick={() => setView(v.id)}
                title={v.label}
                aria-label={v.label}
                aria-pressed={view === v.id}
                className={`grid h-8 w-8 place-items-center rounded-xl transition ${
                  view === v.id
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-muted"
                }`}
              >
                <v.Icon className="h-4 w-4" />
              </button>
            ))}
          </div>

          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="h-10 min-w-0 flex-1 rounded-2xl border border-border/70 bg-background px-3 text-xs font-semibold outline-none focus:border-primary/60 sm:flex-none"
          >
            {SORTS.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>

          <button
            onClick={() => setGrouped((g) => !g)}
            className={`h-10 rounded-2xl border px-3 text-xs font-semibold transition ${
              grouped
                ? "border-primary/50 bg-primary/10 text-primary"
                : "border-border/70 bg-background text-muted-foreground hover:text-foreground"
            }`}
          >
            A–Z Gruppen
          </button>

          <button
            onClick={() => {
              setSelectMode((s) => !s);
              setSelected([]);
            }}
            className={`h-10 rounded-2xl border px-3 text-xs font-semibold transition ${
              selectMode
                ? "border-primary/50 bg-primary/10 text-primary"
                : "border-border/70 bg-background text-muted-foreground hover:text-foreground"
            }`}
          >
            {selectMode ? "Fertig" : "Auswählen"}
          </button>
        </div>

        {/* Filter chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          {LEVELS.map((l) => {
            const active = levels.includes(l);
            return (
              <button
                key={l}
                onClick={() =>
                  setLevels((s) => (s.includes(l) ? s.filter((x) => x !== l) : [...s, l]))
                }
                className={`rounded-full border px-2.5 py-1 text-[11px] font-bold transition ${
                  active
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border/70 bg-background text-muted-foreground hover:text-foreground"
                }`}
              >
                {l}
              </button>
            );
          })}
          <span aria-hidden className="mx-1 hidden h-4 w-px bg-border sm:block" />
          {(Object.keys(POS_LABEL) as DictPos[]).map((p) => {
            const active = posFilter.includes(p);
            return (
              <button
                key={p}
                onClick={() =>
                  setPosFilter((s) => (s.includes(p) ? s.filter((x) => x !== p) : [...s, p]))
                }
                className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold transition ${
                  active
                    ? "border-foreground bg-foreground text-background"
                    : "border-border/70 bg-background text-muted-foreground hover:text-foreground"
                }`}
              >
                {POS_LABEL[p]}
              </button>
            );
          })}
          {activeFilters > 0 && (
            <button
              onClick={() => {
                setLevels([]);
                setPosFilter([]);
                setQuery("");
              }}
              className="inline-flex items-center gap-1 rounded-full bg-destructive/10 px-2.5 py-1 text-[11px] font-bold text-destructive"
            >
              <X className="h-3 w-3" /> Filter zurücksetzen
            </button>
          )}
        </div>
      </div>

      {/* Bulk bar */}
      <AnimatePresence>
        {selectMode && selected.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="flex flex-wrap items-center gap-2 rounded-2xl border border-primary/40 bg-primary/5 p-3"
          >
            <span className="text-xs font-bold text-primary">{selected.length} ausgewählt</span>
            <div className="ms-auto flex flex-wrap gap-2">
              {onToggleLeitner && (
                <button
                  onClick={() => {
                    selected.forEach((id) => {
                      if (!inLeitner?.(id)) onToggleLeitner(id, wordById.get(id)?.headword);
                    });
                    setSelected([]);
                  }}
                  className="rounded-xl bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
                >
                  Zu Leitner
                </button>
              )}
              <button
                onClick={() => {
                  selected.forEach((id) => {
                    if (!bookmarks(id)) onToggleBookmark(id);
                  });
                  setSelected([]);
                }}
                className="rounded-xl border border-border bg-card px-3 py-1.5 text-xs font-semibold"
              >
                Lesezeichen
              </button>
              <button
                onClick={() => {
                  const own = selected.filter(isCustom);
                  if (own.length && confirm(`${own.length} eigene Wörter löschen?`)) {
                    own.forEach(remove);
                  }
                  setSelected([]);
                }}
                className="inline-flex items-center gap-1 rounded-xl bg-destructive/10 px-3 py-1.5 text-xs font-semibold text-destructive"
              >
                <Trash2 className="h-3.5 w-3.5" /> Eigene löschen
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results */}
      {list.length === 0 ? (
        <EmptyState tab={tab} filtered={activeFilters > 0} onAdd={() => setModalOpen(true)} />
      ) : (
        <div className="space-y-5">
          {groups ? (
            groups.map(([letter, items]) => (
              <div key={letter} className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-primary/10 text-xs font-black text-primary">
                    {letter}
                  </span>
                  <span className="h-px flex-1 bg-border" />
                  <span className="text-[11px] font-semibold text-muted-foreground">
                    {items.length}
                  </span>
                </div>
                <div className={gridClass(view)}>
                  <AnimatePresence initial={false}>{items.map(renderCard)}</AnimatePresence>
                </div>
              </div>
            ))
          ) : (
            <div className={gridClass(view)}>
              <AnimatePresence initial={false}>{shown.map(renderCard)}</AnimatePresence>
            </div>
          )}

          {visible < list.length && (
            <div className="flex flex-col items-center gap-2">
              <div className="text-xs text-muted-foreground">
                {shown.length} von {list.length}
              </div>
              <button
                onClick={() => setVisible((v) => v + PAGE_SIZE)}
                className="rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:shadow-lg active:scale-[0.98]"
              >
                Weitere laden
              </button>
            </div>
          )}
        </div>
      )}

      <AddWordModal open={modalOpen} onClose={() => setModalOpen(false)} onSubmit={handleAdd} />
    </section>
  );
}

function gridClass(view: ViewMode) {
  if (view === "list") return "grid grid-cols-1 gap-2.5";
  if (view === "compact")
    return "grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4";
  return "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4";
}

function StatCard({
  label,
  fa,
  value,
  Icon,
  tone,
}: {
  label: string;
  fa: string;
  value: number;
  Icon: typeof Heart;
  tone: string;
}) {
  return (
    <div className="flex min-w-0 items-center gap-2.5 rounded-2xl border border-border/70 bg-card p-3 shadow-sm">
      <span
        className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
        style={{ background: `linear-gradient(135deg, ${tone}, ${tone}aa)` }}
      >
        <Icon className="h-4 w-4" />
      </span>
      <div className="min-w-0">
        <div className="text-lg font-black leading-none">{value}</div>
        <div className="truncate text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          {label}
        </div>
        <div dir="rtl" className="fa-inline truncate text-[10px] text-muted-foreground/80">
          {fa}
        </div>
      </div>
    </div>
  );
}

function EmptyState({ tab, filtered, onAdd }: { tab: Tab; filtered: boolean; onAdd: () => void }) {
  if (filtered) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-3xl border-2 border-dashed border-border/60 bg-muted/30 px-6 py-12 text-center">
        <div className="text-4xl">🔍</div>
        <h3 className="text-sm font-bold">Keine Treffer</h3>
        <p className="max-w-sm text-xs text-muted-foreground">
          Passe Suche oder Filter an, um mehr Wörter zu sehen.
        </p>
      </div>
    );
  }
  const copy: Record<Tab, { icon: string; title: string; desc: string; cta?: string }> = {
    all: {
      icon: "🌱",
      title: "Deine Sammlung ist noch leer",
      desc: "Speichere Wörter, markiere Favoriten oder erstelle eigene Einträge.",
      cta: "Erstes Wort hinzufügen",
    },
    own: {
      icon: "✍️",
      title: "Noch keine eigenen Wörter",
      desc: "Erstelle dein erstes persönliches Wort mit vollständiger Grammatik.",
      cta: "Wort erstellen",
    },
    bookmarks: {
      icon: "🔖",
      title: "Keine Lesezeichen",
      desc: "Tippe auf das Lesezeichen-Symbol eines Wortes, um es hier zu speichern.",
    },
    favorites: {
      icon: "❤️",
      title: "Keine Favoriten",
      desc: "Tippe auf das Herz in der Detailansicht, um Favoriten zu sammeln.",
    },
  };
  const c = copy[tab];
  return (
    <div className="flex flex-col items-center gap-3 rounded-3xl border-2 border-dashed border-border/60 bg-muted/30 px-6 py-12 text-center">
      <div className="text-5xl">{c.icon}</div>
      <div>
        <h3 className="text-sm font-bold">{c.title}</h3>
        <p className="mt-1 max-w-sm text-xs text-muted-foreground">{c.desc}</p>
      </div>
      {c.cta && (
        <button
          onClick={onAdd}
          className="mt-1 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-2 text-xs font-semibold text-white shadow-md transition hover:shadow-lg"
        >
          {c.cta}
        </button>
      )}
    </div>
  );
}
