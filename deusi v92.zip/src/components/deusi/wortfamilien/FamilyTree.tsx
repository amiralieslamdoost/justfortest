import { motion } from "@/lib/motion-lite";
import { MorphemeBreakdown } from "./MorphemeBreakdown";
import {
  POS_COLOR,
  POS_LABEL,
  type FamilyMember,
  type WordRoot,
} from "@/lib/deusi/wordfamilies/types";

type Props = {
  root: WordRoot;
  members: FamilyMember[];
  selectedId: string | null;
  onSelect: (member: FamilyMember) => void;
};

/**
 * Derivation tree: root on the left, every derived word as a branch, grouped
 * by word class — better for *reading* how the word is built.
 */
export function FamilyTree({ root, members, selectedId, onSelect }: Props) {
  const groups = (["verb", "noun", "adjective", "adverb"] as const)
    .map((pos) => ({ pos, list: members.filter((m) => m.pos === pos) }))
    .filter((g) => g.list.length > 0);

  return (
    <div className="rounded-3xl border border-border/60 bg-card p-4 sm:p-5">
      <div className="mb-4 flex items-center gap-3">
        <div
          className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-sm font-black text-white"
          style={{ background: "var(--section-primary)" }}
        >
          {root.root}-
        </div>
        <div className="min-w-0">
          <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            Wortstamm
          </div>
          <div className="truncate text-lg font-black">{root.label}</div>
          <div className="truncate text-xs text-muted-foreground" dir="rtl">
            {root.meaningFa}
          </div>
        </div>
      </div>

      <div className="space-y-5">
        {groups.map((g) => (
          <div key={g.pos} className="relative pl-4">
            <span
              aria-hidden
              className="absolute left-0 top-2 bottom-2 w-[3px] rounded-full"
              style={{ background: POS_COLOR[g.pos], opacity: 0.55 }}
            />
            <div
              className="mb-2 flex items-center gap-2 text-xs font-bold"
              style={{ color: POS_COLOR[g.pos] }}
            >
              {POS_LABEL[g.pos].de}
              <span className="text-muted-foreground" dir="rtl">
                {POS_LABEL[g.pos].fa}
              </span>
              <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">
                {g.list.length}
              </span>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              {g.list.map((m, i) => {
                const active = selectedId === m.id;
                return (
                  <motion.button
                    key={m.id}
                    type="button"
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.03 * i }}
                    onClick={() => onSelect(m)}
                    className={`rounded-2xl border p-3 text-left transition ${
                      active
                        ? "border-[color:var(--section-accent)] bg-secondary"
                        : "border-border/60 bg-card hover:bg-secondary"
                    }`}
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-sm font-bold">
                        {m.article ? (
                          <span className="text-muted-foreground">{m.article} </span>
                        ) : null}
                        {m.word}
                      </span>
                      <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[9px] font-bold">
                        {m.cefr}
                      </span>
                    </div>
                    <div className="mt-1.5">
                      <MorphemeBreakdown member={m} size="sm" />
                    </div>
                    <div className="mt-1.5 text-xs text-muted-foreground">{m.meaningDe}</div>
                    <div className="text-xs text-muted-foreground" dir="rtl">
                      {m.meaningFa}
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
