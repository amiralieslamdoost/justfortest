import { motion, AnimatePresence } from "@/lib/motion-lite";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

interface Props {
  waveform: number[];
  durationSec: number;
  accent?: string;
  /** increment `seekNonce` to force a jump to `seekTo` */
  seekTo?: number;
  seekNonce?: number;
  onTimeUpdate?: (sec: number) => void;
  /** when set, playback loops inside this range (line repeat) */
  loopRange?: { start: number; end: number } | null;
  compact?: boolean;
}

/**
 * Polished mock music player.
 * - Animated, interactive waveform with hover-scrub + drag
 * - Play / seek ±5s / shuffle / repeat / speed / volume+mute
 * - Keyboard shortcuts: Space, ←/→, M
 * - Fully responsive: stacks gracefully on narrow screens
 * - Purely presentational (no real <audio>) — drives karaoke lyrics
 */
export function MusicPlayer({
  waveform,
  durationSec,
  accent = "#ff5ecb",
  seekTo = 0,
  seekNonce = 0,
  onTimeUpdate,
  loopRange = null,
  compact = false,
}: Props) {
  const [playing, setPlaying] = useState(false);
  const [rate, setRate] = useState(1);
  const [pos, setPos] = useState(seekTo);
  const [volume, setVolume] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [hoverP, setHoverP] = useState<number | null>(null);
  const [dragging, setDragging] = useState(false);

  const barRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number | null>(null);
  const lastTsRef = useRef<number | null>(null);
  const loopRef = useRef(loopRange);
  loopRef.current = loopRange;
  const repeatRef = useRef(repeat);
  repeatRef.current = repeat;

  useEffect(() => {
    setPos(seekTo);
    onTimeUpdate?.(seekTo);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seekNonce]);

  useEffect(() => {
    if (!playing) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      lastTsRef.current = null;
      return;
    }
    const tick = (ts: number) => {
      if (lastTsRef.current == null) lastTsRef.current = ts;
      const dt = (ts - lastTsRef.current) / 1000;
      lastTsRef.current = ts;
      setPos((p) => {
        let next = p + dt * rate;
        const loop = loopRef.current;
        if (loop && next >= loop.end) next = loop.start;
        if (next >= durationSec) {
          if (repeatRef.current) {
            next = 0;
          } else {
            next = durationSec;
            setPlaying(false);
          }
        }
        onTimeUpdate?.(next);
        return next;
      });
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [playing, rate, durationSec, onTimeUpdate]);

  const progress = Math.max(0, Math.min(1, pos / durationSec));

  const jump = useCallback(
    (delta: number) => {
      setPos((p) => {
        const next = Math.max(0, Math.min(durationSec, p + delta));
        onTimeUpdate?.(next);
        return next;
      });
    },
    [durationSec, onTimeUpdate],
  );

  const seekToPct = useCallback(
    (p: number) => {
      const s = Math.max(0, Math.min(1, p)) * durationSec;
      setPos(s);
      onTimeUpdate?.(s);
    },
    [durationSec, onTimeUpdate],
  );

  // Keyboard shortcuts — ignore while typing in inputs
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
      if (e.code === "Space") {
        e.preventDefault();
        setPlaying((v) => !v);
      } else if (e.code === "ArrowLeft") {
        e.preventDefault();
        jump(-5);
      } else if (e.code === "ArrowRight") {
        e.preventDefault();
        jump(5);
      } else if (e.key.toLowerCase() === "m") {
        setMuted((v) => !v);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [jump]);

  // Drag scrubbing
  useEffect(() => {
    if (!dragging) return;
    function onMove(e: PointerEvent) {
      if (!barRef.current) return;
      const rect = barRef.current.getBoundingClientRect();
      const p = (e.clientX - rect.left) / rect.width;
      setHoverP(Math.max(0, Math.min(1, p)));
      seekToPct(p);
    }
    function onUp() {
      setDragging(false);
      setHoverP(null);
    }
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [dragging, seekToPct]);

  const rates = [0.75, 1, 1.25, 1.5];

  const displayedWave = useMemo(() => waveform, [waveform]);
  const effectiveVolume = muted ? 0 : volume;

  return (
    <div className="relative w-full min-w-0" style={{ "--accent": accent } as React.CSSProperties}>
      <div className="flex w-full min-w-0 flex-col gap-3 sm:gap-4">
        {/* --- Main row: transport + waveform + time --- */}
        <div className="flex w-full min-w-0 items-center gap-3 sm:gap-4">
          {/* transport */}
          <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
            <IconBtn
              onClick={() => jump(-5)}
              aria-label="5 Sekunden zurück"
              title="−5s (←)"
              className="hidden sm:grid"
            >
              <svg
                viewBox="0 0 24 24"
                width="16"
                height="16"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M11 5 4 12l7 7" />
                <path d="M20 12H5" />
              </svg>
            </IconBtn>

            <motion.button
              type="button"
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.06 }}
              onClick={() => setPlaying((p) => !p)}
              aria-label={playing ? "Pause" : "Abspielen"}
              title={playing ? "Pause (Space)" : "Play (Space)"}
              className="relative grid shrink-0 place-items-center rounded-full text-white outline-none focus-visible:ring-2 focus-visible:ring-white/70"
              style={{
                background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 65%, #ffffff))`,
                width: compact ? 48 : 60,
                height: compact ? 48 : 60,
                boxShadow: `0 18px 40px -12px ${accent}, 0 0 0 1px color-mix(in oklab, ${accent} 60%, transparent) inset`,
              }}
            >
              {/* pulsing ring while playing */}
              {playing && (
                <motion.span
                  key="pulse"
                  animate={{ opacity: [0.55, 0], scale: [1, 1.55] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
                  className="pointer-events-none absolute inset-0 rounded-full"
                  style={{ background: accent }}
                  aria-hidden
                />
              )}

              <motion.span
                key={playing ? "pause" : "play"}
                initial={{ scale: 0.7, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 520, damping: 28 }}
                className="relative"
              >
                {playing ? (
                  <svg
                    viewBox="0 0 24 24"
                    width={compact ? 20 : 22}
                    height={compact ? 20 : 22}
                    fill="currentColor"
                  >
                    <rect x="6" y="5" width="4" height="14" rx="1.2" />
                    <rect x="14" y="5" width="4" height="14" rx="1.2" />
                  </svg>
                ) : (
                  <svg
                    viewBox="0 0 24 24"
                    width={compact ? 20 : 22}
                    height={compact ? 20 : 22}
                    fill="currentColor"
                  >
                    <path d="M8 5v14l11-7z" />
                  </svg>
                )}
              </motion.span>
            </motion.button>

            <IconBtn
              onClick={() => jump(5)}
              aria-label="5 Sekunden vor"
              title="+5s (→)"
              className="hidden sm:grid"
            >
              <svg
                viewBox="0 0 24 24"
                width="16"
                height="16"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m13 5 7 7-7 7" />
                <path d="M19 12H4" />
              </svg>
            </IconBtn>
          </div>

          {/* waveform */}
          <div className="min-w-0 flex-1">
            <div
              ref={barRef}
              role="slider"
              aria-label="Wiedergabeposition"
              aria-valuemin={0}
              aria-valuemax={Math.round(durationSec)}
              aria-valuenow={Math.round(pos)}
              tabIndex={0}
              onPointerDown={(e) => {
                e.preventDefault();
                (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
                setDragging(true);
                if (barRef.current) {
                  const rect = barRef.current.getBoundingClientRect();
                  const p = (e.clientX - rect.left) / rect.width;
                  setHoverP(Math.max(0, Math.min(1, p)));
                  seekToPct(p);
                }
              }}
              onPointerMove={(e) => {
                if (!barRef.current) return;
                const rect = barRef.current.getBoundingClientRect();
                setHoverP(Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)));
              }}
              onPointerLeave={() => {
                if (!dragging) setHoverP(null);
              }}
              className="group relative flex h-9 cursor-pointer items-center gap-[2px] select-none touch-none sm:h-10"
            >
              {displayedWave.map((v, i) => {
                const barP = (i + 0.5) / displayedWave.length;
                const active = barP <= progress;
                const inHover = hoverP != null && barP > progress && barP <= hoverP;
                const h = Math.max(18, v * 100);
                const distanceToHead = Math.abs(barP - progress);
                const dance = playing && distanceToHead < 0.02 ? 1.2 : 1;
                return (
                  <motion.div
                    key={i}
                    className="flex-1 rounded-full"
                    animate={{ scaleY: dance }}
                    transition={{ duration: 0.25 }}
                    style={{
                      height: `${h}%`,
                      transformOrigin: "center",
                      background: active
                        ? accent
                        : inHover
                          ? `color-mix(in oklab, ${accent} 40%, transparent)`
                          : "color-mix(in oklab, currentColor 18%, transparent)",
                    }}
                  />
                );
              })}

              {/* playhead */}
              <div
                aria-hidden
                className="pointer-events-none absolute top-1/2 -translate-y-1/2"
                style={{ left: `calc(${progress * 100}% - 5px)` }}
              >
                <div
                  className="h-4 w-2.5 rounded-full sm:h-5"
                  style={{
                    background: accent,
                    boxShadow: `0 0 0 3px color-mix(in oklab, ${accent} 18%, transparent)`,
                  }}
                />
              </div>

              {/* hover time tooltip */}
              <AnimatePresence>
                {hoverP != null && (
                  <motion.div
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 4 }}
                    className="pointer-events-none absolute -top-8 rounded-md bg-foreground px-1.5 py-0.5 text-[10px] font-bold tabular-nums text-background shadow-lg"
                    style={{ left: `calc(${hoverP * 100}% - 22px)` }}
                  >
                    {fmtTime(hoverP * durationSec)}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* loop range overlay */}
              {loopRange && (
                <div
                  aria-hidden
                  className="pointer-events-none absolute inset-y-0 rounded-md"
                  style={{
                    left: `${(loopRange.start / durationSec) * 100}%`,
                    width: `${((loopRange.end - loopRange.start) / durationSec) * 100}%`,
                    background: `color-mix(in oklab, ${accent} 15%, transparent)`,
                    border: `1px dashed color-mix(in oklab, ${accent} 60%, transparent)`,
                  }}
                />
              )}
            </div>
          </div>

          {/* time — desktop */}
          <div className="hidden shrink-0 items-center gap-2 text-xs tabular-nums text-muted-foreground sm:flex">
            <span className="font-black text-foreground">{fmtTime(pos)}</span>
            <span className="opacity-40">/</span>
            <span>{fmtTime(durationSec)}</span>
          </div>
        </div>

        {/* --- Secondary controls row --- */}
        <div className="flex w-full min-w-0 flex-wrap items-center justify-between gap-3">
          {/* time on mobile + mobile transport */}
          <div className="flex items-center gap-2 text-xs tabular-nums text-muted-foreground sm:hidden">
            <span className="font-black text-foreground">{fmtTime(pos)}</span>
            <span className="opacity-40">/</span>
            <span>{fmtTime(durationSec)}</span>
          </div>
          <div className="flex items-center gap-1.5 sm:hidden">
            <IconBtn onClick={() => jump(-5)} aria-label="−5s">
              <svg
                viewBox="0 0 24 24"
                width="14"
                height="14"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M11 5 4 12l7 7" />
                <path d="M20 12H5" />
              </svg>
            </IconBtn>
            <IconBtn onClick={() => jump(5)} aria-label="+5s">
              <svg
                viewBox="0 0 24 24"
                width="14"
                height="14"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m13 5 7 7-7 7" />
                <path d="M19 12H4" />
              </svg>
            </IconBtn>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <ToggleBtn
              on={shuffle}
              onClick={() => setShuffle((v) => !v)}
              accent={accent}
              aria-label="Zufall"
              title="Shuffle"
            >
              <svg
                viewBox="0 0 24 24"
                width="15"
                height="15"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M16 3h5v5" />
                <path d="M4 20 21 3" />
                <path d="M21 16v5h-5" />
                <path d="m15 15 6 6" />
                <path d="M4 4l5 5" />
              </svg>
            </ToggleBtn>
            <ToggleBtn
              on={repeat}
              onClick={() => setRepeat((v) => !v)}
              accent={accent}
              aria-label="Wiederholen"
              title="Repeat"
            >
              <svg
                viewBox="0 0 24 24"
                width="15"
                height="15"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m17 2 4 4-4 4" />
                <path d="M3 11v-1a4 4 0 0 1 4-4h14" />
                <path d="m7 22-4-4 4-4" />
                <path d="M21 13v1a4 4 0 0 1-4 4H3" />
              </svg>
            </ToggleBtn>

            {/* volume cluster */}
            <div className="ml-1 flex items-center gap-1.5 rounded-full border border-border bg-card px-1.5 py-1">
              <button
                type="button"
                onClick={() => setMuted((m) => !m)}
                aria-label={muted ? "Ton an" : "Ton aus"}
                title="Mute (M)"
                className="grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground"
              >
                <VolumeIcon v={effectiveVolume} />
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={effectiveVolume}
                onChange={(e) => {
                  setMuted(false);
                  setVolume(parseFloat(e.target.value));
                }}
                aria-label="Lautstärke"
                className="deusi-volume h-1 w-20 cursor-pointer appearance-none rounded-full sm:w-24"
                style={{
                  background: `linear-gradient(to right, ${accent} 0%, ${accent} ${effectiveVolume * 100}%, color-mix(in oklab, currentColor 15%, transparent) ${effectiveVolume * 100}%, color-mix(in oklab, currentColor 15%, transparent) 100%)`,
                }}
              />
            </div>

            {/* speed */}
            <button
              type="button"
              onClick={() => setRate((r) => rates[(rates.indexOf(r) + 1) % rates.length])}
              className="rounded-full border border-border bg-card px-2.5 py-1.5 text-[11px] font-black tabular-nums text-foreground transition hover:bg-secondary"
              aria-label="Wiedergabegeschwindigkeit"
              title="Speed"
            >
              {rate}×
            </button>
          </div>
        </div>
      </div>

      <style>{`
        .deusi-volume::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 12px; height: 12px; border-radius: 999px;
          background: #fff;
          border: 2px solid ${accent};
          box-shadow: 0 2px 6px ${accent}66;
          cursor: pointer;
        }
        .deusi-volume::-moz-range-thumb {
          width: 12px; height: 12px; border-radius: 999px;
          background: #fff;
          border: 2px solid ${accent};
          box-shadow: 0 2px 6px ${accent}66;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}

function IconBtn({
  children,
  className = "",
  type = "button",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      type={type}
      className={
        "grid h-9 w-9 place-items-center rounded-full border border-border bg-card text-muted-foreground transition hover:-translate-y-0.5 hover:bg-secondary hover:text-foreground active:translate-y-0 " +
        className
      }
    >
      {children}
    </button>
  );
}

function ToggleBtn({
  on,
  accent,
  children,
  className = "",
  type = "button",
  ...rest
}: { on: boolean; accent: string } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      type={type}
      aria-pressed={on}
      className={
        "grid h-9 w-9 place-items-center rounded-full border transition " +
        (on
          ? "text-white shadow-sm"
          : "border-border bg-card text-muted-foreground hover:bg-secondary hover:text-foreground ") +
        className
      }
      style={
        on
          ? { background: accent, borderColor: accent, boxShadow: `0 6px 16px -6px ${accent}` }
          : undefined
      }
    >
      {children}
    </button>
  );
}

function VolumeIcon({ v }: { v: number }) {
  if (v <= 0.001) {
    return (
      <svg
        viewBox="0 0 24 24"
        width="15"
        height="15"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M11 5 6 9H2v6h4l5 4z" />
        <line x1="22" y1="9" x2="16" y2="15" />
        <line x1="16" y1="9" x2="22" y2="15" />
      </svg>
    );
  }
  return (
    <svg
      viewBox="0 0 24 24"
      width="15"
      height="15"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M11 5 6 9H2v6h4l5 4z" />
      {v > 0.33 && <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />}
      {v > 0.66 && <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />}
    </svg>
  );
}

export function fmtTime(sec: number) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
