import { AnimatePresence, motion } from "@/lib/motion-lite";
import { useEffect, useMemo, useRef, useState } from "react";
import { Fa } from "@/components/deusi/Fa";
import type { LyricLine, Song, SongVocab } from "@/lib/deusi/mockMusic";

interface Props {
  song: Song;
  currentTime: number;
  onSeekLine: (sec: number) => void;
  showTranslation: boolean;
  loopLineId: string | null;
  onToggleLoop: (line: LyricLine | null) => void;
  savedIds: string[];
  onSaveVocab: (v: SongVocab) => void;
}

/**
 * Line-by-line karaoke lyrics: the active line is highlighted and scrolled
 * into view, clicking a line jumps the playhead, clicking a linked word opens
 * a small vocabulary card with a "save to Leitner" action.
 */
export function KaraokeLyrics({
  song,
  currentTime,
  onSeekLine,
  showTranslation,
  loopLineId,
  onToggleLoop,
  savedIds,
  onSaveVocab,
}: Props) {
  const [openVocab, setOpenVocab] = useState<SongVocab | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef<HTMLDivElement>(null);

  const activeLine = useMemo(
    () => song.lyrics.find((l) => currentTime >= l.start && currentTime < l.end) ?? null,
    [song.lyrics, currentTime],
  );

  useEffect(() => {
    if (!activeRef.current || !containerRef.current) return;
    const c = containerRef.current;
    const el = activeRef.current;
    const target = el.offsetTop - c.clientHeight / 2 + el.clientHeight / 2;
    c.scrollTo({ top: Math.max(0, target), behavior: "smooth" });
  }, [activeLine?.id]);

  if (song.lyrics.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-6 text-center">
        <p className="text-sm font-semibold text-muted-foreground">
          Für diesen Song gibt es noch keinen synchronen Text.
        </p>
        <Fa className="fa-hint-xs mt-1">برای این آهنگ هنوز متن همگام اضافه نشده است.</Fa>
      </div>
    );
  }

  return (
    <div className="relative">
      <div ref={containerRef} className="max-h-[420px] space-y-1 overflow-y-auto pr-1">
        {song.lyrics.map((l) => {
          const isActive = activeLine?.id === l.id;
          const isPast = currentTime >= l.end;
          return (
            <div
              key={l.id}
              ref={isActive ? activeRef : undefined}
              className={`group rounded-2xl px-3 py-2 transition-colors ${
                isActive ? "bg-secondary" : "hover:bg-secondary/60"
              }`}
            >
              <div className="flex items-start gap-1.5 sm:gap-2">
                <button
                  onClick={() => onSeekLine(l.start)}
                  className="mt-1 hidden sm:block shrink-0 rounded-lg px-1.5 py-0.5 text-[10px] font-bold tabular-nums text-muted-foreground opacity-0 transition group-hover:opacity-100 hover:bg-card"
                  aria-label="Zu dieser Zeile springen"
                >
                  {fmtShort(l.start)}
                </button>

                <p
                  className={`flex-1 cursor-pointer text-[15px] font-bold leading-relaxed transition-colors sm:text-[17px] lg:text-lg ${
                    isActive
                      ? "text-foreground"
                      : isPast
                        ? "text-muted-foreground/70"
                        : "text-muted-foreground"
                  }`}
                  onClick={() => onSeekLine(l.start)}
                >
                  {l.words.map((w, i) => {
                    const vocab = w.vocabId
                      ? song.vocab.find((v) => v.id === w.vocabId)
                      : undefined;
                    if (!vocab) return <span key={i}>{w.w} </span>;
                    return (
                      <button
                        key={i}
                        onClick={(e) => {
                          e.stopPropagation();
                          setOpenVocab(vocab);
                        }}
                        className="mx-[1px] rounded-md px-[3px] underline decoration-dotted decoration-2 underline-offset-4 transition"
                        style={{ color: song.accent, textDecorationColor: song.accent }}
                      >
                        {w.w}
                      </button>
                    );
                  })}
                </p>

                <button
                  onClick={() => onToggleLoop(loopLineId === l.id ? null : l)}
                  aria-pressed={loopLineId === l.id}
                  aria-label="Zeile wiederholen"
                  title="Zeile wiederholen"
                  className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-lg transition sm:opacity-0 sm:group-hover:opacity-100 ${
                    loopLineId === l.id ? "text-white" : "text-muted-foreground hover:bg-card"
                  }`}
                  style={loopLineId === l.id ? { background: song.accent } : undefined}
                >
                  <svg
                    viewBox="0 0 24 24"
                    width="14"
                    height="14"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M17 2l4 4-4 4" />
                    <path d="M3 11v-1a4 4 0 0 1 4-4h14" />
                    <path d="M7 22l-4-4 4-4" />
                    <path d="M21 13v1a4 4 0 0 1-4 4H3" />
                  </svg>
                </button>
              </div>

              {showTranslation && (
                <Fa className={`fa-hint-xs mt-0.5 pl-1 ${isActive ? "opacity-100" : "opacity-70"}`}>
                  {l.translation}
                </Fa>
              )}
            </div>
          );
        })}
      </div>

      <AnimatePresence>
        {openVocab && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            className="sticky bottom-0 mt-3 rounded-2xl border border-border bg-card p-4 shadow-lg"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  {openVocab.article && (
                    <span
                      className="rounded-lg px-2 py-0.5 text-[11px] font-bold text-white"
                      style={{ background: song.accent }}
                    >
                      {openVocab.article}
                    </span>
                  )}
                  <h4 className="truncate text-lg font-black">{openVocab.term}</h4>
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold uppercase text-muted-foreground">
                    {openVocab.pos}
                  </span>
                </div>
                <Fa className="fa-hint-xs mt-1">{openVocab.translation}</Fa>
                <p className="mt-2 text-xs italic text-muted-foreground">„{openVocab.example}“</p>
              </div>
              <button
                onClick={() => setOpenVocab(null)}
                aria-label="Schließen"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-muted-foreground hover:bg-secondary"
              >
                <svg
                  viewBox="0 0 24 24"
                  width="16"
                  height="16"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                >
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>
            </div>

            <button
              onClick={() => onSaveVocab(openVocab)}
              disabled={savedIds.includes(openVocab.id)}
              className="mt-3 w-full rounded-xl px-3 py-2 text-sm font-bold text-white transition disabled:opacity-60"
              style={{ background: song.accent }}
            >
              {savedIds.includes(openVocab.id) ? "In der Leitner-Box ✓" : "In die Leitner-Box"}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function fmtShort(sec: number) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}
