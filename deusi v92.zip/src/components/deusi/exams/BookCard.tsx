import { motion } from "@/lib/motion-lite";
import { Star } from "lucide-react";
import type { ExamBook } from "@/lib/deusi/exams/mockExams";
import { DownloadButton } from "./DownloadButton";

export function BookCard({ book, index = 0 }: { book: ExamBook; index?: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ delay: Math.min(index, 6) * 0.04, duration: 0.35 }}
      whileHover={{ y: -3 }}
      className="neu-card group flex gap-4 overflow-hidden p-4 sm:p-5"
    >
      <div
        className="relative grid h-32 w-24 shrink-0 place-items-end overflow-hidden rounded-xl py-2 pl-3.5 pr-2 text-white shadow-lg"
        style={{ background: book.cover }}
        aria-hidden
      >
        <span className="absolute inset-y-0 left-0 w-1.5 bg-black/25" />
        <span className="line-clamp-4 w-full break-words text-[11px] font-bold leading-tight drop-shadow">
          {book.title}
        </span>
      </div>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="rounded-md bg-[color:var(--section-primary)]/10 px-2 py-0.5 text-[11px] font-bold text-[color:var(--section-primary)]">
            {book.level}
          </span>
          <span className="rounded-md bg-secondary px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
            {book.skill}
          </span>
        </div>
        <h3 className="mt-2 line-clamp-2 text-sm font-bold leading-snug">{book.title}</h3>
        <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
          {book.description}
        </p>

        <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-muted-foreground">
          <span className="font-semibold text-foreground/80">{book.publisher}</span>
          <span>· {book.year}</span>
          <span>· {book.pages} S.</span>
          <span>· {book.size}</span>
          <span className="inline-flex items-center gap-0.5 text-amber-500">
            <Star className="h-3 w-3 fill-current" aria-hidden /> {book.rating.toFixed(1)}
          </span>
        </div>

        <div className="mt-auto flex items-center gap-2 pt-3">
          <DownloadButton
            title={book.title}
            note={`${book.publisher} · ${book.level}`}
            label="PDF laden"
            className="flex-1"
          />
        </div>
      </div>
    </motion.article>
  );
}
