import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion } from "@/lib/motion-lite";
import { EXAMS, type Exam, type ExamPurpose } from "@/lib/deusi/exams/mockExams";
import { ExamLogo } from "./ExamLogo";

const ROWS: { key: keyof Exam["comparison"] | "levels"; label: string }[] = [
  { key: "levels", label: "Niveaustufen" },
  { key: "duration", label: "Dauer" },
  { key: "cost", label: "Kosten (ca.)" },
  { key: "results", label: "Ergebnis" },
  { key: "format", label: "Format" },
  { key: "validity", label: "Gültigkeit" },
  { key: "bestFor", label: "Am besten für" },
];

function value(exam: Exam, key: (typeof ROWS)[number]["key"]) {
  return key === "levels" ? exam.levels.join(" · ") : exam.comparison[key];
}

export function ExamCompareTable() {
  return (
    <div className="neu-card overflow-hidden p-0">
      {/* Desktop table */}
      <div className="hidden overflow-x-auto lg:block">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-border/70">
              <th className="sticky left-0 bg-card/80 px-4 py-4 text-xs font-bold uppercase tracking-wider text-muted-foreground backdrop-blur">
                Kriterium
              </th>
              {EXAMS.map((e) => (
                <th key={e.id} className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <ExamLogo kind={e.logo} size={34} />
                    <Link
                      to="/pruefungen/$examId"
                      params={{ examId: e.id }}
                      className="text-sm font-bold hover:text-[color:var(--section-primary)]"
                    >
                      {e.shortName}
                    </Link>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ROWS.map((row, i) => (
              <tr key={row.key} className={i % 2 ? "bg-secondary/30" : ""}>
                <td className="sticky left-0 whitespace-nowrap bg-inherit px-4 py-3 font-semibold text-muted-foreground">
                  {row.label}
                </td>
                {EXAMS.map((e) => (
                  <td key={e.id} className="px-4 py-3 text-foreground/85">
                    {value(e, row.key)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile stacked cards */}
      <div className="grid gap-3 p-3 lg:hidden">
        {EXAMS.map((e) => (
          <div key={e.id} className="glass rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-xl bg-background/70">
                <ExamLogo kind={e.logo} size={36} />
              </span>
              <div className="min-w-0">
                <Link
                  to="/pruefungen/$examId"
                  params={{ examId: e.id }}
                  className="block text-sm font-bold leading-snug"
                >
                  {e.name}
                </Link>
                <div className="text-xs leading-relaxed text-muted-foreground">
                  {e.comparison.bestFor}
                </div>
              </div>
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
              {ROWS.map((row) => (
                <div key={row.key} className="min-w-0">
                  <dt className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                    {row.label}
                  </dt>
                  <dd className="mt-0.5 break-words leading-relaxed text-foreground/85">
                    {value(e, row.key)}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        ))}
      </div>
    </div>
  );
}

const PURPOSES: { id: ExamPurpose; label: string; icon: string }[] = [
  { id: "Studium", label: "Studium", icon: "🎓" },
  { id: "Beruf", label: "Beruf", icon: "💼" },
  { id: "Aufenthalt", label: "Aufenthalt", icon: "🏠" },
];
const LEVELS = ["A1–A2", "B1", "B2", "C1–C2"];
const SPEEDS = [
  { id: "schnell", label: "So schnell wie möglich" },
  { id: "normal", label: "In 2–3 Monaten" },
  { id: "flexibel", label: "Ganz flexibel" },
];

export function ExamPicker() {
  const [purpose, setPurpose] = useState<ExamPurpose | null>(null);
  const [level, setLevel] = useState<string | null>(null);
  const [speed, setSpeed] = useState<string | null>(null);

  const result = useMemo(() => {
    if (!purpose || !level || !speed) return null;
    const scored = EXAMS.map((e) => {
      let s = 0;
      if (e.purpose.includes(purpose)) s += 3;
      if (e.purpose[0] === purpose) s += 2;
      const wanted = level.split("–");
      if (wanted.some((l) => e.levels.includes(l))) s += 2;
      if (speed === "schnell" && e.comparison.results.startsWith("1")) s += 2;
      if (speed === "schnell" && e.comparison.results.startsWith("2")) s += 1;
      if (speed === "flexibel" && e.levels.length > 3) s += 1;
      return { exam: e, s };
    }).sort((a, b) => b.s - a.s);
    return scored[0].exam;
  }, [purpose, level, speed]);

  return (
    <div className="neu-card p-5">
      <h3 className="text-sm font-bold">Welche Prüfung passt zu mir?</h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Drei kurze Fragen – wir empfehlen dir die passende Prüfung.
      </p>

      <div className="mt-4 space-y-4">
        <PickerRow label="1 · Mein Ziel">
          {PURPOSES.map((p) => (
            <Chip key={p.id} active={purpose === p.id} onClick={() => setPurpose(p.id)}>
              <span aria-hidden>{p.icon}</span> {p.label}
            </Chip>
          ))}
        </PickerRow>
        <PickerRow label="2 · Mein Niveau">
          {LEVELS.map((l) => (
            <Chip key={l} active={level === l} onClick={() => setLevel(l)}>
              {l}
            </Chip>
          ))}
        </PickerRow>
        <PickerRow label="3 · Mein Zeitrahmen">
          {SPEEDS.map((s) => (
            <Chip key={s.id} active={speed === s.id} onClick={() => setSpeed(s.id)}>
              {s.label}
            </Chip>
          ))}
        </PickerRow>
      </div>

      {result && (
        <motion.div
          key={result.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-5 flex items-center gap-3 rounded-2xl border border-[color:var(--section-primary)]/30 bg-[color:var(--section-primary)]/8 p-4"
        >
          <ExamLogo kind={result.logo} size={44} />
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
              Unsere Empfehlung
            </div>
            <div className="text-sm font-bold leading-snug">{result.name}</div>
            <div className="text-xs leading-relaxed text-muted-foreground">
              {result.comparison.bestFor}
            </div>
          </div>
          <Link
            to="/pruefungen/$examId"
            params={{ examId: result.id }}
            className="shrink-0 rounded-full bg-[color:var(--section-primary)] px-4 py-2 text-xs font-semibold text-white transition hover:opacity-90"
          >
            Ansehen
          </Link>
        </motion.div>
      )}
    </div>
  );
}

function PickerRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className="flex flex-wrap gap-1.5">{children}</div>
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
        active
          ? "border-transparent bg-[color:var(--section-primary)] text-white shadow-sm"
          : "border-border/70 bg-card/60 text-muted-foreground hover:border-[color:var(--section-primary)]/40 hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}
