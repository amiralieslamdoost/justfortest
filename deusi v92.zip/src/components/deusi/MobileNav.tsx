import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Logo } from "./Logo";

type Route =
  | "/learn"
  | "/planer"
  | "/dictionary"
  | "/dashboard"
  | "/statistiken"
  | "/podcasts"
  | "/musik"
  | "/lesen"
  | "/grammatik"
  | "/leitner"
  | "/events"
  | "/community"
  | "/profil"
  | "/pruefungen"
  | "/ki-coach"
  | "/kino"
  | "/docs"
  | "/verben"
  | "/schreiben"
  | "/achievements"
  | "/lesezeichen"
  | "/suche"
  | "/abonnement"
  | "/einstellungen"
  | "/benachrichtigungen"
  | "/support";

type Item = { to: Route; label: string; hint?: string; icon: ReactNode };

// Primary tabs — always visible in the bottom bar
const primary: Item[] = [
  { to: "/dashboard", label: "Start", icon: <HomeIcon /> },
  { to: "/dictionary", label: "Wörter", icon: <BookIcon /> },
  { to: "/ki-coach", label: "KI Coach", icon: <SparkleIcon /> },
  { to: "/leitner", label: "Leitner", icon: <BoxIcon /> },
];

// Everything else lives in the "Mehr" sheet — grouped by category
type SheetItem = {
  to?: Route;
  label: string;
  hint?: string;
  icon: ReactNode;
  comingSoon?: boolean;
};
type Group = { title: string; items: SheetItem[] };

const groups: Group[] = [
  {
    title: "Übersicht",
    items: [
      { to: "/dashboard", label: "Start", hint: "Dein Überblick", icon: <HomeIcon /> },
      {
        to: "/planer",
        label: "Smart Planner",
        hint: "Dein Wochenplan",
        icon: <CalendarIcon />,
      },
      { to: "/suche", label: "Suche", hint: "Alles finden", icon: <SearchIcon /> },
    ],
  },
  {
    title: "Werkzeuge",
    items: [
      { to: "/dictionary", label: "Wörterbuch", hint: "Wortschatz", icon: <BookIcon /> },
      { to: "/verben", label: "Wortfamilien", hint: "Wortstämme & Wortbau", icon: <BoltIcon /> },
      { to: "/lesezeichen", label: "Lesezeichen", hint: "Merkliste", icon: <BookmarkIcon /> },
    ],
  },
  {
    title: "Lernen",
    items: [
      { to: "/grammatik", label: "Grammatik", hint: "Regeln & Übungen", icon: <GrammarIcon /> },
      { to: "/schreiben", label: "Schreiben", hint: "Texte korrigieren", icon: <PencilIcon /> },
      { to: "/lesen", label: "Lesen", hint: "Artikel & Bücher", icon: <ReadIcon /> },
      { to: "/leitner", label: "Leitner-Box", hint: "Wiederholen", icon: <BoxIcon /> },
      { to: "/ki-coach", label: "KI-Coach", hint: "Dein Sprachcoach", icon: <SparkleIcon /> },
    ],
  },
  {
    title: "Medien",
    items: [
      { to: "/podcasts", label: "Podcasts", hint: "Hörverstehen", icon: <HeadphoneIcon /> },
      { to: "/musik", label: "Musik", hint: "Songs & Karaoke", icon: <MusicNoteIcon /> },
      { to: "/kino", label: "Filme & Serien", hint: "Deutsches Kino", icon: <FilmIcon /> },
    ],
  },
  {
    title: "Informationen",
    items: [
      {
        to: "/pruefungen",
        label: "Prüfungen",
        hint: "Goethe, telc, ÖSD",
        icon: <CertificateIcon />,
      },
      { to: "/events", label: "Events", hint: "Treffen & Stammtisch", icon: <CalendarIcon /> },
    ],
  },
  {
    title: "Community",
    items: [
      { to: "/community", label: "Community", hint: "Talare, Gruppen & Chats", icon: <ChatIcon /> },
    ],
  },
  {
    title: "Fortschritt",
    items: [
      { to: "/statistiken", label: "Statistik", hint: "Dein Fortschritt", icon: <ChartIcon /> },
      { to: "/achievements", label: "Erfolge", hint: "Abzeichen & Serien", icon: <TrophyIcon /> },
    ],
  },
  {
    title: "Konto",
    items: [
      { to: "/profil", label: "Profil", hint: "Niveau & Einstufung", icon: <UserIcon /> },
      { to: "/abonnement", label: "Abonnement", hint: "Abo & Premium", icon: <CrownIcon /> },
      {
        to: "/benachrichtigungen",
        label: "Benachrichtigungen",
        hint: "Updates",
        icon: <BellIcon />,
      },
      { to: "/einstellungen", label: "Einstellungen", hint: "App & Konto", icon: <GearIcon /> },
      { to: "/support", label: "Support", hint: "Wir helfen dir", icon: <LifebuoyIcon /> },
      { to: "/docs", label: "Dokumentation", hint: "Anleitungen", icon: <DocsIcon /> },
    ],
  },
];

const secondary: SheetItem[] = groups.flatMap((g) => g.items);

export function MobileNav() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [dragY, setDragY] = useState(0);
  const dragStart = useRef<number | null>(null);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setOpen(false);
    setQuery("");
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    const prevPaddingRight = document.body.style.paddingRight;
    const prevScrollbarWidth = document.documentElement.style.getPropertyValue(
      "--mobile-nav-scrollbar-width",
    );
    const scrollbarWidth = Math.max(0, window.innerWidth - document.documentElement.clientWidth);
    const bodyPaddingRight =
      Number.parseFloat(window.getComputedStyle(document.body).paddingRight) || 0;

    document.documentElement.style.setProperty(
      "--mobile-nav-scrollbar-width",
      `${scrollbarWidth}px`,
    );
    document.body.style.overflow = "hidden";
    document.body.style.paddingRight = `${bodyPaddingRight + scrollbarWidth}px`;

    return () => {
      document.body.style.overflow = prevOverflow;
      document.body.style.paddingRight = prevPaddingRight;
      if (prevScrollbarWidth) {
        document.documentElement.style.setProperty(
          "--mobile-nav-scrollbar-width",
          prevScrollbarWidth,
        );
      } else {
        document.documentElement.style.removeProperty("--mobile-nav-scrollbar-width");
      }
    };
  }, [open]);

  const isActive = (to?: Route) => !!to && (pathname === to || pathname.startsWith(to + "/"));
  const secondaryActive = secondary.some((i) => isActive(i.to));

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return groups;
    return groups
      .map((g) => ({
        ...g,
        items: g.items.filter(
          (i) => i.label.toLowerCase().includes(q) || i.hint?.toLowerCase().includes(q),
        ),
      }))
      .filter((g) => g.items.length > 0);
  }, [query]);

  const closeSheet = () => {
    setOpen(false);
    setDragY(0);
  };

  return (
    <>
      {/* Native-style bottom Tab Bar (mobile only) */}
      <nav
        aria-label="Hauptnavigation"
        className="tabbar-glass fixed inset-x-0 bottom-0 z-40 lg:hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="relative mx-auto grid w-full max-w-[520px] grid-cols-5 items-start px-1 pb-1 pt-1.5">
          {primary.map((it) => (
            <TabLink key={it.to} item={it} active={isActive(it.to)} />
          ))}

          <button
            type="button"
            onClick={() => setOpen(true)}
            aria-label="Mehr anzeigen"
            aria-expanded={open}
            className={`tab-press group relative flex flex-col items-center justify-start gap-1 rounded-xl px-1 py-1 text-[10px] font-semibold outline-none transition-colors ${
              secondaryActive
                ? "text-[color:var(--section-primary,var(--flag-red))]"
                : "text-foreground/55 hover:text-foreground"
            }`}
          >
            <span className="grid h-6 w-6 place-items-center">
              <MoreIcon />
            </span>
            <span className="leading-none tracking-tight">Mehr</span>
            <span
              aria-hidden
              className={`h-1 w-1 rounded-full ${secondaryActive ? "tab-dot bg-[color:var(--section-primary,var(--flag-red))]" : "bg-transparent"}`}
            />
          </button>
        </div>
      </nav>

      {/* Bottom Sheet — "Mehr" */}
      <div
        onClick={closeSheet}
        aria-hidden
        className={`fixed inset-y-0 left-0 z-40 bg-black/45 transition-opacity duration-200 lg:hidden ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        style={{ right: "var(--mobile-nav-scrollbar-width, 0px)" }}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Alle Bereiche"
        className={`fixed bottom-0 left-0 z-50 min-w-0 overflow-x-hidden lg:hidden ${
          dragY ? "" : "transition-transform duration-300 ease-[cubic-bezier(0.32,0.72,0,1)]"
        } will-change-transform`}
        style={{
          right: "var(--mobile-nav-scrollbar-width, 0px)",
          transform: open ? `translateY(${dragY}px)` : "translateY(100%)",
        }}
      >
        <div
          className="mx-auto flex max-h-[86dvh] w-full min-w-0 max-w-[520px] flex-col overflow-x-hidden rounded-t-[1.75rem] border-t border-border/70 bg-card shadow-[0_-8px_30px_-10px_rgba(0,0,0,0.25)]"
          style={{ paddingBottom: "max(1rem, env(safe-area-inset-bottom))" }}
        >
          <div
            className="shrink-0 cursor-grab touch-none pt-2.5"
            onTouchStart={(e) => {
              dragStart.current = e.touches[0].clientY;
            }}
            onTouchMove={(e) => {
              if (dragStart.current === null) return;
              setDragY(Math.max(0, e.touches[0].clientY - dragStart.current));
            }}
            onTouchEnd={() => {
              if (dragY > 110) closeSheet();
              else setDragY(0);
              dragStart.current = null;
            }}
          >
            <div className="mx-auto h-1.5 w-10 rounded-full bg-foreground/20" aria-hidden />
          </div>

          <div className="flex shrink-0 items-center justify-between px-5 pb-3 pt-3">
            <div className="min-w-0">
              <Logo compact />
            </div>
            <button
              onClick={closeSheet}
              aria-label="Schließen"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-secondary text-muted-foreground transition hover:bg-secondary/70 hover:text-foreground active:scale-95"
            >
              <svg
                viewBox="0 0 24 24"
                width="16"
                height="16"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
              >
                <path d="M6 6l12 12M18 6l-12 12" />
              </svg>
            </button>
          </div>

          {/* Quick search */}
          <div className="shrink-0 px-4 pb-3">
            <label className="flex items-center gap-2 rounded-2xl bg-secondary/70 px-3.5 py-2.5 text-sm">
              <span className="text-muted-foreground">
                <SearchIcon />
              </span>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Bereich suchen …"
                className="w-full min-w-0 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Suche leeren"
                  className="text-muted-foreground"
                >
                  <svg
                    viewBox="0 0 24 24"
                    width="14"
                    height="14"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                  >
                    <path d="M6 6l12 12M18 6l-12 12" />
                  </svg>
                </button>
              )}
            </label>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-3">
            {results.map((group) => (
              <div key={group.title} className="mb-2">
                <div className="px-2.5 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/70">
                  {group.title}
                </div>
                <ul className="space-y-1">
                  {group.items.map((it) => {
                    const active = isActive(it.to);
                    const inner = (
                      <>
                        <span
                          className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${
                            active
                              ? "bg-[color:var(--section-primary,var(--flag-red))] text-white"
                              : "bg-secondary/70 text-foreground"
                          }`}
                        >
                          {it.icon}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-semibold leading-tight">
                            {it.label}
                          </span>
                          {it.hint && (
                            <span className="block truncate text-[11px] text-muted-foreground">
                              {it.hint}
                            </span>
                          )}
                        </span>
                        <svg
                          viewBox="0 0 24 24"
                          width="16"
                          height="16"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          className="shrink-0 text-muted-foreground"
                        >
                          <path d="m9 6 6 6-6 6" />
                        </svg>
                      </>
                    );

                    return (
                      <li key={it.label}>
                        {it.to && !it.comingSoon ? (
                          <Link
                            to={it.to}
                            className={`flex items-center gap-3 rounded-2xl px-2.5 py-2.5 transition active:scale-[0.985] ${
                              active
                                ? "bg-[color:var(--section-primary,var(--flag-red))]/10 text-[color:var(--section-primary,var(--flag-red))]"
                                : "text-foreground/85 hover:bg-secondary/60"
                            }`}
                          >
                            {inner}
                          </Link>
                        ) : (
                          <div
                            aria-disabled="true"
                            className="pointer-events-none flex select-none items-center gap-3 rounded-2xl px-2.5 py-2.5 text-foreground/85 opacity-50"
                          >
                            {inner}
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
            {results.length === 0 && (
              <p className="px-3 py-8 text-center text-sm text-muted-foreground">
                Nichts gefunden.
              </p>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}

function TabLink({ item, active }: { item: Item; active: boolean }) {
  return (
    <Link
      to={item.to}
      aria-label={item.label}
      aria-current={active ? "page" : undefined}
      className={`tab-press group relative flex min-w-0 flex-col items-center justify-start gap-1 rounded-xl px-1 py-1 text-[10px] font-semibold outline-none transition-colors ${
        active ? "text-[color:var(--section-primary,var(--flag-red))]" : "text-foreground/55 hover:text-foreground"
      }`}
    >
      <span className="grid h-6 w-6 place-items-center">{item.icon}</span>
      <span className="max-w-full truncate leading-none tracking-tight">{item.label}</span>
      <span
        aria-hidden
        className={`h-1 w-1 rounded-full ${active ? "tab-dot bg-[color:var(--section-primary,var(--flag-red))]" : "bg-transparent"}`}
      />
    </Link>
  );
}

/* ---------- Icons ---------- */
function I({ children }: { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width="21"
      height="21"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {children}
    </svg>
  );
}
function HomeIcon() {
  return (
    <I>
      <path d="M3 11 12 3l9 8" />
      <path d="M5 10v10h14V10" />
    </I>
  );
}
function BookIcon() {
  return (
    <I>
      <path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2V5z" />
      <path d="M8 7h7M8 11h7" />
    </I>
  );
}
function ReadIcon() {
  return (
    <I>
      <path d="M2 6c3-1 6-1 9 1v13c-3-2-6-2-9-1V6z" />
      <path d="M22 6c-3-1-6-1-9 1v13c3-2 6-2 9-1V6z" />
    </I>
  );
}
function HeadphoneIcon() {
  return (
    <I>
      <path d="M4 14v-2a8 8 0 1 1 16 0v2" />
      <path d="M4 14h3v6H5a1 1 0 0 1-1-1v-5zM20 14h-3v6h2a1 1 0 0 0 1-1v-5z" />
    </I>
  );
}
function ChartIcon() {
  return (
    <I>
      <path d="M4 20V10" />
      <path d="M10 20V4" />
      <path d="M16 20v-8" />
      <path d="M22 20H2" />
    </I>
  );
}
function GearIcon() {
  return (
    <I>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1" />
    </I>
  );
}
function GrammarIcon() {
  return (
    <I>
      <path d="M4 4h16v4H4z" />
      <path d="M4 12h10v4H4z" />
      <path d="M4 20h6" />
      <path d="M18 12l3 3-3 3" />
    </I>
  );
}
function BoxIcon() {
  return (
    <I>
      <path d="M3 7l9-4 9 4-9 4-9-4z" />
      <path d="M3 12l9 4 9-4" />
      <path d="M3 17l9 4 9-4" />
    </I>
  );
}
function CalendarIcon() {
  return (
    <I>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </I>
  );
}
function SparkleIcon() {
  return (
    <I>
      <path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3z" />
      <path d="M19 14l.9 2.1 2.1.9-2.1.9L19 20l-.9-2.1-2.1-.9 2.1-.9L19 14z" />
    </I>
  );
}
function CertificateIcon() {
  return (
    <I>
      <rect x="4" y="3" width="16" height="14" rx="2" />
      <path d="M8 21l4-3 4 3v-6" />
      <circle cx="12" cy="10" r="2" />
    </I>
  );
}
function FilmIcon() {
  return (
    <I>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" />
    </I>
  );
}
function MoreIcon() {
  return (
    <I>
      <circle cx="5" cy="12" r="1.4" />
      <circle cx="12" cy="12" r="1.4" />
      <circle cx="19" cy="12" r="1.4" />
    </I>
  );
}
function DocsIcon() {
  return (
    <I>
      <path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2V5z" />
      <path d="M8 7h7M8 11h7" />
    </I>
  );
}
function GraduationIcon() {
  return (
    <I>
      <path d="M2 10l10-5 10 5-10 5L2 10z" />
      <path d="M6 12v4c0 1.5 3 3 6 3s6-1.5 6-3v-4" />
    </I>
  );
}

function MusicNoteIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="21"
      height="21"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M10 18V6l9-2v12" />
      <circle cx="7.5" cy="18" r="2.4" fill="currentColor" stroke="none" />
      <circle cx="16.5" cy="16" r="2.4" fill="currentColor" stroke="none" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <I>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.2-3.2" />
    </I>
  );
}
function BoltIcon() {
  return (
    <I>
      <path d="M13 2 3 14h7l-1 8 10-12h-7l1-8z" />
    </I>
  );
}
function UserIcon() {
  return (
    <I>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </I>
  );
}
function TrophyIcon() {
  return (
    <I>
      <path d="M8 4h8v5a4 4 0 0 1-8 0V4z" />
      <path d="M8 5H5v2a3 3 0 0 0 3 3M16 5h3v2a3 3 0 0 1-3 3" />
      <path d="M10 17h4M9 21h6" />
      <path d="M12 13v4" />
    </I>
  );
}
function BookmarkIcon() {
  return (
    <I>
      <path d="M6 3h12v18l-6-4-6 4V3z" />
    </I>
  );
}
function CrownIcon() {
  return (
    <I>
      <path d="M3 7l4 4 5-6 5 6 4-4v11H3V7z" />
    </I>
  );
}
function LifebuoyIcon() {
  return (
    <I>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="3.5" />
      <path d="m5.6 5.6 3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9" />
    </I>
  );
}
function PencilIcon() {
  return (
    <I>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
    </I>
  );
}

function ChatIcon() {
  return (
    <I>
      <path d="M4 12a8 8 0 1 1 3.2 6.4L4 20l1.2-3.6" />
    </I>
  );
}
function BellIcon() {
  return (
    <I>
      <path d="M18 8a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7" />
      <path d="M10.5 20a2 2 0 0 0 3 0" />
    </I>
  );
}
