import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import { Check, ChevronDown, Search, Sparkles, Trophy, Volume2 } from "lucide-react";
import { ALL_WORDS } from "@/lib/deusi/dictionary/mockWords";
import { CEFR_COLOR, POS_SHORT, POS_COLOR } from "@/lib/deusi/dictionary/categories";
import { Fa } from "@/components/deusi/Fa";
import { SearchField } from "@/components/deusi/SearchField";

function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "de-DE";
    window.speechSynthesis.speak(u);
  } catch {
    /* noop */
  }
}

interface Props {
  /** Headwords the learner has fully mastered (final Leitner box). */
  headwords: string[];
  /** Total cards currently in the system — used for the mastery ratio. */
  totalCards?: number;
}

export function MasteredWordsCard({ headwords, totalCards }: Props) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");

  const rows = useMemo(
    () =>
      headwords.map((hw) => {
        const w = ALL_WORDS.find((x) => x.headword === hw);
        return {
          headword: hw,
          pos: w?.pos,
          cefr: w?.cefr,
          de: w?.meanings?.[0]?.de,
          fa: w?.meanings?.[0]?.fa,
          article: w?.nounGrammar?.article,
        };
      }),
    [headwords],
  );

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return rows;
    return rows.filter(
      (r) =>
        r.headword.toLowerCase().includes(t) ||
        (r.de ?? "").toLowerCase().includes(t) ||
        (r.fa ?? "").includes(t),
    );
  }, [rows, q]);

  const pct = totalCards ? Math.round((rows.length / totalCards) * 100) : null;

  return (
    <div className="glass-strong relative overflow-hidden rounded-[1.75rem]">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, #22C55E55, transparent 70%)" }}
      />
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="group relative flex w-full items-center gap-4 p-5 text-left"
      >
        <span
          className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-white shadow-[0_14px_30px_-14px_rgba(34,197,94,.9)] transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:scale-[1.04]"
          style={{ background: "linear-gradient(135deg,#22C55E,#0EA5E9)" }}
        >
          <Trophy className="h-7 w-7" />
        </span>

        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <span className="text-lg font-black">Gemeisterte Wörter</span>
            <span className="rounded-full bg-[#22C55E]/15 px-2 py-0.5 text-[11px] font-black tabular-nums text-[#16a34a]">
              {rows.length}
            </span>
          </span>
          <Fa className="fa-hint-xs">واژه‌هایی که کاملاً مسلط شده‌ای</Fa>
          <span className="mt-0.5 block text-xs text-muted-foreground">
            Karten aus der letzten Leitner-Box – sicher im Langzeitgedächtnis.
          </span>
          {pct !== null && (
            <span className="mt-2.5 block h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-muted/50">
              <motion.span
                className="block h-full rounded-full"
                style={{ background: "linear-gradient(90deg,#22C55E,#0EA5E9)" }}
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, pct)}%` }}
                transition={{ duration: 0.9, ease: [0.2, 0.8, 0.2, 1] }}
              />
            </span>
          )}
        </span>

        <span className="flex shrink-0 items-center gap-2 rounded-full border border-border/60 bg-card/70 px-3 py-2 text-xs font-bold backdrop-blur transition group-hover:bg-accent">
          {open ? "Schließen" : "Liste ansehen"}
          <ChevronDown
            className={`h-4 w-4 transition-transform duration-300 ${open ? "rotate-180" : ""}`}
          />
        </span>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="list"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
            className="relative overflow-hidden"
          >
            <div className="border-t border-border/50 p-5 pt-4">
              <SearchField
                value={q}
                onValueChange={setQ}
                placeholder="Gemeisterte Wörter durchsuchen…"
                className="mb-4"
                trailing={
                  <span className="shrink-0 text-[11px] font-bold tabular-nums text-muted-foreground">
                    {filtered.length}
                  </span>
                }
              />

              {filtered.length === 0 ? (
                <div className="grid place-items-center rounded-2xl border border-dashed border-border/60 p-8 text-center">
                  <Sparkles className="mb-2 h-5 w-5 text-muted-foreground" />
                  <p className="text-sm font-semibold">Noch nichts gemeistert</p>
                  <p className="text-xs text-muted-foreground">
                    Bringe Karten bis in Box 5 – sie erscheinen dann hier.
                  </p>
                </div>
              ) : (
                <ul className="grid max-h-[26rem] gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
                  {filtered.map((r, i) => (
                    <motion.li
                      key={r.headword + i}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.25, delay: Math.min(i * 0.02, 0.3) }}
                      className="group/item flex items-center gap-3 rounded-2xl border border-border/50 bg-card/60 p-3 backdrop-blur transition hover:-translate-y-0.5 hover:border-[#22C55E]/50 hover:shadow-[0_14px_30px_-18px_rgba(34,197,94,.8)]"
                    >
                      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[#22C55E]/15 text-[#16a34a]">
                        <Check className="h-4 w-4" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-1.5">
                          {r.article && (
                            <span className="text-[11px] font-semibold text-muted-foreground">
                              {r.article}
                            </span>
                          )}
                          <span className="truncate text-sm font-bold">{r.headword}</span>
                          {r.cefr && (
                            <span
                              className="rounded px-1 py-px text-[9px] font-black text-white"
                              style={{ background: CEFR_COLOR[r.cefr] }}
                            >
                              {r.cefr}
                            </span>
                          )}
                          {r.pos && (
                            <span
                              className="rounded px-1 py-px text-[9px] font-bold"
                              style={{
                                background: `${POS_COLOR[r.pos]}1f`,
                                color: POS_COLOR[r.pos],
                              }}
                            >
                              {POS_SHORT[r.pos]}
                            </span>
                          )}
                        </span>
                        {(r.de || r.fa) && (
                          <span className="mt-0.5 block truncate text-[11px] text-muted-foreground">
                            {r.de ?? r.fa}
                          </span>
                        )}
                      </span>
                      <button
                        type="button"
                        onClick={() => speak(r.headword)}
                        aria-label={`${r.headword} anhören`}
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-xl border border-border/60 text-muted-foreground opacity-0 transition hover:bg-accent hover:text-foreground group-hover/item:opacity-100"
                      >
                        <Volume2 className="h-4 w-4" />
                      </button>
                    </motion.li>
                  ))}
                </ul>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
