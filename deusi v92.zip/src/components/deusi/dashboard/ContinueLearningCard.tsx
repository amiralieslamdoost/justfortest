import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import { ArrowRightIcon } from "./icons";

export interface ContinueLearningCardProps {
  due: number;
  className?: string;
}

export function ContinueLearningCard({ due, className = "" }: ContinueLearningCardProps) {
  const progress = 65;
  const size = 78;
  const stroke = 9;
  const svg = size + 24; // padding so the ring glow never gets clipped
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = (progress / 100) * c;

  return (
    <div
      className={`group relative overflow-hidden rounded-2xl p-4 text-white sm:rounded-3xl shadow-[0_24px_60px_-24px_rgba(221,34,34,0.55)] sm:p-8 ${className}`}
      style={{
        background: "linear-gradient(135deg, #b91c1c 0%, #dd2222 42%, #f59e0b 100%)",
      }}
    >
      {/* Ambient blobs */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-28 h-80 w-80 rounded-full bg-white/25 blur-3xl transition-transform duration-700 group-hover:scale-110"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-24 -left-20 h-72 w-72 rounded-full bg-black/20 blur-3xl"
      />
      {/* Subtle grid overlay */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="relative z-10 flex h-full flex-col">
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-white ring-1 ring-white/30 backdrop-blur">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
            Aktuelle Lektion
          </span>
          <span className="rounded-full bg-black/25 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white/90 backdrop-blur">
            Grammatik · A2
          </span>
        </div>

        <h3 className="mt-3 text-2xl font-black leading-tight tracking-tight sm:mt-4 sm:text-4xl">
          Lernen fortsetzen
        </h3>
        <Fa className="fa-hint-xs mt-1 !hidden !text-base !text-white/90 !opacity-100 sm:!block">ادامه یادگیری</Fa>

        <div className="mt-4 flex items-center gap-3 sm:mt-6 sm:gap-4">
          <div className="relative h-[102px] w-[102px] shrink-0 -m-3 sm:h-[120px] sm:w-[120px]">
            <svg width={svg} height={svg} className="-rotate-90 overflow-visible">
              <circle
                cx={svg / 2}
                cy={svg / 2}
                r={r}
                stroke="rgba(255,255,255,0.22)"
                strokeWidth={stroke}
                fill="none"
              />
              <circle
                cx={svg / 2}
                cy={svg / 2}
                r={r}
                stroke="white"
                strokeWidth={stroke}
                strokeLinecap="round"
                fill="none"
                strokeDasharray={c}
                strokeDashoffset={c - dash}
                style={{ filter: "drop-shadow(0 0 6px rgba(255,255,255,0.6))" }}
              />
            </svg>
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-center leading-none">
                <div className="text-lg font-black">A2</div>
                <div className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-white/80">
                  {progress}%
                </div>
              </div>
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <div className="truncate text-lg font-black leading-tight">
              Präpositionen mit Dativ & Akkusativ
            </div>
            <Fa className="fa-hint-xs !hidden !text-white/90 !opacity-100 sm:!block">
              حروف اضافه با داتیو و آکوزاتیو
            </Fa>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-bold text-white/95 ring-1 ring-white/20 backdrop-blur">
                Lektion 4 / 8
              </span>
              <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-bold text-white/95 ring-1 ring-white/20 backdrop-blur">
                📇 {Math.max(due, 12)} fällig
              </span>
            </div>
          </div>
        </div>

        {/* Fill the gap: quick lesson stats */}
        <div className="mt-4 grid grid-cols-3 gap-2 sm:mt-6 sm:gap-3">
          {[
            { k: "Minuten", v: "18", fa: "دقیقه" },
            { k: "Übungen", v: "12", fa: "تمرین" },
            { k: "Genauigkeit", v: "86%", fa: "دقت" },
          ].map((s) => (
            <div
              key={s.k}
              className="rounded-xl bg-white/12 px-2 py-1.5 text-center sm:rounded-2xl sm:px-3 sm:py-2.5 ring-1 ring-white/20 backdrop-blur transition hover:bg-white/20"
            >
              <div className="text-lg font-black leading-none tabular-nums">{s.v}</div>
              <div className="mt-1 text-[10px] font-bold uppercase tracking-wider text-white/80">
                {s.k}
              </div>
              <Fa className="fa-hint-xs !hidden !text-[10px] !text-white/70 !opacity-100 sm:!block">{s.fa}</Fa>
            </div>
          ))}
        </div>

        <div className="mt-auto pt-3.5 sm:pt-5">
          <div className="flex flex-col gap-2 sm:flex-row sm:gap-3">
            <Link
              to="/grammatik"
              className="group/btn inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-white px-5 py-2.5 text-sm font-black sm:rounded-2xl sm:px-6 sm:py-3.5 sm:text-base text-[color:var(--flag-red)] shadow-[0_12px_28px_-10px_rgba(0,0,0,0.35)] transition hover:-translate-y-0.5 hover:shadow-[0_18px_38px_-10px_rgba(0,0,0,0.45)]"
            >
              Weiterlernen
              <span className="transition-transform group-hover/btn:translate-x-1">
                <ArrowRightIcon />
              </span>
            </Link>
            <Link
              to="/learn"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-white/15 px-4 py-2.5 text-sm font-bold sm:rounded-2xl sm:px-5 sm:py-3.5 text-white ring-1 ring-white/30 backdrop-blur transition hover:-translate-y-0.5 hover:bg-white/25"
            >
              📇 Karten üben
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
