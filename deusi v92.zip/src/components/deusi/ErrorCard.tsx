import { motion } from "@/lib/motion-lite";
import { Link, useRouter } from "@tanstack/react-router";
import { AlertTriangle, RotateCw, Home, ArrowLeft } from "lucide-react";

interface Props {
  title?: string;
  description?: string;
  error?: Error | unknown;
  reset?: () => void;
  showHome?: boolean;
  showBack?: boolean;
}

/**
 * Glass error card used by defaultErrorComponent + per-route errorComponent.
 * Provides retry / back / home recovery actions.
 */
export function ErrorCard({
  title = "Etwas ist schiefgelaufen",
  description = "Beim Laden dieser Seite ist ein Fehler aufgetreten. Bitte versuche es erneut.",
  error,
  reset,
  showHome = true,
  showBack = true,
}: Props) {
  const router = useRouter();
  const message = error instanceof Error ? error.message : undefined;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="mx-auto my-8 flex max-w-lg flex-col items-center gap-4 rounded-3xl border border-white/40 bg-white/60 p-8 text-center shadow-[var(--elev-2)] backdrop-blur-xl dark:border-white/10 dark:bg-white/5"
      role="alert"
    >
      <div
        aria-hidden
        className="grid h-14 w-14 place-items-center rounded-2xl bg-rose-500/10 text-rose-500 ring-1 ring-inset ring-rose-500/20"
      >
        <AlertTriangle className="h-6 w-6" />
      </div>
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-foreground">{title}</h2>
        <p className="text-sm text-muted-foreground">{description}</p>
        {message && (
          <p className="pt-1 font-mono text-[11px] text-muted-foreground/70">{message}</p>
        )}
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
        {reset && (
          <button
            type="button"
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="btn btn-primary"
          >
            <RotateCw className="h-4 w-4" /> Erneut versuchen
          </button>
        )}
        {showBack && (
          <button type="button" onClick={() => router.history.back()} className="btn-back">
            <ArrowLeft className="h-4 w-4" /> Zurück
          </button>
        )}
        {showHome && (
          <Link to="/dashboard" className="btn btn-ghost">
            <Home className="h-4 w-4" /> Startseite
          </Link>
        )}
      </div>
    </motion.div>
  );
}
