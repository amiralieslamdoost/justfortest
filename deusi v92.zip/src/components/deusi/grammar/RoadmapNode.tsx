import { Link } from "@tanstack/react-router";
import { motion } from "@/lib/motion-lite";
import { nodeKindMeta, type RoadmapNode as NodeT } from "@/lib/deusi/mockGrammar";

export function RoadmapNodeCard({
  node,
  index,
  side,
  topicId,
  accent,
}: {
  node: NodeT;
  index: number;
  side: "left" | "right";
  topicId: string;
  accent: string;
}) {
  const meta = nodeKindMeta[node.kind];
  const locked = node.status === "locked";
  const current = node.status === "current";
  const done = node.status === "done";

  const inner = (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.96 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
      whileHover={locked ? undefined : { y: -6, scale: 1.01 }}
      className={`glass relative w-full max-w-md overflow-hidden rounded-3xl p-6 ${
        locked ? "opacity-50 blur-[1px] pointer-events-none" : ""
      } ${current ? "ring-2 ring-offset-2 ring-offset-background" : ""}`}
      style={current ? { boxShadow: `0 0 60px ${accent}55, 0 0 0 2px ${accent}` } : undefined}
    >
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full opacity-40 blur-3xl"
        style={{ background: meta.hue }}
        animate={current ? { scale: [1, 1.2, 1], opacity: [0.4, 0.7, 0.4] } : undefined}
        transition={current ? { duration: 3, repeat: Infinity } : undefined}
      />
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-2xl shadow-inner"
            style={{ background: `${meta.hue}22`, color: meta.hue }}
          >
            {meta.emoji}
          </div>
          <div className="min-w-0">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              Schritt {index + 1} · {meta.label}
            </div>
            <h3 className="truncate text-lg font-bold text-foreground">{node.title}</h3>
          </div>
        </div>
        <StatusBadge status={node.status} accent={accent} />
      </div>
      <p className="mt-3 text-sm text-muted-foreground">{node.description}</p>
      <div className="mt-4 flex items-center gap-2 text-xs">
        <span className="rounded-full bg-muted px-2 py-1 font-medium">⏱ {node.duration} Min</span>
        <span className="rounded-full bg-muted px-2 py-1 font-medium">{node.difficulty}</span>
        {done && (
          <span className="rounded-full bg-emerald-500/15 px-2 py-1 font-semibold text-emerald-600">
            Abgeschlossen
          </span>
        )}
        {current && (
          <span
            className="rounded-full px-2 py-1 font-semibold"
            style={{ background: `${accent}22`, color: accent }}
          >
            Jetzt dran
          </span>
        )}
      </div>
    </motion.div>
  );

  if (locked) {
    return (
      <div className={`flex ${side === "left" ? "justify-start" : "justify-end"}`}>{inner}</div>
    );
  }

  return (
    <div className={`flex ${side === "left" ? "justify-start" : "justify-end"}`}>
      <Link
        to="/grammatik/$topicId/$lessonId"
        params={{ topicId, lessonId: `${node.id}-l` }}
        className="block w-full max-w-md"
      >
        {inner}
      </Link>
    </div>
  );
}

function StatusBadge({ status, accent }: { status: NodeT["status"]; accent: string }) {
  if (status === "done") {
    return (
      <div className="grid h-8 w-8 place-items-center rounded-full bg-emerald-500 text-white">
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M20 6L9 17l-5-5" />
        </svg>
      </div>
    );
  }
  if (status === "current") {
    return (
      <motion.div
        className="grid h-8 w-8 place-items-center rounded-full text-white"
        style={{ background: accent }}
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        ▶
      </motion.div>
    );
  }
  if (status === "locked") {
    return (
      <div className="grid h-8 w-8 place-items-center rounded-full bg-muted text-muted-foreground">
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
        >
          <rect x="4" y="11" width="16" height="10" rx="2" />
          <path d="M8 11V7a4 4 0 0 1 8 0v4" />
        </svg>
      </div>
    );
  }
  return <div className="h-8 w-8 rounded-full border-2 border-dashed border-muted-foreground/40" />;
}
