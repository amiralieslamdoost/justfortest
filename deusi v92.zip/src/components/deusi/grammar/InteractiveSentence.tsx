import { AnimatePresence, motion } from "@/lib/motion-lite";
import { useState } from "react";
import type { Sentence, Word } from "@/lib/deusi/mockGrammar";

export function InteractiveSentence({
  sentence,
  accent = "#7c5cff",
}: {
  sentence: Sentence;
  accent?: string;
}) {
  const [active, setActive] = useState<Word | null>(null);
  const [showTrans, setShowTrans] = useState(false);

  // Build a list of segments matching either a highlighted word or plain text
  const segments = splitIntoSegments(sentence.text, sentence.words);

  function speak() {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const u = new SpeechSynthesisUtterance(sentence.text);
    u.lang = "de-DE";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  }

  return (
    <div className="glass rounded-2xl p-4">
      <p className="text-lg leading-relaxed text-foreground">
        {segments.map((seg, i) =>
          seg.word ? (
            <button
              key={i}
              onClick={() => setActive(seg.word!)}
              className="mx-0.5 rounded-md px-1 py-0.5 font-semibold underline decoration-dotted underline-offset-4 transition-colors hover:bg-accent"
              style={{ color: accent }}
            >
              {seg.text}
            </button>
          ) : (
            <span key={i}>{seg.text}</span>
          ),
        )}
      </p>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <button
          onClick={speak}
          className="rounded-full bg-muted px-3 py-1 text-xs font-semibold hover:bg-accent"
        >
          🔊 Anhören
        </button>
        <button
          onClick={() => setShowTrans((v) => !v)}
          className="rounded-full bg-muted px-3 py-1 text-xs font-semibold hover:bg-accent"
        >
          🌐 Übersetzen
        </button>
        <button
          onClick={() => setActive(sentence.words[0] ?? null)}
          className="rounded-full bg-muted px-3 py-1 text-xs font-semibold hover:bg-accent"
        >
          🔎 Analysieren
        </button>
      </div>
      <AnimatePresence>
        {showTrans && (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 text-sm text-muted-foreground"
          >
            {sentence.translation}
          </motion.p>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {active && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="mt-3 rounded-xl border border-border/60 bg-background/80 p-3 text-sm shadow-lg"
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-bold text-foreground">{active.text}</div>
                <div className="text-muted-foreground">{active.translation}</div>
                {active.role && (
                  <div className="mt-1 text-xs" style={{ color: accent }}>
                    {active.role}
                  </div>
                )}
                {active.ipa && (
                  <div className="mt-0.5 text-xs text-muted-foreground">/{active.ipa}/</div>
                )}
              </div>
              <button
                onClick={() => setActive(null)}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                ✕
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function splitIntoSegments(text: string, words: Word[]): { text: string; word?: Word }[] {
  const out: { text: string; word?: Word }[] = [];
  let remaining = text;
  const sorted = [...words].sort((a, b) => b.text.length - a.text.length);
  while (remaining.length > 0) {
    let matched = false;
    for (const w of sorted) {
      const idx = remaining.indexOf(w.text);
      if (idx === 0) {
        out.push({ text: w.text, word: w });
        remaining = remaining.slice(w.text.length);
        matched = true;
        break;
      }
    }
    if (!matched) {
      // find next occurrence of any word
      let nextIdx = remaining.length;
      for (const w of sorted) {
        const idx = remaining.indexOf(w.text);
        if (idx > -1 && idx < nextIdx) nextIdx = idx;
      }
      out.push({ text: remaining.slice(0, nextIdx) });
      remaining = remaining.slice(nextIdx);
    }
  }
  return out;
}
