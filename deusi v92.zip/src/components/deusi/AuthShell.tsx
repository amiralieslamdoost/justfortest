import { motion } from "@/lib/motion-lite";
import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/deusi/Logo";
import { ArrowLeft, Sparkles, BookOpen, Brain, Trophy } from "lucide-react";
import type { ReactNode } from "react";
import { FaHint } from "@/components/deusi/FaHint";

interface Props {
  title: string;
  subtitle: string;
  children: ReactNode;
  footer: ReactNode;
  side?: "login" | "register";
}

const features = [
  {
    icon: BookOpen,
    title: "Grammatik & Wortschatz",
    desc: "Strukturierte Lektionen von A1 bis C2.",
    fa: "گرامر و واژگان — درس‌های ساختاریافته از A1 تا C2",
  },
  {
    icon: Brain,
    title: "Leitner & FSRS",
    desc: "Intelligente Wiederholung, die wirklich funktioniert.",
    fa: "لایتنر و FSRS — مرور هوشمند که واقعاً جواب می‌ده",
  },
  {
    icon: Trophy,
    title: "Prüfungen üben",
    desc: "Realistische Aufgaben & Auswertungen.",
    fa: "تمرین آزمون — سؤال‌های واقعی و ارزیابی دقیق",
  },
];

export function AuthShell({ title, subtitle, children, footer, side = "login" }: Props) {
  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-background">
      {/* Ambient background */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div
          className="absolute -top-40 -left-32 h-[520px] w-[520px] rounded-full opacity-70 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(221,34,34,0.35), transparent 60%)" }}
        />
        <div
          className="absolute -bottom-40 -right-32 h-[520px] w-[520px] rounded-full opacity-60 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(247,201,72,0.35), transparent 60%)" }}
        />
        <div
          className="absolute top-1/2 left-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-40 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(26,26,26,0.18), transparent 60%)" }}
        />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: "radial-gradient(rgba(20,22,26,0.06) 1px, transparent 1px)",
            backgroundSize: "22px 22px",
          }}
        />
      </div>

      {/* Top bar — absolute so it doesn't push content off-center */}
      <div className="absolute inset-x-0 top-0 z-20 mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 sm:py-5">
        <Link to="/" aria-label="DEUSI">
          <Logo />
        </Link>
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/70 px-3 py-1.5 text-sm font-medium text-muted-foreground backdrop-blur transition hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> <span className="hidden sm:inline">Zurück</span>
        </Link>
      </div>

      <div className="mx-auto grid w-full max-w-7xl flex-1 grid-cols-1 items-center gap-10 px-4 pb-6 pt-20 sm:px-6 sm:pt-24 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:py-24">
        {/* Brand panel */}
        <motion.aside
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1] }}
          className="relative hidden overflow-hidden rounded-[2.5rem] p-10 text-white lg:block"
          style={{
            background:
              "linear-gradient(140deg, #1a1a1a 0%, #2a1010 40%, #DD2222 75%, #F7C948 130%)",
            boxShadow:
              "0 40px 100px -40px rgba(221,34,34,0.55), inset 0 1px 0 rgba(255,255,255,0.15)",
          }}
        >
          {/* Decorative shapes */}
          <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-2xl" />
            <div className="absolute -bottom-32 -left-24 h-80 w-80 rounded-full bg-black/30 blur-2xl" />
            <svg
              className="absolute right-8 top-8 h-24 w-24 opacity-20"
              viewBox="0 0 100 100"
              fill="none"
            >
              <polygon points="50,4 96,27 96,73 50,96 4,73 4,27" stroke="white" strokeWidth="1.5" />
              <polygon
                points="50,20 80,35 80,65 50,80 20,65 20,35"
                stroke="white"
                strokeWidth="1"
              />
            </svg>
          </div>

          <div className="relative flex h-full flex-col">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15, duration: 0.6 }}
              className="inline-flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-widest backdrop-blur"
            >
              <Sparkles className="h-3.5 w-3.5" style={{ color: "#F7C948" }} /> Deutsch lernen · neu
              gedacht
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25, duration: 0.7 }}
              className="mt-6 font-display text-5xl font-black leading-[1.05] tracking-tight"
            >
              {side === "login" ? (
                <>
                  Willkommen
                  <br />
                  zurück bei <span style={{ color: "#F7C948" }}>DEUSI</span>.
                </>
              ) : (
                <>
                  Starte deine
                  <br />
                  <span style={{ color: "#F7C948" }}>Deutsch-Reise</span>.
                </>
              )}
            </motion.h2>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="mt-4 max-w-md text-base text-white/80"
            >
              {side === "login"
                ? "Setze deine Serie fort, wiederhole deine Karten und meistere die nächste Prüfungsaufgabe."
                : "In 60 Sekunden angemeldet — dein persönlicher Lernpfad wartet schon auf dich."}
            </motion.p>

            <div className="mt-10 space-y-4">
              {features.map((f, i) => {
                const Icon = f.icon;
                return (
                  <motion.div
                    key={f.title}
                    initial={{ opacity: 0, x: -12 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + i * 0.1, duration: 0.5 }}
                    className="flex items-start gap-4 rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-sm"
                  >
                    <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/15 ring-1 ring-white/20">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold">{f.title}</div>
                      <div className="text-sm text-white/70">{f.desc}</div>
                      <div
                        lang="fa"
                        dir="rtl"
                        className="mt-1 text-[12px] text-white/60"
                        style={{ fontFamily: "YekanBakh, system-ui, sans-serif" }}
                      >
                        {f.fa}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9, duration: 0.6 }}
              className="mt-auto flex items-center gap-3 pt-10 text-sm text-white/70"
            >
              <div className="flex -space-x-2">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="grid h-8 w-8 place-items-center rounded-full border-2 border-white/30 text-xs font-bold"
                    style={{
                      background: ["#DD2222", "#F7C948", "#1a1a1a", "#ffffff20"][i],
                      color: i === 1 ? "#1a1a1a" : "#fff",
                    }}
                  >
                    {["M", "A", "L", "S"][i]}
                  </div>
                ))}
              </div>
              <span>
                <b className="text-white">10.000+</b> Lernende üben täglich
              </span>
            </motion.div>
          </div>
        </motion.aside>

        {/* Form panel */}
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.2, 0.8, 0.2, 1] }}
          className="mx-auto w-full max-w-md"
        >
          <div className="glass-strong rounded-3xl p-5 sm:rounded-[2rem] sm:p-8 md:p-10">
            <h1 className="font-display text-2xl font-black tracking-tight sm:text-3xl">{title}</h1>
            <FaHint size="sm">{side === "login" ? "ورود به حساب" : "ثبت‌نام رایگان"}</FaHint>
            <p className="mt-1.5 text-sm text-muted-foreground">{subtitle}</p>
            <div className="mt-5 sm:mt-7">{children}</div>
            <div className="mt-5 border-t border-border pt-4 text-center text-sm text-muted-foreground sm:mt-6 sm:pt-5">
              {footer}
            </div>
          </div>
          <p className="mt-4 text-center text-xs text-muted-foreground sm:mt-5">
            Mit der Anmeldung stimmst du unseren{" "}
            <Link className="font-semibold text-foreground hover:underline" to="/agb">
              Bedingungen
            </Link>{" "}
            und der{" "}
            <Link className="font-semibold text-foreground hover:underline" to="/datenschutz">
              Datenschutzerklärung
            </Link>{" "}
            zu.
          </p>
        </motion.section>
      </div>
    </div>
  );
}

export function AuthField({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: ReactNode;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-sm font-semibold text-foreground">{label}</span>
        {hint}
      </div>
      {children}
    </label>
  );
}
