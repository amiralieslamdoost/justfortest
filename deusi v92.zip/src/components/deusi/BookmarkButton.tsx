import { motion } from "@/lib/motion-lite";
import { Bookmark } from "lucide-react";
import { useInteractions, type InteractionType, type ItemMeta } from "@/lib/deusi/interactions";
import { cn } from "@/lib/utils";

interface Props extends ItemMeta {
  type: InteractionType;
  id: string;
  label?: string;
  size?: number;
  className?: string;
  variant?: "ghost" | "chip";
}

export function BookmarkButton({
  type,
  id,
  label,
  size = 18,
  className,
  variant = "ghost",
  title,
  sub,
  level,
  to,
}: Props) {
  const { isBookmarked, toggleBookmark } = useInteractions();
  const active = isBookmarked(type, id);

  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.85 }}
      whileHover={{ scale: 1.06 }}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleBookmark(type, id, { title: title ?? label, sub, level, to });
      }}
      aria-pressed={active}
      aria-label={active ? "Lesezeichen entfernen" : "Lesezeichen setzen"}
      className={cn(
        "focus-ring inline-grid place-items-center rounded-full transition-colors",
        variant === "chip"
          ? "h-8 w-8 bg-foreground/5 hover:bg-foreground/10"
          : "h-8 w-8 hover:bg-foreground/5",
        active && "text-[color:var(--accent)]",
        className,
      )}
    >
      <motion.span
        key={active ? "on" : "off"}
        initial={{ scale: 0.6, opacity: 0.4 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 500, damping: 22 }}
        className="inline-grid place-items-center"
      >
        <Bookmark
          width={size}
          height={size}
          className={active ? "fill-current" : ""}
          strokeWidth={1.8}
        />
      </motion.span>
    </motion.button>
  );
}
