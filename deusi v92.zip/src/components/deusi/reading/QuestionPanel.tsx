import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "@/lib/motion-lite";
import { Check, X as XIcon, ChevronLeft, ChevronRight, Sparkles } from "lucide-react";
import type { Question } from "@/lib/deusi/mockReading";

interface Props {
  questions: Question[];
  onFinish: (result: { correct: number; wrong: number; total: number }) => void;
}

interface Feedback {
  correct: boolean;
}

export function QuestionPanel({ questions, onFinish }: Props) {
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [feedback, setFeedback] = useState<Record<string, Feedback>>({});
  const q = questions[i];
  const total = questions.length;
  const answeredCount = Object.keys(feedback).length;
  const progress = Math.round((answeredCount / total) * 100);
  const currentChecked = feedback[q.id] !== undefined;
  const currentAnswer = answers[q.id];

  const correctCount = Object.entries(feedback).filter(([, v]) => v.correct).length;
  const wrongCount = Object.entries(feedback).filter(([, v]) => !v.correct).length;
  const remaining = total - answeredCount;

  function isCorrect(question: Question, given: string | string[] | undefined): boolean {
    if (given === undefined) return false;
    if (Array.isArray(question.answer)) {
      const a = Array.isArray(given) ? given : String(given).split("|");
      return (
        a.length === question.answer.length &&
        a.every((v, idx) => v.trim().toLowerCase() === question.answer[idx].toLowerCase())
      );
    }
    return String(given).trim().toLowerCase() === String(question.answer).toLowerCase();
  }

  function setAnswer(v: string | string[]) {
    if (currentChecked) return; // lock once checked
    setAnswers((prev) => ({ ...prev, [q.id]: v }));
  }

  function check() {
    if (
      currentAnswer === undefined ||
      currentAnswer === "" ||
      (Array.isArray(currentAnswer) && currentAnswer.length === 0)
    )
      return;
    const correct = isCorrect(q, currentAnswer);
    setFeedback((prev) => ({ ...prev, [q.id]: { correct } }));
  }

  function next() {
    if (i < total - 1) {
      setI(i + 1);
      return;
    }
    const c = Object.entries(feedback).filter(([, v]) => v.correct).length;
    const w = Object.entries(feedback).filter(([, v]) => !v.correct).length;
    onFinish({ correct: c, wrong: w, total });
  }

  function skip() {
    // mark as wrong and move on
    setFeedback((prev) => ({ ...prev, [q.id]: { correct: false } }));
    if (i < total - 1) setI(i + 1);
  }

  return (
    <div className="neu-card p-5 sm:p-6">
      {/* Header */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="text-lg font-bold sm:text-xl">Fragen beantworten</div>
          <div className="text-xs text-muted-foreground">
            Frage {i + 1} von {total} · Beantwortet {answeredCount}/{total}
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-1 font-semibold text-green-700 dark:bg-green-500/15 dark:text-green-300">
            <Check className="h-3 w-3" /> {correctCount}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-1 font-semibold text-red-700 dark:bg-red-500/15 dark:text-red-300">
            <XIcon className="h-3 w-3" /> {wrongCount}
          </span>
          <span className="rounded-full bg-secondary px-2 py-1 font-semibold text-muted-foreground">
            · {remaining}
          </span>
        </div>
      </div>

      <div className="mb-5 h-1.5 overflow-hidden rounded-full bg-secondary">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.35 }}
          className="h-full rounded-full bg-[var(--flag-red)]"
        />
      </div>

      {/* Question navigation dots */}
      <div className="mb-5 flex flex-wrap items-center gap-1.5">
        {questions.map((qq, idx) => {
          const state: "done" | "wrong" | "current" | "todo" = feedback[qq.id]
            ? feedback[qq.id].correct
              ? "done"
              : "wrong"
            : idx === i
              ? "current"
              : "todo";
          const cls =
            state === "done"
              ? "bg-green-500 text-white"
              : state === "wrong"
                ? "bg-red-500 text-white"
                : state === "current"
                  ? "bg-[var(--flag-black)] text-white ring-2 ring-offset-2 ring-[var(--flag-red)]"
                  : "bg-secondary text-muted-foreground";
          return (
            <button
              key={qq.id}
              onClick={() => setI(idx)}
              className={`h-9 w-9 shrink-0 rounded-full text-[11px] font-bold transition ${cls}`}
              aria-label={`Frage ${idx + 1}`}
            >
              {idx + 1}
            </button>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={q.id}
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -12 }}
          transition={{ duration: 0.2 }}
          className="space-y-4"
        >
          <div className="flex items-start gap-2 text-base font-semibold sm:text-lg">
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[var(--flag-red)] text-xs font-black text-white">
              {i + 1}
            </span>
            <span className="min-w-0">{q.prompt}</span>
          </div>

          {(q.type === "mcq" || q.type === "vocab") && q.options && (
            <div className="grid gap-2">
              {q.options.map((opt, idx) => {
                const val = String(idx);
                const selected = currentAnswer === val;
                const showAsCorrect = currentChecked && val === q.answer;
                const showAsWrong = currentChecked && selected && val !== q.answer;
                return (
                  <Option
                    key={idx}
                    letter={String.fromCharCode(65 + idx)}
                    label={opt}
                    selected={selected}
                    correct={showAsCorrect}
                    wrong={showAsWrong}
                    disabled={currentChecked}
                    onClick={() => setAnswer(val)}
                  />
                );
              })}
            </div>
          )}

          {q.type === "truefalse" && (
            <div className="grid grid-cols-2 gap-3">
              {["true", "false"].map((v) => {
                const selected = currentAnswer === v;
                const showAsCorrect = currentChecked && v === q.answer;
                const showAsWrong = currentChecked && selected && v !== q.answer;
                const base = "rounded-2xl border px-4 py-4 text-sm font-bold transition";
                const state = showAsCorrect
                  ? "border-green-500 bg-green-50 text-green-700 dark:bg-green-500/10"
                  : showAsWrong
                    ? "border-red-500 bg-red-50 text-red-700 dark:bg-red-500/10"
                    : selected
                      ? "border-primary bg-primary/5"
                      : "border-border hover:bg-secondary";
                return (
                  <button
                    key={v}
                    onClick={() => setAnswer(v)}
                    disabled={currentChecked}
                    className={`${base} ${state} disabled:cursor-not-allowed`}
                  >
                    {v === "true" ? "✓ Richtig" : "✗ Falsch"}
                  </button>
                );
              })}
            </div>
          )}

          {q.type === "fill" && (
            <FillInput
              value={typeof currentAnswer === "string" ? currentAnswer : ""}
              disabled={currentChecked}
              expected={typeof q.answer === "string" ? q.answer : ""}
              showResult={currentChecked}
              onChange={setAnswer}
            />
          )}

          {q.type === "match" && q.pairs && (
            <MatchGame
              pairs={q.pairs}
              disabled={currentChecked}
              expected={Array.isArray(q.answer) ? q.answer : []}
              answered={Array.isArray(currentAnswer) ? currentAnswer : undefined}
              onChange={setAnswer}
            />
          )}

          {currentChecked && q.explanation && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl bg-[#F3ECFF] p-3 text-sm text-[#4C1D95] dark:bg-[#6D28D9]/20 dark:text-[#DDD6FE]"
            >
              <div className="mb-1 inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="h-3 w-3" /> Erklärung
              </div>
              {q.explanation}
            </motion.div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Footer actions */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <button
          onClick={() => setI(Math.max(0, i - 1))}
          disabled={i === 0}
          className="inline-flex items-center gap-1 rounded-2xl border border-border px-4 py-2 text-sm font-semibold transition hover:bg-secondary disabled:opacity-40"
        >
          <ChevronLeft className="h-4 w-4" /> Zurück
        </button>

        <div className="flex flex-wrap items-center gap-2">
          {!currentChecked ? (
            <>
              <button
                onClick={skip}
                className="rounded-2xl px-3 py-2 text-xs font-semibold text-muted-foreground hover:bg-secondary"
              >
                Überspringen
              </button>
              <button
                onClick={check}
                disabled={
                  currentAnswer === undefined ||
                  currentAnswer === "" ||
                  (Array.isArray(currentAnswer) && currentAnswer.length === 0)
                }
                className="inline-flex items-center gap-1 rounded-2xl bg-[var(--flag-black)] px-5 py-2.5 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Prüfen <Check className="h-4 w-4" />
              </button>
            </>
          ) : (
            <button
              onClick={next}
              className="inline-flex items-center gap-1 rounded-2xl bg-[var(--flag-red)] px-5 py-2.5 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5"
            >
              {i < total - 1 ? "Weiter" : "Fertig"} <ChevronRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function Option({
  letter,
  label,
  selected,
  correct,
  wrong,
  disabled,
  onClick,
}: {
  letter: string;
  label: string;
  selected: boolean;
  correct: boolean;
  wrong: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  const state = correct
    ? "border-green-500 bg-green-50 dark:bg-green-500/10"
    : wrong
      ? "border-red-500 bg-red-50 dark:bg-red-500/10"
      : selected
        ? "border-primary bg-primary/5"
        : "border-border hover:bg-secondary";
  const dot = correct
    ? "bg-green-500 text-white"
    : wrong
      ? "bg-red-500 text-white"
      : selected
        ? "bg-primary text-primary-foreground"
        : "bg-secondary text-muted-foreground";
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex w-full items-start gap-3 rounded-2xl border px-4 py-3 text-left text-sm transition disabled:cursor-not-allowed ${state}`}
    >
      <span
        className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs font-bold ${dot}`}
      >
        {letter}
      </span>
      <span className="flex-1">{label}</span>
      {correct && <Check className="h-5 w-5 shrink-0 text-green-600" />}
      {wrong && <XIcon className="h-5 w-5 shrink-0 text-red-600" />}
    </button>
  );
}

function FillInput({
  value,
  onChange,
  disabled,
  expected,
  showResult,
}: {
  value: string;
  onChange: (v: string) => void;
  disabled: boolean;
  expected: string;
  showResult: boolean;
}) {
  const ok = showResult && value.trim().toLowerCase() === expected.toLowerCase();
  return (
    <div>
      <div className="relative">
        <input
          className={`w-full rounded-2xl border bg-secondary/40 px-4 py-3 pr-24 text-sm outline-none transition ${
            showResult
              ? ok
                ? "border-green-500 bg-green-50 dark:bg-green-500/10"
                : "border-red-500 bg-red-50 dark:bg-red-500/10"
              : "border-border focus:border-primary"
          }`}
          placeholder="Antwort eingeben..."
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
        />
        {showResult && (
          <span
            className={`absolute right-3 top-1/2 -translate-y-1/2 inline-flex items-center gap-1 text-xs font-bold ${ok ? "text-green-600" : "text-red-600"}`}
          >
            {ok ? (
              <>
                <Check className="h-4 w-4" /> Richtig
              </>
            ) : (
              <>
                <XIcon className="h-4 w-4" /> {expected}
              </>
            )}
          </span>
        )}
      </div>
    </div>
  );
}

function MatchGame({
  pairs,
  disabled,
  expected,
  answered,
  onChange,
}: {
  pairs: { left: string; right: string }[];
  disabled: boolean;
  expected: string[];
  answered?: string[];
  onChange: (v: string[]) => void;
}) {
  // Randomize right column once
  const rights = useMemo(
    () => [...pairs.map((p) => p.right)].sort(() => 0.5 - Math.random()),
    [pairs],
  );
  const [selection, setSelection] = useState<Record<string, string>>(() => {
    if (answered) {
      const acc: Record<string, string> = {};
      pairs.forEach((p, idx) => {
        if (answered[idx]) acc[p.left] = answered[idx];
      });
      return acc;
    }
    return {};
  });
  const [activeLeft, setActiveLeft] = useState<string | null>(null);

  function pickLeft(l: string) {
    if (disabled) return;
    setActiveLeft((prev) => (prev === l ? null : l));
  }
  function pickRight(r: string) {
    if (disabled || !activeLeft) return;
    const next = { ...selection };
    // remove r from other lefts
    for (const k of Object.keys(next)) if (next[k] === r) delete next[k];
    next[activeLeft] = r;
    setSelection(next);
    setActiveLeft(null);
    if (Object.keys(next).length === pairs.length) {
      onChange(pairs.map((p) => next[p.left] ?? ""));
    } else {
      onChange(pairs.map((p) => next[p.left] ?? ""));
    }
  }
  function clear(l: string) {
    if (disabled) return;
    const next = { ...selection };
    delete next[l];
    setSelection(next);
    onChange(pairs.map((p) => next[p.left] ?? ""));
  }

  return (
    <div>
      <div className="mb-2 text-xs text-muted-foreground">
        Tippe links auf ein Wort und dann rechts auf die passende Übersetzung.
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          {pairs.map((p, idx) => {
            const chosen = selection[p.left];
            const correct =
              disabled && chosen && chosen.toLowerCase() === expected[idx]?.toLowerCase();
            const wrong = disabled && chosen && !correct;
            const state = correct
              ? "border-green-500 bg-green-50 dark:bg-green-500/10"
              : wrong
                ? "border-red-500 bg-red-50 dark:bg-red-500/10"
                : activeLeft === p.left
                  ? "border-primary bg-primary/5"
                  : chosen
                    ? "border-border bg-secondary/60"
                    : "border-border hover:bg-secondary";
            return (
              <button
                key={p.left}
                onClick={() => pickLeft(p.left)}
                disabled={disabled}
                className={`flex w-full items-center justify-between rounded-2xl border px-3 py-2.5 text-left text-sm font-semibold transition ${state}`}
              >
                <span>{p.left}</span>
                {chosen && (
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <span className="rounded-full bg-white/70 px-2 py-0.5">{chosen}</span>
                    {!disabled && (
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          clear(p.left);
                        }}
                        className="grid h-5 w-5 place-items-center rounded-full hover:bg-red-100"
                      >
                        <XIcon className="h-3 w-3" />
                      </span>
                    )}
                  </span>
                )}
              </button>
            );
          })}
        </div>
        <div className="space-y-2">
          {rights.map((r) => {
            const used = Object.values(selection).includes(r);
            return (
              <button
                key={r}
                onClick={() => pickRight(r)}
                disabled={disabled || used || !activeLeft}
                className={`w-full rounded-2xl border px-3 py-2.5 text-left text-sm transition ${
                  used
                    ? "border-border bg-secondary/40 text-muted-foreground line-through"
                    : activeLeft
                      ? "border-primary/50 bg-primary/5 hover:bg-primary/10"
                      : "border-border hover:bg-secondary"
                }`}
              >
                {r}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
