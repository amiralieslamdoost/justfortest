/* Design: Quiet Lexicon — editorial study surface, warm-paper contrast, petrol-teal structure, and correct Yekan Bakh typography for Persian learning content. */
import { useState } from "react";
import { motion } from "@/lib/motion-lite";
import {
  ArrowLeft,
  ArrowRight,
  BookOpenText,
  Check,
  Rotate3D,
  RotateCcw,
  Volume2,
  X,
} from "lucide-react";
import type { VocabItem } from "@/lib/deusi/mockReading";

interface Props {
  vocab: VocabItem[];
  onFinish?: (summary: { known: number; learning: number; total: number }) => void;
}

const ARTICLE_TONES: Record<string, { bg: string; text: string; border: string }> = {
  der: { bg: "#e7f0ff", text: "#1d4ed8", border: "#bfdbfe" },
  die: { bg: "#fdebec", text: "#c91f37", border: "#fecdd3" },
  das: { bg: "#e8f7ee", text: "#15803d", border: "#bbf7d0" },
};

export function Flashcards({ vocab, onFinish }: Props) {
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<Set<string>>(new Set());
  const [learning, setLearning] = useState<Set<string>>(new Set());

  if (vocab.length === 0) {
    return (
      <div className="neu-card p-8 text-center">
        <div className="text-lg font-bold">Kein Wortschatz vorhanden</div>
        <p className="mt-2 text-sm text-muted-foreground">
          Speichere Wörter beim Lesen, um Karteikarten zu üben.
        </p>
      </div>
    );
  }

  const card = vocab[i];
  const total = vocab.length;
  const done = known.size + learning.size;
  const progress = Math.round((done / total) * 100);
  const articleTone = card.article ? ARTICLE_TONES[card.article] : undefined;

  function mark(kind: "known" | "learning") {
    const targetSet = kind === "known" ? new Set(known) : new Set(learning);
    targetSet.add(card.word);
    if (kind === "known") setKnown(targetSet);
    else setLearning(targetSet);
    setFlipped(false);

    if (i < total - 1) setI(i + 1);
    else {
      onFinish?.({
        known: kind === "known" ? targetSet.size : known.size,
        learning: kind === "learning" ? targetSet.size : learning.size,
        total,
      });
    }
  }

  function nav(direction: 1 | -1) {
    setFlipped(false);
    setI((current) => Math.min(total - 1, Math.max(0, current + direction)));
  }

  function pronounce() {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(card.word);
    utterance.lang = "de-DE";
    utterance.rate = 0.82;
    window.speechSynthesis.speak(utterance);
  }

  return (
    <section className="flashcard-workspace neu-card overflow-hidden p-4 sm:p-6 lg:p-7" aria-label="Wörter lernen">
      <div className="flashcard-heading">
        <div className="flex min-w-0 items-center gap-3">
          <img
            src="/manus-storage/deusiv-symbol_12b871fc.png"
            alt=""
            className="flashcard-brand-mark"
            onError={(event) => {
              event.currentTarget.style.display = "none";
            }}
          />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <h2 className="flashcard-heading-title">Wörter lernen</h2>
              <span className="flashcard-heading-dot" aria-hidden="true" />
              <span className="flashcard-heading-count">Karte {i + 1} von {total}</span>
            </div>
            <p className="flashcard-heading-helper">Erst erinnern, dann die Karte umdrehen.</p>
          </div>
        </div>
        <img
          src="/manus-storage/flashcard-study-banner_21de7416.png"
          alt=""
          className="flashcard-banner"
          onError={(event) => {
            event.currentTarget.style.display = "none";
          }}
        />
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flashcard-progress-track" aria-label={`${progress} Prozent abgeschlossen`}>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.35 }}
            className="flashcard-progress-value"
          />
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="flashcard-stat flashcard-stat-learning" title="Noch lernen">
            <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" /> {learning.size}
          </span>
          <span className="flashcard-stat flashcard-stat-known" title="Kenne ich">
            <Check className="h-3.5 w-3.5" aria-hidden="true" /> {known.size}
          </span>
        </div>
      </div>

      <div className="mt-5 sm:mt-6">
        <div className="flip-scene relative mx-auto h-[31rem] w-full max-w-[37rem] sm:h-[30rem]">
          <button
            type="button"
            onClick={() => setFlipped((value) => !value)}
            className={`flip-card h-full w-full text-left ${flipped ? "is-flipped" : ""}`}
            aria-label={flipped ? "Vorderseite der Karte zeigen" : "Karte umdrehen"}
            aria-pressed={flipped}
          >
            <div className="flip-face front flashcard-face flashcard-face-front">
              <img
                src="/manus-storage/flashcard-orbit_83a2132c.png"
                alt=""
                className="flashcard-orbit-art"
                onError={(event) => {
                  event.currentTarget.style.display = "none";
                }}
              />
              <div className="flashcard-face-content">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    {card.article && articleTone && (
                      <span
                        className="flashcard-article"
                        style={{
                          backgroundColor: articleTone.bg,
                          borderColor: articleTone.border,
                          color: articleTone.text,
                        }}
                      >
                        {card.article}
                      </span>
                    )}
                    <span className="flashcard-pos">{card.pos}</span>
                  </div>
                  <span className="flashcard-level">{card.level}</span>
                </div>

                <div className="my-auto py-8 text-center sm:py-10" lang="de">
                  <div className="flashcard-word">{card.word}</div>
                  <div className="mt-3 font-mono text-xs tracking-wide text-muted-foreground sm:text-sm">
                    {card.pronunciation}
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-black/6 pt-4 text-xs text-muted-foreground dark:border-white/10">
                  <span className="inline-flex items-center gap-2 font-semibold">
                    <Rotate3D className="h-4 w-4 text-[#0F766E]" aria-hidden="true" /> Karte umdrehen
                  </span>
                  <span className="flashcard-tap-key">Enter</span>
                </div>
              </div>
            </div>

            <div className="flip-face back flashcard-face flashcard-face-back">
              <div className="flashcard-face-content">
                <div className="flex items-center justify-between gap-3">
                  <span className="flashcard-back-kicker">
                    <BookOpenText className="h-4 w-4" aria-hidden="true" /> Bedeutung &amp; Kontext
                  </span>
                  <span className="flashcard-level">{card.level}</span>
                </div>

                <div className="flashcard-definition-grid mt-5">
                  <div className="flashcard-definition-cell">
                    <span className="flashcard-definition-label">English meaning</span>
                    <strong className="flashcard-definition-value" lang="en">{card.translation}</strong>
                  </div>
                  <div className="flashcard-definition-cell fa" dir="rtl">
                    <span className="flashcard-definition-label">معنی فارسی</span>
                    <strong className="flashcard-definition-value">{card.translationFa}</strong>
                  </div>
                </div>

                <div className="flashcard-example mt-4" lang="de">
                  <span className="flashcard-example-label">Beispielsatz</span>
                  <p>„{card.example}“</p>
                </div>

                <div className="flashcard-example flashcard-example-fa fa mt-3" dir="rtl">
                  <span className="flashcard-example-label">ترجمهٔ جمله</span>
                  <p>{card.exampleTranslation}</p>
                </div>

                <div className="mt-auto flex items-center gap-2 border-t border-black/6 pt-4 text-xs text-muted-foreground dark:border-white/10">
                  <Rotate3D className="h-4 w-4 text-[#0F766E]" aria-hidden="true" /> Zum Wort zurückkehren
                </div>
              </div>
            </div>
          </button>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-[2.75rem_minmax(0,1fr)_2.75rem] items-center gap-2 sm:mt-6 sm:gap-3">
        <button type="button" onClick={() => nav(-1)} disabled={i === 0} className="flashcard-nav-button" aria-label="Vorherige Karte">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="flex min-w-0 flex-wrap items-center justify-center gap-2">
          <button type="button" onClick={pronounce} className="flashcard-utility-button">
            <Volume2 className="h-4 w-4" aria-hidden="true" /> <span>Aussprache</span>
          </button>
          <button type="button" onClick={() => setFlipped((value) => !value)} className="flashcard-utility-button">
            <RotateCcw className="h-4 w-4" aria-hidden="true" /> <span>Umdrehen</span>
          </button>
        </div>
        <button type="button" onClick={() => nav(1)} disabled={i === total - 1} className="flashcard-nav-button" aria-label="Nächste Karte">
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2.5 sm:gap-3">
        <button type="button" onClick={() => mark("learning")} className="flashcard-decision flashcard-decision-learning">
          <X className="h-4 w-4 shrink-0" aria-hidden="true" /> <span>Noch lernen</span>
        </button>
        <button type="button" onClick={() => mark("known")} className="flashcard-decision flashcard-decision-known">
          <Check className="h-4 w-4 shrink-0" aria-hidden="true" /> <span>Kenne ich</span>
        </button>
      </div>
    </section>
  );
}
