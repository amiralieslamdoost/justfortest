import { Link } from "@tanstack/react-router";
import { motion } from "@/lib/motion-lite";
import { Clock, ArrowUpRight, CheckCircle2, BookOpen } from "lucide-react";
import type { Article } from "@/lib/deusi/mockReading";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";
import { FavoriteButton } from "@/components/deusi/FavoriteButton";

interface Props {
  article: Article;
  variant?: "list" | "grid";
}

const CATEGORY_COLOR: Record<string, string> = {
  nachrichten: "#3B82F6",
  kultur: "#8B5CF6",
  wissenschaft: "#22C55E",
  geschichten: "#F97316",
  reisen: "#0EA5E9",
  alltag: "#EAB308",
  technologie: "#6366F1",
  natur: "#10B981",
  bildung: "#EF4444",
  sport: "#F43F5E",
};

function hexToRgba(hex: string, alpha: number) {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function ArticleCard({ article, variant = "list" }: Props) {
  const color = CATEGORY_COLOR[article.category] ?? "#DD2222";
  const done = article.progress >= 100;
  const started = article.progress > 0 && !done;

  if (variant === "grid") {
    return (
      <Link to="/lesen/$articleId" params={{ articleId: article.id }} className="block h-full">
        <motion.div
          whileHover={{ y: -6 }}
          transition={{ type: "spring", stiffness: 260, damping: 22 }}
          className="group relative flex h-full flex-col overflow-hidden rounded-3xl bg-card ring-1 ring-border transition-all duration-300 hover:ring-2"
          style={{
            boxShadow: `0 1px 2px rgba(0,0,0,.04), 0 8px 24px -12px ${hexToRgba(color, 0.18)}`,
          }}
        >
          {/* Top accent glow */}
          <div
            className="pointer-events-none absolute inset-x-0 top-0 h-24 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
            style={{
              background: `radial-gradient(60% 100% at 50% 0%, ${hexToRgba(color, 0.25)}, transparent)`,
            }}
            aria-hidden
          />

          <div className="relative aspect-[16/10] overflow-hidden">
            <img
              loading="lazy"
              decoding="async"
              src={article.cover}
              alt={article.title}
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />

            {/* Category chip */}
            <span
              className="absolute left-3 top-3 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-lg backdrop-blur-md ring-1 ring-white/20"
              style={{ background: hexToRgba(color, 0.9) }}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-white shadow-[0_0_6px_rgba(255,255,255,0.9)]" />
              {article.category}
            </span>

            {/* Level pill */}
            <span className="absolute right-3 top-3 rounded-full bg-white/95 px-2.5 py-1 text-[10px] font-black text-foreground shadow-md ring-1 ring-black/5 backdrop-blur">
              {article.level}
            </span>

            {/* Title + CTA */}
            <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-2 text-white">
              <div className="line-clamp-2 flex-1 text-sm font-black leading-tight drop-shadow-lg sm:text-base">
                {article.title}
              </div>
              <div
                className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white shadow-lg ring-1 ring-black/5 transition-transform duration-300 group-hover:rotate-45 group-hover:scale-110"
                style={{ color }}
              >
                <ArrowUpRight className="h-4 w-4" />
              </div>
            </div>

            {/* Progress bar */}
            {(started || done) && (
              <div className="absolute inset-x-0 bottom-0 h-1 bg-black/20">
                <div
                  className="h-full transition-all"
                  style={{
                    width: `${article.progress}%`,
                    background: `linear-gradient(90deg, ${color}, ${hexToRgba(color, 0.7)})`,
                    boxShadow: `0 0 12px ${hexToRgba(color, 0.7)}`,
                  }}
                />
              </div>
            )}
          </div>

          <div className="flex flex-1 items-center justify-between gap-2 px-4 py-3">
            <div className="flex min-w-0 items-center gap-2.5 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1 font-medium">
                <Clock className="h-3 w-3" /> {article.minutes} Min
              </span>
              {done ? (
                <span className="inline-flex items-center gap-1 font-bold" style={{ color }}>
                  <CheckCircle2 className="h-3 w-3" /> Gelesen
                </span>
              ) : started ? (
                <span className="inline-flex items-center gap-1 font-bold" style={{ color }}>
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
                  {article.progress}%
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 font-semibold text-muted-foreground/80">
                  <BookOpen className="h-3 w-3" /> Neu
                </span>
              )}
            </div>
            <div className="flex items-center gap-0.5">
              <BookmarkButton
                type="article"
                id={article.id}
                title={article.title}
                sub={article.description}
                level={article.level}
                to={`/lesen/${article.id}`}
              />
              <FavoriteButton
                type="article"
                id={article.id}
                title={article.title}
                sub={article.description}
                level={article.level}
                to={`/lesen/${article.id}`}
              />
            </div>
          </div>
        </motion.div>
      </Link>
    );
  }

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 300, damping: 24 }}
      className="group relative flex gap-3 overflow-hidden rounded-3xl bg-card p-3 ring-1 ring-border transition-all duration-300 hover:ring-2 sm:gap-4 sm:p-4"
      style={{
        boxShadow: `0 1px 2px rgba(0,0,0,.03), 0 6px 20px -14px ${hexToRgba(color, 0.35)}`,
      }}
    >
      {/* Left accent bar with gradient */}
      <div
        className="absolute inset-y-4 left-0 w-1 rounded-r-full opacity-80 transition-all duration-300 group-hover:w-1.5 group-hover:opacity-100"
        style={{ background: `linear-gradient(180deg, ${color}, ${hexToRgba(color, 0.4)})` }}
        aria-hidden
      />

      {/* Ambient hover glow */}
      <div
        className="pointer-events-none absolute inset-y-0 left-0 w-40 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background: `radial-gradient(60% 100% at 0% 50%, ${hexToRgba(color, 0.12)}, transparent)`,
        }}
        aria-hidden
      />

      <Link
        to="/lesen/$articleId"
        params={{ articleId: article.id }}
        className="relative shrink-0 self-stretch"
      >
        <div className="relative h-full min-h-20 w-20 overflow-hidden rounded-2xl ring-1 ring-black/5 sm:min-h-32 sm:w-48">
          <img
            loading="lazy"
            decoding="async"
            src={article.cover}
            alt={article.title}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          {/* Color-tinted vignette */}
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(135deg, ${hexToRgba(color, 0.35)} 0%, transparent 45%, rgba(0,0,0,0.35) 100%)`,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-tr from-black/40 via-transparent to-transparent" />

          {/* Level pill on image */}
          <span className="absolute left-1.5 top-1.5 rounded-md bg-white/95 px-1.5 py-0.5 text-[9px] font-black text-foreground shadow ring-1 ring-black/5 backdrop-blur sm:left-2 sm:top-2 sm:px-2 sm:py-1 sm:text-[10px]">
            {article.level}
          </span>

          {/* Minutes badge bottom-left on desktop */}
          <span className="absolute bottom-1.5 left-1.5 hidden items-center gap-1 rounded-md bg-black/55 px-1.5 py-0.5 text-[10px] font-bold text-white backdrop-blur-sm sm:inline-flex">
            <Clock className="h-3 w-3" /> {article.minutes}′
          </span>

          {/* Progress bar */}
          {(started || done) && (
            <div className="absolute inset-x-0 bottom-0 h-1 bg-black/30">
              <div
                className="h-full"
                style={{
                  width: `${article.progress}%`,
                  background: color,
                  boxShadow: `0 0 8px ${hexToRgba(color, 0.7)}`,
                }}
                aria-hidden
              />
            </div>
          )}
        </div>
      </Link>

      <div className="flex min-w-0 flex-1 flex-col justify-center gap-1.5">
        {/* Top row: category + progress */}
        <div className="flex items-center justify-between gap-2">
          <span
            className="inline-flex min-w-0 items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider sm:text-[11px]"
            style={{ background: hexToRgba(color, 0.1), color }}
          >
            <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: color }} />
            <span className="truncate">{article.category}</span>
          </span>
          <ProgressRing value={article.progress} color={color} />
        </div>

        {/* Title */}
        <Link
          to="/lesen/$articleId"
          params={{ articleId: article.id }}
          className="line-clamp-2 text-sm font-black leading-snug text-foreground transition-colors sm:text-base"
          style={{ ["--hover-color" as string]: color }}
        >
          <span
            className="bg-gradient-to-r from-foreground to-foreground bg-[length:0%_2px] bg-left-bottom bg-no-repeat transition-[background-size] duration-300 group-hover:bg-[length:100%_2px]"
            style={{ backgroundImage: `linear-gradient(90deg, ${color}, ${color})` }}
          >
            {article.title}
          </span>
        </Link>

        {/* Description (desktop) */}
        <div className="line-clamp-1 hidden text-sm text-muted-foreground sm:block">
          {article.description}
        </div>

        {/* Meta row */}
        <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1 font-medium">
            <Clock className="h-3 w-3" /> {article.minutes} Min
          </span>
          {done && (
            <span className="inline-flex items-center gap-1 font-bold" style={{ color }}>
              <CheckCircle2 className="h-3 w-3" /> Gelesen
            </span>
          )}
          {started && (
            <span className="inline-flex items-center gap-1 font-bold" style={{ color }}>
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
              Läuft
            </span>
          )}
          <div className="ml-auto flex items-center gap-0.5">
            <BookmarkButton
              type="article"
              id={article.id}
              title={article.title}
              sub={article.description}
              level={article.level}
              to={`/lesen/${article.id}`}
            />
            <FavoriteButton
              type="article"
              id={article.id}
              title={article.title}
              sub={article.description}
              level={article.level}
              to={`/lesen/${article.id}`}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function ProgressRing({ value, color }: { value: number; color: string }) {
  const r = 18,
    c = 2 * Math.PI * r;
  const off = c - (value / 100) * c;
  if (value === 0) {
    return (
      <span
        className="shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1"
        style={{ background: hexToRgba(color, 0.08), color, borderColor: hexToRgba(color, 0.2) }}
      >
        Neu
      </span>
    );
  }
  if (value >= 100) {
    return (
      <span
        className="inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold"
        style={{ background: hexToRgba(color, 0.12), color }}
      >
        <CheckCircle2 className="h-3 w-3" /> 100%
      </span>
    );
  }
  return (
    <div className="relative h-10 w-10 shrink-0" title={`${value}%`}>
      <svg viewBox="0 0 44 44" className="h-full w-full -rotate-90">
        <circle cx="22" cy="22" r={r} stroke="var(--secondary)" strokeWidth="4" fill="none" />
        <circle
          cx="22"
          cy="22"
          r={r}
          stroke={color}
          strokeWidth="4"
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={off}
          strokeLinecap="round"
          style={{
            transition: "stroke-dashoffset 700ms",
            filter: `drop-shadow(0 0 3px ${hexToRgba(color, 0.5)})`,
          }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <span className="text-[9px] font-black" style={{ color }}>
          {value}%
        </span>
      </div>
    </div>
  );
}
