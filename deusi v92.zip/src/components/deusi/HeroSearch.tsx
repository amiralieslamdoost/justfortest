import * as React from "react";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import { Search, X, Clock, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export type HeroSearchItem = {
  id: string;
  title: string;
  sub?: string;
  badge?: string;
  /** Emoji / short glyph shown in the leading tile */
  glyph?: React.ReactNode;
  color?: string;
};

type Props = {
  value: string;
  onValueChange: (v: string) => void;
  /** Live results for the current query (already filtered & sliced by caller) */
  items: HeroSearchItem[];
  /** Total number of matches — used for the "show all" footer */
  totalCount?: number;
  onSelect: (id: string) => void;
  /** Enter / "alle Ergebnisse" — usually scrolls to the results list */
  onSubmit?: () => void;
  placeholder?: string;
  ariaLabel?: string;
  emptyText?: string;
  className?: string;
};

const RECENT_LIMIT = 5;

/**
 * Unified hero search — same UX as the dictionary header:
 * type → instant suggestion dropdown → pick one, instead of silently
 * filtering a list far down the page.
 */
export function HeroSearch({
  value,
  onValueChange,
  items,
  totalCount,
  onSelect,
  onSubmit,
  placeholder = "Suchen…",
  ariaLabel,
  emptyText = "Keine Ergebnisse",
  className,
}: Props) {
  const [open, setOpen] = React.useState(false);
  const [recent, setRecent] = React.useState<string[]>([]);
  const total = totalCount ?? items.length;

  const remember = (q: string) => {
    const t = q.trim();
    if (!t) return;
    setRecent((prev) => [t, ...prev.filter((x) => x !== t)].slice(0, RECENT_LIMIT));
  };

  const submit = () => {
    remember(value);
    setOpen(false);
    onSubmit?.();
  };

  return (
    <div className={cn("relative z-40 w-full sm:min-w-[300px]", className)}>
      <div className="group relative flex w-full items-center gap-2 rounded-2xl border border-white/25 bg-white/12 px-3 shadow-[0_18px_40px_-24px_rgba(0,0,0,.7)] backdrop-blur-md transition-all focus-within:border-white/50 focus-within:bg-white/20 focus-within:ring-2 focus-within:ring-white/25">
        <Search className="h-4 w-4 shrink-0 text-white/70" aria-hidden />
        <input
          value={value}
          onChange={(e) => {
            onValueChange(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 150)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={placeholder}
          aria-label={ariaLabel ?? placeholder}
          className="min-w-0 flex-1 bg-transparent py-2.5 text-sm font-medium text-white outline-none placeholder:text-white/60"
        />
        {value && (
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => onValueChange("")}
            aria-label="Suche löschen"
            className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-white/70 transition hover:bg-white/20 hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      <AnimatePresence>
        {open && (value || recent.length > 0) && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            transition={{ duration: 0.15 }}
            className="absolute left-0 right-0 top-full z-[100] mt-2 max-h-80 overflow-y-auto rounded-2xl border border-border/70 bg-card p-2 text-foreground shadow-2xl ring-1 ring-black/5"
          >
            {value && items.length > 0 && (
              <div>
                <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                  Vorschläge
                </div>
                {items.map((s) => (
                  <button
                    key={s.id}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      remember(value);
                      setOpen(false);
                      onSelect(s.id);
                    }}
                    className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left transition hover:bg-muted"
                  >
                    {s.glyph !== undefined && (
                      <span
                        className="grid h-8 w-8 shrink-0 place-items-center overflow-hidden rounded-lg text-base"
                        style={{ background: (s.color ?? "#64748B") + "22" }}
                      >
                        {s.glyph}
                      </span>
                    )}
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold">{s.title}</span>
                      {s.sub && (
                        <span className="block truncate text-[11px] text-muted-foreground">
                          {s.sub}
                        </span>
                      )}
                    </span>
                    {s.badge && (
                      <span className="shrink-0 rounded-md bg-secondary px-1.5 py-0.5 text-[10px] font-black">
                        {s.badge}
                      </span>
                    )}
                  </button>
                ))}
                {onSubmit && total > items.length && (
                  <button
                    onMouseDown={(e) => {
                      e.preventDefault();
                      submit();
                    }}
                    className="mt-1 flex w-full items-center justify-between rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold transition hover:bg-secondary"
                  >
                    Alle {total} Ergebnisse anzeigen
                    <ArrowRight className="h-3.5 w-3.5" aria-hidden />
                  </button>
                )}
              </div>
            )}

            {value && items.length === 0 && (
              <div className="px-3 py-6 text-center text-sm text-muted-foreground">
                {emptyText} für „{value}"
              </div>
            )}

            {!value && recent.length > 0 && (
              <div>
                <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                  Letzte Suchen
                </div>
                {recent.map((r) => (
                  <button
                    key={r}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      onValueChange(r);
                      setOpen(true);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm transition hover:bg-muted"
                  >
                    <Clock className="h-3.5 w-3.5 text-muted-foreground" aria-hidden />
                    {r}
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
