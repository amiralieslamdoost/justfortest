# seed مدیا (سشن ۵)

- `media.ts` — تبدیل داده‌های ماک (`mockKino`, `mockMusic`, `mockPodcasts`, `dictionary/books`) به رکوردهای PocketBase.
- `seed-media.ts` — اجرای seed.

```bash
bun backend/seed/seed-media.ts --json                     # فقط خروجی JSON در out/
bun backend/seed/seed-media.ts http://127.0.0.1:8090 admin@example.com pass
```

رکوردها بر اساس `slug` upsert می‌شوند؛ اجرای چندباره داده تکراری نمی‌سازد.
ترتیب: films → artists → songs (relation هنرمند) → podcast_shows → episodes → books.
