# سشن ۵ — اتصال دامنهٔ Media (Kino / Musik / Podcasts / Books) به PocketBase

## ۰. پیش‌نیاز: بازگرداندن پروژه
پروژهٔ این اکانت در حال حاضر خالی است (فقط تمپلیت). ابتدا محتوای `deusi_v77.zip` (خروجی سشن ۴) بدون `node_modules` و بدون `.git` در ریشهٔ پروژه بازگردانی می‌شود، وابستگی‌ها نصب و یک build سالم گرفته می‌شود؛ ساختار Vite Static SPA + TanStack Router دست‌نخورده می‌ماند.

## ۱. قواعد ثابت سشن
- بدون SSR / Lovable Cloud / Supabase / react-router-dom. `vite.config.ts`، `src/main.tsx` و `index.html` از حالت SPA خارج نمی‌شوند.
- ظاهر، زبان آلمانی/فارسی، RTL و توکن‌های `src/styles.css` دست نمی‌خورند.
- `MOCK_MODE` حفظ می‌شود: بدون `VITE_PB_URL` همان دیتای mock فعلی کار می‌کند.
- فقط دامنهٔ Media تغییر می‌کند؛ به گرامر/خواندن/واژگان و بقیهٔ دامنه‌ها دست نمی‌زنیم.

## ۲. لایهٔ داده (هم‌الگوی سشن ۴)
فایل‌های جدید در `src/lib/api/`:
- `media.ts` — نگاشت رکورد↔مدل UI برای `films`، `songs` (+`artists`)، `episodes` (+`podcast_shows`) و `books`؛ فهرست با صفحه‌بندی و فیلتر سمت سرور (سطح، ژانر/دسته، جست‌وجو)، دریافت تکی با slug، ساخت URL کاور/ویدیو/صوت از PocketBase files با fallback به `cover`/`video_url`/`audio_url`، کش محلی و fallback به mock.
- `mediaProgress.ts` — خواندن/نوشتن `media_progress`: `position_sec`، `progress`، `finished`، `plays`، `quiz_answers`، `quiz_score`، `last_played_at`؛ نوشتن‌ها throttle شده، از طریق `offline-queue` موجود (IndexedDB) با optimistic update.
- `mediaVocab.ts` — ذخیرهٔ واژه از داخل مدیا در `media_vocab` و افزودن به `user_words` (با استفاده از `musicVocab.ts` و مسیر موجود واژگان؛ فیلد `added_to_srs`).
- `useMedia.ts` — هوک‌های TanStack Query: `useFilms/useFilm`، `useSongs/useSong`، `useEpisodes/useEpisode`، `useBooks/useBook`، `useMediaProgress(type, id)`، `useSaveMediaWord`.
- `queryKeys.ts` — گسترش کلیدهای `media` برای حالت‌های صفحه‌بندی/فیلتر و progress هر آیتم.

## ۳. اتصال روت‌ها (فقط جایگزینی منبع داده)
`kino.index`، `kino.$filmId`، `musik.index`، `musik.$songId`، `podcasts.index`، `podcasts.$episodeId`، `books.index`، `books.$bookId`:
- خواندن دیتا از هوک‌ها به‌جای import مستقیم mock.
- ادامهٔ پخش از آخرین موقعیت، ذخیرهٔ خودکار پیشرفت هنگام پخش/توقف/خروج، علامت «تمام‌شده».
- ذخیرهٔ نتیجهٔ کوئیز پادکست و پیشرفت مطالعهٔ کتاب در `media_progress`.
- دکمهٔ ذخیرهٔ واژه در ترانه/زیرنویس/ترنسکریپت → `media_vocab` + `user_words`.
- حالت loading/error/empty هم‌راستا با صفحات سشن ۴، بدون تغییر چیدمان و ظاهر.

## ۴. Seed محتوا
`scripts/seed-media.ts` (هم‌الگوی `scripts/seed-content.ts`، idempotent روی slug): انتقال `mockKino.ts`، `mockMusic.ts`، `mockPodcasts.ts` و `dictionary/books.ts` به `films`/`artists`/`songs`/`podcast_shows`/`episodes`/`books`، به‌همراه راهنمای اجرا در `backend/seed/README-FA.md` و افزودن اسکریپت به `package.json`.

## ۵. تحویل و بستن سشن
- build کامل + رفع همهٔ خطاهای TypeScript/build.
- تست هر ۸ روت در حالت MOCK (بدون `VITE_PB_URL`).
- خروجی: زیپ کامل پروژه بدون `node_modules` به‌عنوان ورودی سشن ۶.

## نکات فنی
اسکیمای موجود برای مدیا کافی است، پس به `pb_schema.json` دست نمی‌زنیم مگر کمبودی دیده شود؛ در آن صورت فقط فیلد لازم اضافه و `API-RULES.md`/`SCHEMA-FA.md` به‌روزرسانی و گزارش می‌شود. محتوای عمومی مدیا فقط-خواندنی می‌ماند و پیشرفت/واژهٔ کاربر با قواعد `@request.auth.id` محدود است.