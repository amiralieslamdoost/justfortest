import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";
import { ErrorCard } from "@/components/deusi/ErrorCard";
import { NotFoundPage } from "@/components/deusi/NotFound";
import { SkelPage } from "@/components/deusi/Skeletons";

export const getRouter = () => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
    defaultErrorComponent: ({ error, reset }) => <ErrorCard error={error} reset={reset} />,
    defaultNotFoundComponent: () => <NotFoundPage />,
    defaultPendingComponent: () => <SkelPage />,
    defaultPendingMs: 200,
  });

  return router;
};
