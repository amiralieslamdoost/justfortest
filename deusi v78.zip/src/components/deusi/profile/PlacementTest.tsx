import { Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FaHint } from "@/components/deusi/FaHint";
import { GraduationCap, CheckCircle2, XCircle, RotateCcw, ArrowRight } from "lucide-react";

type Q = {
  id: string;
  level: "A1" | "A2" | "B1" | "B2" | "C1";
  question: string;
  options: string[];
  correct: number;
  explain: string;
};

const QUESTIONS: Q[] = [
  {
    id: "q1",
    level: "A1",
    question: "Wie ___ du?",
    options: ["heißt", "heißen", "heiße", "heißst"],
    correct: 0,
    explain: "2. Person Singular: du heißt.",
  },
  {
    id: "q2",
    level: "A1",
    question: "Ich ___ aus dem Iran.",
    options: ["bin", "bist", "ist", "sind"],
    correct: 0,
    explain: "1. Person Singular von sein: ich bin.",
  },
  {
    id: "q3",
    level: "A2",
    question: "Gestern ___ ich ins Kino gegangen.",
    options: ["habe", "bin", "war", "hatte"],
    correct: 1,
    explain: "Bewegungsverben bilden Perfekt mit sein.",
  },
  {
    id: "q4",
    level: "A2",
    question: "Der Mann, ___ Auto rot ist, wohnt hier.",
    options: ["der", "dessen", "den", "dem"],
    correct: 1,
    explain: "Relativpronomen im Genitiv: dessen.",
  },
  {
    id: "q5",
    level: "B1",
    question: "Wenn ich Zeit ___, würde ich mehr lesen.",
    options: ["hätte", "habe", "hatte", "haben"],
    correct: 0,
    explain: "Konjunktiv II Gegenwart: hätte.",
  },
  {
    id: "q6",
    level: "B1",
    question: "Das Buch wurde von ihm ___.",
    options: ["geschrieben", "schreiben", "geschrieben werden", "schreibt"],
    correct: 0,
    explain: "Vorgangspassiv Perfekt: wurde … geschrieben.",
  },
  {
    id: "q7",
    level: "B2",
    question: "Er tat so, ___ er alles verstanden hätte.",
    options: ["als ob", "obwohl", "damit", "weil"],
    correct: 0,
    explain: "Irrealer Vergleich mit als ob + Konjunktiv II.",
  },
  {
    id: "q8",
    level: "B2",
    question: "___ des schlechten Wetters fand das Konzert statt.",
    options: ["Trotz", "Wegen", "Während", "Statt"],
    correct: 0,
    explain: "Trotz + Genitiv drückt Konzession aus.",
  },
  {
    id: "q9",
    level: "C1",
    question: "Er ließ sich nicht ___, seine Meinung zu ändern.",
    options: ["dazu bewegen", "bewegen dazu", "bewegen", "bewegt"],
    correct: 0,
    explain: "Feste Verbverbindung: sich (dazu) bewegen lassen.",
  },
  {
    id: "q10",
    level: "C1",
    question: "___ er auch versuchte, es gelang ihm nicht.",
    options: ["Wie sehr", "Obwohl", "Wenn", "Als"],
    correct: 0,
    explain: "Konzessive Konstruktion: Wie sehr … auch.",
  },
];

function scoreToLevel(correct: number): { level: string; label: string; color: string } {
  if (correct <= 2) return { level: "A1", label: "Anfänger", color: "#22C55E" };
  if (correct <= 4) return { level: "A2", label: "Grundstufe", color: "#10B981" };
  if (correct <= 6) return { level: "B1", label: "Mittelstufe", color: "#3B82F6" };
  if (correct <= 8) return { level: "B2", label: "Obere Mittelstufe", color: "#8B5CF6" };
  return { level: "C1", label: "Fortgeschritten", color: "#DD2222" };
}

export function PlacementTest() {
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [done, setDone] = useState(false);

  const q = QUESTIONS[i];
  const answered = answers[q.id] !== undefined;
  const correctCount = useMemo(
    () => QUESTIONS.reduce((n, qq) => (answers[qq.id] === qq.correct ? n + 1 : n), 0),
    [answers],
  );

  if (done) {
    const res = scoreToLevel(correctCount);
    return (
      <div className="space-y-4">
        <TestHeader />
        <div className="glass-strong mx-auto max-w-3xl rounded-3xl p-8 text-center">
          <div
            className="mx-auto grid h-24 w-24 place-items-center rounded-full text-3xl font-black text-white shadow-xl"
            style={{ background: `linear-gradient(135deg, ${res.color}, ${res.color}cc)` }}
          >
            {res.level}
          </div>
          <h2 className="mt-5 text-2xl font-bold">Dein Niveau: {res.label}</h2>
          <FaHint>سطح شما بر اساس این تست</FaHint>
          <p className="mt-3 text-muted-foreground">
            Du hast{" "}
            <strong className="text-foreground">
              {correctCount} von {QUESTIONS.length}
            </strong>{" "}
            Fragen richtig beantwortet.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-5">
            {QUESTIONS.map((qq) => {
              const ok = answers[qq.id] === qq.correct;
              return (
                <div
                  key={qq.id}
                  className={`rounded-xl border p-2 text-center text-xs font-semibold ${ok ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-500" : "border-red-500/40 bg-red-500/10 text-red-500"}`}
                >
                  {qq.level}
                </div>
              );
            })}
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              onClick={() => {
                setAnswers({});
                setI(0);
                setDone(false);
              }}
              className="inline-flex items-center gap-2 rounded-xl border border-border/60 bg-card px-5 py-2.5 text-sm font-semibold hover:bg-secondary"
            >
              <RotateCcw className="h-4 w-4" /> Wiederholen
            </button>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold text-white shadow-lg"
              style={{ background: "linear-gradient(135deg,#8B5CF6,#DD2222)" }}
            >
              Zum Dashboard <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <TestHeader />
      <div className="glass-strong mx-auto max-w-3xl rounded-3xl p-6 sm:p-8">
        <div className="mb-4 flex items-center justify-between text-xs font-semibold text-muted-foreground">
          <span>
            Frage {i + 1} / {QUESTIONS.length}
          </span>
          <span className="rounded-full bg-secondary px-2 py-0.5">{q.level}</span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full rounded-full transition-all"
            style={{
              width: `${((i + 1) / QUESTIONS.length) * 100}%`,
              background: "linear-gradient(90deg,#8B5CF6,#DD2222)",
            }}
          />
        </div>

        <h2 className="mt-6 text-xl font-bold leading-relaxed">{q.question}</h2>

        <div className="mt-5 space-y-2.5">
          {q.options.map((opt, idx) => {
            const chosen = answers[q.id] === idx;
            const isCorrect = idx === q.correct;
            const showState = answered;
            return (
              <button
                key={idx}
                disabled={answered}
                onClick={() => setAnswers({ ...answers, [q.id]: idx })}
                className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
                  showState && isCorrect
                    ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                    : showState && chosen && !isCorrect
                      ? "border-red-500/50 bg-red-500/10 text-red-600 dark:text-red-400"
                      : chosen
                        ? "border-[color:var(--accent)] bg-secondary"
                        : "border-border/60 bg-card hover:bg-secondary"
                }`}
              >
                <span>{opt}</span>
                {showState && isCorrect && <CheckCircle2 className="h-4 w-4" />}
                {showState && chosen && !isCorrect && <XCircle className="h-4 w-4" />}
              </button>
            );
          })}
        </div>

        {answered && (
          <div className="mt-4 rounded-xl border border-border/60 bg-secondary/60 p-3 text-sm">
            <div className="font-semibold">Erklärung</div>
            <div className="mt-1 text-muted-foreground">{q.explain}</div>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            disabled={!answered}
            onClick={() => (i + 1 < QUESTIONS.length ? setI(i + 1) : setDone(true))}
            className="inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold text-white shadow-lg disabled:opacity-40"
            style={{ background: "linear-gradient(135deg,#8B5CF6,#DD2222)" }}
          >
            {i + 1 < QUESTIONS.length ? "Weiter" : "Ergebnis anzeigen"}{" "}
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

function TestHeader() {
  return (
    <div
      className="relative overflow-hidden rounded-3xl p-6 sm:p-8"
      style={{ background: "linear-gradient(135deg,#0F172A,#1E293B 60%,#312E81)" }}
    >
      <div className="relative z-10 flex items-center gap-4">
        <div className="grid h-14 w-14 place-items-center rounded-2xl bg-white/10 text-white backdrop-blur">
          <GraduationCap className="h-7 w-7" />
        </div>
        <div>
          <h2 className="text-2xl font-black text-white sm:text-3xl">
            Einstufungs
            <span
              style={{
                background: "linear-gradient(90deg,#F7C948,#DD2222)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              test
            </span>
          </h2>
          <FaHint className="text-white/70">تعیین سطح در ۵ دقیقه</FaHint>
        </div>
      </div>
      <p className="relative z-10 mt-3 max-w-xl text-sm text-white/70">
        10 kurze Fragen — wir schätzen dein Niveau von A1 bis C1 und schlagen den passenden Lernpfad
        vor.
      </p>
    </div>
  );
}
