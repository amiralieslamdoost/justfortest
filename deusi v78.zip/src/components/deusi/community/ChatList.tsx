import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { MessageCircle, Plus, Search } from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { searchUsers, useCommunity } from "@/lib/deusi/community/store";
import type { Chat, ChatKind } from "@/lib/deusi/community/types";
import { ChatAvatar, FilterChip, KIND_STYLE, LevelBadge, UserAvatar } from "./parts";

type Filter = "alle" | ChatKind;

const FILTERS: Array<{ key: Filter; de: string }> = [
  { key: "alle", de: "Alle" },
  { key: "room", de: "Talare" },
  { key: "group", de: "Gruppen" },
  { key: "dm", de: "Privat" },
];

const SECTIONS: Array<{ kind: ChatKind; de: string; fa: string }> = [
  { kind: "room", de: "Öffentliche Talare", fa: "تالارهای عمومی" },
  { kind: "group", de: "Meine Gruppen", fa: "گروه‌های من" },
  { kind: "dm", de: "Private Chats", fa: "گفت‌وگوهای خصوصی" },
];

function preview(chat: Chat) {
  const last = chat.messages[chat.messages.length - 1];
  if (!last) return "Noch keine Nachrichten";
  const body = last.deleted ? "Nachricht gelöscht" : last.body || "📷 Bild";
  return last.authorId === "me" ? `Du: ${body}` : body;
}

export function ChatList({
  chats,
  activeId,
  onNewGroup,
}: {
  chats: Chat[];
  activeId?: string;
  onNewGroup: () => void;
}) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("alle");
  const { openDirectChat } = useCommunity();
  const navigate = useNavigate();

  const q = query.trim().toLowerCase();
  const isIdSearch = query.trim().startsWith("@");
  const people = useMemo(() => (query.trim() ? searchUsers(query) : []), [query]);

  const list = useMemo(
    () =>
      chats
        .filter((c) => (filter === "alle" ? true : c.kind === filter))
        .filter(
          (c) =>
            !q ||
            c.title.toLowerCase().includes(q) ||
            c.messages.some((mm) => mm.body.toLowerCase().includes(q)),
        ),
    [chats, q, filter],
  );

  const sections = SECTIONS.map((s) => ({
    ...s,
    items: list.filter((c) => c.kind === s.kind),
  })).filter((s) => s.items.length > 0);

  return (
    <div className="neu-card flex flex-col overflow-hidden lg:h-full lg:min-h-0">
      <div className="space-y-3 border-b border-border/60 p-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Chats oder @id suchen…"
              aria-label="Chats oder ID durchsuchen"
              className="h-11 w-full rounded-2xl border border-border/70 bg-card/70 pl-9 pr-3 text-sm outline-none transition focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
            />
          </div>
          <button
            type="button"
            onClick={onNewGroup}
            aria-label="Neue Gruppe erstellen"
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[color:var(--section-primary,#c2410c)] text-white shadow-sm transition active:scale-95"
          >
            <Plus className="h-5 w-5" aria-hidden />
          </button>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <FilterChip
              key={f.key}
              active={filter === f.key}
              accent={f.key === "alle" ? undefined : KIND_STYLE[f.key].accent}
              onClick={() => setFilter(f.key)}
            >
              {f.de}
            </FilterChip>
          ))}
        </div>
        {!query && <FaHint size="sm">با @ آیدی افراد را جست‌وجو کن</FaHint>}
      </div>

      <div className="p-2 lg:min-h-0 lg:flex-1 lg:overflow-y-auto">
        {people.length > 0 && (
          <section className="mb-2">
            <SectionTitle de="Personen" fa="افراد" color="#c2410c" />
            <ul>
              {people.map((u) => (
                <li key={u.id}>
                  <button
                    type="button"
                    onClick={() => {
                      const chatId = openDirectChat(u.id);
                      navigate({
                        to: "/community/chat/$chatId",
                        params: { chatId },
                        resetScroll: false,
                      });
                    }}
                    className="flex w-full items-center gap-3 rounded-2xl p-2.5 text-left transition hover:bg-foreground/5"
                  >
                    <UserAvatar user={u} size={40} />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2">
                        <span className="truncate text-sm font-bold">{u.name}</span>
                        <LevelBadge level={u.level} />
                      </span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {u.handle}
                      </span>
                    </span>
                    <MessageCircle className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}

        {sections.length === 0 && people.length === 0 && (
          <div className="px-3 py-10 text-center">
            <p className="text-sm text-muted-foreground">Nichts gefunden.</p>
            <FaHint size="sm">چیزی پیدا نشد</FaHint>
          </div>
        )}

        {!isIdSearch &&
          sections.map((s) => {
            const style = KIND_STYLE[s.kind];
            return (
              <section key={s.kind} className="mb-2">
                <SectionTitle de={s.de} fa={s.fa} color={style.accent} />
                <ul>
                  {s.items.map((c) => {
                    const active = c.id === activeId;
                    return (
                      <li key={c.id}>
                        <Link
                          to="/community/chat/$chatId"
                          params={{ chatId: c.id }}
                          resetScroll={false}
                          style={
                            active
                              ? {
                                  background: `${style.accent}18`,
                                  boxShadow: `inset 3px 0 0 ${style.accent}`,
                                }
                              : undefined
                          }
                          className={`flex items-center gap-3 rounded-2xl p-2.5 transition ${
                            active ? "" : "hover:bg-foreground/5"
                          }`}
                        >
                          <ChatAvatar chat={c} />
                          <span className="min-w-0 flex-1">
                            <span className="flex items-center gap-2">
                              <span className="truncate text-sm font-bold">
                                {c.kind === "room" ? `#${c.title}` : c.title}
                              </span>
                              <span className="ml-auto shrink-0 text-[10px] text-muted-foreground">
                                {c.lastTime}
                              </span>
                            </span>
                            <span className="mt-0.5 flex items-center gap-2">
                              <span className="truncate text-xs text-muted-foreground">
                                {preview(c)}
                              </span>
                              {c.unread > 0 && (
                                <span
                                  style={{ background: style.accent }}
                                  className="ml-auto grid h-5 min-w-5 shrink-0 place-items-center rounded-full px-1 text-[10px] font-black text-white"
                                >
                                  {c.unread}
                                </span>
                              )}
                            </span>
                          </span>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </section>
            );
          })}
      </div>
    </div>
  );
}

function SectionTitle({ de, fa, color }: { de: string; fa: string; color: string }) {
  return (
    <h3 className="flex items-center gap-2 px-2.5 pb-1 pt-2">
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} aria-hidden />
      <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
        {de}
      </span>
      <span className="text-[10px] text-muted-foreground/70">{fa}</span>
    </h3>
  );
}
