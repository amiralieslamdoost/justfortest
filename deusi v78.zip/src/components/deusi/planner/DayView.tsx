import { CalendarPlus, Coffee, Flame } from "lucide-react";
import { EmptyState } from "@/components/deusi/EmptyState";
import { Fa } from "@/components/deusi/Fa";
import { formatDayLong, formatMinutes, weekdayLabel } from "@/lib/deusi/planner/date";
import type { PlannerSession, SessionStatus } from "@/lib/deusi/planner/types";
import { SessionCard } from "./SessionCard";

const toMin = (t: string) => {
  const [h, m] = t.split(":");
  return Number(h ?? 0) * 60 + Number(m ?? 0);
};

/**
 * Tagesansicht — chronologische Timeline aller Sessions eines Tages,
 * inklusive Pausen-Hinweis zwischen zwei Blöcken.
 */
export function DayView({
  date,
  sessions,
  onStatus,
  onEdit,
  onRemove,
  onAdd,
}: {
  date: string;
  sessions: PlannerSession[];
  onStatus: (id: string, status: SessionStatus) => void;
  onEdit: (session: PlannerSession) => void;
  onRemove: (id: string) => void;
  onAdd: (date: string) => void;
}) {
  const daySessions = sessions
    .filter((s) => s.date === date)
    .slice()
    .sort((a, b) => toMin(a.start) - toMin(b.start));
  const total = daySessions.reduce((a, s) => a + s.minutes, 0);
  const done = daySessions.filter((s) => s.status === "done").length;
  const progress = daySessions.length ? Math.round((done / daySessions.length) * 100) : 0;

  return (
    <section aria-label={`Tagesplan ${formatDayLong(date)}`} className="flex flex-col gap-4">
      <header className="rounded-3xl border border-border/60 bg-muted/25 p-4">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
          <div className="min-w-0">
            <h2 className="truncate text-lg font-black tracking-tight">
              {weekdayLabel(date).de}, {formatDayLong(date)}
            </h2>
            <Fa>{weekdayLabel(date).fa}</Fa>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-background px-2.5 py-1 text-[11px] font-bold tabular-nums text-muted-foreground ring-1 ring-inset ring-border/60">
              <Flame className="h-3.5 w-3.5 text-[color:var(--section-primary)]" />
              {daySessions.length ? formatMinutes(total) : "0 min"}
            </span>
            <span className="rounded-full bg-[color:var(--section-primary)]/12 px-2.5 py-1 text-[11px] font-bold tabular-nums text-[color:var(--section-primary)]">
              {done}/{daySessions.length}
            </span>
          </div>
        </div>
        {daySessions.length ? (
          <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full transition-[width] duration-500"
              style={{
                width: `${progress}%`,
                background:
                  "linear-gradient(90deg, color-mix(in oklab, var(--section-primary) 55%, white), var(--section-primary))",
              }}
            />
          </div>
        ) : null}
      </header>

      {daySessions.length ? (
        <ol className="relative flex flex-col gap-3 sm:pl-6">
          <span
            aria-hidden
            className="pointer-events-none absolute inset-y-2 left-[9px] hidden w-px bg-gradient-to-b from-[color:var(--section-primary)]/40 via-border to-transparent sm:block"
          />
          {daySessions.map((s, i) => {
            const prev = daySessions[i - 1];
            const gap = prev ? toMin(s.start) - (toMin(prev.start) + prev.minutes) : 0;
            return (
              <li key={s.id} className="relative">
                {gap > 0 ? (
                  <p className="mb-3 flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground">
                    <Coffee className="h-3.5 w-3.5" />
                    {gap} min Pause
                    <Fa inline>استراحت</Fa>
                  </p>
                ) : null}
                <span
                  aria-hidden
                  className="absolute -left-6 top-6 hidden h-2.5 w-2.5 rounded-full bg-[color:var(--section-primary)] ring-4 ring-[color:var(--section-primary)]/15 sm:block"
                />
                <SessionCard
                  session={s}
                  onToggleDone={() => onStatus(s.id, s.status === "done" ? "planned" : "done")}
                  onSkip={() => onStatus(s.id, s.status === "skipped" ? "planned" : "skipped")}
                  onEdit={() => onEdit(s)}
                  onRemove={() => onRemove(s.id)}
                />
              </li>
            );
          })}
        </ol>
      ) : (
        <EmptyState
          compact
          title="Heute ist Ruhetag"
          description="Pausen gehören zum Plan. Du kannst trotzdem eine Session hinzufügen."
          action={
            <button
              type="button"
              onClick={() => onAdd(date)}
              className="inline-flex items-center gap-2 rounded-full bg-[color:var(--section-primary)] px-4 py-2 text-sm font-bold text-white"
            >
              <CalendarPlus className="h-4 w-4" />
              Session hinzufügen
            </button>
          }
        />
      )}

      {daySessions.length ? (
        <button
          type="button"
          onClick={() => onAdd(date)}
          className="inline-flex items-center gap-2 self-start rounded-full border border-dashed border-border px-4 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:border-[color:var(--section-primary)]/50 hover:text-foreground sm:ml-6"
        >
          <CalendarPlus className="h-4 w-4" />
          Weitere Session
        </button>
      ) : null}
    </section>
  );
}
