/**
 * Square (1:1) cover artwork. Renders the real artwork when `url` is provided,
 * otherwise falls back to the song's gradient + a music glyph.
 */
export function SongCover({
  cover,
  url,
  alt,
  className = "",
  rounded = "rounded-2xl",
  children,
}: {
  cover: string;
  url?: string;
  alt: string;
  className?: string;
  rounded?: string;
  children?: React.ReactNode;
}) {
  return (
    <span
      className={`relative block aspect-square w-full overflow-hidden ${rounded} ${className}`}
      style={{ background: cover }}
    >
      {url ? (
        <img src={url} alt={alt} loading="lazy" className="h-full w-full object-cover" />
      ) : (
        <span className="absolute inset-0 grid place-items-center text-white/35">
          <svg viewBox="0 0 24 24" width="38%" height="38%" fill="currentColor">
            <path d="M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z" />
          </svg>
        </span>
      )}
      {children}
    </span>
  );
}
