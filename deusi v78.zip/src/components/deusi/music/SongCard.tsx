import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import { artistName, type Song } from "@/lib/deusi/mockMusic";
import { fmtTime } from "./MusicPlayer";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";

/**
 * Compact Spotify-style song row / tile.
 *  - "row"  = dense list row with 44px cover, one line meta
 *  - "tile" = small square-cover card with title + artist beneath
 */
export function SongCard({
  song,
  progressPct,
  layout = "row",
  index,
}: {
  song: Song;
  progressPct?: number;
  layout?: "row" | "tile";
  index?: number;
}) {
  const hasLyrics = song.lyrics.length > 0;

  if (layout === "tile") {
    return (
      <Link
        to="/musik/$songId"
        params={{ songId: song.id }}
        className="group relative flex flex-col overflow-hidden rounded-xl border border-border/60 bg-card p-2.5 transition hover:-translate-y-0.5 hover:shadow-lg"
      >
        <div
          className="relative aspect-square w-full overflow-hidden rounded-lg"
          style={{ background: song.cover }}
        >
          {song.coverUrl && (
            <img
              src={song.coverUrl}
              alt={song.title}
              loading="lazy"
              className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/0 to-transparent" />
          <span className="absolute left-1.5 top-1.5 rounded-md bg-black/55 px-1.5 py-0.5 text-[10px] font-black text-white backdrop-blur">
            {song.level}
          </span>
          {hasLyrics && (
            <span className="absolute right-1.5 top-1.5 rounded-md bg-white/95 px-1.5 py-0.5 text-[9px] font-black text-slate-900">
              LYRICS
            </span>
          )}
          <span
            className="absolute bottom-1.5 right-1.5 grid h-9 w-9 translate-y-2 place-items-center rounded-full text-white opacity-0 shadow-xl transition group-hover:translate-y-0 group-hover:opacity-100"
            style={{ background: song.accent }}
          >
            <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor">
              <path d="M8 5v14l11-7z" />
            </svg>
          </span>
        </div>
        <div className="flex items-start gap-1 pt-2">
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13px] font-black leading-tight">{song.title}</div>
            <div className="mt-0.5 truncate text-[11px] text-muted-foreground">
              {artistName(song.artistId)}
            </div>
          </div>
          <BookmarkButton
            type="music"
            id={song.id}
            title={song.title}
            sub={`${artistName(song.artistId)} · ${song.album}`}
            level={song.level}
            to={`/musik/${song.id}`}
            size={15}
            className="h-7 w-7 shrink-0"
          />
        </div>
      </Link>
    );
  }

  return (
    <Link
      to="/musik/$songId"
      params={{ songId: song.id }}
      className="group relative flex items-center gap-3 rounded-xl border border-transparent px-2 py-1.5 transition hover:border-border/60 hover:bg-secondary/60"
    >
      {typeof index === "number" && (
        <span className="hidden w-5 shrink-0 text-center text-[11px] font-black tabular-nums text-muted-foreground group-hover:text-foreground sm:block">
          {index}
        </span>
      )}
      <span
        className="relative h-11 w-11 shrink-0 overflow-hidden rounded-md"
        style={{ background: song.cover }}
      >
        {song.coverUrl && (
          <img
            src={song.coverUrl}
            alt={song.title}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        )}
        <span className="pointer-events-none absolute inset-0 grid place-items-center bg-black/40 text-white opacity-0 transition group-hover:opacity-100">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        </span>
      </span>

      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1.5">
          <span className="truncate text-[13px] font-black">{song.title}</span>
          {hasLyrics && (
            <span className="hidden shrink-0 rounded bg-secondary px-1 py-0.5 text-[9px] font-black text-muted-foreground sm:inline">
              LYR
            </span>
          )}
        </span>
        <span className="mt-0.5 block truncate text-[11px] text-muted-foreground">
          {artistName(song.artistId)} · {song.album}
        </span>
        {typeof progressPct === "number" && (
          <span className="mt-1 block h-0.5 w-full overflow-hidden rounded-full bg-secondary">
            <span
              className="block h-full rounded-full"
              style={{ width: `${progressPct}%`, background: song.accent }}
            />
          </span>
        )}
      </span>

      <span className="hidden shrink-0 rounded-md bg-secondary px-1.5 py-0.5 text-[10px] font-black text-muted-foreground sm:inline">
        {song.level}
      </span>
      <span className="shrink-0 text-[11px] tabular-nums text-muted-foreground">
        {fmtTime(song.durationSec)}
      </span>
      <BookmarkButton
        type="music"
        id={song.id}
        title={song.title}
        sub={`${artistName(song.artistId)} · ${song.album}`}
        level={song.level}
        to={`/musik/${song.id}`}
        size={15}
        className="h-7 w-7 shrink-0"
      />
    </Link>
  );
}
