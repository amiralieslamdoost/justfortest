import { motion } from "framer-motion";
import { Flame, Snowflake, TrendingUp } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import {
  WEEK_DAYS,
  WEEK_XP,
  STREAK_DAYS,
  STREAK_BEST,
  STREAK_FREEZES,
} from "@/lib/deusi/gamification";

export function StreakWeekCard() {
  const max = Math.max(...WEEK_XP);
  const weekTotal = WEEK_XP.filter((x) => x > 0).reduce((s, x) => s + x, 0);

  return (
    <section className="neu-card relative overflow-hidden p-4 sm:p-6">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-orange-500/10 blur-3xl"
      />
      <div className="relative flex flex-wrap items-center justify-between gap-2 sm:gap-3">
        <div className="min-w-0">
          <h2 className="flex items-center gap-2 text-base font-black leading-tight sm:text-lg">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-orange-500/12">
              <Flame className="h-4 w-4" style={{ color: "#F97316" }} aria-hidden />
            </span>
            {STREAK_DAYS}-Tage-Serie
          </h2>
          <Fa className="fa-hint-xs">زنجیره یادگیری این هفته</Fa>
        </div>
        <div className="flex gap-1.5 sm:gap-2">
          <Pill icon={<TrendingUp className="h-3 w-3" />} label={`Rekord ${STREAK_BEST}`} />
          <Pill icon={<Snowflake className="h-3 w-3" />} label={`${STREAK_FREEZES} Freeze`} />
        </div>
      </div>

      <div className="relative mt-5 flex items-end justify-between gap-1.5 sm:gap-2.5">
        {WEEK_DAYS.map((d, i) => {
          const xp = WEEK_XP[i];
          const future = xp < 0;
          const best = !future && xp === max;
          const h = future ? 8 : Math.max(12, Math.round((xp / max) * 96));
          return (
            <div key={d} className="flex min-w-0 flex-1 flex-col items-center gap-1.5">
              <span
                className={`text-[10px] font-bold tabular-nums ${
                  best ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                {future ? "—" : xp}
              </span>
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: h }}
                transition={{ delay: i * 0.05, duration: 0.5, ease: "easeOut" }}
                className={`w-full rounded-lg ${future ? "bg-secondary" : "shadow-sm"}`}
                style={
                  future
                    ? undefined
                    : {
                        backgroundImage: "linear-gradient(180deg, #FBBF24, #F97316)",
                        boxShadow: best ? "0 0 16px rgba(249,115,22,0.45)" : undefined,
                      }
                }
              />
              <span
                className={`grid h-6 w-6 place-items-center rounded-full text-[10px] font-black ${
                  future ? "bg-secondary text-muted-foreground" : "bg-foreground text-background"
                }`}
              >
                {future ? d[0] : "🔥"}
              </span>
              <span className="text-[9px] font-semibold text-muted-foreground sm:text-[10px]">
                {d}
              </span>
            </div>
          );
        })}
      </div>

      <div className="relative mt-4 rounded-2xl bg-secondary/70 p-3 text-[11px] font-semibold leading-relaxed text-muted-foreground ring-1 ring-border/60 sm:text-xs">
        Diese Woche <b className="text-foreground tabular-nums">{weekTotal} XP</b> gesammelt — heute
        noch aktiv bleiben, sonst reißt die Serie!
        <Fa className="fa-hint-xs">امروز هم تمرین کن تا زنجیره‌ات نشکند</Fa>
      </div>
    </section>
  );
}

function Pill({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
      {icon}
      {label}
    </span>
  );
}
