/**
 * کلیدهای مرکزی TanStack Query.
 * هر دامنه یک شاخه دارد تا invalidate کردن ساده و بدون رشتهٔ جادویی باشد.
 * (در سشن ۲ فقط auth/profile استفاده می‌شود؛ بقیه برای سشن‌های بعدی رزرو است.)
 */

export const queryKeys = {
  auth: {
    all: ["auth"] as const,
    session: () => ["auth", "session"] as const,
  },
  profile: {
    all: ["profile"] as const,
    me: () => ["profile", "me"] as const,
    byUser: (userId: string) => ["profile", "user", userId] as const,
    settings: () => ["profile", "settings"] as const,
    placement: () => ["profile", "placement"] as const,
    subscription: () => ["profile", "subscription"] as const,
  },
  vocabulary: {
    all: ["vocabulary"] as const,
    words: (filter?: unknown) => ["vocabulary", "words", filter ?? null] as const,
    userWords: () => ["vocabulary", "userWords"] as const,
    srs: () => ["vocabulary", "srs"] as const,
    proverbs: () => ["vocabulary", "proverbs"] as const,
    verbs: () => ["vocabulary", "verbs"] as const,
    families: () => ["vocabulary", "families"] as const,
  },
  grammar: {
    all: ["grammar"] as const,
    topics: () => ["grammar", "topics"] as const,
    topic: (id: string) => ["grammar", "topic", id] as const,
    lesson: (id: string) => ["grammar", "lesson", id] as const,
    progress: () => ["grammar", "progress"] as const,
    lessonProgress: (userId: string) => ["grammar", "progress", userId] as const,
  },
  reading: {
    all: ["reading"] as const,
    articles: () => ["reading", "articles"] as const,
    articlesPaged: (filter?: unknown) => ["reading", "articles", filter ?? null] as const,
    article: (id: string) => ["reading", "article", id] as const,
    progress: () => ["reading", "progress"] as const,
    readingProgress: (userId: string) => ["reading", "progress", userId] as const,
    writing: () => ["reading", "writing"] as const,
    writingList: (userId: string) => ["reading", "writing", userId] as const,
  },
  media: {
    all: ["media"] as const,
    films: (filter?: unknown) => ["media", "films", filter ?? null] as const,
    film: (id: string) => ["media", "film", id] as const,
    songs: (filter?: unknown) => ["media", "songs", filter ?? null] as const,
    song: (id: string) => ["media", "song", id] as const,
    artists: () => ["media", "artists"] as const,
    episodes: (filter?: unknown) => ["media", "episodes", filter ?? null] as const,
    episode: (id: string) => ["media", "episode", id] as const,
    shows: () => ["media", "shows"] as const,
    books: (filter?: unknown) => ["media", "books", filter ?? null] as const,
    book: (id: string) => ["media", "book", id] as const,
    progress: () => ["media", "progress"] as const,
    progressByUser: (userId: string) => ["media", "progress", userId] as const,
    vocab: (userId: string, filter?: unknown) =>
      ["media", "vocab", userId, filter ?? null] as const,
  },
  exams: {
    all: ["exams"] as const,
    list: () => ["exams", "list"] as const,
    detail: (id: string) => ["exams", "detail", id] as const,
    attempts: () => ["exams", "attempts"] as const,
  },
  planner: {
    all: ["planner"] as const,
    plan: () => ["planner", "plan"] as const,
    sessions: () => ["planner", "sessions"] as const,
  },
  community: {
    all: ["community"] as const,
    posts: () => ["community", "posts"] as const,
    chat: (id: string) => ["community", "chat", id] as const,
    tandem: () => ["community", "tandem"] as const,
    events: () => ["community", "events"] as const,
  },
  gamification: {
    all: ["gamification"] as const,
    achievements: () => ["gamification", "achievements"] as const,
    stats: () => ["gamification", "stats"] as const,
  },
  ai: {
    all: ["ai"] as const,
    threads: () => ["ai", "threads"] as const,
    thread: (id: string) => ["ai", "thread", id] as const,
  },
} as const;
