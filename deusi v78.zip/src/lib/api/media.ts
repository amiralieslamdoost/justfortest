/**
 * لایهٔ دادهٔ مدیا / Medien-Datenschicht (سشن ۵).
 *
 * دامنه‌ها: kino (films)، musik (songs + artists)، podcasts (episodes + shows)، books.
 * در حالت MOCK دقیقاً همان دیتای `mockKino/mockMusic/mockPodcasts/dictionary/books` برگردانده می‌شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import { readLocal, writeLocal } from "./storage";
import type {
  ArtistRecord,
  BookRecord,
  EpisodeRecord,
  FilmRecord,
  PodcastShowRecord,
  SongRecord,
} from "./types";
import { films as MOCK_FILMS, type Film, type SubtitleCue } from "@/lib/deusi/mockKino";
import {
  artists as MOCK_ARTISTS,
  songs as MOCK_SONGS,
  type Artist,
  type LyricLine,
  type Song,
  type SongVocab,
} from "@/lib/deusi/mockMusic";
import {
  podcastEpisodes as MOCK_EPISODES,
  podcastShows as MOCK_SHOWS,
  type PodcastEpisode,
  type PodcastShow,
  type PodcastVocab,
  type TranscriptLine,
} from "@/lib/deusi/mockPodcasts";
import {
  LEARNING_BOOKS as MOCK_BOOKS,
  type LearningBook,
} from "@/lib/deusi/dictionary/books";

/* -------------------------------------------------------------------------- */
/* کلیدهای کش محلی                                                             */
/* -------------------------------------------------------------------------- */

const LS_FILMS_CACHE = "deusi.media.films.cache.v1";
const LS_SONGS_CACHE = "deusi.media.songs.cache.v1";
const LS_ARTISTS_CACHE = "deusi.media.artists.cache.v1";
const LS_EPISODES_CACHE = "deusi.media.episodes.cache.v1";
const LS_SHOWS_CACHE = "deusi.media.shows.cache.v1";
const LS_BOOKS_CACHE = "deusi.media.books.cache.v1";

export interface MediaQuery {
  q?: string;
  level?: string; // "alle" یا CEFR
  category?: string; // ژانر/دستهٔ مدیا یا "alle"/"fuer-dich"
  page?: number;
  perPage?: number;
}

export interface Paged<T> {
  items: T[];
  page: number;
  perPage: number;
  totalItems: number;
  totalPages: number;
}

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

function pagedLocal<T>(all: T[], query: MediaQuery): Paged<T> {
  const page = Math.max(1, query.page ?? 1);
  const perPage = Math.min(200, Math.max(1, query.perPage ?? 60));
  const start = (page - 1) * perPage;
  return {
    items: all.slice(start, start + perPage),
    page,
    perPage,
    totalItems: all.length,
    totalPages: Math.max(1, Math.ceil(all.length / perPage)),
  };
}

/** آدرس فایل PocketBase با fallback به آدرس متنی. */
function fileUrl(
  collection: string,
  record: { id: string; collectionId?: string; collectionName?: string },
  filename: string | undefined,
  fallback: string,
): string {
  if (!filename || !BACKEND) return fallback;
  try {
    const pb = getPb();
    return pb.files.getURL({ ...record, collectionName: collection }, filename) || fallback;
  } catch {
    return fallback;
  }
}

/* -------------------------------------------------------------------------- */
/* نگاشت رکورد ← مدل UI                                                        */
/* -------------------------------------------------------------------------- */

export function filmRecordToFilm(r: FilmRecord): Film {
  return {
    id: r.slug || r.id,
    title: r.title,
    titleFa: r.title_fa,
    year: r.year,
    duration: r.duration,
    level: (r.level ?? "B1") as Film["level"],
    genre: r.genre ?? [],
    director: r.director,
    synopsis: r.synopsis,
    synopsisFa: r.synopsis_fa,
    poster: fileUrl("films", r, r.poster_image, r.poster),
    videoUrl: fileUrl("films", r, r.video_file, r.video_url),
    cues: (r.cues ?? []) as unknown as SubtitleCue[],
  };
}

export function artistRecordToArtist(r: ArtistRecord): Artist {
  return {
    id: r.slug || r.id,
    name: r.name,
    country: "",
    genre: (r.genre || "indie") as Artist["genre"],
    tagline: r.bio ?? "",
    cover: r.photo ?? "",
    accent: r.accent ?? "#6366f1",
    songs: 0,
    listeners: "",
  };
}

export function songRecordToSong(
  r: SongRecord & { expand?: { artist?: ArtistRecord } },
): Song {
  const artist = r.expand?.artist;
  return {
    id: r.slug || r.id,
    title: r.title,
    artistId: artist?.slug ?? (artist?.id || (r.artist as string) || ""),
    album: r.album ?? "",
    year: r.year ?? 0,
    durationSec: r.duration_sec ?? 0,
    level: (r.level ?? "B1") as Song["level"],
    genre: (r.genre || "indie") as Song["genre"],
    cover: fileUrl("songs", r, r.cover_image, r.cover),
    accent: r.accent ?? "#6366f1",
    plays: "",
    audioUrl: fileUrl("songs", r, r.audio_file, r.audio_url),
    waveform: r.waveform ?? [],
    lyrics: (r.lyrics ?? []).map((l) => ({
      id: l.id,
      start: l.start,
      end: l.end,
      words: (l.words ?? []).map((w) => ({ w: w.w, vocabId: w.wordId })),
      translation: l.translation ?? l.translationFa ?? "",
    })) as LyricLine[],
    vocab: (r.vocab ?? []).map((v) => ({
      id: v.id,
      term: v.word,
      pos: v.pos,
      article: v.article,
      plural: v.plural,
      praeteritum: v.praeteritum,
      perfekt: v.perfekt,
      comparative: v.comparative,
      superlative: v.superlative,
      translation: v.meaning,
      example: v.example ?? "",
    })) as SongVocab[],
    noteFa: r.note_fa ?? "",
  };
}

export function showRecordToShow(r: PodcastShowRecord): PodcastShow {
  return {
    id: r.slug || r.id,
    title: r.title,
    publisher: r.publisher ?? "",
    tagline: r.tagline ?? "",
    cover: fileUrl("podcast_shows", r, r.cover_image, r.cover),
    accent: r.accent ?? "#6366f1",
    level: (r.level || "B1") as PodcastShow["level"],
    category: (r.category || "gesellschaft") as PodcastShow["category"],
    episodes: r.episodes_count ?? 0,
  };
}

export function episodeRecordToEpisode(
  r: EpisodeRecord & { expand?: { show?: PodcastShowRecord } },
): PodcastEpisode {
  const show = r.expand?.show;
  return {
    id: r.slug || r.id,
    showId: show?.slug ?? (show?.id || (r.show as string) || ""),
    number: r.number ?? 0,
    title: r.title,
    description: r.description ?? "",
    summary: r.summary ?? "",
    cover: r.cover ?? "",
    accent: r.accent ?? "#6366f1",
    category: (r.category || "gesellschaft") as PodcastEpisode["category"],
    level: (r.level || "B1") as PodcastEpisode["level"],
    publishedAt: r.published_at || r.created,
    durationSec: r.duration_sec ?? 0,
    waveform: r.waveform ?? [],
    transcript: (r.transcript ?? []).map((l) => ({
      id: l.id,
      start: l.start,
      end: l.end,
      speaker: l.speaker,
      words: (l.words ?? []).map((w) => ({ w: w.w, wordId: w.wordId })),
      translation: l.translation ?? l.translationFa ?? "",
    })) as TranscriptLine[],
    vocab: (r.vocab ?? []).map((v) => ({
      id: v.id,
      word: v.word,
      article: v.article,
      ipa: v.ipa ?? "",
      pos: (v.pos ?? "Nomen") as PodcastVocab["pos"],
      meaning: v.meaning,
      example: v.example ?? "",
      level: (v.level ?? "B1") as PodcastVocab["level"],
    })) as PodcastVocab[],
    quiz: r.quiz ?? [],
    featured: r.featured,
  };
}

export function bookRecordToBook(r: BookRecord): LearningBook {
  return {
    id: r.slug || r.id,
    title: r.title,
    publisher: r.publisher ?? "",
    level: (r.level ?? "A1") as LearningBook["level"],
    cover: r.cover || "📘",
    coverUrl: r.cover_image ? fileUrl("books", r, r.cover_image, "") || undefined : undefined,
    color: r.color || "#6366f1",
    wordCount: r.word_count ?? 0,
    wordIds: r.word_ids ?? [],
  };
}

/* -------------------------------------------------------------------------- */
/* فیلترهای محلی (MOCK و fallback)                                             */
/* -------------------------------------------------------------------------- */

function levelMatches(level: string, want?: string) {
  if (!want || want === "alle") return true;
  return level.includes(want);
}

function textMatches(haystack: string[], q?: string) {
  const needle = (q ?? "").trim().toLowerCase();
  if (!needle) return true;
  return haystack.some((h) => (h ?? "").toLowerCase().includes(needle));
}

function serverFilters(query: MediaQuery, opts: { categoryField?: string } = {}) {
  const filters = ["published = true"];
  const q = escapeFilter((query.q ?? "").trim());
  if (q) filters.push(`title ~ "${q}"`);
  if (query.level && query.level !== "alle") {
    filters.push(`level ~ "${escapeFilter(query.level)}"`);
  }
  if (
    opts.categoryField &&
    query.category &&
    query.category !== "alle" &&
    query.category !== "fuer-dich" &&
    query.category !== "fuerdich"
  ) {
    filters.push(`${opts.categoryField} ~ "${escapeFilter(query.category)}"`);
  }
  return filters.join(" && ");
}

/* -------------------------------------------------------------------------- */
/* فیلم‌ها (kino)                                                              */
/* -------------------------------------------------------------------------- */

function filterFilms(all: Film[], query: MediaQuery) {
  return all.filter(
    (f) =>
      levelMatches(f.level, query.level) &&
      (!query.category ||
        query.category === "alle" ||
        f.genre.some((g) => g.toLowerCase() === query.category!.toLowerCase())) &&
      textMatches([f.title, f.titleFa, f.director, f.synopsis], query.q),
  );
}

export async function listFilms(query: MediaQuery = {}): Promise<Paged<Film>> {
  if (!BACKEND) return pagedLocal(filterFilms(MOCK_FILMS, query), query);
  const pb = getPb();
  const page = Math.max(1, query.page ?? 1);
  const perPage = Math.min(200, Math.max(1, query.perPage ?? 60));
  try {
    const res = await pbRequest((signal) =>
      pb.collection("films").getList<FilmRecord>(page, perPage, {
        filter: serverFilters(query),
        sort: "-year",
        signal,
      }),
    );
    const items = res.items.map(filmRecordToFilm);
    if (page === 1) writeLocal(LS_FILMS_CACHE, items);
    return {
      items,
      page: res.page,
      perPage: res.perPage,
      totalItems: res.totalItems,
      totalPages: res.totalPages,
    };
  } catch (err) {
    if (toApiError(err).kind === "auth") throw err;
    const cached = readLocal<Film[] | null>(LS_FILMS_CACHE, null);
    return pagedLocal(filterFilms(cached?.length ? cached : MOCK_FILMS, query), query);
  }
}

export async function getFilm(idOrSlug: string): Promise<Film | null> {
  const local = MOCK_FILMS.find((f) => f.id === idOrSlug) ?? null;
  if (!idOrSlug || !BACKEND) return local;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("films")
        .getFirstListItem<FilmRecord>(
          `slug = "${escapeFilter(idOrSlug)}" || id = "${escapeFilter(idOrSlug)}"`,
          { signal },
        ),
    );
    return filmRecordToFilm(rec);
  } catch {
    return local;
  }
}

/* -------------------------------------------------------------------------- */
/* آهنگ‌ها و هنرمندان (musik)                                                  */
/* -------------------------------------------------------------------------- */

function filterSongs(all: Song[], query: MediaQuery) {
  return all.filter(
    (s) =>
      levelMatches(s.level, query.level) &&
      (!query.category ||
        query.category === "alle" ||
        query.category === "fuer-dich" ||
        s.genre === query.category) &&
      textMatches([s.title, s.album], query.q),
  );
}

export async function listSongs(query: MediaQuery = {}): Promise<Paged<Song>> {
  if (!BACKEND) return pagedLocal(filterSongs(MOCK_SONGS, query), query);
  const pb = getPb();
  const page = Math.max(1, query.page ?? 1);
  const perPage = Math.min(200, Math.max(1, query.perPage ?? 60));
  try {
    const res = await pbRequest((signal) =>
      pb.collection("songs").getList<SongRecord>(page, perPage, {
        filter: serverFilters(query, { categoryField: "genre" }),
        expand: "artist",
        sort: "-year",
        signal,
      }),
    );
    const items = res.items.map((r) => songRecordToSong(r));
    if (page === 1) writeLocal(LS_SONGS_CACHE, items);
    return {
      items,
      page: res.page,
      perPage: res.perPage,
      totalItems: res.totalItems,
      totalPages: res.totalPages,
    };
  } catch (err) {
    if (toApiError(err).kind === "auth") throw err;
    const cached = readLocal<Song[] | null>(LS_SONGS_CACHE, null);
    return pagedLocal(filterSongs(cached?.length ? cached : MOCK_SONGS, query), query);
  }
}

export async function getSong(idOrSlug: string): Promise<Song | null> {
  const local = MOCK_SONGS.find((s) => s.id === idOrSlug) ?? null;
  if (!idOrSlug || !BACKEND) return local;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("songs")
        .getFirstListItem<SongRecord>(
          `slug = "${escapeFilter(idOrSlug)}" || id = "${escapeFilter(idOrSlug)}"`,
          { expand: "artist", signal },
        ),
    );
    return songRecordToSong(rec);
  } catch {
    return local;
  }
}

export async function listArtists(): Promise<Artist[]> {
  if (!BACKEND) return MOCK_ARTISTS;
  const pb = getPb();
  try {
    const res = await pbRequest((signal) =>
      pb.collection("artists").getFullList<ArtistRecord>({ sort: "name", signal }),
    );
    if (!res.length) return MOCK_ARTISTS;
    const items = res.map(artistRecordToArtist);
    writeLocal(LS_ARTISTS_CACHE, items);
    return items;
  } catch {
    return readLocal<Artist[]>(LS_ARTISTS_CACHE, MOCK_ARTISTS);
  }
}

/* -------------------------------------------------------------------------- */
/* پادکست‌ها                                                                   */
/* -------------------------------------------------------------------------- */

function filterEpisodes(all: PodcastEpisode[], query: MediaQuery) {
  return all.filter(
    (e) =>
      levelMatches(e.level, query.level) &&
      (!query.category ||
        query.category === "alle" ||
        query.category === "fuer-dich" ||
        e.category === query.category) &&
      textMatches([e.title, e.description, e.summary], query.q),
  );
}

export async function listEpisodes(query: MediaQuery = {}): Promise<Paged<PodcastEpisode>> {
  if (!BACKEND) return pagedLocal(filterEpisodes(MOCK_EPISODES, query), query);
  const pb = getPb();
  const page = Math.max(1, query.page ?? 1);
  const perPage = Math.min(200, Math.max(1, query.perPage ?? 60));
  try {
    const res = await pbRequest((signal) =>
      pb.collection("episodes").getList<EpisodeRecord>(page, perPage, {
        filter: serverFilters(query, { categoryField: "category" }),
        expand: "show",
        sort: "-published_at",
        signal,
      }),
    );
    const items = res.items.map((r) => episodeRecordToEpisode(r));
    if (page === 1) writeLocal(LS_EPISODES_CACHE, items);
    return {
      items,
      page: res.page,
      perPage: res.perPage,
      totalItems: res.totalItems,
      totalPages: res.totalPages,
    };
  } catch (err) {
    if (toApiError(err).kind === "auth") throw err;
    const cached = readLocal<PodcastEpisode[] | null>(LS_EPISODES_CACHE, null);
    return pagedLocal(filterEpisodes(cached?.length ? cached : MOCK_EPISODES, query), query);
  }
}

export async function getEpisode(idOrSlug: string): Promise<PodcastEpisode | null> {
  const local = MOCK_EPISODES.find((e) => e.id === idOrSlug) ?? null;
  if (!idOrSlug || !BACKEND) return local;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("episodes")
        .getFirstListItem<EpisodeRecord>(
          `slug = "${escapeFilter(idOrSlug)}" || id = "${escapeFilter(idOrSlug)}"`,
          { expand: "show", signal },
        ),
    );
    return episodeRecordToEpisode(rec);
  } catch {
    return local;
  }
}

export async function listShows(): Promise<PodcastShow[]> {
  if (!BACKEND) return MOCK_SHOWS;
  const pb = getPb();
  try {
    const res = await pbRequest((signal) =>
      pb.collection("podcast_shows").getFullList<PodcastShowRecord>({ sort: "title", signal }),
    );
    if (!res.length) return MOCK_SHOWS;
    const items = res.map(showRecordToShow);
    writeLocal(LS_SHOWS_CACHE, items);
    return items;
  } catch {
    return readLocal<PodcastShow[]>(LS_SHOWS_CACHE, MOCK_SHOWS);
  }
}

/* -------------------------------------------------------------------------- */
/* کتاب‌ها                                                                     */
/* -------------------------------------------------------------------------- */

function filterBooks(all: LearningBook[], query: MediaQuery) {
  return all.filter(
    (b) => levelMatches(b.level, query.level) && textMatches([b.title, b.publisher], query.q),
  );
}

export async function listBooks(query: MediaQuery = {}): Promise<Paged<LearningBook>> {
  if (!BACKEND) return pagedLocal(filterBooks(MOCK_BOOKS, query), query);
  const pb = getPb();
  const page = Math.max(1, query.page ?? 1);
  const perPage = Math.min(200, Math.max(1, query.perPage ?? 60));
  try {
    const res = await pbRequest((signal) =>
      pb.collection("books").getList<BookRecord>(page, perPage, {
        filter: serverFilters(query),
        sort: "level,title",
        signal,
      }),
    );
    const items = res.items.map(bookRecordToBook);
    if (page === 1) writeLocal(LS_BOOKS_CACHE, items);
    return {
      items,
      page: res.page,
      perPage: res.perPage,
      totalItems: res.totalItems,
      totalPages: res.totalPages,
    };
  } catch (err) {
    if (toApiError(err).kind === "auth") throw err;
    const cached = readLocal<LearningBook[] | null>(LS_BOOKS_CACHE, null);
    return pagedLocal(filterBooks(cached?.length ? cached : MOCK_BOOKS, query), query);
  }
}

export async function getBook(idOrSlug: string): Promise<LearningBook | null> {
  const local = MOCK_BOOKS.find((b) => b.id === idOrSlug) ?? null;
  if (!idOrSlug || !BACKEND) return local;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("books")
        .getFirstListItem<BookRecord>(
          `slug = "${escapeFilter(idOrSlug)}" || id = "${escapeFilter(idOrSlug)}"`,
          { signal },
        ),
    );
    return bookRecordToBook(rec);
  } catch {
    return local;
  }
}

/** شناسهٔ رکورد یک آیتم مدیا بر اساس slug (برای پیشرفت/واژه). */
export async function resolveMediaRecordId(
  collection: "films" | "songs" | "episodes" | "books",
  slug: string,
): Promise<string | null> {
  if (!BACKEND || !slug) return null;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection(collection)
        .getFirstListItem<{ id: string }>(
          `slug = "${escapeFilter(slug)}" || id = "${escapeFilter(slug)}"`,
          { signal },
        ),
    );
    return rec.id;
  } catch {
    return null;
  }
}