/**
 * ============================================================================
 * DEUSI — قرارداد تایپ لایه داده (Session 1)
 * ============================================================================
 *
 * این فایل نمایش TypeScript اسکیمای PocketBase در `backend/pb_schema.json` است.
 * فقط تایپ — هیچ کد اجرایی، هیچ import از pocketbase، هیچ وابستگی به UI.
 * مستندات فارسی هر کالکشن: `backend/SCHEMA-FA.md`
 * قواعد دسترسی: `backend/API-RULES.md`
 */

/* -------------------------------------------------------------------------- */
/* پایه                                                                        */
/* -------------------------------------------------------------------------- */

/** ISO-8601 datetime string as returned by PocketBase (e.g. "2026-08-09 12:00:00.000Z"). */
export type ISODate = string;
/** "yyyy-mm-dd" */
export type DayString = string;
/** "HH:MM" */
export type TimeString = string;
/** PocketBase record id (15 chars). */
export type RecordId = string;

/** فیلدهای سیستمی که PocketBase به هر رکورد اضافه می‌کند. */
export interface BaseRecord {
  id: RecordId;
  created: ISODate;
  updated: ISODate;
  /** رکوردهای expand شده (relation) */
  expand?: Record<string, unknown>;
  collectionId?: string;
  collectionName?: string;
}

export type Cefr = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";
export type CefrOrUnknown = Cefr | "unknown";
export type SkillKey = "vocabulary" | "grammar" | "listening" | "speaking" | "reading" | "writing";
export type MediaType = "film" | "song" | "episode" | "book";
export type Rarity = "common" | "rare" | "epic" | "legendary";

/** پاسخ لیست PocketBase */
export interface ListResult<T> {
  page: number;
  perPage: number;
  totalItems: number;
  totalPages: number;
  items: T[];
}

/** ورودی نوشتن: بدون فیلدهای سیستمی. */
export type CreateInput<T extends BaseRecord> = Omit<T, keyof BaseRecord>;
export type UpdateInput<T extends BaseRecord> = Partial<CreateInput<T>>;

/* -------------------------------------------------------------------------- */
/* کاربر و احراز هویت                                                          */
/* -------------------------------------------------------------------------- */

export interface UserRecord extends BaseRecord {
  email: string;
  emailVisibility: boolean;
  verified: boolean;
  name: string;
  avatar: string;
}

export interface ProfileRecord extends BaseRecord {
  user: RecordId;
  display_name: string;
  handle: string;
  initials: string;
  level: CefrOrUnknown;
  native_language: string;
  city: string;
  country: string;
  bio: string;
  accent_color: string;
  goals: string[];
  preferences: Record<string, unknown>;
  xp: number;
  level_number: number;
  streak_days: number;
  longest_streak: number;
  last_study_at: ISODate | "";
  onboarding_done: boolean;
  public_profile: boolean;
}

export interface SettingsRecord extends BaseRecord {
  user: RecordId;
  ui_language: "de" | "fa";
  theme: "light" | "dark" | "system";
  rtl: boolean;
  sound: boolean;
  email_digest: boolean;
  push_enabled: boolean;
  daily_goal_minutes: number;
  notification_prefs: Record<string, boolean>;
}

export interface PlacementResultRecord extends BaseRecord {
  user: RecordId;
  level: Cefr;
  score: number;
  max_score: number;
  skill_scores: Partial<Record<SkillKey, number>>;
  answers: Record<string, unknown>;
  taken_at: ISODate | "";
}

export interface SubscriptionRecord extends BaseRecord {
  user: RecordId;
  plan: "free" | "plus" | "pro" | "institute";
  status: "active" | "trialing" | "canceled" | "expired";
  started_at: ISODate | "";
  expires_at: ISODate | "";
  meta: Record<string, unknown>;
}

/* -------------------------------------------------------------------------- */
/* واژگان                                                                      */
/* -------------------------------------------------------------------------- */

export type WordPos =
  "noun" | "verb" | "adjective" | "adverb" | "preposition" | "conjunction" | "pronoun";

export interface Meaning {
  de: string;
  fa?: string;
  en?: string;
}

export interface ExampleSentence {
  id: string;
  de: string;
  en?: string;
  fa?: string;
}

export interface Conjugation {
  ich: string;
  du: string;
  er: string;
  wir: string;
  ihr: string;
  sie: string;
}

export interface NounGrammar {
  article: "der" | "die" | "das";
  gender: "m" | "f" | "n";
  plural: string;
  genitive: string;
  declension?: string;
}

export interface GovernedPreposition {
  text: string;
  case: "Akk" | "Dat" | "Gen";
  example?: string;
}

export interface VerbGrammar {
  separable: boolean;
  regular: boolean;
  aux: "haben" | "sein";
  praeteritum: string;
  perfekt: string;
  partizipII: string;
  praesens: Conjugation;
  praeteritumConj: Conjugation;
  perfektConj: Conjugation;
  objectCase?: "Akk" | "Dat" | "Gen" | "none";
  reflexive?: boolean;
  governedPrepositions?: GovernedPreposition[];
}

export interface AdjectiveGrammar {
  comparative: string;
  superlative: string;
  attributive: { nom: string; akk: string; dat: string; gen: string };
  collocations: string[];
}

export interface AdverbGrammar {
  usage: string;
  position: string;
}

export interface PrepositionGrammar {
  cases: Array<"Nom" | "Akk" | "Dat" | "Gen">;
  examples: string[];
}

export interface WordFamilyLinks {
  synonyms: string[];
  antonyms: string[];
  similar: string[];
  compounds: string[];
  relatedVerbs: string[];
  relatedNouns: string[];
  relatedAdjectives: string[];
}

export interface WordRecord extends BaseRecord {
  headword: string;
  lemma: string;
  slug: string;
  pos: WordPos;
  cefr: Cefr;
  category: string;
  frequency: number;
  difficulty: number;
  ipa: string;
  short_meaning: string;
  meanings: Meaning[];
  usage: string;
  examples: ExampleSentence[];
  family: WordFamilyLinks;
  memory_tip: string;
  image_prompt: string;
  noun_grammar?: NounGrammar | null;
  verb_grammar?: VerbGrammar | null;
  adjective_grammar?: AdjectiveGrammar | null;
  adverb_grammar?: AdverbGrammar | null;
  preposition_grammar?: PrepositionGrammar | null;
  book_ids: string[];
  published: boolean;
}

export interface UserWordRecord extends BaseRecord {
  user: RecordId;
  word: RecordId | "";
  custom_headword: string;
  custom_data: Partial<WordRecord> | null;
  bookmarked: boolean;
  favorite: boolean;
  status: "new" | "learning" | "known";
  progress: number;
  views: number;
  last_seen_at: ISODate | "";
  source: string;
  source_id: string;
}

export interface SrsReview {
  at: ISODate;
  rating: number;
  interval: number;
  box: number;
}

export interface SrsCardRecord extends BaseRecord {
  user: RecordId;
  word: RecordId;
  box: 1 | 2 | 3 | 4 | 5;
  reps: number;
  lapses: number;
  ease: number;
  interval: number;
  stability: number;
  difficulty: number;
  due_at: ISODate;
  last_review_at: ISODate | "";
  last_rating: number;
  history: SrsReview[];
}

export interface ProverbRecord extends BaseRecord {
  kind: "sprichwort" | "redewendung";
  de: string;
  literal: string;
  fa: string;
  meaning: string;
  example: string;
  cefr: Cefr;
  icon: string;
  color: string;
}

export interface VerbRecord extends BaseRecord {
  word: RecordId | "";
  infinitive: string;
  separable: boolean;
  regular: boolean;
  aux: "haben" | "sein";
  praeteritum: string;
  perfekt: string;
  partizip_ii: string;
  praesens_conj: Conjugation;
  praeteritum_conj: Conjugation;
  perfekt_conj: Conjugation;
  governed_prepositions: GovernedPreposition[];
  object_case: "Akk" | "Dat" | "Gen" | "none";
  reflexive: boolean;
}

export interface FamilyMember {
  id: string;
  word: string;
  pos: "verb" | "noun" | "adjective" | "adverb";
  prefix?: string;
  root: string;
  suffix?: string;
  article?: "der" | "die" | "das";
  separable?: boolean;
  meaningDe: string;
  meaningFa: string;
  example: string;
  cefr: Cefr;
  familyId?: string;
}

export interface PrefixInfo {
  prefix: string;
  separable: boolean;
  meaningDe: string;
  meaningFa: string;
  example: string;
  exampleMeaningFa: string;
}

export interface WordFamilyRecord extends BaseRecord {
  root: string;
  label: string;
  meaning_de: string;
  meaning_fa: string;
  cefr: Cefr;
  note_de: string;
  note_fa: string;
  members: FamilyMember[];
  prefixes: PrefixInfo[];
}

/* -------------------------------------------------------------------------- */
/* گرامر                                                                       */
/* -------------------------------------------------------------------------- */

export type GrammarCategoryKey =
  | "cases"
  | "articles"
  | "tenses"
  | "modal-verbs"
  | "sentence-structure"
  | "adjective-endings"
  | "prepositions"
  | "passive"
  | "konjunktiv"
  | "relative-clauses"
  | "word-order"
  | "common-mistakes";

export type ExerciseType =
  | "multiple-choice"
  | "fill-blank"
  | "drag-drop"
  | "rearrange"
  | "build-sentence"
  | "match"
  | "error-correction"
  | "select";

export interface ExerciseData {
  options?: string[];
  answer?: string | string[];
  tokens?: string[];
  pairs?: { left: string; right: string }[];
  wrong?: string;
  correct?: string;
  explanation?: string;
}

export interface RoadmapNode {
  id: string;
  title: string;
  kind: string;
  duration?: number;
  lessonId?: string;
}

export interface LessonSection {
  id: string;
  kind: string;
  title: string;
  body?: string;
  sentences?: unknown[];
  exercise?: { id: string; type: ExerciseType; prompt: string; data: ExerciseData };
  bullets?: string[];
  compare?: { wrong: string; right: string; why: string }[];
}

export interface GrammarTopicRecord extends BaseRecord {
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  category: GrammarCategoryKey;
  emoji: string;
  difficulty: Cefr;
  duration: number;
  accent: string;
  nodes: RoadmapNode[];
  order: number;
  published: boolean;
}

export interface GrammarLessonRecord extends BaseRecord {
  topic: RecordId;
  node_id: string;
  slug: string;
  title: string;
  subtitle: string;
  emoji: string;
  duration: number;
  difficulty: Cefr;
  sections: LessonSection[];
  order: number;
  published: boolean;
}

export interface ExerciseRecord extends BaseRecord {
  lesson: RecordId | "";
  type: ExerciseType;
  prompt: string;
  data: ExerciseData;
  explanation: string;
  cefr: Cefr;
  order: number;
}

export interface LessonProgressRecord extends BaseRecord {
  user: RecordId;
  lesson: RecordId;
  progress: number;
  status: "not-started" | "in-progress" | "done";
  score: number;
  seconds_spent: number;
  answers: Record<string, unknown>;
  completed_at: ISODate | "";
}

/* -------------------------------------------------------------------------- */
/* خواندن و نوشتن                                                              */
/* -------------------------------------------------------------------------- */

export type ReadingCategory =
  | "alltag"
  | "kultur"
  | "nachrichten"
  | "wissenschaft"
  | "geschichte"
  | "reisen"
  | "beruf"
  | "gesellschaft";

export interface ArticleParagraph {
  id: string;
  text: string;
  translation?: string;
}

export interface VocabItem {
  id: string;
  word: string;
  article?: "der" | "die" | "das";
  meaning: string;
  example?: string;
  level?: Cefr;
  /** اختیاری برای واژه‌های مدیا (پادکست): تلفظ و نقش دستوری. */
  ipa?: string;
  pos?: string;
}

export interface ReadingQuestion {
  id: string;
  type: "mcq" | "truefalse" | "fill" | "match" | "vocab";
  question: string;
  options?: string[];
  answer: string | string[] | boolean;
  explanation?: string;
}

export interface ArticleRecord extends BaseRecord {
  slug: string;
  title: string;
  description: string;
  category: ReadingCategory;
  level: Cefr;
  minutes: number;
  words: number;
  cover: string;
  cover_image: string;
  author: string;
  published_at: ISODate | "";
  content: ArticleParagraph[];
  vocab: VocabItem[];
  questions: ReadingQuestion[];
  ai_summary: string;
  grammar_notes: { title: string; body: string }[];
  published: boolean;
}

export interface ReadingProgressRecord extends BaseRecord {
  user: RecordId;
  article: RecordId;
  progress: number;
  scroll_position: number;
  finished: boolean;
  question_answers: Record<string, unknown>;
  quiz_score: number;
  last_read_at: ISODate | "";
}

export interface WritingSubmissionRecord extends BaseRecord {
  user: RecordId;
  prompt_id: string;
  title: string;
  body: string;
  level: Cefr;
  task_type: "email" | "essay" | "letter" | "description" | "free";
  word_count: number;
  status: "draft" | "submitted" | "reviewed";
  ai_feedback: Record<string, unknown> | null;
  score: number;
  submitted_at: ISODate | "";
}

/* -------------------------------------------------------------------------- */
/* مدیا                                                                        */
/* -------------------------------------------------------------------------- */

export interface SubtitleWord {
  w: string;
  wordId?: string;
}

export interface SubtitleCue {
  id: string;
  start: number;
  end: number;
  words?: SubtitleWord[];
  translation?: string;
  /** متن آلمانی و ترجمهٔ فارسی زیرنویس (هم‌شکل با mockKino). */
  de?: string;
  fa?: string;
}

export interface FilmRecord extends BaseRecord {
  slug: string;
  title: string;
  title_fa: string;
  year: number;
  duration: string;
  level: Cefr;
  genre: string[];
  director: string;
  synopsis: string;
  synopsis_fa: string;
  poster: string;
  poster_image: string;
  video_url: string;
  video_file: string;
  cues: SubtitleCue[];
  published: boolean;
}

export interface ArtistRecord extends BaseRecord {
  slug: string;
  name: string;
  genre: string;
  bio: string;
  accent: string;
  photo: string;
}

export interface LyricLine {
  id: string;
  start: number;
  end: number;
  words: { w: string; wordId?: string }[];
  translationFa?: string;
  /** ترجمهٔ نمایش‌داده‌شده در UI (هم‌شکل با mockMusic). */
  translation?: string;
}

export interface SongVocabItem {
  id: string;
  word: string;
  pos: "noun" | "verb" | "adjective";
  article?: "der" | "die" | "das";
  meaning: string;
  example?: string;
  level?: Cefr;
  /** صرف‌های اختیاری (هم‌شکل با SongVocab در mockMusic). */
  plural?: string;
  praeteritum?: string;
  perfekt?: string;
  comparative?: string;
  superlative?: string;
}

export interface SongRecord extends BaseRecord {
  slug: string;
  title: string;
  artist: RecordId | "";
  album: string;
  year: number;
  duration_sec: number;
  level: Cefr;
  genre: string;
  cover: string;
  cover_image: string;
  accent: string;
  audio_url: string;
  audio_file: string;
  waveform: number[];
  lyrics: LyricLine[];
  vocab: SongVocabItem[];
  note_fa: string;
  published: boolean;
}

export interface PodcastShowRecord extends BaseRecord {
  slug: string;
  title: string;
  publisher: string;
  tagline: string;
  cover: string;
  cover_image: string;
  accent: string;
  level: string;
  category: string;
  episodes_count: number;
}

export interface TranscriptLine {
  id: string;
  start: number;
  end: number;
  speaker?: string;
  words: { w: string; wordId?: string }[];
  translationFa?: string;
  /** ترجمهٔ نمایش‌داده‌شده در UI (هم‌شکل با mockPodcasts). */
  translation?: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface EpisodeRecord extends BaseRecord {
  show: RecordId | "";
  slug: string;
  number: number;
  title: string;
  description: string;
  summary: string;
  cover: string;
  accent: string;
  category: string;
  level: string;
  published_at: ISODate | "";
  duration_sec: number;
  waveform: number[];
  audio_url: string;
  audio_file: string;
  transcript: TranscriptLine[];
  vocab: VocabItem[];
  quiz: QuizQuestion[];
  featured: boolean;
  published: boolean;
}

export interface BookRecord extends BaseRecord {
  slug: string;
  title: string;
  publisher: string;
  level: Cefr;
  cover: string;
  cover_image: string;
  color: string;
  word_count: number;
  word_ids: string[];
  published: boolean;
}

export interface MediaProgressRecord extends BaseRecord {
  user: RecordId;
  media_type: MediaType;
  media_id: string;
  position_sec: number;
  progress: number;
  finished: boolean;
  plays: number;
  quiz_answers: Record<string, unknown>;
  quiz_score: number;
  last_played_at: ISODate | "";
}

export interface MediaVocabRecord extends BaseRecord {
  user: RecordId;
  media_type: MediaType;
  media_id: string;
  word_text: string;
  word: RecordId | "";
  context: string;
  timestamp_sec: number;
  added_to_srs: boolean;
}

/* -------------------------------------------------------------------------- */
/* آزمون‌ها                                                                    */
/* -------------------------------------------------------------------------- */

export type ExamSkill = "Lesen" | "Hoeren" | "Schreiben" | "Sprechen" | "Modelltest";

export interface ExamRecord extends BaseRecord {
  slug: string;
  name: string;
  short_name: string;
  description: string;
  levels: string[];
  purposes: string[];
  comparison: Record<string, string>;
  resources: unknown[];
  practice_files: unknown[];
  books: unknown[];
  centers: unknown[];
  faq: { q: string; a: string }[];
  prep_plan: { week: string; focus: string; tasks: string[] }[];
  accent: string;
  published: boolean;
}

export interface ExamSectionRecord extends BaseRecord {
  exam: RecordId;
  skill: ExamSkill;
  title: string;
  duration_min: number;
  max_points: number;
  questions: unknown[];
  order: number;
}

export interface ExamAttemptRecord extends BaseRecord {
  user: RecordId;
  exam: RecordId | "";
  section: RecordId | "";
  status: "in-progress" | "submitted" | "scored" | "abandoned";
  started_at: ISODate | "";
  deadline_at: ISODate | "";
  submitted_at: ISODate | "";
  seconds_remaining: number;
  score: number;
  max_score: number;
  result_level: Cefr;
  section_scores: Record<string, number>;
}

export interface AnswerRecord extends BaseRecord {
  user: RecordId;
  attempt: RecordId;
  question_id: string;
  value: unknown;
  correct: boolean;
  points: number;
  answered_at: ISODate | "";
}

/* -------------------------------------------------------------------------- */
/* برنامه‌ریز                                                                   */
/* -------------------------------------------------------------------------- */

export type GoalKey =
  | "general"
  | "migration"
  | "university"
  | "work"
  | "goethe"
  | "testdaf"
  | "conversation"
  | "travel"
  | "personal"
  | "other";

export interface StudyPlanRecord extends BaseRecord {
  user: RecordId;
  level: CefrOrUnknown;
  goals: GoalKey[];
  weak_skills: SkillKey[];
  strong_skills: SkillKey[];
  daily_minutes: number;
  available_days: number[];
  preferred_start: TimeString;
  intensity: "light" | "steady" | "intense";
  week_start: DayString;
  target_minutes: number;
  active: boolean;
  generated_at: ISODate | "";
  prefs: Record<string, unknown>;
}

export interface PlanSessionRecord extends BaseRecord {
  user: RecordId;
  plan: RecordId | "";
  date: DayString;
  start: TimeString;
  end: TimeString;
  minutes: number;
  activity_id: string;
  module: string;
  skill: SkillKey;
  title: string;
  description: string;
  level: CefrOrUnknown;
  priority: "low" | "normal" | "high";
  status: "planned" | "done" | "skipped";
  href: string;
  cta: string;
  resource_id: string;
  generated: boolean;
  edited: boolean;
}

export interface SessionLogRecord extends BaseRecord {
  user: RecordId;
  session: RecordId | "";
  skill: SkillKey;
  minutes: number;
  items_done: number;
  accuracy: number;
  xp_earned: number;
  started_at: ISODate | "";
  ended_at: ISODate | "";
  meta: Record<string, unknown>;
}

/* -------------------------------------------------------------------------- */
/* کامیونیتی و رویدادها                                                        */
/* -------------------------------------------------------------------------- */

export interface PostRecord extends BaseRecord {
  author: RecordId;
  title: string;
  body: string;
  tags: string[];
  level: Cefr;
  images: string[];
  likes: number;
  comments_count: number;
  pinned: boolean;
  hidden: boolean;
}

export interface CommentRecord extends BaseRecord {
  post: RecordId;
  author: RecordId;
  body: string;
  reply_to: RecordId | "";
  likes: number;
  hidden: boolean;
}

export interface ChatRecord extends BaseRecord {
  kind: "room" | "group" | "dm";
  title: string;
  title_fa: string;
  description: string;
  color: string;
  emoji: string;
  owner: RecordId | "";
  members: RecordId[];
  private: boolean;
  last_message_at: ISODate | "";
}

export interface MessageRecord extends BaseRecord {
  chat: RecordId;
  author: RecordId;
  body: string;
  image: string;
  reply_to: RecordId | "";
  deleted: boolean;
  read_by: RecordId[];
}

export interface ChatReadRecord extends BaseRecord {
  user: RecordId;
  chat: RecordId;
  last_read_at: ISODate | "";
  unread: number;
}

export interface TandemProfileRecord extends BaseRecord {
  user: RecordId;
  headline: string;
  native_language: string;
  level: Cefr;
  goal: string;
  availability: string;
  description: string;
  active: boolean;
}

export type LevelBand = "B1-B2" | "C1-C2";

export interface EventGroup {
  id: string;
  name: string;
  level: LevelBand;
  tableNumber: number;
  seats: number;
  leader: { id: string; name: string; role: string };
}

export interface EventRecord extends BaseRecord {
  slug: string;
  institute_id: string;
  title: string;
  short_description: string;
  description: string;
  cover: string;
  cover_image: string;
  organizer: {
    id: string;
    name: string;
    tagline: string;
    rating: number;
    reviews: number;
    verified: boolean;
  } | null;
  starts_at: ISODate | "";
  ends_at: ISODate | "";
  date_label: string;
  weekday: string;
  time_label: string;
  duration_label: string;
  location_name: string;
  location_address: string;
  levels: Cefr[];
  level_summary: string;
  bands: LevelBand[];
  themes_count: number;
  groups_count: number;
  seats_per_group: number;
  notes: string[];
  groups: EventGroup[];
  weekly_topics: { weekLabel: string; topics: Record<LevelBand, string[]> } | null;
  price: number;
  currency: string;
  published: boolean;
}

export interface EventRsvpRecord extends BaseRecord {
  user: RecordId;
  event: RecordId;
  group_id: string;
  seat: number;
  participant_name: string;
  order_note: string;
  status: "reserved" | "waitlist" | "canceled" | "attended";
  reserved_at: ISODate | "";
}

export interface ReportRecord extends BaseRecord {
  reporter: RecordId;
  target_type: "post" | "comment" | "message" | "tandem_profile" | "user";
  target_id: string;
  reason: "spam" | "harassment" | "hate" | "sexual" | "other";
  details: string;
  status: "open" | "reviewing" | "resolved" | "rejected";
}

export interface BlockRecord extends BaseRecord {
  user: RecordId;
  blocked_user: RecordId;
  reason: string;
}

/* -------------------------------------------------------------------------- */
/* گیمیفیکیشن (نوشتن فقط سمت سرور)                                             */
/* -------------------------------------------------------------------------- */

export type XpSource =
  | "srs"
  | "lesson"
  | "reading"
  | "media"
  | "exam"
  | "planner"
  | "community"
  | "streak"
  | "achievement"
  | "mission"
  | "other";

export interface XpLedgerRecord extends BaseRecord {
  user: RecordId;
  amount: number;
  source: XpSource;
  source_id: string;
  note: string;
  earned_at: ISODate | "";
}

export interface AchievementRecord extends BaseRecord {
  slug: string;
  title: string;
  title_fa: string;
  description: string;
  icon: string;
  category:
    | "vocabulary"
    | "grammar"
    | "reading"
    | "listening"
    | "streak"
    | "community"
    | "exam"
    | "special";
  rarity: Rarity;
  xp_reward: number;
  criteria: Record<string, unknown>;
  hidden: boolean;
}

export interface UserAchievementRecord extends BaseRecord {
  user: RecordId;
  achievement: RecordId;
  progress: number;
  unlocked: boolean;
  unlocked_at: ISODate | "";
}

export interface MissionRecord extends BaseRecord {
  slug: string;
  title: string;
  description: string;
  period: "daily" | "weekly" | "season";
  target: number;
  xp_reward: number;
  criteria: Record<string, unknown>;
  active: boolean;
}

export interface UserMissionRecord extends BaseRecord {
  user: RecordId;
  mission: RecordId;
  period_key: string;
  progress: number;
  completed: boolean;
  completed_at: ISODate | "";
}

export interface StreakRecord extends BaseRecord {
  user: RecordId;
  current: number;
  longest: number;
  last_active_day: ISODate | "";
  freezes_left: number;
  week_map: boolean[];
}

export interface DailyStatRecord extends BaseRecord {
  user: RecordId;
  day: DayString;
  minutes: number;
  xp: number;
  words_reviewed: number;
  words_learned: number;
  lessons_done: number;
  articles_read: number;
  media_minutes: number;
  accuracy: number;
  skill_minutes: Partial<Record<SkillKey, number>>;
}

/* -------------------------------------------------------------------------- */
/* متعلقات کاربر                                                               */
/* -------------------------------------------------------------------------- */

export interface NotificationRecord extends BaseRecord {
  user: RecordId;
  kind: "system" | "srs" | "planner" | "community" | "event" | "achievement" | "exam";
  title: string;
  body: string;
  href: string;
  read: boolean;
  read_at: ISODate | "";
  meta: Record<string, unknown>;
}

export type BookmarkTarget =
  | "word"
  | "article"
  | "lesson"
  | "film"
  | "song"
  | "episode"
  | "book"
  | "proverb"
  | "event"
  | "post";

export interface BookmarkRecord extends BaseRecord {
  user: RecordId;
  target_type: BookmarkTarget;
  target_id: string;
  label: string;
  meta: Record<string, unknown>;
}

export interface ContactMessageRecord extends BaseRecord {
  name: string;
  email: string;
  subject: string;
  message: string;
  topic: "support" | "bug" | "billing" | "feedback" | "other";
  user: RecordId | "";
  status: "new" | "read" | "answered";
}

/* -------------------------------------------------------------------------- */
/* هوش مصنوعی                                                                  */
/* -------------------------------------------------------------------------- */

export interface AiThreadRecord extends BaseRecord {
  user: RecordId;
  title: string;
  mode: "coach" | "grammar" | "writing" | "conversation" | "translate";
  level: CefrOrUnknown;
  last_message_at: ISODate | "";
  archived: boolean;
}

export interface AiMessageRecord extends BaseRecord {
  user: RecordId;
  thread: RecordId;
  role: "user" | "assistant" | "system";
  content: string;
  meta: Record<string, unknown>;
  tokens: number;
}

export interface AiUsageRecord extends BaseRecord {
  user: RecordId;
  day: DayString;
  requests: number;
  tokens_in: number;
  tokens_out: number;
  model: string;
}

/* -------------------------------------------------------------------------- */
/* نگاشت کالکشن → تایپ                                                         */
/* -------------------------------------------------------------------------- */

export interface Collections {
  users: UserRecord;
  profiles: ProfileRecord;
  settings: SettingsRecord;
  placement_results: PlacementResultRecord;
  subscriptions: SubscriptionRecord;
  words: WordRecord;
  user_words: UserWordRecord;
  srs_cards: SrsCardRecord;
  proverbs: ProverbRecord;
  verbs: VerbRecord;
  word_families: WordFamilyRecord;
  grammar_topics: GrammarTopicRecord;
  grammar_lessons: GrammarLessonRecord;
  exercises: ExerciseRecord;
  lesson_progress: LessonProgressRecord;
  articles: ArticleRecord;
  reading_progress: ReadingProgressRecord;
  writing_submissions: WritingSubmissionRecord;
  films: FilmRecord;
  artists: ArtistRecord;
  songs: SongRecord;
  podcast_shows: PodcastShowRecord;
  episodes: EpisodeRecord;
  books: BookRecord;
  media_progress: MediaProgressRecord;
  media_vocab: MediaVocabRecord;
  exams: ExamRecord;
  exam_sections: ExamSectionRecord;
  exam_attempts: ExamAttemptRecord;
  answers: AnswerRecord;
  study_plans: StudyPlanRecord;
  plan_sessions: PlanSessionRecord;
  session_logs: SessionLogRecord;
  posts: PostRecord;
  comments: CommentRecord;
  chats: ChatRecord;
  messages: MessageRecord;
  chat_reads: ChatReadRecord;
  tandem_profiles: TandemProfileRecord;
  events: EventRecord;
  event_rsvps: EventRsvpRecord;
  reports: ReportRecord;
  blocks: BlockRecord;
  xp_ledger: XpLedgerRecord;
  achievements: AchievementRecord;
  user_achievements: UserAchievementRecord;
  missions: MissionRecord;
  user_missions: UserMissionRecord;
  streaks: StreakRecord;
  daily_stats: DailyStatRecord;
  notifications: NotificationRecord;
  bookmarks: BookmarkRecord;
  contact_messages: ContactMessageRecord;
  ai_threads: AiThreadRecord;
  ai_messages: AiMessageRecord;
  ai_usage: AiUsageRecord;
}

export type CollectionName = keyof Collections;
export type RecordOf<K extends CollectionName> = Collections[K];
export type CreateOf<K extends CollectionName> = CreateInput<Collections[K]>;
export type UpdateOf<K extends CollectionName> = UpdateInput<Collections[K]>;
