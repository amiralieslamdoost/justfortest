/**
 * Konfiguration der Datenschicht / پیکربندی لایهٔ داده.
 *
 * تنها منبع آدرس بک‌اند: `VITE_PB_URL`.
 * اگر تعریف نشده باشد، اپ در حالت MOCK اجرا می‌شود و دقیقاً مثل قبل
 * از دیتای محلی (`src/lib/deusi/*` + localStorage) استفاده می‌کند.
 */

const raw = (import.meta.env.VITE_PB_URL as string | undefined) ?? "";

/** آدرس PocketBase بدون اسلش انتهایی. رشتهٔ خالی یعنی بک‌اند تنظیم نشده. */
export const PB_URL = raw.trim().replace(/\/+$/, "");

/** true وقتی هیچ بک‌اندی تنظیم نشده — همهٔ سرویس‌ها به آداپتور mock می‌روند. */
export const MOCK_MODE = PB_URL === "";

/** true وقتی PocketBase در دسترس است. */
export const BACKEND = !MOCK_MODE;

/** حداکثر زمان انتظار برای هر درخواست (میلی‌ثانیه). */
export const REQUEST_TIMEOUT_MS = 15_000;
