import { DEFAULT_PREFS } from "./config";
import { toMinutes, weekStartOf } from "./date";
import type { PlannerPrefs, PlannerSession, PlannerWeek, PlannerWeekMeta } from "./types";

/**
 * Persistenz-Schicht des Planers.
 *
 * Alle Planer-Daten liegen im localStorage des Nutzers.
 */

const KEY = (userId: string) => `deusi.planner.${userId}`;

type LocalShape = {
  prefs: PlannerPrefs | null;
  weeks: Record<string, PlannerWeekMeta>;
  sessions: PlannerSession[];
};

const EMPTY: LocalShape = { prefs: null, weeks: {}, sessions: [] };

function readLocal(userId: string): LocalShape {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = localStorage.getItem(KEY(userId));
    if (!raw) return { ...EMPTY, weeks: {}, sessions: [] };
    const parsed = JSON.parse(raw) as Partial<LocalShape>;
    return {
      prefs: parsed.prefs ?? null,
      weeks: parsed.weeks ?? {},
      sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
    };
  } catch {
    return { ...EMPTY, weeks: {}, sessions: [] };
  }
}

function writeLocal(userId: string, data: LocalShape) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(KEY(userId), JSON.stringify(data));
  } catch (err) {
    console.warn("[planner] localStorage write failed", err);
  }
}

export function normalizePrefs(input: Partial<PlannerPrefs> | null): PlannerPrefs {
  const merged = { ...DEFAULT_PREFS, ...(input ?? {}) } as PlannerPrefs;
  return {
    ...merged,
    dailyMinutes: Math.max(10, Math.min(240, Math.round(merged.dailyMinutes || 45))),
    availableDays: (merged.availableDays?.length
      ? merged.availableDays
      : DEFAULT_PREFS.availableDays
    )
      .filter((d) => d >= 0 && d <= 6)
      .sort((a, b) => a - b),
    goals: merged.goals?.length ? merged.goals : DEFAULT_PREFS.goals,
    weakSkills: merged.weakSkills ?? [],
    strongSkills: merged.strongSkills ?? [],
    updatedAt: merged.updatedAt ?? new Date().toISOString(),
  };
}

/* ------------------------------------------------------------ Präferenzen */

export async function loadPrefs(userId: string): Promise<PlannerPrefs | null> {
  return readLocal(userId).prefs;
}

export async function savePrefs(userId: string, prefs: PlannerPrefs): Promise<void> {
  const local = readLocal(userId);
  writeLocal(userId, { ...local, prefs });
}

/* ------------------------------------------------------------------ Woche */

export async function loadWeek(userId: string, weekStart: string): Promise<PlannerWeek | null> {
  const local = readLocal(userId);
  const sessions = local.sessions.filter((s) => weekKeyOf(s.date) === weekStart);
  const meta = local.weeks[weekStart];
  if (!meta && !sessions.length) return null;
  return {
    weekStart,
    targetMinutes: meta?.targetMinutes ?? 0,
    generatedAt: meta?.generatedAt ?? null,
    sessions: sortSessions(sessions),
  };
}

/** Ersetzt eine ganze Woche (Regenerieren). */
export async function saveWeek(userId: string, week: PlannerWeek): Promise<void> {
  const local = readLocal(userId);
  const others = local.sessions.filter((s) => weekKeyOf(s.date) !== week.weekStart);
  writeLocal(userId, {
    ...local,
    weeks: {
      ...local.weeks,
      [week.weekStart]: {
        weekStart: week.weekStart,
        targetMinutes: week.targetMinutes,
        generatedAt: week.generatedAt,
      },
    },
    sessions: [...others, ...week.sessions],
  });
}

/** Einzelne Session speichern (anlegen oder ändern). */
export async function putSession(
  userId: string,
  weekStart: string,
  session: PlannerSession,
): Promise<void> {
  const local = readLocal(userId);
  const sessions = local.sessions.filter((s) => s.id !== session.id);
  writeLocal(userId, { ...local, sessions: [...sessions, session] });
}

export async function deleteSession(userId: string, sessionId: string): Promise<void> {
  const local = readLocal(userId);
  writeLocal(userId, { ...local, sessions: local.sessions.filter((s) => s.id !== sessionId) });
}

/* ----------------------------------------------------------------- Utils */

function weekKeyOf(date: string): string {
  return weekStartOf(date);
}

export function sortSessions(sessions: PlannerSession[]): PlannerSession[] {
  return [...sessions].sort(
    (a, b) => a.date.localeCompare(b.date) || toMinutes(a.start) - toMinutes(b.start),
  );
}
