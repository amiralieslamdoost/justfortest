import { useCallback, useEffect, useMemo, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { ACTIVITY_BY_ID, FALLBACK_ACTIVITY } from "./activities";
import { addClock, todayISO, weekStartOf } from "./date";
import { generateWeek, newSessionId, sessionFromActivity, skillDistribution } from "./engine";
import * as storage from "./storage";
import type {
  ActivityDef,
  PlannerPrefs,
  PlannerSession,
  PlannerWeek,
  SessionStatus,
  SkillKey,
} from "./types";

/**
 * Zentraler Planer-Hook.
 *
 * Lädt Profil und Woche (PocketBase oder Offline-Spiegel), erzeugt bei Bedarf
 * einen Plan und stellt alle Bearbeitungs-Aktionen bereit. Die UI kennt weder
 * Persistenz noch Engine.
 */

export type PlannerStatus = "loading" | "onboarding" | "ready" | "anonymous";

export function usePlanner(initialWeek?: string) {
  const { currentUser, hydrated } = useDeusi();
  const userId = currentUser?.id ?? "";

  const [weekStart, setWeekStart] = useState(() => weekStartOf(initialWeek ?? todayISO()));
  const [prefs, setPrefs] = useState<PlannerPrefs | null>(null);
  const [week, setWeek] = useState<PlannerWeek | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /* ------------------------------------------------------------- Laden */

  useEffect(() => {
    if (!hydrated) return;
    if (!userId) {
      setPrefs(null);
      setWeek(null);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const loadedPrefs = await storage.loadPrefs(userId);
        const loadedWeek = await storage.loadWeek(userId, weekStart);
        if (cancelled) return;
        setPrefs(loadedPrefs);
        setWeek(loadedWeek);
        setError(null);
      } catch (err) {
        console.error("[planner] load failed", err);
        if (!cancelled) setError("Der Plan konnte nicht geladen werden.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [hydrated, userId, weekStart]);

  const status: PlannerStatus =
    !hydrated || loading ? "loading" : !userId ? "anonymous" : !prefs ? "onboarding" : "ready";

  /* ---------------------------------------------------------- Speichern */

  const persistWeek = useCallback(
    async (next: PlannerWeek) => {
      setWeek(next);
      if (!userId) return;
      try {
        await storage.saveWeek(userId, next);
      } catch (err) {
        console.error("[planner] save week failed", err);
        setError("Änderungen konnten nicht gespeichert werden.");
      }
    },
    [userId],
  );

  const persistSession = useCallback(
    async (session: PlannerSession) => {
      if (!userId) return;
      try {
        await storage.putSession(userId, weekStart, session);
      } catch (err) {
        console.error("[planner] save session failed", err);
        setError("Die Session konnte nicht gespeichert werden.");
      }
    },
    [userId, weekStart],
  );

  /* ------------------------------------------------------------ Aktionen */

  /** Profil speichern und Woche neu planen. */
  const savePrefs = useCallback(
    async (input: Partial<PlannerPrefs>) => {
      const next = storage.normalizePrefs({
        ...(prefs ?? {}),
        ...input,
        updatedAt: new Date().toISOString(),
      });
      setPrefs(next);
      setBusy(true);
      try {
        if (userId) await storage.savePrefs(userId, next);
        const keep = (week?.sessions ?? []).filter((s) => !s.generated || s.status === "done");
        await persistWeek(generateWeek(next, weekStart, { keep }));
      } finally {
        setBusy(false);
      }
      return next;
    },
    [persistWeek, prefs, userId, week, weekStart],
  );

  /**
   * Woche neu erzeugen.
   * `mode: "keep-edits"` schützt manuell veränderte, eigene und erledigte Sessions.
   */
  const regenerate = useCallback(
    async (mode: "keep-edits" | "fresh" = "keep-edits") => {
      if (!prefs) return;
      setBusy(true);
      try {
        const keep =
          mode === "fresh"
            ? []
            : (week?.sessions ?? []).filter((s) => s.edited || !s.generated || s.status === "done");
        await persistWeek(generateWeek(prefs, weekStart, { keep }));
      } finally {
        setBusy(false);
      }
    },
    [persistWeek, prefs, week, weekStart],
  );

  const updateSession = useCallback(
    async (id: string, patch: Partial<PlannerSession>) => {
      if (!week) return;
      let updated: PlannerSession | null = null;
      const sessions = week.sessions.map((s) => {
        if (s.id !== id) return s;
        const minutes = patch.minutes ?? s.minutes;
        const start = patch.start ?? s.start;
        updated = {
          ...s,
          ...patch,
          minutes,
          start,
          end: patch.end ?? addClock(start, minutes),
          edited: true,
          updatedAt: new Date().toISOString(),
        };
        return updated;
      });
      await persistWeek({ ...week, sessions: storage.sortSessions(sessions) });
      if (updated) await persistSession(updated);
    },
    [persistSession, persistWeek, week],
  );

  const setSessionStatus = useCallback(
    (id: string, status: SessionStatus) => updateSession(id, { status }),
    [updateSession],
  );

  /** Session auf einen anderen Tag / eine andere Zeit legen. */
  const moveSession = useCallback(
    (id: string, date: string, start?: string) =>
      updateSession(id, { date, ...(start ? { start } : {}) }),
    [updateSession],
  );

  const removeSession = useCallback(
    async (id: string) => {
      if (!week) return;
      await persistWeek({ ...week, sessions: week.sessions.filter((s) => s.id !== id) });
      if (userId) await storage.deleteSession(userId, id);
    },
    [persistWeek, userId, week],
  );

  /** Eigene Session hinzufügen (aus dem Aktivitäten-Katalog). */
  /** Komplett freie, selbst formulierte Lerneinheit (nicht aus dem Katalog). */
  const addCustomSession = useCallback(
    async (input: {
      title: string;
      description?: string;
      skill: SkillKey;
      date: string;
      start: string;
      minutes: number;
    }) => {
      const now = new Date().toISOString();
      const session: PlannerSession = {
        id: newSessionId(),
        date: input.date,
        start: input.start,
        end: addClock(input.start, input.minutes),
        minutes: input.minutes,
        activityId: "custom",
        module: "planner",
        skill: input.skill,
        title: input.title.trim() || "Eigene Lerneinheit",
        description: (input.description ?? "").trim(),
        level: prefs?.level ?? "unknown",
        priority: "normal",
        status: "planned",
        href: "/dashboard",
        cta: "Öffnen",
        generated: false,
        edited: true,
        createdAt: now,
        updatedAt: now,
      };
      const base: PlannerWeek = week ?? {
        weekStart,
        targetMinutes: 0,
        generatedAt: null,
        sessions: [],
      };
      await persistWeek({
        ...base,
        sessions: storage.sortSessions([...base.sessions, session]),
      });
      await persistSession(session);
      return session;
    },
    [persistSession, persistWeek, prefs, week, weekStart],
  );

  const addSession = useCallback(
    async (input: { activityId: string; date: string; start: string; minutes: number }) => {
      const activity: ActivityDef = ACTIVITY_BY_ID[input.activityId] ?? FALLBACK_ACTIVITY;
      const session = {
        ...sessionFromActivity(activity, {
          date: input.date,
          start: input.start,
          minutes: input.minutes,
          level: prefs?.level ?? "unknown",
          generated: false,
        }),
        generated: false,
      };
      const base: PlannerWeek = week ?? {
        weekStart,
        targetMinutes: 0,
        generatedAt: null,
        sessions: [],
      };
      await persistWeek({
        ...base,
        sessions: storage.sortSessions([...base.sessions, session]),
      });
      await persistSession(session);
      return session;
    },
    [persistSession, persistWeek, prefs, week, weekStart],
  );

  const goToWeek = useCallback((next: string) => setWeekStart(weekStartOf(next)), []);

  /* ------------------------------------------------------------ Ableitungen */

  const sessions = week?.sessions ?? [];

  const stats = useMemo(() => {
    const planned = sessions.reduce((a, s) => a + s.minutes, 0);
    const done = sessions.filter((s) => s.status === "done");
    const doneMinutes = done.reduce((a, s) => a + s.minutes, 0);
    return {
      plannedMinutes: planned,
      doneMinutes,
      doneCount: done.length,
      totalCount: sessions.length,
      skippedCount: sessions.filter((s) => s.status === "skipped").length,
      progress: planned ? Math.round((doneMinutes / planned) * 100) : 0,
      distribution: skillDistribution(sessions),
    };
  }, [sessions]);

  const today = todayISO();
  const todaySessions = useMemo(() => sessions.filter((s) => s.date === today), [sessions, today]);
  const nextSession = useMemo(
    () => todaySessions.find((s) => s.status === "planned") ?? null,
    [todaySessions],
  );

  return {
    status,
    loading,
    busy,
    error,
    prefs,
    week,
    weekStart,
    sessions,
    stats,
    today,
    todaySessions,
    nextSession,
    goToWeek,
    savePrefs,
    regenerate,
    updateSession,
    setSessionStatus,
    moveSession,
    removeSession,
    addSession,
    addCustomSession,
  };
}

export type PlannerApi = ReturnType<typeof usePlanner>;
