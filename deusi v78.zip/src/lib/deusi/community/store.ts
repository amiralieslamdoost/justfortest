import { useCallback, useSyncExternalStore } from "react";
import { INITIAL_CHATS, MOCK_TANDEM, COMMUNITY_USERS, getUser } from "./mockCommunity";
import type { Chat, CommunityUser, Message, TandemProfile } from "./types";

/**
 * Chat-Store (rein clientseitig).
 *
 * Der Store arbeitet mit In-Memory-Daten, damit die UI ohne Backend
 * vollständig funktioniert.
 */
let chats: Chat[] = INITIAL_CHATS;
let ads: TandemProfile[] = MOCK_TANDEM;
const listeners = new Set<() => void>();

function emit() {
  chats = [...chats];
  ads = [...ads];
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

const getChats = () => chats;
const getAds = () => ads;

function patch(id: string, fn: (chat: Chat) => Chat) {
  chats = chats.map((c) => (c.id === id ? fn(c) : c));
  emit();
}

let seq = 0;
const nextId = () => `local-${Date.now()}-${seq++}`;

export type Draft = { body: string; imageUrl?: string; replyToId?: string };

/** Users searchable by @handle or name (without me). */
export function searchUsers(query: string): CommunityUser[] {
  const q = query.trim().toLowerCase().replace(/^@/, "");
  if (!q) return [];
  return Object.values(COMMUNITY_USERS).filter(
    (u) =>
      u.id !== "me" && (u.handle.toLowerCase().includes(q) || u.name.toLowerCase().includes(q)),
  );
}

export function useCommunity() {
  const allChats = useSyncExternalStore(subscribe, getChats, getChats);
  const tandemAds = useSyncExternalStore(subscribe, getAds, getAds);

  const sendMessage = useCallback((chatId: string, draft: Draft) => {
    const text = draft.body.trim();
    if (!text && !draft.imageUrl) return;
    const msg: Message = {
      id: nextId(),
      authorId: "me",
      body: text,
      time: "jetzt",
      imageUrl: draft.imageUrl,
      replyToId: draft.replyToId,
    };
    patch(chatId, (c) => ({
      ...c,
      lastTime: "jetzt",
      unread: 0,
      messages: [...c.messages, msg],
    }));
  }, []);

  const deleteMessage = useCallback((chatId: string, messageId: string) => {
    patch(chatId, (c) => ({
      ...c,
      messages: c.messages.map((m) =>
        m.id === messageId ? { ...m, body: "", imageUrl: undefined, deleted: true } : m,
      ),
    }));
  }, []);

  const markRead = useCallback((chatId: string) => {
    const chat = chats.find((c) => c.id === chatId);
    if (!chat || chat.unread === 0) return;
    patch(chatId, (c) => ({ ...c, unread: 0 }));
  }, []);

  const toggleJoined = useCallback((chatId: string) => {
    patch(chatId, (c) => ({ ...c, joined: !c.joined }));
  }, []);

  const addMember = useCallback((chatId: string, userId: string) => {
    patch(chatId, (c) =>
      c.members.includes(userId) ? c : { ...c, members: [...c.members, userId] },
    );
  }, []);

  const updateChat = useCallback(
    (
      chatId: string,
      input: Partial<Pick<Chat, "title" | "description" | "emoji" | "private" | "color">>,
    ) => {
      patch(chatId, (c) => ({ ...c, ...input }));
    },
    [],
  );

  const removeMember = useCallback((chatId: string, userId: string) => {
    patch(chatId, (c) => ({ ...c, members: c.members.filter((m) => m !== userId) }));
  }, []);

  const createGroup = useCallback(
    (input: { name: string; description: string; private: boolean }) => {
      const id = `group-${nextId()}`;
      chats = [
        {
          id,
          kind: "group",
          title: input.name.trim(),
          description: input.description.trim() || undefined,
          color: "#6366f1",
          emoji: "✨",
          ownerId: "me",
          members: [],
          joined: true,
          private: input.private,
          unread: 0,
          lastTime: "jetzt",
          messages: [],
        },
        ...chats,
      ];
      emit();
      return id;
    },
    [],
  );

  /** Opens (or creates) the private chat with a user and returns its id. */
  const openDirectChat = useCallback((userId: string) => {
    const existing = chats.find((c) => c.kind === "dm" && c.partnerId === userId);
    if (existing) return existing.id;
    const user = getUser(userId);
    const id = `dm-${userId}`;
    chats = [
      {
        id,
        kind: "dm",
        title: user.name,
        color: user.color,
        members: [userId],
        partnerId: userId,
        joined: true,
        unread: 0,
        lastTime: "jetzt",
        messages: [],
      },
      ...chats,
    ];
    emit();
    return id;
  }, []);

  const createAd = useCallback((input: Omit<TandemProfile, "id" | "userId" | "mine">) => {
    const ad: TandemProfile = { ...input, id: `ad-${nextId()}`, userId: "me", mine: true };
    ads = [ad, ...ads];
    emit();
    return ad.id;
  }, []);

  const deleteAd = useCallback((id: string) => {
    ads = ads.filter((a) => a.id !== id);
    emit();
  }, []);

  return {
    chats: allChats,
    tandemAds,
    sendMessage,
    deleteMessage,
    markRead,
    toggleJoined,
    addMember,
    updateChat,
    removeMember,
    createGroup,
    openDirectChat,
    createAd,
    deleteAd,
  };
}
