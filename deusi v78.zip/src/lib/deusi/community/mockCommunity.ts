import type { Chat, CommunityLevel, CommunityUser, TandemProfile } from "./types";

const U = (
  id: string,
  name: string,
  initials: string,
  level: CommunityLevel,
  color: string,
  online = false,
): CommunityUser => ({ id, name, handle: `@${id}`, initials, level, color, online });

export const ME: CommunityUser = U("me", "Du", "DU", "B1", "#f97316", true);

export const COMMUNITY_USERS: Record<string, CommunityUser> = {
  me: ME,
  sara: U("sara", "Sara M.", "SM", "B2", "#ef4444", true),
  amir: U("amir", "Amir K.", "AK", "A2", "#0ea5e9"),
  lena: U("lena", "Lena Vogt", "LV", "C1", "#8b5cf6", true),
  nima: U("nima", "Nima R.", "NR", "B1", "#10b981"),
  yalda: U("yalda", "Yalda H.", "YH", "A2", "#f59e0b", true),
  jonas: U("jonas", "Jonas Weber", "JW", "C2", "#0f766e"),
  mina: U("mina", "Mina S.", "MS", "B2", "#db2777"),
};

export function getUser(id: string): CommunityUser {
  return COMMUNITY_USERS[id] ?? U(id, "Mitglied", "??", "B1", "#94a3b8");
}

const m = (id: string, authorId: string, body: string, time: string, day?: string) => ({
  id,
  authorId,
  body,
  time,
  day,
});

/** Öffentliche Talare — replace the old Q&A tab: ask and chat in one place. */
const ROOMS: Chat[] = [
  {
    id: "room-grammatik",
    kind: "room",
    title: "Grammatik",
    titleFa: "گرامر",
    description: "Fragen zu Fällen, Zeiten und Satzbau.",
    color: "#c2410c",
    emoji: "📐",
    members: ["sara", "amir", "lena", "nima", "yalda", "jonas", "mina"],
    joined: true,
    unread: 3,
    lastTime: "09:41",
    messages: [
      m(
        "g1",
        "amir",
        "Wann benutzt man „seit“ und wann „vor“? Ich verwechsle die beiden ständig.",
        "09:12",
        "Heute",
      ),
      m(
        "g2",
        "lena",
        "„vor“ = ein Zeitpunkt in der Vergangenheit: „Ich bin vor zwei Jahren umgezogen.“ „seit“ = ein Zeitraum bis heute: „Ich wohne seit zwei Jahren hier.“",
        "09:18",
      ),
      m("g3", "amir", "Ahh, das ergibt Sinn. Danke! 🙏", "09:20"),
      m("g4", "mina", "Kleiner Trick: „seit“ + Präsens, „vor“ + Perfekt.", "09:41"),
    ],
  },
  {
    id: "room-wortschatz",
    kind: "room",
    title: "Wortschatz",
    titleFa: "واژگان",
    description: "Neue Wörter, Redewendungen und Synonyme.",
    color: "#0ea5e9",
    emoji: "🧩",
    members: ["sara", "lena", "nima", "mina"],
    joined: true,
    unread: 0,
    lastTime: "Gestern",
    messages: [
      m(
        "w1",
        "sara",
        "Wort des Tages: „die Vorfreude“ — die Freude auf etwas Kommendes. 😊",
        "18:02",
        "Gestern",
      ),
      m("w2", "nima", "Auf Persisch gibt es dafür kein einzelnes Wort. Schön!", "18:20"),
      m("w3", "me", "Ich schreibe es direkt in meine Leitner-Box.", "18:26"),
    ],
  },
  {
    id: "room-aussprache",
    kind: "room",
    title: "Aussprache",
    titleFa: "تلفظ",
    description: "Umlaute, „ch“, Betonung und Sprachnachrichten.",
    color: "#8b5cf6",
    emoji: "🎧",
    members: ["yalda", "jonas", "amir"],
    joined: true,
    unread: 1,
    lastTime: "Mo",
    messages: [
      m("a1", "yalda", "Wie spricht man „Streichholzschächtelchen“ aus? 😅", "11:04", "Montag"),
      m(
        "a2",
        "jonas",
        "Langsam anfangen und in Silben zerlegen: Streich-holz-schäch-tel-chen.",
        "11:10",
      ),
    ],
  },
  {
    id: "room-pruefung",
    kind: "room",
    title: "Prüfung",
    titleFa: "آزمون",
    description: "Goethe, telc & ÖSD — Tipps und Lernpläne.",
    color: "#10b981",
    emoji: "🎯",
    members: ["sara", "mina", "jonas"],
    joined: true,
    unread: 0,
    lastTime: "Mo",
    messages: [
      m("p1", "mina", "Nächsten Monat B2 telc. Wer übt mit mir den Sprechteil?", "20:15", "Montag"),
      m("p2", "sara", "Ich bin dabei! Am besten dienstags abends.", "20:31"),
    ],
  },
  {
    id: "room-alltag",
    kind: "room",
    title: "Alltag",
    titleFa: "زندگی روزمره",
    description: "Behörden, Wohnung, Arbeit — einfach quatschen.",
    color: "#f59e0b",
    emoji: "☕",
    members: ["amir", "yalda", "nima", "lena"],
    joined: true,
    unread: 0,
    lastTime: "So",
    messages: [
      m(
        "al1",
        "nima",
        "Anmeldung beim Bürgeramt — hat jemand einen Tipp für einen Termin?",
        "13:22",
        "Sonntag",
      ),
      m("al2", "lena", "Früh morgens die Seite aktualisieren, da werden Termine frei.", "13:40"),
    ],
  },
];

const GROUPS: Chat[] = [
  {
    id: "group-b1-abends",
    kind: "group",
    title: "B1 Abendrunde",
    ownerId: "me",
    description: "Kleine Lerngruppe, jeden Abend 20 Uhr.",
    color: "#ef4444",
    emoji: "🌙",
    members: ["sara", "nima", "mina"],
    joined: true,
    private: true,
    unread: 2,
    lastTime: "21:08",
    messages: [
      m("b1", "sara", "Heute Abend Kapitel 4? Ich bringe die Übungen mit.", "20:55", "Heute"),
      m("b2", "me", "Perfekt, ich bin um 20 Uhr da.", "21:02"),
      m("b3", "nima", "Bis gleich! 👋", "21:08"),
    ],
  },
  {
    id: "group-persisch-deutsch",
    kind: "group",
    title: "Persisch ↔ Deutsch",
    ownerId: "sara",
    description: "Wir helfen uns gegenseitig beim Übersetzen.",
    color: "#0f766e",
    emoji: "🤝",
    members: ["amir", "yalda", "jonas"],
    joined: true,
    unread: 0,
    lastTime: "Gestern",
    messages: [
      m("pd1", "yalda", "Wie sagt man „دلم برات تنگ شده“ auf Deutsch?", "16:12", "Gestern"),
      m("pd2", "jonas", "„Ich vermisse dich.“ 🙂", "16:14"),
    ],
  },
  {
    id: "group-filmclub",
    kind: "group",
    title: "Filmclub",
    ownerId: "lena",
    description: "Jede Woche ein Film auf Deutsch — mit Untertiteln.",
    color: "#6366f1",
    emoji: "🎬",
    members: ["lena", "mina", "sara", "jonas"],
    joined: false,
    unread: 0,
    lastTime: "Fr",
    messages: [
      m("f1", "lena", "Diese Woche: „Good Bye, Lenin!“ — wer ist dabei?", "19:00", "Freitag"),
    ],
  },
];

const DMS: Chat[] = [
  {
    id: "dm-sara",
    kind: "dm",
    title: "Sara M.",
    color: "#ef4444",
    members: ["sara"],
    partnerId: "sara",
    joined: true,
    unread: 1,
    lastTime: "10:24",
    messages: [
      m("s1", "sara", "Hallo! Sollen wir morgen 30 Minuten sprechen?", "10:02", "Heute"),
      m("s2", "me", "Sehr gerne — 18 Uhr passt mir gut.", "10:12"),
      m("s3", "sara", "Super, ich schicke dir den Link. 😊", "10:24"),
    ],
  },
  {
    id: "dm-jonas",
    kind: "dm",
    title: "Jonas Weber",
    color: "#0f766e",
    members: ["jonas"],
    partnerId: "jonas",
    joined: true,
    unread: 0,
    lastTime: "Gestern",
    messages: [
      m("j1", "jonas", "Deine Aussprache war heute richtig gut!", "17:40", "Gestern"),
      m("j2", "me", "Danke! Ich übe jeden Tag zehn Minuten.", "17:55"),
    ],
  },
];

export const INITIAL_CHATS: Chat[] = [...ROOMS, ...GROUPS, ...DMS];

export const MOCK_TANDEM: TandemProfile[] = [
  {
    id: "t-lena",
    userId: "lena",
    headline: "Deutsch gegen Persisch — 30 Min. pro Woche",
    nativeLanguage: "Deutsch",
    level: "C1",
    goal: "Persisch lernen",
    availability: "Abends",
    description:
      "Ich korrigiere gerne deine Aussprache und Grammatik. Im Gegenzug möchte ich Persisch für den Alltag üben. Wir sprechen 15 Minuten Deutsch, 15 Minuten Persisch.",
  },
  {
    id: "t-amir",
    userId: "amir",
    headline: "A2: einfache Alltagsgespräche üben",
    nativeLanguage: "Persisch",
    level: "A2",
    goal: "A2 sprechen üben",
    availability: "Wochenende",
    description:
      "Ich bin noch Anfänger und suche jemanden mit Geduld. Themen: Einkaufen, Arzttermin, Small Talk. Bitte langsam sprechen. 🙂",
  },
  {
    id: "t-mina",
    userId: "mina",
    headline: "telc B2 Sprechteil — Partner gesucht",
    nativeLanguage: "Persisch",
    level: "B2",
    goal: "telc B2 Sprechteil",
    availability: "Dienstags",
    description:
      "Prüfung in vier Wochen. Ich möchte den Sprechteil 1 und 2 mit Zeitmessung durchspielen und danach Feedback geben.",
  },
  {
    id: "t-jonas",
    userId: "jonas",
    headline: "Muttersprachler bietet Sprachaustausch",
    nativeLanguage: "Deutsch",
    level: "C2",
    goal: "Sprachaustausch",
    availability: "Flexibel",
    description:
      "Ich habe Zeit für lockere Gespräche über Filme, Musik und Politik. Ich schreibe dir neue Wörter immer als Liste auf.",
  },
  {
    id: "t-yalda",
    userId: "yalda",
    headline: "Morgens sprechen — Alltagsdeutsch",
    nativeLanguage: "Persisch",
    level: "A2",
    goal: "Alltagsgespräche",
    availability: "Morgens",
    description:
      "Ich lerne seit sechs Monaten und möchte jeden Morgen 20 Minuten sprechen, damit ich nicht wieder alles vergesse.",
  },
];
