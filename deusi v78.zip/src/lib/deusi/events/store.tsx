import { useCallback, useEffect, useState } from "react";
import { MOCK_EVENTS, type DeusiEvent, type EventGroup, type SeatReservation } from "./mockEvents";

/**
 * Multi-tenant friendly registration & order store.
 * Data is keyed by `${instituteId}::${eventId}` in localStorage
 * so multiple institutes can host independent events later.
 */

export interface Registration {
  eventId: string;
  instituteId: string;
  groupId: string; // "A".."G"
  tableNumber: number;
  seat: number; // 1..10
  level: string;
  leaderName: string;
  registeredAt: number;
}

interface EventState {
  reservations: Record<string, SeatReservation[]>; // groupId -> reservations (extra, on top of seed)
  myRegistration: Registration | null;
}

const KEY = (instituteId: string, eventId: string) => `deusi.events::${instituteId}::${eventId}`;

function load(instituteId: string, eventId: string): EventState {
  if (typeof window === "undefined") return { reservations: {}, myRegistration: null };
  try {
    const raw = localStorage.getItem(KEY(instituteId, eventId));
    if (!raw) return { reservations: {}, myRegistration: null };
    return JSON.parse(raw) as EventState;
  } catch {
    return { reservations: {}, myRegistration: null };
  }
}

function persist(instituteId: string, eventId: string, s: EventState) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(KEY(instituteId, eventId), JSON.stringify(s));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

// Merge seed reservations + persisted extras
export function mergedGroups(event: DeusiEvent, state: EventState): EventGroup[] {
  if (!event.groups) return [];
  return event.groups.map((g) => {
    const extra = state.reservations[g.id] ?? [];
    const merged = [
      ...g.reservations,
      ...extra.filter((e) => !g.reservations.some((r) => r.seat === e.seat)),
    ];
    return { ...g, reservations: merged };
  });
}

export function useEventState(event: DeusiEvent) {
  const [state, setState] = useState<EventState>({ reservations: {}, myRegistration: null });
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setState(load(event.instituteId, event.id));
    setHydrated(true);
  }, [event.instituteId, event.id]);

  useEffect(() => {
    if (hydrated) persist(event.instituteId, event.id, state);
  }, [state, hydrated, event.instituteId, event.id]);

  const groups = mergedGroups(event, state);

  const findFirstFreeSeat = useCallback((): { group: EventGroup; seat: number } | null => {
    for (const g of groups) {
      const taken = new Set(g.reservations.map((r) => r.seat));
      for (let s = 1; s <= g.seats; s++) {
        if (!taken.has(s)) return { group: g, seat: s };
      }
    }
    return null;
  }, [groups]);

  const register = useCallback(
    (participantName: string): Registration | null => {
      if (state.myRegistration) return state.myRegistration;
      const spot = findFirstFreeSeat();
      if (!spot) return null;

      const reg: Registration = {
        eventId: event.id,
        instituteId: event.instituteId,
        groupId: spot.group.id,
        tableNumber: spot.group.tableNumber,
        seat: spot.seat,
        level: spot.group.level,
        leaderName: spot.group.leader.name,
        registeredAt: Date.now(),
      };

      setState((prev) => {
        const extra = prev.reservations[spot.group.id] ?? [];
        return {
          myRegistration: reg,
          reservations: {
            ...prev.reservations,
            [spot.group.id]: [...extra, { seat: spot.seat, participantName }],
          },
        };
      });

      return reg;
    },
    [state.myRegistration, findFirstFreeSeat, event.id, event.instituteId],
  );

  const submitOrder = useCallback(
    (order: string) => {
      const reg = state.myRegistration;
      if (!reg || !order.trim()) return;
      setState((prev) => {
        const extra = prev.reservations[reg.groupId] ?? [];
        return {
          ...prev,
          reservations: {
            ...prev.reservations,
            [reg.groupId]: extra.map((r) =>
              r.seat === reg.seat ? { ...r, order: order.trim() } : r,
            ),
          },
        };
      });
    },
    [state.myRegistration],
  );

  const cancelRegistration = useCallback(() => {
    const reg = state.myRegistration;
    if (!reg) return;
    setState((prev) => {
      const extra = prev.reservations[reg.groupId] ?? [];
      return {
        myRegistration: null,
        reservations: {
          ...prev.reservations,
          [reg.groupId]: extra.filter((r) => r.seat !== reg.seat),
        },
      };
    });
  }, [state.myRegistration]);

  return {
    groups,
    myRegistration: state.myRegistration,
    register,
    submitOrder,
    cancelRegistration,
    hydrated,
  };
}

export function totalStats(event: DeusiEvent, groups: EventGroup[]) {
  if (!event.groups) {
    return {
      participants: 0,
      remaining: event.groupsCount * event.seatsPerGroup,
      total: event.groupsCount * event.seatsPerGroup,
      groups: event.groupsCount,
    };
  }
  const total = groups.reduce((s, g) => s + g.seats, 0);
  const participants = groups.reduce((s, g) => s + g.reservations.length, 0);
  return {
    participants,
    remaining: total - participants,
    total,
    groups: groups.length,
  };
}

export function allEventsForInstitute(instituteId: string) {
  return MOCK_EVENTS.filter((e) => e.instituteId === instituteId);
}
