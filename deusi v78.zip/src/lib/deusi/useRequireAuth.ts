import { useEffect } from "react";
import { useRouter } from "@tanstack/react-router";
import { useDeusi } from "./store";

/**
 * Redirects to /login when no user is signed in — but only AFTER the store has
 * hydrated from localStorage. Without the `hydrated` gate the very first render
 * (server + pre-hydration client) always sees `currentUser === null` and kicks
 * signed-in users out to /login on direct page loads / refreshes.
 */
export function useRequireAuth() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  return { currentUser, hydrated };
}
