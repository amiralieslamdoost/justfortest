/**
 * Gamification layer for the /achievements page:
 * XP + levels, rarity tiers, daily/weekly missions, league season
 * and the leaderboard ("Bestenliste" / نفرات برتر).
 *
 * All data is mock data for now — the shapes are ready for a real backend.
 */

import { ACHIEVEMENTS, unlockedCount } from "./achievements";

/* ------------------------------------------------------------------ */
/* XP & Level                                                          */
/* ------------------------------------------------------------------ */

export const TOTAL_XP = 3240;

/** XP required to reach a given level (quadratic-ish curve). */
export function xpForLevel(level: number): number {
  return 250 * (level - 1) * level;
}

export function levelFromXp(xp: number): number {
  let lvl = 1;
  while (xpForLevel(lvl + 1) <= xp) lvl++;
  return lvl;
}

export const LEVEL = levelFromXp(TOTAL_XP);
export const LEVEL_XP_FLOOR = xpForLevel(LEVEL);
export const LEVEL_XP_CEIL = xpForLevel(LEVEL + 1);
export const LEVEL_XP_IN = TOTAL_XP - LEVEL_XP_FLOOR;
export const LEVEL_XP_NEED = LEVEL_XP_CEIL - LEVEL_XP_FLOOR;
export const LEVEL_PCT = Math.round((LEVEL_XP_IN / LEVEL_XP_NEED) * 100);

export const LEVEL_TITLES: Record<number, { de: string; fa: string }> = {
  1: { de: "Anfänger", fa: "تازه‌کار" },
  2: { de: "Entdecker", fa: "کاشف" },
  3: { de: "Sammler", fa: "گردآورنده" },
  4: { de: "Aufsteiger", fa: "روبه‌رشد" },
  5: { de: "Sprachjäger", fa: "شکارچی واژه" },
  6: { de: "Wortmeister", fa: "استاد واژگان" },
  7: { de: "Sprachprofi", fa: "حرفه‌ای زبان" },
  8: { de: "Legende", fa: "اسطوره" },
};

export const LEVEL_TITLE = LEVEL_TITLES[Math.min(LEVEL, 8)];
export const NEXT_LEVEL_TITLE = LEVEL_TITLES[Math.min(LEVEL + 1, 8)];

/* ------------------------------------------------------------------ */
/* Rarity                                                              */
/* ------------------------------------------------------------------ */

export type Rarity = "common" | "rare" | "epic" | "legendary";

export const RARITY_META: Record<Rarity, { de: string; fa: string; color: string; xp: number }> = {
  common: { de: "Gewöhnlich", fa: "معمولی", color: "#94A3B8", xp: 50 },
  rare: { de: "Selten", fa: "کمیاب", color: "#3B82F6", xp: 120 },
  epic: { de: "Episch", fa: "حماسی", color: "#A855F7", xp: 250 },
  legendary: { de: "Legendär", fa: "افسانه‌ای", color: "#F59E0B", xp: 500 },
};

const RARITY_BY_ID: Record<string, Rarity> = {
  "streak-14": "rare",
  "streak-30": "epic",
  "streak-100": "legendary",
  "words-100": "common",
  "words-500": "rare",
  "words-1000": "epic",
  "grammar-pro": "rare",
  "grammar-cases": "rare",
  "grammar-master": "epic",
  "listen-5": "common",
  "listen-song": "rare",
  "listen-25": "epic",
  "read-first": "common",
  "read-book": "rare",
  "exam-a2": "epic",
  "exam-b1": "legendary",
  "xp-1000": "rare",
  "xp-5000": "legendary",
};

/** How many % of all learners own this badge — drives the "rarity" feel. */
const OWNERS_BY_RARITY: Record<Rarity, number> = {
  common: 62,
  rare: 28,
  epic: 9,
  legendary: 2,
};

export function rarityOf(id: string): Rarity {
  return RARITY_BY_ID[id] ?? "common";
}

export function ownersPctOf(id: string): number {
  return OWNERS_BY_RARITY[rarityOf(id)];
}

export const RARITY_ORDER: Rarity[] = ["common", "rare", "epic", "legendary"];

export const RARITY_SUMMARY = RARITY_ORDER.map((r) => {
  const all = ACHIEVEMENTS.filter((a) => rarityOf(a.id) === r);
  return {
    rarity: r,
    total: all.length,
    unlocked: all.filter((a) => a.unlocked).length,
  };
});

/* ------------------------------------------------------------------ */
/* Missions                                                            */
/* ------------------------------------------------------------------ */

export interface Mission {
  id: string;
  titleDe: string;
  titleFa: string;
  emoji: string;
  xp: number;
  current: number;
  target: number;
  href: string;
  color: string;
}

export const DAILY_MISSIONS: Mission[] = [
  {
    id: "d-words",
    titleDe: "10 neue Wörter lernen",
    titleFa: "۱۰ واژه جدید یاد بگیر",
    emoji: "📚",
    xp: 40,
    current: 7,
    target: 10,
    href: "/dictionary",
    color: "#8B5CF6",
  },
  {
    id: "d-leitner",
    titleDe: "20 Leitner-Karten wiederholen",
    titleFa: "۲۰ کارت لایتنر مرور کن",
    emoji: "🗂️",
    xp: 30,
    current: 20,
    target: 20,
    href: "/leitner",
    color: "#22C55E",
  },
  {
    id: "d-listen",
    titleDe: "1 Podcast hören",
    titleFa: "یک پادکست گوش بده",
    emoji: "🎧",
    xp: 35,
    current: 0,
    target: 1,
    href: "/podcasts",
    color: "#EC4899",
  },
];

export const WEEKLY_MISSIONS: Mission[] = [
  {
    id: "w-grammar",
    titleDe: "5 Grammatik-Lektionen abschließen",
    titleFa: "۵ درس گرامر کامل کن",
    emoji: "✍️",
    xp: 150,
    current: 3,
    target: 5,
    href: "/grammatik",
    color: "#16A34A",
  },
  {
    id: "w-read",
    titleDe: "3 Artikel lesen",
    titleFa: "۳ مقاله بخوان",
    emoji: "📰",
    xp: 120,
    current: 1,
    target: 3,
    href: "/lesen",
    color: "#0EA5E9",
  },
  {
    id: "w-exam",
    titleDe: "1 Prüfungssimulation machen",
    titleFa: "یک آزمون آزمایشی بده",
    emoji: "🎓",
    xp: 200,
    current: 0,
    target: 1,
    href: "/pruefungen",
    color: "#14B8A6",
  },
];

export const missionPct = (m: Mission) => Math.min(100, Math.round((m.current / m.target) * 100));

export const DAILY_DONE = DAILY_MISSIONS.filter((m) => m.current >= m.target).length;
export const DAILY_XP_OPEN = DAILY_MISSIONS.filter((m) => m.current < m.target).reduce(
  (s, m) => s + m.xp,
  0,
);

/* ------------------------------------------------------------------ */
/* League / Season                                                     */
/* ------------------------------------------------------------------ */

export interface League {
  id: string;
  de: string;
  fa: string;
  emoji: string;
  color: string;
}

export const LEAGUES: League[] = [
  { id: "bronze", de: "Bronze", fa: "برنز", emoji: "🥉", color: "#B45309" },
  { id: "silber", de: "Silber", fa: "نقره", emoji: "🥈", color: "#94A3B8" },
  { id: "gold", de: "Gold", fa: "طلا", emoji: "🥇", color: "#F59E0B" },
  { id: "diamant", de: "Diamant", fa: "الماس", emoji: "💎", color: "#22D3EE" },
  { id: "legende", de: "Legende", fa: "اسطوره", emoji: "👑", color: "#A855F7" },
];

export const CURRENT_LEAGUE_INDEX = 2; // Gold
export const CURRENT_LEAGUE = LEAGUES[CURRENT_LEAGUE_INDEX];
export const NEXT_LEAGUE = LEAGUES[CURRENT_LEAGUE_INDEX + 1];
export const SEASON = {
  nameDe: "Sommer-Saison",
  nameFa: "فصل تابستان",
  daysLeft: 6,
  promoteRank: 5,
  demoteRank: 26,
};

/* ------------------------------------------------------------------ */
/* Leaderboard                                                         */
/* ------------------------------------------------------------------ */

export type LeaderboardRange = "Woche" | "Monat" | "Gesamt";

export interface LeaderRow {
  id: string;
  name: string;
  initials: string;
  gradient: [string, string];
  xp: number;
  badges: number;
  streak: number;
  country: string;
  delta: number; // rank change vs. last period
  isMe?: boolean;
}

const BASE_ROWS: Omit<LeaderRow, "xp">[] = [
  {
    id: "1",
    name: "Sara Ahmadi",
    initials: "SA",
    gradient: ["#8B5CF6", "#EC4899"],
    badges: 16,
    streak: 61,
    country: "🇮🇷",
    delta: 1,
  },
  {
    id: "2",
    name: "Leon Weber",
    initials: "LW",
    gradient: ["#0EA5E9", "#22D3EE"],
    badges: 15,
    streak: 44,
    country: "🇩🇪",
    delta: -1,
  },
  {
    id: "3",
    name: "Niloofar R.",
    initials: "NR",
    gradient: ["#F97316", "#F59E0B"],
    badges: 14,
    streak: 38,
    country: "🇮🇷",
    delta: 3,
  },
  {
    id: "4",
    name: "Amir Tehrani",
    initials: "AT",
    gradient: ["#22C55E", "#84CC16"],
    badges: 13,
    streak: 33,
    country: "🇮🇷",
    delta: 0,
  },
  {
    id: "me",
    name: "Max Mustermann",
    initials: "MM",
    gradient: ["#8B5CF6", "#DD2222"],
    badges: unlockedCount,
    streak: 14,
    country: "🇮🇷",
    delta: 2,
    isMe: true,
  },
  {
    id: "6",
    name: "Yasmin K.",
    initials: "YK",
    gradient: ["#EC4899", "#F43F5E"],
    badges: 10,
    streak: 21,
    country: "🇹🇷",
    delta: -2,
  },
  {
    id: "7",
    name: "Daniel Fischer",
    initials: "DF",
    gradient: ["#14B8A6", "#0EA5E9"],
    badges: 9,
    streak: 12,
    country: "🇦🇹",
    delta: 1,
  },
  {
    id: "8",
    name: "Reza Karimi",
    initials: "RK",
    gradient: ["#6366F1", "#8B5CF6"],
    badges: 8,
    streak: 9,
    country: "🇮🇷",
    delta: -3,
  },
  {
    id: "9",
    name: "Mina S.",
    initials: "MS",
    gradient: ["#F59E0B", "#EF4444"],
    badges: 7,
    streak: 7,
    country: "🇮🇷",
    delta: 0,
  },
  {
    id: "10",
    name: "Jonas Braun",
    initials: "JB",
    gradient: ["#64748B", "#94A3B8"],
    badges: 6,
    streak: 4,
    country: "🇨🇭",
    delta: -1,
  },
];

const XP_BY_RANGE: Record<LeaderboardRange, number[]> = {
  Woche: [1840, 1720, 1610, 1480, 1290, 1180, 1040, 960, 870, 720],
  Monat: [6420, 6180, 5940, 5210, 4870, 4310, 3980, 3620, 3150, 2740],
  Gesamt: [24800, 23150, 21440, 18960, TOTAL_XP + 12000, 14320, 12980, 11450, 9870, 8210],
};

export function leaderboardFor(range: LeaderboardRange): LeaderRow[] {
  const xps = XP_BY_RANGE[range];
  return BASE_ROWS.map((r, i) => ({ ...r, xp: xps[i] })).sort((a, b) => b.xp - a.xp);
}

export function myRank(range: LeaderboardRange): number {
  return leaderboardFor(range).findIndex((r) => r.isMe) + 1;
}

/* ------------------------------------------------------------------ */
/* Weekly activity (streak calendar)                                   */
/* ------------------------------------------------------------------ */

export const WEEK_DAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
/** XP earned per weekday this week; -1 = future day. */
export const WEEK_XP = [120, 180, 90, 240, 160, 75, -1];
export const STREAK_DAYS = 14;
export const STREAK_BEST = 23;
export const STREAK_FREEZES = 2;
