import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";

export type InteractionType =
  "word" | "grammar" | "article" | "podcast" | "exam" | "music" | "film" | "book";

export const INTERACTION_TYPES: InteractionType[] = [
  "word",
  "grammar",
  "article",
  "podcast",
  "exam",
  "music",
  "film",
  "book",
];

export interface ItemMeta {
  title?: string;
  sub?: string;
  level?: string;
  /** target href, e.g. "/musik/song-1" */
  to?: string;
}

export interface Entry extends ItemMeta {
  id: string;
  type: InteractionType;
  at: string;
}

type State = Record<InteractionType, Entry[]>;

function emptyState(): State {
  return {
    word: [],
    grammar: [],
    article: [],
    podcast: [],
    exam: [],
    music: [],
    film: [],
    book: [],
  };
}

const LS_BOOKMARKS = "deusi.bookmarks.v2";
const LS_FAVORITES = "deusi.favorites.v2";
const LEGACY_BOOKMARKS = "deusi.bookmarks.v1";
const LEGACY_FAVORITES = "deusi.favorites.v1";

const LABELS: Record<InteractionType, string> = {
  word: "Wort",
  grammar: "Lektion",
  article: "Artikel",
  podcast: "Podcast",
  exam: "Prüfung",
  music: "Song",
  film: "Film",
  book: "Buch",
};

function normalize(raw: unknown, legacy: unknown): State {
  const state = emptyState();
  const merge = (source: unknown) => {
    if (!source || typeof source !== "object") return;
    for (const [key, list] of Object.entries(source as Record<string, unknown>)) {
      const type = key as InteractionType;
      if (!state[type] || !Array.isArray(list)) continue;
      for (const item of list) {
        if (typeof item === "string") {
          if (!state[type].some((e) => e.id === item)) {
            state[type].push({ id: item, type, at: new Date(0).toISOString() });
          }
        } else if (item && typeof item === "object" && typeof (item as Entry).id === "string") {
          const entry = item as Entry;
          if (!state[type].some((e) => e.id === entry.id)) {
            state[type].push({ ...entry, type });
          }
        }
      }
    }
  };
  merge(legacy);
  merge(raw);
  return state;
}

function loadState(key: string, legacyKey: string): State {
  if (typeof window === "undefined") return emptyState();
  try {
    const raw = localStorage.getItem(key);
    const legacy = localStorage.getItem(legacyKey);
    return normalize(raw ? JSON.parse(raw) : null, raw ? null : legacy ? JSON.parse(legacy) : null);
  } catch {
    return emptyState();
  }
}

function save(key: string, v: State) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

interface Ctx {
  bookmarks: State;
  favorites: State;
  bookmarkList: Entry[];
  favoriteList: Entry[];
  toggleBookmark: (type: InteractionType, id: string, meta?: string | ItemMeta) => void;
  toggleFavorite: (type: InteractionType, id: string, meta?: string | ItemMeta) => void;
  removeBookmark: (type: InteractionType, id: string) => void;
  removeFavorite: (type: InteractionType, id: string) => void;
  isBookmarked: (type: InteractionType, id: string) => boolean;
  isFavorited: (type: InteractionType, id: string) => boolean;
  totalBookmarks: number;
  totalFavorites: number;
  countBookmarks: (type: InteractionType) => number;
  countFavorites: (type: InteractionType) => number;
}

const InteractionsCtx = createContext<Ctx | null>(null);

function toMeta(meta?: string | ItemMeta): ItemMeta {
  if (!meta) return {};
  return typeof meta === "string" ? { title: meta } : meta;
}

function flatten(state: State): Entry[] {
  return Object.values(state)
    .flat()
    .sort((a, b) => (a.at < b.at ? 1 : -1));
}

export function InteractionsProvider({ children }: { children: ReactNode }) {
  const [bookmarks, setBookmarks] = useState<State>(emptyState);
  const [favorites, setFavorites] = useState<State>(emptyState);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setBookmarks(loadState(LS_BOOKMARKS, LEGACY_BOOKMARKS));
    setFavorites(loadState(LS_FAVORITES, LEGACY_FAVORITES));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) save(LS_BOOKMARKS, bookmarks);
  }, [bookmarks, hydrated]);
  useEffect(() => {
    if (hydrated) save(LS_FAVORITES, favorites);
  }, [favorites, hydrated]);

  const toggle = useCallback(
    (
      setter: React.Dispatch<React.SetStateAction<State>>,
      type: InteractionType,
      id: string,
      kind: "bookmark" | "favorite",
      meta?: string | ItemMeta,
    ) => {
      const m = toMeta(meta);
      setter((prev) => {
        const list = prev[type] ?? [];
        const has = list.some((e) => e.id === id);
        const next = has
          ? list.filter((e) => e.id !== id)
          : [{ id, type, at: new Date().toISOString(), ...m }, ...list];
        const name = m.title ?? LABELS[type];
        const verb = kind === "bookmark" ? "Lesezeichen" : "Favorit";
        toast.success(has ? `${verb} entfernt` : `${verb} gesetzt`, { description: name });
        return { ...prev, [type]: next };
      });
    },
    [],
  );

  const remove = useCallback(
    (setter: React.Dispatch<React.SetStateAction<State>>, type: InteractionType, id: string) => {
      setter((prev) => ({ ...prev, [type]: (prev[type] ?? []).filter((e) => e.id !== id) }));
    },
    [],
  );

  const value = useMemo<Ctx>(
    () => ({
      bookmarks,
      favorites,
      bookmarkList: flatten(bookmarks),
      favoriteList: flatten(favorites),
      toggleBookmark: (t, id, m) => toggle(setBookmarks, t, id, "bookmark", m),
      toggleFavorite: (t, id, m) => toggle(setFavorites, t, id, "favorite", m),
      removeBookmark: (t, id) => remove(setBookmarks, t, id),
      removeFavorite: (t, id) => remove(setFavorites, t, id),
      isBookmarked: (t, id) => (bookmarks[t] ?? []).some((e) => e.id === id),
      isFavorited: (t, id) => (favorites[t] ?? []).some((e) => e.id === id),
      totalBookmarks: Object.values(bookmarks).reduce((a, b) => a + b.length, 0),
      totalFavorites: Object.values(favorites).reduce((a, b) => a + b.length, 0),
      countBookmarks: (t) => (bookmarks[t] ?? []).length,
      countFavorites: (t) => (favorites[t] ?? []).length,
    }),
    [bookmarks, favorites, toggle, remove],
  );

  return <InteractionsCtx.Provider value={value}>{children}</InteractionsCtx.Provider>;
}

export function useInteractions() {
  const v = useContext(InteractionsCtx);
  if (!v) throw new Error("useInteractions must be used within InteractionsProvider");
  return v;
}
