import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { Fa } from "@/components/deusi/Fa";
import { SectionHero } from "@/components/deusi/SectionHero";
import { HeroSearch } from "@/components/deusi/HeroSearch";
import { fmtTime } from "@/components/deusi/music/MusicPlayer";
import { SongCard } from "@/components/deusi/music/SongCard";
import { GenreChips, LevelFilter, genreAccent } from "@/components/deusi/music/GenreChips";
import { PlaylistCard, ArtistCard } from "@/components/deusi/music/PlaylistCard";
import { MusicStats } from "@/components/deusi/music/MusicStats";
import {
  featuredSong,
  findPlaylist,
  musicGenres,
  musicLevels,
  playlists,
  recommendedTopicsMusic,
  artistName,
  type MusicGenreKey,
} from "@/lib/deusi/mockMusic";
import { useArtists, useMediaProgressMap, useSongs } from "@/lib/api/useMedia";
import { mediaKey } from "@/lib/api/mediaProgress";

export const Route = createFileRoute("/musik/")({
  head: () => ({
    meta: [
      { title: "Musik — Deutsch lernen mit Songs | DEUSI" },
      {
        name: "description",
        content:
          "Deutsche Songs mit synchronem Songtext, Übersetzung, Vokabeln für die Leitner-Box und Playlists nach Niveau.",
      },
      { property: "og:title", content: "Musik — Deutsch lernen mit Songs | DEUSI" },
      {
        property: "og:description",
        content: "Karaoke-Songtexte, Vokabeltraining und Playlists von A1 bis C1.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MusicPage,
});

const PAGE_SIZE = 10;

function MusicPage() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();

  // آهنگ‌ها/هنرمندان و پیشرفت واقعی کاربر از لایهٔ API — سشن ۵.
  const { songs } = useSongs({ perPage: 200 });
  const { artists } = useArtists();
  const { progress: mediaProgress } = useMediaProgressMap();

  const [genre, setGenre] = useState<MusicGenreKey>("fuer-dich");
  const [level, setLevel] = useState<string | null>(null);
  const [artistId, setArtistId] = useState<string | null>(null);
  const [playlistId, setPlaylistId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [onlyLyrics, setOnlyLyrics] = useState(false);
  const [visible, setVisible] = useState(PAGE_SIZE);
  const listRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  function selectGenre(k: MusicGenreKey) {
    setGenre(k);
    setPlaylistId(null);
    setArtistId(null);
    // Scroll to the list this filter drives
    requestAnimationFrame(() => {
      listRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  const activePlaylist = playlistId ? findPlaylist(playlistId) : null;

  const filtered = useMemo(() => {
    return songs.filter((s) => {
      if (activePlaylist && !activePlaylist.songIds.includes(s.id)) return false;
      if (artistId && s.artistId !== artistId) return false;
      if (genre !== "fuer-dich" && genre !== "alle" && s.genre !== genre) return false;
      if (level && s.level !== level) return false;
      if (onlyLyrics && s.lyrics.length === 0) return false;
      if (
        search &&
        !`${s.title} ${s.album} ${artistName(s.artistId)}`
          .toLowerCase()
          .includes(search.toLowerCase())
      )
        return false;
      return true;
    });
  }, [genre, level, artistId, search, activePlaylist, onlyLyrics, songs]);

  const suggestions = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [];
    return songs
      .filter((s) => `${s.title} ${s.album} ${artistName(s.artistId)}`.toLowerCase().includes(q))
      .slice(0, 6);
  }, [search, songs]);

  // Reset pagination on filter changes
  useEffect(() => {
    setVisible(PAGE_SIZE);
  }, [genre, level, artistId, playlistId, search, onlyLyrics]);

  const inProgress = songs
    .map((song) => {
      const st = mediaProgress[mediaKey("song", song.id)];
      if (!st || st.progress <= 0 || st.finished) return null;
      return {
        progress: { songId: song.id, progress: st.progress, lastPlayed: st.lastPlayedAt ?? "" },
        song,
      };
    })
    .filter((x): x is { progress: { songId: string; progress: number; lastPlayed: string }; song: (typeof songs)[number] } => Boolean(x))
    .slice(0, 6);

  const featured = songs[0] ?? featuredSong();
  const featuredArtist = artists.find((a) => a.id === featured.artistId);

  if (!currentUser) return null;

  const filtersActive = Boolean(activePlaylist || artistId || level || search || onlyLyrics);
  const shown = filtered.slice(0, visible);
  const remaining = Math.max(0, filtered.length - shown.length);

  return (
    <div className="space-y-6 animate-fade">
      <SectionHero
        sectionKey="music"
        allowOverflow
        right={
          <HeroSearch
            value={search}
            onValueChange={setSearch}
            placeholder="Songs, Alben, Künstler:innen…"
            ariaLabel="Musik durchsuchen"
            emptyText="Keine Songs"
            className="flex-1"
            items={suggestions.map((s) => ({
              id: s.id,
              title: s.title,
              sub: `${artistName(s.artistId)} · ${s.album}`,
              badge: s.level,
              glyph: "🎵",
              color: s.accent,
            }))}
            totalCount={filtered.length}
            onSelect={(id) => router.navigate({ to: "/musik/$songId", params: { songId: id } })}
            onSubmit={() => listRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })}
          />
        }
      />

      {/* --- Featured song: Spotify-style horizontal media card --- */}
      <section
        className="relative overflow-hidden rounded-3xl border border-border/60"
        style={{
          background: `linear-gradient(120deg, ${featured.accent}22 0%, transparent 60%), var(--card)`,
        }}
      >
        <div className="grid gap-5 p-4 sm:grid-cols-[auto_minmax(0,1fr)] sm:items-end sm:gap-6 sm:p-6">
          <div
            className="relative h-40 w-40 shrink-0 overflow-hidden rounded-2xl shadow-2xl sm:h-48 sm:w-48"
            style={{ background: featured.cover }}
          >
            {featured.coverUrl && (
              <img
                src={featured.coverUrl}
                alt={featured.title}
                className="h-full w-full object-cover"
              />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              <span
                className="inline-block h-1.5 w-1.5 rounded-full"
                style={{ background: featured.accent }}
              />
              Song der Woche
              <Fa inline className="!text-muted-foreground/80">
                آهنگ هفته
              </Fa>
            </div>
            <h2 className="mt-1.5 text-2xl font-black leading-tight sm:text-4xl">
              {featured.title}
            </h2>
            <p className="mt-1 truncate text-sm font-semibold text-muted-foreground">
              {featuredArtist?.name} · {featured.album} · {featured.year}
            </p>
            <Fa className="fa-hint-xs mt-1 line-clamp-2">{featured.noteFa}</Fa>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Link
                to="/musik/$songId"
                params={{ songId: featured.id }}
                className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-black text-white shadow-lg transition hover:scale-[1.03] active:scale-95"
                style={{
                  background: featured.accent,
                  boxShadow: `0 12px 28px -12px ${featured.accent}`,
                }}
              >
                <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                  <path d="M8 5v14l11-7z" />
                </svg>
                Jetzt abspielen
              </Link>
              <span className="rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-black text-muted-foreground">
                {featured.level}
              </span>
              <span className="rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-black tabular-nums text-muted-foreground">
                {fmtTime(featured.durationSec)}
              </span>
              <span className="rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-black text-muted-foreground">
                {featured.plays}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* --- Genre categories: bold, colorful, mobile-fit (2 rows, no scroll) --- */}
      <div className="space-y-2">
        <div className="flex items-end justify-between gap-2 px-0.5">
          <div>
            <h2 className="text-sm font-black sm:text-base">Kategorien</h2>
            <Fa className="fa-hint-xs">دسته‌بندی‌ها — برای دیدن آهنگ‌های هر دسته کلیک کن</Fa>
          </div>
        </div>
        <GenreChips genres={musicGenres} active={genre} onChange={selectGenre} />
      </div>

      <div className="grid gap-6 grid-cols-[minmax(0,1fr)] xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-8">
          {/* Playlists */}
          <section className="space-y-3">
            <Header de="Playlists nach Niveau" fa="پلی‌لیست‌ها بر اساس سطح" />
            <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4">
              {playlists.map((p) => (
                <PlaylistCard
                  key={p.id}
                  playlist={p}
                  onOpen={(id) => {
                    setPlaylistId(id);
                    setArtistId(null);
                    setGenre("alle");
                    setLevel(null);
                  }}
                />
              ))}
            </div>
          </section>

          {/* Artists — horizontal filter row */}
          <section className="space-y-3">
            <Header de="Künstler:innen" fa="هنرمندان — برای فیلتر آهنگ‌ها روی یک هنرمند کلیک کن" />
            <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-2 [scrollbar-width:thin]">
              {artists.map((a) => {
                const on = artistId === a.id;
                return (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => {
                      const next = on ? null : a.id;
                      setArtistId(next);
                      setPlaylistId(null);
                      if (next) {
                        setGenre("alle");
                        requestAnimationFrame(() =>
                          listRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
                        );
                      }
                    }}
                    aria-pressed={on}
                    className="group flex w-[92px] shrink-0 flex-col items-center gap-2 rounded-2xl p-2 transition hover:-translate-y-0.5"
                    style={
                      on
                        ? { background: `color-mix(in oklab, ${a.accent} 12%, transparent)` }
                        : undefined
                    }
                  >
                    <span
                      className="relative h-16 w-16 overflow-hidden rounded-full transition"
                      style={{
                        background: a.cover,
                        boxShadow: on
                          ? `0 0 0 3px ${a.accent}, 0 12px 24px -10px ${a.accent}`
                          : `0 0 0 2px color-mix(in oklab, ${a.accent} 40%, transparent)`,
                      }}
                    >
                      {a.coverUrl ? (
                        <img
                          src={a.coverUrl}
                          alt={a.name}
                          loading="lazy"
                          className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                        />
                      ) : (
                        <span className="grid h-full w-full place-items-center text-base font-black text-white/95">
                          {a.name
                            .split(/\s+/)
                            .slice(0, 2)
                            .map((w) => w[0])
                            .join("")}
                        </span>
                      )}
                    </span>
                    <span className="w-full truncate text-center text-[11px] font-black">
                      {a.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Continue listening */}
          {inProgress.length > 0 && !filtersActive && (
            <section className="space-y-3">
              <Header de="Weiterhören" fa="ادامه‌ی گوش دادن" />
              <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4">
                {inProgress.map(({ progress, song }) => (
                  <SongCard
                    key={song.id}
                    song={song}
                    layout="tile"
                    progressPct={progress.progress}
                  />
                ))}
              </div>
            </section>
          )}

          {/* --- Alle Songs + filters directly above --- */}
          <section ref={listRef} className="space-y-3 scroll-mt-24">
            <Header
              de={activePlaylist ? activePlaylist.title : "Alle Songs"}
              fa={activePlaylist ? activePlaylist.titleFa : "همه‌ی آهنگ‌ها"}
              count={filtered.length}
            />

            {/* Filter bar sits DIRECTLY above the list it filters */}
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border/60 bg-card p-3">
              <LevelFilter levels={musicLevels} active={level} onChange={setLevel} />
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOnlyLyrics((v) => !v)}
                  aria-pressed={onlyLyrics}
                  className={`rounded-full border px-3 py-1 text-[11px] font-black transition ${
                    onlyLyrics
                      ? "border-transparent bg-foreground text-background"
                      : "border-border bg-transparent text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  ♪ Nur Lyrics
                </button>
                {(filtersActive || (genre !== "alle" && genre !== "fuer-dich")) && (
                  <button
                    type="button"
                    onClick={() => {
                      setPlaylistId(null);
                      setArtistId(null);
                      setLevel(null);
                      setSearch("");
                      setOnlyLyrics(false);
                      setGenre("fuer-dich");
                    }}
                    className="rounded-full border border-destructive/40 bg-transparent px-3 py-1 text-[11px] font-black text-destructive transition hover:bg-destructive/10 hover:text-destructive"
                  >
                    Zurücksetzen ✕
                  </button>
                )}
              </div>
            </div>

            {(() => {
              const genreObj =
                genre !== "fuer-dich" && genre !== "alle"
                  ? musicGenres.find((g) => g.key === genre)
                  : null;
              if (!activePlaylist && !artistId && !genreObj) return null;
              const color = genreObj ? genreAccent[genreObj.key] : undefined;
              return (
                <div className="flex flex-wrap items-center gap-2 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
                  <span>Auswahl</span>
                  <span
                    className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-white"
                    style={{ background: color ?? "hsl(var(--foreground))" }}
                  >
                    {color && (
                      <span
                        className="inline-block h-1.5 w-1.5 rounded-full bg-white/90"
                        aria-hidden
                      />
                    )}
                    {activePlaylist
                      ? activePlaylist.title
                      : artistId
                        ? artists.find((a) => a.id === artistId)?.name
                        : genreObj?.label}
                  </span>
                </div>
              );
            })()}

            {filtered.length === 0 ? (
              <p className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
                Keine Songs für diesen Filter.
              </p>
            ) : (
              <>
                <div className="divide-y divide-border/60 rounded-2xl border border-border/60 bg-card">
                  {shown.map((s, i) => (
                    <div key={s.id} className="px-1.5">
                      <SongCard song={s} index={i + 1} />
                    </div>
                  ))}
                </div>

                {remaining > 0 && (
                  <div className="flex justify-center">
                    <button
                      onClick={() => setVisible((v) => v + PAGE_SIZE)}
                      className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-5 py-2 text-xs font-black text-foreground shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
                    >
                      Mehr laden
                      <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] tabular-nums text-muted-foreground">
                        +{Math.min(PAGE_SIZE, remaining)}
                      </span>
                    </button>
                  </div>
                )}
              </>
            )}
          </section>
        </div>

        {/* --- Sidebar --- */}
        <aside className="space-y-5">
          <MusicStats savedCount={0} accent={featured.accent} />

          <section className="rounded-2xl border border-border/60 bg-card p-4">
            <div className="mb-3">
              <div className="text-sm font-black">Künstler:innen</div>
              <Fa className="fa-hint-xs">هنرمندان محبوب</Fa>
            </div>
            <div className="space-y-1.5">
              {artists.map((a) => (
                <ArtistCard
                  key={a.id}
                  artist={a}
                  onSelect={(id) => {
                    setArtistId(id);
                    setPlaylistId(null);
                    setGenre("alle");
                  }}
                />
              ))}
            </div>
          </section>

          <section className="rounded-2xl border border-border/60 bg-card p-4">
            <div className="mb-3">
              <div className="text-sm font-black">Themen</div>
              <Fa className="fa-hint-xs">موضوع‌های پیشنهادی</Fa>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {recommendedTopicsMusic.map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-border bg-transparent px-2.5 py-1 text-[11px] font-bold text-muted-foreground"
                >
                  {t}
                </span>
              ))}
            </div>
          </section>

          <section
            className="relative overflow-hidden rounded-2xl p-4 text-white"
            style={{
              background: `linear-gradient(135deg, ${featured.accent}, color-mix(in oklab, ${featured.accent} 55%, #000))`,
            }}
          >
            <div className="text-sm font-black">Wortschatz aus Songs</div>
            <Fa className="fa-hint-xs !text-white/85">واژه‌های آهنگ‌ها</Fa>
            <p className="mt-2 text-xs text-white/85">
              Tippe im Songtext auf ein farbiges Wort und speichere es in deiner Leitner-Box.
            </p>
            <Link
              to="/leitner"
              className="mt-3 inline-block rounded-full bg-white/95 px-3 py-1.5 text-[12px] font-black text-slate-900"
            >
              Zur Leitner-Box →
            </Link>
          </section>
        </aside>
      </div>
    </div>
  );
}

function Header({ de, fa, count }: { de: string; fa: string; count?: number }) {
  return (
    <div className="flex items-end justify-between gap-3">
      <div>
        <h2 className="text-lg font-black sm:text-xl">{de}</h2>
        <Fa className="fa-hint-xs">{fa}</Fa>
      </div>
      {typeof count === "number" && (
        <span className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-black tabular-nums text-muted-foreground">
          {count}
        </span>
      )}
    </div>
  );
}
