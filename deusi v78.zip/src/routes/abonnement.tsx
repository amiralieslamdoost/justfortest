import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  Crown,
  Check,
  Sparkles,
  Zap,
  CreditCard,
  Download,
  Receipt,
  ArrowUpRight,
  Calendar,
  Shield,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";

export const Route = createFileRoute("/abonnement")({
  head: () => ({
    meta: [
      { title: "Abonnement · DEUSI" },
      { name: "description", content: "Verwalte deinen Plan, Rechnungen und Zahlungsmethode." },
    ],
  }),
  component: SubscriptionPage,
});

type BillingCycle = "monat" | "jahr";
type PlanKey = "free" | "plus" | "pro";

const PLANS: {
  key: PlanKey;
  name: string;
  fa: string;
  badge?: string;
  monthly: number;
  yearly: number;
  tagline: string;
  features: string[];
  highlight?: boolean;
}[] = [
  {
    key: "free",
    name: "Kostenlos",
    fa: "رایگان",
    monthly: 0,
    yearly: 0,
    tagline: "Zum Kennenlernen — ideal für den Einstieg.",
    features: [
      "Leitner-Box (bis 200 Karten)",
      "3 Lektionen pro Tag",
      "Grundwortschatz A1–A2",
      "Community-Events",
    ],
  },
  {
    key: "plus",
    name: "Plus",
    fa: "پلاس",
    badge: "Beliebt",
    highlight: true,
    monthly: 7.99,
    yearly: 79,
    tagline: "Für ernsthaftes Lernen — alle Werkzeuge, keine Grenzen.",
    features: [
      "Unbegrenzte Leitner-Karten",
      "Alle Podcasts & Musik-Transkripte",
      "KI-Coach (500 Nachrichten/Monat)",
      "Prüfungssimulator (Goethe A1–C2)",
      "Offline-Modus auf allen Geräten",
    ],
  },
  {
    key: "pro",
    name: "Pro",
    fa: "پرو",
    monthly: 14.99,
    yearly: 149,
    tagline: "Für Sprachprofis, Lehrer:innen und ambitionierte Lerner.",
    features: [
      "Alles aus Plus",
      "Unbegrenzter KI-Coach",
      "1-zu-1-Sprech-Feedback",
      "Frühzeitiger Zugriff auf neue Module",
      "Prioritäts-Support",
    ],
  },
];

const INVOICES = [
  { id: "INV-2026-07", date: "01. Jul. 2026", amount: "7,99 €", status: "Bezahlt" },
  { id: "INV-2026-06", date: "01. Jun. 2026", amount: "7,99 €", status: "Bezahlt" },
  { id: "INV-2026-05", date: "01. Mai 2026", amount: "7,99 €", status: "Bezahlt" },
  { id: "INV-2026-04", date: "01. Apr. 2026", amount: "7,99 €", status: "Bezahlt" },
];

function SubscriptionPage() {
  const [cycle, setCycle] = useState<BillingCycle>("jahr");
  const [current] = useState<PlanKey>("plus");

  return (
    <div className="space-y-6 pb-10 animate-fade">
      <MiniHero />

      {/* Current plan */}
      <section className="glass-strong overflow-hidden rounded-[28px]">
        <div className="grid gap-6 p-6 sm:p-7 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-foreground/5 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest">
              Aktueller Plan
            </div>
            <h2 className="mt-2 flex items-center gap-2 text-2xl font-black">
              <Crown className="h-6 w-6 text-amber-500" /> DEUSI Plus
            </h2>
            <FaHint>پلن فعلی: پلاس</FaHint>
            <p className="mt-2 text-sm text-muted-foreground">
              Nächste Abrechnung am <b className="text-foreground">01. Aug. 2026</b> · 79 € / Jahr
            </p>
            <div className="mt-3 flex flex-wrap gap-2 text-xs">
              <button className="inline-flex items-center gap-1.5 rounded-full bg-foreground px-3 py-1.5 font-bold text-background">
                <ArrowUpRight className="h-3.5 w-3.5" /> Auf Pro upgraden
              </button>
              <button className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background/50 px-3 py-1.5 font-semibold hover:border-foreground/30">
                Abo kündigen
              </button>
            </div>
          </div>
          <div className="w-full rounded-2xl border border-border bg-background/40 p-4 md:w-72">
            <div className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
              Verbrauch diesen Monat
            </div>
            <div className="mt-3 space-y-3 text-xs">
              <Meter label="KI-Coach Nachrichten" used={287} max={500} />
              <Meter label="Prüfungssimulationen" used={4} max={20} />
              <Meter label="Karten in Leitner" used={1240} max={999999} unbounded />
            </div>
          </div>
        </div>
      </section>

      {/* Plan picker */}
      <section>
        <div className="mb-4 flex items-end justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold">Pläne vergleichen</h2>
            <FaHint>مقایسه‌ی پلن‌ها</FaHint>
          </div>
          <div className="inline-flex items-center gap-1 rounded-full border border-border bg-background/60 p-1 text-xs font-semibold">
            <button
              onClick={() => setCycle("monat")}
              className={`rounded-full px-3 py-1.5 ${cycle === "monat" ? "bg-foreground text-background" : "text-foreground/70"}`}
            >
              Monatlich
            </button>
            <button
              onClick={() => setCycle("jahr")}
              className={`inline-flex items-center gap-1 rounded-full px-3 py-1.5 ${cycle === "jahr" ? "bg-foreground text-background" : "text-foreground/70"}`}
            >
              Jährlich{" "}
              <span
                className={`rounded-full px-1.5 text-[10px] ${cycle === "jahr" ? "bg-background/25" : "bg-emerald-500/15 text-emerald-600"}`}
              >
                −17%
              </span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {PLANS.map((p) => {
            const price = cycle === "monat" ? p.monthly : p.yearly;
            const suffix = p.monthly === 0 ? "" : cycle === "monat" ? "/ Monat" : "/ Jahr";
            const isCurrent = p.key === current;
            return (
              <motion.article
                key={p.key}
                whileHover={{ y: -3 }}
                className={`relative flex flex-col rounded-3xl border p-6 ${
                  p.highlight
                    ? "border-transparent bg-gradient-to-br from-[#150b26] to-[#54276b] text-white shadow-xl"
                    : "border-border bg-background/70"
                }`}
              >
                {p.badge && (
                  <span className="absolute -top-3 right-6 rounded-full bg-amber-400 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-amber-950 shadow-lg">
                    {p.badge}
                  </span>
                )}
                <div className="flex items-center gap-2">
                  {p.key === "free" && <Sparkles className="h-5 w-5" />}
                  {p.key === "plus" && <Crown className="h-5 w-5 text-amber-400" />}
                  {p.key === "pro" && <Zap className="h-5 w-5" />}
                  <h3 className="text-lg font-black">{p.name}</h3>
                </div>
                <FaHint className={p.highlight ? "!text-white/70" : ""}>{p.fa}</FaHint>
                <p
                  className={`mt-2 text-sm ${p.highlight ? "text-white/80" : "text-muted-foreground"}`}
                >
                  {p.tagline}
                </p>

                <div className="mt-5 flex items-baseline gap-1">
                  <span className="text-4xl font-black">{price === 0 ? "0" : `${price}`}</span>
                  <span
                    className={`text-sm ${p.highlight ? "text-white/70" : "text-muted-foreground"}`}
                  >
                    {price === 0 ? "€" : `€ ${suffix}`}
                  </span>
                </div>

                <ul className="mt-5 space-y-2 text-sm">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check
                        className={`mt-0.5 h-4 w-4 shrink-0 ${p.highlight ? "text-emerald-300" : "text-emerald-600"}`}
                      />
                      <span className={p.highlight ? "text-white/90" : "text-foreground/80"}>
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>

                <button
                  disabled={isCurrent}
                  className={`mt-6 inline-flex items-center justify-center gap-1.5 rounded-2xl px-4 py-2.5 text-sm font-bold transition disabled:cursor-default disabled:opacity-70 ${
                    p.highlight
                      ? "bg-white text-foreground hover:bg-white/90"
                      : "bg-foreground text-background hover:opacity-90"
                  }`}
                >
                  {isCurrent ? "Aktueller Plan" : p.monthly === 0 ? "Downgraden" : "Auswählen"}
                </button>
              </motion.article>
            );
          })}
        </div>
      </section>

      {/* Payment + invoices */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
        <section className="glass-strong rounded-[28px] p-5 sm:p-6">
          <header className="mb-4 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            <div>
              <h2 className="text-sm font-bold">Zahlungsmethode</h2>
              <FaHint>روش پرداخت</FaHint>
            </div>
          </header>
          <div className="rounded-2xl border border-border bg-gradient-to-br from-[#1a1a1a] to-[#2a2a2a] p-5 text-white shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-widest text-white/60">
                Visa
              </span>
              <Shield className="h-4 w-4 text-white/50" />
            </div>
            <div className="mt-6 font-mono text-lg tracking-widest">•••• •••• •••• 4242</div>
            <div className="mt-3 flex items-center justify-between text-xs text-white/70">
              <span>Max Mustermann</span>
              <span>08 / 28</span>
            </div>
          </div>
          <button className="mt-4 w-full rounded-xl border border-border bg-background/50 py-2 text-sm font-semibold hover:border-foreground/30">
            Zahlungsmethode ändern
          </button>
        </section>

        <section className="glass-strong rounded-[28px] p-5 sm:p-6">
          <header className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Receipt className="h-5 w-5" />
              <div>
                <h2 className="text-sm font-bold">Rechnungen</h2>
                <FaHint>فاکتورها</FaHint>
              </div>
            </div>
          </header>
          <div className="divide-y divide-border">
            {INVOICES.map((inv) => (
              <div key={inv.id} className="flex items-center gap-3 py-3">
                <span className="grid h-9 w-9 place-items-center rounded-lg bg-foreground/5">
                  <Calendar className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold">{inv.id}</div>
                  <div className="text-xs text-muted-foreground">{inv.date}</div>
                </div>
                <span className="text-sm font-bold">{inv.amount}</span>
                <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                  {inv.status}
                </span>
                <button
                  className="grid h-8 w-8 place-items-center rounded-lg text-foreground/60 hover:bg-foreground/5 hover:text-foreground"
                  title="PDF"
                >
                  <Download className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

function Meter({
  label,
  used,
  max,
  unbounded,
}: {
  label: string;
  used: number;
  max: number;
  unbounded?: boolean;
}) {
  const pct = unbounded ? 60 : Math.min(100, (used / max) * 100);
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between">
        <span className="text-foreground/70">{label}</span>
        <span className="font-semibold">
          {used.toLocaleString("de-DE")}
          {!unbounded && ` / ${max.toLocaleString("de-DE")}`}
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-foreground/10">
        <div className="h-full rounded-full bg-foreground" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function MiniHero() {
  return (
    <header
      className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
      style={{ backgroundImage: `linear-gradient(135deg, #3a2500 0%, #c48412 55%, #ffcf4a 130%)` }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div
          className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
          style={{ backgroundColor: "#ffcf4a", opacity: 0.4 }}
        />
      </div>
      <div className="relative flex min-w-0 items-center gap-3 sm:gap-4">
        <div
          className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16"
          style={{ color: "#c48412" }}
        >
          <Crown className="h-8 w-8" />
        </div>
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
            Abonnement
          </div>
          <h1 className="mt-2 text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
            Dein Plan, deine{" "}
            <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
              Kontrolle
            </span>
          </h1>
          <FaHint className="!text-white/85">پلن تو، اختیار با تو</FaHint>
          <p className="mt-2 max-w-2xl text-sm text-white/80">
            Verwalte Plan, Zahlungsmethode und Rechnungen.
          </p>
          <FaHint className="!text-white/70">مدیریت اشتراک، روش پرداخت و فاکتورها.</FaHint>
        </div>
      </div>
    </header>
  );
}
