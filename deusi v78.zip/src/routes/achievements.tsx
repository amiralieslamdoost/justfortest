import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  ArrowLeft,
  Trophy,
  Sparkles,
  Lock,
  Share2,
  Flame,
  Target,
  Zap,
  Copy,
  Check,
  X,
} from "lucide-react";
import {
  ACHIEVEMENTS,
  ACHIEVEMENT_CATEGORIES,
  latestUnlocked,
  progressPct,
  totalCount,
  unlockedCount,
  type Achievement,
  type AchievementCategory,
} from "@/lib/deusi/achievements";
import {
  LEVEL,
  LEVEL_PCT,
  LEVEL_TITLE,
  LEVEL_XP_IN,
  LEVEL_XP_NEED,
  NEXT_LEVEL_TITLE,
  TOTAL_XP,
  RARITY_META,
  rarityOf,
  ownersPctOf,
  myRank,
  DAILY_DONE,
  DAILY_XP_OPEN,
} from "@/lib/deusi/gamification";
import { Leaderboard } from "@/components/deusi/achievements/Leaderboard";
import { StreakWeekCard } from "@/components/deusi/achievements/StreakWeekCard";
import { RarityBar } from "@/components/deusi/achievements/RarityBar";
import { Fa } from "@/components/deusi/Fa";

export const Route = createFileRoute("/achievements")({
  head: () => ({
    meta: [
      { title: "Deine Erfolge — DEUSI" },
      {
        name: "description",
        content:
          "Alle DEUSI-Erfolge auf einen Blick: Serien, Wortschatz, Grammatik, Hören, Lesen und Prüfungen.",
      },
      { property: "og:title", content: "Deine Erfolge — DEUSI" },
      {
        property: "og:description",
        content: "Sammle Abzeichen für jede Etappe deiner Deutschreise mit DEUSI.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AchievementsPage,
});

type Filter = "Alle" | "Freigeschaltet" | "Gesperrt" | AchievementCategory;

const FILTERS: Filter[] = ["Alle", "Freigeschaltet", "Gesperrt", ...ACHIEVEMENT_CATEGORIES];

function AchievementsPage() {
  const [filter, setFilter] = useState<Filter>("Alle");
  const [shareTarget, setShareTarget] = useState<Achievement | "all" | null>(null);

  const visible = useMemo(() => {
    if (filter === "Alle") return ACHIEVEMENTS;
    if (filter === "Freigeschaltet") return ACHIEVEMENTS.filter((a) => a.unlocked);
    if (filter === "Gesperrt") return ACHIEVEMENTS.filter((a) => !a.unlocked);
    return ACHIEVEMENTS.filter((a) => a.category === filter);
  }, [filter]);

  // Next achievement to unlock — the one closest to completion.
  const nextUp = useMemo<Achievement | undefined>(() => {
    const locked = ACHIEVEMENTS.filter((a) => !a.unlocked && a.progress);
    if (!locked.length) return undefined;
    return [...locked].sort((a, b) => {
      const pa = a.progress!.current / a.progress!.target;
      const pb = b.progress!.current / b.progress!.target;
      return pb - pa;
    })[0];
  }, []);

  const nextLevelIn = Math.max(1, 3 - (unlockedCount % 3));
  const rank = myRank("Woche");

  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 pb-16 sm:space-y-8">
      {/* Back link */}
      <Link
        to="/dashboard"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground transition hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
        <span>Dashboard</span>
      </Link>

      {/* Hero */}
      <header
        className="relative overflow-hidden rounded-[1.75rem] p-5 text-white shadow-2xl sm:rounded-[2rem] sm:p-8"
        style={{
          backgroundImage:
            "radial-gradient(120% 120% at 85% -10%, #FDE68A 0%, transparent 45%), radial-gradient(100% 100% at 0% 110%, #DB2777 0%, transparent 50%), linear-gradient(135deg, #7C2D12 0%, #EA580C 45%, #F59E0B 100%)",
        }}
      >
        {/* Ambient shapes */}
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/15 blur-3xl" />
          <div className="absolute -bottom-24 -left-10 h-56 w-56 rounded-full bg-yellow-200/30 blur-3xl" />
          <motion.div
            className="absolute -inset-x-1/2 -top-1/2 h-[200%] w-[60%] rotate-12 bg-gradient-to-r from-transparent via-white/12 to-transparent"
            animate={{ x: ["-20%", "220%"] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", repeatDelay: 2 }}
          />
          {/* Floating frosted dots (decorative) */}
          <FloatingDot size={7} className="left-[6%] top-[16%]" delay={0} opacity={0.55} />
          <FloatingDot size={7} className="left-[18%] top-[62%]" delay={0.4} opacity={0.45} />
          <FloatingDot size={7} className="left-[31%] top-[28%]" delay={0.8} opacity={0.5} />
          <FloatingDot size={7} className="left-[46%] top-[9%]" delay={1.2} opacity={0.45} />
          <FloatingDot size={7} className="left-[55%] top-[72%]" delay={1.6} opacity={0.5} />
          <FloatingDot size={7} className="right-[30%] bottom-[18%]" delay={2} opacity={0.5} />
          <FloatingDot size={7} className="right-[18%] top-[36%]" delay={2.4} opacity={0.45} />
          <FloatingDot size={7} className="right-[8%] top-[62%]" delay={2.8} opacity={0.5} />
          <FloatingDot size={7} className="left-[68%] bottom-[30%]" delay={3.2} opacity={0.45} />
          <FloatingDot size={7} className="left-[12%] bottom-[14%]" delay={3.6} opacity={0.5} />
        </div>

        <div className="relative grid gap-5 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center lg:gap-8">
          <div className="min-w-0">
            <div className="flex min-w-0 items-start gap-3 sm:gap-4">
              <XpRing pct={LEVEL_PCT} level={LEVEL} />
              <div className="min-w-0 flex-1 lg:max-w-xl">
                <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.14em] backdrop-blur sm:text-[10px]">
                  <Sparkles className="h-3 w-3 shrink-0" aria-hidden />
                  Level {LEVEL} · {LEVEL_TITLE.de}
                </div>
                <h1 className="mt-2 text-[1.6rem] font-black leading-[1.05] sm:text-4xl">
                  Deine{" "}
                  <span className="bg-gradient-to-r from-white via-yellow-100 to-amber-200 bg-clip-text text-transparent">
                    Ruhmeshalle
                  </span>
                </h1>
                <Fa className="fa-hint-xs !text-white/85">تالار افتخارات تو</Fa>
                <p className="mt-2 max-w-lg text-[13px] leading-relaxed text-white/85 sm:text-sm">
                  Noch <b className="text-white tabular-nums">{LEVEL_XP_NEED - LEVEL_XP_IN} XP</b>{" "}
                  bis Level {LEVEL + 1} — «{NEXT_LEVEL_TITLE.de}». Du bist Platz{" "}
                  <b className="text-white">#{rank}</b> diese Woche! <span aria-hidden>🔥</span>
                </p>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-1.5 sm:gap-2">
              <HeroChip>⚡ {TOTAL_XP.toLocaleString("de-DE")} XP gesamt</HeroChip>
              <HeroChip>🎯 {DAILY_DONE}/3 Tagesmissionen</HeroChip>
              <HeroChip>🎁 +{DAILY_XP_OPEN} XP heute</HeroChip>
            </div>
          </div>

          <div className="grid w-full grid-cols-3 gap-2 lg:w-auto lg:min-w-[300px]">
            <HeroKpi value={unlockedCount} label="frei" icon="🏅" />
            <HeroKpi value={totalCount} label="gesamt" icon="🎯" />
            <HeroKpi value={`${progressPct}%`} label="Fortschritt" icon="⚡" />
          </div>
        </div>

        {/* Wide progress bar */}
        <div className="relative mt-6">
          <div className="h-3 w-full overflow-hidden rounded-full bg-black/25 ring-1 ring-white/25 sm:h-3.5">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPct}%` }}
              transition={{ duration: 1.1, ease: "easeOut" }}
              className="relative h-full rounded-full bg-gradient-to-r from-white via-yellow-100 to-amber-300 shadow-[0_0_22px_rgba(255,255,255,0.65)]"
            >
              <motion.span
                className="absolute right-0 top-1/2 hidden -translate-y-1/2 translate-x-1/2 text-lg sm:block"
                aria-hidden
                animate={{ y: [-1, -5, -1] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
              >
                🚀
              </motion.span>
            </motion.div>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-semibold text-white/85">
            <span>
              {unlockedCount} / {totalCount} Abzeichen
            </span>
            <span className="tabular-nums">{progressPct}%</span>
          </div>
        </div>

        {/* Share hero */}
        <div className="relative mt-5 flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShareTarget("all")}
            className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-sm font-black text-orange-600 shadow-lg ring-1 ring-white/60 transition hover:-translate-y-0.5 hover:shadow-xl active:translate-y-0"
          >
            <Share2 className="h-4 w-4" aria-hidden />
            Fortschritt teilen
          </button>
          <span className="text-[11px] font-semibold text-white/75">
            Zeig deinen Freunden, wie weit du bist!
          </span>
        </div>
      </header>

      {/* Fun bar: next up + streak + reward */}
      <div className="grid gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-3">
        {nextUp && <NextUpCard achievement={nextUp} />}
        <FunTile
          icon={<Flame className="h-5 w-5" />}
          gradient="linear-gradient(135deg, #F97316, #EF4444)"
          title="14-Tage-Serie"
          fa="سری ۱۴ روزه"
          hint="Bleib dran — jeder Tag zählt!"
          highlight="🔥 aktiv"
        />
        <FunTile
          icon={<Zap className="h-5 w-5" />}
          gradient="linear-gradient(135deg, #8B5CF6, #EC4899)"
          title="Nächste Belohnung"
          fa="جایزه بعدی"
          hint="Level up und schalte einen neuen Titel frei."
          highlight={`+${nextLevelIn * 50} XP`}
        />
      </div>

      {/* Weekly streak + rarity side by side */}
      <div className="grid gap-3 sm:gap-4 lg:grid-cols-2">
        <StreakWeekCard />
        <RarityBar />
      </div>

      {/* Latest unlocked highlight */}
      {latestUnlocked && (
        <LatestUnlockedCard
          achievement={latestUnlocked}
          onShare={() => setShareTarget(latestUnlocked ?? null)}
        />
      )}

      {/* Collection header + filters */}
      <div className="flex flex-wrap items-end justify-between gap-2 pt-1">
        <div>
          <h2 className="text-lg font-black leading-tight sm:text-xl">Deine Sammlung</h2>
          <Fa className="fa-hint-xs">مجموعه نشان‌های تو</Fa>
        </div>
        <span className="rounded-full bg-secondary px-3 py-1 text-[11px] font-bold tabular-nums text-muted-foreground ring-1 ring-border">
          {visible.length} / {totalCount}
        </span>
      </div>
      <div className="-mx-1 -mt-3 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:flex-wrap sm:overflow-visible">
        {FILTERS.map((f) => {
          const active = f === filter;
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition ring-1 ${
                active
                  ? "bg-foreground text-background ring-foreground shadow-md"
                  : "bg-card text-muted-foreground ring-border hover:text-foreground hover:ring-foreground/40"
              }`}
            >
              {f}
            </button>
          );
        })}
      </div>

      {/* Grid */}
      {visible.length === 0 ? (
        <div className="neu-card p-10 text-center text-sm text-muted-foreground">
          Keine Erfolge in dieser Kategorie.
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
          {visible.map((a, i) => (
            <AchievementCard
              key={a.id}
              achievement={a}
              index={i}
              onShare={() => setShareTarget(a)}
            />
          ))}
        </div>
      )}

      {/* Leaderboard — نفرات برتر */}
      <Leaderboard />

      {shareTarget && <ShareModal target={shareTarget} onClose={() => setShareTarget(null)} />}
    </div>
  );
}

/** Soft, blurred white orbs drifting inside the hero — replaces the old emojis. */
function FloatingDot({
  size = 28,
  className = "",
  delay = 0,
  opacity = 0.5,
}: {
  size?: number;
  className?: string;
  delay?: number;
  opacity?: number;
}) {
  return (
    <motion.span
      aria-hidden
      className={`absolute rounded-full ${className}`}
      style={{
        width: size,
        height: size,
        background: "rgba(255,255,255,0.9)",
        boxShadow: "0 0 10px 2px rgba(255,255,255,0.45)",
        filter: "blur(1px)",
        opacity,
      }}

      initial={{ y: 0 }}
      animate={{ y: [-10, 10, -10], opacity: [opacity * 0.6, opacity, opacity * 0.6] }}
      transition={{ duration: 7, repeat: Infinity, delay, ease: "easeInOut" }}
    />
  );
}

function HeroChip({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold ring-1 ring-white/20 backdrop-blur sm:text-[11px]">
      {children}
    </span>
  );
}

function XpRing({ pct, level }: { pct: number; level: number }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <motion.div
      initial={{ scale: 0.6, rotate: -18, opacity: 0 }}
      animate={{ scale: 1, rotate: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 180, damping: 13 }}
      className="relative h-[68px] w-[68px] shrink-0 sm:h-20 sm:w-20"
    >
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="rgba(0,0,0,0.22)" strokeWidth="6" />
        <motion.circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          stroke="url(#xpgrad)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - (c * Math.min(100, pct)) / 100 }}
          transition={{ duration: 1.1, ease: "easeOut" }}
        />
        <defs>
          <linearGradient id="xpgrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#FDE68A" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-[9px] grid place-items-center rounded-full bg-white/95 shadow-inner">
        <Trophy className="h-6 w-6 sm:h-7 sm:w-7" style={{ color: "#EA580C" }} aria-hidden />
      </div>
      <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full bg-foreground px-1.5 py-px text-[9px] font-black text-background shadow">
        LV {level}
      </span>
    </motion.div>
  );
}

function HeroKpi({ value, label, icon }: { value: string | number; label: string; icon?: string }) {
  return (
    <div className="rounded-2xl bg-white/12 p-2.5 text-center shadow-[inset_0_1px_0_rgba(255,255,255,0.35)] ring-1 ring-white/25 backdrop-blur sm:p-3">
      {icon && (
        <div className="text-base leading-none sm:text-lg" aria-hidden>
          {icon}
        </div>
      )}
      <div className="mt-0.5 text-lg font-black tabular-nums sm:text-2xl">{value}</div>
      <div className="mt-0.5 truncate text-[9px] font-semibold uppercase tracking-wider text-white/85 sm:text-[10px]">
        {label}
      </div>
    </div>
  );
}

function NextUpCard({ achievement }: { achievement: Achievement }) {
  const pct = achievement.progress
    ? Math.min(100, Math.round((achievement.progress.current / achievement.progress.target) * 100))
    : 0;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-2xl p-5 shadow-lg ring-1 ring-border md:col-span-1"
      style={{
        backgroundImage:
          "linear-gradient(135deg, color-mix(in oklab, var(--card) 96%, transparent), var(--card))",
      }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-40 blur-3xl"
        style={{ background: `radial-gradient(circle, ${achievement.color}, transparent 70%)` }}
      />
      <div className="relative flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
        <Target className="h-3.5 w-3.5" aria-hidden />
        Fast geschafft
        <Fa className="fa-hint-xs" inline>
          نزدیک به موفقیت
        </Fa>
      </div>
      <div className="relative mt-3 flex items-center gap-3">
        <div
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-2xl ring-1 ring-border"
          style={{
            backgroundImage: `linear-gradient(135deg, ${achievement.color}, color-mix(in oklab, ${achievement.color} 60%, #fff))`,
            color: "#fff",
          }}
        >
          <span aria-hidden>{achievement.emoji}</span>
        </div>
        <div className="min-w-0">
          <div className="truncate text-sm font-black leading-tight">{achievement.labelDe}</div>
          <Fa className="fa-hint-xs">{achievement.labelFa}</Fa>
        </div>
      </div>
      <div className="relative mt-3">
        <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.7 }}
            className="h-full rounded-full"
            style={{
              background: `linear-gradient(90deg, ${achievement.color}, color-mix(in oklab, ${achievement.color} 60%, #fff))`,
            }}
          />
        </div>
        <div className="mt-1 flex items-center justify-between text-[11px] font-bold tabular-nums text-muted-foreground">
          <span>
            {achievement.progress?.current} / {achievement.progress?.target}
          </span>
          <span>{pct}%</span>
        </div>
      </div>
    </motion.div>
  );
}

function FunTile({
  icon,
  gradient,
  title,
  fa,
  hint,
  highlight,
}: {
  icon: React.ReactNode;
  gradient: string;
  title: string;
  fa: string;
  hint: string;
  highlight: string;
}) {
  return (
    <div
      className="relative overflow-hidden rounded-2xl p-5 text-white shadow-lg ring-1 ring-white/20"
      style={{ backgroundImage: gradient }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-white/20 blur-2xl"
      />
      <div className="relative flex items-center justify-between">
        <div className="grid h-9 w-9 place-items-center rounded-xl bg-white/20 backdrop-blur">
          {icon}
        </div>
        <span className="rounded-full bg-white/25 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest backdrop-blur">
          {highlight}
        </span>
      </div>
      <div className="relative mt-3 text-base font-black leading-tight">{title}</div>
      <Fa className="fa-hint-xs !text-white/85">{fa}</Fa>
      <p className="mt-1 text-xs text-white/85">{hint}</p>
    </div>
  );
}

function LatestUnlockedCard({
  achievement,
  onShare,
}: {
  achievement: Achievement;
  onShare: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="neu-card relative overflow-hidden p-5 sm:p-6"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full opacity-40 blur-3xl"
        style={{ background: `radial-gradient(circle, ${achievement.color}, transparent 70%)` }}
      />
      <div className="relative grid gap-4 sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center">
        <motion.div
          initial={{ scale: 0.6, rotate: -12 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 180 }}
          className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-3xl shadow-lg ring-1 ring-white/40"
          style={{
            backgroundImage: `linear-gradient(135deg, ${achievement.color}, color-mix(in oklab, ${achievement.color} 70%, #000))`,
            color: "#fff",
          }}
        >
          <span aria-hidden>{achievement.emoji}</span>
        </motion.div>
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
            <Sparkles className="h-3 w-3" aria-hidden />
            zuletzt freigeschaltet
          </div>
          <h2 className="mt-1.5 text-lg font-black leading-tight sm:text-xl">
            {achievement.labelDe}
          </h2>
          <Fa className="fa-hint-xs">{achievement.labelFa}</Fa>
          <p className="mt-1 text-xs text-muted-foreground">
            {achievement.sub}
            {achievement.unlockedAt && ` · ${formatDate(achievement.unlockedAt)}`}
          </p>
        </div>
        <button
          onClick={onShare}
          className="inline-flex items-center gap-1.5 rounded-full bg-foreground px-3.5 py-2 text-xs font-black text-background shadow-sm transition hover:opacity-90"
        >
          <Share2 className="h-3.5 w-3.5" aria-hidden />
          Teilen
        </button>
      </div>
    </motion.div>
  );
}

function AchievementCard({
  achievement,
  index,
  onShare,
}: {
  achievement: Achievement;
  index: number;
  onShare: () => void;
}) {
  const a = achievement;
  const pct = a.progress
    ? Math.min(100, Math.round((a.progress.current / a.progress.target) * 100))
    : a.unlocked
      ? 100
      : 0;
  const remaining = a.progress ? Math.max(0, a.progress.target - a.progress.current) : 0;
  const rarity = RARITY_META[rarityOf(a.id)];

  // Medal ring geometry
  const R = 30;
  const C = 2 * Math.PI * R;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.035 * index, duration: 0.35 }}
      whileHover={{ y: -6 }}
      className="group relative flex flex-col items-center overflow-hidden rounded-[1.5rem] p-4 text-center ring-1 transition-shadow duration-300"
      style={{
        backgroundImage: a.unlocked
          ? `radial-gradient(120% 90% at 50% -10%, color-mix(in oklab, ${a.color} 55%, transparent) 0%, transparent 62%), linear-gradient(160deg, #12131A 0%, #1B1D28 60%, #0C0D12 100%)`
          : `radial-gradient(120% 90% at 50% -20%, color-mix(in oklab, ${rarity.color} 16%, transparent) 0%, transparent 60%), linear-gradient(160deg, color-mix(in oklab, var(--secondary) 92%, transparent), var(--secondary))`,
        boxShadow: a.unlocked
          ? `0 18px 40px -22px color-mix(in oklab, ${a.color} 85%, transparent), inset 0 1px 0 rgba(255,255,255,.14)`
          : "inset 0 1px 0 rgba(255,255,255,.05)",
        ...({
          "--tw-ring-color": a.unlocked
            ? `color-mix(in oklab, ${a.color} 45%, transparent)`
            : "color-mix(in oklab, var(--border) 90%, transparent)",
        } as React.CSSProperties),
      }}
    >
      {/* Sheen sweep on hover */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-1/2 top-0 h-full w-1/2 -skew-x-12 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 transition-all duration-700 group-hover:left-[130%] group-hover:opacity-100" />
      </div>

      {/* Rarity ribbon */}
      <span
        className="absolute left-3 top-3 rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-[0.14em]"
        style={{
          background: a.unlocked
            ? "rgba(255,255,255,.16)"
            : `color-mix(in oklab, ${rarity.color} 18%, transparent)`,
          color: a.unlocked ? "#fff" : rarity.color,
        }}
      >
        {rarity.de}
      </span>
      <span
        className={`absolute right-3 top-3 inline-flex items-center gap-1 text-[9px] font-black tabular-nums ${
          a.unlocked ? "text-white/80" : "text-muted-foreground"
        }`}
      >
        {a.unlocked ? (
          <Sparkles className="h-3 w-3" aria-hidden />
        ) : (
          <Lock className="h-3 w-3" aria-hidden />
        )}
        +{rarity.xp} XP
      </span>

      {/* Medallion */}
      <div className="relative mt-7 grid h-[98px] w-[98px] place-items-center">
        <svg
          viewBox="-11 -11 98 98"
          className="absolute inset-0 h-full w-full -rotate-90 overflow-visible"
        >
          <circle
            cx="38"
            cy="38"
            r={R}
            fill="none"
            strokeWidth="5"
            stroke={
              a.unlocked
                ? "rgba(255,255,255,.14)"
                : "color-mix(in oklab, var(--border) 90%, transparent)"
            }
          />
          <motion.circle
            cx="38"
            cy="38"
            r={R}
            fill="none"
            strokeWidth="5"
            strokeLinecap="round"
            stroke={a.color}
            strokeDasharray={C}
            initial={{ strokeDashoffset: C }}
            animate={{ strokeDashoffset: C - (C * pct) / 100 }}
            transition={{ duration: 0.9, delay: 0.05 * index, ease: "easeOut" }}
            style={{
              filter: a.unlocked ? `drop-shadow(0 0 6px ${a.color})` : undefined,
            }}
          />
        </svg>
        <motion.div
          whileHover={{ rotate: [-8, 8, 0], scale: 1.06 }}
          transition={{ duration: 0.5 }}
          className="grid h-14 w-14 place-items-center rounded-full text-2xl ring-1"
          style={{
            background: a.unlocked
              ? `linear-gradient(150deg, color-mix(in oklab, ${a.color} 92%, #fff) 0%, color-mix(in oklab, ${a.color} 55%, #000) 100%)`
              : "color-mix(in oklab, var(--background) 88%, transparent)",
            boxShadow: a.unlocked
              ? `0 8px 22px -8px ${a.color}, inset 0 2px 6px rgba(255,255,255,.35)`
              : "inset 0 2px 6px rgba(0,0,0,.12)",
            ["--tw-ring-color" as never]: a.unlocked
              ? "rgba(255,255,255,.45)"
              : "color-mix(in oklab, var(--border) 90%, transparent)",
          }}
        >
          <span
            aria-hidden
            className={a.unlocked ? "" : "opacity-45 grayscale"}
            style={a.unlocked ? { filter: "drop-shadow(0 1px 2px rgba(0,0,0,.35))" } : undefined}
          >
            {a.emoji}
          </span>
        </motion.div>
        {!a.unlocked && (
          <span className="absolute -bottom-1 rounded-full bg-background px-1.5 py-0.5 text-[9px] font-black tabular-nums text-muted-foreground ring-1 ring-border">
            {pct}%
          </span>
        )}
      </div>

      {/* Text */}
      <div className="relative mt-3 w-full min-w-0 flex-1">
        <div
          className={`line-clamp-2 text-[13px] font-black leading-tight sm:text-sm ${
            a.unlocked ? "text-white" : "text-foreground"
          }`}
        >
          {a.labelDe}
        </div>
        <Fa className={`fa-hint-xs !text-[10px] ${a.unlocked ? "!text-white/75" : ""}`}>
          {a.labelFa}
        </Fa>

        {a.unlocked ? (
          <div className="mt-2 inline-flex max-w-full items-center gap-1 truncate rounded-full bg-white/12 px-2.5 py-1 text-[10px] font-bold text-white/85 ring-1 ring-white/15">
            ✓ {a.unlockedAt ? formatDate(a.unlockedAt) : "freigeschaltet"} · nur {ownersPctOf(a.id)}
            %
          </div>
        ) : a.progress ? (
          <div className="mt-2 rounded-xl bg-background/60 px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground ring-1 ring-border/60">
            noch{" "}
            <span className="tabular-nums" style={{ color: a.color }}>
              {remaining}
            </span>{" "}
            bis zum Abzeichen
          </div>
        ) : (
          <div className="mt-2 text-[10px] font-semibold text-muted-foreground">{a.sub}</div>
        )}
      </div>

      {a.unlocked && (
        <button
          onClick={onShare}
          aria-label={`${a.labelDe} teilen`}
          className="relative mt-3 inline-flex items-center gap-1 rounded-full bg-white/20 px-3 py-1 text-[10px] font-black text-white backdrop-blur transition hover:bg-white/35"
        >
          <Share2 className="h-3 w-3" aria-hidden />
          Teilen
        </button>
      )}
    </motion.div>
  );
}

function ShareModal({ target, onClose }: { target: Achievement | "all"; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const url =
    typeof window !== "undefined" ? window.location.href : "https://deusi.app/achievements";

  const text =
    target === "all"
      ? `Ich habe ${unlockedCount} von ${totalCount} DEUSI-Abzeichen (${progressPct}%) freigeschaltet! 🎉 Lern mit mir Deutsch:`
      : `Neues Abzeichen freigeschaltet: ${target.emoji} ${target.labelDe} bei DEUSI! 🎉 Lern mit mir Deutsch:`;

  const encoded = encodeURIComponent(`${text} ${url}`);
  const links = [
    {
      name: "WhatsApp",
      color: "#25D366",
      href: `https://wa.me/?text=${encoded}`,
      emoji: "💬",
    },
    {
      name: "Telegram",
      color: "#0088CC",
      href: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`,
      emoji: "✈️",
    },
    {
      name: "X / Twitter",
      color: "#000000",
      href: `https://twitter.com/intent/tweet?text=${encoded}`,
      emoji: "𝕏",
    },
    {
      name: "Facebook",
      color: "#1877F2",
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
      emoji: "📘",
    },
  ];

  async function handleNative() {
    if (
      typeof navigator !== "undefined" &&
      (navigator as Navigator & { share?: (d: ShareData) => Promise<void> }).share
    ) {
      try {
        await (navigator as Navigator & { share: (d: ShareData) => Promise<void> }).share({
          title: "DEUSI",
          text,
          url,
        });
      } catch {
        /* user cancelled */
      }
    }
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(`${text} ${url}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* noop */
    }
  }

  const heroColor = target === "all" ? "#F97316" : target.color;
  const heroEmoji = target === "all" ? "🏆" : target.emoji;
  const heroTitle = target === "all" ? "Mein Fortschritt" : target.labelDe;
  const heroFa = target === "all" ? "پیشرفت من" : target.labelFa;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md overflow-hidden rounded-3xl bg-card shadow-2xl ring-1 ring-border"
      >
        {/* Header preview card */}
        <div
          className="relative overflow-hidden p-6 text-white"
          style={{
            backgroundImage: `linear-gradient(135deg, ${heroColor}, color-mix(in oklab, ${heroColor} 60%, #000))`,
          }}
        >
          <button
            onClick={onClose}
            aria-label="Schließen"
            className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-white/20 text-white backdrop-blur transition hover:bg-white/30"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
          <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
            <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/25 blur-3xl" />
            <div className="absolute -bottom-10 -left-8 h-32 w-32 rounded-full bg-white/10 blur-3xl" />
          </div>
          <div className="relative flex items-center gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-white/95 text-4xl shadow ring-1 ring-white/40">
              <span aria-hidden>{heroEmoji}</span>
            </div>
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-widest text-white/85">
                DEUSI · Erfolg
              </div>
              <div className="text-xl font-black leading-tight">{heroTitle}</div>
              <div className="text-xs text-white/85">{heroFa}</div>
              {target === "all" && (
                <div className="mt-1 text-[11px] font-black">
                  {unlockedCount} / {totalCount} · {progressPct}%
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-4 p-6">
          <div>
            <div className="text-sm font-black">Mit Freunden teilen</div>
            <Fa className="fa-hint-xs">با دوستان به اشتراک بگذار</Fa>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {links.map((l) => (
              <a
                key={l.name}
                href={l.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col items-center gap-1 rounded-2xl bg-secondary p-3 text-center transition hover:-translate-y-0.5 hover:shadow-md"
              >
                <div
                  className="grid h-10 w-10 place-items-center rounded-full text-lg text-white shadow"
                  style={{ backgroundColor: l.color }}
                >
                  <span aria-hidden>{l.emoji}</span>
                </div>
                <div className="text-[10px] font-bold">{l.name}</div>
              </a>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex flex-1 items-center justify-center gap-2 rounded-full bg-foreground px-4 py-2.5 text-sm font-black text-background transition hover:opacity-90"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4" aria-hidden /> Kopiert
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" aria-hidden /> Link kopieren
                </>
              )}
            </button>
            <button
              onClick={handleNative}
              className="grid h-11 w-11 place-items-center rounded-full bg-secondary text-foreground transition hover:bg-secondary/70"
              aria-label="Mit Gerät teilen"
              title="Mit Gerät teilen"
            >
              <Share2 className="h-4 w-4" aria-hidden />
            </button>
          </div>

          <p className="text-[11px] text-muted-foreground">
            Motiviere deine Freunde mit — gemeinsam macht Lernen mehr Spaß!{" "}
            <span aria-hidden>🎉</span>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("de-DE", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  } catch {
    return iso;
  }
}
