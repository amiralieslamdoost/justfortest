import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { Modal } from "@/components/deusi/Modal";
import type { Word, VerbWord, NounWord, AdjectiveWord, PrepositionWord } from "@/lib/deusi/types";
import type { Rating } from "@/lib/deusi/fsrs";
import { LeitnerBoxBar } from "@/components/deusi/learn/LeitnerBoxBar";
import { FaHint } from "@/components/deusi/FaHint";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "Lernen — DEUSI" },
      {
        name: "description",
        content: "Vokabeln mit Karteikarten und Spaced Repetition effektiv lernen.",
      },
      { property: "og:title", content: "Lernen — DEUSI" },
      {
        property: "og:description",
        content: "Vokabeln mit Karteikarten und Spaced Repetition effektiv lernen.",
      },
    ],
  }),
  component: Learn,
});

/* -------------- helpers -------------- */

const POS_DE = {
  noun: "Substantiv",
  verb: "Verb",
  adjective: "Adjektiv",
  preposition: "Präposition",
} as const;

function primaryOf(w: Word) {
  if (w.pos === "noun") return w.singular;
  if (w.pos === "verb") return w.infinitive;
  if (w.pos === "adjective") return w.positive;
  return w.preposition;
}
function articleColor(a?: "der" | "die" | "das") {
  return a === "der" ? "var(--der)" : a === "die" ? "var(--die)" : "var(--das)";
}
function accentColor(w: Word) {
  if (w.pos === "noun") return articleColor(w.article);
  if (w.pos === "verb") return "#F97316";
  if (w.pos === "adjective") return "#F7C948";
  return prepAccent(w as PrepositionWord);
}

/** Different color/shape per preposition case pattern for visual memory */
function prepPattern(p: PrepositionWord): {
  color: string;
  tint: string;
  label: string;
  shape: "circle" | "square" | "diamond" | "hex";
} {
  const set = new Set(p.cases);
  const hasAkk = set.has("Akk");
  const hasDat = set.has("Dat");
  const hasGen = (set as Set<string>).has("Gen");
  if (hasAkk && hasDat)
    return {
      color: "#8B5CF6",
      tint: "#EDE9FE",
      label: "Wechselpräposition (Akk/Dat)",
      shape: "hex",
    };
  if (hasAkk) return { color: "#DD2222", tint: "#FEE9E7", label: "Akkusativ", shape: "circle" };
  if (hasDat) return { color: "#2563eb", tint: "#DBEAFE", label: "Dativ", shape: "square" };
  if (hasGen) return { color: "#059669", tint: "#D1FAE5", label: "Genitiv", shape: "diamond" };
  return { color: "#8B5CF6", tint: "#EDE9FE", label: p.cases.join("/"), shape: "hex" };
}
function prepAccent(p: PrepositionWord) {
  return prepPattern(p).color;
}

function CaseShape({
  shape,
  color,
  tint,
  size = 96,
}: {
  shape: "circle" | "square" | "diamond" | "hex";
  color: string;
  tint: string;
  size?: number;
}) {
  const common = { width: size, height: size } as const;
  if (shape === "circle")
    return (
      <div
        style={{
          ...common,
          background: tint,
          border: `3px solid ${color}`,
          borderRadius: "9999px",
        }}
      />
    );
  if (shape === "square")
    return (
      <div
        style={{ ...common, background: tint, border: `3px solid ${color}`, borderRadius: 12 }}
      />
    );
  if (shape === "diamond")
    return (
      <div
        style={{
          ...common,
          background: tint,
          border: `3px solid ${color}`,
          borderRadius: 8,
          transform: "rotate(45deg)",
        }}
      />
    );
  return (
    <div
      style={{
        ...common,
        background: tint,
        border: `3px solid ${color}`,
        clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
      }}
    />
  );
}
function speak(t: string) {
  try {
    const u = new SpeechSynthesisUtterance(t);
    u.lang = "de-DE";
    speechSynthesis.speak(u);
  } catch {
    /* noop */
  }
}
function discClass(w: Word) {
  if (w.pos === "noun") {
    return w.article === "der"
      ? "disc-noun-der"
      : w.article === "die"
        ? "disc-noun-die"
        : "disc-noun-das";
  }
  return `disc-${w.pos}`;
}

/* -------------- page -------------- */

function Learn() {
  const { currentUser, hydrated, dueCards, rate, ensureDeckFor } = useDeusi();
  const router = useRouter();
  const [conjOpen, setConjOpen] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [hoverRating, setHoverRating] = useState<Rating | null>(null);

  useEffect(() => {
    if (!hydrated) return;
    if (!currentUser) router.navigate({ to: "/login" });
    else ensureDeckFor(currentUser.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, currentUser?.id]);

  const queue = dueCards();
  const current = queue[0];
  const total = currentUser?.deck.length ?? 0;
  const done = total - queue.length;

  useEffect(() => {
    setRevealed(false);
    setHoverRating(null);
  }, [current?.word.id]);

  const onRate = (r: Rating) => {
    if (!current) return;
    if (!revealed) {
      setRevealed(true);
      return;
    }
    setRevealed(false);
    setTimeout(() => rate(current.word.id, r), 220);
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!current) return;
      if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        setRevealed((v) => !v);
        return;
      }
      if (e.key === "1") onRate("again");
      if (e.key === "2") onRate("hard");
      if (e.key === "3") onRate("good");
      if (e.key === "4") onRate("easy");
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.word.id, revealed]);

  if (!currentUser) return null;

  if (!current) {
    return (
      <div className="mx-auto mt-16 max-w-xl neu-card p-10 text-center animate-fade">
        <div className="mb-3 text-5xl">🎉</div>
        <h1 className="mb-2 text-2xl font-bold">Fantastisch — alles erledigt!</h1>
        <FaHint size="sm" className="!mb-2 block">
          عالی بود — کارِ امروز تمام شد!
        </FaHint>
        <p className="mb-6 text-muted-foreground">
          Alle heutigen Karten sind wiederholt. Komm morgen wieder oder füge neue Vokabeln hinzu.
        </p>
        <FaHint size="sm" className="!mb-4 block">
          همهٔ کارت‌های امروز مرور شدند. فردا برگرد یا واژهٔ جدید اضافه کن.
        </FaHint>
        <div className="flex justify-center gap-3">
          <Link
            to="/dashboard"
            className="rounded-xl border border-border bg-card px-5 py-2.5 font-semibold hover:bg-secondary"
          >
            Zum Dashboard
          </Link>
          <Link
            to="/dictionary"
            className="rounded-xl px-5 py-2.5 font-semibold text-white"
            style={{ background: "var(--flag-black)" }}
          >
            + Neue Vokabel
          </Link>
        </div>
      </div>
    );
  }

  const w = current.word;
  const pct = Math.round(((done + 1) / (total || 1)) * 100);
  const accent = accentColor(w);

  return (
    <div className="mx-auto flex min-h-[calc(100vh-2.5rem)] max-w-6xl flex-col gap-4 py-2 sm:gap-6 lg:gap-8">
      <h1 className="sr-only">Lernen — Karteikarten wiederholen</h1>
      {/* Header: Zurück links, Fortschritt Mitte */}
      <header className="flex items-center gap-3 sm:gap-4">
        <Link to="/dashboard" className="btn-back">
          <span aria-hidden>←</span>
          <span>Zurück</span>
        </Link>

        <div className="flex flex-1 items-center gap-3">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${pct}%`, background: accent }}
            />
          </div>
          <div className="text-xs font-semibold text-muted-foreground tabular-nums whitespace-nowrap">
            {done + 1} / {total}
          </div>
        </div>
      </header>

      {/* Live Leitner box overview */}
      <LeitnerBoxBar
        deck={currentUser.deck}
        current={current.card}
        previewRating={revealed ? hoverRating : null}
      />

      {/* Stage: on mobile pin to top so the card never shifts when content grows below.
          On desktop keep it visually centered. */}
      <div className="flex flex-1 flex-col items-center justify-start lg:justify-center">
        <div className="relative w-full">
          {/* Desktop (≥lg): 3 Spalten mit Verbindungslinien */}
          <div className="hidden lg:grid lg:grid-cols-[220px_minmax(0,1fr)_220px] lg:items-center lg:gap-x-14 xl:grid-cols-[240px_minmax(0,1fr)_240px] xl:gap-x-20">
            <SideColumn side="left" word={w} revealed={revealed} accent={accent} />
            <CenterStage
              word={w}
              revealed={revealed}
              onFlip={() => setRevealed((v) => !v)}
              onOpenConj={() => setConjOpen(true)}
            />
            <SideColumn side="right" word={w} revealed={revealed} accent={accent} />
          </div>

          {/* Mobile & Tablet: Karte → Aktionen → Nodes */}
          <div className="flex flex-col items-center gap-3 sm:gap-4 lg:hidden">
            <CenterStage
              word={w}
              revealed={revealed}
              onFlip={() => setRevealed((v) => !v)}
              onOpenConj={() => setConjOpen(true)}
            />

            {/* Aktionszone mit stabiler Höhe, damit die Karte beim Umdrehen nicht springt */}
            <div className="w-full min-h-[60px] sm:min-h-[64px]">
              {!revealed ? (
                <button
                  onClick={() => setRevealed(true)}
                  className="group relative mx-auto block w-full max-w-sm overflow-hidden rounded-2xl px-6 py-3.5 text-sm font-bold text-white shadow-lg transition-transform duration-200 active:scale-[0.98] sm:py-4 sm:text-base"
                  style={{
                    background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 70%, #000))`,
                    boxShadow: `0 14px 32px -12px ${accent}88`,
                  }}
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    <span>Antwort zeigen</span>
                    <span aria-hidden className="text-lg">
                      ↻
                    </span>
                  </span>
                </button>
              ) : (
                <div className="grid w-full grid-cols-4 gap-1.5 sm:gap-2">
                  <RateBtn
                    kind="again"
                    title="Nochmal"
                    onClick={() => onRate("again")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="hard"
                    title="Schwer"
                    onClick={() => onRate("hard")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="good"
                    title="Gut"
                    onClick={() => onRate("good")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="easy"
                    title="Einfach"
                    onClick={() => onRate("easy")}
                    onHover={setHoverRating}
                    compact
                  />
                </div>
              )}
            </div>

            {revealed && (
              <div className="grid w-full grid-cols-2 gap-2.5 sm:grid-cols-3">
                {[...attributesFor(w, "left"), ...attributesFor(w, "right")].map((n, i) => (
                  <NodeBox key={i} spec={n} delay={i * 70} accent={accent} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Reveal button or Rating pills — nur Desktop (≥lg) */}
      {!revealed ? (
        <div className="mx-auto hidden w-full max-w-2xl flex-col items-center gap-2 lg:flex">
          <button
            onClick={() => setRevealed(true)}
            className="group relative w-full max-w-sm overflow-hidden rounded-2xl px-6 py-4 text-base font-bold text-white shadow-lg transition hover:-translate-y-0.5 hover:shadow-xl active:scale-[0.98]"
            style={{
              background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 65%, #000))`,
              boxShadow: `0 18px 40px -12px ${accent}88`,
            }}
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              <span>Antwort zeigen</span>
              <span aria-hidden className="text-lg transition group-hover:translate-x-0.5">
                ↻
              </span>
            </span>
            <span
              aria-hidden
              className="absolute inset-0 bg-white/10 opacity-0 transition group-hover:opacity-100"
            />
          </button>
          <p className="text-center text-[11px] text-muted-foreground">
            Tippe die Karte oder <b>Leertaste</b> zum Umdrehen
          </p>
        </div>
      ) : (
        <div className="mx-auto hidden w-full max-w-2xl flex-col items-center gap-2 lg:flex">
          <div className="flex w-full flex-wrap items-center justify-center gap-3">
            <RateBtn
              kind="again"
              title="Nochmal"
              onClick={() => onRate("again")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="hard"
              title="Schwer"
              onClick={() => onRate("hard")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="good"
              title="Gut"
              onClick={() => onRate("good")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="easy"
              title="Einfach"
              onClick={() => onRate("easy")}
              onHover={setHoverRating}
            />
          </div>
          <p className="text-center text-xs text-muted-foreground">
            Bewerte, wie gut du dich erinnert hast · Tasten <b>1–4</b>
          </p>
        </div>
      )}

      {w.pos === "verb" && (
        <Modal
          open={conjOpen}
          onClose={() => setConjOpen(false)}
          title={`Konjugation · ${(w as VerbWord).infinitive}`}
          wide
        >
          <ConjTable v={w as VerbWord} />
        </Modal>
      )}
    </div>
  );
}

/* -------------- Rating pill -------------- */

function RateBtn({
  kind,
  title,
  onClick,
  onHover,
  compact = false,
}: {
  kind: Rating;
  title: string;
  onClick: () => void;
  onHover?: (r: Rating | null) => void;
  compact?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => onHover?.(kind)}
      onMouseLeave={() => onHover?.(null)}
      onFocus={() => onHover?.(kind)}
      onBlur={() => onHover?.(null)}
      onTouchStart={() => onHover?.(kind)}
      onTouchEnd={() => onHover?.(null)}
      className={`rate-pill ${kind}${compact ? " rate-pill--compact" : ""}`}
    >
      <span className="dot" />
      <span>{title}</span>
    </button>
  );
}

/* -------------- Center stage -------------- */

function CenterStage({
  word,
  revealed,
  onFlip,
  onOpenConj,
}: {
  word: Word;
  revealed: boolean;
  onFlip: () => void;
  onOpenConj: () => void;
}) {
  const article = word.pos === "noun" ? word.article : undefined;

  return (
    <div className="relative mx-auto w-full max-w-[360px] sm:max-w-[440px]">
      {/* Rotating conic gradient disc */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 grid place-items-center"
      >
        <div className="relative h-[112%] w-[112%]">
          <div className={`pos-disc ${discClass(word)}`} />
          <div className={`pos-disc b2 ${discClass(word)}`} />
        </div>
      </div>

      <div className="flip-scene">
        <div
          className={`flip-card ${revealed ? "is-flipped" : ""}`}
          onClick={onFlip}
          role="button"
          tabIndex={0}
          aria-label="Karte umdrehen"
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onFlip();
            }
          }}
        >
          {/* FRONT */}
          <div className="flip-face card-glass front w-full min-h-[360px] sm:min-h-[380px] md:min-h-[420px] lg:min-h-[440px] p-5 sm:p-8 md:p-10 flex flex-col items-center justify-center text-center">
            {article && (
              <div
                className="mb-2 text-xl font-bold tracking-tight sm:mb-4 sm:text-2xl"
                style={{ color: articleColor(article) }}
              >
                {article}
              </div>
            )}
            <h2 className="text-4xl font-bold tracking-tight sm:text-6xl md:text-7xl">
              {primaryOf(word)}
            </h2>

            <div className="mt-3 flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground sm:mt-6 sm:text-xs">
              <span className="h-px w-8 bg-border" />
              <span>{POS_DE[word.pos]}</span>
              <span className="h-px w-8 bg-border" />
            </div>

            <span
              onClick={(e) => {
                e.stopPropagation();
                speak(primaryOf(word));
              }}
              role="button"
              tabIndex={0}
              className="mt-3 grid h-10 w-10 place-items-center rounded-full bg-white/80 text-muted-foreground shadow hover:bg-white transition sm:mt-6 sm:h-11 sm:w-11"
              aria-label="Aussprache"
            >
              <SpeakerIcon />
            </span>
          </div>

          {/* BACK */}
          <div className="flip-face card-glass back w-full min-h-[360px] sm:min-h-[380px] md:min-h-[420px] lg:min-h-[440px] p-5 sm:p-8 flex flex-col items-center justify-center text-center">
            {article && (
              <div className="text-lg font-bold" style={{ color: articleColor(article) }}>
                {article}
              </div>
            )}
            <h2 className="mt-1 text-3xl font-bold tracking-tight sm:text-5xl">
              {primaryOf(word)}
            </h2>

            {word.pos === "adjective" && (
              <div className="mt-4 flex items-center gap-2 text-base font-semibold">
                <span>{(word as AdjectiveWord).positive}</span>
                <span className="text-muted-foreground">·</span>
                <span style={{ color: "var(--hard)" }}>{(word as AdjectiveWord).comparative}</span>
                <span className="text-muted-foreground">·</span>
                <span style={{ color: "var(--again)" }}>{(word as AdjectiveWord).superlative}</span>
              </div>
            )}
            {word.pos === "verb" && (
              <div className="mt-4 text-sm text-muted-foreground">
                {(word as VerbWord).praeteritum} · {(word as VerbWord).perfekt}
                {(word as VerbWord).governedPreposition && (
                  <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[color:var(--accent)] px-3 py-1 text-xs font-bold text-[color:var(--accent-foreground)]">
                    <span>+ {(word as VerbWord).governedPreposition!.text}</span>
                    <span className="rounded-md bg-white/70 px-1.5 py-0.5 text-[10px] font-black text-slate-900">
                      {(word as VerbWord).governedPreposition!.case}
                    </span>
                  </div>
                )}
              </div>
            )}
            {word.pos === "noun" && (
              <div className="mt-4 text-sm text-muted-foreground">
                Plural: die {(word as NounWord).plural}
              </div>
            )}
            {word.pos === "preposition" &&
              (() => {
                const pat = prepPattern(word as PrepositionWord);
                return (
                  <div className="mt-4 flex flex-col items-center gap-2">
                    <div
                      className="relative grid place-items-center"
                      style={{ width: 96, height: 96 }}
                    >
                      <CaseShape shape={pat.shape} color={pat.color} tint={pat.tint} size={92} />
                      <span
                        className="absolute text-xs font-black uppercase tracking-wider"
                        style={{
                          color: pat.color,
                          transform: pat.shape === "diamond" ? "rotate(0deg)" : undefined,
                        }}
                      >
                        {(word as PrepositionWord).cases.join(" / ")}
                      </span>
                    </div>
                    <div className="text-xs font-bold" style={{ color: pat.color }}>
                      {pat.label}
                    </div>
                  </div>
                );
              })()}

            {word.example && (
              <p className="mt-5 max-w-[85%] text-sm italic text-foreground/80">„{word.example}"</p>
            )}

            <div
              dir="rtl"
              lang="fa"
              className="mt-6 rounded-2xl bg-white/70 px-5 py-3 text-lg font-semibold shadow-sm text-slate-900"
              style={{ fontFamily: "Vazirmatn, Sora, sans-serif" }}
            >
              {word.translation}
            </div>

            {word.pos === "verb" && (
              <span
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenConj();
                }}
                role="button"
                className="mt-5 rounded-full bg-white/85 px-4 py-1.5 text-xs font-semibold shadow-sm hover:bg-white text-slate-900"
              >
                ▤ Konjugation ansehen
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* -------------- Side node columns (desktop) -------------- */

function SideColumn({
  side,
  word,
  revealed,
  accent,
}: {
  side: "left" | "right";
  word: Word;
  revealed: boolean;
  accent: string;
}) {
  const nodes = attributesFor(word, side);
  return (
    <div className="flex flex-col gap-4">
      {nodes.map((n, i) => (
        <div
          key={`${word.id}-${side}-${i}`}
          className={`relative ${revealed ? "node-in" : "opacity-0 pointer-events-none"}`}
          style={
            revealed ? { animationDelay: `${i * 110 + (side === "left" ? 40 : 120)}ms` } : undefined
          }
        >
          <NodeBox spec={n} accent={accent} />
          {/* Verbindungslinie zur Mitte */}
          <span
            aria-hidden
            className="absolute top-1/2 hidden h-px md:block"
            style={{
              [side === "left" ? "right" : "left"]: "-4rem",
              width: "4rem",
              background: `linear-gradient(${side === "left" ? "to right" : "to left"}, ${accent}00, ${accent}aa)`,
            }}
          />
          <span
            aria-hidden
            className="absolute top-1/2 hidden h-2 w-2 -translate-y-1/2 rounded-full md:block"
            style={{
              [side === "left" ? "right" : "left"]: "-4.35rem",
              background: accent,
              boxShadow: `0 0 0 3px ${accent}22`,
            }}
          />
        </div>
      ))}
    </div>
  );
}

function NodeBox({ spec, accent, delay }: { spec: NodeSpec; accent?: string; delay?: number }) {
  return (
    <div
      className="node-card"
      style={{
        borderColor: accent ? `${accent}33` : undefined,
        animationDelay: delay !== undefined ? `${delay}ms` : undefined,
      }}
    >
      <div className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground">
        <span style={{ color: accent }}>{spec.icon}</span>
        <span>{spec.label}</span>
      </div>
      <div className="text-sm font-semibold leading-snug">{spec.value}</div>
      {spec.hint && <div className="mt-0.5 text-[11px] text-muted-foreground">{spec.hint}</div>}
    </div>
  );
}

type NodeSpec = { icon: string; label: string; value: ReactNode; hint?: string };

function attributesFor(w: Word, side: "left" | "right"): NodeSpec[] {
  if (w.pos === "noun") {
    const n = w as NounWord;
    if (side === "left")
      return [
        { icon: "↕", label: "Plural", value: `die ${n.plural}` },
        { icon: "✎", label: "Beispiel", value: n.example ?? "—" },
        { icon: "🖼", label: "Bild", value: "—" },
      ];
    return [
      {
        icon: "◫",
        label: "Artikel",
        value: (
          <span style={{ color: articleColor(n.article) }}>
            {n.article} ({n.article === "der" ? "Mask." : n.article === "die" ? "Fem." : "Neutr."})
          </span>
        ),
      },
      { icon: "☰", label: "Wortart", value: "Nomen" },
      { icon: "★", label: "Häufigkeit", value: "B1 · Häufig" },
    ];
  }
  if (w.pos === "verb") {
    const v = w as VerbWord;
    if (side === "left")
      return [
        {
          icon: "→",
          label: "Präsens",
          value: `${v.praesens.ich} · ${v.praesens.du} · ${v.praesens.er}`,
        },
        { icon: "II", label: "Partizip II", value: v.perfekt.split(" ").slice(1).join(" ") || "—" },
        { icon: "✎", label: "Beispiel", value: v.example ?? "—" },
      ];
    return [
      { icon: "☰", label: "Wortart", value: "Verb" },
      {
        icon: "≡",
        label: "Hilfsverb",
        value: (
          <span style={{ color: v.aux === "sein" ? "var(--hard)" : "var(--again)" }}>{v.aux}</span>
        ),
      },
      { icon: "★", label: "Häufigkeit", value: "A1 · Sehr häufig" },
    ];
  }
  if (w.pos === "adjective") {
    const a = w as AdjectiveWord;
    if (side === "left")
      return [
        { icon: "↗", label: "Komparativ", value: a.comparative },
        { icon: "✎", label: "Beispiel", value: a.example ?? "—" },
        { icon: "⇋", label: "Gegenteil", value: a.antonym ?? "—" },
      ];
    return [
      { icon: "☰", label: "Wortart", value: "Adjektiv" },
      { icon: "▲", label: "Steigerung", value: "Pos · Komp · Sup" },
      { icon: "★", label: "Häufigkeit", value: "A2 · Grundwort" },
    ];
  }
  const p = w as PrepositionWord;
  if (side === "left")
    return [
      { icon: "✎", label: "Beispiel", value: p.example ?? "—" },
      { icon: "⇋", label: "Bedeutung", value: p.translation, hint: "Persisch" },
      {
        icon: "◫",
        label: "Muster",
        value: p.cases.length === 2 ? "Wechselpräposition" : `Immer mit ${p.cases[0]}`,
      },
    ];
  return [
    { icon: "☰", label: "Wortart", value: "Präposition" },
    { icon: "◈", label: "Kasus", value: p.cases.join(" / ") },
    { icon: "★", label: "Häufigkeit", value: "A2 · Häufig" },
  ];
}

/* -------------- Conjugation modal -------------- */

function ConjTable({ v }: { v: VerbWord }) {
  const pronouns: Array<keyof VerbWord["praesens"]> = ["ich", "du", "er", "wir", "ihr", "sie"];
  const label: Record<string, string> = {
    ich: "ich",
    du: "du",
    er: "er / sie / es",
    wir: "wir",
    ihr: "ihr",
    sie: "sie / Sie",
  };
  const auxCls = v.aux === "sein" ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-700";
  return (
    <div>
      <div className="mb-3 text-center">
        <div className="text-4xl font-bold">{v.infinitive}</div>
        <div className="mt-1 text-sm text-muted-foreground">
          Hilfsverb:{" "}
          <span className={`inline-block rounded-md px-1.5 py-0.5 font-semibold ${auxCls}`}>
            {v.aux}
          </span>
        </div>
      </div>
      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-start text-sm">
          <thead className="text-xs text-muted-foreground">
            <tr>
              <th className="p-3 text-start font-medium">Person</th>
              <th className="p-3 text-start font-medium">Präsens</th>
              <th className="p-3 text-start font-medium">Präteritum</th>
              <th className="p-3 text-start font-medium">Perfekt</th>
            </tr>
          </thead>
          <tbody>
            {pronouns.map((p) => {
              const [auxW, ...rest] = String(v.perfektConj[p]).split(" ");
              return (
                <tr key={p} className="border-t border-border">
                  <td className="p-3 text-muted-foreground">{label[p]}</td>
                  <td className="p-3 font-semibold">{v.praesens[p]}</td>
                  <td className="p-3 font-semibold">{v.praeteritumConj[p]}</td>
                  <td className="p-3 font-semibold">
                    <span className={`inline-block rounded-md px-1.5 py-0.5 ${auxCls}`}>
                      {auxW}
                    </span>{" "}
                    {rest.join(" ")}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SpeakerIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="18"
      height="18"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
    >
      <path d="M4 10v4h4l5 4V6L8 10H4z" />
      <path d="M16 9a4 4 0 0 1 0 6" />
    </svg>
  );
}
