import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { motion, useMotionValue, useTransform, animate, AnimatePresence } from "framer-motion";
import { useEffect, useState, type ReactNode } from "react";
import { useDeusi } from "@/lib/deusi/store";
import {
  PROFILE_HEADER,
  ROADMAP,
  ROADMAP_META,
  STATS,
  ACTIVITY,
  CERTIFICATES,
  HEATMAP,
  HEATMAP_MONTHS,
  HEATMAP_WEEKDAYS,
  DEFAULT_SETTINGS,
  SETTINGS_LANGUAGES,
  CEFR_GOALS,
  TIMEZONES,
} from "@/lib/deusi/profile/mockProfile";
import { useTheme } from "@/lib/deusi/theme";
import { FaHint } from "@/components/deusi/FaHint";
import { SectionHero } from "@/components/deusi/SectionHero";
import { LearnerProfilePrompt } from "@/components/deusi/onboarding/LearnerProfilePrompt";
import { GraduationCap, ArrowRight } from "lucide-react";
import { ACHIEVEMENTS } from "@/lib/deusi/achievements";

export const Route = createFileRoute("/profil")({
  head: () => ({
    meta: [
      { title: "Mein Profil · DEUSI" },
      { name: "description", content: "Dein persönliches Lern-Cockpit auf DEUSI." },
    ],
  }),
  component: ProfilePage,
});

// ============================================================
// Shared primitives
// ============================================================

function AnimatedNumber({
  value,
  duration = 1.1,
  format = (n: number) => n.toLocaleString("de-DE"),
}: {
  value: number;
  duration?: number;
  format?: (n: number) => string;
}) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (latest) => format(Math.round(latest)));
  useEffect(() => {
    const controls = animate(mv, value, { duration, ease: [0.2, 0.8, 0.2, 1] });
    return controls.stop;
  }, [value, duration, mv]);
  return <motion.span>{rounded}</motion.span>;
}

function GlassSection({
  title,
  action,
  children,
  className = "",
}: {
  title?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
      className={`glass-strong rounded-[28px] p-5 sm:p-6 ${className}`}
    >
      {(title || action) && (
        <header className="mb-4 flex items-center justify-between gap-3">
          {title && <h2 className="text-[15px] font-semibold tracking-tight">{title}</h2>}
          {action}
        </header>
      )}
      {children}
    </motion.section>
  );
}

function SectionLink({ children }: { children: ReactNode }) {
  return (
    <button
      type="button"
      className="text-xs font-semibold text-[color:var(--accent-foreground)] transition hover:opacity-80"
    >
      {children}
    </button>
  );
}

// ============================================================
// Page
// ============================================================

function ProfilePage() {
  return (
    <div className="space-y-6 pb-10 animate-fade">
      <SectionHero sectionKey="profile" />

      <LearnerProfilePrompt />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-6">
          <ProfileHeader />
          <SubscriptionCard />
          <PlacementTestEntry />
          <LanguageRoadmap />
          <SettingsCard />

          <StatisticsCard />

          <HeatmapCard />
        </div>

        <aside className="space-y-6">
          <RecentActivityCard />
          <BadgesCard />
          <CertificatesCard />
          <DailyGoalCard />
        </aside>
      </div>
    </div>
  );
}

function PlacementTestEntry() {
  return (
    <Link
      to="/einstufungstest"
      id="einstufungstest"
      className="group relative block scroll-mt-24 overflow-hidden rounded-3xl p-6 text-left shadow-lg transition hover:-translate-y-0.5 hover:shadow-2xl sm:p-8"
      style={{ background: "linear-gradient(135deg,#0F172A,#1E293B 60%,#312E81)" }}
    >
      <div className="relative z-10 flex items-center gap-4">
        <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/10 text-white backdrop-blur transition group-hover:scale-105">
          <GraduationCap className="h-7 w-7" />
        </div>
        <div className="min-w-0">
          <h2 className="text-2xl font-black text-white sm:text-3xl">
            Einstufungs
            <span
              style={{
                background: "linear-gradient(90deg,#F7C948,#DD2222)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              test
            </span>
          </h2>
          <FaHint className="text-white/70">تعیین سطح در ۵ دقیقه</FaHint>
        </div>
        <ArrowRight className="ml-auto hidden h-5 w-5 shrink-0 text-white/70 transition group-hover:translate-x-1 group-hover:text-white sm:block" />
      </div>
      <p className="relative z-10 mt-3 max-w-xl text-sm text-white/70">
        10 kurze Fragen — wir schätzen dein Niveau von A1 bis C1 und schlagen den passenden Lernpfad
        vor.
      </p>
      <span className="relative z-10 mt-4 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-sm font-semibold text-white backdrop-blur transition group-hover:bg-white/25">
        Test starten <ArrowRight className="h-4 w-4" />
      </span>
    </Link>
  );
}

function PageHeader() {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Mein Profil</h1>
        <FaHint>پروفایل من</FaHint>
        <p className="mt-1 text-sm text-[color:var(--muted-foreground)]">
          Deine Lernreise auf einen Blick.
        </p>
        <FaHint size="sm">سفر یادگیری‌ات در یک نگاه</FaHint>
      </div>
    </div>
  );
}

// ============================================================
// Profile Header card
// ============================================================

function ProfileHeader() {
  const p = PROFILE_HEADER;
  const { logout } = useDeusi();
  const router = useRouter();
  const handleLogout = () => {
    logout();
    router.navigate({ to: "/login" });
  };
  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, ease: [0.2, 0.8, 0.2, 1] }}
      className="glass-strong relative overflow-hidden rounded-[32px] p-6 sm:p-8"
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{
          background:
            "radial-gradient(120% 90% at 0% 0%, rgba(139,92,246,0.18), transparent 55%), radial-gradient(80% 70% at 100% 20%, rgba(221,34,34,0.14), transparent 60%)",
        }}
      />
      <div className="relative grid grid-cols-1 gap-6 sm:grid-cols-[auto_minmax(0,1fr)] sm:items-center 2xl:grid-cols-[auto_minmax(0,1fr)_auto]">
        <Avatar initials={p.avatarInitials} gradient={p.avatarGradient} size={128} />

        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{p.fullName}</h2>
            {p.verified && <VerifiedBadge />}
          </div>
          <div className="mt-1 text-sm text-[color:var(--muted-foreground)]">{p.username}</div>

          <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-[color:var(--secondary)] px-3 py-1 text-xs font-semibold">
            <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--accent-foreground)]" />
            {p.level} Lernender
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <HeaderStat
              icon={<CalendarLine />}
              label="Mitglied seit"
              value={p.memberSince}
              tint="#EEF2FF"
              color="#4F46E5"
            />
            <HeaderStat
              icon={<FireLine />}
              label="Lernserie"
              value={`${p.streakDays} Tage`}
              tint="#FEE9E7"
              color="#DD2222"
            />
            <HeaderStat
              icon={<HeartLine />}
              label="Memory Health"
              value={`${p.memoryHealth}%`}
              tint="#F3ECFE"
              color="#8B5CF6"
            />
          </div>
        </div>

        <div className="flex w-full flex-col gap-2 sm:col-span-2 sm:flex-row sm:flex-wrap 2xl:col-span-1 2xl:w-[240px] 2xl:flex-col 2xl:flex-nowrap">
          <PillButton icon={<PenIcon />} label="Profil bearbeiten" />
          <PillButton icon={<ShareIcon />} label="Profil teilen" />
          <PillButton icon={<DownloadIcon />} label="Zertifikat herunterladen" />
          <button
            type="button"
            onClick={handleLogout}
            className="mt-1 flex items-center justify-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold text-white transition hover:-translate-y-0.5"
            style={{
              background: "linear-gradient(135deg, #DD2222, #B91C1C)",
              boxShadow: "0 12px 28px -12px rgba(221,34,34,.55)",
            }}
          >
            <svg
              viewBox="0 0 24 24"
              width="16"
              height="16"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
              <path d="M10 17l-5-5 5-5" />
              <path d="M15 12H5" />
            </svg>
            <span>Abmelden</span>
          </button>
        </div>
      </div>
    </motion.section>
  );
}

// ============================================================
// Subscription Card
// ============================================================

const SUBSCRIPTION = {
  plan: "Premium",
  tagline: "Voller Zugang zu allen Lernmodulen",
  status: "Aktiv",
  price: "9,99 €",
  cycle: "pro Monat",
  renewsOn: "15. August 2026",
  daysLeft: 28,
  totalDays: 30,
  paymentBrand: "Visa",
  paymentLast4: "4242",
  features: [
    { icon: "🎴", label: "Unbegrenzte Flashcards" },
    { icon: "🤖", label: "KI Coach ohne Limit" },
    { icon: "📚", label: "Alle Grammatiklektionen" },
    { icon: "🎧", label: "Premium Podcasts" },
    { icon: "🏆", label: "Exklusive Zertifikate" },
    { icon: "☁️", label: "Cloud Sync & Offline" },
  ],
};

function SubscriptionCard() {
  const s = SUBSCRIPTION;
  const pct = Math.round((s.daysLeft / s.totalDays) * 100);
  const R = 34;
  const C = 2 * Math.PI * R;
  const dash = (pct / 100) * C;

  return (
    <motion.section
      id="abonnement"
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, ease: [0.2, 0.8, 0.2, 1] }}
      className="relative overflow-hidden rounded-[32px] p-6 sm:p-8 scroll-mt-24"
      style={{
        background: "linear-gradient(135deg, #1a0b1e 0%, #2a0f3f 45%, #4a1220 100%)",
        boxShadow: "0 30px 80px -30px rgba(139,92,246,.5), inset 0 1px 0 rgba(255,255,255,.06)",
      }}
    >
      {/* Ambient glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-60 blur-3xl"
        style={{ background: "radial-gradient(circle, #F7C948 0%, transparent 65%)" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-16 -bottom-20 h-64 w-64 rounded-full opacity-45 blur-3xl"
        style={{ background: "radial-gradient(circle, #8B5CF6 0%, transparent 65%)" }}
      />

      <div className="relative grid gap-6 lg:grid-cols-[1fr_auto] lg:items-center">
        <div className="min-w-0 text-white">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white/85 backdrop-blur">
              <span aria-hidden>👑</span> Mein Abonnement
            </span>
            <FaHint size="sm" className="!text-white/70">
              اشتراک من
            </FaHint>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#22C55E]/95 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> {s.status}
            </span>
          </div>

          <h2 className="mt-3 text-3xl font-black leading-tight tracking-tight sm:text-4xl">
            <span
              className="bg-clip-text text-transparent"
              style={{ backgroundImage: "linear-gradient(135deg, #FDE68A, #F7C948 50%, #FB923C)" }}
            >
              {s.plan}
            </span>{" "}
            Plan
          </h2>
          <p className="mt-1 text-sm text-white/60">{s.tagline}</p>

          <div className="mt-5 flex flex-wrap items-baseline gap-2">
            <span className="text-4xl font-black tracking-tight">{s.price}</span>
            <span className="text-sm text-white/60">{s.cycle}</span>
          </div>

          {/* Features */}
          <ul className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {s.features.map((f) => (
              <li
                key={f.label}
                className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.05] px-3 py-2 text-xs text-white/85 backdrop-blur"
              >
                <span aria-hidden className="text-sm">
                  {f.icon}
                </span>
                <span className="truncate">{f.label}</span>
              </li>
            ))}
          </ul>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-2xl px-5 py-2.5 text-sm font-bold text-[#1a0b1e] shadow-[0_10px_30px_-8px_rgba(247,201,72,.6)] transition hover:-translate-y-0.5"
              style={{ background: "linear-gradient(135deg, #FDE68A, #F7C948 60%, #FB923C)" }}
            >
              Plan verwalten →
            </button>
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-2xl border border-white/15 bg-white/[0.06] px-4 py-2.5 text-xs font-semibold text-white/85 backdrop-blur transition hover:bg-white/[0.14]"
            >
              Rechnung ansehen
            </button>
          </div>
        </div>

        {/* Right side: countdown ring + payment */}
        <div className="flex flex-col items-center gap-4 lg:w-[240px]">
          <div className="relative h-[140px] w-[140px]">
            <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
              <defs>
                <linearGradient id="subRing" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#F7C948" />
                  <stop offset="60%" stopColor="#FB923C" />
                  <stop offset="100%" stopColor="#DD2222" />
                </linearGradient>
              </defs>
              <circle
                cx="50"
                cy="50"
                r={R}
                fill="none"
                stroke="rgba(255,255,255,.08)"
                strokeWidth="7"
              />
              <circle
                cx="50"
                cy="50"
                r={R}
                fill="none"
                stroke="url(#subRing)"
                strokeWidth="7"
                strokeLinecap="round"
                strokeDasharray={`${dash} ${C}`}
                style={{
                  transition: "stroke-dasharray 1.2s cubic-bezier(.2,.8,.2,1)",
                  filter: "drop-shadow(0 0 8px rgba(247,201,72,.5))",
                }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-3xl font-black tabular-nums text-white">
                <AnimatedNumber value={s.daysLeft} />
              </div>
              <div className="text-[10px] font-semibold uppercase tracking-wider text-white/60">
                Tage übrig
              </div>
            </div>
          </div>

          <div className="w-full rounded-2xl border border-white/10 bg-white/[0.06] p-3 backdrop-blur">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-white/60">
              Verlängerung
            </div>
            <div className="mt-0.5 text-sm font-bold text-white">{s.renewsOn}</div>
            <div className="mt-3 flex items-center gap-2 border-t border-white/10 pt-3">
              <span className="grid h-8 w-12 place-items-center rounded-md bg-white text-[10px] font-black tracking-wider text-[#1a1f71]">
                {s.paymentBrand.toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-[10px] text-white/60">Zahlungsmittel</div>
                <div className="text-xs font-semibold text-white">•••• {s.paymentLast4}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.section>
  );
}

function Avatar({
  initials,
  gradient,
  size = 96,
}: {
  initials: string;
  gradient: [string, string];
  size?: number;
}) {
  return (
    <div className="relative shrink-0">
      <div
        className="grid place-items-center rounded-full text-white font-bold shadow-[0_20px_50px_-15px_rgba(0,0,0,0.35)]"
        style={{
          width: size,
          height: size,
          background: `linear-gradient(135deg, ${gradient[0]}, ${gradient[1]})`,
          fontSize: size * 0.36,
          letterSpacing: "-0.03em",
        }}
      >
        {initials}
      </div>
      <button
        type="button"
        aria-label="Profilbild ändern"
        className="absolute -bottom-1 -right-1 grid h-9 w-9 place-items-center rounded-full bg-[color:var(--card)] shadow-[0_8px_24px_-8px_rgba(0,0,0,0.3)] transition hover:scale-105"
      >
        <PenIcon />
      </button>
    </div>
  );
}

function VerifiedBadge() {
  return (
    <span className="grid h-5 w-5 place-items-center rounded-full bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] text-white">
      <svg
        viewBox="0 0 24 24"
        width="12"
        height="12"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M5 12l5 5L20 7" />
      </svg>
    </span>
  );
}

function HeaderStat({
  icon,
  label,
  value,
  tint,
  color,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  tint: string;
  color: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <span
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl"
        style={{ background: tint, color }}
      >
        {icon}
      </span>
      <div className="min-w-0">
        <div className="text-[11px] font-medium uppercase tracking-wider text-[color:var(--muted-foreground)]">
          {label}
        </div>
        <div className="truncate text-sm font-semibold">{value}</div>
      </div>
    </div>
  );
}

function PillButton({
  icon,
  label,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-2 rounded-full bg-[color:var(--card)] px-4 py-2.5 text-sm font-medium shadow-[0_1px_2px_rgba(0,0,0,0.04),0_10px_24px_-12px_rgba(0,0,0,0.15)] transition hover:-translate-y-0.5 hover:shadow-[0_1px_2px_rgba(0,0,0,0.04),0_18px_32px_-14px_rgba(0,0,0,0.22)]"
    >
      <span className="text-[color:var(--muted-foreground)]">{icon}</span>
      <span className="truncate">{label}</span>
    </button>
  );
}

// ============================================================
// Language Roadmap
// ============================================================

function LanguageRoadmap() {
  const current = ROADMAP.find((n) => n.status === "current");
  const doneCount = ROADMAP.filter((n) => n.status === "done").length;

  return (
    <GlassSection>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1b0a3d] via-[#4c1d95] to-[#7a2ff2] p-6 text-white">
          <div
            aria-hidden
            className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-white/15 blur-3xl"
          />
          <div
            aria-hidden
            className="pointer-events-none absolute -bottom-24 -left-12 h-56 w-56 rounded-full bg-[#ff6a3d]/30 blur-3xl"
          />

          <div className="relative flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/70">
                Sprachniveau
              </div>
              <h2 className="mt-1 text-xl font-black tracking-tight">Dein Deutsch Level</h2>
              <FaHint size="sm" className="!text-white/80 !opacity-100">
                مسیر سطح زبان آلمانی‌ات
              </FaHint>
            </div>
            <div className="rounded-2xl bg-white/15 px-4 py-2 text-center backdrop-blur">
              <div className="text-2xl font-black leading-none">{current?.level ?? "A1"}</div>
              <div className="mt-1 text-[10px] font-semibold uppercase tracking-widest text-white/70">
                aktuell
              </div>
            </div>
          </div>

          <div className="relative mt-8">
            <div className="relative flex items-start justify-between">
              <div className="absolute left-4 right-4 top-5 h-[6px] rounded-full bg-white/15" />
              <motion.div
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: ROADMAP_META.overallProgress / 100 }}
                viewport={{ once: true }}
                transition={{ duration: 1, ease: [0.2, 0.8, 0.2, 1] }}
                style={{ transformOrigin: "left" }}
                className="absolute left-4 right-4 top-5 h-[6px] rounded-full bg-gradient-to-r from-[#4ade80] via-[#facc15] to-[#ff6a3d] shadow-[0_0_18px_rgba(255,255,255,0.45)]"
              />
              {ROADMAP.map((n, i) => (
                <motion.div
                  key={n.level}
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.15 + i * 0.08, duration: 0.4 }}
                  className="relative z-10 flex w-[16%] flex-col items-center gap-2"
                >
                  <RoadmapDot node={n} />
                  <span
                    className={`text-xs font-bold ${n.status === "locked" ? "text-white/55" : "text-white"}`}
                  >
                    {n.level}
                  </span>
                  {n.status === "current" && (
                    <span className="rounded-full bg-white px-2 py-0.5 text-center text-[9px] font-black uppercase tracking-wide text-[#4c1d95]">
                      Aktuell
                    </span>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          <div className="relative mt-7 grid grid-cols-3 gap-2 rounded-2xl bg-white/10 p-3 backdrop-blur">
            <RoadmapStat value={`${ROADMAP_META.overallProgress}%`} label="Gesamtweg" />
            <RoadmapStat value={`${doneCount}/${ROADMAP.length}`} label="Stufen" />
            <RoadmapStat value={ROADMAP_META.nextLevel} label="Nächstes Ziel" />
          </div>
        </div>

        <div className="flex flex-col justify-center rounded-3xl border border-[color:var(--border)] bg-[color:var(--secondary)] p-5">
          <div className="text-xs font-medium text-[color:var(--muted-foreground)]">
            Geschätzte Zeit bis {ROADMAP_META.nextLevel}
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-4xl font-bold tracking-tight">
              <AnimatedNumber value={ROADMAP_META.daysUntilNext} />
            </span>
            <span className="text-sm text-[color:var(--muted-foreground)]">Tage</span>
          </div>
          <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-[color:var(--card)]">
            <motion.div
              initial={{ width: 0 }}
              whileInView={{ width: `${ROADMAP_META.progressToNext}%` }}
              viewport={{ once: true }}
              transition={{ duration: 1.1, ease: [0.2, 0.8, 0.2, 1] }}
              className="h-full rounded-full bg-gradient-to-r from-[#7a2ff2] to-[#ff6a3d]"
            />
          </div>
          <div className="mt-2 text-xs text-[color:var(--muted-foreground)]">
            {ROADMAP_META.progressToNext}% abgeschlossen
          </div>
          <FaHint size="sm" className="mt-3">
            ‫{ROADMAP_META.progressToNext}٪ تا سطح بعدی طی شده
          </FaHint>
        </div>
      </div>
    </GlassSection>
  );
}

function RoadmapStat({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center">
      <div className="text-sm font-black leading-tight">{value}</div>
      <div className="mt-0.5 text-[9px] font-semibold uppercase tracking-wider text-white/65">
        {label}
      </div>
    </div>
  );
}

function RoadmapDot({ node }: { node: (typeof ROADMAP)[number] }) {
  if (node.status === "done") {
    return (
      <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-[#4ade80] to-[#15803d] text-white shadow-[0_10px_26px_-8px_rgba(74,222,128,0.8)] ring-4 ring-white/20">
        <svg
          viewBox="0 0 24 24"
          width="15"
          height="15"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M5 12l5 5L20 7" />
        </svg>
      </div>
    );
  }
  if (node.status === "current") {
    return (
      <div className="relative grid h-11 w-11 place-items-center rounded-full bg-white text-[#4c1d95] shadow-[0_12px_28px_-6px_rgba(255,255,255,0.6)] ring-4 ring-white/30">
        <span className="absolute inset-0 animate-ping rounded-full bg-white opacity-40" />
        <span className="relative text-[11px] font-black">{node.level}</span>
      </div>
    );
  }
  return (
    <div className="grid h-10 w-10 place-items-center rounded-full bg-white/12 text-white/70 ring-1 ring-inset ring-white/25 backdrop-blur">
      <span className="text-[10px] font-bold">{node.level}</span>
    </div>
  );
}

// ============================================================

function StatisticsCard() {
  const total = STATS.reduce((a, s) => a + s.value, 0);
  const max = Math.max(...STATS.map((s) => s.value));
  const top = [...STATS].sort((a, b) => b.value - a.value).slice(0, 3);

  return (
    <GlassSection title="Statistik Übersicht" action={<SectionLink>Alle ansehen</SectionLink>}>
      {/* Headline row — total activity + the three strongest areas */}
      <div className="mb-4 flex flex-col gap-4 rounded-3xl bg-gradient-to-br from-[#141821] to-[#2b2233] p-5 text-white sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-widest text-white/60">
            Gesamte Lernaktionen
          </div>
          <div className="mt-1 text-4xl font-black tracking-tight">
            <AnimatedNumber value={total} />
          </div>
          <div className="fa-hint !text-white/60">مجموع فعالیت‌های یادگیری</div>
        </div>
        <div className="flex flex-wrap gap-2">
          {top.map((s) => (
            <div
              key={s.key}
              className="flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 backdrop-blur"
            >
              <span
                className="grid h-7 w-7 place-items-center rounded-lg"
                style={{ background: s.tint, color: s.color }}
              >
                <StatIcon kind={s.icon} />
              </span>
              <div className="leading-tight">
                <div className="text-sm font-bold tabular-nums">{s.value}</div>
                <div className="text-[10px] text-white/60">{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
        {STATS.map((s, i) => {
          const share = Math.round((s.value / total) * 100);
          const barW = Math.round(Math.sqrt(s.value / max) * 100);
          return (
            <motion.div
              key={s.key}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.035, duration: 0.35 }}
              className="group relative overflow-hidden rounded-2xl bg-[color:var(--card)] p-3.5 ring-1 ring-black/5 transition hover:-translate-y-1 hover:shadow-[0_18px_34px_-18px_rgba(0,0,0,0.35)]"
            >
              <span
                aria-hidden
                className="pointer-events-none absolute -right-8 -top-8 h-20 w-20 rounded-full opacity-0 blur-2xl transition-opacity duration-300 group-hover:opacity-60"
                style={{ background: s.color }}
              />
              <div className="relative flex items-start justify-between">
                <span
                  className="grid h-9 w-9 place-items-center rounded-xl"
                  style={{ background: s.tint, color: s.color }}
                >
                  <StatIcon kind={s.icon} />
                </span>
                <span className="text-[10px] font-bold tabular-nums" style={{ color: s.color }}>
                  {share}%
                </span>
              </div>
              <div className="relative mt-2.5 text-2xl font-black tracking-tight">
                <AnimatedNumber value={s.value} />
              </div>
              <div className="relative text-[11px] font-medium text-[color:var(--muted-foreground)]">
                {s.label}
              </div>
              <div className="relative mt-2.5 h-1.5 overflow-hidden rounded-full bg-[color:var(--secondary)]">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${barW}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.9, delay: 0.1 + i * 0.03, ease: [0.2, 0.8, 0.2, 1] }}
                  className="h-full rounded-full"
                  style={{ background: s.color }}
                />
              </div>
            </motion.div>
          );
        })}
      </div>
    </GlassSection>
  );
}

function StatIcon({ kind }: { kind: string }) {
  const s = { width: 14, height: 14 } as const;
  switch (kind) {
    case "book":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2V5z" />
        </svg>
      );
    case "cards":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="6" width="14" height="12" rx="2" />
          <path d="M7 3h12a2 2 0 0 1 2 2v10" />
        </svg>
      );
    case "box":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M3 7l9-4 9 4-9 4-9-4z" />
          <path d="M3 12l9 4 9-4" />
        </svg>
      );
    case "grammar":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 4h16v4H4z" />
          <path d="M4 12h10v4H4z" />
          <path d="M4 20h6" />
        </svg>
      );
    case "read":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M2 6c3-1 6-1 9 1v13c-3-2-6-2-9-1V6z" />
          <path d="M22 6c-3-1-6-1-9 1v13c3-2 6-2 9-1V6z" />
        </svg>
      );
    case "ear":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M6 9a6 6 0 1 1 12 0c0 3-2 4-2 6a3 3 0 0 1-6 0" />
        </svg>
      );
    case "headphone":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 14v-2a8 8 0 1 1 16 0v2" />
          <path d="M4 14h3v6H5a1 1 0 0 1-1-1v-5zM20 14h-3v6h2a1 1 0 0 0 1-1v-5z" />
        </svg>
      );
    case "pencil":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 20h9" />
          <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
        </svg>
      );
    case "sparkle":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3z" />
        </svg>
      );
    case "calendar":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="5" width="18" height="16" rx="2" />
          <path d="M16 3v4M8 3v4M3 10h18" />
        </svg>
      );
    default:
      return null;
  }
}

// ============================================================
// Heatmap
// ============================================================

function HeatmapCard() {
  const [range, setRange] = useState("Dieses Jahr");
  return (
    <GlassSection
      title="Lernaktivität Heatmap"
      action={
        <select
          value={range}
          onChange={(e) => setRange(e.target.value)}
          className="rounded-full bg-[color:var(--secondary)] px-3 py-1 text-xs font-semibold outline-none"
        >
          <option>Dieses Jahr</option>
          <option>Letztes Jahr</option>
          <option>Alle Zeit</option>
        </select>
      }
    >
      <div className="flex gap-2 overflow-x-auto pb-2">
        <div className="flex flex-col justify-between py-[2px] text-[9px] text-[color:var(--muted-foreground)]">
          {HEATMAP_WEEKDAYS.map((w) => (
            <span key={w} className="h-[10px] leading-[10px]">
              {w}
            </span>
          ))}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex gap-[3px]">
            {HEATMAP.map((week, wi) => (
              <div key={wi} className="flex flex-col gap-[3px]">
                {week.map((v, di) => (
                  <motion.span
                    key={di}
                    initial={{ opacity: 0, scale: 0.6 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: (wi * 7 + di) * 0.001, duration: 0.2 }}
                    className="h-[10px] w-[10px] rounded-[3px]"
                    style={{ background: heatColor(v) }}
                    title={`Level ${v}`}
                  />
                ))}
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between text-[10px] text-[color:var(--muted-foreground)]">
            {HEATMAP_MONTHS.map((m) => (
              <span key={m}>{m}</span>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-end gap-1.5 text-[10px] text-[color:var(--muted-foreground)]">
        <span>Weniger</span>
        {[0, 1, 2, 3, 4].map((l) => (
          <span
            key={l}
            className="h-[10px] w-[10px] rounded-[3px]"
            style={{ background: heatColor(l) }}
          />
        ))}
        <span>Mehr</span>
      </div>
    </GlassSection>
  );
}

function heatColor(v: number) {
  const shades = ["var(--secondary)", "#E9E1FB", "#C9B8F5", "#9F82EA", "#7C5DE6"];
  return shades[v] || shades[0];
}

// ============================================================
// Right column: activity / badges / certificates / daily goal
// ============================================================

function RecentActivityCard() {
  const groups = ACTIVITY.reduce<Record<string, typeof ACTIVITY>>((acc, a) => {
    (acc[a.day] ||= []).push(a);
    return acc;
  }, {});
  const orderedDays = ["Heute", "Gestern"].filter((d) => groups[d]);
  return (
    <GlassSection title="Letzte Aktivitäten" action={<SectionLink>Alle anzeigen</SectionLink>}>
      <div className="space-y-4">
        {orderedDays.map((day) => (
          <div key={day}>
            <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-[color:var(--muted-foreground)]">
              {day}
            </div>
            <div className="relative space-y-3 border-l border-[color:var(--border)] pl-4">
              {groups[day].map((a) => (
                <div key={a.id} className="relative">
                  <span className="absolute -left-[22px] top-1.5 grid h-4 w-4 place-items-center rounded-full bg-[color:var(--card)] ring-2 ring-[color:var(--border)]">
                    <span
                      className="h-1.5 w-1.5 rounded-full"
                      style={{ background: activityColor(a.icon) }}
                    />
                  </span>
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-xs font-semibold">{a.title}</div>
                      <div className="text-xs text-[color:var(--muted-foreground)]">{a.detail}</div>
                    </div>
                    <div className="text-[10px] font-medium text-[color:var(--muted-foreground)]">
                      {a.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </GlassSection>
  );
}
function activityColor(k: string) {
  return (
    (
      {
        leitner: "#8B5CF6",
        podcast: "#3B82F6",
        event: "#DD2222",
        grammar: "#F59E0B",
        cards: "#22C55E",
        ai: "#EC4899",
        read: "#10B981",
      } as Record<string, string>
    )[k] || "#8B5CF6"
  );
}

function BadgesCard() {
  const unlocked = ACHIEVEMENTS.filter((a) => a.unlocked);
  const shown = unlocked.slice(0, 6);
  return (
    <GlassSection
      title="Erfolge"
      action={
        <Link
          to="/achievements"
          className="inline-flex items-center gap-1 rounded-full border border-[color:var(--border)] px-3 py-1.5 text-[11px] font-bold transition hover:bg-[color:var(--secondary)]"
        >
          Alle Erfolge
          <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      }
    >
      <div className="mb-3 flex items-center gap-2 text-[11px] font-semibold text-[color:var(--muted-foreground)]">
        <span className="tabular-nums text-[color:var(--foreground)]">
          {unlocked.length}/{ACHIEVEMENTS.length}
        </span>
        <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-[color:var(--secondary)]">
          <motion.span
            className="block h-full rounded-full"
            style={{ background: "linear-gradient(90deg,#8B5CF6,#F59E0B)" }}
            initial={{ width: 0 }}
            whileInView={{ width: `${(unlocked.length / ACHIEVEMENTS.length) * 100}%` }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, ease: [0.2, 0.8, 0.2, 1] }}
          />
        </span>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((a, i) => (
          <motion.div
            key={a.id}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05, duration: 0.35 }}
            whileHover={{ y: -4 }}
            className="group relative flex flex-col overflow-hidden rounded-2xl p-3.5 text-white shadow-md ring-1 ring-white/25 transition hover:shadow-xl"
            style={{
              backgroundImage: `linear-gradient(135deg, ${a.color} 0%, color-mix(in oklab, ${a.color} 62%, #000) 100%)`,
              boxShadow: `0 10px 24px -12px color-mix(in oklab, ${a.color} 75%, transparent)`,
            }}
          >
            <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
              <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-white/25 blur-2xl" />
              <div className="absolute inset-x-0 -top-24 h-24 rotate-12 bg-gradient-to-r from-transparent via-white/25 to-transparent opacity-0 transition duration-700 group-hover:top-full group-hover:opacity-100" />
            </div>
            <div className="relative flex items-start justify-between gap-2">
              <div
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/95 text-2xl shadow ring-1 ring-white/50"
                style={{ color: a.color }}
              >
                <span aria-hidden>{a.emoji}</span>
              </div>
              <span className="max-w-[52%] truncate rounded-full bg-white/22 px-2 py-0.5 text-[8px] font-black uppercase tracking-wider">
                {a.category}
              </span>
            </div>
            <div className="relative mt-3">
              <div className="text-[13px] font-black leading-tight">{a.labelDe}</div>
              <div className="fa-hint-xs !text-[10px] !text-white/80" dir="rtl">
                {a.labelFa}
              </div>
              <div className="mt-1 text-[10px] font-semibold text-white/80">{a.sub}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </GlassSection>
  );
}

function BadgeIcon({ kind }: { kind: string }) {
  const s = { width: 20, height: 20 } as const;
  switch (kind) {
    case "fire":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2s5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 1-3s-1 4 2 4a2 2 0 0 0 2-2c0-3-4-4 0-9z" />
        </svg>
      );
    case "words":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2V5z" />
          <path d="M8 7h7M8 11h7" />
        </svg>
      );
    case "grammar":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 4h16v4H4z" />
          <path d="M4 12h10v4H4z" />
        </svg>
      );
    case "read":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M2 6c3-1 6-1 9 1v13c-3-2-6-2-9-1V6z" />
        </svg>
      );
    case "podcast":
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 14v-2a8 8 0 1 1 16 0v2" />
        </svg>
      );
    default:
      return (
        <svg {...s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="5" width="18" height="16" rx="2" />
        </svg>
      );
  }
}

function CertificatesCard() {
  return (
    <GlassSection title="Zertifikate" action={<SectionLink>Alle ansehen</SectionLink>}>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {CERTIFICATES.map((c) => (
          <motion.div
            key={c.id}
            whileHover={{ y: -3 }}
            className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[color:var(--card)] to-[color:var(--secondary)] p-4 shadow-[0_1px_2px_rgba(0,0,0,0.04),0_10px_24px_-14px_rgba(0,0,0,0.15)]"
          >
            <div className="absolute -right-4 -top-4 grid h-16 w-16 place-items-center rounded-full bg-[color:var(--accent)] opacity-40">
              <TrophyIcon />
            </div>
            <div className="text-xs font-semibold text-[color:var(--muted-foreground)]">
              {c.title}
            </div>
            <div className="mt-1 text-lg font-bold tracking-tight">{c.level}</div>
            <div className="mt-3 text-[10px] font-medium text-[color:var(--muted-foreground)]">
              Erhalten am {c.issuedOn}
            </div>
            <button
              type="button"
              className="mt-3 inline-flex items-center gap-1 text-[11px] font-semibold text-[color:var(--accent-foreground)] hover:opacity-80"
            >
              <DownloadIcon /> Herunterladen
            </button>
          </motion.div>
        ))}
      </div>
    </GlassSection>
  );
}

function DailyGoalCard() {
  const [minutes, setMinutes] = useState(DEFAULT_SETTINGS.learning.dailyGoalMinutes);
  const [reminder, setReminder] = useState(true);
  return (
    <GlassSection title="Tägliches Lernziel">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-[color:var(--accent)] text-[color:var(--accent-foreground)]">
          <svg
            viewBox="0 0 24 24"
            width="18"
            height="18"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <circle cx="12" cy="12" r="9" />
            <path d="M12 7v5l3 2" />
          </svg>
        </span>
        <div>
          <div className="text-lg font-bold tracking-tight">
            <AnimatedNumber value={minutes} /> Minuten pro Tag
          </div>
        </div>
      </div>
      <div className="mt-4">
        <input
          type="range"
          min={10}
          max={60}
          step={5}
          value={minutes}
          onChange={(e) => setMinutes(Number(e.target.value))}
          className="w-full accent-[color:var(--accent-foreground)]"
        />
        <div className="mt-1 flex justify-between text-[10px] font-medium text-[color:var(--muted-foreground)]">
          <span>10 Min</span>
          <span>20 Min</span>
          <span>30 Min</span>
          <span>45 Min</span>
          <span>60 Min</span>
        </div>
      </div>
      <label className="mt-5 flex items-center justify-between gap-3">
        <div>
          <div className="text-sm font-semibold">Erinnerung</div>
          <div className="text-xs text-[color:var(--muted-foreground)]">
            Tägliche Erinnerung aktivieren
          </div>
        </div>
        <Toggle checked={reminder} onChange={setReminder} label="Tägliche Erinnerung" />
      </label>
    </GlassSection>
  );
}

// ============================================================
// Settings (tabbed)
// ============================================================

const SETTINGS_TABS = [
  "Profil",
  "Konto",
  "Lernen",
  "Benachrichtigungen",
  "Datenschutz",
  "Sicherheit",
  "Design",
  "Sprache",
] as const;
type SettingsTab = (typeof SETTINGS_TABS)[number];

function SettingsCard() {
  const [tab, setTab] = useState<SettingsTab>("Profil");
  return (
    <GlassSection title="Einstellungen">
      <div className="border-b border-[color:var(--border)]">
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          {SETTINGS_TABS.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className="relative pb-3 text-sm font-medium transition"
              style={{ color: tab === t ? "var(--foreground)" : "var(--muted-foreground)" }}
            >
              {t}
              {tab === t && (
                <motion.span
                  layoutId="settings-tab-underline"
                  className="absolute inset-x-0 -bottom-px h-[2px] rounded-full bg-[color:var(--accent-foreground)]"
                />
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.25, ease: [0.2, 0.8, 0.2, 1] }}
          >
            {tab === "Profil" && <ProfileTab />}
            {tab === "Konto" && <AccountTab />}
            {tab === "Lernen" && <LearningTab />}
            {tab === "Benachrichtigungen" && <NotificationsTab />}
            {tab === "Datenschutz" && <PrivacyTab />}
            {tab === "Sicherheit" && <SecurityTab />}
            {tab === "Design" && <AppearanceTab />}
            {tab === "Sprache" && <LanguageTab />}
          </motion.div>
        </AnimatePresence>
      </div>
    </GlassSection>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1.5 text-xs font-semibold text-[color:var(--muted-foreground)]">
        {label}
      </div>
      {children}
    </label>
  );
}
function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={
        "w-full rounded-xl border border-[color:var(--border)] bg-[color:var(--card)] px-3.5 py-2.5 text-sm outline-none transition focus:border-[color:var(--accent-foreground)] " +
        (props.className || "")
      }
    />
  );
}
function SelectInput({ children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={
        "w-full rounded-xl border border-[color:var(--border)] bg-[color:var(--card)] px-3.5 py-2.5 text-sm outline-none transition focus:border-[color:var(--accent-foreground)] " +
        (props.className || "")
      }
    >
      {children}
    </select>
  );
}
function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-label={label}
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="relative h-6 w-11 shrink-0 rounded-full transition"
      style={{ background: checked ? "var(--accent-foreground)" : "var(--secondary)" }}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-md"
        style={{ left: checked ? "22px" : "2px" }}
      />
    </button>
  );
}

function ProfileTab() {
  const [profile, setProfile] = useState(DEFAULT_SETTINGS.profile);
  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-[auto_1fr_1fr]">
      <div className="flex flex-col items-start gap-3">
        <div className="text-xs font-semibold text-[color:var(--muted-foreground)]">
          Profilinformationen
        </div>
        <Avatar
          initials={PROFILE_HEADER.avatarInitials}
          gradient={PROFILE_HEADER.avatarGradient}
          size={92}
        />
      </div>
      <div className="space-y-4">
        <Field label="Vollständiger Name">
          <TextInput
            value={profile.fullName}
            onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
          />
        </Field>
        <Field label="E-Mail">
          <TextInput
            type="email"
            value={profile.email}
            onChange={(e) => setProfile({ ...profile, email: e.target.value })}
          />
        </Field>
        <Field label="Benutzername">
          <TextInput
            value={profile.username}
            onChange={(e) => setProfile({ ...profile, username: e.target.value })}
          />
        </Field>
      </div>
      <div className="space-y-4">
        <Field label="Sprache">
          <SelectInput defaultValue="Deutsch">
            {SETTINGS_LANGUAGES.map((l) => (
              <option key={l}>{l}</option>
            ))}
          </SelectInput>
        </Field>
        <Field label="Zeitzone">
          <SelectInput defaultValue={profile.timezone}>
            {TIMEZONES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </SelectInput>
        </Field>
        <Field label="Geburtsdatum">
          <TextInput
            type="date"
            value={profile.birthday}
            onChange={(e) => setProfile({ ...profile, birthday: e.target.value })}
          />
        </Field>
      </div>
    </div>
  );
}

function AccountTab() {
  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      <Field label="Land">
        <TextInput defaultValue={DEFAULT_SETTINGS.profile.country} />
      </Field>
      <Field label="Kontoart">
        <TextInput defaultValue="Premium" disabled />
      </Field>
      <Field label="Mitglied seit">
        <TextInput defaultValue={PROFILE_HEADER.memberSince} disabled />
      </Field>
      <Field label="Verifizierungsstatus">
        <TextInput defaultValue="Verifiziert ✓" disabled />
      </Field>
    </div>
  );
}

function LearningTab() {
  const [l, setL] = useState(DEFAULT_SETTINGS.learning);
  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      <Field label="Lernziel">
        <SelectInput defaultValue={l.cefrGoal}>
          {CEFR_GOALS.map((g) => (
            <option key={g}>{g}</option>
          ))}
        </SelectInput>
      </Field>
      <Field label="Tägliche Lernzeit (Min)">
        <TextInput
          type="number"
          value={l.dailyGoalMinutes}
          onChange={(e) => setL({ ...l, dailyGoalMinutes: Number(e.target.value) })}
        />
      </Field>
      <Field label="Bevorzugte Uhrzeit">
        <TextInput
          type="time"
          value={l.preferredTime}
          onChange={(e) => setL({ ...l, preferredTime: e.target.value })}
        />
      </Field>
      <Field label="Standard-Wörterbuchsprache">
        <SelectInput defaultValue={l.dictionaryLanguage}>
          {SETTINGS_LANGUAGES.map((x) => (
            <option key={x}>{x}</option>
          ))}
        </SelectInput>
      </Field>
      <Field label="Leitner: Reviews pro Sitzung">
        <TextInput
          type="number"
          value={l.leitnerReviewLimit}
          onChange={(e) => setL({ ...l, leitnerReviewLimit: Number(e.target.value) })}
        />
      </Field>
      <div className="space-y-3 pt-6">
        <ToggleRow
          label="Automatische Aussprache"
          desc="Nach dem Öffnen einer Karte"
          checked={l.autoPronunciation}
          onChange={(v) => setL({ ...l, autoPronunciation: v })}
        />
        <ToggleRow
          label="Automatische Übersetzung"
          desc="Übersetzung sofort anzeigen"
          checked={l.autoTranslation}
          onChange={(v) => setL({ ...l, autoTranslation: v })}
        />
        <ToggleRow
          label="IPA auf Flashcards"
          desc="Lautschrift auf Karten zeigen"
          checked={l.flashcardShowIPA}
          onChange={(v) => setL({ ...l, flashcardShowIPA: v })}
        />
        <ToggleRow
          label="Auto-Umdrehen"
          desc="Karten automatisch umdrehen"
          checked={l.flashcardAutoFlip}
          onChange={(v) => setL({ ...l, flashcardAutoFlip: v })}
        />
      </div>
    </div>
  );
}

function NotificationsTab() {
  const [n, setN] = useState(DEFAULT_SETTINGS.notifications);
  const rows: Array<[keyof typeof n, string, string]> = [
    ["dailyReminder", "Tägliche Erinnerung", "Erinnerung an dein Tagesziel"],
    ["leitnerReminder", "Leitner-Erinnerung", "Wenn Karten fällig sind"],
    ["eventReminder", "Event-Erinnerung", "Vor deinen registrierten Events"],
    ["podcastReminder", "Podcast-Erinnerung", "Neue Folgen für dein Niveau"],
    ["grammarReminder", "Grammatik-Erinnerung", "Nächste empfohlene Lektion"],
    ["email", "E-Mail Benachrichtigungen", "Zusammenfassungen per E-Mail"],
    ["push", "Push Benachrichtigungen", "Auf diesem Gerät"],
  ];
  return (
    <div className="space-y-3">
      {rows.map(([k, label, desc]) => (
        <ToggleRow
          key={k}
          label={label}
          desc={desc}
          checked={n[k]}
          onChange={(v) => setN({ ...n, [k]: v })}
        />
      ))}
    </div>
  );
}

function ToggleRow({
  label,
  desc,
  checked,
  onChange,
}: {
  label: string;
  desc: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl bg-[color:var(--card)] px-4 py-3">
      <div className="min-w-0">
        <div className="text-sm font-semibold">{label}</div>
        <div className="text-xs text-[color:var(--muted-foreground)]">{desc}</div>
      </div>
      <Toggle checked={checked} onChange={onChange} label={label} />
    </div>
  );
}

function PrivacyTab() {
  return (
    <div className="space-y-3">
      <ActionRow
        label="Persönliche Daten exportieren"
        desc="Alle deine Lern- und Profildaten als JSON herunterladen"
        cta="Exportieren"
      />
      <ActionRow label="Profil-Sichtbarkeit" desc="Wer kann dein Profil sehen?" cta="Öffentlich" />
      <ActionRow
        label="Konto löschen"
        desc="Alle Daten werden dauerhaft gelöscht"
        cta="Löschen"
        tone="danger"
      />
    </div>
  );
}

function SecurityTab() {
  const [twoFa, setTwoFa] = useState(false);
  return (
    <div className="space-y-3">
      <ActionRow
        label="Passwort ändern"
        desc="Aktualisiere dein Passwort regelmäßig"
        cta="Ändern"
      />
      <div className="flex items-center justify-between gap-3 rounded-2xl bg-[color:var(--card)] px-4 py-3">
        <div className="min-w-0">
          <div className="text-sm font-semibold">Zwei-Faktor-Authentifizierung</div>
          <div className="text-xs text-[color:var(--muted-foreground)]">
            Zusätzliche Sicherheitsebene aktivieren
          </div>
        </div>
        <Toggle checked={twoFa} onChange={setTwoFa} label="Zwei-Faktor-Authentifizierung" />
      </div>
      <ActionRow label="Aktive Sitzungen" desc="3 aktive Geräte" cta="Verwalten" />
      <ActionRow label="Anmeldeverlauf" desc="Letzte 30 Anmeldungen anzeigen" cta="Anzeigen" />
    </div>
  );
}

function ActionRow({
  label,
  desc,
  cta,
  tone = "default",
}: {
  label: string;
  desc: string;
  cta: string;
  tone?: "default" | "danger";
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl bg-[color:var(--card)] px-4 py-3">
      <div className="min-w-0">
        <div className="text-sm font-semibold">{label}</div>
        <div className="text-xs text-[color:var(--muted-foreground)]">{desc}</div>
      </div>
      <button
        type="button"
        className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${tone === "danger" ? "bg-[#DD2222] text-white hover:opacity-90" : "bg-[color:var(--secondary)] hover:opacity-80"}`}
      >
        {cta}
      </button>
    </div>
  );
}

function AppearanceTab() {
  const { theme, setTheme } = useTheme();
  const options: Array<{ id: "light" | "dark" | "system"; label: string; preview: string }> = [
    { id: "light", label: "Hell", preview: "linear-gradient(135deg,#ffffff,#f4f4f6)" },
    { id: "dark", label: "Dunkel", preview: "linear-gradient(135deg,#0B0C0F,#22262C)" },
    { id: "system", label: "System", preview: "linear-gradient(135deg,#ffffff 50%,#0B0C0F 50%)" },
  ];
  return (
    <div>
      <div className="grid grid-cols-3 gap-3">
        {options.map((o) => (
          <button
            key={o.id}
            type="button"
            onClick={() => setTheme(o.id)}
            className={`overflow-hidden rounded-2xl border-2 p-1.5 text-left transition ${theme === o.id ? "border-[color:var(--accent-foreground)]" : "border-[color:var(--border)]"}`}
          >
            <div className="h-20 w-full rounded-xl" style={{ background: o.preview }} />
            <div className="mt-2 px-2 pb-1 text-sm font-semibold">{o.label}</div>
          </button>
        ))}
      </div>
      <p className="mt-4 text-xs text-[color:var(--muted-foreground)]">
        Akzentfarben folgen automatisch dem DEUSI-Design.
      </p>
    </div>
  );
}

function LanguageTab() {
  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      <Field label="App-Sprache">
        <SelectInput defaultValue="Deutsch">
          {SETTINGS_LANGUAGES.map((l) => (
            <option key={l}>{l}</option>
          ))}
        </SelectInput>
      </Field>
      <Field label="Lernsprache">
        <SelectInput defaultValue="Deutsch">
          <option>Deutsch</option>
        </SelectInput>
      </Field>
    </div>
  );
}

// ============================================================
// Small icons used across the page
// ============================================================

function PenIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
    </svg>
  );
}
function ShareIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="6" r="3" />
      <circle cx="18" cy="18" r="3" />
      <path d="M8.6 10.5l6.8-3M8.6 13.5l6.8 3" />
    </svg>
  );
}
function DownloadIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3v13" />
      <path d="M6 12l6 6 6-6" />
      <path d="M4 21h16" />
    </svg>
  );
}
function CalendarLine() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </svg>
  );
}
function FireLine() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3s5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 1-3s-1 4 2 4a2 2 0 0 0 2-2c0-3-4-4 0-9z" />
    </svg>
  );
}
function HeartLine() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6C19 16.5 12 21 12 21z" />
    </svg>
  );
}
function TrophyIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="20"
      height="20"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M8 4h8v4a4 4 0 0 1-8 0V4z" />
      <path d="M8 6H4v2a4 4 0 0 0 4 4M16 6h4v2a4 4 0 0 1-4 4" />
      <path d="M12 12v4" />
      <path d="M9 20h6" />
    </svg>
  );
}
