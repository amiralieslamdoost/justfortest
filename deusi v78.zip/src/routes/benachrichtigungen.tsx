import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bell,
  BellRing,
  Check,
  CheckCheck,
  Trash2,
  Settings2,
  Sparkles,
  MessageCircle,
  Trophy,
  BookOpen,
  Users,
  AlertCircle,
  Flame,
  Undo2,
  ArrowRight,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";

export const Route = createFileRoute("/benachrichtigungen")({
  head: () => ({
    meta: [
      { title: "Benachrichtigungen · DEUSI" },
      { name: "description", content: "Alle deine Erinnerungen, Missionen und Community-Updates." },
      { property: "og:title", content: "Benachrichtigungen · DEUSI" },
      {
        property: "og:description",
        content: "Erinnerungen, Erfolge und Community-Updates an einem Ort.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NotificationsPage,
});

type NType = "reminder" | "achievement" | "social" | "system" | "content";
type Bucket = "today" | "yesterday" | "earlier";

type Notif = {
  id: string;
  type: NType;
  title: string;
  fa: string;
  desc: string;
  time: string;
  bucket: Bucket;
  read: boolean;
  to?: string;
  cta?: string;
};

const MOCK: Notif[] = [
  {
    id: "n1",
    type: "reminder",
    title: "Zeit für deine tägliche Runde",
    fa: "زمان مرور روزانه فرا رسیده",
    desc: "12 Karten in deiner Leitner-Box warten auf dich.",
    time: "vor 12 Min.",
    bucket: "today",
    read: false,
    to: "/leitner",
    cta: "Jetzt wiederholen",
  },
  {
    id: "n2",
    type: "achievement",
    title: "Neue Errungenschaft: 7-Tage-Streak",
    fa: "دستاورد تازه: ۷ روز پیوسته",
    desc: "Weiter so — du bist auf dem besten Weg!",
    time: "vor 2 Std.",
    bucket: "today",
    read: false,
    to: "/achievements",
    cta: "Ansehen",
  },
  {
    id: "n3",
    type: "social",
    title: "Anna hat dich zum Sprachcafé eingeladen",
    fa: "آنا تو رو به کافه گفتگو دعوت کرد",
    desc: "Samstag 18:00 · Kreuzberg, Berlin",
    time: "vor 5 Std.",
    bucket: "today",
    read: false,
    to: "/community",
    cta: "Einladung öffnen",
  },
  {
    id: "n4",
    type: "content",
    title: "Neuer Podcast: Deutsch im Alltag #42",
    fa: "پادکست تازه منتشر شد",
    desc: "22 Min. · Niveau B1 · mit Transkript",
    time: "gestern",
    bucket: "yesterday",
    read: true,
    to: "/podcasts",
    cta: "Anhören",
  },
  {
    id: "n5",
    type: "system",
    title: "Neue Version von DEUSI verfügbar",
    fa: "نسخه جدید در دسترس است",
    desc: "Version 4.6 bringt schnelleren Fokus-Modus.",
    time: "gestern",
    bucket: "yesterday",
    read: true,
  },
  {
    id: "n6",
    type: "achievement",
    title: "Grammatik-Meilenstein: 50 Übungen",
    fa: "۵۰ تمرین گرامر تکمیل شد",
    desc: "Du hast diese Woche mehr geübt als 78% der Nutzer.",
    time: "2 Tage",
    bucket: "earlier",
    read: true,
    to: "/grammatik",
    cta: "Weiter üben",
  },
  {
    id: "n7",
    type: "reminder",
    title: "Prüfungstermin in 14 Tagen",
    fa: "۱۴ روز تا آزمون Goethe B2",
    desc: "Simuliere die Prüfung, um bereit zu sein.",
    time: "3 Tage",
    bucket: "earlier",
    read: true,
    to: "/pruefungen",
    cta: "Simulation starten",
  },
];

const FILTERS: { key: "all" | NType | "unread"; label: string; Icon: typeof Bell }[] = [
  { key: "all", label: "Alle", Icon: Bell },
  { key: "unread", label: "Ungelesen", Icon: BellRing },
  { key: "reminder", label: "Erinnerungen", Icon: Flame },
  { key: "achievement", label: "Erfolge", Icon: Trophy },
  { key: "social", label: "Community", Icon: Users },
  { key: "content", label: "Inhalte", Icon: BookOpen },
  { key: "system", label: "System", Icon: Settings2 },
];

const TYPE_META: Record<NType, { Icon: typeof Bell; color: string; bg: string; label: string }> = {
  reminder: { Icon: Flame, color: "#DD2222", bg: "#ffe6e6", label: "Erinnerung" },
  achievement: { Icon: Trophy, color: "#c48412", bg: "#fff2d1", label: "Erfolg" },
  social: { Icon: MessageCircle, color: "#0e7c5a", bg: "#d7f5e6", label: "Community" },
  content: { Icon: Sparkles, color: "#1552c8", bg: "#dbe6ff", label: "Neuer Inhalt" },
  system: { Icon: AlertCircle, color: "#3a3f4d", bg: "#e8eaef", label: "System" },
};

const BUCKETS: { key: Bucket; label: string; fa: string }[] = [
  { key: "today", label: "Heute", fa: "امروز" },
  { key: "yesterday", label: "Gestern", fa: "دیروز" },
  { key: "earlier", label: "Früher", fa: "پیش‌تر" },
];

function NotificationsPage() {
  const [items, setItems] = useState(MOCK);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["key"]>("all");
  const [lastDeleted, setLastDeleted] = useState<{ item: Notif; index: number } | null>(null);

  const visible = useMemo(() => {
    if (filter === "all") return items;
    if (filter === "unread") return items.filter((i) => !i.read);
    return items.filter((i) => i.type === filter);
  }, [items, filter]);

  const unread = items.filter((i) => !i.read).length;
  const grouped = BUCKETS.map((b) => ({
    ...b,
    list: visible.filter((i) => i.bucket === b.key),
  })).filter((g) => g.list.length > 0);

  const markRead = (id: string, read: boolean) =>
    setItems((s) => s.map((i) => (i.id === id ? { ...i, read } : i)));

  const removeItem = (id: string) =>
    setItems((s) => {
      const index = s.findIndex((i) => i.id === id);
      if (index >= 0) setLastDeleted({ item: s[index]!, index });
      return s.filter((i) => i.id !== id);
    });

  const undoDelete = () => {
    if (!lastDeleted) return;
    setItems((s) => {
      const next = [...s];
      next.splice(lastDeleted.index, 0, lastDeleted.item);
      return next;
    });
    setLastDeleted(null);
  };

  return (
    <div className="space-y-5 pb-10 animate-fade">
      <NotificationsHero
        unread={unread}
        total={items.length}
        onMarkAll={() => setItems((s) => s.map((i) => ({ ...i, read: true })))}
      />

      {/* Filters — wrapping, never horizontally scrollable */}
      <div className="flex flex-wrap items-center gap-1.5">
        {FILTERS.map((f) => {
          const active = filter === f.key;
          const count =
            f.key === "all"
              ? items.length
              : f.key === "unread"
                ? unread
                : items.filter((i) => i.type === f.key).length;
          return (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`inline-flex min-w-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-semibold transition sm:text-xs ${
                active
                  ? "bg-foreground text-background shadow"
                  : "border border-border bg-background/60 text-foreground/70 hover:border-foreground/30"
              }`}
            >
              <f.Icon className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{f.label}</span>
              <span
                className={`shrink-0 rounded-full px-1.5 text-[10px] font-bold ${
                  active ? "bg-background/20" : "bg-muted text-muted-foreground"
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      <AnimatePresence>
        {lastDeleted && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-card p-3 text-xs"
          >
            <span className="min-w-0 truncate font-semibold">
              „{lastDeleted.item.title}" gelöscht
            </span>
            <button
              onClick={undoDelete}
              className="ms-auto inline-flex items-center gap-1 rounded-xl bg-foreground px-3 py-1.5 font-bold text-background"
            >
              <Undo2 className="h-3.5 w-3.5" /> Rückgängig
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {visible.length === 0 ? (
        <div className="grid place-items-center gap-2 rounded-[28px] border-2 border-dashed border-border/60 bg-muted/25 py-16 text-center">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-foreground/5">
            <Check className="h-6 w-6 text-foreground/60" />
          </div>
          <div className="text-sm font-semibold">Nichts Neues hier.</div>
          <FaHint>خبری نیست — همه‌چی مرتبه</FaHint>
        </div>
      ) : (
        <div className="space-y-6">
          {grouped.map((g) => (
            <section key={g.key} className="space-y-2.5">
              <div className="flex items-center gap-2">
                <h2 className="text-xs font-black uppercase tracking-widest text-muted-foreground">
                  {g.label}
                </h2>
                <span dir="rtl" className="fa-inline text-[11px] text-muted-foreground/70">
                  {g.fa}
                </span>
                <span className="h-px flex-1 bg-border" />
                <span className="text-[11px] font-semibold text-muted-foreground">
                  {g.list.length}
                </span>
              </div>

              <div className="space-y-2">
                <AnimatePresence initial={false}>
                  {g.list.map((n) => {
                    const meta = TYPE_META[n.type];
                    return (
                      <motion.article
                        key={n.id}
                        layout
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -16, height: 0, marginTop: 0 }}
                        transition={{ duration: 0.2 }}
                        className={`group relative overflow-hidden rounded-2xl border p-3 transition sm:p-4 ${
                          n.read
                            ? "border-border bg-card/60"
                            : "border-transparent bg-card shadow-sm ring-1 ring-foreground/10"
                        }`}
                      >
                        <span
                          aria-hidden
                          className="absolute inset-y-0 left-0 w-1"
                          style={{ backgroundColor: n.read ? "transparent" : meta.color }}
                        />
                        <div className="grid grid-cols-[auto_minmax(0,1fr)] gap-3 pl-1.5">
                          <span
                            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl"
                            style={{ backgroundColor: meta.bg, color: meta.color }}
                          >
                            <meta.Icon className="h-5 w-5" />
                          </span>

                          <div className="min-w-0">
                            <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1">
                              <span
                                className="rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-wider"
                                style={{ backgroundColor: meta.bg, color: meta.color }}
                              >
                                {meta.label}
                              </span>
                              {!n.read && (
                                <span className="inline-flex items-center gap-1 rounded-full bg-foreground/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider">
                                  <span className="h-1.5 w-1.5 rounded-full bg-foreground" /> Neu
                                </span>
                              )}
                              <span className="ms-auto shrink-0 text-[11px] text-muted-foreground">
                                {n.time}
                              </span>
                            </div>

                            <h3
                              className={`mt-1.5 break-words text-sm leading-snug ${
                                n.read ? "font-medium text-foreground/80" : "font-bold"
                              }`}
                            >
                              {n.title}
                            </h3>
                            <FaHint>{n.fa}</FaHint>
                            <p className="mt-1 break-words text-xs text-muted-foreground">
                              {n.desc}
                            </p>

                            <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                              {n.to && (
                                <Link
                                  to={n.to}
                                  className="inline-flex items-center gap-1 rounded-xl bg-foreground px-3 py-1.5 text-[11px] font-bold text-background transition hover:opacity-90"
                                >
                                  {n.cta ?? "Öffnen"} <ArrowRight className="h-3 w-3" />
                                </Link>
                              )}
                              <button
                                onClick={() => markRead(n.id, !n.read)}
                                className="inline-flex items-center gap-1 rounded-xl border border-border bg-background px-3 py-1.5 text-[11px] font-semibold text-foreground/70 transition hover:text-foreground"
                              >
                                <Check className="h-3.5 w-3.5" />
                                {n.read ? "Ungelesen" : "Gelesen"}
                              </button>
                              <button
                                onClick={() => removeItem(n.id)}
                                className="ms-auto inline-flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-[11px] font-semibold text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                <span className="hidden sm:inline">Löschen</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </motion.article>
                    );
                  })}
                </AnimatePresence>
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

function NotificationsHero({
  unread,
  total,
  onMarkAll,
}: {
  unread: number;
  total: number;
  onMarkAll: () => void;
}) {
  return (
    <header
      className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
      style={{
        backgroundImage: "linear-gradient(135deg, #3a1080 0%, #7c3bff 55%, #c084fc 130%)",
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full bg-[#c084fc]/40 blur-3xl" />
      </div>

      <div className="relative space-y-4">
        <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 sm:gap-4">
          <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/95 text-[#7c3bff] shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16">
            <BellRing className="h-8 w-8" />
          </div>
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
              Benachrichtigungen
            </div>
            <h1 className="mt-2 text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
              {unread} neue Nachrichten
            </h1>
            <FaHint className="!text-white/85">پیام‌های تازه‌ی تو</FaHint>
          </div>
        </div>

        <p className="max-w-2xl text-sm text-white/80">
          Erinnerungen, Erfolge und Neuigkeiten — alles an einem Ort.
        </p>

        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <HeroStat value={unread} label="Ungelesen" />
          <HeroStat value={total - unread} label="Gelesen" />
          <HeroStat value={total} label="Gesamt" />
          <div className="col-span-2 grid grid-cols-2 gap-2 sm:col-span-1 sm:grid-cols-1">
            <button
              onClick={onMarkAll}
              className="inline-flex min-w-0 items-center justify-center gap-1.5 rounded-xl bg-white/95 px-2.5 py-2.5 text-xs font-bold text-[#3a1080] shadow transition hover:bg-white sm:text-[11px]"
            >
              <CheckCheck className="h-4 w-4 shrink-0" />
              <span className="truncate">Alle gelesen</span>
            </button>
            <Link
              to="/einstellungen"
              className="inline-flex min-w-0 items-center justify-center gap-1.5 rounded-xl bg-white/15 px-2.5 py-2.5 text-xs font-bold ring-1 ring-inset ring-white/25 backdrop-blur transition hover:bg-white/25 sm:text-[11px]"
            >
              <Settings2 className="h-4 w-4 shrink-0" />
              <span className="truncate">Einstellungen</span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}

function HeroStat({ value, label }: { value: number; label: string }) {
  return (
    <div className="min-w-0 rounded-xl bg-white/10 px-3 py-2 ring-1 ring-inset ring-white/20 backdrop-blur">
      <div className="text-xl font-black leading-none">{value}</div>
      <div className="mt-1 truncate text-[10px] font-semibold uppercase tracking-wider text-white/75">
        {label}
      </div>
    </div>
  );
}
