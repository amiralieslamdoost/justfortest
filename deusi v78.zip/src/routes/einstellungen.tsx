import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { useTheme } from "@/lib/deusi/theme";
import { motion, AnimatePresence } from "framer-motion";
import {
  Settings2,
  User,
  Bell,
  Shield,
  Palette,
  Languages,
  KeyRound,
  Trash2,
  Download,
  LogOut,
  Check,
  Moon,
  Sun,
  Monitor,
  Mail,
  Smartphone,
  Globe,
  ChevronRight,
  Sparkles,
  Search,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { SearchField } from "@/components/deusi/SearchField";

export const Route = createFileRoute("/einstellungen")({
  head: () => ({
    meta: [
      { title: "Einstellungen · DEUSI" },
      {
        name: "description",
        content: "Verwalte dein Konto, Benachrichtigungen, Datenschutz und Erscheinungsbild.",
      },
    ],
  }),
  component: SettingsPage,
});

type TabKey =
  "konto" | "benachrichtigungen" | "datenschutz" | "erscheinung" | "sprache" | "sicherheit";

const TABS: { key: TabKey; label: string; fa: string; desc: string; Icon: typeof User }[] = [
  {
    key: "konto",
    label: "Konto",
    fa: "حساب کاربری",
    desc: "Profildaten & Konto-Aktionen",
    Icon: User,
  },
  {
    key: "benachrichtigungen",
    label: "Benachrichtigungen",
    fa: "اعلان‌ها",
    desc: "Erinnerungen, E-Mail & Push",
    Icon: Bell,
  },
  {
    key: "datenschutz",
    label: "Datenschutz",
    fa: "حریم خصوصی",
    desc: "Sichtbarkeit & geteilte Daten",
    Icon: Shield,
  },
  {
    key: "erscheinung",
    label: "Erscheinungsbild",
    fa: "ظاهر",
    desc: "Farbmodus, Dichte & Animationen",
    Icon: Palette,
  },
  {
    key: "sprache",
    label: "Sprache & Region",
    fa: "زبان و منطقه",
    desc: "Oberfläche, Zeitzone & CEFR-Ziel",
    Icon: Languages,
  },
  {
    key: "sicherheit",
    label: "Sicherheit",
    fa: "امنیت",
    desc: "Passwort, 2FA & Sitzungen",
    Icon: KeyRound,
  },
];

function SettingsPage() {
  const [tab, setTab] = useState<TabKey>("konto");
  const [dirty, setDirty] = useState(false);
  const [q, setQ] = useState("");
  const activeTab = TABS.find((t) => t.key === tab)!;
  const filtered = q.trim()
    ? TABS.filter((t) => (t.label + t.desc + t.fa).toLowerCase().includes(q.trim().toLowerCase()))
    : TABS;

  return (
    <div className="space-y-6 pb-10 animate-fade">
      <MiniHero
        Icon={Settings2}
        label="Einstellungen"
        title="Alles nach deinem Geschmack"
        highlight="Geschmack"
        fa="همه‌چیز طبق سلیقه‌ی تو"
        desc="Konto, Benachrichtigungen, Datenschutz und Erscheinung — an einem Ort."
        descFa="حساب، اعلان‌ها، حریم خصوصی و ظاهر — همه در یک صفحه."
        base="#1a1d24"
        primary="#3a3f4d"
        accent="#8b93a6"
      />

      {/* Mobile: horizontally scrollable segmented tabs */}
      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 lg:hidden [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {TABS.map((t) => {
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`inline-flex shrink-0 items-center gap-2 rounded-full px-3.5 py-2 text-xs font-bold transition ${
                active
                  ? "bg-foreground text-background shadow-sm"
                  : "border border-border bg-background/50 text-foreground/70"
              }`}
            >
              <t.Icon className="h-3.5 w-3.5" />
              {t.label}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[268px_minmax(0,1fr)]">
        <nav className="glass-strong sticky top-5 hidden h-fit rounded-[24px] p-2.5 lg:block">
          <SearchField
            value={q}
            onValueChange={setQ}
            size="sm"
            placeholder="Einstellung suchen…"
            className="mb-2"
          />

          {filtered.map((t) => {
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className="group relative flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition"
              >
                {active && (
                  <motion.span
                    layoutId="settings-active"
                    transition={{ type: "spring", stiffness: 520, damping: 40 }}
                    className="absolute inset-0 rounded-2xl bg-foreground shadow-sm"
                  />
                )}
                <span
                  className={`relative grid h-8 w-8 shrink-0 place-items-center rounded-xl transition ${active ? "bg-background/15 text-background" : "bg-foreground/5 text-foreground/70 group-hover:text-foreground"}`}
                >
                  <t.Icon className="h-4 w-4" />
                </span>
                <span className="relative min-w-0 flex-1">
                  <span
                    className={`block truncate text-sm font-semibold ${active ? "text-background" : "text-foreground/80 group-hover:text-foreground"}`}
                  >
                    {t.label}
                  </span>
                  <span
                    className={`block truncate text-[10px] ${active ? "text-background/70" : "text-muted-foreground"}`}
                  >
                    {t.desc}
                  </span>
                </span>
                <ChevronRight
                  className={`relative h-3.5 w-3.5 transition ${active ? "text-background opacity-100" : "opacity-0 group-hover:opacity-40"}`}
                />
              </button>
            );
          })}
          {filtered.length === 0 && (
            <div className="px-3 py-6 text-center text-xs text-muted-foreground">
              Nichts gefunden
            </div>
          )}
        </nav>

        <div className="min-w-0" onChangeCapture={() => setDirty(true)}>
          <header className="mb-4 flex items-center gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-foreground/5">
              <activeTab.Icon className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h2 className="truncate text-lg font-black tracking-tight">{activeTab.label}</h2>
              <FaHint>{activeTab.fa}</FaHint>
            </div>
          </header>
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              {tab === "konto" && <AccountPanel />}
              {tab === "benachrichtigungen" && <NotifPanel />}
              {tab === "datenschutz" && <PrivacyPanel />}
              {tab === "erscheinung" && <AppearancePanel />}
              {tab === "sprache" && <LanguagePanel />}
              {tab === "sicherheit" && <SecurityPanel />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Sticky save bar — appears as soon as something changes */}
      <AnimatePresence>
        {dirty && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            transition={{ type: "spring", stiffness: 420, damping: 36 }}
            className="glass-strong fixed inset-x-3 bottom-20 z-40 flex items-center justify-between gap-3 rounded-2xl px-4 py-3 shadow-xl lg:inset-x-auto lg:right-8 lg:bottom-8 lg:w-[420px]"
          >
            <div className="min-w-0">
              <div className="text-sm font-bold">Ungespeicherte Änderungen</div>
              <FaHint>تغییرات ذخیره‌نشده</FaHint>
            </div>
            <div className="flex shrink-0 gap-2">
              <GhostBtn onClick={() => setDirty(false)}>Verwerfen</GhostBtn>
              <PrimaryBtn onClick={() => setDirty(false)}>
                <Check className="h-4 w-4" /> Speichern
              </PrimaryBtn>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ---------- Panels ----------

function AccountPanel() {
  return (
    <>
      <Panel title="Profildaten" fa="اطلاعات پروفایل">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Anzeigename">
            <Input defaultValue="Max Mustermann" />
          </Field>
          <Field label="Benutzername">
            <Input defaultValue="max.mustermann" />
          </Field>
          <Field label="E-Mail">
            <Input type="email" defaultValue="max@deusi.app" />
          </Field>
          <Field label="Telefonnummer">
            <Input type="tel" placeholder="+49 …" />
          </Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <GhostBtn>Abbrechen</GhostBtn>
          <PrimaryBtn>
            <Check className="h-4 w-4" /> Speichern
          </PrimaryBtn>
        </div>
      </Panel>

      <Panel title="Konto-Aktionen" fa="اقدامات حساب" tone="warn">
        <div className="space-y-3">
          <Row
            Icon={Download}
            title="Daten exportieren"
            fa="دریافت خروجی از داده‌ها"
            desc="Lade eine Kopie deiner Lerndaten als JSON."
          >
            <GhostBtn>Exportieren</GhostBtn>
          </Row>
          <Row
            Icon={LogOut}
            title="Von allen Geräten abmelden"
            fa="خروج از همه دستگاه‌ها"
            desc="Beendet alle aktiven Sitzungen."
          >
            <GhostBtn>Abmelden</GhostBtn>
          </Row>
          <Row
            Icon={Trash2}
            title="Konto löschen"
            fa="حذف حساب"
            desc="Unwiderruflich. Alle Daten werden entfernt."
            tone="danger"
          >
            <DangerBtn>Konto löschen</DangerBtn>
          </Row>
        </div>
      </Panel>
    </>
  );
}

function NotifPanel() {
  return (
    <Panel title="Benachrichtigungen" fa="اعلان‌ها">
      <div className="space-y-3">
        <ToggleRow
          Icon={Bell}
          title="Tägliche Lernerinnerung"
          fa="یادآوری روزانه مطالعه"
          defaultChecked
        />
        <ToggleRow
          Icon={Mail}
          title="Wöchentliche Zusammenfassung per E-Mail"
          fa="خلاصه هفتگی از طریق ایمیل"
          defaultChecked
        />
        <ToggleRow
          Icon={Smartphone}
          title="Push auf mobilen Geräten"
          fa="اعلان روی موبایل"
          defaultChecked
        />
        <ToggleRow
          Icon={Sparkles}
          title="Neue Missionen & Erfolge"
          fa="مأموریت‌ها و دستاوردهای جدید"
          defaultChecked
        />
        <ToggleRow
          Icon={Globe}
          title="Community-Events in deiner Nähe"
          fa="رویدادها در نزدیکی تو"
        />
      </div>

      <div className="mt-6 rounded-2xl border border-border bg-background/40 p-4">
        <div className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
          Ruhezeiten
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Von">
            <Input type="time" defaultValue="22:00" />
          </Field>
          <Field label="Bis">
            <Input type="time" defaultValue="07:00" />
          </Field>
        </div>
      </div>
    </Panel>
  );
}

function PrivacyPanel() {
  return (
    <Panel title="Datenschutz" fa="حریم خصوصی">
      <div className="space-y-3">
        <ToggleRow title="Profil öffentlich zeigen" fa="نمایش عمومی پروفایل" defaultChecked />
        <ToggleRow title="In Leaderboards erscheinen" fa="نمایش در جدول امتیازات" defaultChecked />
        <ToggleRow
          title="Anonyme Nutzungsstatistiken teilen"
          fa="ارسال آمار ناشناس"
          defaultChecked
        />
        <ToggleRow
          title="Personalisierte Empfehlungen"
          fa="پیشنهادهای شخصی‌سازی‌شده"
          defaultChecked
        />
        <ToggleRow title="Kontaktbar per E-Mail" fa="تماس از طریق ایمیل" />
      </div>
      <div className="mt-6 flex flex-wrap gap-2 text-xs">
        <Link
          to="/datenschutz"
          className="rounded-full border border-border px-3 py-1.5 font-semibold text-foreground/80 hover:bg-foreground/5"
        >
          Datenschutzerklärung ansehen
        </Link>
        <Link
          to="/agb"
          className="rounded-full border border-border px-3 py-1.5 font-semibold text-foreground/80 hover:bg-foreground/5"
        >
          AGB ansehen
        </Link>
      </div>
    </Panel>
  );
}

function AppearancePanel() {
  const { theme: activeTheme, setTheme: applyTheme } = useTheme();
  const [theme, setThemeChoice] = useState<"system" | "light" | "dark">("system");
  const setTheme = (t: "system" | "light" | "dark") => {
    setThemeChoice(t);
    applyTheme(t);
  };
  useEffect(() => {
    setThemeChoice((prev) => (prev === "system" ? prev : activeTheme));
  }, [activeTheme]);
  const [density, setDensity] = useState<"comfort" | "compact">("comfort");
  const [motionReduce, setMotion] = useState(false);
  return (
    <Panel title="Erscheinungsbild" fa="ظاهر">
      <div className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        Farbmodus
      </div>
      <div className="grid gap-2 sm:grid-cols-3">
        {[
          { key: "system", label: "System", Icon: Monitor },
          { key: "light", label: "Hell", Icon: Sun },
          { key: "dark", label: "Dunkel", Icon: Moon },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTheme(t.key as typeof theme)}
            className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
              theme === t.key
                ? "border-foreground bg-foreground/5"
                : "border-border hover:border-foreground/30"
            }`}
          >
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-foreground/5">
              <t.Icon className="h-5 w-5" />
            </span>
            <span className="text-sm font-semibold">{t.label}</span>
            {theme === t.key && <Check className="ml-auto h-4 w-4" />}
          </button>
        ))}
      </div>

      <div className="mt-6 mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        Dichte
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {[
          { key: "comfort", label: "Komfortabel", fa: "راحت" },
          { key: "compact", label: "Kompakt", fa: "فشرده" },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setDensity(t.key as typeof density)}
            className={`rounded-2xl border p-4 text-left transition ${
              density === t.key
                ? "border-foreground bg-foreground/5"
                : "border-border hover:border-foreground/30"
            }`}
          >
            <div className="text-sm font-semibold">{t.label}</div>
            <FaHint>{t.fa}</FaHint>
          </button>
        ))}
      </div>

      <div className="mt-6">
        <ToggleRow
          title="Animationen reduzieren"
          fa="کاهش انیمیشن‌ها"
          checked={motionReduce}
          onChange={setMotion}
        />
      </div>
    </Panel>
  );
}

function LanguagePanel() {
  return (
    <Panel title="Sprache & Region" fa="زبان و منطقه">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Oberflächensprache">
          <Select defaultValue="de">
            <option value="de">Deutsch</option>
            <option value="fa">فارسی</option>
            <option value="en">English</option>
          </Select>
        </Field>
        <Field label="Muttersprache">
          <Select defaultValue="fa">
            <option value="fa">Persisch (فارسی)</option>
            <option value="tr">Türkçe</option>
            <option value="ar">العربية</option>
            <option value="en">English</option>
          </Select>
        </Field>
        <Field label="Zeitzone">
          <Select defaultValue="Europe/Berlin">
            <option>Europe/Berlin</option>
            <option>Asia/Tehran</option>
            <option>Europe/Vienna</option>
            <option>Europe/Zurich</option>
          </Select>
        </Field>
        <Field label="CEFR-Ziel">
          <Select defaultValue="B2">
            {["A1", "A2", "B1", "B2", "C1", "C2"].map((l) => (
              <option key={l}>{l}</option>
            ))}
          </Select>
        </Field>
      </div>
    </Panel>
  );
}

function SecurityPanel() {
  return (
    <>
      <Panel title="Passwort ändern" fa="تغییر رمز عبور">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Aktuelles Passwort">
            <Input type="password" />
          </Field>
          <div />
          <Field label="Neues Passwort">
            <Input type="password" />
          </Field>
          <Field label="Neues Passwort bestätigen">
            <Input type="password" />
          </Field>
        </div>
        <div className="mt-4 flex justify-between">
          <Link
            to="/passwort-vergessen"
            className="text-xs font-semibold text-muted-foreground hover:text-foreground"
          >
            Passwort vergessen?
          </Link>
          <PrimaryBtn>
            <Check className="h-4 w-4" /> Aktualisieren
          </PrimaryBtn>
        </div>
      </Panel>

      <Panel title="Zwei-Faktor-Authentifizierung" fa="احراز هویت دومرحله‌ای">
        <ToggleRow
          Icon={Shield}
          title="2FA aktivieren"
          fa="فعال‌سازی احراز دو مرحله‌ای"
          desc="Zusätzlicher Code beim Anmelden."
        />
      </Panel>

      <Panel title="Aktive Sitzungen" fa="نشست‌های فعال">
        <div className="space-y-2">
          {[
            { d: "MacBook Pro · Chrome", loc: "Berlin, DE", now: true },
            { d: "iPhone 15 · DEUSI App", loc: "Berlin, DE", now: false },
            { d: "iPad · Safari", loc: "München, DE", now: false },
          ].map((s, i) => (
            <div
              key={i}
              className="flex items-center justify-between rounded-xl border border-border bg-background/40 p-3"
            >
              <div>
                <div className="text-sm font-semibold">{s.d}</div>
                <div className="text-xs text-muted-foreground">
                  {s.loc} {s.now && "· Diese Sitzung"}
                </div>
              </div>
              {!s.now && <GhostBtn>Beenden</GhostBtn>}
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}

// ---------- Primitives ----------

function MiniHero(props: {
  Icon: typeof Settings2;
  label: string;
  title: string;
  highlight?: string;
  fa: string;
  desc: string;
  descFa: string;
  base: string;
  primary: string;
  accent: string;
}) {
  const { Icon, label, title, highlight, fa, desc, descFa, base, primary, accent } = props;
  const idx = highlight ? title.indexOf(highlight) : -1;
  const before = idx >= 0 ? title.slice(0, idx) : title;
  const mid = idx >= 0 ? title.slice(idx, idx + (highlight?.length ?? 0)) : "";
  const after = idx >= 0 ? title.slice(idx + (highlight?.length ?? 0)) : "";
  return (
    <header
      className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
      style={{
        backgroundImage: `linear-gradient(135deg, ${base} 0%, ${primary} 55%, ${accent} 130%)`,
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div
          className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
          style={{ backgroundColor: accent, opacity: 0.35 }}
        />
      </div>
      <div className="relative flex min-w-0 items-center gap-3 sm:gap-4">
        <div
          className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16"
          style={{ color: primary }}
        >
          <Icon className="h-8 w-8" />
        </div>
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
            {label}
          </div>
          <h1 className="mt-2 text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
            {before}
            {mid && (
              <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
                {mid}
              </span>
            )}
            {after}
          </h1>
          <FaHint className="!text-white/85">{fa}</FaHint>
          <p className="mt-2 max-w-2xl text-sm text-white/80">{desc}</p>
          <FaHint className="!text-white/70">{descFa}</FaHint>
        </div>
      </div>
    </header>
  );
}

function Panel({
  title,
  fa,
  tone = "default",
  children,
}: {
  title: string;
  fa?: string;
  tone?: "default" | "warn";
  children: ReactNode;
}) {
  return (
    <section
      className={`glass-strong rounded-[28px] p-5 sm:p-6 ${tone === "warn" ? "ring-1 ring-amber-400/20" : ""}`}
    >
      <header className="mb-4">
        <h2 className="text-[15px] font-semibold tracking-tight">{title}</h2>
        {fa && <FaHint>{fa}</FaHint>}
      </header>
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}
function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className="w-full rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none transition focus:border-foreground/40 focus:ring-4 focus:ring-foreground/5"
    />
  );
}
function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className="w-full rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none transition focus:border-foreground/40 focus:ring-4 focus:ring-foreground/5"
    />
  );
}

function PrimaryBtn({ children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...p}
      className="inline-flex items-center gap-1.5 rounded-xl bg-foreground px-4 py-2 text-sm font-bold text-background transition hover:opacity-90"
    >
      {children}
    </button>
  );
}
function GhostBtn({ children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...p}
      className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-background/40 px-4 py-2 text-sm font-semibold text-foreground/80 transition hover:bg-foreground/5"
    >
      {children}
    </button>
  );
}
function DangerBtn({ children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...p}
      className="inline-flex items-center gap-1.5 rounded-xl bg-destructive/10 px-4 py-2 text-sm font-bold text-destructive ring-1 ring-inset ring-destructive/30 transition hover:bg-destructive/15"
    >
      {children}
    </button>
  );
}

function Row({
  Icon,
  title,
  fa,
  desc,
  tone = "default",
  children,
}: {
  Icon?: typeof Settings2;
  title: string;
  fa?: string;
  desc?: string;
  tone?: "default" | "danger";
  children?: ReactNode;
}) {
  return (
    <div
      className={`flex items-start gap-3 rounded-2xl border p-3 ${tone === "danger" ? "border-destructive/25 bg-destructive/5" : "border-border bg-background/40"}`}
    >
      {Icon && (
        <span
          className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${tone === "danger" ? "bg-destructive/10 text-destructive" : "bg-foreground/5"}`}
        >
          <Icon className="h-5 w-5" />
        </span>
      )}
      <div className="min-w-0 flex-1">
        <div className="text-sm font-semibold">{title}</div>
        {fa && <FaHint>{fa}</FaHint>}
        {desc && <p className="mt-0.5 text-xs text-muted-foreground">{desc}</p>}
      </div>
      {children}
    </div>
  );
}

function ToggleRow({
  Icon,
  title,
  fa,
  desc,
  checked,
  defaultChecked,
  onChange,
}: {
  Icon?: typeof Settings2;
  title: string;
  fa?: string;
  desc?: string;
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (v: boolean) => void;
}) {
  const [inner, setInner] = useState(defaultChecked ?? false);
  const value = checked ?? inner;
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-border bg-background/40 p-3 transition hover:border-foreground/20">
      {Icon && (
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-foreground/5">
          <Icon className="h-5 w-5" />
        </span>
      )}
      <div className="min-w-0 flex-1">
        <div className="text-sm font-semibold">{title}</div>
        {fa && <FaHint>{fa}</FaHint>}
        {desc && <p className="mt-0.5 text-xs text-muted-foreground">{desc}</p>}
      </div>
      <span className="relative inline-flex h-6 w-11 shrink-0">
        <input
          type="checkbox"
          checked={value}
          onChange={(e) => (onChange ? onChange(e.target.checked) : setInner(e.target.checked))}
          className="peer sr-only"
        />
        <span className="absolute inset-0 rounded-full bg-foreground/15 transition peer-checked:bg-foreground" />
        <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition peer-checked:translate-x-5" />
      </span>
    </label>
  );
}
