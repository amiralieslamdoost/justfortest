import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Timer,
  Gauge,
  CalendarCheck,
  Flame,
  TrendingUp,
  Layers,
  CalendarRange,
  Clock,
  Boxes,
  GraduationCap,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { useDeusi } from "@/lib/deusi/store";
import { SectionHero } from "@/components/deusi/SectionHero";
import { StatKpi } from "@/components/deusi/stats/StatKpi";
import { StatCard } from "@/components/deusi/stats/StatCard";
import { StudyTimeChart } from "@/components/deusi/stats/StudyTimeChart";
import { LearningActivityChart } from "@/components/deusi/stats/LearningActivityChart";
import { ProgressList } from "@/components/deusi/stats/ProgressList";
import { VocabularyHeatmap } from "@/components/deusi/stats/VocabularyHeatmap";
import { WeekdayProfile } from "@/components/deusi/stats/WeekdayProfile";
import { StudyHoursChart } from "@/components/deusi/stats/StudyHoursChart";
import { DailyGoalCard } from "@/components/deusi/stats/DailyGoalCard";
import {
  dateRanges,
  formatMinutes,
  grammarTopics,
  hourBuckets,
  last7Days,
  leitnerBoxes,
  leitnerDueToday,
  monthlyTotals,
  sliceDays,
  studyHeatmap,
  studyProfile,
  todayMinutes,
  type DateRangeKey,
} from "@/lib/deusi/mockStudyStats";
import { Fa } from "@/components/deusi/Fa";

/** One accent per topic keeps the page colorful but never random. */
const ACCENT = {
  time: "#DD2222",
  average: "#0EA5A0",
  regularity: "#F59E0B",
  streak: "#7C3AED",
  trend: "#DD2222",
  modules: "#2563EB",
  pattern: "#DB2777",
  hours: "#0891B2",
  leitner: "#16A34A",
  grammar: "#4F46E5",
  months: "#EA580C",
} as const;

export const Route = createFileRoute("/statistiken")({
  head: () => ({
    meta: [
      { title: "Lernzeit & Statistiken — DEUSI" },
      {
        name: "description",
        content:
          "Sieh genau, wie viel Zeit du mit Deutsch verbringst — pro Tag, pro Bereich und im Verlauf.",
      },
      { property: "og:title", content: "Lernzeit & Statistiken — DEUSI" },
      {
        property: "og:description",
        content:
          "Sieh genau, wie viel Zeit du mit Deutsch verbringst — pro Tag, pro Bereich und im Verlauf.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: StatistikenPage,
});

function StatistikenPage() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  const [range, setRange] = useState<DateRangeKey>("4w");

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, currentUser?.id]);

  const days = useMemo(() => {
    const cfg = dateRanges.find((r) => r.key === range) ?? dateRanges[1];
    return sliceDays(cfg.days);
  }, [range]);

  const totalMinutes = useMemo(() => days.reduce((s, d) => s + d.minutes, 0), [days]);
  const activeDays = useMemo(() => days.filter((d) => d.minutes > 0).length, [days]);
  const avgPerDay = days.length ? Math.round(totalMinutes / days.length) : 0;
  const avgPerActiveDay = activeDays ? Math.round(totalMinutes / activeDays) : 0;
  const sessions = useMemo(() => days.reduce((s, d) => s + d.sessions, 0), [days]);
  const cards = useMemo(() => days.reduce((s, d) => s + d.cardsReviewed, 0), [days]);
  const words = useMemo(() => days.reduce((s, d) => s + d.wordsSaved, 0), [days]);
  const regularity = Math.round((activeDays / Math.max(days.length, 1)) * 100);

  /** Sparkline series: at most ~20 points so the mini chart stays legible. */
  const spark = useMemo(() => {
    const step = Math.max(1, Math.ceil(days.length / 20));
    return days.filter((_, i) => i % step === 0).map((d) => d.minutes);
  }, [days]);

  /** Average minutes per weekday (Mon → Sun) over the selected range. */
  const weekdayProfile = useMemo(() => {
    const names = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
    const namesFa = ["دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه"];
    const sum = Array(7).fill(0) as number[];
    const count = Array(7).fill(0) as number[];
    for (const d of days) {
      const js = new Date(d.date + "T00:00:00").getDay();
      const i = (js + 6) % 7;
      sum[i] += d.minutes;
      count[i] += 1;
    }
    return names.map((label, i) => ({
      index: i,
      label,
      labelFa: namesFa[i],
      minutes: count[i] ? Math.round(sum[i] / count[i]) : 0,
    }));
  }, [days]);

  /** Total of the selected range vs. the equally long range before it. */
  const deltaPct = useMemo(() => {
    const both = sliceDays(days.length * 2);
    if (both.length < days.length * 2) return 0;
    const prev = both.slice(0, days.length).reduce((s, d) => s + d.minutes, 0);
    if (!prev) return 0;
    return Math.round(((totalMinutes - prev) / prev) * 100);
  }, [days, totalMinutes]);
  const heatmap = useMemo(() => studyHeatmap(sliceDays(182)), []);
  const months = useMemo(() => monthlyTotals(sliceDays(182)), []);
  const grammarAvg = Math.round(
    grammarTopics.reduce((s, g) => s + g.mastery, 0) / grammarTopics.length,
  );
  /** Gelernte Wörter = Karten in Box 4 + 5 (gefestigt & beherrscht). */
  const totalCards = leitnerBoxes.reduce((s, b) => s + b.cards, 0);
  const mastered = leitnerBoxes.filter((b) => b.box >= 4).reduce((s, b) => s + b.cards, 0);
  const masteredPct = Math.round((mastered / Math.max(totalCards, 1)) * 100);

  if (!currentUser) return null;

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 animate-fade sm:space-y-5">
      <SectionHero
        sectionKey="statistics"
        titleDe="Deine Lernzeit im Blick"
        titleFa="زمان یادگیری‌ات، شفاف و قابل‌سنجش"
        descDe="Wie viel Zeit du wirklich mit Deutsch verbringst — pro Tag, pro Bereich, im Verlauf."
        descFa="ببین واقعاً چقدر وقت برای آلمانی می‌گذاری — روزانه، به تفکیک بخش و در طول زمان."
        highlight="Lernzeit"
        right={
          <div
            role="tablist"
            aria-label="Zeitraum"
            className="no-scrollbar -mx-1 flex w-full snap-x gap-1 overflow-x-auto rounded-2xl bg-white/15 p-1 ring-1 ring-white/20 backdrop-blur sm:mx-0 sm:w-auto"
          >
            {dateRanges.map((r) => (
              <button
                key={r.key}
                role="tab"
                aria-selected={range === r.key}
                onClick={() => setRange(r.key)}
                className={`shrink-0 snap-start whitespace-nowrap rounded-xl px-3 py-1.5 text-[11px] font-semibold transition sm:text-xs ${
                  range === r.key
                    ? "bg-white text-[color:var(--section-primary)] shadow-sm"
                    : "text-white/80 hover:bg-white/10"
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        }
      />

      {/* KPIs — alles zeitbezogen */}
      <section className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <StatKpi
          icon={<Timer size={18} strokeWidth={2.4} />}
          accent={ACCENT.time}
          label="Lernzeit im Zeitraum"
          labelFa="کل زمان مطالعه"
          value={formatMinutes(totalMinutes)}
          sub={`${sessions} Lerneinheiten`}
          spark={spark}
        />
        <StatKpi
          icon={<Gauge size={18} strokeWidth={2.4} />}
          accent={ACCENT.average}
          label="Ø pro Tag"
          labelFa="میانگین روزانه"
          value={`${avgPerDay} Min`}
          sub={`${avgPerActiveDay} Min an aktiven Tagen`}
          progress={Math.round((avgPerDay / Math.max(studyProfile.dailyGoalMinutes, 1)) * 100)}
        />
        <StatKpi
          icon={<CalendarCheck size={18} strokeWidth={2.4} />}
          accent={ACCENT.regularity}
          label="Aktive Tage"
          labelFa="روزهای فعال"
          value={`${activeDays} / ${days.length}`}
          sub={`${regularity} % Regelmäßigkeit`}
          progress={regularity}
        />
        <StatKpi
          icon={<Flame size={18} strokeWidth={2.4} />}
          accent={ACCENT.streak}
          label="Aktuelle Serie"
          labelFa="سری روزهای پیاپی"
          value={`${studyProfile.streakDays} Tage`}
          sub={`Rekord: ${studyProfile.longestStreak} Tage`}
          progress={Math.round(
            (studyProfile.streakDays / Math.max(studyProfile.longestStreak, 1)) * 100,
          )}
        />
      </section>

      {/* Verlauf + Tagesziel */}
      <section className="grid gap-3 sm:gap-4 lg:grid-cols-[minmax(0,1fr)_340px]">
        <StatCard
          title="Lernzeit im Verlauf"
          fa="روند زمان مطالعه"
          accent={ACCENT.trend}
          icon={<TrendingUp size={16} strokeWidth={2.4} />}
          action={<span className="stat-chip">{formatMinutes(totalMinutes)}</span>}
        >
          <StudyTimeChart data={days} goal={studyProfile.dailyGoalMinutes} height={260} />
        </StatCard>

        <DailyGoalCard
          todayMinutes={todayMinutes}
          goalMinutes={studyProfile.dailyGoalMinutes}
          week={last7Days}
        />
      </section>

      {/* Wochenrhythmus */}
      <StatCard
        title="Wochenrhythmus"
        fa="ریتم هفتگی مطالعه"
        accent={ACCENT.modules}
        icon={<CalendarRange size={16} strokeWidth={2.4} />}
        action={
          <span className="stat-chip">
            {deltaPct >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
            {deltaPct >= 0 ? "+" : ""}
            {deltaPct}% vs. davor
          </span>
        }
      >
        <WeekdayProfile data={weekdayProfile} accent={ACCENT.modules} />
      </StatCard>

      {/* Muster + Tageszeit */}
      <section className="grid items-start gap-3 sm:gap-4 lg:grid-cols-[minmax(0,1fr)_340px]">
        <StatCard
          title="Lernmuster"
          fa="الگوی مطالعه در هفته‌ها"
          accent={ACCENT.pattern}
          icon={<CalendarRange size={16} strokeWidth={2.4} />}
          action={<span className="stat-chip">6 Monate</span>}
        >
          <VocabularyHeatmap data={heatmap.grid} months={heatmap.months} />
        </StatCard>

        <StatCard
          title="Wann du lernst"
          fa="ساعت‌های فعال روز"
          accent={ACCENT.hours}
          icon={<Clock size={16} strokeWidth={2.4} />}
        >
          <StudyHoursChart data={hourBuckets} />
        </StatCard>
      </section>

      {/* Leitner + Grammatik */}
      <section className="grid gap-3 sm:gap-4 lg:grid-cols-2">
        <StatCard
          title="Leitner-Boxen"
          fa="توزیع جعبه‌های لایتنر"
          accent={ACCENT.leitner}
          icon={<Boxes size={16} strokeWidth={2.4} />}
          action={<span className="stat-chip">{leitnerDueToday} heute fällig</span>}
        >
          <div className="grid grid-cols-5 gap-1.5 pt-1 sm:gap-2">
            {leitnerBoxes.map((b) => {
              const max = Math.max(...leitnerBoxes.map((x) => x.cards));
              return (
                <div key={b.box} className="flex min-w-0 flex-col items-center gap-2">
                  <span className="text-[10px] font-bold tabular-nums text-muted-foreground sm:text-[11px]">
                    {b.cards}
                  </span>
                  <div className="flex h-[110px] w-full max-w-[54px] items-end">
                    <div
                      className="w-full rounded-t-xl transition-[height] duration-700"
                      style={{
                        height: `${(b.cards / max) * 100}%`,
                        background: `linear-gradient(180deg, color-mix(in oklab, ${b.color} 55%, white), ${b.color})`,
                      }}
                      title={`${b.cards} Karten`}
                    />
                  </div>
                  <div className="w-full truncate text-center text-[10px] font-semibold sm:text-[11px]">
                    {b.label}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Gelernte Wörter — füllt den freien Raum unter den Balken */}
          <div className="mt-4 grid gap-2 border-t border-border/60 pt-3 sm:grid-cols-2">
            <div
              className="rounded-2xl p-3"
              style={{ background: `color-mix(in oklab, ${ACCENT.leitner} 10%, transparent)` }}
            >
              <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Gelernte Wörter
              </div>
              <div className="flex items-baseline gap-2">
                <span
                  className="text-2xl font-black tabular-nums"
                  style={{ color: ACCENT.leitner }}
                >
                  {mastered.toLocaleString("de-DE")}
                </span>
                <span className="text-[11px] font-semibold text-muted-foreground">
                  von {totalCards.toLocaleString("de-DE")}
                </span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-foreground/10">
                <div
                  className="h-full rounded-full"
                  style={{ width: `${masteredPct}%`, background: ACCENT.leitner }}
                />
              </div>
              <Fa className="fa-hint-xs mt-1 block">
                {masteredPct}% از واژه‌ها به جعبه‌های بالا رسیده‌اند
              </Fa>
            </div>
            <div className="rounded-2xl bg-secondary/50 p-3">
              <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Wiederholt im Zeitraum
              </div>
              <div className="text-2xl font-black tabular-nums">
                {cards.toLocaleString("de-DE")}
              </div>
              <Fa className="fa-hint-xs mt-1 block">کارت‌های مرورشده در این بازه</Fa>
            </div>
          </div>
        </StatCard>

        <StatCard
          title="Grammatik-Themen"
          fa="پیشرفت مباحث گرامر"
          accent={ACCENT.grammar}
          icon={<GraduationCap size={16} strokeWidth={2.4} />}
          action={<span className="stat-chip">Ø {grammarAvg}%</span>}
        >
          <ProgressList
            rows={grammarTopics.map((g) => ({ label: g.name, value: g.mastery, color: g.color }))}
          />
        </StatCard>
      </section>

      {/* Monatsverlauf */}
      <StatCard
        title="Monatsverlauf"
        fa="فعالیت ماهانه"
        accent={ACCENT.months}
        icon={<BarChart3 size={16} strokeWidth={2.4} />}
        action={<span className="stat-chip">{words.toLocaleString("de-DE")} Wörter</span>}
      >
        <LearningActivityChart data={months} />
        <Fa className="fa-hint-xs mt-3 block">مجموع دقیقه‌های مطالعه در شش ماه گذشته</Fa>
      </StatCard>
    </div>
  );
}
