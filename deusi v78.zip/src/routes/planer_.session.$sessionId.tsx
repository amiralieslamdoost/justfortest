import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PlannerSubPage } from "@/components/deusi/planner/PlannerSubPage";
import { SessionEditForm } from "@/components/deusi/planner/SessionForms";
import { formatDayLong } from "@/lib/deusi/planner/date";
import { usePlanner } from "@/lib/deusi/planner/usePlanner";

const TITLE = "Session bearbeiten — DEUSI Smart Planner";
const DESCRIPTION =
  "Verschiebe einen Lernblock auf einen anderen Tag, ändere Startzeit und Dauer oder entferne ihn aus der Woche.";

export const Route = createFileRoute("/planer_/session/$sessionId")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: EditSessionPage,
});

function EditSessionPage() {
  const { sessionId } = Route.useParams();
  const planner = usePlanner();
  const navigate = useNavigate();
  const back = () => void navigate({ to: "/planer" });

  const session = planner.sessions.find((s) => s.id === sessionId);

  if (!session) {
    return (
      <PlannerSubPage
        title="Session nicht gefunden"
        titleFa="این جلسه پیدا نشد"
        intro="Dieser Lernblock gehört nicht zur aktuell geöffneten Woche."
        introFa="این بلوک در هفته‌ی باز شده وجود ندارد. به برنامه برگرد و دوباره انتخابش کن."
      >
        <Link
          to="/planer"
          className="inline-flex rounded-full bg-[color:var(--section-primary)] px-5 py-2 text-sm font-bold text-white"
        >
          Zum Wochenplan
        </Link>
      </PlannerSubPage>
    );
  }

  return (
    <PlannerSubPage
      title={session.title}
      titleFa="ویرایش جلسه"
      intro={formatDayLong(session.date)}
      introFa="می‌توانی روز، ساعت و مدت این بلوک را تغییر دهی یا آن را از هفته حذف کنی."
    >
      <SessionEditForm
        session={session}
        weekStart={planner.weekStart}
        onCancel={back}
        onSave={(patch) => {
          void planner.updateSession(session.id, patch).then(back);
        }}
        onRemove={() => {
          void planner.removeSession(session.id).then(back);
        }}
      />
    </PlannerSubPage>
  );
}
