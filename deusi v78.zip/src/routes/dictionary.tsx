import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useDeusi } from "@/lib/deusi/store";
import { useInteractions } from "@/lib/deusi/interactions";
import {
  FEATURED_WORDS,
  RECENTLY_VIEWED_IDS,
  POPULAR_IDS,
  VOCAB_STATS,
  findById,
  searchWords,
  categoryCount,
} from "@/lib/deusi/dictionary/mockWords";
import { CATEGORIES, CEFR_LEVELS, POS_LABEL } from "@/lib/deusi/dictionary/categories";
import { LEARNING_BOOKS } from "@/lib/deusi/dictionary/books";
import { PROVERBS } from "@/lib/deusi/dictionary/proverbs";
import { useWordCatalog } from "@/lib/api/useVocabulary";
import { ProverbCard } from "@/components/deusi/dictionary/ProverbCard";
import type { CEFR, DictPos, DictWord } from "@/lib/deusi/dictionary/types";
import { WordCard } from "@/components/deusi/dictionary/WordCard";
import { WordDetailPanel } from "@/components/deusi/dictionary/WordDetailPanel";
import { MyWordsSection } from "@/components/deusi/dictionary/MyWordsSection";
import { CefrBadge } from "@/components/deusi/dictionary/Badges";
import { SectionShell } from "@/components/deusi/dictionary/SectionShell";
import { Fa } from "@/components/deusi/Fa";
import { SectionHero } from "@/components/deusi/SectionHero";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";

import { useCustomWords } from "@/lib/deusi/dictionary/customWords";
import { useLeitnerQueue } from "@/lib/deusi/dictionary/leitnerQueue";

// Section identity — one source of truth so SectionNav and each
// SectionShell agree on order, icon, label, and accent color.
const SECTIONS = [
  { id: "sec-recent", label: "Kürzlich", icon: "🕐", accent: "#64748B" },
  { id: "sec-wortschatz", label: "Wortschatz", icon: "📊", accent: "#7C3AED" },
  { id: "sec-mine", label: "Meine Wörter", icon: "✨", accent: "#EC4899" },
  { id: "sec-popular", label: "Beliebt", icon: "🔥", accent: "#F97316" },
  { id: "sec-proverbs", label: "Sprichwörter", icon: "💬", accent: "#14B8A6" },
  { id: "sec-books", label: "Lehrbücher", icon: "📚", accent: "#6366F1" },
  { id: "sec-categories", label: "Kategorien", icon: "🗂️", accent: "#0EA5E9" },
  { id: "sec-all", label: "Alle Wörter", icon: "📖", accent: "#A855F7" },
] as const;
const ACCENT = Object.fromEntries(SECTIONS.map((s) => [s.id, s])) as Record<
  (typeof SECTIONS)[number]["id"],
  (typeof SECTIONS)[number]
>;

export const Route = createFileRoute("/dictionary")({
  head: () => ({
    meta: [
      { title: "Wörterbuch — DEUSI" },
      {
        name: "description",
        content: "Deutsches Wörterbuch mit Aussprache, Beispielen und persischer Übersetzung.",
      },
      { property: "og:title", content: "Wörterbuch — DEUSI" },
      {
        property: "og:description",
        content: "Deutsches Wörterbuch mit Aussprache, Beispielen und persischer Übersetzung.",
      },
    ],
  }),
  component: Dictionary,
});

function Dictionary() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  const {
    isBookmarked,
    isFavorited,
    toggleBookmark,
    toggleFavorite,
    countBookmarks,
    countFavorites,
  } = useInteractions();
  const { words: customWords } = useCustomWords();
  const leitner = useLeitnerQueue();

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  // ---- state ----
  const [query, setQuery] = useState("");
  const [cefr, setCefr] = useState<CEFR | "all">("all");
  const [pos, setPos] = useState<DictPos | "all">("all");
  const [category, setCategory] = useState<string | "all">("all");
  const [showSuggest, setShowSuggest] = useState(false);
  const [recent, setRecent] = useState<string[]>(RECENTLY_VIEWED_IDS);
  const bookmarks = { has: (id: string) => isBookmarked("word", id) };
  const favorites = { has: (id: string) => isFavorited("word", id) };
  const [progress] = useState<Record<string, number>>({
    lernen: 85,
    wunderbar: 65,
    zeit: 90,
    freund: 72,
    entwickeln: 45,
    morgen: 85,
    abenteuer: 65,
    geniessen: 90,
    traumhaft: 40,
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>(["Zeit", "lernen", "Freund"]);
  const PAGE_SIZE = 10;
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [allLayout, setAllLayout] = useState<"grid" | "list">("grid");
  const resultsRef = useRef<HTMLDivElement | null>(null);

  // Reset pagination when filters/query change
  useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [cefr, pos, category, query]);

  // Mobile detail sheet: lock background scroll + close on Escape
  useEffect(() => {
    if (!selectedId || typeof window === "undefined") return;
    if (window.matchMedia("(min-width: 1024px)").matches) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSelectedId(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [selectedId]);

  const scrollToResults = () => {
    setTimeout(
      () => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
      60,
    );
  };
  const pickCategory = (id: string) => {
    setCategory((prev) => (prev === id ? "all" : id));
    scrollToResults();
  };

  // ---- derived ----
  const { words: catalog } = useWordCatalog();
  const suggestions = useMemo(() => searchWords(query, 6), [query]);
  const filtered = useMemo(
    () =>
      catalog.filter((w) => {
        if (cefr !== "all" && w.cefr !== cefr) return false;
        if (pos !== "all" && w.pos !== pos) return false;
        if (category !== "all" && w.category !== category) return false;
        if (query) {
          const q = query.toLowerCase();
          if (!w.headword.toLowerCase().includes(q) && !w.shortMeaning.toLowerCase().includes(q))
            return false;
        }
        return true;
      }),
    [catalog, cefr, pos, category, query],
  );

  const resolveWord = (id: string): DictWord | undefined =>
    findById(id) ?? catalog.find((w) => w.id === id) ?? customWords.find((w) => w.id === id);

  const selectedWord: DictWord | null = selectedId ? (resolveWord(selectedId) ?? null) : null;

  // ---- actions ----
  const openWord = (
    id: string,
    event?: React.MouseEvent<HTMLElement> | React.KeyboardEvent<HTMLElement>,
  ) => {
    void event;
    setSelectedId(id);
    setRecent((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, 8));
  };
  const wordMeta = (id: string) => {
    const w = resolveWord(id);
    return {
      title: w?.headword ?? id,
      sub: [w?.pos, w?.meanings?.[0]?.fa ?? w?.meanings?.[0]?.de].filter(Boolean).join(" · "),
      level: w?.cefr,
      to: "/dictionary",
    };
  };
  const toggleBm = (id: string) => toggleBookmark("word", id, wordMeta(id));
  const toggleFv = (id: string) => toggleFavorite("word", id, wordMeta(id));
  const toggleLeitner = (id: string, label?: string) => {
    const w = resolveWord(id);
    leitner.toggle(id, label ?? w?.headword);
  };

  const submitSearch = () => {
    if (query.trim() && !recentSearches.includes(query)) {
      setRecentSearches((prev) => [query, ...prev].slice(0, 5));
    }
    setShowSuggest(false);
  };

  const mobileDetailPopover =
    typeof document === "undefined"
      ? null
      : createPortal(
          <AnimatePresence>
            {selectedWord && (
              <div key="mobile-dictionary-detail" className="lg:hidden">
                {/* Backdrop */}
                <motion.div
                  className="fixed inset-0 z-40 bg-black/45 backdrop-blur-[2px]"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.18, ease: "easeOut" }}
                  onClick={() => setSelectedId(null)}
                />

                {/* Slide-in sheet from the right, swipe right to dismiss */}
                <motion.div
                  role="dialog"
                  aria-modal="true"
                  drag="x"
                  dragDirectionLock
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={{ left: 0, right: 0.6 }}
                  onDragEnd={(_, info) => {
                    if (info.offset.x > 110 || info.velocity.x > 600) setSelectedId(null);
                  }}
                  initial={{ x: "100%" }}
                  animate={{ x: 0 }}
                  exit={{ x: "100%" }}
                  transition={{ type: "spring", stiffness: 460, damping: 42, mass: 0.7 }}
                  className="fixed inset-y-0 right-0 z-50 flex w-full max-w-[520px] flex-col overflow-hidden bg-card shadow-2xl ring-1 ring-border/70 [&>aside]:!rounded-none [&>aside]:!bg-card [&>aside]:!backdrop-blur-none [&>aside]:!border-border [&>aside]:!shadow-none"
                  style={{ touchAction: "pan-y" }}
                >
                  {/* Grab handle hinting the swipe-to-close gesture */}
                  <div
                    aria-hidden
                    className="pointer-events-none absolute left-1.5 top-1/2 z-20 h-14 w-1 -translate-y-1/2 rounded-full bg-foreground/15"
                  />
                  <WordDetailPanel
                    word={selectedWord}
                    favorite={favorites.has(selectedWord.id)}
                    inLeitner={leitner.has(selectedWord.id)}
                    bookmarked={bookmarks.has(selectedWord.id)}
                    onClose={() => setSelectedId(null)}
                    onToggleFavorite={() => toggleFv(selectedWord.id)}
                    onToggleLeitner={() => toggleLeitner(selectedWord.id)}
                    onToggleBookmark={() => toggleBm(selectedWord.id)}
                    onOpenWord={openWord}
                  />
                </motion.div>
              </div>
            )}
          </AnimatePresence>,
          document.body,
        );

  if (!currentUser) return null;

  return (
    <div className="grid gap-4 sm:gap-5 lg:grid-cols-[minmax(0,1fr)_420px] animate-fade">
      {/* ============ LEFT: Home ============ */}
      <div className="isolate min-w-0 space-y-6 sm:space-y-7">
        <SectionHero sectionKey="dictionary" allowOverflow>
          {/* Suche direkt im Header — ein einziges, kompaktes Steuerelement */}
          <div className="relative z-40">
            <div className="group relative flex w-full flex-col gap-2 rounded-2xl border border-white/25 bg-white/12 p-1.5 shadow-[0_18px_40px_-24px_rgba(0,0,0,.7)] backdrop-blur-md transition-all focus-within:border-white/50 focus-within:bg-white/18 focus-within:ring-2 focus-within:ring-white/25 sm:flex-row sm:items-center sm:gap-1">
              <div className="flex min-w-0 flex-1 items-center gap-2 pl-3 text-white">
                <SearchIcon />
                <input
                  value={query}
                  onChange={(e) => {
                    setQuery(e.target.value);
                    setShowSuggest(true);
                  }}
                  onFocus={() => setShowSuggest(true)}
                  onBlur={() => setTimeout(() => setShowSuggest(false), 150)}
                  onKeyDown={(e) => e.key === "Enter" && submitSearch()}
                  placeholder="Wörter suchen…"
                  aria-label="Wörter suchen"
                  className="min-w-0 flex-1 bg-transparent py-2.5 text-sm text-white outline-none placeholder:text-white/60"
                />
                {query && (
                  <button
                    onClick={() => setQuery("")}
                    className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-white/70 transition hover:bg-white/20 hover:text-white"
                    aria-label="Löschen"
                  >
                    ✕
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  setCefr("all");
                  setPos("all");
                  setCategory("all");
                  setQuery("");
                  scrollToResults();
                }}
                className="flex w-full shrink-0 items-center justify-center gap-1.5 rounded-xl bg-white px-3 py-2.5 text-xs font-bold shadow-sm transition hover:shadow-md sm:w-auto sm:text-sm"
                style={{ color: SECTION_THEME.dictionary.base }}
                title="Alle Wörter anzeigen"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="hidden sm:block"
                >
                  <rect x="3" y="4" width="18" height="4" rx="1" />
                  <rect x="3" y="11" width="18" height="4" rx="1" />
                  <rect x="3" y="18" width="18" height="3" rx="1" />
                </svg>
                <span className="whitespace-nowrap">Alle Wörter</span>
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M9 6l6 6-6 6" />
                </svg>
              </button>

              {/* Suggestions dropdown */}
              <AnimatePresence>
                {showSuggest && (query || recentSearches.length > 0) && (
                  <motion.div
                    initial={{ opacity: 0, y: -6, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -6, scale: 0.98 }}
                    transition={{ duration: 0.15 }}
                    className="absolute left-0 right-0 top-full z-[100] mt-2 max-h-80 overflow-y-auto rounded-2xl border border-border/70 bg-card p-2 text-foreground shadow-2xl ring-1 ring-black/5"
                  >
                    {query && suggestions.length > 0 && (
                      <div>
                        <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                          Vorschläge
                        </div>
                        {suggestions.map((s) => (
                          <button
                            key={s.id}
                            onMouseDown={(event) => {
                              event.preventDefault();
                              openWord(s.id, event);
                              setQuery("");
                              setShowSuggest(false);
                            }}
                            className="flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left transition hover:bg-muted"
                          >
                            <div className="flex items-baseline gap-2">
                              <span className="font-semibold">{s.headword}</span>
                              <span className="text-xs text-muted-foreground">
                                {POS_LABEL[s.pos]}
                              </span>
                            </div>
                            <CefrBadge level={s.cefr} />
                          </button>
                        ))}
                      </div>
                    )}
                    {query && suggestions.length === 0 && (
                      <div className="px-3 py-6 text-center text-sm text-muted-foreground">
                        Keine Ergebnisse für „{query}"
                      </div>
                    )}
                    {!query && recentSearches.length > 0 && (
                      <div>
                        <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                          Letzte Suchen
                        </div>
                        {recentSearches.map((r) => (
                          <button
                            key={r}
                            onMouseDown={(event) => {
                              event.preventDefault();
                              setQuery(r);
                              setShowSuggest(true);
                            }}
                            className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm transition hover:bg-muted"
                          >
                            <ClockIcon /> {r}
                          </button>
                        ))}
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </SectionHero>

        {/* 01 · Recently viewed */}
        <SectionShell
          anchorId="sec-recent"
          index={1}
          icon={ACCENT["sec-recent"].icon}
          accent={ACCENT["sec-recent"].accent}
          title="Kürzlich angesehen"
          subtitle="Deine zuletzt geöffneten Wörter"
        >
          {recent.length === 0 ? (
            <p className="rounded-xl border border-dashed border-border/60 bg-muted/30 px-4 py-6 text-center text-xs text-muted-foreground">
              Noch keine Wörter geöffnet — tippe unten auf ein Wort, um zu starten.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {recent.slice(0, 6).map((id) => {
                const w = findById(id);
                if (!w) return null;
                return (
                  <WordCard
                    key={w.id}
                    word={w}
                    variant="compact"
                    bookmarked={bookmarks.has(w.id)}
                    onOpen={(event) => openWord(w.id, event)}
                    onToggleBookmark={() => toggleBm(w.id)}
                  />
                );
              })}
            </div>
          )}
        </SectionShell>

        {/* 02 · Dein Wortschatz — stats hero (keeps its own vivid design) */}
        <div id="sec-wortschatz" className="scroll-mt-24">
          <WortschatzHero
            bookmarksCount={countBookmarks("word")}
            customCount={customWords.length}
            leitnerCount={leitner.count}
          />
        </div>

        {/* 03 · Meine Wörter — personal collection (has its own gradient header) */}
        <div id="sec-mine" className="scroll-mt-24">
          <MyWordsSection
            masterWords={catalog}
            findById={findById}
            onOpen={openWord}
            onToggleBookmark={toggleBm}
            bookmarks={(id) => bookmarks.has(id)}
            progress={progress}
            inLeitner={(id) => leitner.has(id)}
            onToggleLeitner={toggleLeitner}
            previewLimit={4}
            moreTo="/dictionary/meine-woerter"
          />
        </div>

        {/* 04 · Popular words */}
        <SectionShell
          anchorId="sec-popular"
          index={4}
          icon={ACCENT["sec-popular"].icon}
          accent={ACCENT["sec-popular"].accent}
          title="Beliebte Wörter"
          subtitle="Meistgesucht diese Woche"
          action={
            <span
              className="rounded-full px-2.5 py-1 text-[10px] font-bold"
              style={{
                background: `${ACCENT["sec-popular"].accent}18`,
                color: ACCENT["sec-popular"].accent,
              }}
            >
              Trending
            </span>
          }
        >
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {POPULAR_IDS.map((id) => {
              const w = findById(id);
              if (!w) return null;
              return (
                <WordCard
                  key={w.id}
                  word={w}
                  progress={progress[w.id] ?? 40}
                  bookmarked={bookmarks.has(w.id)}
                  inLeitner={leitner.has(w.id)}
                  onOpen={(event) => openWord(w.id, event)}
                  onToggleBookmark={() => toggleBm(w.id)}
                  onToggleLeitner={() => toggleLeitner(w.id, w.headword)}
                />
              );
            })}
          </div>
        </SectionShell>

        {/* 05 · Proverbs & idioms */}
        <ProverbsSection accent={ACCENT["sec-proverbs"].accent} anchorId="sec-proverbs" />

        {/* 06 · Textbook vocabulary */}
        <SectionShell
          anchorId="sec-books"
          index={6}
          icon={ACCENT["sec-books"].icon}
          accent={ACCENT["sec-books"].accent}
          title="Wortschatz aus Lehrbüchern"
          subtitle="Wichtige Vokabeln pro Kursbuch"
          action={
            <Link
              to="/books"
              className="rounded-full border border-border/60 bg-card px-2.5 py-1 text-[10px] font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground"
            >
              Alle Bücher →
            </Link>
          }
        >
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {LEARNING_BOOKS.map((b) => (
              <Link
                key={b.id}
                to="/books/$bookId"
                params={{ bookId: b.id }}
                className="group flex flex-col overflow-hidden rounded-2xl border border-border/70 bg-card text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg"
                aria-label={`${b.title} — Vokabeln öffnen`}
              >
                <div
                  className="relative aspect-[3/4] w-full overflow-hidden"
                  style={{ background: `linear-gradient(160deg, ${b.color}33, ${b.color}11)` }}
                >
                  {b.coverUrl ? (
                    <img
                      src={b.coverUrl}
                      alt={b.title}
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
                    />
                  ) : (
                    <div className="grid h-full w-full place-items-center text-5xl opacity-80">
                      {b.cover}
                    </div>
                  )}
                  <span
                    className="absolute left-2 top-2 rounded-md px-1.5 py-0.5 text-[10px] font-bold text-white shadow"
                    style={{ background: b.color }}
                  >
                    {b.level}
                  </span>
                </div>

                <div className="flex flex-col gap-0.5 p-3">
                  <div className="truncate text-sm font-semibold">{b.title}</div>
                  <div className="truncate text-[11px] text-muted-foreground">{b.publisher}</div>
                  <div className="mt-1 text-[11px] font-medium" style={{ color: b.color }}>
                    {b.wordCount} Wörter →
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </SectionShell>

        {/* 07 · Categories — filter surface right before the master list */}
        <SectionShell
          anchorId="sec-categories"
          index={7}
          icon={ACCENT["sec-categories"].icon}
          accent={ACCENT["sec-categories"].accent}
          title="Wortschatz nach Kategorien"
          subtitle={`Tippe eine Kategorie, um „Alle Wörter" zu filtern`}
          action={
            category !== "all" ? (
              <button
                onClick={() => setCategory("all")}
                className="rounded-full border border-border/60 bg-card px-2.5 py-1 text-[10px] font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground"
              >
                Zurücksetzen
              </button>
            ) : (
              <span className="hidden text-[10px] text-muted-foreground sm:inline">
                Tippe zum Filtern ↓
              </span>
            )
          }
        >
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {CATEGORIES.slice(0, 12).map((c) => {
              const active = category === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => pickCategory(c.id)}
                  title={c.label}
                  className={`neu-card cat-glow relative flex min-w-0 flex-col items-center gap-2 overflow-hidden p-3 text-center transition sm:p-4 ${
                    active ? "ring-2 -translate-y-0.5 shadow-lg" : ""
                  }`}
                  style={{
                    ["--cat-rgb" as never]: hexToRgb(c.color),
                    ...(active
                      ? { boxShadow: `0 12px 30px -12px ${c.color}66`, borderColor: c.color }
                      : {}),
                  }}
                >
                  <span
                    className="cat-icon shrink-0 text-xl"
                    style={{ background: c.color + "22" }}
                  >
                    {c.icon}
                  </span>
                  <div className="w-full min-w-0">
                    <div className="line-clamp-2 hyphens-auto break-words text-[11px] font-semibold leading-snug sm:text-xs">
                      {c.label}
                    </div>
                    <div className="mt-0.5 truncate text-[10px] text-muted-foreground">
                      {categoryCount(c.id)} Wörter
                    </div>
                  </div>
                  {active && (
                    <span
                      className="absolute right-1.5 top-1.5 rounded-full px-1.5 py-0.5 text-[9px] font-bold text-white shadow"
                      style={{ background: c.color }}
                    >
                      aktiv
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </SectionShell>
        {/* 08 · All words (master results list) */}
        {(() => {
          const activeCat = category !== "all" ? CATEGORIES.find((c) => c.id === category) : null;
          const activeFilters: { label: string; onClear: () => void; color?: string }[] = [];
          if (activeCat)
            activeFilters.push({
              label: `${activeCat.icon} ${activeCat.label}`,
              onClear: () => setCategory("all"),
              color: activeCat.color,
            });
          if (cefr !== "all")
            activeFilters.push({ label: `Niveau ${cefr}`, onClear: () => setCefr("all") });
          if (pos !== "all")
            activeFilters.push({ label: POS_LABEL[pos], onClear: () => setPos("all") });
          if (query) activeFilters.push({ label: `"${query}"`, onClear: () => setQuery("") });
          return (
            <section
              id="sec-all"
              ref={resultsRef}
              className="relative scroll-mt-24 overflow-hidden rounded-3xl border-2 border-purple-200/70 bg-[linear-gradient(160deg,#F5F3FF_0%,#FDF2F8_55%,#EFF6FF_100%)] p-4 shadow-lg ring-1 ring-purple-100/50 dark:border-purple-800/50 dark:bg-[linear-gradient(160deg,rgba(76,29,149,0.18)_0%,rgba(131,24,67,0.18)_55%,rgba(30,58,138,0.18)_100%)] dark:ring-purple-900/30 sm:p-5"
            >
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 opacity-60 dark:opacity-30"
                style={{
                  background:
                    "radial-gradient(circle at 15% 0%, rgba(168,85,247,0.10), transparent 45%), radial-gradient(circle at 100% 100%, rgba(236,72,153,0.10), transparent 50%)",
                }}
              />
              <div className="relative">
                <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white text-lg shadow-md ring-1 ring-purple-200 dark:bg-slate-900 dark:ring-purple-800">
                      📖
                    </span>
                    <div>
                      <div className="mb-0.5 flex items-center gap-1.5">
                        <span className="rounded-full bg-purple-600/15 px-1.5 py-px text-[9px] font-black tracking-widest text-purple-700 dark:text-purple-300">
                          08
                        </span>
                        <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                          Abschnitt
                        </span>
                      </div>
                      <h2 className="text-base font-black tracking-tight sm:text-lg">
                        Alle Wörter · Ergebnisse ({filtered.length})
                      </h2>
                      <div className="text-[11px] text-muted-foreground sm:text-xs">
                        Vollständige Datenbank aller Vokabeln
                      </div>
                      <Fa className="fa-hint-xs">همهٔ واژه‌ها · نتایج</Fa>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-0.5 rounded-full bg-white/80 p-0.5 shadow-sm ring-1 ring-purple-200 dark:bg-slate-900/60 dark:ring-purple-800">
                      <button
                        onClick={() => setAllLayout("grid")}
                        aria-pressed={allLayout === "grid"}
                        title="Kartenansicht"
                        className={`grid h-7 w-7 place-items-center rounded-full transition ${
                          allLayout === "grid"
                            ? "bg-purple-600 text-white shadow-sm"
                            : "text-purple-700 hover:bg-purple-50 dark:text-purple-300"
                        }`}
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                          <rect x="3" y="3" width="8" height="8" rx="2" />
                          <rect x="13" y="3" width="8" height="8" rx="2" />
                          <rect x="3" y="13" width="8" height="8" rx="2" />
                          <rect x="13" y="13" width="8" height="8" rx="2" />
                        </svg>
                      </button>
                      <button
                        onClick={() => setAllLayout("list")}
                        aria-pressed={allLayout === "list"}
                        title="Listenansicht"
                        className={`grid h-7 w-7 place-items-center rounded-full transition ${
                          allLayout === "list"
                            ? "bg-purple-600 text-white shadow-sm"
                            : "text-purple-700 hover:bg-purple-50 dark:text-purple-300"
                        }`}
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                          <rect x="3" y="4" width="18" height="4" rx="2" />
                          <rect x="3" y="10" width="18" height="4" rx="2" />
                          <rect x="3" y="16" width="18" height="4" rx="2" />
                        </svg>
                      </button>
                    </div>
                    <button
                      onClick={() => {
                        setCefr("all");
                        setPos("all");
                        setCategory("all");
                        setQuery("");
                      }}
                      className="rounded-full bg-white/80 px-3 py-1.5 text-xs font-semibold text-purple-700 shadow-sm ring-1 ring-purple-200 transition hover:bg-white dark:bg-slate-900/60 dark:text-purple-300 dark:ring-purple-800"
                    >
                      Filter zurücksetzen
                    </button>
                  </div>
                </div>

                {activeFilters.length > 0 && (
                  <div className="mb-3 flex flex-wrap items-center gap-2 rounded-2xl border border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50 px-3 py-2.5 dark:border-purple-900/50 dark:from-purple-950/40 dark:to-pink-950/40">
                    <span className="text-[11px] font-bold uppercase tracking-widest text-purple-700 dark:text-purple-300">
                      Aktive Filter:
                    </span>
                    {activeFilters.map((f, i) => (
                      <span
                        key={i}
                        className="flex items-center gap-1 rounded-full bg-white px-2.5 py-1 text-xs font-semibold shadow-sm dark:bg-slate-900"
                        style={
                          f.color ? { color: f.color, boxShadow: `0 0 0 1px ${f.color}40` } : {}
                        }
                      >
                        {f.label}
                        <button
                          onClick={f.onClear}
                          className="grid h-4 w-4 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
                          aria-label="Entfernen"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                )}

                {/* Filters */}
                <div className="mb-4 flex flex-wrap items-center gap-2 rounded-2xl border border-border/60 bg-secondary/40 p-3">
                  <Chip active={cefr === "all"} onClick={() => setCefr("all")} accent>
                    Alle
                  </Chip>
                  {CEFR_LEVELS.map((l) => (
                    <Chip key={l} active={cefr === l} onClick={() => setCefr(l)}>
                      {l}
                    </Chip>
                  ))}
                  <div className="ml-2 hidden text-xs text-muted-foreground sm:block">·</div>
                  <select
                    value={pos}
                    onChange={(e) => setPos(e.target.value as DictPos | "all")}
                    className="rounded-full border border-border/60 bg-card px-3 py-1.5 text-xs font-medium outline-none hover:bg-muted"
                  >
                    <option value="all">Alle Wortarten</option>
                    {Object.entries(POS_LABEL).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </select>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="rounded-full border border-border/60 bg-card px-3 py-1.5 text-xs font-medium outline-none hover:bg-muted"
                  >
                    <option value="all">Alle Kategorien</option>
                    {CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div
                  className={
                    allLayout === "grid"
                      ? "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                      : "flex flex-col gap-2"
                  }
                >
                  {filtered.slice(0, visibleCount).map((w) => (
                    <WordCard
                      key={w.id}
                      word={w}
                      variant={allLayout === "list" ? "row" : "grid"}
                      progress={progress[w.id] ?? Math.min(90, w.frequency)}
                      bookmarked={bookmarks.has(w.id)}
                      inLeitner={leitner.has(w.id)}
                      onOpen={(event) => openWord(w.id, event)}
                      onToggleBookmark={() => toggleBm(w.id)}
                      onToggleLeitner={() => toggleLeitner(w.id, w.headword)}
                    />
                  ))}
                </div>
                {visibleCount < filtered.length && (
                  <div className="mt-5 flex flex-col items-center gap-2">
                    <div className="text-xs text-muted-foreground">
                      {Math.min(visibleCount, filtered.length)} von {filtered.length}
                    </div>
                    <button
                      onClick={() => setVisibleCount((v) => v + PAGE_SIZE)}
                      className="rounded-2xl bg-purple-600 px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:bg-purple-700 hover:shadow-lg active:scale-[0.98]"
                    >
                      {PAGE_SIZE} weitere Wörter laden
                    </button>
                  </div>
                )}
              </div>
            </section>
          );
        })()}
      </div>

      {/* ============ RIGHT: Detail panel ============ */}
      <div className="sticky top-5 hidden h-[calc(100vh-2.5rem)] self-start lg:block">
        <AnimatePresence mode="wait">
          {selectedWord ? (
            <WordDetailPanel
              word={selectedWord}
              favorite={favorites.has(selectedWord.id)}
              inLeitner={leitner.has(selectedWord.id)}
              bookmarked={bookmarks.has(selectedWord.id)}
              onClose={() => setSelectedId(null)}
              onToggleFavorite={() => toggleFv(selectedWord.id)}
              onToggleLeitner={() => toggleLeitner(selectedWord.id)}
              onToggleBookmark={() => toggleBm(selectedWord.id)}
              onOpenWord={openWord}
            />
          ) : (
            <motion.div
              key="placeholder"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="glass flex h-full flex-col items-center justify-center gap-4 rounded-3xl p-8 text-center"
            >
              <div className="text-6xl">📖</div>
              <div>
                <h3 className="text-lg font-semibold">Wähle ein Wort</h3>
                <Fa className="fa-hint-xs">یک واژه را انتخاب کن</Fa>
                <p className="mt-1 text-sm text-muted-foreground">
                  Tippe auf ein Wort links, um Übersetzung, Grammatik, Beispiele und KI-Tipps zu
                  sehen.
                </p>
                <Fa className="fa-hint-xs">
                  روی هر واژه بزنید تا ترجمه، گرامر، مثال‌ها و راهنمای هوشمند را ببینید.
                </Fa>
              </div>
              <div className="mt-2 flex flex-wrap justify-center gap-1.5">
                {FEATURED_WORDS.slice(0, 5).map((w) => (
                  <button
                    key={w.id}
                    onClick={(event) => openWord(w.id, event)}
                    className="rounded-full bg-card px-3 py-1 text-xs font-medium shadow-sm hover:bg-muted"
                  >
                    {w.headword}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Mobile anchored detail popover */}
      {mobileDetailPopover}
    </div>
  );
}

// ============ Small helpers ============

function Chip({
  children,
  active,
  onClick,
  accent,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
  accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${
        active
          ? accent
            ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md"
            : "bg-primary text-primary-foreground shadow-md"
          : "border border-border/60 bg-card hover:bg-muted"
      }`}
    >
      {children}
    </button>
  );
}

function hexToRgb(hex: string): string {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `${r} ${g} ${b}`;
}

function SearchIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      className="text-muted-foreground"
    >
      <circle cx="11" cy="11" r="7" />
      <path d="M20 20l-3.5-3.5" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      className="text-muted-foreground"
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </svg>
  );
}

/* ============ Proverbs & Idioms (Teaser) ============ */
function ProverbsSection({ accent, anchorId }: { accent: string; anchorId: string }) {
  const preview = PROVERBS.slice(0, 3);
  const sprichwoerter = PROVERBS.filter((p) => p.kind === "sprichwort").length;
  const redewendungen = PROVERBS.length - sprichwoerter;
  return (
    <SectionShell
      anchorId={anchorId}
      index={5}
      icon="💬"
      accent={accent}
      title="Sprichwörter & Redewendungen"
      subtitle={`${sprichwoerter} Sprichwörter · ${redewendungen} Redewendungen`}
      action={
        <Link
          to="/dictionary/sprichwoerter"
          className="shrink-0 rounded-full px-3.5 py-1.5 text-xs font-bold text-white shadow-sm transition hover:-translate-y-0.5"
          style={{ background: `linear-gradient(135deg, ${accent}, ${accent}cc)` }}
        >
          Alle ansehen →
        </Link>
      }
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {preview.map((p) => (
          <ProverbCard key={p.id} p={p} />
        ))}
      </div>
      <div className="mt-5 flex justify-center">
        <Link
          to="/dictionary/sprichwoerter"
          className="rounded-2xl border border-border/60 bg-card px-5 py-2 text-sm font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground"
        >
          Alle {PROVERBS.length} Ausdrücke auf einer eigenen Seite
        </Link>
      </div>
    </SectionShell>
  );
}

function MiniStat({
  icon,
  label,
  value,
  delta,
  accent,
}: {
  icon: string;
  label: string;
  value: number;
  delta?: number;
  tint?: string;
  accent: string;
}) {
  return (
    <div
      className="group relative flex min-w-0 items-center gap-2.5 overflow-hidden rounded-2xl border border-border/60 bg-card p-3 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
      style={{
        backgroundImage: `linear-gradient(135deg, color-mix(in oklab, ${accent} 8%, transparent), transparent 60%)`,
      }}
    >
      {/* top accent bar */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[3px]"
        style={{
          background: `linear-gradient(90deg, ${accent}, color-mix(in oklab, ${accent} 30%, transparent))`,
        }}
      />
      {/* soft corner glow */}
      <span
        aria-hidden
        className="pointer-events-none absolute -right-8 -top-8 h-20 w-20 rounded-full opacity-40 blur-2xl"
        style={{ background: `radial-gradient(circle, ${accent}66, transparent 70%)` }}
      />
      <span
        className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl text-base ring-1"
        style={{
          background: `linear-gradient(135deg, color-mix(in oklab, ${accent} 22%, transparent), color-mix(in oklab, ${accent} 8%, transparent))`,
          color: accent,
          boxShadow: `0 6px 16px -8px ${accent}80`,
          // @ts-expect-error CSS custom prop
          "--tw-ring-color": `${accent}33`,
        }}
      >
        {icon}
      </span>
      <div className="relative min-w-0 flex-1">
        <div className="truncate text-[9px] font-semibold uppercase tracking-widest text-muted-foreground">
          {label}
        </div>
        <div className="flex items-baseline gap-1.5">
          <span className="text-lg font-black leading-none tabular-nums text-foreground">
            {value.toLocaleString("de")}
          </span>
          {typeof delta === "number" && (
            <span
              className="rounded-full px-1.5 py-px text-[9px] font-bold"
              style={{ background: "rgba(16,185,129,0.12)", color: "#059669" }}
            >
              +{delta}%
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

const CEFR_SPLIT = [
  { lvl: "A1", pct: 26, color: "#10B981" }, // emerald
  { lvl: "A2", pct: 22, color: "#22C55E" }, // green
  { lvl: "B1", pct: 20, color: "#3B82F6" }, // blue
  { lvl: "B2", pct: 16, color: "#6366F1" }, // indigo
  { lvl: "C1", pct: 10, color: "#A855F7" }, // purple
  { lvl: "C2", pct: 6, color: "#EC4899" }, // pink
] as const;

function WortschatzHero({
  bookmarksCount,
  customCount,
  leitnerCount,
}: {
  bookmarksCount: number;
  customCount: number;
  leitnerCount: number;
}) {
  const t = SECTION_THEME.dictionary;
  const active = bookmarksCount + customCount;
  const accent = "#2563EB"; // blue-forward
  const remaining = 100 - VOCAB_STATS.levelProgress;

  return (
    <section className="neu-card relative overflow-hidden p-4 sm:p-6">
      {/* Left accent stripe — matches SectionShell */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-y-6 left-0 w-1 rounded-r-full"
        style={{ background: `linear-gradient(180deg, ${accent}, ${accent}55)` }}
      />
      {/* Soft accent glow in the top-right */}
      <span
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-30 blur-3xl"
        style={{ background: `radial-gradient(circle, ${accent}80, transparent 70%)` }}
      />

      {/* Header — mirrors SectionShell layout */}
      <header className="relative mb-5 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-xl shadow-sm ring-1"
            style={{
              background: `linear-gradient(135deg, ${accent}22, ${accent}0d)`,
              color: accent,
              boxShadow: `0 6px 18px -8px ${accent}80`,
              // @ts-expect-error CSS custom prop
              "--tw-ring-color": `${accent}40`,
            }}
          >
            <span aria-hidden>📊</span>
          </span>
          <div className="min-w-0">
            <div className="mb-0.5 flex items-center gap-1.5">
              <span
                className="rounded-full px-1.5 py-px text-[9px] font-black tracking-widest"
                style={{ background: `${accent}1a`, color: accent }}
              >
                02
              </span>
              <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                Abschnitt
              </span>
            </div>
            <h2 className="truncate text-base font-black tracking-tight sm:text-lg">
              Dein Wortschatz
            </h2>
            <p className="mt-0.5 truncate text-[11px] text-muted-foreground sm:text-xs">
              Fortschritt, Niveau und Verteilung deiner Wörter
            </p>
          </div>
        </div>
        <div
          className="flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold tracking-wide"
          style={{
            background: `${accent}0d`,
            borderColor: `${accent}33`,
            color: accent,
          }}
        >
          <span
            aria-hidden
            className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.7)]"
          />
          <span className="tabular-nums">{VOCAB_STATS.streak}</span>
          <span className="text-muted-foreground">Tage-Serie</span>
        </div>
      </header>

      {/* Level + active words summary */}
      <div className="relative grid gap-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
        <div className="min-w-0">
          <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
            Aktiver Wortschatz
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span
              className="text-4xl font-black leading-none tracking-tight tabular-nums sm:text-5xl"
              style={{ color: accent }}
            >
              {active.toLocaleString("de")}
            </span>
            <span className="text-sm font-medium text-muted-foreground">Wörter</span>
          </div>
          <p className="mt-2 text-xs leading-snug text-muted-foreground">
            Noch <span className="font-bold text-foreground tabular-nums">{remaining}%</span> bis
            zum nächsten Niveau.
          </p>
        </div>

        {/* Level ring */}
        <div className="relative grid h-24 w-24 shrink-0 place-items-center sm:h-28 sm:w-28">
          <svg viewBox="0 0 40 40" className="absolute inset-0 -rotate-90">
            <defs>
              <linearGradient id="wsRing" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#60A5FA" />
                <stop offset="100%" stopColor="#2563EB" />
              </linearGradient>
            </defs>
            <circle
              cx="20"
              cy="20"
              r="17"
              fill="none"
              stroke="currentColor"
              className="text-muted"
              strokeWidth="2.6"
            />
            <circle
              cx="20"
              cy="20"
              r="17"
              fill="none"
              stroke="url(#wsRing)"
              strokeWidth="2.6"
              strokeDasharray={`${VOCAB_STATS.levelProgress}, 100`}
              pathLength={100}
              strokeLinecap="round"
            />
          </svg>
          <div className="text-center leading-none">
            <div className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
              Niveau
            </div>
            <div
              className="mt-1 text-2xl font-black tracking-tight sm:text-3xl"
              style={{ color: accent }}
            >
              {VOCAB_STATS.level}
            </div>
            <div className="mt-1 text-[10px] font-semibold tabular-nums text-muted-foreground">
              {VOCAB_STATS.levelProgress}%
            </div>
          </div>
        </div>
      </div>

      {/* Progress rail */}
      <div className="relative mt-5">
        <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          <span>Fortschritt</span>
          <span className="tabular-nums text-foreground">{VOCAB_STATS.levelProgress} / 100</span>
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full transition-[width] duration-700"
            style={{
              width: `${VOCAB_STATS.levelProgress}%`,
              background: "linear-gradient(90deg, #60A5FA 0%, #3B82F6 55%, #2563EB 100%)",
              boxShadow: "0 0 12px rgba(59,130,246,0.45)",
            }}
          />
        </div>
      </div>

      {/* ── Stat grid ── */}
      <div className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-3">
        <MiniStat icon="📚" label="Gesamt" value={VOCAB_STATS.total} accent={accent} />
        <MiniStat
          icon="✅"
          label="Bekannt"
          value={VOCAB_STATS.known}
          delta={VOCAB_STATS.knownDelta}
          accent="#10B981"
        />
        <MiniStat
          icon="📖"
          label="Am Lernen"
          value={VOCAB_STATS.learning}
          delta={VOCAB_STATS.learningDelta}
          accent="#F59E0B"
        />
        <MiniStat icon="🔖" label="Lesezeichen" value={bookmarksCount} accent={t.accent} />
        <MiniStat icon="🎴" label="Leitner" value={leitnerCount} accent="#059669" />
        <MiniStat icon="✨" label="Eigene" value={customCount} accent="#EC4899" />
      </div>

      {/* ── CEFR distribution — colorful per level ── */}
      <div className="mt-5 rounded-2xl border border-border/60 bg-card/60 p-3 sm:p-4">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
            Verteilung nach Niveau
          </div>
          <div
            className="rounded-full px-2 py-0.5 text-[10px] font-bold"
            style={{ background: `${accent}14`, color: accent }}
          >
            Ziel: B2
          </div>
        </div>
        <div className="flex h-3 w-full gap-[3px] overflow-hidden rounded-full bg-muted p-[2px]">
          {CEFR_SPLIT.map(({ lvl, pct, color }) => (
            <div
              key={lvl}
              title={`${lvl} · ${pct}%`}
              style={{
                width: `${pct}%`,
                background: color,
              }}
              className="rounded-full transition hover:brightness-110"
            />
          ))}
        </div>

        <div className="mt-3 grid grid-cols-3 gap-x-3 gap-y-1.5 sm:grid-cols-6">
          {CEFR_SPLIT.map(({ lvl, pct, color }) => (
            <div key={lvl} className="flex items-center gap-1.5">
              <span
                className="h-2.5 w-2.5 rounded-full ring-2"
                style={{
                  background: color,
                  // @ts-expect-error CSS custom prop
                  "--tw-ring-color": `${color}33`,
                }}
              />
              <span className="text-[11px] font-bold text-foreground">{lvl}</span>
              <span className="text-[10px] tabular-nums text-muted-foreground">{pct}%</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
