import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Calendar, MapPin, Target } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { MOCK_EVENTS, type DeusiEvent } from "@/lib/deusi/events/mockEvents";
import { mergedGroups, totalStats } from "@/lib/deusi/events/store";
import { SectionHero } from "@/components/deusi/SectionHero";

export const Route = createFileRoute("/events/")({
  head: () => ({
    meta: [
      { title: "Events — DEUSI" },
      {
        name: "description",
        content: "Deutsche Sprach-Events, Stammtische und Gruppen zum Üben finden.",
      },
      { property: "og:title", content: "Events — DEUSI" },
      {
        property: "og:description",
        content: "Deutsche Sprach-Events, Stammtische und Gruppen zum Üben finden.",
      },
    ],
  }),
  component: EventsPage,
});

function EventsPage() {
  return (
    <div className="space-y-8 pb-16">
      <SectionHero
        sectionKey="events"
        right={
          <div className="flex flex-wrap gap-2">
            {["Alle", "Diese Woche", "Online", "Vor Ort"].map((f, i) => (
              <button
                key={f}
                className={`rounded-full px-3 py-1.5 text-xs font-semibold backdrop-blur transition ring-1 ring-white/20 ${
                  i === 0 ? "bg-white text-foreground" : "bg-white/15 text-white hover:bg-white/25"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        }
      />

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {MOCK_EVENTS.map((ev, i) => (
          <EventCard key={ev.id} event={ev} index={i} />
        ))}
      </div>
    </div>
  );
}

function EventCard({ event, index }: { event: DeusiEvent; index: number }) {
  // Use the same seed data for accurate participant counts in the list
  const groups = event.groups
    ? mergedGroups(event, { reservations: {}, myRegistration: null })
    : [];
  const stats = totalStats(event, groups);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.45 }}
      className="group neu-card overflow-hidden"
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <img
          src={event.cover}
          alt={event.title}
          loading="lazy"
          width={1024}
          height={640}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-4">
          <span className="glass rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-foreground">
            {event.organizer.name}
          </span>
          <span className="glass rounded-full px-3 py-1 text-[11px] font-semibold text-foreground">
            {event.levelSummary}
          </span>
        </div>
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/45 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 flex items-center justify-between p-4 text-white">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-wider opacity-80">
              {event.weekday} · {event.time}
            </div>
            <h3 className="mt-0.5 text-lg font-bold leading-tight drop-shadow">{event.title}</h3>
          </div>
        </div>
      </div>

      <div className="space-y-4 p-5">
        <p className="text-sm text-muted-foreground line-clamp-2">{event.shortDescription}</p>

        <div className="grid grid-cols-3 gap-2 text-xs">
          <InfoTile icon={Calendar} label="Datum" value={event.dateShort} />
          <InfoTile icon={MapPin} label="Ort" value={event.locationName} />
          <InfoTile icon={Target} label="Niveau" value={event.levelSummary} />
        </div>

        <div className="flex items-end justify-between">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              Teilnehmer
            </div>
            <div className="text-sm font-semibold">
              {stats.participants} / {stats.total}
              <span className="ml-2 text-xs font-medium text-muted-foreground">
                · {stats.remaining} frei
              </span>
            </div>
          </div>
          {event.hasRegistration ? (
            <Link
              to="/events/$eventId"
              params={{ eventId: event.id }}
              className="rounded-full bg-foreground px-4 py-2 text-xs font-semibold text-background transition hover:opacity-90"
            >
              Anmelden →
            </Link>
          ) : (
            <button
              disabled
              className="rounded-full border border-border px-4 py-2 text-xs font-semibold text-muted-foreground"
              title="Bald verfügbar"
            >
              Bald verfügbar
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function InfoTile({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl bg-secondary/60 p-2.5">
      <div className="flex items-center gap-1 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        <Icon className="h-3 w-3" aria-hidden />
        <span>{label}</span>
      </div>
      <div className="mt-0.5 truncate text-xs font-semibold text-foreground">{value}</div>
    </div>
  );
}
