import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Play,
  Clock,
  Film as FilmIcon,
  Sparkles,
  Languages,
  MousePointerClick,
  Star,
} from "lucide-react";
import { type Film } from "@/lib/deusi/mockKino";
import { useFilms } from "@/lib/api/useMedia";
import { useDeusi } from "@/lib/deusi/store";
import { SectionHero } from "@/components/deusi/SectionHero";
import { HeroSearch } from "@/components/deusi/HeroSearch";
import { FaHint } from "@/components/deusi/FaHint";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";

export const Route = createFileRoute("/kino/")({
  head: () => ({
    meta: [
      { title: "Deutsches Kino — DEUSI" },
      {
        name: "description",
        content: "Deutsche Filme mit intelligenten zweisprachigen Untertiteln (Deutsch/Persisch).",
      },
    ],
  }),
  component: KinoIndex,
});

const LEVELS = ["Alle", "A1", "A2", "B1", "B2", "C1"] as const;

function KinoIndex() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);
  const [level, setLevel] = useState<(typeof LEVELS)[number]>("Alle");
  const [q, setQ] = useState("");

  // دیتای فیلم‌ها از لایهٔ API (بک‌اند یا fallback محلی) — سشن ۵.
  const { films } = useFilms({ perPage: 200 });

  const featured = films[0];
  const rest = films.slice(1);

  const filtered = useMemo(
    () =>
      films.filter((f) => {
        if (level !== "Alle" && f.level !== level) return false;
        if (
          q &&
          !`${f.title} ${f.titleFa} ${f.director} ${f.genre.join(" ")}`
            .toLowerCase()
            .includes(q.toLowerCase())
        )
          return false;
        return true;
      }),
    [level, q, films],
  );

  const suggestions = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return [];
    return films
      .filter((f) =>
        `${f.title} ${f.titleFa} ${f.director} ${f.genre.join(" ")}`.toLowerCase().includes(t),
      )
      .slice(0, 6);
  }, [q, films]);

  const isFiltering = level !== "Alle" || q.trim().length > 0;
  const totalMinutes = films.reduce((sum, f) => {
    const m = f.duration.match(/(?:(\d+)h)?\s*(\d+)?/);
    const h = m?.[1] ? parseInt(m[1], 10) : 0;
    const min = m?.[2] ? parseInt(m[2], 10) : 0;
    return sum + h * 60 + min;
  }, 0);

  if (!currentUser) return null;

  return (
    <div className="space-y-10 animate-fade pb-10">
      <SectionHero
        sectionKey="movies"
        allowOverflow
        right={
          <HeroSearch
            value={q}
            onValueChange={setQ}
            placeholder="Film, Regisseur, Genre…"
            ariaLabel="Filme durchsuchen"
            emptyText="Keine Filme"
            className="flex-1"
            items={suggestions.map((f) => ({
              id: f.id,
              title: f.title,
              sub: `${f.director} · ${f.genre.join(", ")}`,
              badge: f.level,
              glyph: "🎬",
              color: "#0EA5E9",
            }))}
            totalCount={filtered.length}
            onSelect={(id) => router.navigate({ to: "/kino/$filmId", params: { filmId: id } })}
            onSubmit={() =>
              document.getElementById("alle-filme")?.scrollIntoView({ behavior: "smooth" })
            }
          />
        }
      />
      {/* HERO */}

      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-[28px] border border-border/60"
      >
        {/* Backdrop */}
        <div className="absolute inset-0" style={{ background: featured.poster }} aria-hidden />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(115deg, rgba(10,10,12,.88) 0%, rgba(10,10,12,.72) 45%, rgba(10,10,12,.18) 100%)",
          }}
          aria-hidden
        />
        {/* Grain / vignette accent */}
        <div
          className="pointer-events-none absolute inset-0 opacity-40 mix-blend-overlay"
          style={{
            background:
              "radial-gradient(120% 80% at 90% 10%, rgba(255,255,255,.18), transparent 55%), radial-gradient(120% 80% at 10% 110%, rgba(0,0,0,.4), transparent 60%)",
          }}
          aria-hidden
        />

        <div className="relative grid gap-8 p-6 md:grid-cols-[1.35fr_1fr] md:p-10 lg:p-12">
          <div className="min-w-0 text-white">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] backdrop-blur">
                <Sparkles className="h-3 w-3" aria-hidden />
                Empfohlen
              </span>
              <span className="rounded-full bg-[color:var(--flag-red)] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em]">
                {featured.level}
              </span>
              <span className="rounded-full bg-white/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] backdrop-blur">
                {featured.year}
              </span>
            </div>

            <h2 className="mt-5 text-4xl font-black leading-[1.02] tracking-tight md:text-6xl">
              {featured.title}
            </h2>
            <p className="mt-1 text-lg font-medium text-white/70 md:text-xl" dir="rtl">
              {featured.titleFa}
            </p>

            <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/80 md:text-base">
              {featured.synopsis}
            </p>

            <div className="mt-6 flex flex-wrap items-center gap-4 text-xs text-white/70">
              <span className="inline-flex items-center gap-1.5">
                <FilmIcon className="h-3.5 w-3.5" aria-hidden />
                {featured.director}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" aria-hidden />
                {featured.duration}
              </span>
              <span className="inline-flex flex-wrap gap-1.5">
                {featured.genre.map((g) => (
                  <span
                    key={g}
                    className="rounded-full border border-white/25 px-2 py-0.5 text-[10px] font-semibold"
                  >
                    {g}
                  </span>
                ))}
              </span>
            </div>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Link
                to="/kino/$filmId"
                params={{ filmId: featured.id }}
                className="group inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-bold text-[color:var(--flag-black)] shadow-2xl transition hover:-translate-y-0.5 hover:shadow-[0_20px_50px_-15px_rgba(255,255,255,.5)]"
              >
                <Play className="h-4 w-4 fill-current" aria-hidden />
                Jetzt ansehen
              </Link>
              <a
                href="#alle-filme"
                className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-3 text-sm font-semibold text-white/90 backdrop-blur transition hover:bg-white/10"
              >
                Alle Filme durchstöbern
              </a>
            </div>
          </div>

          {/* Right-side "poster" card */}
          <div className="relative hidden min-w-0 md:block">
            <motion.div
              initial={{ opacity: 0, scale: 0.96, rotate: 3 }}
              animate={{ opacity: 1, scale: 1, rotate: 3 }}
              transition={{ delay: 0.15, duration: 0.6 }}
              className="absolute right-4 top-4 aspect-[3/4] w-full max-w-[280px] rounded-3xl border border-white/20 shadow-[0_40px_80px_-30px_rgba(0,0,0,.7)]"
              style={{ background: featured.poster, rotate: "3deg" } as React.CSSProperties}
              aria-hidden
            >
              <div className="absolute inset-x-0 bottom-0 rounded-b-3xl bg-gradient-to-t from-black/80 to-transparent p-4">
                <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/80">
                  DEUSI Kino · Empfehlung
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.94, rotate: -6 }}
              animate={{ opacity: 1, scale: 1, rotate: -6 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="absolute right-24 top-16 hidden aspect-[3/4] w-[220px] rounded-3xl border border-white/20 opacity-70 shadow-[0_30px_60px_-25px_rgba(0,0,0,.6)] lg:block"
              style={
                {
                  background: rest[0]?.poster ?? featured.poster,
                  rotate: "-6deg",
                } as React.CSSProperties
              }
              aria-hidden
            />
          </div>
        </div>
      </motion.section>

      {/* FEATURE STRIP */}
      <section className="grid gap-3 sm:grid-cols-3">
        <FeatureBadge
          icon={Languages}
          title="Zweisprachige Untertitel"
          subtitle="Deutsch & Persisch, synchron"
        />
        <FeatureBadge
          icon={MousePointerClick}
          title="Wort-für-Wort Übersetzung"
          subtitle="Ein Klick — Bedeutung, Wortart, Notiz"
        />
        <FeatureBadge
          icon={Star}
          title="Kuratierte Auswahl"
          subtitle="Filme nach GER-Niveau sortiert"
        />
      </section>

      {/* TOOLBAR */}
      <section id="alle-filme" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-2xl font-black tracking-tight md:text-3xl">Alle Filme</h2>
            <FaHint size="sm">همه فیلم‌ها</FaHint>
            <p className="mt-1 text-sm text-muted-foreground">
              {films.length} Filme · {Math.round(totalMinutes / 60)} Std. zweisprachiges Kino
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Niveau
          </span>
          {LEVELS.map((l) => (
            <button
              key={l}
              onClick={() => setLevel(l)}
              className={`rounded-full px-4 py-1.5 text-xs font-bold transition ${
                level === l
                  ? "bg-[color:var(--flag-black)] text-[color:var(--background)] shadow-md"
                  : "glass text-foreground hover:-translate-y-0.5"
              }`}
              aria-pressed={level === l}
            >
              {l}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((film, i) => (
            <FilmCard key={film.id} film={film} index={i} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="glass-strong rounded-3xl p-10 text-center">
            <div className="text-sm font-semibold text-foreground">Keine Filme gefunden.</div>
            <FaHint size="sm" className="mt-1">
              فیلمی با این جست‌وجو پیدا نشد — فیلترها را تغییر بده.
            </FaHint>
          </div>
        )}

        {!isFiltering && (
          <p className="pt-2 text-center text-[11px] text-muted-foreground">
            Bald mehr Filme · به‌زودی فیلم‌های بیشتر
          </p>
        )}
      </section>
    </div>
  );
}

function FilmCard({ film, index }: { film: Film; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.04 * index, duration: 0.4 }}
    >
      <Link
        to="/kino/$filmId"
        params={{ filmId: film.id }}
        className="group block overflow-hidden rounded-3xl border border-border bg-card transition hover:-translate-y-1 hover:border-transparent hover:shadow-[0_28px_60px_-25px_rgba(0,0,0,.35)]"
      >
        {/* Poster */}
        <div
          className="relative aspect-[3/4] w-full overflow-hidden"
          style={{ background: film.poster }}
        >
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, rgba(0,0,0,.05) 0%, rgba(0,0,0,.15) 45%, rgba(0,0,0,.8) 100%)",
            }}
            aria-hidden
          />
          <div className="absolute inset-x-0 top-0 flex items-start justify-between p-4 text-white">
            <span className="rounded-full bg-black/40 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider backdrop-blur">
              {film.level}
            </span>
            <span className="flex items-center gap-1">
              <span className="rounded-full bg-black/40 px-2.5 py-1 text-[10px] font-bold backdrop-blur">
                {film.year}
              </span>
              <BookmarkButton
                type="film"
                id={film.id}
                title={film.title}
                sub={`${film.genre.join(" · ")} · ${film.duration}`}
                level={film.level}
                to={`/kino/${film.id}`}
                size={16}
                className="h-7 w-7 bg-black/40 backdrop-blur"
              />
            </span>
          </div>

          <div className="absolute inset-x-0 bottom-0 p-5 text-white">
            <div className="text-2xl font-black leading-tight drop-shadow-lg">{film.title}</div>
            <div className="mt-1 text-xs font-medium text-white/85" dir="rtl">
              {film.titleFa}
            </div>
          </div>

          {/* Hover play */}
          <div className="pointer-events-none absolute inset-0 grid place-items-center opacity-0 transition group-hover:opacity-100">
            <div className="flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-bold text-[color:var(--flag-black)] shadow-2xl">
              <Play className="h-4 w-4 fill-current" aria-hidden />
              Ansehen
            </div>
          </div>
        </div>

        {/* Meta */}
        <div className="space-y-3 p-4">
          <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
            <span className="inline-flex min-w-0 items-center gap-1.5">
              <FilmIcon className="h-3.5 w-3.5 shrink-0" aria-hidden />
              <span className="truncate">{film.director}</span>
            </span>
            <span className="inline-flex shrink-0 items-center gap-1">
              <Clock className="h-3.5 w-3.5" aria-hidden />
              {film.duration}
            </span>
          </div>

          <p className="line-clamp-2 text-xs leading-relaxed text-muted-foreground">
            {film.synopsis}
          </p>

          <div className="flex flex-wrap gap-1.5">
            {film.genre.map((g) => (
              <span
                key={g}
                className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold text-foreground/80"
              >
                {g}
              </span>
            ))}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

function FeatureBadge({
  icon: Icon,
  title,
  subtitle,
}: {
  icon: typeof Sparkles;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="glass flex items-center gap-3 rounded-2xl p-4">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[color:var(--flag-red)]/10 text-[color:var(--flag-red)]">
        <Icon className="h-5 w-5" aria-hidden />
      </div>
      <div className="min-w-0">
        <div className="truncate text-sm font-bold">{title}</div>
        <div className="truncate text-[11px] text-muted-foreground">{subtitle}</div>
      </div>
    </div>
  );
}
