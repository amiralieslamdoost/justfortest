import { createFileRoute, Link } from "@tanstack/react-router";
import { HeroSearch } from "@/components/deusi/HeroSearch";
import { useState } from "react";
import {
  BookOpen,
  Search,
  BookText,
  Languages,
  Brain,
  Layers,
  Sparkles,
  Headphones,
  Music,
  Film,
  Newspaper,
  Calendar,
  Award,
  BarChart3,
  MessageCircleQuestion,
  ArrowRight,
  ChevronDown,
  Image as ImageIcon,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/docs")({
  component: DocsPage,
  head: () => ({
    meta: [
      { title: "راهنمای دئوسی | DEUSI" },
      {
        name: "description",
        content:
          "راهنمای جامع دئوسی: آشنایی با بخش‌ها، امکانات پیشرفته، شروع سریع و پاسخ به سوالات رایج.",
      },
      { property: "og:title", content: "راهنمای دئوسی | DEUSI" },
      {
        property: "og:description",
        content:
          "راهنمای جامع دئوسی: آشنایی با بخش‌ها، امکانات پیشرفته، شروع سریع و پاسخ به سوالات رایج.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/docs" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "/docs" }],
  }),
});

function DocsPage() {
  const [query, setQuery] = useState("");
  const [openFeature, setOpenFeature] = useState<string>(FEATURES[0].id);

  const q = query.trim().toLowerCase();
  const features = q
    ? FEATURES.filter(
        (f) =>
          f.title.toLowerCase().includes(q) ||
          f.desc.includes(query.trim()) ||
          f.details.some((d) => d.includes(query.trim())),
      )
    : FEATURES;

  const activeFeature = features.find((f) => f.id === openFeature) ?? features[0] ?? FEATURES[0];

  return (
    <div dir="rtl" className="fa min-h-[calc(100vh-2rem)] pb-12">
      {/* Back to dashboard */}
      <div className="mb-4 flex justify-start">
        <Button asChild variant="outline" className="gap-2">
          <Link to="/dashboard">
            <ArrowRight className="h-5 w-5" />
            بازگشت به داشبورد
          </Link>
        </Button>
      </div>

      {/* Hero */}
      <section className="relative rounded-3xl bg-gradient-to-br from-[var(--accent)] via-[var(--secondary)] to-[var(--background)] p-6 sm:p-10 lg:p-12">
        <div className="relative z-10 mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-2xl bg-[var(--card)] shadow-lg">
            <BookOpen className="h-8 w-8 text-[var(--accent-foreground)]" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-[var(--foreground)] sm:text-4xl lg:text-5xl">
            راهنمای دئوسی
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-[var(--muted-foreground)] sm:text-lg">
            هر آنچه برای استفاده حرفه‌ای از دئوسی نیاز دارید: از شروع سریع تا عمیق‌ترین امکانات، همه
            در یک جا.
          </p>

          <div
            className="mx-auto mt-8 max-w-xl text-right [&>div:first-child]:!border-border [&>div:first-child]:!bg-[var(--card)] [&_input]:!text-[var(--foreground)] [&_input]:placeholder:!text-[var(--muted-foreground)] [&_svg]:!text-[var(--muted-foreground)]"
            dir="rtl"
          >
            <HeroSearch
              value={query}
              onValueChange={setQuery}
              placeholder="جستجو در راهنما..."
              ariaLabel="جستجو در راهنما"
              emptyText="نتیجه‌ای نیست"
              items={(q ? features : []).slice(0, 6).map((f) => ({
                id: f.id,
                title: f.title,
                sub: f.desc,
                glyph: <f.icon className="h-4 w-4" />,
                color: "#7c5cff",
              }))}
              totalCount={features.length}
              onSelect={(id) => {
                setOpenFeature(id);
                document
                  .getElementById("docs-features")
                  ?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
              onSubmit={() =>
                document
                  .getElementById("docs-features")
                  ?.scrollIntoView({ behavior: "smooth", block: "start" })
              }
            />
          </div>
        </div>
      </section>

      {/* Quick start */}
      <section className="mt-8">
        <SectionTitle>شروع سریع</SectionTitle>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <StepCard
            step="۱"
            title="ثبت‌نام و ورود"
            desc="با ساخت حساب کاربری، پیشرفت شما ذخیره می‌شود و در هر دستگاه می‌توانید ادامه دهید."
          />
          <StepCard
            step="۲"
            title="داشبورد خود را ببینید"
            desc="روزانه هدف یادگیری، رکورد روزهای متوالی و خلاصه‌ای از آخرین فعالیت‌ها را اینجا دارید."
          />
          <StepCard
            step="۳"
            title="یک بخش را انتخاب کنید"
            desc="از دیکشنری و گرامر تا موسیقی و پادکست: هر بخش برای تقویت یک مهارت خاص طراحی شده."
          />
        </div>
      </section>

      {/* Features menu */}
      <section id="docs-features" className="mt-10 scroll-mt-24">
        <SectionTitle>بخش‌های اصلی سایت</SectionTitle>
        <p className="mb-4 text-sm text-[var(--muted-foreground)]">
          یک بخش را از منوی کناری انتخاب کنید تا آموزش کامل آن نمایش داده شود.
        </p>

        {features.length === 0 ? (
          <p className="text-sm text-[var(--muted-foreground)]">
            نتیجه‌ای برای «{query}» پیدا نشد.
          </p>
        ) : (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-[260px_minmax(0,1fr)]">
            <nav className="neu-card max-h-[520px] overflow-y-auto p-2 lg:sticky lg:top-4">
              {features.map((f) => {
                const Icon = f.icon;
                const isActive = f.id === activeFeature.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setOpenFeature(f.id)}
                    aria-current={isActive}
                    className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-right text-sm font-semibold transition ${
                      isActive
                        ? "bg-[var(--foreground)] text-[var(--background)] shadow-sm"
                        : "text-[var(--foreground)]/70 hover:bg-[var(--foreground)]/5 hover:text-[var(--foreground)]"
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="flex-1 truncate">{f.title}</span>
                    <ChevronDown
                      className={`h-3.5 w-3.5 shrink-0 -rotate-90 transition ${isActive ? "opacity-100" : "opacity-0 group-hover:opacity-40"}`}
                    />
                  </button>
                );
              })}
            </nav>

            <div key={activeFeature.id} className="neu-card animate-scale-in min-w-0 p-5 sm:p-7">
              <div className="mb-4 flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--accent)] text-[var(--accent-foreground)]">
                  <activeFeature.icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">آموزش کامل «{activeFeature.title}»</h3>
                  <p className="text-xs text-[var(--muted-foreground)]">{activeFeature.desc}</p>
                </div>
              </div>

              <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
                <ol className="space-y-3">
                  {activeFeature.details.map((d, i) => (
                    <li
                      key={i}
                      className="flex gap-3 text-sm leading-7 text-[var(--muted-foreground)]"
                    >
                      <span className="mt-1 grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-[var(--secondary)] text-xs font-bold text-[var(--foreground)]">
                        {i + 1}
                      </span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ol>

                <div className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--secondary)]/40">
                  {activeFeature.image ? (
                    <img
                      src={activeFeature.image}
                      alt={`نمای بخش ${activeFeature.title}`}
                      loading="lazy"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="grid h-full min-h-[180px] place-items-center gap-2 p-6 text-center">
                      <ImageIcon className="h-8 w-8 text-[var(--muted-foreground)]" />
                      <p className="text-xs text-[var(--muted-foreground)]">
                        تصویر آموزشی این بخش به‌زودی اضافه می‌شود.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {activeFeature.to && (
                <div className="mt-5">
                  <Button asChild variant="primary" className="gap-2">
                    <Link to={activeFeature.to}>
                      رفتن به {activeFeature.title}
                      <ArrowRight className="h-4 w-4 rotate-180" />
                    </Link>
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </section>

      {/* Advanced features */}
      <section className="mt-10">
        <SectionTitle>امکانات پیشرفته</SectionTitle>
        <div className="grid gap-5 lg:grid-cols-2">
          <div className="neu-card p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--accent)] text-[var(--accent-foreground)]">
                <Sparkles className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-bold">KI Coach</h3>
            </div>
            <p className="text-sm leading-7 text-[var(--muted-foreground)]">
              در بخش KI Coach می‌توانید به آلمانی بنویسید یا صحبت کنید و در لحظه اصلاح شوید. از این
              ابزار برای تمرین مکالمه‌های روزمره، نوشتن ایمیل و آمادگی مصاحبه استفاده کنید. هر پاسخ
              هوش مصنوعی شامل توضیح خطا و پیشنهاد جمله صحیح است.
            </p>
          </div>

          <div className="neu-card p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--accent)] text-[var(--accent-foreground)]">
                <Brain className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-bold">Leitner Box و FSRS</h3>
            </div>
            <p className="text-sm leading-7 text-[var(--muted-foreground)]">
              کارت‌هایی که سخت‌تر است را بیشتر و کارت‌های آسان‌تر را دیرتر مرور کنید. دئوسی با
              الگوریتم‌های بازگشایی فاصله‌ای، بهترین زمان مرور را پیشنهاد می‌دهد و وقت شما را هدر
              نمی‌دهد.
            </p>
          </div>

          <div className="neu-card p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--accent)] text-[var(--accent-foreground)]">
                <Award className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-bold">دستاوردها و سری‌ها</h3>
            </div>
            <p className="text-sm leading-7 text-[var(--muted-foreground)]">
              با یادگیری روزانه، سری خود را حفظ کنید و Badgeهای مختلف را باز کنید. دستاوردها انگیزه
              شما را بالا نگه می‌دارند و پیشرفتتان را قابل مشاهده می‌کنند.
            </p>
          </div>

          <div className="neu-card p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--accent)] text-[var(--accent-foreground)]">
                <BarChart3 className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-bold">آمار و تحلیل پیشرفت</h3>
            </div>
            <p className="text-sm leading-7 text-[var(--muted-foreground)]">
              در صفحه آمار می‌توانید زمان مطالعه، توزیع مهارت‌ها، فعالیت روزانه و واژگان
              یادگرفته‌شده را ببینید. این داده‌ها به شما کمک می‌کنند نقاط ضعف را پیدا کنید.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mt-10">
        <SectionTitle>
          <MessageCircleQuestion className="h-5 w-5" />
          سوالات متداول
        </SectionTitle>
        <div className="neu-card p-5 sm:p-8">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="q1">
              <AccordionTrigger className="text-right font-semibold hover:no-underline">
                از کجا شروع کنم؟
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-7 text-[var(--muted-foreground)]">
                بهترین شروع، دیدن داشبورد و انتخاب یک بخش بر اساس هدف شماست. اگر می‌خواهید واژگان
                بسازید، دیکشنری و Leitner را امتحان کنید؛ اگر مهارت شنیداری را هدف گرفته‌اید،
                پادکست‌ها بهترین انتخاب هستند.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="q2">
              <AccordionTrigger className="text-right font-semibold hover:no-underline">
                آیا دئوسی رایگان است؟
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-7 text-[var(--muted-foreground)]">
                بله، بخش عمده‌ای از محتوا رایگان است. برخی امکانات پیشرفته مانند KI Coach و آمار
                پیشرفته در طرح پریمیوم در دسترس هستند. اطلاعات بیشتر را در پروفایل بخش اشتراک
                ببینید.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="q3">
              <AccordionTrigger className="text-right font-semibold hover:no-underline">
                آیا می‌توانم بدون اینترنت از دئوسی استفاده کنم؟
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-7 text-[var(--muted-foreground)]">
                برخی بخش‌ها مانند کارت‌های Leitner و واژگان ذخیره‌شده به صورت محلی نگه داشته می‌شوند
                و در صورت قطعی اینترنت هم قابل دسترسی هستند. اما برای به‌روزرسانی و امکانات ابری،
                نیاز به اتصال اینترنت دارید.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="q4">
              <AccordionTrigger className="text-right font-semibold hover:no-underline">
                Leitner Box چگونه کار می‌کند؟
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-7 text-[var(--muted-foreground)]">
                کارت‌ها در جعبه‌هایی با بازه‌های مروری مختلف قرار می‌گیرند. اگر پاسخ شما درست باشد،
                کارت به جعبه بعدی (با بازه طولانی‌تر) می‌رود؛ اگر اشتباه باشد، به جعبه اول
                بازمی‌گردد. این روش باعث می‌شود کارت‌های سخت‌تر بیشتر مرور شوند.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="q5">
              <AccordionTrigger className="text-right font-semibold hover:no-underline">
                چطور پیشرفت خود را ریست کنم؟
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-7 text-[var(--muted-foreground)]">
                در حال حاضر ریست کلی پیشرفت از طریق تنظیمات پروفایل امکان‌پذیر است. قبل از انجام این
                کار، دقت کنید که این عملیات غیرقابل بازگشت است.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* CTA */}
      <section className="mt-10">
        <div className="neu-card flex flex-col items-center gap-5 p-8 text-center sm:flex-row sm:justify-between sm:p-10">
          <div>
            <h3 className="text-xl font-bold">آماده شروع هستید؟</h3>
            <p className="mt-2 text-sm text-[var(--muted-foreground)]">
              به داشبورد برگردید و اولین جلسه یادگیری خود را امروز شروع کنید.
            </p>
          </div>
          <Button asChild className="gap-2 px-6 py-5 text-base font-semibold" variant="primary">
            <Link to="/dashboard">
              <ArrowRight className="h-5 w-5" />
              بازگشت به داشبورد
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer note */}
      <p className="mt-10 text-center text-xs text-[var(--muted-foreground)]">
        این راهنما به‌مرور به‌روز می‌شود. اگر سوالی داشتید که اینجا پاسخ آن را نیافتید، از پروفایل
        خود با تیم پشتیبانی تماس بگیرید.
      </p>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-4 flex items-center gap-2 text-xl font-bold text-[var(--foreground)] sm:text-2xl">
      {children}
    </h2>
  );
}

function StepCard({ step, title, desc }: { step: string; title: string; desc: string }) {
  return (
    <div className="neu-card flex flex-col items-start gap-3 p-5">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--accent)] text-sm font-bold text-[var(--accent-foreground)]">
        {step}
      </span>
      <h3 className="text-base font-bold">{title}</h3>
      <p className="text-sm leading-6 text-[var(--muted-foreground)]">{desc}</p>
    </div>
  );
}

type Feature = {
  id: string;
  title: string;
  desc: string;
  icon: typeof BookText;
  to?: string;
  image?: string;
  details: string[];
};

const FEATURES: Feature[] = [
  {
    id: "dictionary",
    title: "دیکشنری",
    desc: "جستجوی لغات، ذخیره واژگان شخصی، مترادف‌ها و نمونه جملات.",
    icon: BookText,
    to: "/dictionary",
    details: [
      "کلمه آلمانی یا فارسی را در نوار جستجو وارد کنید؛ نتایج به‌صورت زنده فیلتر می‌شوند.",
      "برای هر واژه، آرتیکل (der/die/das)، جمع، ترجمه فارسی و نمونه جمله نمایش داده می‌شود.",
      "با دکمه ذخیره، واژه به لیست شخصی شما و کارت‌های مرور اضافه می‌شود.",
      "واژگان ذخیره‌شده به‌طور خودکار در Leitner و Learn برای مرور در دسترس‌اند.",
    ],
  },
  {
    id: "grammatik",
    title: "گرامر",
    desc: "موضوعات گرامری با توضیحات، تمرین‌های تعاملی و نقشه راه یادگیری.",
    icon: Languages,
    to: "/grammatik",
    details: [
      "موضوعات بر اساس سطح (A1 تا C1) دسته‌بندی شده‌اند؛ ابتدا سطح خود را انتخاب کنید.",
      "هر موضوع شامل چند درس است: توضیح فارسی، جدول قواعد و مثال‌های آلمانی.",
      "در پایان هر درس تمرین تعاملی وجود دارد؛ پاسخ‌ها بلافاصله بررسی می‌شوند.",
      "درس‌های تکمیل‌شده علامت می‌خورند تا مسیر پیشرفت شما مشخص بماند.",
    ],
  },
  {
    id: "leitner",
    title: "Leitner Box",
    desc: "سیستم مرور فاصله‌دار برای کارت‌هایی که باید دوباره یاد بگیرید.",
    icon: Brain,
    to: "/leitner",
    details: [
      "کارت‌ها در جعبه‌هایی با بازه‌های مروری متفاوت قرار می‌گیرند.",
      "پاسخ درست کارت را به جعبه بعدی می‌برد و پاسخ اشتباه آن را به جعبه اول برمی‌گرداند.",
      "هر روز فقط کارت‌های سررسیدشده به شما نشان داده می‌شود تا وقتتان هدر نرود.",
      "برای بهترین نتیجه، روزی ۱۰ تا ۱۵ دقیقه مرور را ادامه دهید.",
    ],
  },
  {
    id: "learn",
    title: "Learn / Flashcards",
    desc: "کارت‌های دوطرفه با الگوریتم FSRS برای یادگیری بهینه‌تر.",
    icon: Layers,
    to: "/learn",
    details: [
      "روی کارت کلیک کنید تا سمت دیگر (ترجمه یا معنی) نمایش داده شود.",
      "بعد از دیدن پاسخ، سختی کارت را مشخص کنید: دوباره، سخت، خوب یا آسان.",
      "الگوریتم FSRS بر اساس انتخاب شما زمان مرور بعدی را حساب می‌کند.",
      "می‌توانید دسته کارت‌ها را از واژگان ذخیره‌شده یا درس‌های گرامر بسازید.",
    ],
  },
  {
    id: "ki-coach",
    title: "KI Coach",
    desc: "تمرین مکالمه و دریافت بازخورد هوشمند از هوش مصنوعی.",
    icon: Sparkles,
    to: "/ki-coach",
    details: [
      "یک سناریو (مثلاً مکالمه در فروشگاه یا نوشتن ایمیل رسمی) انتخاب کنید.",
      "به آلمانی بنویسید؛ نگران اشتباه نباشید، هدف تمرین است.",
      "پاسخ مربی شامل نسخه اصلاح‌شده جمله و توضیح خطاست.",
      "جملات مفید را ذخیره کنید تا در کارت‌های مرور شما قرار بگیرند.",
    ],
  },
  {
    id: "podcasts",
    title: "Podcasts",
    desc: "فایل‌های صوتی با رونویسی تعاملی برای تقویت مهارت شنیداری.",
    icon: Headphones,
    to: "/podcasts",
    details: [
      "یک اپیزود متناسب با سطح خود انتخاب کنید.",
      "ابتدا بدون متن گوش کنید، سپس با رونویسی همراه شوید.",
      "روی کلمات ناآشنا کلیک کنید تا معنی آن‌ها را ببینید و ذخیره کنید.",
      "سرعت پخش را کم کنید اگر گفتار برایتان سریع است.",
    ],
  },
  {
    id: "musik",
    title: "Musik",
    desc: "یادگیری آلمانی از طریق ترانه‌ها، متن آهنگ و واژگان کلیدی.",
    icon: Music,
    to: "/musik",
    details: [
      "آهنگ را انتخاب کنید و متن آن را همزمان با پخش دنبال کنید.",
      "ترجمه فارسی هر خط برای درک بهتر در دسترس است.",
      "واژگان کلیدی هر ترانه جداگانه فهرست شده‌اند.",
      "تکرار آهنگ‌های محبوب بهترین راه برای تثبیت تلفظ است.",
    ],
  },
  {
    id: "kino",
    title: "Deutsches Kino",
    desc: "تماشای فیلم‌های آلمانی همراه با زیرنویس و آموزش واژگان.",
    icon: Film,
    to: "/kino",
    details: [
      "فیلم یا کلیپ متناسب با سطح خود را انتخاب کنید.",
      "زیرنویس آلمانی را فعال کنید و در صورت نیاز ترجمه را ببینید.",
      "دیالوگ‌های کاربردی را یادداشت و ذخیره کنید.",
      "بخش‌های سخت را دوباره ببینید تا گوشتان عادت کند.",
    ],
  },
  {
    id: "lesen",
    title: "Lesen",
    desc: "مقالات سطح‌بندی‌شده برای تقویت مهارت خواندن و درک مطلب.",
    icon: Newspaper,
    to: "/lesen",
    details: [
      "مقاله‌ای متناسب با سطح خود انتخاب کنید (A1 تا C1).",
      "ابتدا یک‌بار کامل بخوانید و سعی کنید کلیت متن را بفهمید.",
      "بار دوم روی واژگان ناآشنا کلیک کنید و آن‌ها را ذخیره کنید.",
      "در پایان به سوالات درک مطلب پاسخ دهید.",
    ],
  },
  {
    id: "events",
    title: "Events",
    desc: "رویدادهای آنلاین و آفلاین برای تمرین گروهی و فرهنگ آلمانی.",
    icon: Calendar,
    to: "/events",
    details: [
      "فهرست رویدادها را بر اساس تاریخ مرور کنید.",
      "روی هر رویداد بزنید تا جزئیات، سطح زبانی و نحوه شرکت را ببینید.",
      "رویدادهای گفت‌وگو (Stammtisch) بهترین فرصت برای تمرین مکالمه‌اند.",
    ],
  },
  {
    id: "pruefungen",
    title: "Prüfungen",
    desc: "آمادگی آزمون‌های رسمی آلمانی با سوال‌های شبیه‌سازی‌شده.",
    icon: BookOpen,
    to: "/pruefungen",
    details: [
      "آزمون هدف خود (مثلاً Goethe A2 یا telc B1) را انتخاب کنید.",
      "هر آزمون شامل بخش‌های شنیداری، خواندن، نوشتن و گرامر است.",
      "در پایان نمره و تحلیل نقاط ضعف نمایش داده می‌شود.",
      "آزمون‌ها را چند بار تکرار کنید تا با زمان‌بندی واقعی آشنا شوید.",
    ],
  },
  {
    id: "statistiken",
    title: "Statistiken",
    desc: "نمودارهای پیشرفت، توزیع مهارت‌ها و زمان مطالعه.",
    icon: BarChart3,
    to: "/statistiken",
    details: [
      "نمودار فعالیت روزانه نشان می‌دهد چه روزهایی فعال بوده‌اید.",
      "توزیع مهارت‌ها مشخص می‌کند کدام بخش را کمتر تمرین کرده‌اید.",
      "تعداد واژگان یادگرفته‌شده و کارت‌های مرورشده اینجا گزارش می‌شود.",
      "هدف روزانه را طوری تنظیم کنید که واقع‌بینانه و قابل تداوم باشد.",
    ],
  },
  {
    id: "achievements",
    title: "دستاوردها",
    desc: "نشان‌ها و سری روزهای متوالی برای حفظ انگیزه.",
    icon: Award,
    to: "/achievements",
    details: [
      "هر فعالیت روزانه سری (Streak) شما را یک روز جلو می‌برد.",
      "با رسیدن به اهداف مشخص، نشان‌های جدید باز می‌شوند.",
      "در صفحه دستاوردها می‌توانید نشان‌های قفل‌شده و شرط باز شدنشان را ببینید.",
    ],
  },
];
