import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  motion,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
  useInView,
  animate,
  useMotionValueEvent,
  useMotionTemplate,
  useVelocity,
  type MotionValue,
} from "framer-motion";
import {
  ArrowRight,
  Sparkles,
  BookOpen,
  Brain,
  Layers,
  Headphones,
  GraduationCap,
  BarChart3,
  MessageSquare,
  Play,
  Zap,
  Globe,
  ShieldCheck,
  Star,
  Check,
  Crown,
  Rocket,
  Flame,
  Infinity as InfinityIcon,
  Music,
  Film,
  Network,
  PenLine,
  Users,
  CalendarDays,
  Trophy,
  Library,
  type LucideIcon,
} from "lucide-react";

import { useDeusi } from "@/lib/deusi/store";
import { Logo } from "@/components/deusi/Logo";

export const Route = createFileRoute("/")({ component: Landing });

const EASE = [0.22, 1, 0.36, 1] as const;

/* Small bilingual helpers */
function FA({
  children,
  className = "",
  style,
}: {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <span className={`fa-inline ${className}`} dir="rtl" style={style}>
      {children}
    </span>
  );
}

function Landing() {
  const { currentUser } = useDeusi();
  const router = useRouter();
  useEffect(() => {
    if (currentUser) router.navigate({ to: "/dashboard" });
  }, [currentUser, router]);

  const { scrollYProgress } = useScroll();
  const barScale = useSpring(scrollYProgress, { stiffness: 140, damping: 30, restDelta: 0.001 });

  return (
    <div className="relative overflow-x-clip">
      {/* Scroll progress bar */}
      <motion.div
        aria-hidden
        style={{ scaleX: barScale, transformOrigin: "0% 50%" }}
        className="fixed inset-x-0 top-0 z-[60] h-[3px]"
      >
        <div
          className="h-full w-full"
          style={{ background: "linear-gradient(90deg, #1a1a1a, #DD2222 45%, #F7C948)" }}
        />
      </motion.div>

      <CursorSpotlight />
      <Nav />
      <Hero />
      <Manifest />
      <Marquee />
      <HorizontalFeatures />
      <Features />
      <DeepDive />
      <AppShowcase />
      <FlashcardShowcase />
      <Stats />
      <Journey />
      <Pricing />
      <Testimonials />
      <FinalCTA />

      <Footer />
    </div>
  );
}

/* ---------- CURSOR SPOTLIGHT ---------- */
function CursorSpotlight() {
  const isMobile = useIsMobile();
  const x = useMotionValue(-500);
  const y = useMotionValue(-500);
  const sx = useSpring(x, { stiffness: 160, damping: 22, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 160, damping: 22, mass: 0.4 });
  useEffect(() => {
    if (isMobile) return;
    const onMove = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };
    const onLeave = () => {
      x.set(-500);
      y.set(-500);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseleave", onLeave);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseleave", onLeave);
    };
  }, [x, y, isMobile]);
  if (isMobile) return null;
  return (
    <motion.div aria-hidden className="cursor-spot hidden md:block" style={{ left: sx, top: sy }} />
  );
}

/* ---------- NAV ---------- */
function Nav() {
  const { scrollY } = useScroll();
  const [scrolled, setScrolled] = useState(false);
  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 20));

  const items: Array<[string, string, string]> = [
    ["Features", "فیچرها", "#features"],
    ["Bereiche", "بخش‌ها", "#deep-dive"],
    ["Karten", "کارت‌ها", "#cards"],
    ["Reise", "مسیر", "#journey"],
    ["Stimmen", "نظرها", "#testimonials"],
  ];

  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: EASE }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "py-2" : "py-4"}`}
    >
      <motion.div
        layout
        transition={{ duration: 0.5, ease: EASE }}
        className={`mx-auto flex items-center justify-between rounded-full px-3 transition-all duration-500 sm:px-5 ${
          scrolled
            ? "border border-border bg-card/80 py-1.5 shadow-[0_20px_60px_-25px_rgba(20,22,26,0.35)] backdrop-blur-xl"
            : "border border-transparent bg-card/40 py-2 backdrop-blur-md"
        }`}
        style={{ maxWidth: scrolled ? "60rem" : "92rem" }}
      >
        <Link to="/" className="group relative flex items-center gap-2">
          <motion.span
            aria-hidden
            className="absolute -inset-3 -z-10 rounded-full opacity-0 blur-xl transition-opacity duration-500 group-hover:opacity-70"
            style={{ background: "radial-gradient(circle, rgba(221,34,34,.5), transparent 70%)" }}
          />
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 text-sm font-semibold text-muted-foreground md:flex">
          {items.map(([de, fa, h], i) => (
            <motion.a
              key={h}
              href={h}
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 + i * 0.06, duration: 0.5, ease: EASE }}
              className="group relative rounded-full px-3.5 py-2 transition-colors hover:text-foreground"
            >
              <span
                aria-hidden
                className="absolute inset-0 -z-10 scale-90 rounded-full opacity-0 transition-all duration-300 group-hover:scale-100 group-hover:opacity-100"
                style={{
                  background: "linear-gradient(135deg, rgba(221,34,34,.10), rgba(247,201,72,.14))",
                }}
              />
              <span className="nav-flip align-middle">
                <span className="flip-de whitespace-nowrap">{de}</span>
                <span
                  className="flip-fa fa-inline whitespace-nowrap font-bold"
                  dir="rtl"
                  style={{ color: "var(--flag-red)" }}
                >
                  {fa}
                </span>
              </span>
              <span
                aria-hidden
                className="absolute inset-x-3 -bottom-0.5 h-[2px] origin-left scale-x-0 rounded-full transition-transform duration-500 group-hover:scale-x-100"
                style={{ background: "linear-gradient(90deg, #1a1a1a, #DD2222, #F7C948)" }}
              />
            </motion.a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/login"
            className="hidden rounded-full px-3.5 py-2 text-sm font-semibold text-muted-foreground transition hover:text-foreground sm:inline-flex"
          >
            <span className="nav-flip">
              <span className="flip-de">Anmelden</span>
              <span
                className="flip-fa fa-inline font-bold"
                dir="rtl"
                style={{ color: "var(--flag-red)" }}
              >
                ورود
              </span>
            </span>
          </Link>
          <MagneticLink to="/register" />
        </div>
      </motion.div>
    </motion.header>
  );
}

function MagneticLink({ to }: { to: string }) {
  const ref = useRef<HTMLAnchorElement>(null);
  const [t, setT] = useState({ x: 0, y: 0 });
  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    setT({
      x: (e.clientX - (r.left + r.width / 2)) * 0.25,
      y: (e.clientY - (r.top + r.height / 2)) * 0.3,
    });
  };
  return (
    <Link
      to={to}
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setT({ x: 0, y: 0 })}
      style={{
        background: "linear-gradient(135deg, #1a1a1a 0%, #B01818 55%, #DD2222 100%)",
        boxShadow: "0 12px 30px -12px rgba(221,34,34,0.6)",
        transform: `translate(${t.x}px, ${t.y}px)`,
        transition: "transform .35s cubic-bezier(.2,.8,.2,1), box-shadow .35s ease",
      }}
      className="shine-on-hover magnetic group inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-bold text-white"
    >
      <span className="nav-flip">
        <span className="flip-de">Start</span>
        <span className="flip-fa fa-inline" dir="rtl">
          شروع
        </span>
      </span>
      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
    </Link>
  );
}

/* ---------- WORD REVEAL (scroll-driven) ---------- */
function WordReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const rotate = useTransform(scrollYProgress, [0, 1], [-6, 6]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.85, 1.05, 0.85]);

  const pairs: Array<[string, string, string]> = [
    ["der Anfang", "آغاز", "#2563eb"],
    ["die Reise", "سفر", "#DD2222"],
    ["das Ziel", "هدف", "#22C55E"],
    ["der Rhythmus", "ریتم", "#8B5CF6"],
    ["die Freude", "شادی", "#22C55E"],
    ["das Wort", "کلمه", "#EF4444"],
  ];

  return (
    <section
      ref={ref}
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-16 sm:px-8 sm:py-24"
    >
      <div className="mb-10 flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-[0.4em] text-muted-foreground">
        <span className="h-px w-8 bg-border" />
        Wörter · <FA className="tracking-normal">کلمه‌ها</FA>
        <span className="h-px w-8 bg-border" />
      </div>
      <motion.div style={{ rotate, scale }} className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {pairs.map(([de, fa, c], i) => (
          <WordRevealCard
            key={de}
            de={de}
            fa={fa}
            color={c}
            index={i}
            total={pairs.length}
            progress={scrollYProgress}
          />
        ))}
      </motion.div>
    </section>
  );
}

function WordRevealCard({
  de,
  fa,
  color,
  index,
  total,
  progress,
}: {
  de: string;
  fa: string;
  color: string;
  index: number;
  total: number;
  progress: MotionValue<number>;
}) {
  const p = (index + 1) / (total + 1);
  const dir = index % 2 === 0 ? 1 : -1;
  const y = useTransform(progress, [0, 1], [80 * dir, -80 * dir]);
  const op = useTransform(
    progress,
    [Math.max(0, p - 0.35), p, Math.min(1, p + 0.35)],
    [0.2, 1, 0.2],
  );
  return (
    <motion.div
      style={{ y, opacity: op }}
      whileHover={{ scale: 1.04, y: 0 }}
      className="group relative overflow-hidden rounded-3xl border border-border bg-card p-5 sm:p-6"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-30 blur-3xl transition-opacity duration-500 group-hover:opacity-70"
        style={{ background: color }}
      />
      <div className="relative">
        <div className="font-display text-2xl font-black tracking-tight sm:text-3xl">{de}</div>
        <div dir="rtl" className="fa-inline mt-1 text-xl font-black" style={{ color }}>
          {fa}
        </div>
        <div className="mt-3 flex gap-1">
          {[0, 1, 2, 3].map((k) => (
            <span
              key={k}
              className="h-1 flex-1 rounded-full"
              style={{ background: color, opacity: 0.15 + k * 0.2 }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}

/* ---------- HERO ---------- */
function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const sx = useSpring(mx, { stiffness: 60, damping: 20 });
  const sy = useSpring(my, { stiffness: 60, damping: 20 });
  const rx = useTransform(sy, [0, 1], [10, -10]);
  const ry = useTransform(sx, [0, 1], [-14, 14]);
  const px1 = useTransform(sx, [0, 1], [-20, 20]);
  const py1 = useTransform(sy, [0, 1], [-14, 14]);
  const px1Neg = useTransform(px1, (v: number) => -v);
  const py1Neg = useTransform(py1, (v: number) => -v);

  // Scroll parallax on hero content — desktop only. On mobile the cards live
  // below the copy and would get faded/blurred out of view before the user
  // ever scrolled to them.
  const { scrollY } = useScroll();
  const [isDesktop, setIsDesktop] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(min-width: 1024px)");
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  const heroYRaw = useTransform(scrollY, [0, 600], [0, 120]);
  const heroOpacityRaw = useTransform(scrollY, [0, 500], [1, 0.15]);
  const heroY = useTransform(heroYRaw, (v: number) => (isDesktop ? v : 0));
  const heroOpacity = useTransform(heroOpacityRaw, (v: number) => (isDesktop ? v : 1));

  const isMobile = useIsMobile();
  const onMove = (e: React.MouseEvent) => {
    if (isMobile) return;
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set((e.clientX - r.left) / r.width);
    my.set((e.clientY - r.top) / r.height);
  };

  const words = ["Deutsch.", "Einfach.", "Meistern."];
  const wordsFa = ["آلمانی.", "ساده.", "مسلط."];

  return (
    <section
      ref={ref}
      onMouseMove={onMove}
      className="relative min-h-[100svh] overflow-hidden pt-28 sm:pt-32"
    >
      {/* Cinematic backdrop */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <motion.div
          style={{
            x: px1,
            y: py1,
            background: "radial-gradient(circle, rgba(221,34,34,0.55), transparent 60%)",
          }}
          className="absolute -top-32 -left-32 h-[560px] w-[560px] rounded-full blur-3xl"
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.7 }}
          transition={{ duration: 1.4, ease: EASE }}
        />
        <motion.div
          style={{
            x: px1Neg,
            y: py1Neg,
            background: "radial-gradient(circle, rgba(247,201,72,0.55), transparent 60%)",
          }}
          className="absolute -bottom-40 -right-24 h-[560px] w-[560px] rounded-full blur-3xl"
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.7 }}
          transition={{ duration: 1.4, ease: EASE, delay: 0.15 }}
        />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: "radial-gradient(rgba(20,22,26,0.07) 1px, transparent 1px)",
            backgroundSize: "24px 24px",
            maskImage: "radial-gradient(ellipse at center, black 40%, transparent 75%)",
          }}
        />
      </div>

      <motion.div
        style={{ y: heroY, opacity: heroOpacity }}
        className="mx-auto grid max-w-[1500px] items-center gap-10 px-5 pb-16 sm:px-8 lg:grid-cols-[1.1fr_1fr] lg:gap-16 lg:px-16"
      >
        {/* LEFT */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: EASE }}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-semibold backdrop-blur"
          >
            <span
              className="grid h-4 w-4 place-items-center rounded-full"
              style={{ background: "var(--flag-red)" }}
            >
              <Sparkles className="h-2.5 w-2.5 text-white" />
            </span>
            Neu · FSRS 5 & KI-Coach{" "}
            <span className="hidden sm:inline text-muted-foreground">·</span>
            <FA className="hidden sm:inline text-muted-foreground">جدید · مربی هوش مصنوعی</FA>
          </motion.div>

          <h1 className="mt-5 font-display text-5xl font-black leading-[0.95] tracking-tight sm:text-6xl md:text-7xl">
            {words.map((w, i) => (
              <span key={w} className="block overflow-hidden">
                <motion.span
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.9, ease: EASE, delay: 0.1 + i * 0.12 }}
                  className="block"
                  style={
                    i === 1
                      ? { color: "var(--flag-red)" }
                      : i === 2
                        ? { color: "#F7C948", WebkitTextStroke: "1px rgba(20,22,26,0.15)" }
                        : undefined
                  }
                >
                  {w}
                </motion.span>
              </span>
            ))}
          </h1>

          {/* Farsi mirror headline */}
          <div className="mt-3 overflow-hidden">
            <motion.h2
              dir="rtl"
              initial={{ y: "110%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.9, ease: EASE, delay: 0.55 }}
              className="fa-inline font-black leading-tight text-2xl sm:text-3xl md:text-4xl text-muted-foreground"
            >
              {wordsFa[0]} <span style={{ color: "var(--flag-red)" }}>{wordsFa[1]}</span>{" "}
              <span style={{ color: "#B8912A" }}>{wordsFa[2]}</span>
            </motion.h2>
          </div>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE, delay: 0.7 }}
            className="mt-5 max-w-xl text-base text-muted-foreground sm:text-lg"
          >
            DEUSI vereint Leitner, FSRS 5, dynamische Karten pro Wortart, Grammatik, Lesen, Podcasts
            und einen KI-Coach — zu einem Lernritual, das wirklich hängen bleibt.
          </motion.p>
          <motion.p
            dir="rtl"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE, delay: 0.8 }}
            className="fa-inline mt-3 max-w-xl text-sm text-muted-foreground/90 sm:text-base"
          >
            دئوسی، لایتنر و اف‌اس‌آر‌اس ۵ را کنار کارت‌های هوشمند، گرامر، خواندن، پادکست و یک مربی
            هوش مصنوعی می‌گذارد — یک آیین ساده که واقعاً می‌ماند.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE, delay: 0.9 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <Link
              to="/register"
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-2xl px-6 py-3.5 text-sm font-bold text-white shadow-xl transition"
              style={{
                background: "linear-gradient(135deg, #1a1a1a 0%, #B01818 55%, #DD2222 100%)",
                boxShadow: "0 25px 45px -20px rgba(221,34,34,0.7)",
              }}
            >
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              <span className="relative">Kostenlos starten</span>
              <FA className="relative text-white/90 text-[11px]">· رایگان شروع کن</FA>
              <ArrowRight className="relative h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/login"
              className="group inline-flex items-center gap-2 rounded-2xl border border-border bg-card/70 px-5 py-3.5 text-sm font-semibold backdrop-blur transition hover:bg-secondary"
            >
              <Play className="h-4 w-4 transition-transform group-hover:scale-110" />
              Demo ansehen
              <FA className="text-[11px] text-muted-foreground">· دموی زنده</FA>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.05, duration: 0.7 }}
            className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 text-xs text-muted-foreground"
          >
            <Badge icon={<ShieldCheck className="h-3.5 w-3.5" />}>
              100% offline <FA>· دیتات پیش خودت</FA>
            </Badge>
            <Badge icon={<Globe className="h-3.5 w-3.5" />}>A1 – C2</Badge>
            <Badge icon={<Zap className="h-3.5 w-3.5" />}>
              Keine Anmeldegebühr <FA>· بدون هزینه</FA>
            </Badge>
          </motion.div>
        </div>

        {/* RIGHT — 3D stack of cards */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85, rotateY: 15 }}
          animate={{ opacity: 1, scale: 1, rotateY: 0 }}
          transition={{ duration: 1, ease: EASE, delay: 0.3 }}
          style={{ perspective: 1400 }}
          className="relative mx-auto h-[420px] w-full max-w-md scale-[0.78] sm:h-[480px] sm:max-w-lg sm:scale-100"
        >
          <motion.div
            style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d" }}
            className="relative h-full w-full"
          >
            <FloatingCard
              depth={-60}
              rotate={-10}
              offsetX={-70}
              offsetY={-30}
              delay={0}
              tint="der"
              word="der Mann"
              fa="مرد"
              pos="Nomen · maskulin"
              plural="die Männer"
            />
            <FloatingCard
              depth={20}
              rotate={4}
              offsetX={0}
              offsetY={0}
              delay={0.15}
              tint="das"
              word="das Leben"
              fa="زندگی"
              pos="Nomen · neutrum"
              plural="die Leben"
              front
            />
            <FloatingCard
              depth={80}
              rotate={12}
              offsetX={70}
              offsetY={40}
              delay={0.3}
              tint="die"
              word="die Freiheit"
              fa="آزادی"
              pos="Nomen · feminin"
              plural="die Freiheiten"
            />
          </motion.div>

          {/* orbiting chips */}
          {[
            { t: "Leitner", top: "-6%", left: "-10%", color: "#DD2222" },
            { t: "FSRS 5", top: "12%", right: "-14%", color: "#F7C948" },
            { t: "KI-Coach", bottom: "10%", left: "-14%", color: "#1a1a1a" },
            { t: "Offline", bottom: "-4%", right: "-8%", color: "#2563eb" },
          ].map((c, i) => (
            <motion.div
              key={c.t}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 + i * 0.12, duration: 0.6, ease: EASE }}
              className="absolute z-20 flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold shadow-lg backdrop-blur"
              style={{ top: c.top, left: c.left, right: c.right, bottom: c.bottom, color: c.color }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: c.color }} />
              {c.t}
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.6 }}
        className="pointer-events-none absolute inset-x-0 bottom-6 flex justify-center"
      >
        <div className="flex flex-col items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          <span>
            Scroll · <FA>پایین بیا</FA>
          </span>
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
            className="h-8 w-[2px] rounded-full"
            style={{ background: "linear-gradient(180deg, transparent, var(--flag-red))" }}
          />
        </div>
      </motion.div>
    </section>
  );
}

function Badge({ children, icon }: { children: React.ReactNode; icon: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/60 px-2.5 py-1 backdrop-blur">
      <span className="text-[var(--flag-red)]">{icon}</span> {children}
    </span>
  );
}

function FloatingCard({
  depth,
  rotate,
  delay,
  word,
  fa,
  pos,
  plural,
  tint,
  front,
  offsetX = 0,
  offsetY = 0,
}: {
  depth: number;
  rotate: number;
  delay: number;
  word: string;
  fa: string;
  pos: string;
  plural: string;
  tint: "der" | "die" | "das";
  front?: boolean;
  offsetX?: number;
  offsetY?: number;
}) {
  const bg = tint === "der" ? "#2563eb" : tint === "die" ? "#DD2222" : "#22C55E";
  return (
    <div
      className="absolute inset-0 mx-auto"
      style={{
        transform: `translate3d(${offsetX}px, ${offsetY}px, ${depth}px) rotate(${rotate}deg)`,
      }}
    >
      <motion.div
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 6 + delay * 2, repeat: Infinity, ease: "easeInOut", delay }}
        className="h-full w-full"
      >
        <div
          className="card-glass relative flex h-full flex-col justify-between p-6 sm:p-8"
          style={{
            background: "#ffffff",
            boxShadow: front
              ? "0 40px 90px -25px rgba(20,22,26,0.35), inset 0 1px 0 rgba(255,255,255,1)"
              : "0 25px 55px -20px rgba(20,22,26,0.22), inset 0 1px 0 rgba(255,255,255,1)",
            border: "1px solid rgba(20,22,26,0.08)",
          }}
        >
          <div>
            <div
              className="inline-flex items-center gap-2 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white"
              style={{ background: bg }}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-white" /> {tint}
            </div>
            <div className="mt-4 font-display text-3xl font-black tracking-tight sm:text-4xl">
              {word}
            </div>
            <div className="mt-1.5 text-sm text-muted-foreground">{pos}</div>
            <div dir="rtl" className="fa-inline mt-2 text-lg font-bold" style={{ color: bg }}>
              {fa}
            </div>
          </div>
          <div className="mt-6 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                Plural
              </div>
              <div className="text-sm font-semibold">{plural}</div>
            </div>
            <div className="flex gap-1.5">
              {["#EF4444", "#F59E0B", "#3B82F6", "#22C55E"].map((c) => (
                <div
                  key={c}
                  className="h-2 w-6 rounded-full"
                  style={{ background: c, opacity: 0.85 }}
                />
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

/* ---------- MANIFEST (editorial, scroll-velocity driven, bilingual) ---------- */
function Manifest() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });

  // Live scroll velocity → smoothed → normalized
  const rawVel = useVelocity(scrollY);
  const smoothVel = useSpring(rawVel, { stiffness: 120, damping: 30, mass: 0.5 });
  const velFactor = useTransform(smoothVel, [-3000, 0, 3000], [-1, 0, 1]);

  const lines: Array<{ de: string; fa: string; capDe: string; capFa: string; color: string }> = [
    {
      de: "Jeder Artikel hat eine Farbe.",
      fa: "هر حرف تعریف، یک رنگ دارد.",
      capDe: "der · die · das",
      capFa: "سه رنگ، سه هویت",
      color: "#DD2222",
    },
    {
      de: "Jede Karte kennt ihr Wort.",
      fa: "هر کارت، معنای خودش را می‌شناسد.",
      capDe: "Nomen, Verben, Adjektive",
      capFa: "کارت‌های زنده",
      color: "#F7C948",
    },
    {
      de: "Jede Wiederholung zählt.",
      fa: "هر مرور، یک قدم است.",
      capDe: "FSRS 5 · Leitner",
      capFa: "دو الگوریتم، یک آیین",
      color: "#2563eb",
    },
    {
      de: "Jeder Tag ein Ritual.",
      fa: "هر روز، یک آیین.",
      capDe: "Streak · Retention",
      capFa: "پیوستگی، ماندگاری",
      color: "#1a1a1a",
    },
  ];

  const activeIndex = useTransform(scrollYProgress, (p: number) => {
    const inner = Math.min(Math.max((p - 0.15) / 0.7, 0), 0.9999);
    return Math.floor(inner * lines.length);
  });

  return (
    <section
      ref={ref}
      className="relative mx-auto max-w-[1500px] overflow-hidden px-5 py-24 sm:px-8 sm:py-32 lg:px-12"
    >
      {/* Ambient glows */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div
          className="absolute left-1/3 top-24 h-[420px] w-[420px] rounded-full opacity-25 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(221,34,34,.45), transparent 60%)" }}
        />
        <div
          className="absolute right-8 bottom-16 h-[360px] w-[360px] rounded-full opacity-25 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(247,201,72,.5), transparent 60%)" }}
        />
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: "radial-gradient(currentColor 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
        />
      </div>

      {/* Section chrome */}
      <div className="mb-14 flex items-center justify-between gap-6">
        <div className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.4em] text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--flag-red)" }} />
          Manifest <span className="opacity-50">·</span>
          <FA className="tracking-normal">مانیفست</FA>
        </div>
        <div className="hidden text-[10px] font-bold uppercase tracking-[0.4em] text-muted-foreground sm:block">
          Vier Prinzipien <span className="opacity-50">·</span>
          <FA className="tracking-normal ml-1">چهار اصل</FA>
        </div>
      </div>

      {/* Body — sticky rail + lines */}
      <div className="grid gap-8 lg:grid-cols-[120px_1fr] lg:gap-12">
        <div className="hidden lg:block">
          <div className="sticky top-32">
            <ManifestRail
              progress={scrollYProgress}
              total={lines.length}
              activeIndex={activeIndex}
            />
          </div>
        </div>

        <div className="flex flex-col divide-y divide-border/60">
          {lines.map((l, i) => (
            <ManifestLine
              key={i}
              index={i}
              total={lines.length}
              de={l.de}
              fa={l.fa}
              capDe={l.capDe}
              capFa={l.capFa}
              color={l.color}
              progress={scrollYProgress}
              velFactor={velFactor}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function ManifestRail({
  progress,
  total,
  activeIndex,
}: {
  progress: MotionValue<number>;
  total: number;
  activeIndex: MotionValue<number>;
}) {
  const h = useTransform(progress, [0.1, 0.9], ["0%", "100%"]);
  const [active, setActive] = useState(0);
  useMotionValueEvent(activeIndex, "change", (v) => setActive(Math.min(total - 1, Math.max(0, v))));
  return (
    <div className="flex flex-col gap-6">
      <div className="text-[10px] font-bold uppercase tracking-[0.4em] text-muted-foreground">
        {String(active + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}
      </div>
      <div className="relative h-64 w-[3px] overflow-hidden rounded-full bg-border">
        <motion.div style={{ height: h }} className="absolute inset-x-0 top-0 rounded-full">
          <div
            className="h-full w-full"
            style={{ background: "linear-gradient(180deg, #F7C948, #DD2222)" }}
          />
        </motion.div>
      </div>
      <div className="text-[10px] font-bold uppercase tracking-[0.35em] text-muted-foreground">
        Scroll ↓ <FA className="tracking-normal">پایین بیا</FA>
      </div>
    </div>
  );
}

function ManifestLine({
  de,
  fa,
  capDe,
  capFa,
  color,
  index,
  total,
  progress,
  velFactor,
}: {
  de: string;
  fa: string;
  capDe: string;
  capFa: string;
  color: string;
  index: number;
  total: number;
  progress: MotionValue<number>;
  velFactor: MotionValue<number>;
}) {
  const seg = 1 / total;
  const start = 0.1 + index * seg * 0.75;
  const peak = start + seg * 0.4;
  const end = start + seg * 1.15;

  // Subtle enter from left (DE) / right (FA), then settle and stay put
  const xDe = useTransform(progress, [start, peak, end], [-40, 0, 0]);
  const xFa = useTransform(progress, [start, peak, end], [40, 0, 0]);
  const opacity = useTransform(progress, [start, peak, end], [0.15, 1, 0.85]);
  const scale = useTransform(progress, [start, peak, end], [0.97, 1, 1]);

  // Keep velocity as a tiny visual cue only (no skew, minimal push)
  void velFactor;

  const accent = useTransform(progress, [start, peak, end], ["#8A8B92", color, "#8A8B92"]);

  return (
    <motion.div
      style={{ opacity, scale }}
      className="grid gap-6 py-10 sm:py-14 md:grid-cols-[80px_1fr_1fr] md:gap-10 md:py-16"
    >
      {/* Number */}
      <div className="flex items-start gap-3 md:block">
        <motion.div
          style={{ color: accent }}
          className="font-display text-4xl font-black leading-none tracking-tight sm:text-5xl"
        >
          {String(index + 1).padStart(2, "0")}
        </motion.div>
        <div className="hidden h-px w-10 translate-y-4 bg-border md:block" />
      </div>

      {/* DE side */}
      <motion.div style={{ x: xDe }} className="will-change-transform">
        <div className="font-display text-3xl font-black leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
          {de}
        </div>
        <div className="mt-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.35em] text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
          {capDe}
        </div>
      </motion.div>

      {/* FA side */}
      <motion.div dir="rtl" style={{ x: xFa }} className="text-right will-change-transform">
        <div
          className="fa-inline text-2xl font-black leading-[1.15] sm:text-4xl md:text-5xl"
          style={{ color }}
        >
          {fa}
        </div>
        <div className="mt-3 flex items-center justify-end gap-2 text-[10px] font-bold tracking-[0.2em] text-muted-foreground">
          <FA className="tracking-normal">{capFa}</FA>
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ---------- MARQUEE ---------- */
function Marquee() {
  const items = [
    ["Wortschatz", "واژه"],
    ["Grammatik", "گرامر"],
    ["Prüfungen", "آزمون"],
    ["Konjugation", "صرف فعل"],
    ["Deklination", "صرف اسم"],
    ["Redewendungen", "اصطلاح"],
    ["Aussprache", "تلفظ"],
    ["Lesen", "خواندن"],
    ["Podcasts", "پادکست"],
    ["KI-Coach", "مربی هوش مصنوعی"],
  ];
  const doubled = [...items, ...items];
  return (
    <div className="relative my-4 overflow-hidden border-y border-border/60 bg-card/40 py-5 backdrop-blur">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-20 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-20 bg-gradient-to-l from-background to-transparent" />
      <motion.div
        className="flex gap-8 whitespace-nowrap"
        animate={{ x: ["0%", "-50%"] }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
      >
        {doubled.map(([de, fa], i) => (
          <span
            key={i}
            className="flex items-center gap-4 font-display text-2xl font-black tracking-tight text-muted-foreground sm:text-3xl"
          >
            {de}
            <FA className="text-xl font-bold opacity-70">{fa}</FA>
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ background: i % 3 === 0 ? "#DD2222" : i % 3 === 1 ? "#F7C948" : "#1a1a1a" }}
            />
          </span>
        ))}
      </motion.div>
    </div>
  );
}

/* ---------- FEATURES ---------- */
const FEATURES = [
  {
    icon: Layers,
    title: "Dynamische Karten",
    fa: "کارت‌های هوشمند",
    desc: "Jede Karte passt sich der Wortart an — Nomen mit Artikel, Verben mit Konjugation, Adjektive mit Steigerung.",
    descFa: "هر کارت با نوع کلمه تغییر می‌کند: اسم با حرف تعریف، فعل با صرف، صفت با درجه‌ها.",
    color: "#DD2222",
    tag: "Karten",
  },
  {
    icon: Brain,
    title: "FSRS 5 + Leitner",
    fa: "الگوریتم مرور",
    desc: "Zwei bewährte Systeme, ein Ritual. Wiederhole genau dann, wenn dein Gehirn es braucht.",
    descFa: "دو سیستم اثبات‌شده، یک آیین. درست وقتی مرور کن که مغزت نیاز دارد.",
    color: "#F7C948",
    tag: "Algorithmus",
  },
  {
    icon: BookOpen,
    title: "Grammatik-Pfade",
    fa: "مسیر گرامر",
    desc: "Von Artikeln bis Konjunktiv II — geführte Lektionen mit Beispielen und Mini-Übungen.",
    descFa: "از حرف تعریف تا کنیونکتیو ۲ — درس‌های گام‌به‌گام با مثال و تمرین.",
    color: "#2563eb",
    tag: "Grammatik",
  },
  {
    icon: MessageSquare,
    title: "KI-Coach",
    fa: "کوچ هوش مصنوعی",
    desc: "Dialog auf deinem Niveau. Frage nach Erklärungen, übe Konversation, bekomme Korrekturen.",
    descFa: "گفت‌وگو در سطح خودت. توضیح بخواه، مکالمه تمرین کن، اصلاح بگیر.",
    color: "#8B5CF6",
    tag: "KI",
  },
  {
    icon: Headphones,
    title: "Podcasts & Lesen",
    fa: "پادکست و خواندن",
    desc: "Authentische Texte und Hörbeiträge, gefiltert nach A1 bis C2 — mit Wörterbuch-Tap.",
    descFa: "متن‌ها و پادکست‌های واقعی، از A1 تا C2 — با لمس روی هر کلمه.",
    color: "#22C55E",
    tag: "Immersion",
  },
  {
    icon: GraduationCap,
    title: "Prüfungen üben",
    fa: "آمادگی آزمون",
    desc: "Original-nahe Aufgaben für Goethe, telc und ÖSD mit sofortiger Auswertung.",
    descFa: "سوال‌های نزدیک به اصل گوته، telc و ÖSD با ارزیابی فوری.",
    color: "#EF4444",
    tag: "Prüfung",
  },
  {
    icon: BarChart3,
    title: "Statistiken",
    fa: "آمار رشد",
    desc: "Heatmap, Wortarten-Fortschritt, Serien und Retention — sieh, wie du wächst.",
    descFa: "هیت‌مپ، پیشرفت اجزای کلام، سری‌ها و ماندگاری — رشدت را ببین.",
    color: "#0EA5E9",
    tag: "Analyse",
  },
  {
    icon: ShieldCheck,
    title: "100% offline",
    fa: "کاملاً آفلاین",
    desc: "Alle Daten leben in deinem Browser. Kein Konto-Zwang, kein Tracking, kein Umweg.",
    descFa: "همه چیز در مرورگر خودت. بدون حساب اجباری، بدون ردیابی.",
    color: "#1a1a1a",
    tag: "Privatsphäre",
  },
  {
    icon: Music,
    title: "Musik & Karaoke",
    fa: "موزیک و کارائوکه",
    desc: "Deutsche Songs Zeile für Zeile mitlesen, Vokabeln direkt aus dem Text sammeln.",
    descFa: "آهنگ‌های آلمانی را خط‌به‌خط بخوان و واژه‌ها را از دل متن ذخیره کن.",
    color: "#DB2777",
    tag: "Neu",
  },
  {
    icon: Film,
    title: "Kino & Serien",
    fa: "سینما و سریال",
    desc: "Szenen mit Untertiteln, Redewendungen und Wortschatz aus echten Filmen.",
    descFa: "صحنه‌ها با زیرنویس، اصطلاح‌ها و واژگان از فیلم‌های واقعی.",
    color: "#7C3AED",
    tag: "Neu",
  },
  {
    icon: Network,
    title: "Wortfamilien",
    fa: "خانواده واژه‌ها",
    desc: "Ein Wortstamm, seine ganze Familie — Präfixe, Suffixe und Wortbildung visuell.",
    descFa: "یک ریشه و همه‌ی هم‌خانواده‌هایش — پیشوند، پسوند و ساخت واژه به‌صورت تصویری.",
    color: "#0D9488",
    tag: "Neu",
  },
  {
    icon: PenLine,
    title: "Schreibtrainer",
    fa: "تمرین نوشتن",
    desc: "Briefe und Aufsätze schreiben, mit KI-Feedback zu Grammatik, Stil und Struktur.",
    descFa: "نامه و انشا بنویس و بازخورد هوش مصنوعی درباره‌ی گرامر، سبک و ساختار بگیر.",
    color: "#EA580C",
    tag: "Neu",
  },
  {
    icon: Users,
    title: "Community & Tandem",
    fa: "جامعه و همتا",
    desc: "Chats, Lerngruppen und Tandem-Partner — Deutsch üben mit echten Menschen.",
    descFa: "گفت‌وگو، گروه‌های یادگیری و شریک زبانی همتا — تمرین آلمانی با آدم‌های واقعی.",
    color: "#2563EB",
    tag: "Neu",
  },
  {
    icon: CalendarDays,
    title: "Events & Stammtisch",
    fa: "رویدادها",
    desc: "Sprach-Events online und vor Ort finden, Platz reservieren und teilnehmen.",
    descFa: "رویدادهای زبانی آنلاین و حضوری را پیدا کن، جا رزرو کن و شرکت کن.",
    color: "#16A34A",
    tag: "Neu",
  },
  {
    icon: Trophy,
    title: "Erfolge & Serien",
    fa: "دستاوردها",
    desc: "Missionen, Medaillen, Season-Ziele und Leaderboard — Motivation, die bleibt.",
    descFa: "ماموریت‌ها، مدال‌ها، اهداف فصلی و جدول رتبه‌بندی — انگیزه‌ای که می‌ماند.",
    color: "#F59E0B",
    tag: "Neu",
  },
  {
    icon: Library,
    title: "Bücher & Sprichwörter",
    fa: "کتاب‌ها و ضرب‌المثل‌ها",
    desc: "Kuratierte Wortschatz-Bücher, eigene Wortlisten und deutsche Redewendungen.",
    descFa: "کتاب‌های واژگان، فهرست‌های شخصی و ضرب‌المثل‌های آلمانی.",
    color: "#0EA5E9",
    tag: "Neu",
  },
];

function Features() {
  return (
    <section
      id="features"
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="Was DEUSI kann"
        kickerFa="دئوسی چه می‌کند"
        title={
          <>
            Alles, was du für Deutsch brauchst.
            <br />
            <span style={{ color: "var(--flag-red)" }}>An einem Ort.</span>
          </>
        }
        titleFa={
          <>
            هر چیزی که برای آلمانی نیاز داری —{" "}
            <span style={{ color: "var(--flag-red)" }}>یکجا.</span>
          </>
        }
        subtitle="Ein Werkzeugkasten, der mitwächst — vom ersten Artikel bis zum Konjunktiv II."
        subtitleFa="جعبه‌ابزاری که با تو رشد می‌کند — از اولین حرف تعریف تا کنیونکتیو ۲."
      />

      <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map((f, i) => (
          <FeatureCard key={f.title} {...f} index={i} />
        ))}
      </div>
    </section>
  );
}

function FeatureCard({
  icon: Icon,
  title,
  fa,
  desc,
  descFa,
  color,
  tag,
  index,
}: (typeof FEATURES)[number] & { index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const mx = useMotionValue(0),
    my = useMotionValue(0);
  const spotlight = useMotionTemplate`radial-gradient(280px circle at ${mx}px ${my}px, ${color}22, transparent 70%)`;

  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set(e.clientX - r.left);
    my.set(e.clientY - r.top);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, ease: EASE, delay: (index % 4) * 0.08 }}
      whileHover={{ y: -6 }}
      className="group relative overflow-hidden rounded-3xl border border-border bg-card p-6 transition-shadow hover:shadow-2xl"
    >
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -inset-px rounded-3xl opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{ background: spotlight }}
      />
      <div
        aria-hidden
        className="absolute -right-8 -top-8 h-28 w-28 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-70"
        style={{ background: color }}
      />

      <div className="relative">
        <div className="flex items-start justify-between">
          <motion.div
            whileHover={{ rotate: -6, scale: 1.05 }}
            transition={{ type: "spring", stiffness: 250, damping: 15 }}
            className="grid h-12 w-12 place-items-center rounded-2xl text-white shadow-lg"
            style={{
              background: `linear-gradient(135deg, ${color}, ${color}cc)`,
              boxShadow: `0 15px 30px -12px ${color}80`,
            }}
          >
            <Icon className="h-5 w-5" />
          </motion.div>
          <span className="rounded-full border border-border px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
            {tag}
          </span>
        </div>
        <h3 className="mt-5 font-display text-lg font-black tracking-tight">{title}</h3>
        <div dir="rtl" className="fa-inline mt-0.5 text-sm font-bold" style={{ color }}>
          {fa}
        </div>
        <p className="mt-3 text-sm text-muted-foreground">{desc}</p>
        <p dir="rtl" className="fa-inline mt-2 text-sm text-muted-foreground/85">
          {descFa}
        </p>
        <div className="mt-5 flex items-center gap-1.5 text-xs font-bold" style={{ color }}>
          Mehr <FA className="opacity-80">· بیشتر</FA>
          <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
        </div>
      </div>
    </motion.div>
  );
}

/* ---------- FLASHCARD SHOWCASE (interactive flip) ---------- */
function FlashcardShowcase() {
  const [flipped, setFlipped] = useState(false);
  const cards = [
    {
      front: "die Sehnsucht",
      back: "longing · desire",
      fa: "دلتنگی",
      ex: "Er spürt eine große Sehnsucht nach der Heimat.",
      exFa: "او دلتنگی بزرگی برای وطن حس می‌کند.",
    },
    {
      front: "der Feierabend",
      back: "end of workday",
      fa: "پایان روز کاری",
      ex: "Nach dem Feierabend gehen wir spazieren.",
      exFa: "بعد از پایان کار، پیاده‌روی می‌کنیم.",
    },
    {
      front: "das Fernweh",
      back: "wanderlust",
      fa: "شوق سفر",
      ex: "Das Fernweh packt mich jedes Frühjahr.",
      exFa: "شوق سفر هر بهار سراغم می‌آید.",
    },
  ];
  const [i, setI] = useState(0);
  const c = cards[i];

  return (
    <section
      id="cards"
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <div>
          <SectionHeader
            align="left"
            kicker="Karten mit Charakter"
            kickerFa="کارت‌هایی با شخصیت"
            title={
              <>
                Klick sie um.
                <br />
                <span style={{ color: "var(--flag-red)" }}>Fühl das Deutsche.</span>
              </>
            }
            titleFa={
              <>
                روی کارت کلیک کن. <span style={{ color: "var(--flag-red)" }}>آلمانی را حس کن.</span>
              </>
            }
            subtitle="Jede Karte kennt ihre Wortart — mit Artikel, Kontextsatz und einem Klick zur Bedeutung. FSRS entscheidet, wann du sie wiedersiehst."
            subtitleFa="هر کارت نوع کلمه‌اش را می‌شناسد — با حرف تعریف، جمله و یک کلیک تا معنی. FSRS تصمیم می‌گیرد کِی دوباره ببینی‌اش."
          />
          <ul className="mt-8 space-y-3">
            {[
              ["Artikel-Farbcode für der/die/das", "کد رنگی برای der/die/das"],
              ["Beispielsätze aus echten Texten", "جمله‌های نمونه از متن‌های واقعی"],
              [
                "Vier Bewertungen: Nochmal · Schwer · Gut · Leicht",
                "چهار درجه: دوباره · سخت · خوب · آسان",
              ],
              ["Automatische Wiederholung durch FSRS 5", "مرور خودکار با FSRS 5"],
            ].map(([de, fa], k) => (
              <motion.li
                key={de}
                initial={{ opacity: 0, x: -12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: k * 0.08, duration: 0.5 }}
                className="flex items-start gap-3 text-sm"
              >
                <span
                  className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-bold text-white"
                  style={{ background: "var(--flag-red)" }}
                >
                  ✓
                </span>
                <span className="min-w-0">
                  <span>{de}</span>
                  <FA className="ml-2 text-muted-foreground">· {fa}</FA>
                </span>
              </motion.li>
            ))}
          </ul>
        </div>

        <div className="flex flex-col items-center gap-6">
          <div className="flip-scene w-full max-w-sm" style={{ perspective: 1400 }}>
            <motion.button
              type="button"
              onClick={() => setFlipped((f) => !f)}
              whileHover={{ y: -4 }}
              animate={{ rotateY: flipped ? 180 : 0 }}
              transition={{ duration: 0.8, ease: EASE }}
              className="relative aspect-[3/4] w-full cursor-pointer"
              style={{ transformStyle: "preserve-3d" }}
              aria-label="Karte umdrehen"
            >
              {/* FRONT */}
              <div
                className="card-glass absolute inset-0 flex flex-col justify-between p-8"
                style={{ backfaceVisibility: "hidden" }}
              >
                <div
                  className="inline-flex w-fit items-center gap-2 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider"
                  style={{
                    background: c.front.startsWith("der")
                      ? "#2563eb"
                      : c.front.startsWith("die")
                        ? "#DD2222"
                        : "#22C55E",
                    color: "#fff",
                  }}
                >
                  {c.front.split(" ")[0]}
                </div>
                <div className="text-center">
                  <div className="font-display text-4xl font-black tracking-tight">{c.front}</div>
                  <div dir="rtl" className="fa-inline mt-2 text-lg font-bold text-muted-foreground">
                    {c.fa}
                  </div>
                  <div className="mt-4 text-xs text-muted-foreground">
                    Klicke, um zu drehen <FA>· برای برگرداندن کلیک کن</FA>
                  </div>
                </div>
                <div className="flex justify-center gap-1.5">
                  {cards.map((_, k) => (
                    <span
                      key={k}
                      className={`h-1.5 rounded-full transition-all ${k === i ? "w-6 bg-foreground" : "w-1.5 bg-muted-foreground/30"}`}
                    />
                  ))}
                </div>
              </div>
              {/* BACK */}
              <div
                className="card-glass absolute inset-0 flex flex-col justify-between p-8"
                style={{
                  backfaceVisibility: "hidden",
                  transform: "rotateY(180deg)",
                  background: "linear-gradient(160deg, #1a1a1a 0%, #2a1010 55%, #DD2222 130%)",
                  color: "#fff",
                }}
              >
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/70">
                  Bedeutung <FA className="text-white/60">· معنی</FA>
                </div>
                <div className="text-center">
                  <div
                    className="font-display text-3xl font-black tracking-tight"
                    style={{ color: "#F7C948" }}
                  >
                    {c.back}
                  </div>
                  <p className="mt-4 text-sm italic text-white/80">„{c.ex}"</p>
                  <p dir="rtl" className="fa-inline mt-2 text-sm italic text-white/70">
                    «{c.exFa}»
                  </p>
                </div>
                <div className="flex justify-center gap-1.5">
                  {["#EF4444", "#F59E0B", "#3B82F6", "#22C55E"].map((color) => (
                    <span
                      key={color}
                      className="h-2 w-6 rounded-full"
                      style={{ background: color }}
                    />
                  ))}
                </div>
              </div>
            </motion.button>
          </div>
          <div className="flex items-center gap-2">
            {cards.map((_, k) => (
              <button
                key={k}
                onClick={() => {
                  setFlipped(false);
                  setI(k);
                }}
                className={`h-2 rounded-full transition-all ${k === i ? "w-8 bg-foreground" : "w-2 bg-muted-foreground/30 hover:bg-muted-foreground/60"}`}
                aria-label={`Karte ${k + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- STATS ---------- */
function Stats() {
  const items = [
    { n: 12000, s: "+", label: "Vokabeln kuratiert", labelFa: "واژه انتخاب‌شده" },
    { n: 96, s: "%", label: "Retention nach 30 Tagen", labelFa: "ماندگاری بعد ۳۰ روز" },
    { n: 6, s: "", label: "Sprachniveaus (A1–C2)", labelFa: "سطح زبانی" },
    { n: 0, s: "", label: "Kosten, keine Werbung", labelFa: "هزینه، بدون تبلیغ", suffix: "€" },
  ];
  return (
    <section className="mx-auto max-w-[1400px] px-5 lg:px-12 py-16 sm:px-8">
      <div className="relative overflow-hidden rounded-[2rem] border border-border bg-card p-8 sm:p-12">
        <div
          aria-hidden
          className="absolute -right-24 -top-24 h-64 w-64 rounded-full opacity-40 blur-3xl"
          style={{ background: "var(--flag-red)" }}
        />
        <div
          aria-hidden
          className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full opacity-40 blur-3xl"
          style={{ background: "var(--flag-gold)" }}
        />
        <div className="relative grid grid-cols-2 gap-8 lg:grid-cols-4">
          {items.map((it, i) => (
            <StatItem key={i} {...it} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StatItem({
  n,
  s,
  label,
  labelFa,
  suffix,
}: {
  n: number;
  s: string;
  label: string;
  labelFa: string;
  suffix?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, n, {
      duration: 1.6,
      ease: EASE,
      onUpdate: (val: number) => setV(Math.round(val)),
    });
    return () => controls.stop();
  }, [inView, n]);
  return (
    <div>
      <div className="flex items-baseline gap-1">
        {suffix && (
          <span className="font-display text-2xl font-black text-muted-foreground">{suffix}</span>
        )}
        <span
          ref={ref}
          className="font-display text-4xl font-black tracking-tight sm:text-5xl"
          style={{ color: "var(--flag-red)" }}
        >
          {v}
        </span>
        <span className="font-display text-2xl font-black">{s}</span>
      </div>
      <div className="mt-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <FA className="mt-0.5 block text-xs text-muted-foreground/85">{labelFa}</FA>
    </div>
  );
}

/* ---------- JOURNEY ---------- */
function Journey() {
  const steps = [
    {
      n: "01",
      t: "Anmelden in 60 s",
      tFa: "ثبت‌نام در ۶۰ ثانیه",
      d: "Benutzername, E-Mail, fertig. Kein Kreditkarten-Zwang.",
      dFa: "نام کاربری، ایمیل، تمام. بدون کارت اعتباری.",
      c: "#1a1a1a",
    },
    {
      n: "02",
      t: "Niveau wählen",
      tFa: "انتخاب سطح",
      d: "A1 bis C2 — DEUSI stellt deinen Pfad zusammen.",
      dFa: "از A1 تا C2 — دئوسی مسیرت را می‌سازد.",
      c: "#DD2222",
    },
    {
      n: "03",
      t: "Täglich üben",
      tFa: "تمرین روزانه",
      d: "10 Minuten reichen. FSRS wählt die richtigen Karten.",
      dFa: "ده دقیقه کافی‌ست. FSRS کارت‌های درست را انتخاب می‌کند.",
      c: "#F7C948",
    },
    {
      n: "04",
      t: "Fortschritt sehen",
      tFa: "دیدن پیشرفت",
      d: "Heatmap, Serien, Retention — visualisiert und ehrlich.",
      dFa: "هیت‌مپ، سری‌ها، ماندگاری — تصویری و صادقانه.",
      c: "#22C55E",
    },
  ];

  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const lineScale = useTransform(scrollYProgress, [0.2, 0.85], [0, 1]);

  return (
    <section
      id="journey"
      ref={ref}
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="So funktioniert es"
        kickerFa="چطور کار می‌کند"
        title={
          <>
            Vier Schritte.
            <br />
            <span style={{ color: "var(--flag-red)" }}>Ein neuer Alltag.</span>
          </>
        }
        titleFa={
          <>
            چهار قدم. <span style={{ color: "var(--flag-red)" }}>یک آیین تازه.</span>
          </>
        }
        subtitle="Kein Schnickschnack, kein Auswendiglernen alter Listen — nur ein Ritual, das trägt."
        subtitleFa="بدون شلوغی، بدون حفظ لیست‌های خشک — فقط یک آیین که تو را می‌برد."
      />
      <div className="relative mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-6 top-14 hidden h-px lg:block bg-border"
        />
        <motion.div
          aria-hidden
          className="pointer-events-none absolute inset-x-6 top-14 hidden h-[2px] lg:block"
          style={{
            scaleX: lineScale,
            transformOrigin: "0% 50%",
            background: "linear-gradient(90deg, #1a1a1a, #DD2222 45%, #F7C948)",
          }}
        />
        {steps.map((s, i) => (
          <motion.div
            key={s.n}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ delay: i * 0.1, duration: 0.6, ease: EASE }}
            whileHover={{ y: -6 }}
            className="relative rounded-3xl border border-border bg-card p-6 transition-shadow hover:shadow-2xl"
          >
            <div
              className="relative z-10 grid h-14 w-14 place-items-center rounded-2xl font-display text-lg font-black text-white shadow-lg"
              style={{
                background: `linear-gradient(135deg, ${s.c}, ${s.c}aa)`,
                boxShadow: `0 20px 30px -15px ${s.c}80`,
              }}
            >
              {s.n}
            </div>
            <h3 className="mt-5 font-display text-lg font-black tracking-tight">{s.t}</h3>
            <FA className="mt-0.5 block text-sm font-bold" style={{ color: s.c }}>
              {s.tFa}
            </FA>
            <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            <FA className="mt-2 block text-sm text-muted-foreground/85">{s.dFa}</FA>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ---------- TESTIMONIALS ---------- */
function Testimonials() {
  const items = [
    {
      name: "Lena K.",
      role: "B2 Vorbereitung",
      roleFa: "آمادگی B2",
      text: "Nach zwei Monaten DEUSI habe ich meine telc B2 mit 89% bestanden. Der FSRS-Rhythmus macht den Unterschied.",
      textFa: "بعد از دو ماه دئوسی، telc B2 را با ۸۹٪ قبول شدم. ریتم FSRS همه‌چیز را عوض می‌کند.",
      init: "L",
      c: "#DD2222",
    },
    {
      name: "Ahmad R.",
      role: "Neu in Berlin",
      roleFa: "تازه‌وارد برلین",
      text: "Endlich eine App, die der/die/das nicht als Nebensache behandelt. Die Farbcodes bleiben einfach hängen.",
      textFa: "بالاخره اپی که der/die/das را فرعی نگرفت. کد رنگی‌اش تو ذهن می‌ماند.",
      init: "A",
      c: "#F7C948",
    },
    {
      name: "Marta S.",
      role: "C1 Prüfungsvorbereitung",
      roleFa: "آمادگی C1",
      text: "Die Prüfungssimulationen sind erstaunlich nah am Original. Und der KI-Coach erklärt geduldig.",
      textFa: "شبیه‌ساز آزمون‌ها فوق‌العاده نزدیک به اصل است. مربی هوشمندش هم با صبر توضیح می‌دهد.",
      init: "M",
      c: "#2563eb",
    },
  ];
  return (
    <section
      id="testimonials"
      className="mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="Stimmen von Lernenden"
        kickerFa="صدای یادگیرنده‌ها"
        title={
          <>
            Von Menschen,
            <br />
            <span style={{ color: "var(--flag-red)" }}>die es geschafft haben.</span>
          </>
        }
        titleFa={
          <>
            از کسانی که <span style={{ color: "var(--flag-red)" }}>موفق شدند.</span>
          </>
        }
      />
      <div className="mt-14 grid gap-5 md:grid-cols-3">
        {items.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.6, ease: EASE }}
            whileHover={{ y: -6 }}
            className="relative rounded-3xl border border-border bg-card p-6 transition-shadow hover:shadow-2xl"
          >
            <div className="mb-3 flex gap-0.5" style={{ color: "#F7C948" }}>
              {Array.from({ length: 5 }).map((_, k) => (
                <Star key={k} className="h-4 w-4 fill-current" />
              ))}
            </div>
            <p className="text-sm leading-relaxed text-foreground">„{t.text}"</p>
            <p dir="rtl" className="fa-inline mt-2 text-sm leading-relaxed text-muted-foreground">
              «{t.textFa}»
            </p>
            <div className="mt-6 flex items-center gap-3 border-t border-border pt-4">
              <div
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full font-display text-sm font-black text-white"
                style={{ background: t.c }}
              >
                {t.init}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-bold">{t.name}</div>
                <div className="text-xs text-muted-foreground">
                  {t.role} <FA>· {t.roleFa}</FA>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ---------- FINAL CTA ---------- */
function FinalCTA() {
  return (
    <section className="mx-auto max-w-[1400px] px-4 pb-24 sm:px-8">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7, ease: EASE }}
        className="relative overflow-hidden rounded-[2.5rem] p-8 text-white sm:p-16"
        style={{
          background: "linear-gradient(135deg, #0d0d0d 0%, #2a1010 45%, #DD2222 85%, #F7C948 140%)",
          boxShadow: "0 60px 120px -50px rgba(221,34,34,0.7)",
        }}
      >
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-black/40 blur-3xl" />
          <svg
            className="absolute right-8 top-8 h-32 w-32 opacity-15"
            viewBox="0 0 100 100"
            fill="none"
          >
            <polygon points="50,4 96,27 96,73 50,96 4,73 4,27" stroke="white" strokeWidth="1" />
            <polygon points="50,20 80,35 80,65 50,80 20,65 20,35" stroke="white" strokeWidth="1" />
          </svg>
        </div>
        <div className="relative max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold uppercase tracking-widest backdrop-blur">
            <Sparkles className="h-3.5 w-3.5" style={{ color: "#F7C948" }} /> Bereit?{" "}
            <FA className="tracking-normal">· آماده‌ای؟</FA>
          </div>
          <h2 className="mt-5 font-display text-4xl font-black leading-[1.05] tracking-tight sm:text-6xl">
            Dein Deutsch
            <br />
            beginnt <span style={{ color: "#F7C948" }}>jetzt.</span>
          </h2>
          <p dir="rtl" className="fa-inline mt-3 text-2xl font-black leading-tight sm:text-4xl">
            آلمانی‌ات از <span style={{ color: "#F7C948" }}>همین حالا</span> شروع می‌شود.
          </p>
          <p className="mt-4 max-w-lg text-white/80">
            Erstelle dein kostenloses Konto und lerne heute noch deine ersten fünf Karten.
          </p>
          <p dir="rtl" className="fa-inline mt-1 max-w-lg text-white/75">
            حساب رایگانت را بساز و همین امروز پنج کارت اولت را یاد بگیر.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/register"
              className="group inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-3.5 text-sm font-bold text-[#0d0d0d] shadow-2xl transition hover:scale-[1.02]"
            >
              Kostenlos starten <FA className="text-[#0d0d0d]/70">· رایگان شروع کن</FA>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 rounded-2xl border border-white/25 bg-white/10 px-5 py-3.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
            >
              Ich habe schon ein Konto <FA className="text-white/70">· حساب دارم</FA>
            </Link>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

/* ---------- FOOTER ---------- */
function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-[1400px] flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-8">
        <Logo />
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} DEUSI · Deutsch. Einfach. Meistern.
        </p>
        <div className="flex gap-4 text-xs font-semibold text-muted-foreground">
          <Link to="/impressum" className="hover:text-foreground">
            Impressum
          </Link>
          <Link to="/datenschutz" className="hover:text-foreground">
            Datenschutz
          </Link>
          <Link to="/support" className="hover:text-foreground">
            Kontakt
          </Link>
        </div>
      </div>
    </footer>
  );
}

/* ---------- Shared ---------- */
function SectionHeader({
  kicker,
  kickerFa,
  title,
  titleFa,
  subtitle,
  subtitleFa,
  align = "center",
}: {
  kicker: string;
  kickerFa?: string;
  title: React.ReactNode;
  titleFa?: React.ReactNode;
  subtitle?: string;
  subtitleFa?: string;
  align?: "center" | "left";
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, ease: EASE }}
      className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-xl"}
    >
      <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-muted-foreground backdrop-blur">
        <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--flag-red)" }} />
        {kicker}
        {kickerFa && (
          <>
            <span className="opacity-50">·</span>
            <FA className="tracking-normal">{kickerFa}</FA>
          </>
        )}
      </div>
      <h2 className="mt-4 font-display text-4xl font-black leading-[1.05] tracking-tight sm:text-5xl">
        {title}
      </h2>
      {titleFa && (
        <div
          dir="rtl"
          className={`fa-inline mt-3 text-2xl font-black leading-tight text-muted-foreground sm:text-3xl ${align === "left" ? "text-right" : ""}`}
        >
          {titleFa}
        </div>
      )}
      {subtitle && <p className="mt-4 text-base text-muted-foreground">{subtitle}</p>}
      {subtitleFa && (
        <p
          dir="rtl"
          className={`fa-inline mt-2 text-base text-muted-foreground/85 ${align === "left" ? "text-right" : ""}`}
        >
          {subtitleFa}
        </p>
      )}
    </motion.div>
  );
}

/* ============================================================
   HORIZONTAL FEATURES — pinned vertical scroll → horizontal pan
   ============================================================ */
function HorizontalFeatures() {
  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const x = useTransform(scrollYProgress, [0, 1], ["2%", "-78%"]);

  const panels = [
    {
      n: "01",
      de: "Wortschatz",
      fa: "واژه",
      desc: "12 000 kuratierte Wörter mit Artikel, Beispiel und Ton.",
      descFa: "دوازده هزار واژهٔ گزیده با حرف تعریف، جمله و صدا.",
      c: "#DD2222",
      icon: BookOpen,
    },
    {
      n: "02",
      de: "Grammatik",
      fa: "گرامر",
      desc: "Interaktive Pfade von A1 bis C2 — Fälle, Zeiten, Modi.",
      descFa: "مسیر تعاملی از A1 تا C2 — حالت‌ها، زمان‌ها، وجوه.",
      c: "#F7C948",
      icon: Brain,
    },
    {
      n: "03",
      de: "KI-Coach",
      fa: "کوچ هوشمند",
      desc: "Chatte auf deinem Niveau, bekomme Korrekturen mit Erklärung.",
      descFa: "در سطح خودت گفت‌وگو کن، اصلاح و توضیح بگیر.",
      c: "#8B5CF6",
      icon: MessageSquare,
    },
    {
      n: "04",
      de: "Podcasts",
      fa: "پادکست",
      desc: "Echte Stimmen mit interaktivem Transkript und Wörterbuch.",
      descFa: "صداهای واقعی با متن تعاملی و دیکشنری زیر انگشت.",
      c: "#22C55E",
      icon: Headphones,
    },
    {
      n: "05",
      de: "Prüfungen",
      fa: "آزمون",
      desc: "Original-nahe Goethe / telc / ÖSD-Simulationen.",
      descFa: "شبیه‌سازهای نزدیک به اصل گوته، telc و ÖSD.",
      c: "#0EA5E9",
      icon: GraduationCap,
    },
    {
      n: "06",
      de: "Statistik",
      fa: "آمار",
      desc: "Heatmap, Serien, Wortarten — dein Rhythmus in Echtzeit.",
      descFa: "هیت‌مپ، سری‌ها و اجزای کلام — ریتم تو، لحظه‌ای.",
      c: "#EF4444",
      icon: BarChart3,
    },
  ];

  return (
    <section ref={ref} className="relative" data-h-features>
      {isMobile ? (
        <div className="mx-auto max-w-3xl px-5 py-16">
          <div className="mb-8 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.4em]">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#DD2222" }} />
            Universum · <FA className="tracking-normal">جهان دئوسی</FA>
          </div>
          <div className="grid gap-4">
            {panels.map((p) => {
              const Icon = p.icon;
              return (
                <motion.div
                  key={p.n}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-10% 0px" }}
                  transition={{ duration: 0.45, ease: EASE }}
                  className="rounded-2xl border border-border bg-card p-5"
                >
                  <div className="mb-3 flex items-center justify-between">
                    <span
                      className="grid h-9 w-9 place-items-center rounded-xl text-white"
                      style={{ background: p.c }}
                    >
                      <Icon className="h-4.5 w-4.5" />
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-[0.35em] text-muted-foreground">
                      {p.n}
                    </span>
                  </div>
                  <div className="font-display text-xl font-black tracking-tight">{p.de}</div>
                  <div
                    dir="rtl"
                    className="fa-inline mt-0.5 text-base font-black"
                    style={{ color: p.c }}
                  >
                    {p.fa}
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
                  <p dir="rtl" className="fa-inline mt-1 text-xs text-muted-foreground/85">
                    {p.descFa}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      ) : (
        <div style={{ height: `${panels.length * 90}vh` }}>
          <div className="sticky top-0 flex h-screen items-center overflow-hidden">
            <div className="absolute inset-x-0 top-8 z-10 flex items-center justify-between px-6 sm:px-10">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.4em]">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#DD2222" }} />
                Universum · <FA className="tracking-normal">جهان دئوسی</FA>
              </div>
              <HorizontalProgress progress={scrollYProgress} total={panels.length} />
            </div>

            <motion.div
              style={{ x }}
              className="flex gap-6 pl-[6vw] pr-[20vw] will-change-transform"
            >
              {panels.map((p, i) => (
                <HorizontalPanel
                  key={p.n}
                  {...p}
                  index={i}
                  total={panels.length}
                  progress={scrollYProgress}
                />
              ))}
            </motion.div>

            <div className="pointer-events-none absolute bottom-6 left-0 right-0 flex justify-center text-[10px] font-bold uppercase tracking-[0.4em] opacity-60">
              Scroll ↓ · <FA className="ml-1 tracking-normal">پایین بیا</FA>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function HorizontalProgress({ progress, total }: { progress: MotionValue<number>; total: number }) {
  const w = useTransform(progress, [0, 1], ["0%", "100%"]);
  return (
    <div className="hidden items-center gap-3 sm:flex">
      <span className="text-[10px] font-bold uppercase tracking-[0.4em] opacity-70">
        01 / {String(total).padStart(2, "0")}
      </span>
      <div className="relative h-[3px] w-40 overflow-hidden rounded-full bg-current/15">
        <motion.div style={{ width: w }} className="h-full rounded-full">
          <div
            className="h-full w-full"
            style={{ background: "linear-gradient(90deg, #F7C948, #DD2222)" }}
          />
        </motion.div>
      </div>
    </div>
  );
}

function HorizontalPanel({
  n,
  de,
  fa,
  desc,
  descFa,
  c,
  icon: Icon,
  index,
  total,
  progress,
}: {
  n: string;
  de: string;
  fa: string;
  desc: string;
  descFa: string;
  c: string;
  icon: typeof BookOpen;
  index: number;
  total: number;
  progress: MotionValue<number>;
}) {
  const start = index / total;
  const mid = start + 1 / total / 2;
  const end = (index + 1) / total;
  const scale = useTransform(progress, [start, mid, end], [0.92, 1, 0.92]);
  const glow = useTransform(progress, [start, mid, end], [0.15, 0.9, 0.15]);
  // Arc — cards tilt at the edges, straighten in the middle.
  // Cards flow right → left, so before centre they lean right, after centre they lean left.
  const rotate = useTransform(progress, [start, mid, end], [7, 0, -7]);
  const yArc = useTransform(progress, [start, mid, end], [28, 0, 28]);

  return (
    <motion.div
      style={{ scale, rotate, y: yArc, transformOrigin: "50% 90%" }}
      className="relative flex h-[74vh] w-[78vw] shrink-0 flex-col justify-between overflow-hidden rounded-[2.5rem] border border-border bg-card p-8 sm:w-[62vw] sm:p-12 md:w-[46vw] lg:w-[38vw]"
    >
      <div
        className="absolute inset-0"
        style={{ background: `linear-gradient(160deg, ${c}18 0%, transparent 40%, ${c}30 100%)` }}
      />
      <motion.div
        aria-hidden
        style={{ opacity: glow }}
        className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full blur-3xl"
      >
        <div className="h-full w-full rounded-full" style={{ background: c }} />
      </motion.div>
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage: "radial-gradient(currentColor 1px, transparent 1px)",
          backgroundSize: "22px 22px",
        }}
      />

      <div className="relative flex items-start justify-between">
        <div
          className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-2xl"
          style={{
            background: `linear-gradient(135deg, ${c}, ${c}bb)`,
            boxShadow: `0 25px 60px -20px ${c}`,
          }}
        >
          <Icon className="h-7 w-7" />
        </div>
        <span className="font-display text-6xl font-black leading-none opacity-15 sm:text-8xl">
          {n}
        </span>
      </div>

      <div className="relative">
        <div className="font-display text-5xl font-black tracking-tight sm:text-7xl">{de}</div>
        <div
          dir="rtl"
          className="fa-inline mt-2 text-3xl font-black sm:text-4xl"
          style={{ color: c }}
        >
          {fa}
        </div>
        <p className="mt-5 max-w-md text-base opacity-80 sm:text-lg">{desc}</p>
        <p dir="rtl" className="fa-inline mt-2 max-w-md text-sm opacity-70 sm:text-base">
          {descFa}
        </p>
        <div className="mt-6 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.4em] opacity-70">
          <span className="h-px w-10 bg-current" />
          Modul {index + 1} / {total}
          <FA className="tracking-normal">· بخش</FA>
        </div>
      </div>
    </motion.div>
  );
}

/* ============================================================
   APP SHOWCASE — scroll-stacked cards (each pins & scales)
   ============================================================ */
function AppShowcase() {
  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });

  const modules = [
    {
      tag: "Karten",
      tagFa: "کارت‌ها",
      title: "Deine tägliche Karten-Session",
      titleFa: "جلسهٔ روزانهٔ کارت‌های تو",
      c: "#DD2222",
      body: (
        <div className="grid grid-cols-3 gap-2">
          {[
            ["der", "der Baum", "درخت", "#2563eb"],
            ["die", "die Sonne", "خورشید", "#DD2222"],
            ["das", "das Licht", "نور", "#F7C948"],
            ["der", "der Weg", "راه", "#2563eb"],
            ["die", "die Welt", "جهان", "#DD2222"],
            ["das", "das Herz", "دل", "#F7C948"],
          ].map(([tag, w, fa, col]) => (
            <div key={w} className="rounded-2xl border border-border bg-card p-3">
              <span
                className="inline-block rounded-full px-2 py-0.5 text-[9px] font-bold uppercase text-white"
                style={{ background: col }}
              >
                {tag}
              </span>
              <div className="mt-2 font-display text-sm font-black tracking-tight">{w}</div>
              <div
                dir="rtl"
                className="fa-inline text-[11px] font-bold"
                style={{ color: col as string }}
              >
                {fa}
              </div>
            </div>
          ))}
        </div>
      ),
    },
    {
      tag: "Grammatik",
      tagFa: "گرامر",
      title: "Grammatik als Landkarte",
      titleFa: "گرامر مثل نقشه",
      c: "#F7C948",
      body: (
        <div className="relative h-40">
          {[
            ["Nomen", 10, 20],
            ["Verben", 40, 55],
            ["Artikel", 8, 90],
            ["Kasus", 55, 30],
            ["Passiv", 78, 70],
          ].map(([t, x, y], i) => (
            <div
              key={i}
              className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold shadow"
              style={{ left: `${x}%`, top: `${y}%` }}
            >
              {t as string}
            </div>
          ))}
          <svg
            className="absolute inset-0 h-full w-full"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
          >
            <path
              d="M10,20 Q30,10 40,55 T55,30 T78,70"
              stroke="#F7C948"
              strokeDasharray="3 3"
              strokeWidth="0.5"
              fill="none"
            />
          </svg>
        </div>
      ),
    },
    {
      tag: "KI-Coach",
      tagFa: "مربی هوشمند",
      title: "Sprich frei — bekomme Korrekturen",
      titleFa: "آزاد حرف بزن، اصلاح بگیر",
      c: "#8B5CF6",
      body: (
        <div className="space-y-2 text-sm">
          <div className="ml-auto max-w-[80%] rounded-2xl rounded-br-sm bg-secondary px-3 py-2">
            Gestern ich habe Pizza gegessen.
          </div>
          <div className="max-w-[85%] rounded-2xl rounded-bl-sm border border-border bg-card px-3 py-2">
            <span className="font-bold text-[#8B5CF6]">
              Gestern <span className="line-through opacity-60">ich habe</span>{" "}
              <span className="underline">habe ich</span> Pizza gegessen.
            </span>
            <div className="mt-1 text-xs text-muted-foreground">
              Im Nebensatz mit Zeitangabe steht das Verb zuerst.
            </div>
            <FA className="mt-1 block text-[11px] text-muted-foreground/85">
              در جمله با قید زمان، فعل اول می‌آید.
            </FA>
          </div>
        </div>
      ),
    },
    {
      tag: "Statistik",
      tagFa: "آمار",
      title: "Dein Rhythmus, sichtbar",
      titleFa: "ریتم تو، قابل‌دیدن",
      c: "#22C55E",
      body: <HeatmapPreview />,
    },
  ];

  return (
    <section
      ref={ref}
      className="relative mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12"
      style={{ height: isMobile ? "auto" : `${modules.length * 100}vh` }}
    >
      {isMobile ? (
        <MobileShowcaseStack modules={modules} />
      ) : (
        <div className="sticky top-0 grid h-screen place-items-center py-10">
          <div className="w-full">
            <div className="mb-6 text-center">
              <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-muted-foreground backdrop-blur">
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ background: "var(--flag-red)" }}
                />
                Live-Vorschau · <FA className="tracking-normal">پیش‌نمایش زنده</FA>
              </div>
            </div>
            <div className="relative mx-auto h-[62vh] max-w-3xl">
              {modules.map((m, i) => (
                <ShowcaseCard
                  key={i}
                  {...m}
                  index={i}
                  total={modules.length}
                  progress={scrollYProgress}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/* Static heatmap grid — deterministic (no Math.random ⇒ no SSR mismatch, no re-render churn). */
function HeatmapPreview() {
  const cells = useMemo(
    () =>
      Array.from({ length: 14 * 7 }).map((_, i) => {
        const v = ((i * 2654435761) >>> 0) / 0xffffffff;
        return v < 0.15
          ? "rgb(var(--shadow-color)/.06)"
          : v < 0.5
            ? "#86efac"
            : v < 0.8
              ? "#22c55e"
              : "#166534";
      }),
    [],
  );
  return (
    <div className="grid gap-1" style={{ gridTemplateColumns: "repeat(14, minmax(0, 1fr))" }}>
      {cells.map((bg, i) => (
        <span key={i} className="aspect-square rounded-[3px]" style={{ background: bg }} />
      ))}
    </div>
  );
}

type ShowcaseModule = {
  tag: string;
  tagFa: string;
  title: string;
  titleFa: string;
  body: React.ReactNode;
  c: string;
};

/* Mobile-friendly plain stack — no scroll-linked transforms, no sticky, no pinned viewport. */
function MobileShowcaseStack({ modules }: { modules: ShowcaseModule[] }) {
  return (
    <div className="py-16">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-muted-foreground backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--flag-red)" }} />
          Live-Vorschau · <FA className="tracking-normal">پیش‌نمایش زنده</FA>
        </div>
      </div>
      <div className="mx-auto grid max-w-3xl gap-5">
        {modules.map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-10% 0px" }}
            transition={{ duration: 0.5, ease: EASE }}
            className="relative overflow-hidden rounded-[1.75rem] border border-border bg-card p-6 shadow-[0_30px_60px_-40px_rgba(20,22,26,0.35)]"
          >
            <div
              className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-40 blur-3xl"
              style={{ background: m.c }}
            />
            <div className="relative">
              <span
                className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest"
                style={{ color: m.c }}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: m.c }} />
                {m.tag} <span className="opacity-60">·</span>{" "}
                <FA className="tracking-normal">{m.tagFa}</FA>
              </span>
              <h3 className="mt-3 font-display text-2xl font-black leading-tight tracking-tight">
                {m.title}
              </h3>
              <div dir="rtl" className="fa-inline mt-1 text-lg font-black" style={{ color: m.c }}>
                {m.titleFa}
              </div>
              <div className="mt-4 rounded-2xl border border-border bg-secondary/50 p-4">
                {m.body}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function ShowcaseCard({
  tag,
  tagFa,
  title,
  titleFa,
  body,
  c,
  index,
  total,
  progress,
}: {
  tag: string;
  tagFa: string;
  title: string;
  titleFa: string;
  body: React.ReactNode;
  c: string;
  index: number;
  total: number;
  progress: MotionValue<number>;
}) {
  const seg = 1 / total;
  const start = index * seg;
  const mid = start + seg * 0.55;
  const end = (index + 1) * seg;
  const scale = useTransform(progress, [start, mid, end], [0.94, 1, 0.9]);
  const y = useTransform(progress, [start, mid, end], [40, 0, -60]);
  const opacity = useTransform(
    progress,
    [start, mid - seg * 0.2, mid, end - seg * 0.05, end],
    [0, 1, 1, 1, 0],
  );
  const rot = useTransform(progress, [start, mid, end], [3, 0, -3]);

  return (
    <motion.div
      style={{ scale, y, opacity, rotate: rot, zIndex: 10 + index }}
      className="absolute inset-0 overflow-hidden rounded-[2rem] border border-border bg-card p-6 shadow-[0_40px_100px_-40px_rgba(20,22,26,0.35)] sm:p-10"
    >
      <div
        className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full opacity-40 blur-3xl"
        style={{ background: c }}
      />
      <div className="relative grid gap-6 md:grid-cols-[1.1fr_1fr]">
        <div>
          <span
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest"
            style={{ color: c }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} />
            {tag} <span className="opacity-60">·</span> <FA className="tracking-normal">{tagFa}</FA>
          </span>
          <h3 className="mt-4 font-display text-3xl font-black leading-tight tracking-tight sm:text-4xl">
            {title}
          </h3>
          <div dir="rtl" className="fa-inline mt-2 text-xl font-black" style={{ color: c }}>
            {titleFa}
          </div>
          <div className="mt-5 flex items-center gap-2 text-xs font-bold text-muted-foreground">
            <span
              className="grid h-6 w-6 place-items-center rounded-full text-white"
              style={{ background: c }}
            >
              {index + 1}
            </span>
            von <span className="opacity-70">{total}</span> · <FA>از {total}</FA>
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-secondary/50 p-4 sm:p-5">{body}</div>
      </div>
    </motion.div>
  );
}

/* ============================================================
   PRICING — creative tiers with monthly/yearly toggle
   ============================================================ */
function Pricing() {
  const [yearly, setYearly] = useState(true);
  const tiers: PricingTier[] = [
    {
      name: "Frei",
      nameFa: "رایگان",
      icon: Rocket,
      c: "#1a1a1a",
      m: 0,
      y: 0,
      tag: "Für den Start",
      tagFa: "برای شروع",
      features: [
        ["500 Karten", "۵۰۰ کارت"],
        ["FSRS 5 & Leitner", "FSRS و لایتنر"],
        ["Grammatik A1–B1", "گرامر A1 تا B1"],
        ["Ohne KI-Coach", "بدون مربی هوشمند"],
      ],
      cta: "Kostenlos starten",
      ctaFa: "شروع رایگان",
    },
    {
      name: "Pro",
      nameFa: "حرفه‌ای",
      icon: Crown,
      c: "#DD2222",
      m: 9,
      y: 79,
      tag: "Meist gewählt",
      tagFa: "پرطرفدارترین",
      featured: true,
      features: [
        ["Unbegrenzte Karten", "کارت‌های نامحدود"],
        ["KI-Coach ohne Limit", "کوچ AI بدون سقف"],
        ["Alle Grammatik-Pfade", "همهٔ مسیرهای گرامر"],
        ["Podcasts & Lesen", "پادکست و خواندن"],
        ["Prüfungssimulationen", "شبیه‌ساز آزمون"],
      ],
      cta: "Pro werden",
      ctaFa: "پرو شو",
    },
    {
      name: "Team",
      nameFa: "تیم",
      icon: Flame,
      c: "#F7C948",
      m: 24,
      y: 219,
      tag: "Für Kurse & Familien",
      tagFa: "برای دوره و خانواده",
      features: [
        ["Bis zu 5 Konten", "تا ۵ حساب"],
        ["Gemeinsame Decks", "دِک مشترک"],
        ["Lehrer-Dashboard", "داشبورد معلم"],
        ["Alles aus Pro", "همهٔ امکانات پرو"],
      ],
      cta: "Team einrichten",
      ctaFa: "تیم بساز",
    },
  ];

  return (
    <section
      id="preise"
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="Preise"
        kickerFa="تعرفه"
        title={
          <>
            Fair. Ehrlich.
            <br />
            <span style={{ color: "var(--flag-red)" }}>Ohne Kleingedrucktes.</span>
          </>
        }
        titleFa={
          <>
            منصفانه، صادقانه، <span style={{ color: "var(--flag-red)" }}>بدون شرط‌های ریز.</span>
          </>
        }
        subtitle="Starte kostenlos, wachse mit Pro. Jederzeit kündbar — kein Vertrag, keine versteckten Gebühren."
        subtitleFa="رایگان شروع کن، با پرو رشد کن. هر وقت خواستی لغو کن — بدون قرارداد، بدون هزینهٔ پنهان."
      />

      {/* Toggle */}
      <div className="mt-10 flex justify-center">
        <div className="relative flex items-center gap-1 rounded-full border border-border bg-card p-1 text-sm font-bold shadow-lg">
          <motion.span
            layout
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="absolute inset-y-1 w-1/2 rounded-full"
            style={{
              left: yearly ? "50%" : "0.25rem",
              right: yearly ? "0.25rem" : "50%",
              background: "linear-gradient(135deg, #1a1a1a, #DD2222)",
            }}
          />
          <button
            onClick={() => setYearly(false)}
            className={`relative z-10 rounded-full px-5 py-2 transition ${!yearly ? "text-white" : "text-muted-foreground hover:text-foreground"}`}
          >
            Monatlich <FA className="text-[10px] opacity-80">· ماهانه</FA>
          </button>
          <button
            onClick={() => setYearly(true)}
            className={`relative z-10 rounded-full px-5 py-2 transition ${yearly ? "text-white" : "text-muted-foreground hover:text-foreground"}`}
          >
            Jährlich <FA className="text-[10px] opacity-80">· سالانه</FA>
            <span className="ml-1.5 rounded-full bg-[#F7C948] px-1.5 py-0.5 text-[9px] font-black text-[#1a1a1a]">
              -27%
            </span>
          </button>
        </div>
      </div>

      <div className="mt-12 grid gap-5 md:grid-cols-3 md:items-stretch">
        {tiers.map((t, i) => (
          <PricingCard key={t.name} tier={t} yearly={yearly} index={i} />
        ))}
      </div>

      <p className="mt-8 text-center text-xs text-muted-foreground">
        Alle Preise in EUR inkl. MwSt. · <FA>همه با احتساب مالیات</FA>
      </p>
    </section>
  );
}

type PricingTier = {
  name: string;
  nameFa: string;
  icon: LucideIcon;
  c: string;
  m: number;
  y: number;
  tag: string;
  tagFa: string;
  featured?: boolean;
  features: [string, string][];
  cta: string;
  ctaFa: string;
};

function PricingCard({
  tier,
  yearly,
  index,
}: {
  tier: PricingTier;
  yearly: boolean;
  index: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0 });
  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    setTilt({ rx: -py * 8, ry: px * 10 });
  };
  const Icon = tier.icon;
  const price = yearly ? tier.y : tier.m;

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setTilt({ rx: 0, ry: 0 })}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ delay: index * 0.1, duration: 0.7, ease: EASE }}
      style={{
        transform: `perspective(1200px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
        transition: "transform .35s cubic-bezier(.2,.8,.2,1)",
      }}
      className={`relative flex flex-col overflow-hidden rounded-[2rem] border p-7 sm:p-8 ${
        tier.featured
          ? "border-transparent text-white shadow-[0_50px_120px_-40px_rgba(221,34,34,0.7)]"
          : "border-border bg-card shadow-[0_20px_60px_-30px_rgba(20,22,26,0.35)]"
      }`}
    >
      {tier.featured && (
        <>
          <div
            className="absolute inset-0 -z-10"
            style={{ background: "linear-gradient(155deg, #0d0d0d 0%, #2a1010 45%, #DD2222 100%)" }}
          />
          <div
            aria-hidden
            className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-[#F7C948]/40 blur-3xl"
          />
        </>
      )}

      {tier.featured && (
        <div className="absolute right-5 top-5 rounded-full bg-[#F7C948] px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]">
          {tier.tag} · <FA>{tier.tagFa}</FA>
        </div>
      )}

      <div className="flex items-center gap-3">
        <div
          className={`grid h-11 w-11 place-items-center rounded-2xl text-white shadow-lg`}
          style={{
            background: tier.featured
              ? "rgba(255,255,255,.15)"
              : `linear-gradient(135deg, ${tier.c}, ${tier.c}bb)`,
          }}
        >
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="font-display text-xl font-black tracking-tight">{tier.name}</div>
          <FA
            className={`text-xs font-bold ${tier.featured ? "text-white/80" : "text-muted-foreground"}`}
          >
            {tier.nameFa}
          </FA>
        </div>
      </div>

      <div className="mt-6 flex items-baseline gap-1">
        <span className="font-display text-6xl font-black tracking-tight">
          {price === 0 ? "0" : price}
        </span>
        <span
          className={`font-display text-2xl font-black ${tier.featured ? "text-white/80" : "text-muted-foreground"}`}
        >
          €
        </span>
        <span
          className={`ml-1 text-xs font-bold ${tier.featured ? "text-white/70" : "text-muted-foreground"}`}
        >
          / {yearly ? "Jahr" : "Monat"} · <FA>{yearly ? "سال" : "ماه"}</FA>
        </span>
      </div>
      {yearly && tier.m > 0 && (
        <div
          className={`mt-1 text-xs ${tier.featured ? "text-white/60" : "text-muted-foreground/80"}`}
        >
          entspricht {(tier.y / 12).toFixed(2)}€/Monat · <FA>معادل ماهانه</FA>
        </div>
      )}

      <ul className="mt-6 space-y-2.5">
        {tier.features.map((f: [string, string], k: number) => (
          <motion.li
            key={f[0]}
            initial={{ opacity: 0, x: -10 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.05 * k + index * 0.1, duration: 0.4 }}
            className="flex items-start gap-2.5 text-sm"
          >
            <span
              className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] font-bold ${
                tier.featured ? "bg-white text-[#DD2222]" : "text-white"
              }`}
              style={tier.featured ? undefined : { background: tier.c }}
            >
              <Check className="h-3 w-3" strokeWidth={3} />
            </span>
            <span className="min-w-0">
              <span>{f[0]}</span>
              <FA className={`ml-2 ${tier.featured ? "text-white/70" : "text-muted-foreground"}`}>
                · {f[1]}
              </FA>
            </span>
          </motion.li>
        ))}
      </ul>

      <Link
        to="/register"
        className={`mt-8 inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition ${
          tier.featured
            ? "bg-white text-[#1a1a1a] hover:scale-[1.02] shadow-xl"
            : "border border-border bg-secondary text-foreground hover:bg-foreground hover:text-background"
        }`}
      >
        {tier.cta}{" "}
        <FA className={`text-[11px] ${tier.featured ? "text-[#1a1a1a]/70" : "opacity-70"}`}>
          · {tier.ctaFa}
        </FA>
        <ArrowRight className="h-4 w-4" />
      </Link>

      {tier.featured && (
        <div className="mt-4 flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest text-white/70">
          <InfinityIcon className="h-3 w-3" /> 14 Tage Geld-zurück · <FA>۱۴ روز ضمانت</FA>
        </div>
      )}
    </motion.div>
  );
}

/* ---------- DEEP DIVE (tabbed feature explorer) ---------- */
type DeepDiveTab = {
  id: string;
  label: string;
  labelFa: string;
  icon: LucideIcon;
  color: string;
  title: string;
  titleFa: string;
  desc: string;
  descFa: string;
  points: Array<[string, string]>;
  chips: string[];
  to: string;
  cta: string;
};

const DEEP_DIVE: DeepDiveTab[] = [
  {
    id: "wortschatz",
    label: "Wortschatz-System",
    labelFa: "سیستم واژگان",
    icon: Layers,
    color: "#DD2222",
    title: "Ein Wort, der ganze Weg — vom Entdecken bis zum Beherrschen",
    titleFa: "یک واژه، تمام مسیر — از کشف تا تسلط",
    desc: "Jedes Wort startet im Wörterbuch, wandert in deine Listen, wird zur Karte und landet im Leitner-Kasten. Nichts geht verloren, nichts wird doppelt gelernt.",
    descFa:
      "هر واژه از دیکشنری شروع می‌شود، به فهرست‌های تو می‌رود، کارت می‌شود و در جعبه‌ی لایتنر جا می‌گیرد. هیچ چیز گم نمی‌شود.",
    points: [
      [
        "Wörterbuch mit Artikel, Plural, Konjugation, Beispielsätzen und Aussprache",
        "دیکشنری با حرف تعریف، جمع، صرف، جمله‌ی نمونه و تلفظ",
      ],
      [
        "Eigene Wortlisten & Wortschatz-Bücher nach Thema und Niveau",
        "فهرست‌های شخصی و کتاب‌های واژگان بر اساس موضوع و سطح",
      ],
      [
        "Dynamische Karten: Nomen, Verben und Adjektive werden unterschiedlich abgefragt",
        "کارت‌های پویا: اسم، فعل و صفت هرکدام جور دیگری پرسیده می‌شوند",
      ],
      [
        "FSRS 5 + Leitner planen jede Wiederholung auf den optimalen Tag",
        "FSRS ۵ و لایتنر هر مرور را برای بهترین روز زمان‌بندی می‌کنند",
      ],
    ],
    chips: ["Wörterbuch", "Meine Wörter", "Flashcards", "Leitner", "Bücher"],
    to: "/dictionary",
    cta: "Wörterbuch ansehen",
  },
  {
    id: "grammatik",
    label: "Grammatik & Schreiben",
    labelFa: "گرامر و نوشتن",
    icon: BookOpen,
    color: "#2563eb",
    title: "Regeln verstehen, Sätze bauen, Texte schreiben",
    titleFa: "قاعده را بفهم، جمله بساز، متن بنویس",
    desc: "Geführte Grammatik-Pfade mit interaktiven Sätzen und Mini-Übungen — und ein Schreibtrainer, der deine Texte Satz für Satz korrigiert.",
    descFa:
      "مسیرهای گرامری گام‌به‌گام با جمله‌های تعاملی و تمرین کوتاه — به‌همراه تمرین نوشتن که متن‌ات را جمله‌به‌جمله اصلاح می‌کند.",
    points: [
      [
        "Roadmap von A1 bis C2: jedes Thema mit Lektion, Beispielen und Übung",
        "نقشه‌راه از A1 تا C2: هر موضوع با درس، مثال و تمرین",
      ],
      [
        "Interaktive Sätze — tippe auf ein Satzglied und sieh, warum es dort steht",
        "جمله‌های تعاملی — روی هر جزء بزن و ببین چرا آنجاست",
      ],
      [
        "Wortfamilien: Wortstamm, Präfixe, Suffixe und Wortbildung als Baum",
        "خانواده‌ی واژه: ریشه، پیشوند، پسوند و واژه‌سازی به‌شکل درختی",
      ],
      [
        "Schreibtrainer mit KI-Feedback zu Grammatik, Stil, Register und Struktur",
        "تمرین نوشتن با بازخورد هوش مصنوعی درباره‌ی گرامر، سبک و ساختار",
      ],
    ],
    chips: ["Grammatik", "Wortfamilien", "Schreiben", "KI-Coach"],
    to: "/grammatik",
    cta: "Grammatik entdecken",
  },
  {
    id: "immersion",
    label: "Hören & Immersion",
    labelFa: "شنیدن و غوطه‌وری",
    icon: Headphones,
    color: "#16A34A",
    title: "Echtes Deutsch: Podcasts, Musik, Filme und Texte",
    titleFa: "آلمانیِ واقعی: پادکست، موزیک، فیلم و متن",
    desc: "Hören, mitlesen, verstehen. Jedes Transkript ist anklickbar — unbekannte Wörter wandern mit einem Tap in deine Lernkarten.",
    descFa:
      "گوش کن، هم‌زمان بخوان، بفهم. هر متن قابل لمس است — واژه‌های ناآشنا با یک لمس به کارت‌هایت اضافه می‌شوند.",
    points: [
      [
        "Podcasts mit interaktivem Transkript, Tempo-Regler und Quiz danach",
        "پادکست با متن تعاملی، تنظیم سرعت و آزمون پایانی",
      ],
      [
        "Musik im Karaoke-Modus: Zeile für Zeile mitlesen und Vokabeln sammeln",
        "موزیک در حالت کارائوکه: خط‌به‌خط بخوان و واژه جمع کن",
      ],
      [
        "Kino & Serien: Szenen, Dialoge und Redewendungen aus echten Filmen",
        "سینما و سریال: صحنه‌ها، دیالوگ‌ها و اصطلاح‌های فیلم‌های واقعی",
      ],
      [
        "Lesen mit Wort-Popup, Lesefortschritt und Flashcards aus dem Text",
        "خواندن با پاپ‌آپ واژه، پیشرفت مطالعه و ساخت کارت از دل متن",
      ],
    ],
    chips: ["Podcasts", "Musik", "Kino", "Lesen", "Lesezeichen"],
    to: "/podcasts",
    cta: "Podcasts hören",
  },
  {
    id: "pruefung",
    label: "Prüfungen & KI-Coach",
    labelFa: "آزمون و کوچ هوشمند",
    icon: GraduationCap,
    color: "#8B5CF6",
    title: "Bereit für Goethe, telc und ÖSD — mit Coach an deiner Seite",
    titleFa: "آماده‌ی گوته، telc و ÖSD — با یک مربی کنارت",
    desc: "Prüfungsformate üben, Zeit im Blick behalten und sofort auswerten. Der KI-Coach erklärt jede Korrektur auf deinem Niveau.",
    descFa:
      "قالب‌های آزمون را تمرین کن، زمان را زیر نظر داشته باش و بلافاصله نتیجه بگیر. کوچ هوشمند هر اصلاح را در سطح خودت توضیح می‌دهد.",
    points: [
      [
        "Aufgabentypen für Lesen, Hören, Schreiben und Sprechen pro Niveau",
        "انواع سؤال خواندن، شنیدن، نوشتن و صحبت‌کردن برای هر سطح",
      ],
      [
        "Vergleichstabelle der Prüfungen plus Vorbereitungs-Zeitplan",
        "جدول مقایسه‌ی آزمون‌ها به‌همراه برنامه‌ی زمانی آمادگی",
      ],
      [
        "Einstufungstest bestimmt dein Startniveau in wenigen Minuten",
        "آزمون تعیین سطح، نقطه‌ی شروعت را در چند دقیقه مشخص می‌کند",
      ],
      [
        "KI-Coach für Erklärungen, Konversation, Korrekturen und Beispielsätze",
        "کوچ هوشمند برای توضیح، مکالمه، اصلاح و جمله‌ی نمونه",
      ],
    ],
    chips: ["Prüfungen", "Einstufungstest", "KI-Coach"],
    to: "/pruefungen",
    cta: "Prüfungen ansehen",
  },
  {
    id: "community",
    label: "Community & Events",
    labelFa: "جامعه و رویدادها",
    icon: Users,
    color: "#0EA5E9",
    title: "Sprache lebt von Menschen — nicht nur von Karten",
    titleFa: "زبان با آدم‌ها زنده است — نه فقط با کارت",
    desc: "Chats, Lerngruppen, Tandem-Partner und echte Sprachtreffs. Übe das, was du gelernt hast, sofort im Gespräch.",
    descFa:
      "گفت‌وگو، گروه‌های یادگیری، شریک زبانی و دیدارهای واقعی. آنچه یاد گرفته‌ای را همان‌جا در گفت‌وگو تمرین کن.",
    points: [
      [
        "Öffentliche Talare, eigene Gruppen und private Chats",
        "تالارهای عمومی، گروه‌های شخصی و گفت‌وگوی خصوصی",
      ],
      [
        "Tandem-Börse: finde Sprechpartner nach Niveau und Interessen",
        "تابلوی تندم: شریک گفت‌وگو بر اساس سطح و علاقه پیدا کن",
      ],
      [
        "Events online und vor Ort — mit Tischplan und Platzreservierung",
        "رویدادهای آنلاین و حضوری — با نقشه‌ی میز و رزرو جا",
      ],
      [
        "Profile mit Niveau, Zielen und Lernstatistik der Mitglieder",
        "پروفایل اعضا با سطح، اهداف و آمار یادگیری",
      ],
    ],
    chips: ["Community", "Tandem", "Events", "Profil"],
    to: "/community",
    cta: "Community entdecken",
  },
  {
    id: "fortschritt",
    label: "Fortschritt & Motivation",
    labelFa: "پیشرفت و انگیزه",
    icon: BarChart3,
    color: "#F59E0B",
    title: "Sieh schwarz auf weiß, dass du besser wirst",
    titleFa: "سیاه روی سفید ببین که بهتر می‌شوی",
    desc: "Heatmaps, Serien, Retention und Skill-Verteilung — plus Missionen und Medaillen, die aus Lernen ein tägliches Ritual machen.",
    descFa:
      "هیت‌مپ، سری‌ها، ماندگاری و توزیع مهارت — به‌همراه ماموریت و مدال که یادگیری را به آیین روزانه تبدیل می‌کند.",
    points: [
      [
        "Tagesziel, Lernzeit-Charts und Wochentag-Profil deiner Gewohnheiten",
        "هدف روزانه، نمودار زمان مطالعه و پروفایل روزهای هفته",
      ],
      [
        "Vokabel-Heatmap und Retention pro Wortart und Niveau",
        "هیت‌مپ واژگان و ماندگاری بر اساس نوع کلمه و سطح",
      ],
      [
        "Missionen, Seasons, Medaillen und Leaderboard mit Freunden",
        "ماموریت، فصل‌ها، مدال و جدول رتبه‌بندی با دوستان",
      ],
      [
        "Serien-Schutz und Erinnerungen, damit die Streak nicht reißt",
        "محافظ سری و یادآوری، تا زنجیره‌ات پاره نشود",
      ],
    ],
    chips: ["Statistiken", "Erfolge", "Dashboard", "Benachrichtigungen"],
    to: "/statistiken",
    cta: "Statistiken ansehen",
  },
];

function DeepDive() {
  const [active, setActive] = useState(0);
  const tab = DEEP_DIVE[active]!;
  const Icon = tab.icon;

  return (
    <section
      id="deep-dive"
      className="relative mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-28 lg:px-12"
    >
      <SectionHeader
        kicker="Im Detail"
        kickerFa="با جزئیات"
        title={
          <>
            Was dich in DEUSI erwartet.
            <br />
            <span style={{ color: "var(--flag-red)" }}>Bereich für Bereich.</span>
          </>
        }
        titleFa={
          <>
            چه چیزی در دئوسی در انتظارت است —{" "}
            <span style={{ color: "var(--flag-red)" }}>بخش به بخش.</span>
          </>
        }
        subtitle="Sechs zusammenhängende Systeme statt zwölf einzelner Apps — hier siehst du genau, was jedes davon für dich tut."
        subtitleFa="شش سیستم به‌هم‌پیوسته به‌جای دوازده اپ جدا — اینجا دقیقاً می‌بینی هرکدام چه کاری برایت می‌کنند."
      />

      <div className="mt-12 grid gap-5 lg:grid-cols-[300px_minmax(0,1fr)] lg:gap-8">
        {/* Tabs — horizontal scroller on mobile, vertical list on desktop */}
        <div
          role="tablist"
          aria-label="Funktionsbereiche"
          className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:flex lg:flex-col"
        >
          {DEEP_DIVE.map((t, i) => {
            const TIcon = t.icon;
            const on = i === active;
            return (
              <button
                key={t.id}
                role="tab"
                aria-selected={on}
                onClick={() => setActive(i)}
                className={`flex w-full min-w-0 items-center gap-2.5 rounded-2xl border px-3 py-3 text-left transition sm:gap-3 sm:px-4 ${
                  on
                    ? "border-transparent bg-card shadow-lg"
                    : "border-border bg-card/50 hover:bg-card"
                }`}
                style={on ? { boxShadow: `0 12px 30px -18px ${t.color}` } : undefined}
              >
                <span
                  aria-hidden
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                  style={{
                    background: on
                      ? `linear-gradient(135deg, ${t.color}, ${t.color}bb)`
                      : "var(--muted, #f1f1f1)",
                    color: on ? "#fff" : t.color,
                  }}
                >
                  <TIcon className="h-4.5 w-4.5" size={18} />
                </span>
                <span className="min-w-0">
                  <span className="block text-[12.5px] leading-tight font-bold break-words hyphens-auto sm:text-sm">
                    {t.label}
                  </span>
                  <FA className="mt-0.5 block text-[10px] leading-tight text-muted-foreground sm:text-[11px]">
                    {t.labelFa}
                  </FA>
                </span>
              </button>
            );
          })}
        </div>

        {/* Panel */}
        <motion.div
          key={tab.id}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: EASE }}
          role="tabpanel"
          className="relative overflow-hidden rounded-3xl border border-border bg-card p-5 sm:p-8"
        >
          <div
            aria-hidden
            className="pointer-events-none absolute -right-16 -top-16 h-52 w-52 rounded-full opacity-25 blur-3xl"
            style={{ background: tab.color }}
          />
          <div className="relative">
            <div className="flex items-center gap-3">
              <span
                aria-hidden
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ background: `linear-gradient(135deg, ${tab.color}, ${tab.color}bb)` }}
              >
                <Icon className="h-5 w-5" />
              </span>
              <span
                className="rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-widest"
                style={{ background: `${tab.color}18`, color: tab.color }}
              >
                {tab.label}
              </span>
            </div>

            <h3 className="mt-5 text-balance text-xl font-black leading-tight sm:text-2xl md:text-3xl">
              {tab.title}
            </h3>
            <FA className="mt-1 block text-sm text-muted-foreground">{tab.titleFa}</FA>
            <p className="mt-3 max-w-2xl text-sm text-muted-foreground sm:text-base">{tab.desc}</p>
            <FA className="mt-1 block text-xs text-muted-foreground/80 sm:text-sm">{tab.descFa}</FA>

            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {tab.points.map(([de, fa], i) => (
                <motion.li
                  key={de}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 * i, duration: 0.4, ease: EASE }}
                  className="flex gap-3 rounded-2xl bg-secondary/50 p-3.5"
                >
                  <span
                    aria-hidden
                    className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-white"
                    style={{ background: tab.color }}
                  >
                    <Check className="h-3 w-3" strokeWidth={3} />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold leading-snug">{de}</span>
                    <FA className="mt-0.5 block text-[11px] text-muted-foreground">{fa}</FA>
                  </span>
                </motion.li>
              ))}
            </ul>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              {tab.chips.map((c) => (
                <span
                  key={c}
                  className="rounded-full border border-border px-3 py-1 text-[11px] font-semibold text-muted-foreground"
                >
                  {c}
                </span>
              ))}
              <Link
                to={tab.to}
                className="ml-auto inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold text-white transition hover:opacity-90"
                style={{ background: tab.color }}
              >
                {tab.cta} <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
