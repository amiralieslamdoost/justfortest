import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { MOCK_EVENTS } from "@/lib/deusi/events/mockEvents";
import { dailySessions, vocabularyHeatmap, learnerProfile } from "@/lib/deusi/mockStats";
import { Fa } from "@/components/deusi/Fa";
import { SectionHero } from "@/components/deusi/SectionHero";
import { SECTION_THEME, type SectionKey } from "@/lib/deusi/sectionTheme";
import { AchievementMedalCard } from "@/components/deusi/achievements/AchievementMedalCard";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — DEUSI" },
      {
        name: "description",
        content:
          "Dein DEUSI Lern-Dashboard mit Tagesziel, Streak, XP und persönlichem Fortschritt.",
      },
      { property: "og:title", content: "Dashboard — DEUSI" },
      {
        property: "og:description",
        content: "Behalte Tagesziel, Streak, XP und Lernfortschritt in DEUSI im Blick.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

/* ---------- Utilities ---------- */

function AnimatedNumber({ value, duration = 1.1 }: { value: number; duration?: number }) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (latest: number) => Math.round(latest).toLocaleString("de-DE"));
  useEffect(() => {
    const controls = animate(mv, value, { duration, ease: [0.2, 0.8, 0.2, 1] });
    return controls.stop;
  }, [value, duration, mv]);
  return <motion.span>{rounded}</motion.span>;
}

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return { de: "Gute Nacht", fa: "شب بخیر" };
  if (h < 12) return { de: "Guten Morgen", fa: "صبح بخیر" };
  if (h < 18) return { de: "Guten Tag", fa: "روز بخیر" };
  return { de: "Guten Abend", fa: "عصر بخیر" };
}

/* ============================================================
 * Dashboard
 * ========================================================== */

function Dashboard() {
  const { currentUser, hydrated, dueCards, ensureDeckFor } = useDeusi();
  const router = useRouter();

  useEffect(() => {
    if (!hydrated) return;
    if (!currentUser) router.navigate({ to: "/login" });
    else ensureDeckFor(currentUser.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, currentUser?.id]);

  const hello = useMemo(greeting, []);
  const today = useMemo(
    () =>
      new Date().toLocaleDateString("de-DE", {
        weekday: "long",
        day: "numeric",
        month: "long",
      }),
    [],
  );
  const nextEvent = MOCK_EVENTS[0];

  if (!currentUser) return null;

  const learned = currentUser.deck.filter((c) => c.box >= 3).length;
  const due = dueCards().length;
  const streak = Math.max(currentUser.streak, 14);
  const goal = 20;
  const doneToday = Math.min(goal, 8);
  const goalPct = Math.round((doneToday / goal) * 100);
  const xp = 125;
  const xpGoal = 500;
  const wordsLearned = Math.max(learned + 200, 356);
  const wordsGoal = 1500;
  const levelPct = 55;

  const firstName = currentUser.username.split(" ")[0];

  return (
    <div className="animate-fade space-y-6 pb-10">
      {/* ============================ HERO ============================ */}
      <SectionHero
        sectionKey="dashboard"
        titleDe={`${hello.de}, ${firstName}`}
        titleFa={`${hello.fa} · ${today}`}
        highlight={firstName}
        descDe="Dein Lernüberblick — alle wichtigen Module und Fortschritte an einem Ort."
        descFa="نمای کلی یادگیری‌ات — همه‌ی ماژول‌ها و پیشرفت‌ها در یک صفحه."
        right={
          <div className="hidden items-center gap-2 md:flex">
            <HeroChip label="Streak" value={`${streak} Tage`} />
            <HeroChip label="XP heute" value={`+${xp}`} />
            <HeroChip label="Level" value="A2 → B1" />
          </div>
        }
      />

      {/* ============ ROW 1 — CONTINUE LEARNING + DAILY GOAL ============ */}
      <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
        {/* Continue Learning — Hero card */}
        <ContinueLearningCard due={due} className="col-span-12 lg:col-span-8" />

        {/* Right column: Daily Goal ring + Streak + XP mini tiles */}
        <div className="col-span-12 grid grid-cols-2 gap-4 md:gap-5 lg:col-span-4">
          <DailyGoalRingCard done={doneToday} goal={goal} pct={goalPct} className="col-span-2" />
          <MiniStatTile
            emoji="⚡"
            value={`+${xp}`}
            label="XP heute"
            labelFa="امتیاز امروز"
            gradient="var(--stat-xp-gradient)"
            glow="var(--stat-xp-glow)"
            dot="var(--stat-xp-dot)"
          />
          <MiniStatTile
            emoji="🔥"
            value={streak}
            label="Streak"
            labelFa="روز پیاپی"
            gradient="var(--stat-streak-gradient)"
            glow="var(--stat-streak-glow)"
            dot="var(--stat-streak-dot)"
          />
        </div>
      </div>

      {/* ============ ROW 2 — LERNAKTIVITÄT + ACHIEVEMENT ============ */}
      <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
        <LearningActivityCard className="col-span-12 lg:col-span-9" />
        <FeatureAchievementCard className="col-span-12 lg:col-span-3" />
      </div>

      {/* ============ THEMENBEREICHE (Section shortcuts bento) ============ */}
      <section className="dash-rise">
        <BlockHeader
          title="Themenbereiche"
          fa="بخش‌های آموزشی"
          subtitle="Alle Lernmodule auf einen Blick"
        />
        <SectionBento />
      </section>

      {/* ============ HEUTE ZU TUN — Due / AI Coach / Next Event ============ */}
      <section className="dash-rise">
        <BlockHeader
          title="Heute dran"
          fa="کارهای امروز"
          subtitle="Wiederholungen, Empfehlungen und dein nächstes Event"
        />
        <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
          <ActionCallCard
            className="col-span-12 md:col-span-6 lg:col-span-4"
            sectionKey="leitner"
            eyebrow="Fällig heute"
            eyebrowFa="امروز باید مرور شود"
            title={`${Math.max(due, 12)} Karten warten`}
            subtitle="Kurze Runde reicht — halte deine Serie."
            subtitleFa="یک نوبت کوتاه کافی است."
            cta={{ to: "/leitner", label: "Jetzt üben" }}
            emoji="📚"
            chips={["Box 2 · 7", "Box 3 · 5", "≈ 6 Min."]}
            progress={{ label: "Heute wiederholt", pct: 35 }}
          />
          <ActionCallCard
            className="col-span-12 md:col-span-6 lg:col-span-4"
            sectionKey="ai-coach"
            eyebrow="KI Coach · Empfehlung"
            eyebrowFa="پیشنهاد مربی"
            title="Präpositionen üben"
            subtitle="Dein schwächster Bereich diese Woche."
            subtitleFa="ضعیف‌ترین حوزه‌ی این هفته."
            cta={{ to: "/grammatik", label: "Los geht’s" }}
            emoji="🎯"
            chips={["Dativ", "Akkusativ", "≈ 10 Min."]}
            progress={{ label: "Beherrschung", pct: 58 }}
          />

          <NextEventCard event={nextEvent} className="col-span-12 lg:col-span-4" />
        </div>
      </section>
      {/* ============ ROW 5 — ACTIVITY FEED + ACHIEVEMENTS ============ */}
      <section>
        <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
          <SpotlightCard className="col-span-12 h-full lg:col-span-7" />
          <AchievementsCard className="col-span-12 lg:col-span-5" />
        </div>
      </section>

      {/* ============ LEVEL PROGRESS + TIPP DES TAGES ============ */}
      <section>
        <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
          <LevelProgressCard
            className="col-span-12 lg:col-span-7"
            levelPct={levelPct}
            wordsLearned={wordsLearned}
            wordsGoal={wordsGoal}
            xp={xp}
            xpGoal={xpGoal}
          />
          <DailyTipCard className="col-span-12 lg:col-span-5" />
        </div>
      </section>
    </div>
  );
}

/* ============================================================
 * Sub-components
 * ========================================================== */

function HeroChip({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-2xl bg-white/15 px-3 py-2 text-white ring-1 ring-white/20 backdrop-blur">
      <div className="text-[10px] font-bold uppercase tracking-[0.14em] opacity-80">{label}</div>
      <div className="text-sm font-black tabular-nums leading-tight">{value}</div>
    </div>
  );
}

function BlockHeader({
  title,
  fa,
  subtitle,
  action,
}: {
  title: string;
  fa: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4 px-1">
      <div className="min-w-0">
        <h2 className="text-xl font-black leading-tight sm:text-2xl">{title}</h2>
        <Fa className="fa-hint-xs mt-0.5">{fa}</Fa>
        {subtitle && <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

/* ---------- Continue Learning (hero) ---------- */

function ContinueLearningCard({ due, className = "" }: { due: number; className?: string }) {
  const progress = 65;
  const size = 96;
  const stroke = 9;
  const svg = size + 24; // padding so the ring glow never gets clipped
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = (progress / 100) * c;

  return (
    <div
      className={`group relative overflow-hidden rounded-3xl p-6 text-white shadow-[0_24px_60px_-24px_rgba(221,34,34,0.55)] sm:p-8 ${className}`}
      style={{
        background: "linear-gradient(135deg, #b91c1c 0%, #dd2222 42%, #f59e0b 100%)",
      }}
    >
      {/* Ambient blobs */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-28 h-80 w-80 rounded-full bg-white/25 blur-3xl transition-transform duration-700 group-hover:scale-110"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-24 -left-20 h-72 w-72 rounded-full bg-black/20 blur-3xl"
      />
      {/* Subtle grid overlay */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="relative z-10 flex h-full flex-col">
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-white ring-1 ring-white/30 backdrop-blur">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
            Aktuelle Lektion
          </span>
          <span className="rounded-full bg-black/25 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white/90 backdrop-blur">
            Grammatik · A2
          </span>
        </div>

        <h3 className="mt-4 text-3xl font-black leading-tight tracking-tight sm:text-4xl">
          Lernen fortsetzen
        </h3>
        <Fa className="fa-hint-xs mt-1 !text-base !text-white/90 !opacity-100">ادامه یادگیری</Fa>

        <div className="mt-6 flex items-center gap-4">
          <div className="relative h-[120px] w-[120px] shrink-0 -m-3">
            <svg width={svg} height={svg} className="-rotate-90 overflow-visible">
              <circle
                cx={svg / 2}
                cy={svg / 2}
                r={r}
                stroke="rgba(255,255,255,0.22)"
                strokeWidth={stroke}
                fill="none"
              />
              <circle
                cx={svg / 2}
                cy={svg / 2}
                r={r}
                stroke="white"
                strokeWidth={stroke}
                strokeLinecap="round"
                fill="none"
                strokeDasharray={c}
                strokeDashoffset={c - dash}
                style={{ filter: "drop-shadow(0 0 6px rgba(255,255,255,0.6))" }}
              />
            </svg>
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-center leading-none">
                <div className="text-lg font-black">A2</div>
                <div className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-white/80">
                  {progress}%
                </div>
              </div>
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <div className="truncate text-lg font-black leading-tight">
              Präpositionen mit Dativ & Akkusativ
            </div>
            <Fa className="fa-hint-xs !text-white/90 !opacity-100">
              حروف اضافه با داتیو و آکوزاتیو
            </Fa>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-bold text-white/95 ring-1 ring-white/20 backdrop-blur">
                Lektion 4 / 8
              </span>
              <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-bold text-white/95 ring-1 ring-white/20 backdrop-blur">
                📇 {Math.max(due, 12)} fällig
              </span>
            </div>
          </div>
        </div>

        {/* Fill the gap: quick lesson stats */}
        <div className="mt-6 grid grid-cols-3 gap-2 sm:gap-3">
          {[
            { k: "Minuten", v: "18", fa: "دقیقه" },
            { k: "Übungen", v: "12", fa: "تمرین" },
            { k: "Genauigkeit", v: "86%", fa: "دقت" },
          ].map((s) => (
            <div
              key={s.k}
              className="rounded-2xl bg-white/12 px-3 py-2.5 text-center ring-1 ring-white/20 backdrop-blur transition hover:bg-white/20"
            >
              <div className="text-lg font-black leading-none tabular-nums">{s.v}</div>
              <div className="mt-1 text-[10px] font-bold uppercase tracking-wider text-white/80">
                {s.k}
              </div>
              <Fa className="fa-hint-xs !text-[10px] !text-white/70 !opacity-100">{s.fa}</Fa>
            </div>
          ))}
        </div>

        <div className="mt-auto pt-5">
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link
              to="/grammatik"
              className="group/btn inline-flex flex-1 items-center justify-center gap-2 rounded-2xl bg-white px-6 py-3.5 text-base font-black text-[color:var(--flag-red)] shadow-[0_12px_28px_-10px_rgba(0,0,0,0.35)] transition hover:-translate-y-0.5 hover:shadow-[0_18px_38px_-10px_rgba(0,0,0,0.45)]"
            >
              Weiterlernen
              <span className="transition-transform group-hover/btn:translate-x-1">
                <ArrowRightIcon />
              </span>
            </Link>
            <Link
              to="/learn"
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white/15 px-5 py-3.5 text-sm font-bold text-white ring-1 ring-white/30 backdrop-blur transition hover:-translate-y-0.5 hover:bg-white/25"
            >
              📇 Karten üben
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Daily Goal Ring ---------- */

function DailyGoalRingCard({
  done,
  goal,
  pct,
  className = "",
}: {
  done: number;
  goal: number;
  pct: number;
  className?: string;
}) {
  const ringSize = 148;
  const ringPadding = 18;
  const size = ringSize + ringPadding * 2;
  const stroke = 13;
  const center = size / 2;
  const r = (ringSize - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;

  return (
    <div className={`group relative ${className}`}>
      <div
        className="relative flex h-full flex-col items-center justify-center overflow-hidden rounded-3xl px-4 py-6 text-center text-white ring-1 ring-white/10 sm:px-5"
        style={{ background: "var(--daily-goal-bg)" }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute right-0 top-0 h-40 w-40 -translate-y-1/4 translate-x-1/4 rounded-full bg-[color:var(--flag-gold)]/25 blur-3xl transition-transform duration-700 group-hover:scale-110"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute bottom-0 left-0 h-40 w-40 translate-y-1/4 -translate-x-1/4 rounded-full bg-[color:var(--flag-red)]/35 blur-3xl"
        />

        <div className="relative z-10 flex flex-col items-center">
          <span className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] ring-1 ring-white/25 backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--flag-gold)]" />
            Tagesziel
          </span>

          <div className="relative" style={{ width: size, height: size }}>
            <svg
              width={size}
              height={size}
              viewBox={`0 0 ${size} ${size}`}
              className="-rotate-90 overflow-visible"
            >
              <defs>
                <linearGradient id="dailyGoalGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="var(--daily-goal-ring-start)" />
                  <stop offset="100%" stopColor="var(--daily-goal-ring-end)" />
                </linearGradient>
              </defs>
              <circle
                cx={center}
                cy={center}
                r={r}
                fill="none"
                stroke="rgba(255,255,255,0.15)"
                strokeWidth={stroke}
              />
              <motion.circle
                cx={center}
                cy={center}
                r={r}
                fill="none"
                stroke="url(#dailyGoalGrad)"
                strokeWidth={stroke}
                strokeLinecap="round"
                strokeDasharray={c}
                initial={{ strokeDashoffset: c }}
                animate={{ strokeDashoffset: offset }}
                transition={{ duration: 1.2, ease: [0.2, 0.8, 0.2, 1] }}
                style={{ filter: "drop-shadow(0 0 8px var(--daily-goal-ring-glow))" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-3xl font-black tabular-nums leading-none">
                <AnimatedNumber value={pct} />
                <span className="text-lg opacity-80">%</span>
              </div>
              <div className="mt-1 text-[10px] font-bold tracking-wider text-white/75">
                {done}/{goal} XP
              </div>
            </div>
          </div>

          <Fa className="fa-hint-xs mt-1 !text-base !font-black !text-white/90 !opacity-100">
            هدف روزانه
          </Fa>
        </div>
      </div>
    </div>
  );
}

/* ---------- Mini stat tile ---------- */

function MiniStatTile({
  emoji,
  value,
  label,
  labelFa,
  gradient,
  glow,
  dot,
}: {
  emoji: string;
  value: ReactNode;
  label: string;
  labelFa: string;
  gradient: string;
  glow: string;
  dot: string;
}) {
  return (
    <div className="group relative">
      <div
        className="relative flex h-full min-h-36 flex-col items-center justify-center overflow-hidden rounded-3xl p-4 text-center text-white ring-1 ring-white/10 transition-transform duration-300 group-hover:-translate-y-0.5"
        style={{ background: gradient }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute right-0 top-0 h-28 w-28 -translate-y-1/3 translate-x-1/3 rounded-full blur-3xl transition-transform duration-700 group-hover:scale-110"
          style={{ background: glow }}
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-10 left-1/2 h-24 w-24 -translate-x-1/2 rounded-full bg-white/20 blur-2xl"
        />

        <span className="relative mb-2 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.18em] ring-1 ring-white/25 backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: dot }} />
          {label}
        </span>

        <div className="relative grid h-10 w-10 place-items-center rounded-2xl bg-white/10 text-xl ring-1 ring-white/20 backdrop-blur">
          {emoji}
        </div>

        <div className="relative mt-2 text-2xl font-black leading-none tabular-nums">{value}</div>
        <Fa className="fa-hint-xs mt-1 !text-[10px] !text-white/80 !opacity-100">{labelFa}</Fa>
      </div>
    </div>
  );
}

/* ---------- Learning activity (last 14 days heatmap-strip) ---------- */

const ACTIVITY_GOAL_MIN = learnerProfile.dailyGoalMinutes;

/** Green when the daily learning goal is reached, red when it is missed. */
function activityTone(minutes: number) {
  const ratio = minutes / ACTIVITY_GOAL_MIN;
  if (minutes <= 0) return { kind: "empty" as const, ratio: 0 };
  if (ratio >= 1) return { kind: "goal" as const, ratio: Math.min(ratio, 1.6) };
  return { kind: "miss" as const, ratio };
}

function LearningActivityCard({ className = "" }: { className?: string }) {
  const last14 = dailySessions.slice(-14);
  const maxMin = Math.max(...last14.map((d) => d.minutes), 1);
  const totalMin = last14.reduce((s, d) => s + d.minutes, 0);
  const hours = Math.floor(totalMin / 60);
  const mins = totalMin % 60;
  const goalDays = last14.filter((d) => d.minutes >= ACTIVITY_GOAL_MIN).length;

  return (
    <div className={`neu-card p-6 sm:p-7 ${className}`}>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <h3 className="text-lg font-black">Lernaktivität · 14 Tage</h3>
          <Fa className="fa-hint-xs">فعالیت یادگیری در ۱۴ روز اخیر</Fa>
          <div className="mt-1 text-xs text-muted-foreground">
            Insgesamt{" "}
            <span className="font-bold text-foreground">
              {hours}h {mins}m
            </span>{" "}
            ·{" "}
            <span className="tabular-nums">
              {goalDays}/14 Tage Ziel erreicht ({ACTIVITY_GOAL_MIN} Min)
            </span>
          </div>
        </div>
        <Link
          to="/statistiken"
          className="inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold text-foreground transition hover:-translate-y-0.5"
        >
          Alle Statistiken <ArrowRightIcon />
        </Link>
      </div>

      <div className="grid grid-cols-7 gap-2 sm:gap-3 md:grid-cols-14">
        {last14.map((d, i) => {
          const tone = activityTone(d.minutes);
          const date = new Date(d.date);
          const weekday = date.toLocaleDateString("de-DE", { weekday: "short" });
          const day = date.getDate();
          const fillPct =
            tone.kind === "empty" ? 0 : Math.max(22, Math.round((d.minutes / maxMin) * 100));
          const gradient =
            tone.kind === "goal"
              ? "linear-gradient(180deg, var(--act-goal-top), var(--act-goal-bottom))"
              : "linear-gradient(180deg, var(--act-miss-top), var(--act-miss-bottom))";
          return (
            <div key={d.date} className="flex flex-col items-center gap-1.5">
              <div
                className="dash-grow relative flex w-full items-end overflow-hidden rounded-xl bg-secondary/70"
                style={{ height: "72px", animationDelay: `${i * 40}ms` }}
                title={`${weekday} ${day} · ${d.minutes} Min · ${
                  tone.kind === "goal" ? "Ziel erreicht" : "Ziel verfehlt"
                }`}
              >
                {tone.kind !== "empty" && (
                  <div
                    className="relative w-full rounded-xl transition-all"
                    style={{
                      height: `${fillPct}%`,
                      background: gradient,
                      boxShadow:
                        tone.kind === "goal"
                          ? "0 -4px 16px -6px var(--act-goal-glow)"
                          : "0 -4px 16px -6px var(--act-miss-glow)",
                    }}
                  >
                    {fillPct > 34 && (
                      <span className="absolute inset-x-0 bottom-1 text-center text-[9px] font-bold tabular-nums text-white/95">
                        {d.minutes}
                      </span>
                    )}
                  </div>
                )}
              </div>
              <div className="text-[9px] font-semibold text-muted-foreground tabular-nums">
                {day}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-end gap-3 text-[10px] font-bold text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span
            className="h-3 w-3 rounded-sm"
            style={{
              background: "linear-gradient(180deg, var(--act-goal-top), var(--act-goal-bottom))",
            }}
          />
          ZIEL ERREICHT
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span
            className="h-3 w-3 rounded-sm"
            style={{
              background: "linear-gradient(180deg, var(--act-miss-top), var(--act-miss-bottom))",
            }}
          />
          ZIEL VERFEHLT
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-sm bg-secondary" />
          PAUSE
        </span>
      </div>
    </div>
  );
}

/* ---------- Feature achievement (gold gradient card) ---------- */

function FeatureAchievementCard({ className = "" }: { className?: string }) {
  return (
    <div
      className={`relative flex flex-col items-center justify-center overflow-hidden rounded-[1.75rem] p-6 text-center text-white shadow-xl ${className}`}
      style={{
        background: "linear-gradient(135deg, #F7C948 0%, #DD8912 60%, #92400E 130%)",
      }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/20 blur-2xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-white/10 blur-2xl"
      />
      <div className="relative">
        <div className="grid h-16 w-16 place-items-center rounded-full border border-white/40 bg-white/20 backdrop-blur">
          <span className="text-3xl">🏆</span>
        </div>
      </div>
      <div className="relative mt-4 text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">
        Nächstes Ziel
      </div>
      <h3 className="relative mt-1 text-xl font-black uppercase tracking-tight leading-tight">
        14-Tage-Serie
      </h3>
      <Fa className="fa-hint-xs relative !text-white/85">سری ۱۴ روزه</Fa>
      <div className="relative mt-4 w-full">
        <div className="h-2 w-full overflow-hidden rounded-full bg-white/25">
          <div className="dash-bar h-full rounded-full bg-white/90" style={{ width: "78%" }} />
        </div>
        <div className="mt-1.5 text-[10px] font-bold opacity-90">
          11 / 14 Tage · fast geschafft!
        </div>
      </div>
    </div>
  );
}

/* ---------- Section Bento (12 sections with per-section colors) ---------- */

type ShortcutMeta = {
  key: SectionKey;
  to:
    | "/dictionary"
    | "/learn"
    | "/grammatik"
    | "/leitner"
    | "/lesen"
    | "/podcasts"
    | "/musik"
    | "/kino"
    | "/statistiken"
    | "/pruefungen"
    | "/events"
    | "/schreiben"
    | "/verben"
    | "/ki-coach"
    | "/achievements";
  labelDe: string;
  labelFa: string;
  stat: string;
  span: string;
  h?: string;
};

const SHORTCUTS: ShortcutMeta[] = [
  {
    key: "dictionary",
    to: "/dictionary",
    labelDe: "Wörterbuch",
    labelFa: "دیکشنری",
    stat: "356 Wörter",
    span: "md:col-span-5",
  },
  {
    key: "grammar",
    to: "/grammatik",
    labelDe: "Grammatik",
    labelFa: "دستور زبان",
    stat: "8 Lektionen · 45%",
    span: "md:col-span-3",
  },
  {
    key: "verbs",
    to: "/verben",
    labelDe: "Wortfamilien",
    labelFa: "خانواده واژه‌ها",
    stat: "Wortstämme & Präfixe",

    span: "md:col-span-4",
  },

  {
    key: "leitner",
    to: "/leitner",
    labelDe: "Leitner Box",
    labelFa: "لایتنر",
    stat: "5 Boxen · fällig",
    span: "md:col-span-3",
  },
  {
    key: "reading",
    to: "/lesen",
    labelDe: "Lesen",
    labelFa: "خواندن",
    stat: "40 Artikel",
    span: "md:col-span-3",
  },
  {
    key: "podcasts",
    to: "/podcasts",
    labelDe: "Podcasts",
    labelFa: "پادکست",
    stat: "12 Episoden",
    span: "md:col-span-6",
  },

  {
    key: "music",
    to: "/musik",
    labelDe: "Musik",
    labelFa: "موزیک",
    stat: "13 Songs",
    span: "md:col-span-4",
  },
  {
    key: "movies",
    to: "/kino",
    labelDe: "Kino",
    labelFa: "فیلم",
    stat: "5 Filme",
    span: "md:col-span-4",
  },
  {
    key: "ai-coach",
    to: "/ki-coach",
    labelDe: "KI Coach",
    labelFa: "مربی هوش مصنوعی",
    stat: "24/7 · Chat",
    span: "md:col-span-4",
  },

  {
    key: "writing",
    to: "/schreiben",
    labelDe: "Schreiben",
    labelFa: "نوشتن",
    stat: "KI-Feedback",
    span: "md:col-span-4",
  },
  {
    key: "statistics",
    to: "/statistiken",
    labelDe: "Statistik",
    labelFa: "آمار",
    stat: "Dein Verlauf",
    span: "md:col-span-5",
  },
  {
    key: "exams",
    to: "/pruefungen",
    labelDe: "Prüfungen",
    labelFa: "آزمون‌ها",
    stat: "Goethe · telc",
    span: "md:col-span-3",
  },

  {
    key: "events",
    to: "/events",
    labelDe: "Events",
    labelFa: "رویدادها",
    stat: "5 offen",
    span: "md:col-span-6",
  },
  {
    key: "achievements",
    to: "/achievements",
    labelDe: "Erfolge",
    labelFa: "دستاوردها",
    stat: "18 Abzeichen",
    span: "md:col-span-6",
  },
];

function SectionBento() {
  return (
    <div className="dash-stagger grid grid-cols-2 gap-3 md:grid-cols-12 md:gap-4">
      {SHORTCUTS.map((s) => (
        <SectionTile
          key={s.key}
          meta={s}
          className={`aspect-square md:aspect-auto md:min-h-[168px] ${s.span} ${s.h ?? ""}`}
        />
      ))}
    </div>
  );
}

function SectionTile({ meta, className = "" }: { meta: ShortcutMeta; className?: string }) {
  const theme = SECTION_THEME[meta.key];
  const Icon = theme.Icon;

  return (
    <Link
      to={meta.to}
      className={`group relative col-span-1 flex flex-col justify-between overflow-hidden rounded-3xl p-4 text-white shadow-lg transition-all duration-300 ease-out will-change-transform hover:-translate-y-1 hover:shadow-2xl sm:p-5 ${className}`}
      style={{
        // Saturated take on each section's hero color: primary -> accent, no white wash.
        backgroundImage: `linear-gradient(135deg, ${theme.primary} 0%, color-mix(in oklab, ${theme.accent} 55%, ${theme.primary}) 58%, ${theme.accent} 100%)`,
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden rounded-3xl">
        <div className="absolute -right-10 -top-12 h-36 w-36 rounded-full bg-white/10 blur-2xl transition-all duration-700 group-hover:scale-125 group-hover:bg-white/20" />
        <div
          className="absolute -bottom-12 -left-8 h-32 w-32 rounded-full blur-2xl transition-transform duration-700 group-hover:scale-125"
          style={{ backgroundColor: theme.accent, opacity: 0.45 }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-white/0 transition-colors duration-300 group-hover:bg-white/[0.07]" />
      </div>

      <div className="relative flex items-start justify-between gap-2">
        <div
          aria-hidden
          className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white/95 shadow-md ring-1 ring-white/50 transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110 sm:h-12 sm:w-12"
          style={{ color: theme.primary }}
        >
          <Icon size={22} />
        </div>
        <ArrowRightIcon className="shrink-0 text-white/70 transition-all duration-300 group-hover:translate-x-1 group-hover:text-white" />
      </div>

      <div className="relative mt-4 min-w-0">
        <div className="flex items-end justify-between gap-2">
          <div className="truncate text-lg font-black leading-tight sm:text-xl">{meta.labelDe}</div>
        </div>
        <div className="mt-1 flex items-center justify-between gap-2">
          <span className="inline-flex max-w-full items-center truncate rounded-full bg-white/20 px-2.5 py-1 text-[11px] font-bold tabular-nums text-white/95 backdrop-blur transition-colors duration-300 group-hover:bg-white/30">
            {meta.stat}
          </span>
          <Fa className="!m-0 shrink-0 !text-[0.72rem] !font-medium !leading-[1.5] !text-white/85">
            {meta.labelFa}
          </Fa>
        </div>
      </div>
    </Link>
  );
}

/* ---------- Action call card (Due / AI suggestion) ---------- */

function ActionCallCard({
  className = "",
  sectionKey,
  eyebrow,
  eyebrowFa,
  title,
  subtitle,
  subtitleFa,
  cta,
  emoji,
  chips = [],
  progress,
}: {
  className?: string;
  sectionKey: SectionKey;
  eyebrow: string;
  eyebrowFa: string;
  title: string;
  subtitle: string;
  subtitleFa: string;
  cta: { to: string; label: string };
  emoji: string;
  chips?: string[];
  progress?: { label: string; pct: number };
}) {
  const theme = SECTION_THEME[sectionKey];
  return (
    <div className={`neu-card group relative flex flex-col overflow-hidden p-0 ${className}`}>
      {/* Colored top band */}
      <div
        className="relative flex items-center gap-3 px-5 py-4 text-white sm:px-6"
        style={{
          backgroundImage: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.accent} 100%)`,
        }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute -right-8 -top-10 h-28 w-28 rounded-full bg-white/25 blur-2xl transition-transform duration-700 group-hover:scale-110"
        />
        <div className="relative grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/20 text-2xl ring-1 ring-white/30 backdrop-blur">
          {emoji}
        </div>
        <div className="relative min-w-0">
          <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/90">
            {eyebrow}
          </div>
          <Fa className="fa-hint-xs !text-[10px] !text-white/80 !opacity-100">{eyebrowFa}</Fa>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <div className="text-lg font-black leading-tight">{title}</div>
        <div className="mt-1 text-xs text-muted-foreground">{subtitle}</div>
        <Fa className="fa-hint-xs">{subtitleFa}</Fa>

        {chips.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {chips.map((ch) => (
              <span
                key={ch}
                className="rounded-full px-2.5 py-1 text-[10px] font-bold tabular-nums"
                style={{
                  background: `color-mix(in oklab, ${theme.primary} 14%, transparent)`,
                  color: theme.primary,
                }}
              >
                {ch}
              </span>
            ))}
          </div>
        )}

        {progress && (
          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between text-[10px] font-bold text-muted-foreground">
              <span>{progress.label}</span>
              <span className="tabular-nums">{progress.pct}%</span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-[color:var(--muted)]">
              <div
                className="h-full rounded-full transition-[width] duration-700"
                style={{
                  width: `${progress.pct}%`,
                  backgroundImage: `linear-gradient(90deg, ${theme.primary}, ${theme.accent})`,
                }}
              />
            </div>
          </div>
        )}

        <Link
          to={cta.to as never}
          className="mt-auto inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 pt-3"
          style={{
            marginTop: "1.25rem",
            backgroundImage: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.accent} 100%)`,
          }}
        >
          {cta.label} <ArrowRightIcon />
        </Link>
      </div>
    </div>
  );
}

/* ---------- Next Event ---------- */

function NextEventCard({
  event,
  className = "",
}: {
  event: (typeof MOCK_EVENTS)[number];
  className?: string;
}) {
  const theme = SECTION_THEME.events;
  const dateParts = event.dateShort.split(".");
  const day = dateParts[0]?.trim() ?? "25";
  const month =
    event.dateShort
      .match(/\b([A-Za-zäöüÄÖÜ]+)\b/)?.[1]
      ?.slice(0, 3)
      .toUpperCase() ?? "MAI";

  return (
    <Link
      to="/events/$eventId"
      params={{ eventId: event.id }}
      className={`neu-card group relative flex flex-col overflow-hidden p-0 transition hover:-translate-y-1 ${className}`}
    >
      <div
        className="relative h-32 w-full overflow-hidden"
        style={{
          background: `linear-gradient(135deg, ${theme.base} 0%, ${theme.primary} 60%, ${theme.accent} 130%)`,
        }}
      >
        <div
          aria-hidden
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage: `url(${event.cover})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            mixBlendMode: "overlay",
          }}
        />
        <div className="absolute left-4 top-4 flex flex-col items-center rounded-2xl bg-white/95 px-3 py-2 text-center shadow-lg">
          <span className="text-lg font-black leading-none tabular-nums text-foreground">
            {day}
          </span>
          <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
            {month}
          </span>
        </div>
        <div className="absolute right-4 top-4 rounded-full bg-white/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-white backdrop-blur">
          Nächstes Event
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="text-sm font-black leading-tight">{event.title}</div>
        <Fa className="fa-hint-xs">رویداد بعدی</Fa>
        <div className="mt-2 space-y-1 text-[11px] text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <ClockIcon /> {event.time} · {event.duration}
          </div>
          <div className="flex items-center gap-1.5 truncate">
            <PinIcon /> {event.locationName}
          </div>
        </div>
        <div className="mt-auto pt-4">
          <span
            className="inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold text-white transition group-hover:translate-x-0.5"
            style={{ background: theme.primary }}
          >
            Details ansehen <ArrowRightIcon />
          </span>
        </div>
      </div>
    </Link>
  );
}

/* ---------- Spotlight: Werbe-Karte für eine andere Sektion ---------- */

type Spotlight = {
  key: SectionKey;
  to: "/ki-coach" | "/kino" | "/musik" | "/community";
  eyebrow: string;
  titleDe: string;
  titleFa: string;
  descDe: string;
  descFa: string;
  cta: string;
  emoji: string;
  bullets: Array<{ icon: string; de: string; fa: string }>;
  stat: { v: string; l: string };
  preview: { label: string; rows: Array<{ de: string; fa: string }> };
};

const SPOTLIGHTS: Spotlight[] = [
  {
    key: "ai-coach",
    to: "/ki-coach",
    eyebrow: "Neu in DEUSI",
    titleDe: "KI-Coach",
    titleFa: "مربی هوش مصنوعی",
    descDe:
      "Sprich frei, lass deine Sätze sofort korrigieren und erhalte Erklärungen auf Persisch.",
    descFa: "آزاد صحبت کن، جمله‌هایت را فوری اصلاح کن و توضیح فارسی بگیر.",
    cta: "Jetzt ausprobieren",
    emoji: "✨",
    bullets: [
      { icon: "💬", de: "Dialoge in Echtzeit", fa: "گفت‌وگوی زنده" },
      { icon: "📝", de: "Korrektur & Erklärung", fa: "اصلاح و توضیح" },
      { icon: "🎯", de: "Auf dein Niveau", fa: "متناسب با سطح تو" },
    ],
    stat: { v: "24/7", l: "verfügbar" },
    preview: {
      label: "Live-Dialog",
      rows: [
        { de: "Du: „Ich habe gestern nach Berlin gefahren.“", fa: "تو: جمله‌ی اولیه" },
        { de: "Coach: „Ich bin gestern nach Berlin gefahren.“", fa: "مربی: نسخه‌ی اصلاح‌شده" },
        { de: "Grund: Bewegungsverb → sein", fa: "دلیل: فعل حرکتی با sein" },
      ],
    },
  },
  {
    key: "movies",
    to: "/kino",
    eyebrow: "Empfohlen für dich",
    titleDe: "Filme & Serien",
    titleFa: "فیلم و سریال",
    descDe: "Lerne Deutsch mit Szenen, zweisprachigen Untertiteln und Vokabelkarten aus dem Film.",
    descFa: "با سکانس‌ها، زیرنویس دوزبانه و فلش‌کارت فیلم آلمانی یاد بگیر.",
    cta: "Kino entdecken",
    emoji: "🎬",
    bullets: [
      { icon: "🍿", de: "Kurze Lern-Szenen", fa: "سکانس‌های کوتاه" },
      { icon: "🔤", de: "Untertitel DE/FA", fa: "زیرنویس دوزبانه" },
      { icon: "📇", de: "Vokabeln speichern", fa: "ذخیره واژه‌ها" },
    ],
    stat: { v: "60+", l: "Titel" },
    preview: {
      label: "Szene des Tages",
      rows: [
        { de: "„Das kann doch nicht dein Ernst sein!“", fa: "«این که نمی‌تونه جدی باشه!»" },
        { de: "der Ernst — جدیت · B1", fa: "واژه‌ی سکانس" },
        { de: "Szene 2:14 · Untertitel DE/FA", fa: "زیرنویس دوزبانه" },
      ],
    },
  },
  {
    key: "music",
    to: "/musik",
    eyebrow: "Beliebt diese Woche",
    titleDe: "Musik & Karaoke",
    titleFa: "موسیقی و کارائوکه",
    descDe: "Songtexte Zeile für Zeile mitlesen, Aussprache trainieren und Wörter sammeln.",
    descFa: "متن آهنگ را خط‌به‌خط بخوان، تلفظ تمرین کن و واژه جمع کن.",
    cta: "Musik starten",
    emoji: "🎵",
    bullets: [
      { icon: "🎤", de: "Karaoke-Modus", fa: "حالت کارائوکه" },
      { icon: "🗣️", de: "Aussprache üben", fa: "تمرین تلفظ" },
      { icon: "⭐", de: "Playlists nach Niveau", fa: "لیست بر اساس سطح" },
    ],
    stat: { v: "120+", l: "Songs" },
    preview: {
      label: "Karaoke-Zeile",
      rows: [
        { de: "„Über den Wolken muss die Freiheit …“", fa: "«بالای ابرها آزادی باید…»" },
        { de: "die Freiheit — آزادی · B1", fa: "واژه‌ی ذخیره‌شده" },
        { de: "Aussprache: 92 % Treffer", fa: "دقت تلفظ" },
      ],
    },
  },
];

const SPOTLIGHT_DURATION = 4200;

function SpotlightCard({ className = "" }: { className?: string }) {
  const [idx, setIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);
  const [drag, setDrag] = useState(0);
  const dragStart = useRef<number | null>(null);
  const progressRef = useRef(0);

  const s = SPOTLIGHTS[idx];
  const theme = SECTION_THEME[s.key];

  const go = (dir: number) => {
    setIdx((i) => (i + dir + SPOTLIGHTS.length) % SPOTLIGHTS.length);
    progressRef.current = 0;
    setProgress(0);
  };

  useEffect(() => {
    if (paused) return;
    let raf = 0;
    let start = performance.now() - progressRef.current * SPOTLIGHT_DURATION;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / SPOTLIGHT_DURATION);
      if (p >= 1) {
        start = now;
        progressRef.current = 0;
        setProgress(0);
        setIdx((i) => (i + 1) % SPOTLIGHTS.length);
      } else {
        progressRef.current = p;
        setProgress(p);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [paused]);

  const onDown = (e: React.PointerEvent) => {
    dragStart.current = e.clientX;
    setPaused(true);
  };
  const onMove = (e: React.PointerEvent) => {
    if (dragStart.current === null) return;
    setDrag(e.clientX - dragStart.current);
  };
  const onUp = () => {
    if (dragStart.current !== null && Math.abs(drag) > 60) go(drag < 0 ? 1 : -1);
    dragStart.current = null;
    setDrag(0);
    setPaused(false);
  };

  return (
    <div
      className={`neu-card min-w-0 overflow-hidden p-0 ${className}`}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => {
        dragStart.current = null;
        setDrag(0);
        setPaused(false);
      }}
    >
      <div
        className="relative flex h-full min-w-0 touch-pan-y select-none flex-col p-5 text-white sm:p-6"
        style={{
          backgroundImage: [
            `radial-gradient(110% 130% at 88% -20%, ${theme.accent}66 0%, transparent 55%)`,
            `radial-gradient(90% 120% at 5% 115%, ${theme.primary}88 0%, transparent 60%)`,
            `linear-gradient(135deg, ${theme.base} 0%, ${theme.primary} 55%, ${theme.accent} 130%)`,
          ].join(", "),
          transition: "background-image 400ms ease",
        }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
      >
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-white/10 blur-3xl" />
          <div
            className="absolute -bottom-24 -left-12 h-52 w-52 rounded-full blur-3xl"
            style={{ backgroundColor: theme.accent, opacity: 0.35 }}
          />
        </div>

        <div
          key={idx}
          className="animate-fade-in relative flex min-w-0 flex-1 flex-col"
          style={{
            transform: `translateX(${drag * 0.35}px)`,
            transition: dragStart.current === null ? "transform 300ms ease" : "none",
          }}
        >
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
            <div className="min-w-0">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
                {s.eyebrow}
              </span>
              <h3 className="mt-2 text-balance text-xl font-black leading-tight sm:text-2xl">
                {s.emoji} {s.titleDe}
              </h3>
              <Fa className="fa-hint-xs !text-white/85">{s.titleFa}</Fa>
            </div>
            <div className="shrink-0 rounded-2xl bg-white/15 px-3 py-2 text-center backdrop-blur">
              <div className="text-base font-black leading-none tabular-nums">{s.stat.v}</div>
              <div className="mt-1 text-[9px] font-semibold uppercase tracking-wider text-white/80">
                {s.stat.l}
              </div>
            </div>
          </div>

          <p className="mt-3 max-w-xl text-sm text-white/85">{s.descDe}</p>
          <Fa className="fa-hint-xs !text-white/70">{s.descFa}</Fa>

          <ul className="mt-4 grid gap-2 sm:grid-cols-3">
            {s.bullets.map((b) => (
              <li
                key={b.de}
                className="flex min-w-0 items-center gap-2 rounded-2xl bg-white/12 p-2.5 backdrop-blur"
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/20 text-sm">
                  {b.icon}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[12px] font-bold">{b.de}</span>
                  <Fa className="fa-hint-xs !text-[9px] !text-white/70">{b.fa}</Fa>
                </span>
              </li>
            ))}
          </ul>

          {/* Mock-Vorschau – füllt den Raum auf großen Bildschirmen */}
          <div className="mt-4 flex min-h-0 flex-1 flex-col rounded-3xl bg-black/20 p-4 ring-1 ring-white/15 backdrop-blur">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-white/70" />
              <span className="h-2 w-2 rounded-full bg-white/40" />
              <span className="h-2 w-2 rounded-full bg-white/25" />
              <span className="ml-auto text-[10px] font-bold uppercase tracking-widest text-white/70">
                {s.preview.label}
              </span>
            </div>
            <div className="mt-3 flex flex-1 flex-col justify-center gap-2">
              {s.preview.rows.map((r, i) => (
                <div
                  key={r.de}
                  className={`min-w-0 rounded-2xl px-3 py-2 ${
                    i === 1 ? "bg-white/22 ring-1 ring-white/25" : "bg-white/10"
                  }`}
                >
                  <div className="truncate text-[12px] font-semibold sm:text-[13px]">{r.de}</div>
                  <Fa className="fa-hint-xs !text-[9px] !text-white/70">{r.fa}</Fa>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-auto grid gap-3 pt-5 sm:flex sm:items-center sm:justify-between">
            <Link
              to={s.to}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-black shadow-lg transition hover:-translate-y-0.5 sm:w-auto"
              style={{ color: theme.primary }}
              draggable={false}
            >
              {s.cta} <ArrowRightIcon />
            </Link>

            <div className="flex items-center justify-center gap-2 sm:justify-end">
              {SPOTLIGHTS.map((sp, i) => (
                <button
                  key={sp.key}
                  type="button"
                  onClick={() => {
                    setIdx(i);
                    setProgress(0);
                  }}
                  aria-label={sp.titleDe}
                  aria-current={i === idx ? "true" : undefined}
                  className={`h-2 overflow-hidden rounded-full transition-all duration-500 ease-out ${
                    i === idx ? "w-10 bg-white/35" : "w-2 bg-white/40 hover:bg-white/70"
                  }`}
                >
                  {i === idx && (
                    <span
                      className="block h-full rounded-full bg-white"
                      style={{ width: `${progress * 100}%`, transition: "width 180ms ease-out" }}
                    />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Achievements ---------- */

import { ACHIEVEMENTS as ALL_ACHIEVEMENTS } from "@/lib/deusi/achievements";

const BADGES = ALL_ACHIEVEMENTS.slice(0, 6);

function AchievementsCard({ className = "" }: { className?: string }) {
  const unlocked = ALL_ACHIEVEMENTS.filter((b) => b.unlocked).length;
  const total = ALL_ACHIEVEMENTS.length;
  const pct = Math.round((unlocked / total) * 100);
  return (
    <div className={`neu-card p-6 ${className}`}>
      <BlockHeader
        title="Erfolge"
        fa="دستاوردها"
        subtitle={`${unlocked} von ${total} freigeschaltet`}
        action={
          <div className="hidden items-center gap-2 sm:flex">
            <div className="h-1.5 w-24 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full"
                style={{
                  width: `${pct}%`,
                  background: "linear-gradient(90deg, #F97316, #F7C948)",
                }}
              />
            </div>
            <span className="text-[11px] font-black tabular-nums text-muted-foreground">
              {pct}%
            </span>
          </div>
        }
      />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {BADGES.map((b, i) => (
          <AchievementMedalCard key={b.id} achievement={b} index={i} compact />
        ))}
      </div>

      {/* Big, distinct CTA to view all achievements */}
      <Link
        to="/achievements"
        className="group relative mt-5 flex items-center justify-between gap-4 overflow-hidden rounded-2xl p-4 text-white shadow-lg ring-1 ring-white/20 transition hover:-translate-y-0.5 hover:shadow-xl sm:p-5"
        style={{
          backgroundImage: "linear-gradient(135deg, #7C2D12 0%, #F97316 55%, #F7C948 130%)",
        }}
      >
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute -bottom-12 -left-6 h-32 w-32 rounded-full bg-yellow-200/30 blur-3xl" />
          <div className="absolute inset-x-0 -top-24 h-24 rotate-12 bg-gradient-to-r from-transparent via-white/25 to-transparent opacity-0 transition duration-700 group-hover:top-full group-hover:opacity-100" />
        </div>
        <div className="relative flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-white/95 text-2xl shadow ring-1 ring-white/40">
            <span aria-hidden>🏆</span>
          </div>
          <div className="min-w-0">
            <div className="text-sm font-black leading-tight sm:text-base">
              Alle Erfolge ansehen
            </div>
            <Fa className="fa-hint-xs !text-white/85">مشاهده همه‌ی دستاوردها</Fa>
            <div className="mt-0.5 text-[11px] font-semibold text-white/85">
              {unlocked} / {total} freigeschaltet · {pct}%
            </div>
          </div>
        </div>
        <div className="relative flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1.5 text-xs font-black backdrop-blur transition group-hover:bg-white/30">
          <span>Öffnen</span>
          <span aria-hidden className="transition group-hover:translate-x-0.5">
            →
          </span>
        </div>
      </Link>
    </div>
  );
}

/* ---------- Level progress ---------- */

function LevelProgressCard({
  className = "",
  levelPct,
  wordsLearned,
  wordsGoal,
  xp,
  xpGoal,
}: {
  className?: string;
  levelPct: number;
  wordsLearned: number;
  wordsGoal: number;
  xp: number;
  xpGoal: number;
}) {
  const heat = vocabularyHeatmap;

  return (
    <div className={`neu-card p-6 sm:p-7 ${className}`}>
      <BlockHeader
        title="Sprachniveau · A2 → B1"
        fa="سطح زبان — پیشرفت به B1"
        subtitle={`Insgesamt ${learnerProfile.totalStudyHours}h · ${learnerProfile.activeDays} aktive Tage`}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <ProgressStat
          label="Niveau"
          fa="سطح"
          value={`${levelPct}%`}
          pct={levelPct}
          color="var(--flag-red)"
        />
        <ProgressStat
          label="Wörter"
          fa="واژگان"
          value={`${wordsLearned}/${wordsGoal}`}
          pct={Math.round((wordsLearned / wordsGoal) * 100)}
          color="#8B5CF6"
        />
        <ProgressStat
          label="XP heute"
          fa="امتیاز امروز"
          value={`${xp}/${xpGoal}`}
          pct={Math.round((xp / xpGoal) * 100)}
          color="#F7C948"
        />
      </div>

      {/* Compact vocabulary heatmap strip (last 12 weeks) */}
      <div className="mt-6">
        <div className="mb-2 flex items-center justify-between">
          <div className="text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
            Wortschatz · 12 Wochen
          </div>
          <Fa className="fa-hint-xs !text-[10px]">واژگان — ۱۲ هفته اخیر</Fa>
        </div>
        <div className="space-y-1">
          {heat.slice(0, 7).map((row, ri) => (
            <div
              key={ri}
              className="grid gap-1"
              style={{ gridTemplateColumns: `repeat(12, minmax(0,1fr))` }}
            >
              {row.slice(-12).map((v, ci) => (
                <div
                  key={ci}
                  className="aspect-square rounded-[4px]"
                  style={{
                    background:
                      v < 0.05
                        ? "var(--secondary)"
                        : `color-mix(in oklab, var(--flag-red) ${Math.round(v * 100)}%, transparent)`,
                  }}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ProgressStat({
  label,
  fa,
  value,
  pct,
  color,
}: {
  label: string;
  fa: string;
  value: string;
  pct: number;
  color: string;
}) {
  return (
    <div className="rounded-2xl border border-border/60 bg-secondary/40 p-4">
      <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-tight text-muted-foreground">
        <span>{label}</span>
        <Fa className="fa-hint-xs !text-[10px]">{fa}</Fa>
      </div>
      <div className="mt-1 text-lg font-black tabular-nums">{value}</div>
      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-background">
        <div
          className="dash-bar h-full rounded-full"
          style={{ width: `${Math.min(100, pct)}%`, background: color }}
        />
      </div>
    </div>
  );
}

/* ---------- Daily Tip ---------- */

function DailyTipCard({ className = "" }: { className?: string }) {
  return (
    <div
      className={`group relative overflow-hidden rounded-[1.75rem] p-6 text-white shadow-[0_24px_60px_-24px_rgba(221,34,34,0.55)] sm:p-7 ${className}`}
      style={{
        background: "linear-gradient(135deg, #b91c1c 0%, #dd2222 42%, #f59e0b 100%)",
      }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-28 h-72 w-72 rounded-full bg-white/25 blur-3xl transition-transform duration-700 group-hover:scale-110"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-24 -left-20 h-64 w-64 rounded-full bg-black/20 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />
      <div className="relative">
        <div className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-white ring-1 ring-white/30 backdrop-blur">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
          Tipp des Tages
        </div>
        <Fa className="fa-hint-xs mt-1 !text-[11px] !text-white/85 !opacity-100">نکته‌ی روز</Fa>
      </div>
      <blockquote className="relative mt-4 text-lg font-black leading-snug sm:text-xl">
        „Kleine Fortschritte führen zu großen Veränderungen."
      </blockquote>
      <Fa className="fa-hint-xs relative mt-1 !text-sm !text-white/90 !opacity-100">
        پیشرفت‌های کوچک، تغییرات بزرگ می‌سازند.
      </Fa>
      <p className="relative mt-4 text-sm text-white/85">
        Lerne täglich nur 15 Minuten — Konstanz schlägt Intensität. Wiederhole schwierige Karten aus
        Box 2 vor dem Schlafengehen für die beste Erinnerung.
      </p>
    </div>
  );
}

/* ---------- Icons ---------- */

function ArrowRightIcon({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}

function ClockIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="12"
      height="12"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </svg>
  );
}

function PinIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="12"
      height="12"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 21s-7-6.6-7-11a7 7 0 1 1 14 0c0 4.4-7 11-7 11z" />
      <circle cx="12" cy="10" r="2.5" />
    </svg>
  );
}
