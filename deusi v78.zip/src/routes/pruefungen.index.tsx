import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  BookOpen,
  FileText,
  GraduationCap,
  Landmark,
  Search,
  Star,
  type LucideIcon,
} from "lucide-react";
import { EXAMS, EXAM_STATS, type Exam, type ExamPurpose } from "@/lib/deusi/exams/mockExams";
import { ExamLogo } from "@/components/deusi/exams/ExamLogo";
import { ExamCompareTable, ExamPicker } from "@/components/deusi/exams/ExamCompareTable";
import { DownloadButton } from "@/components/deusi/exams/DownloadButton";
import { FaHint } from "@/components/deusi/FaHint";
import { SectionHero } from "@/components/deusi/SectionHero";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";

export const Route = createFileRoute("/pruefungen/")({
  head: () => ({
    meta: [
      { title: "Deutschprüfungen – TestDaF, telc, ÖSD, Goethe & DSH | DEUSI" },
      {
        name: "description",
        content:
          "Kompletter Leitfaden zu den internationalen Deutschprüfungen: Vergleich, Bücher, Modelltests, Lernressourcen und Prüfungszentren in Iran.",
      },
      { property: "og:title", content: "Deutschprüfungen – der komplette Leitfaden | DEUSI" },
      {
        property: "og:description",
        content:
          "Vergleiche TestDaF, telc, ÖSD, Goethe und DSH und lade alle Vorbereitungsmaterialien herunter.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ExamsPage,
});

const PURPOSE_FILTERS: ("Alle" | ExamPurpose)[] = ["Alle", "Studium", "Beruf", "Aufenthalt"];

function ExamsPage() {
  const query = "";
  const [level, setLevel] = useState<string>("Alle");
  const [purpose, setPurpose] = useState<"Alle" | ExamPurpose>("Alle");

  const filtered = useMemo(() => {
    return EXAMS.filter((e) => {
      const q = query.trim().toLowerCase();
      const matchQ =
        !q ||
        e.name.toLowerCase().includes(q) ||
        e.tagline.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q);
      const matchL = level === "Alle" || e.levels.includes(level);
      const matchP = purpose === "Alle" || e.purpose.includes(purpose);
      return matchQ && matchL && matchP;
    });
  }, [query, level, purpose]);

  const levelFilters = ["Alle", "A1", "A2", "B1", "B2", "C1", "C2"];

  return (
    <div className="space-y-10 pb-16">
      <SectionHero sectionKey="exams" />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatTile n={EXAM_STATS.totalExams} label="Prüfungen im Überblick" icon={GraduationCap} />
        <StatTile n={EXAM_STATS.totalBooks} label="Bücher zum Download" icon={BookOpen} />
        <StatTile n={EXAM_STATS.totalPractice} label="Modelltests & Übungssätze" icon={FileText} />
        <StatTile n={EXAM_STATS.totalCenters} label="Prüfungszentren in Iran" icon={Landmark} />
      </div>

      <section className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Ziel:
          </span>
          {PURPOSE_FILTERS.map((p) => (
            <FilterChip key={p} active={purpose === p} onClick={() => setPurpose(p)}>
              {p}
            </FilterChip>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Niveau:
          </span>
          {levelFilters.map((l) => (
            <FilterChip key={l} active={level === l} onClick={() => setLevel(l)}>
              {l}
            </FilterChip>
          ))}
        </div>

        <div>
          <h2 className="mb-1 text-lg font-bold">Internationale Deutschprüfungen</h2>
          <FaHint size="sm" className="mb-4 block">
            آزمون‌های بین‌المللی زبان آلمانی
          </FaHint>
          {filtered.length === 0 ? (
            <div className="glass rounded-3xl p-10 text-center text-sm text-muted-foreground">
              Keine Prüfungen gefunden. Bitte Filter oder Suche anpassen.
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
              {filtered.map((exam, i) => (
                <ExamCard key={exam.id} exam={exam} index={i} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section>
        <h2 className="mb-1 text-lg font-bold">Prüfungen im Vergleich</h2>
        <FaHint size="sm" className="mb-4 block">
          مقایسه آزمون‌ها در یک نگاه
        </FaHint>
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
          <ExamCompareTable />
          <ExamPicker />
        </div>
      </section>

      <section>
        <h2 className="mb-1 text-lg font-bold">Bücher & Materialien</h2>
        <FaHint size="sm" className="mb-4 block">
          کتاب‌ها و منابع آماده دانلود
        </FaHint>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {EXAMS.map((e) => (
            <div key={e.id} className="neu-card flex items-center gap-4 p-4">
              <ExamLogo kind={e.logo} size={48} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-bold">{e.shortName}</div>
                <div className="text-xs text-muted-foreground">
                  {e.books.length} Bücher · {e.resources.length} Ressourcen
                </div>
              </div>
              <Link
                to="/pruefungen/$examId"
                params={{ examId: e.id }}
                hash="buecher"
                className="shrink-0 rounded-full border border-border/70 bg-card/60 px-3 py-1.5 text-xs font-semibold transition hover:border-[color:var(--section-primary)]/50"
              >
                Bibliothek
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full border px-4 py-1.5 text-xs font-semibold transition ${
        active
          ? "border-transparent bg-[color:var(--section-primary)] text-white shadow-sm"
          : "border-border/70 bg-card/60 text-muted-foreground hover:border-[color:var(--section-primary)]/40 hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function StatTile({ n, label, icon: Icon }: { n: number; label: string; icon: LucideIcon }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="neu-card flex items-center gap-3 p-4"
    >
      <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[color:var(--section-primary)]/10 text-[color:var(--section-primary)]">
        <Icon className="h-5 w-5" aria-hidden />
      </div>
      <div className="min-w-0">
        <div className="text-2xl font-bold leading-tight">{n}</div>
        <div className="text-xs font-medium leading-snug text-muted-foreground">{label}</div>
      </div>
    </motion.div>
  );
}

function ExamCard({ exam, index }: { exam: Exam; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.4 }}
      whileHover={{ y: -4 }}
      className="neu-card group relative flex flex-col overflow-hidden p-0"
    >
      <div
        className="relative overflow-hidden px-5 pb-5 pt-5"
        style={{ background: exam.gradient }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute -right-10 -top-14 h-40 w-40 rounded-full bg-white/25 blur-3xl"
        />
        <div className="relative flex items-start justify-between gap-3">
          <ExamLogo kind={exam.logo} size={64} />
          <div className="flex flex-wrap justify-end gap-1.5">
            {exam.levels.map((l) => (
              <span
                key={l}
                className="rounded-full bg-background/70 px-2 py-0.5 text-[11px] font-bold text-foreground backdrop-blur"
              >
                {l}
              </span>
            ))}
          </div>
        </div>
        <h3 className="relative mt-4 text-lg font-bold leading-tight text-foreground">
          {exam.name}
        </h3>
        <p className="relative mt-1 line-clamp-2 text-xs text-foreground/70">{exam.tagline}</p>
      </div>

      <div className="flex flex-1 flex-col gap-4 p-5">
        <div className="flex flex-wrap gap-1.5">
          {exam.purpose.map((p) => (
            <span
              key={p}
              className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold text-muted-foreground"
            >
              {p}
            </span>
          ))}
        </div>

        <ul className="space-y-1.5 text-xs">
          {exam.highlights.slice(0, 3).map((h) => (
            <li key={h.title} className="flex items-center gap-2">
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-[color:var(--section-primary)]/10 text-xs">
                {h.icon}
              </span>
              <span className="min-w-0 truncate text-foreground/80">{h.title}</span>
            </li>
          ))}
        </ul>

        <div className="mt-auto grid grid-cols-4 gap-2 rounded-2xl border border-border/60 bg-card/60 p-3 text-center">
          <MiniStat n={exam.books.length} label="Bücher" />
          <MiniStat n={exam.resources.length} label="Quellen" />
          <MiniStat n={exam.practice.length} label="Tests" />
          <MiniStat n={exam.experiences.length} label="Berichte" />
        </div>

        <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-2">
          <Link
            to="/pruefungen/$examId"
            params={{ examId: exam.id }}
            className="grid place-items-center rounded-full bg-[color:var(--section-primary)] py-2.5 text-xs font-semibold text-white transition hover:opacity-90"
          >
            Details ansehen →
          </Link>
          <div className="flex items-center gap-1">
            <BookmarkButton
              type="exam"
              id={exam.id}
              title={exam.name}
              sub={exam.tagline}
              level={exam.recommendedLevel}
              to={`/pruefungen/${exam.id}`}
              variant="chip"
            />
            <DownloadButton
              title={`${exam.shortName} Starter-Paket`}
              note="Übersicht, Wortschatzliste und Modelltest"
              variant="icon"
              label="Starter-Paket"
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function MiniStat({ n, label }: { n: number; label: string }) {
  return (
    <div className="min-w-0">
      <div className="text-base font-bold">{n}</div>
      <div className="truncate text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
    </div>
  );
}
