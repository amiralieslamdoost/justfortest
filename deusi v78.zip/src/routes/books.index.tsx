import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { BookOpen, Library } from "lucide-react";

import { type BookLevel } from "@/lib/deusi/dictionary/books";
import { useBooks } from "@/lib/api/useMedia";
import { SectionHero } from "@/components/deusi/SectionHero";
import { SearchField } from "@/components/deusi/SearchField";
import { FaHint } from "@/components/deusi/FaHint";

export const Route = createFileRoute("/books/")({
  head: () => ({
    meta: [
      { title: "Lehrbücher — Wortschatz · DEUSI" },
      {
        name: "description",
        content:
          "Alle Kursbücher auf einen Blick: Menschen, Netzwerk & Co. — Vokabeln Lektion für Lektion lernen.",
      },
      { property: "og:title", content: "Lehrbücher — Wortschatz · DEUSI" },
      {
        property: "og:description",
        content: "Wortschatz aus deinem Kursbuch — nach Lektionen sortiert.",
      },
    ],
  }),
  component: BooksIndexPage,
});

const LEVELS: (BookLevel | "alle")[] = ["alle", "A1", "A2", "B1", "B2", "C1"];

function BooksIndexPage() {
  const [q, setQ] = useState("");
  const [level, setLevel] = useState<BookLevel | "alle">("alle");
  // کتاب‌ها از لایهٔ API (بک‌اند یا fallback محلی) — سشن ۵.
  const { books: allBooks } = useBooks({ perPage: 200 });

  const books = useMemo(
    () =>
      allBooks.filter(
        (b) =>
          (level === "alle" || b.level === level) &&
          (q ? `${b.title} ${b.publisher}`.toLowerCase().includes(q.toLowerCase()) : true),
      ),
    [q, level, allBooks],
  );

  return (
    <div className="space-y-6 pb-10 animate-fade">
      <SectionHero
        sectionKey="reading"
        titleDe="Wortschatz aus Lehrbüchern"
        titleFa="واژگان کتاب‌های آموزشی"
        highlight="Lehrbüchern"
        descDe="Wähle dein Kursbuch und lerne die Vokabeln Lektion für Lektion."
        descFa="کتاب درسی‌ات را انتخاب کن و واژه‌ها را درس‌به‌درس یاد بگیر."
        right={
          <SearchField
            value={q}
            onValueChange={setQ}
            tone="hero"
            placeholder="Buch oder Verlag suchen…"
            className="w-full sm:w-72"
          />
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        {LEVELS.map((l) => {
          const active = level === l;
          return (
            <button
              key={l}
              type="button"
              onClick={() => setLevel(l)}
              aria-pressed={active}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                active
                  ? "bg-foreground text-background shadow"
                  : "border border-border bg-background/50 text-foreground/70 hover:border-foreground/30"
              }`}
            >
              {l === "alle" ? "Alle Niveaus" : l}
            </button>
          );
        })}
      </div>

      {books.length === 0 ? (
        <div className="glass-strong grid place-items-center gap-2 rounded-[28px] py-20 text-center">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-foreground/5">
            <Library className="h-6 w-6 text-foreground/60" />
          </div>
          <div className="text-sm font-semibold">Kein Buch gefunden.</div>
          <FaHint>کتابی پیدا نشد</FaHint>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {books.map((b) => (
            <Link
              key={b.id}
              to="/books/$bookId"
              params={{ bookId: b.id }}
              aria-label={`${b.title} — Vokabeln öffnen`}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border/70 bg-card text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg"
            >
              <div
                className="relative aspect-[3/4] w-full overflow-hidden"
                style={{ background: `linear-gradient(160deg, ${b.color}33, ${b.color}11)` }}
              >
                {b.coverUrl ? (
                  <img
                    src={b.coverUrl}
                    alt={b.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
                  />
                ) : (
                  <div className="grid h-full w-full place-items-center text-5xl opacity-80">
                    {b.cover}
                  </div>
                )}
                <span
                  className="absolute left-2 top-2 rounded-md px-1.5 py-0.5 text-[10px] font-bold text-white shadow"
                  style={{ background: b.color }}
                >
                  {b.level}
                </span>
              </div>
              <div className="min-w-0 space-y-0.5 p-3">
                <h2 className="truncate text-sm font-bold leading-snug">{b.title}</h2>
                <p className="truncate text-xs text-muted-foreground">{b.publisher}</p>
                <p className="inline-flex items-center gap-1 text-[11px] font-semibold text-foreground/70">
                  <BookOpen className="h-3 w-3" />
                  {b.wordCount} Wörter
                </p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
