import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  HeadContent,
  useRouterState,
  useRouter,
} from "@tanstack/react-router";
import { useEffect } from "react";

import { DeusiProvider, useDeusi } from "@/lib/deusi/store";
import { InteractionsProvider } from "@/lib/deusi/interactions";
import { ThemeProvider } from "@/lib/deusi/theme";
import { Sidebar } from "@/components/deusi/Sidebar";
import { TopBar } from "@/components/deusi/TopBar";
import { MobileNav } from "@/components/deusi/MobileNav";
import { Toaster } from "@/components/ui/sonner";
import { OfflineBanner } from "@/components/deusi/OfflineBanner";
import { SyncIndicator } from "@/components/deusi/SyncIndicator";
import { NotFoundPage } from "@/components/deusi/NotFound";
import { ErrorCard } from "@/components/deusi/ErrorCard";
import { SectionScope } from "@/components/deusi/SectionScope";
import { sectionForPath } from "@/lib/deusi/sectionRoutes";
import { SkelPage } from "@/components/deusi/Skeletons";

/**
 * Seiten, die ohne Anmeldung erreichbar sind. Alles andere leitet auf /login um.
 * صفحاتی که بدون ورود قابل دسترسی هستند؛ بقیه به صفحه ورود هدایت می‌شوند.
 */
const PUBLIC_PATHS = new Set([
  "/",
  "/login",
  "/register",
  "/passwort-vergessen",
  "/passwort-zuruecksetzen",
  "/impressum",
  "/datenschutz",
  "/agb",
]);

function isPublicPath(pathname: string) {
  const p = pathname.length > 1 && pathname.endsWith("/") ? pathname.slice(0, -1) : pathname;
  return PUBLIC_PATHS.has(p);
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: "DEUSI — Deutsch. Einfach. Meistern." },
      {
        name: "description",
        content: "DEUSI: moderne Lernplattform für Deutsch — Leitner-Boxen und FSRS-Algorithmus.",
      },
      { name: "theme-color", content: "#FBFBFC" },
      { property: "og:title", content: "DEUSI — Deutsch Sprach Ingenieur" },
      { property: "og:description", content: "Deutsch. Einfach. Meistern." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      // Sora is self-hosted from /public/fonts (no Google Fonts dependency),
      // so typography is identical on every machine/network.
      {
        rel: "preload",
        href: "/fonts/Sora-latin.woff2",
        as: "font",
        type: "font/woff2",
        crossOrigin: "anonymous",
      },

      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  component: RootComponent,
  notFoundComponent: () => <NotFoundPage />,
  errorComponent: ({ error, reset }) => <ErrorCard error={error} reset={reset} />,
});

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <HeadContent />
      <ThemeProvider>
        <DeusiProvider>
          <InteractionsProvider>
            <Shell />
            <OfflineBanner />
            <SyncIndicator />
            <Toaster />
          </InteractionsProvider>
        </DeusiProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

function Shell() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isPublic = isPublicPath(pathname);
  const isAuthPage =
    pathname === "/" ||
    pathname === "/login" ||
    pathname === "/register" ||
    pathname === "/passwort-vergessen" ||
    pathname === "/passwort-zuruecksetzen";
  const isFocusMode = pathname === "/learn" || pathname === "/onboarding";
  // An open community chat is fullscreen on mobile.
  const isMobileFullscreen = pathname.startsWith("/community/chat/") || pathname === "/ki-coach";
  const sectionKey = sectionForPath(pathname);

  // Gast auf einer geschützten Seite → zurück zum Login.
  const locationHref = useRouterState({ select: (s) => s.location.href });
  useEffect(() => {
    if (hydrated && !currentUser && !isPublic) {
      // مقصد فعلی را نگه می‌داریم تا بعد از ورود کاربر به همان‌جا برگردد.
      router.navigate({ to: "/login", search: { returnTo: locationHref }, replace: true });
    }
  }, [hydrated, currentUser, isPublic, router, locationHref]);

  if (isAuthPage) {
    return (
      <main className="min-h-screen w-full">
        <Outlet />
      </main>
    );
  }

  if (!currentUser && !isPublic) {
    // Noch nicht hydriert oder Gast: keine geschützten Inhalte rendern.
    return (
      <main className="mx-auto min-h-screen w-full max-w-[1500px] px-4 py-6 sm:px-6 sm:py-8">
        <SkelPage />
      </main>
    );
  }

  if (!currentUser) {
    // Public content routes (events, pruefungen, lesen, ...) still need
    // page padding + a max-width container so content isn't glued to the
    // viewport edges when no sidebar is rendered.
    return (
      <main
        className={`mx-auto min-h-screen w-full max-w-[1500px] sm:px-6 sm:py-8 ${isMobileFullscreen ? "px-0 py-0" : "px-4 py-6 pb-16"}`}
      >
        <SectionScope sectionKey={sectionKey}>
          <Outlet />
        </SectionScope>
      </main>
    );
  }

  if (isFocusMode) {
    // Focus mode: no sidebar, no topbar — nur der Zurück-Button in der Seite selbst.
    return (
      <main className="mx-auto min-h-screen max-w-[1400px] px-4 py-5">
        <SectionScope sectionKey={sectionKey}>
          <Outlet />
        </SectionScope>
      </main>
    );
  }

  return (
    <>
      <div
        className={`mx-auto flex min-h-screen max-w-[1500px] gap-5 lg:px-4 lg:py-5 lg:pb-5 ${
          isMobileFullscreen ? "px-0 py-0" : "px-3 py-4 pb-28 sm:px-4 sm:py-5"
        }`}
      >
        <Sidebar />
        <main className="min-w-0 flex-1">
          <div className={isMobileFullscreen ? "hidden lg:block" : undefined}>
            <TopBar />
          </div>
          <SectionScope sectionKey={sectionKey} key={pathname} className="page-in">
            <Outlet />
          </SectionScope>
        </main>
      </div>
      {currentUser && !isMobileFullscreen && <MobileNav />}
    </>
  );
}
