/**
 * اسکریپت مهاجرت محتوا (سشن ۴): انتقال گرامر و مقاله‌های خواندن به PocketBase.
 *
 * اجرا:
 *   PB_URL=http://127.0.0.1:8090 PB_ADMIN_EMAIL=... PB_ADMIN_PASSWORD=... bun scripts/seed-content.ts
 *
 * اسکریپت idempotent است: رکوردهای موجود بر اساس slug به‌روزرسانی می‌شوند.
 */
import PocketBase from "pocketbase";
import { grammarTopics } from "../src/lib/deusi/mockGrammar";
import { articles } from "../src/lib/deusi/mockReading";

const PB_URL = process.env["PB_URL"] ?? "http://127.0.0.1:8090";
const EMAIL = process.env["PB_ADMIN_EMAIL"];
const PASSWORD = process.env["PB_ADMIN_PASSWORD"];

if (!EMAIL || !PASSWORD) {
  console.error("PB_ADMIN_EMAIL و PB_ADMIN_PASSWORD لازم است.");
  process.exit(1);
}

const pb = new PocketBase(PB_URL);
pb.autoCancellation(false);

async function upsert(collection: string, filter: string, data: Record<string, unknown>) {
  const existing = await pb
    .collection(collection)
    .getFirstListItem(filter)
    .catch(() => null);
  if (existing) return pb.collection(collection).update(existing.id, data);
  return pb.collection(collection).create(data);
}

const esc = (v: string) => v.replace(/'/g, "\\'");

async function seedGrammar() {
  let topicCount = 0;
  let lessonCount = 0;
  let exerciseCount = 0;

  for (const [ti, t] of grammarTopics.entries()) {
    const topic = await upsert("grammar_topics", `slug='${esc(t.id)}'`, {
      slug: t.id,
      name: t.name,
      subtitle: t.subtitle,
      description: t.description ?? t.subtitle,
      category: t.category,
      emoji: t.emoji,
      difficulty: t.difficulty,
      duration: t.duration ?? 0,
      accent: t.accent,
      nodes: t.nodes ?? [],
      order: ti,
      published: true,
    });
    topicCount++;

    for (const [li, l] of (t.lessons ?? []).entries()) {
      const lesson = await upsert("grammar_lessons", `slug='${esc(l.id)}' && topic='${topic.id}'`, {
        topic: topic.id,
        node_id: l.nodeId ?? "",
        slug: l.id,
        title: l.title,
        subtitle: l.subtitle ?? "",
        emoji: l.emoji ?? "📘",
        duration: l.duration ?? 0,
        difficulty: l.difficulty ?? t.difficulty,
        sections: l.sections ?? [],
        order: li,
        published: true,
      });
      lessonCount++;

      const exercises = (l.sections ?? [])
        .map((s) => s.exercise)
        .filter((e): e is NonNullable<typeof e> => Boolean(e));
      for (const [ei, ex] of exercises.entries()) {
        await upsert("exercises", `lesson='${lesson.id}' && prompt='${esc(ex.prompt)}'`, {
          lesson: lesson.id,
          type: ex.type,
          prompt: ex.prompt,
          data: ex.data,
          explanation: (ex as { explanation?: string }).explanation ?? "",
          cefr: l.difficulty ?? t.difficulty,
          order: ei,
        });
        exerciseCount++;
      }
    }
  }
  console.log(`گرامر: ${topicCount} موضوع، ${lessonCount} درس، ${exerciseCount} تمرین`);
}

async function seedReading() {
  let count = 0;
  for (const a of articles) {
    await upsert("articles", `slug='${esc(a.slug ?? a.id)}'`, {
      slug: a.slug ?? a.id,
      title: a.title,
      description: a.description,
      category: a.category,
      level: a.level,
      minutes: a.minutes ?? 0,
      words: a.words ?? 0,
      cover: a.cover ?? "",
      author: a.author ?? "DEUSI",
      published_at: a.publishedAt ?? new Date().toISOString(),
      content: a.content ?? [],
      vocab: a.vocab ?? [],
      questions: a.questions ?? [],
      ai_summary: a.aiSummary ?? "",
      grammar_notes: a.grammarNotes ?? [],
      published: true,
    });
    count++;
  }
  console.log(`خواندن: ${count} مقاله`);
}

async function main() {
  await pb.admins.authWithPassword(EMAIL!, PASSWORD!);
  await seedGrammar();
  await seedReading();
  console.log("مهاجرت محتوا کامل شد.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
