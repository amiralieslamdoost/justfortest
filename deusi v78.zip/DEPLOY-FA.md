# DEUSI — نسخهٔ Static / SPA

این پروژه از حالت SSR (TanStack Start روی Cloudflare Worker) به یک **اپ کاملاً استاتیک (SPA)**
با Vite + TanStack Router تبدیل شده است. خروجی build فقط فایل‌های ثابت است و روی هر هاست/سروری بالا می‌آید.

## چه چیزی تغییر کرد

- `src/server.ts`، `src/start.ts`، `src/lib/error-page.ts`، `src/lib/error-capture.ts` حذف شدند (فقط برای SSR بودند).
- وابستگی‌های `@tanstack/react-start`، `nitro`، `@lovable.dev/vite-tanstack-config` حذف شدند.
- `index.html` + `src/main.tsx` به‌عنوان نقطهٔ ورود کلاینت اضافه شد.
- در `src/routes/__root.tsx`: پوستهٔ `<html>/<body>` (shellComponent) و `<Scripts />` حذف شد؛ `<HeadContent />` داخل کامپوننت رندر می‌شود؛ CSS از `src/main.tsx` ایمپورت می‌شود.
- `vite.config.ts` ساده و استاندارد شد (react + tailwind + tsconfigPaths + tanstackRouter).
- تمام ۵۵ روت، تم، RTL، فونت‌های self-hosted، انیمیشن‌ها و PWA manifest دست‌نخورده کار می‌کنند.

## اجرا روی سیستم خودت

```bash
npm install        # یا bun install / pnpm install
npm run dev        # http://localhost:8080
npm run build      # خروجی در پوشهٔ dist/
npm run preview    # تست خروجی build
```

## آپلود روی سرور

کل محتوای پوشهٔ `dist/` را در ریشهٔ سایت (مثلاً `public_html` یا `/var/www/deusi/dist`) بگذار.

**نکتهٔ حیاتی:** چون SPA است، سرور باید همهٔ مسیرها را به `index.html` برگرداند
وگرنه رفرش روی `/dashboard` خطای ۴۰۴ می‌دهد.

- Apache / هاست اشتراکی: فایل `.htaccess` از قبل داخل `dist/` قرار می‌گیرد.
- Nginx: از `nginx.conf.example` استفاده کن.

## قدم بعدی: بک‌اند با PocketBase

1. فایل اجرایی PocketBase را روی سرور اجرا کن: `./pocketbase serve --http=127.0.0.1:8090`
2. در Nginx مسیرهای `/api/` و `/_/` را به آن پروکسی کن (نمونه در `nginx.conf.example` کامنت شده).
3. در فرانت‌اند یک لایهٔ داده بساز (مثلاً `src/lib/api/`) و mock دادهٔ فعلی در `src/lib/deusi/` را
   مرحله‌به‌مرحله با فراخوانی PocketBase جایگزین کن. auth، فایل و realtime همه در خود PocketBase موجود است.
