# سشن ۱۱ — کیفیت، عملکرد، SEO و PWA

معماری بدون تغییر: Vite Static SPA + TanStack React Router، بدون SSR/Cloud. طراحی، توکن‌های رنگی و MOCK_MODE دست نخورده‌اند.

## ۱) شکستن روت‌های بزرگ (بدون تغییر ظاهر)

- `src/routes/index.tsx`: از ۳۱۹۸ خط به ۸۵ خط؛ همهٔ سکشن‌ها به `src/components/deusi/landing/` منتقل شدند (Nav, Hero, Manifest, Marquee, HorizontalFeatures, Features, DeepDive, AppShowcase, FlashcardShowcase, Stats, Journey, Pricing, Testimonials, FinalCTA, Footer, CursorSpotlight).
- `src/routes/dashboard.tsx`: ۱۷۴۵ → ۲۴۷ خط؛ ویجت‌ها در `src/components/deusi/dashboard/`.
- `src/routes/achievements.tsx`: ۱۰۰۰ → ۳۵۵ خط؛ اجزا در `src/components/deusi/achievements/`.
- `src/routes/learn.tsx`: ۸۶۴ → ۳۱۸ خط؛ اجزا در `src/components/deusi/learn/`.
- `src/routes/einstellungen.tsx`: ۸۱۹ → ۲۴۳ خط؛ اجزا در `src/components/deusi/settings/`.
- باقی‌مانده برای سشن بعد: `profil.tsx` (۲۱۰۰ خط)، `dictionary.tsx` (۱۳۴۴ خط) و `pruefungen.$examId.tsx` (۹۱۰ خط) هنوز تفکیک نشده‌اند؛ بقیهٔ کارهای سشن ۱۱ مستقل از آن‌ها کامل است.

هیچ کامپوننت روتی export نشده تا code splitting خودکار روتر حفظ شود.

## ۲) عملکرد

- `defaultPreload: "intent"` در روتر (پیش‌بارگذاری چانک روت با هاور/فوکوس).
- پیش‌فرض‌های TanStack Query: `staleTime: 30s`، `retry: 1`، بدون refetch روی فوکوس.
- چارت‌های recharts در `statistiken` با `React.lazy` از طریق `src/components/deusi/stats/LazyCharts.tsx` بارگذاری می‌شوند (fallback اسکلتون هم‌اندازه).
- همهٔ `<img>`ها `loading="lazy"` و `decoding="async"` گرفتند.
- تصاویر بلااستفادهٔ ۱.۹ مگابایتی (`goal-card.png`، `lernen-card.png`) حذف و آیکون‌ها بهینه شدند (هر آیکون < ۵ کیلوبایت).

## ۳) loading / error / empty

قرارداد سراسری از قبل در `src/router.tsx` وجود داشت و حفظ شد: `defaultPendingComponent = SkelPage`، `defaultErrorComponent = ErrorCard` (با «تلاش دوباره»)، `defaultNotFoundComponent = NotFoundPage`، `defaultPendingMs = 200`.

## ۴) SEO

- `head()` یکتا برای همهٔ روت‌های محتوایی؛ صفحهٔ اصلی هم عنوان/توضیح/OG مخصوص خودش را گرفت.
- JSON-LD: `EducationalOrganization` و `WebSite` + `SearchAction` در صفحهٔ اصلی از طریق `src/components/deusi/JsonLd.tsx`.
- `scripts/gen-sitemap.ts` → `public/sitemap.xml`، به‌صورت خودکار در `prebuild` اجرا می‌شود.
  **مهم:** هنگام بیلد نهایی دامنه را بدهید: `SITE_URL=https://example.de bun run build`.
- `public/robots.txt` کامل شد: مسیرهای پشتِ ورود Disallow و آدرس sitemap اضافه شد.

## ۵) PWA

- `vite-plugin-pwa` (حالت `generateSW`) با `injectRegister: null` و `devOptions.enabled: false`.
- استراتژی کش: ناوبری‌ها NetworkFirst، فونت‌ها CacheFirst، تصاویر StaleWhileRevalidate، `/api/collections/*` NetworkFirst با ذخیرهٔ آخرین پاسخ (کارکرد آفلاین واژگان در کنار `offline-queue.ts`).
- `src/lib/pwa/register.ts`: ثبت فقط در بیلد پروداکشن، خارج از iframe و پیش‌نمایش‌ها؛ `?sw=off` سرویس‌ورکر را حذف می‌کند؛ هنگام آپدیت، اعلان «نسخهٔ جدید» با دکمهٔ بارگذاری مجدد.
- `public/manifest.webmanifest` کامل شد (id، scope، description، categories، آیکون‌های ۱۹۲/۵۱۲ و maskable) + `apple-touch-icon`.
- `nginx.conf.example` و `public/.htaccess`: `sw.js` و مانیفست بدون کش سرو می‌شوند.

## ۶) دسترس‌پذیری و RTL

- لینک «Zum Inhalt springen» (`SkipLink`) و `id="hauptinhalt"` روی همهٔ لندمارک‌های `main`.
- پشتیبانی از `prefers-reduced-motion` در `src/styles.css`.
- ترکیب دو زبانه (پایهٔ آلمانی LTR + بخش‌های فارسی RTL) بازبینی و بدون تغییر حفظ شد.

## وضعیت بررسی

- `bunx tsc --noEmit` بدون خطا.
- `bunx vite build` موفق؛ سرویس‌ورکر و ۲۱۷ فایل precache تولید شد.

## نکته برای سشن ۱۲

بازبینی امنیتی قواعد کالکشن‌ها، CORS و rate limit، تست‌های سبک برای `fsrs.ts`/`gamification.ts`/planner، اسکریپت‌های `backend/ops/` و README-FA نهایی. همچنین قبل از انتشار حتماً `SITE_URL` را تنظیم کنید.
