# DEUSI — اسکیمای PocketBase (توضیح فارسی)

این سند مکمل `backend/pb_schema.json` است. ۵۶ کالکشن، بر پایه دیتای mock موجود در `src/lib/deusi/*`.

## ۱. نصب و ایمپورت اسکیما

> این اسکیما به‌صورت واقعی روی **PocketBase 0.23.12** ایمپورت و تست شده است (۵۶ کالکشن با تمام ایندکس‌ها و قواعد، بدون خطا).

1. PocketBase نسخه **0.23 یا بالاتر** لازم است (فرمت `fields` در JSON).
2. اجرای سرور: `./pocketbase serve --http=127.0.0.1:8090`
3. اولین بار: در `/_/` حساب superuser بساز.
4. ایمپورت با UI: `/_/` → **Settings → Import collections** → محتوای کامل `backend/pb_schema.json` (یک آرایه JSON است) را پیست کن → Review → Import.
5. مهم: کالکشن `users` در این اسکیما auth است و با کالکشن پیش‌فرض `users` پاکت‌بیس هم‌نام است. در صفحه Review گزینه‌ی حذف/جایگزینی کالکشن قدیمی `users` را تأیید کن (روی نصب خالی کاملاً بی‌خطر است). روی نصبِ دارای کاربر واقعی، اول از `pb_data` بکاپ بگیر.
6. ایمپورت با اسکریپت (خودکار): `bash backend/import.sh http://127.0.0.1:8090 <superuser-email> <password>`
7. بعد از ایمپورت، قواعد API را با `backend/API-RULES.md` تطبیق بده.
8. در فرانت `VITE_PB_URL=http://127.0.0.1:8090` (یا دامنه سرور) تنظیم می‌شود — این کار در سشن ۲ انجام می‌شود. تا آن زمان اپ در MOCK_MODE کار می‌کند.

## ۲. ERD متنی

```text
users (auth)
 ├─1:1─ profiles، settings، streaks، subscriptions
 ├─1:n─ placement_results، user_words، srs_cards، lesson_progress،
 │      reading_progress، writing_submissions، media_progress، media_vocab،
 │      exam_attempts ─1:n─ answers
 │      study_plans ─1:n─ plan_sessions ─1:n─ session_logs
 │      bookmarks، notifications، blocks، chat_reads، event_rsvps
 │      xp_ledger، user_achievements، user_missions، daily_stats
 │      ai_threads ─1:n─ ai_messages، ai_usage
 ├─1:n─ posts ─1:n─ comments
 ├─n:m─ chats (members) ─1:n─ messages
 └─1:1─ tandem_profiles

words ─1:1─ verbs           words ─n:m(json word_ids)─ books
words ─1:n─ user_words، srs_cards، media_vocab
word_families (اعضا در json members)
grammar_topics ─1:n─ grammar_lessons ─1:n─ exercises ─1:n─ lesson_progress
articles ─1:n─ reading_progress
artists ─1:n─ songs        podcast_shows ─1:n─ episodes
films / songs / episodes / books ─(media_type + media_id)─ media_progress، media_vocab
exams ─1:n─ exam_sections ─1:n─ exam_attempts ─1:n─ answers
events ─1:n─ event_rsvps
achievements ─1:n─ user_achievements     missions ─1:n─ user_missions
reports → (target_type, target_id) به هر محتوایی
```

نکته طراحی: جاهایی که دیتای mock ساختار تودرتوی عمیق و ثابت دارد (مثل `sections` یک درس، `cues` زیرنویس، `transcript` پادکست، `lyrics` آهنگ، `groups` رویداد) به‌جای ده‌ها کالکشن کوچک از فیلد `json` استفاده شده تا مهاجرت بدون تغییر UI ممکن باشد. چیزهایی که باید جست‌وجو/فیلتر/شمرده شوند فیلد مستقل با ایندکس دارند.

## ۳. کالکشن‌ها

### ۳.۱ کاربر و احراز هویت

| کالکشن              | توضیح                                                                        | فیلدهای کلیدی                                                                         |
| ------------------- | ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| `users` (auth)      | حساب کاربری، ایمیل/رمز و توکن‌ها را PocketBase مدیریت می‌کند                 | name، avatar                                                                          |
| `profiles`          | پروفایل عمومی و سطح یادگیرنده (از `onboarding/*` و `profile/mockProfile.ts`) | display_name، handle (یکتا)، level، native_language، xp، streak_days، onboarding_done |
| `settings`          | تنظیمات UI و اعلان (از `einstellungen`)                                      | ui_language، theme، rtl، daily_goal_minutes، notification_prefs                       |
| `placement_results` | نتیجه `einstufungstest`                                                      | level، score، skill_scores، answers                                                   |
| `subscriptions`     | وضعیت پلن برای `abonnement` (بدون درگاه پرداخت)                              | plan، status، expires_at                                                              |

### ۳.۲ واژگان

| کالکشن          | توضیح                                                                                                                              | منبع mock                                            |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| `words`         | دیکشنری کامل: معانی، مثال‌ها، خانواده واژه، گرامر مخصوص هر نوع کلمه                                                                | `dictionary/mockWords.ts`، `types.ts`                |
| `user_words`    | رابطه کاربر↔واژه: bookmark، وضعیت (new/learning/known)، درصد تسلط، بازدید، واژه‌های شخصی کاربر (`custom_headword` + `custom_data`) | `dictionary/customWords.ts`، `UserWordState`         |
| `srs_cards`     | کارت تکرار فاصله‌دار: box (1..5)، ease، interval، stability، difficulty، due_at، تاریخچه مرور                                      | `fsrs.ts`، `leitner/*`، `dictionary/leitnerQueue.ts` |
| `proverbs`      | ضرب‌المثل و اصطلاح                                                                                                                 | `dictionary/proverbs.ts`                             |
| `verbs`         | صرف فعل و حروف اضافه وابسته، متصل به `words`                                                                                       | `VerbGrammar`                                        |
| `word_families` | ریشه‌ها و خانواده واژه برای `/verben`                                                                                              | `wordfamilies/*`                                     |

ایندکس‌ها: `words.lemma`، `words.slug` (یکتا)، `words(cefr,pos)`، `user_words(user,word)` یکتا، `srs_cards(user,due_at)` برای صف مرور.

### ۳.۳ گرامر

`grammar_topics` (دسته، نقشه راه در `nodes`) → `grammar_lessons` (بخش‌های درس در `sections`) → `exercises` (نوع تمرین + `data`) و `lesson_progress` برای پیشرفت کاربر. منبع: `mockGrammar.ts`.

### ۳.۴ خواندن و نوشتن

`articles` (پاراگراف‌ها، واژگان، سؤالات، خلاصه AI، نکات گرامری) + `reading_progress` (درصد، موقعیت اسکرول، پاسخ سؤالات) + `writing_submissions` (متن کاربر، وضعیت، بازخورد AI). منبع: `mockReading.ts`.

### ۳.۵ مدیا

`films` (زیرنویس در `cues`)، `artists` + `songs` (متن ترانه، واژگان، waveform)، `podcast_shows` + `episodes` (transcript، vocab، quiz)، `books` (لیست شناسه واژه‌ها).
پیشرفت همه مدیا در یک کالکشن `media_progress` با کلید `(media_type, media_id)` ذخیره می‌شود و واژه‌های ذخیره‌شده از داخل مدیا در `media_vocab` (که در سشن ۵ به `user_words` وصل می‌شود). منبع: `mockKino/mockMusic/mockPodcasts/dictionary/books.ts`، `musicVocab.ts`.

### ۳.۶ آزمون‌ها

`exams` (معرفی، منابع، مراکز، FAQ، برنامه آماده‌سازی) → `exam_sections` (مهارت، زمان، سؤالات) → `exam_attempts` (وضعیت، `deadline_at` برای تایمر مقاوم به رفرش، نمره، سطح نتیجه) → `answers` (پاسخ به تفکیک سؤال، یکتا در هر attempt). منبع: `exams/mockExams.ts`.

### ۳.۷ برنامه‌ریز

`study_plans` (سطح، اهداف، مهارت‌های ضعیف/قوی، دقیقه روزانه، روزهای آزاد، هفته هدف) → `plan_sessions` (تاریخ، ساعت، مهارت، وضعیت planned/done/skipped، `generated`/`edited`) → `session_logs` (لاگ واقعی مطالعه، پایه محاسبه XP). منبع: `planner/*`.

### ۳.۸ کامیونیتی و رویدادها

`posts`/`comments`، `chats` (room/group/dm با `members`) + `messages` + `chat_reads` (شمارش نخوانده)، `tandem_profiles`، `events` + `event_rsvps` (گروه، شماره صندلی، سفارش کافه — یکتا روی `(event, group_id, seat)`)، `reports` و `blocks` برای مدیریت تخلف. منبع: `community/*`، `events/*`.

### ۳.۹ گیمیفیکیشن

`xp_ledger` (هر XP با منبعش)، `achievements` + `user_achievements`، `missions` + `user_missions` (با `period_key` روزانه/هفتگی)، `streaks`، `daily_stats` (یک رکورد در هر روز کاربر، پایه صفحه `statistiken`). همه این‌ها سمت سرور نوشته می‌شوند. منبع: `gamification.ts`، `achievements.ts`، `mockStats.ts`، `mockStudyStats.ts`.

### ۳.۱۰ متعلقات کاربر

`notifications`، `bookmarks` (چندنوعی با `target_type`/`target_id`)، `contact_messages` (فرم `support`).

### ۳.۱۱ هوش مصنوعی

`ai_threads` + `ai_messages` (نوشتن فقط از پروکسی سشن ۱۰) + `ai_usage` (محدودیت نرخ و لاگ مصرف). منبع: `kiCoachHistory.ts`.

## ۴. نگاشت mock → کالکشن

| فایل mock                                                         | کالکشن مقصد                                                                   |
| ----------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `dictionary/mockWords.ts`، `dictionary/categories.ts`             | `words`                                                                       |
| `dictionary/customWords.ts`                                       | `user_words` (custom_headword/custom_data)                                    |
| `dictionary/leitnerQueue.ts`، `leitner/mockLeitner.ts`، `fsrs.ts` | `srs_cards`                                                                   |
| `dictionary/proverbs.ts`                                          | `proverbs`                                                                    |
| `dictionary/books.ts`                                             | `books`                                                                       |
| `wordfamilies/mockFamilies.ts`، `wordfamilies/prefixes.ts`        | `word_families`                                                               |
| `mockGrammar.ts`                                                  | `grammar_topics`، `grammar_lessons`، `exercises`                              |
| `mockReading.ts`                                                  | `articles`                                                                    |
| `mockKino.ts`                                                     | `films`                                                                       |
| `mockMusic.ts`                                                    | `artists`، `songs`                                                            |
| `mockPodcasts.ts`                                                 | `podcast_shows`، `episodes`                                                   |
| `musicVocab.ts`                                                   | `media_vocab` → `user_words`                                                  |
| `exams/mockExams.ts`                                              | `exams`، `exam_sections`                                                      |
| `planner/*`                                                       | `study_plans`، `plan_sessions`، `session_logs`                                |
| `community/mockCommunity.ts`، `community/store.ts`                | `posts`، `chats`، `messages`، `tandem_profiles`                               |
| `events/mockEvents.ts`، `events/store.tsx`                        | `events`، `event_rsvps`                                                       |
| `gamification.ts`، `achievements.ts`                              | `achievements`، `missions`، `xp_ledger`، `user_achievements`، `user_missions` |
| `mockStats.ts`، `mockStudyStats.ts`                               | `daily_stats`، `streaks`                                                      |
| `profile/mockProfile.ts`                                          | `profiles` (+ `user_achievements`، `event_rsvps`)                             |
| `onboarding/*`                                                    | `profiles`، `settings`، `placement_results`                                   |
| `store.tsx`، `interactions.tsx`                                   | `bookmarks`، `user_words`، `notifications`                                    |
| `kiCoachHistory.ts`                                               | `ai_threads`، `ai_messages`                                                   |

## ۵. قدم بعدی

سشن ۲: `src/lib/api/client.ts` روی PocketBase SDK، `MOCK_MODE`، TanStack Query، احراز هویت واقعی و گارد روت‌ها — با استفاده از تایپ‌های `src/lib/api/types.ts` که در همین سشن ساخته شد.
