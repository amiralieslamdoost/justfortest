/**
 * seed آزمون‌ها و بخش‌های Modelltest در PocketBase (سشن ۶).
 *
 * استفاده:
 *   bun backend/seed/seed-exams.ts <pb-url> <superuser-email> <password>
 *   bun backend/seed/seed-exams.ts --json     # فقط خروجی JSON در backend/seed/out/
 *
 * `exams` بر اساس `slug` و `exam_sections` بر اساس (exam, title) upsert می‌شوند،
 * پس اجرای چندباره امن است.
 */
import { mkdir, writeFile } from "node:fs/promises";
import { EXAMS } from "../../src/lib/deusi/exams/mockExams";
import { MODELLTESTS } from "../../src/lib/deusi/exams/mockModelltests";

type Row = Record<string, unknown>;

export const examRows: Row[] = EXAMS.map((e) => ({
  slug: e.id,
  name: e.name,
  short_name: e.shortName,
  description: e.description,
  levels: e.levels,
  purposes: e.purposes,
  comparison: e.comparison,
  resources: e.resources,
  practice_files: e.practice,
  books: e.books,
  centers: e.centers,
  faq: e.faq,
  prep_plan: e.prepPlan,
  accent: e.accent ?? "",
  published: true,
}));

/** بخش‌ها؛ اگر نگاشت شناسهٔ آزمون داده شود، فیلد relation پر می‌شود. */
export function sectionRows(examIds: Record<string, string> = {}): Row[] {
  return MODELLTESTS.flatMap((test) =>
    test.sections.map((s) => ({
      exam: examIds[test.examId] ?? test.examId,
      skill: s.skill,
      title: s.title,
      duration_min: s.durationMin,
      max_points: s.maxPoints,
      questions: s.questions,
      order: s.order,
    })),
  );
}

async function writeJson() {
  const dir = new URL("./out/", import.meta.url);
  await mkdir(dir, { recursive: true });
  const files: Record<string, Row[]> = { exams: examRows, exam_sections: sectionRows() };
  for (const [name, rows] of Object.entries(files)) {
    await writeFile(new URL(`./out/${name}.json`, import.meta.url), JSON.stringify(rows, null, 2));
    console.log(`✔ ${name}.json (${rows.length} رکورد)`);
  }
}

async function seed(url: string, email: string, password: string) {
  const auth = await fetch(`${url}/api/collections/_superusers/auth-with-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identity: email, password }),
  });
  if (!auth.ok) throw new Error(`ورود superuser ناموفق: ${auth.status}`);
  const { token } = (await auth.json()) as { token: string };
  const headers = { Authorization: token, "Content-Type": "application/json" };

  async function findId(collection: string, filter: string): Promise<string | undefined> {
    const res = await fetch(
      `${url}/api/collections/${collection}/records?perPage=1&filter=${encodeURIComponent(filter)}`,
      { headers },
    );
    const json = (await res.json()) as { items?: { id: string }[] };
    return json.items?.[0]?.id;
  }

  async function save(collection: string, row: Row, existing?: string) {
    const res = await fetch(
      existing
        ? `${url}/api/collections/${collection}/records/${existing}`
        : `${url}/api/collections/${collection}/records`,
      { method: existing ? "PATCH" : "POST", headers, body: JSON.stringify(row) },
    );
    if (!res.ok) {
      console.error(`✗ ${collection}: ${res.status} ${await res.text()}`);
      return undefined;
    }
    return ((await res.json()) as { id: string }).id;
  }

  const examIds: Record<string, string> = {};
  for (const row of examRows) {
    const slug = String(row["slug"]);
    const id = await save("exams", row, await findId("exams", `slug="${slug}"`));
    if (id) examIds[slug] = id;
  }
  console.log(`✔ exams: ${Object.keys(examIds).length}/${examRows.length}`);

  let done = 0;
  const rows = sectionRows(examIds);
  for (const row of rows) {
    const existing = await findId(
      "exam_sections",
      `exam="${row["exam"]}" && title="${String(row["title"]).replace(/"/g, "")}"`,
    );
    if (await save("exam_sections", row, existing)) done += 1;
  }
  console.log(`✔ exam_sections: ${done}/${rows.length}`);
}

const [a, b, c] = process.argv.slice(2);
if (a === "--json" || !a) {
  await writeJson();
} else {
  if (!b || !c) {
    console.error("usage: bun backend/seed/seed-exams.ts <pb-url> <email> <password>");
    process.exit(1);
  }
  await seed(a.replace(/\/$/, ""), b, c);
}
