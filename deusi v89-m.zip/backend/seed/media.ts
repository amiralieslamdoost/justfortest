/**
 * ساخت رکوردهای مدیا برای PocketBase از داده‌های ماک (سشن ۵).
 * خروجی: آبجکت‌های آمادهٔ ارسال به کالکشن‌های films / artists / songs /
 * podcast_shows / episodes / books.
 */
import { films } from "../../src/lib/deusi/mockKino";
import { artists, songs } from "../../src/lib/deusi/mockMusic";
import { podcastShows, podcastEpisodes } from "../../src/lib/deusi/mockPodcasts";
import { LEARNING_BOOKS } from "../../src/lib/deusi/dictionary/books";

export const filmRows = films.map((f) => ({
  slug: f.id,
  title: f.title,
  title_fa: f.titleFa,
  year: f.year,
  duration: f.duration,
  level: f.level,
  genre: f.genre,
  director: f.director,
  synopsis: f.synopsis,
  synopsis_fa: f.synopsisFa,
  poster: f.poster,
  video_url: f.videoUrl,
  cues: f.cues,
  published: true,
}));

export const artistRows = artists.map((a) => ({
  slug: a.id,
  name: a.name,
  genre: a.genre,
  bio: a.tagline,
  accent: a.accent,
  photo: a.coverUrl ?? "",
  cover: a.cover,
  country: a.country,
  listeners: a.listeners,
  songs_count: a.songs,
}));

/** رکوردهای آهنگ؛ `artistIds` نقشهٔ slug هنرمند → id پاکت‌بیس. */
export const songRows = (artistIds: Record<string, string> = {}) =>
  songs.map((s) => ({
    slug: s.id,
    title: s.title,
    artist: artistIds[s.artistId] ?? "",
    artist_slug: s.artistId,
    album: s.album,
    year: s.year,
    duration_sec: s.durationSec,
    level: s.level,
    genre: s.genre,
    cover: s.cover,
    cover_image: s.coverUrl ?? "",
    accent: s.accent,
    audio_url: s.audioUrl,
    waveform: s.waveform,
    lyrics: s.lyrics,
    vocab: s.vocab.map((v) => ({ ...v, word: v.term })),
    note_fa: s.noteFa,
    published: true,
  }));

export const showRows = podcastShows.map((sh) => ({
  slug: sh.id,
  title: sh.title,
  publisher: sh.publisher,
  tagline: sh.tagline,
  cover: sh.cover,
  accent: sh.accent,
  level: sh.level,
  category: sh.category,
  episodes_count: sh.episodes,
}));

/** رکوردهای قسمت پادکست؛ `showIds` نقشهٔ slug شو → id پاکت‌بیس. */
export const episodeRows = (showIds: Record<string, string> = {}) =>
  podcastEpisodes.map((e) => ({
    slug: e.id,
    show: showIds[e.showId] ?? "",
    show_slug: e.showId,
    number: e.number,
    title: e.title,
    description: e.description,
    summary: e.summary,
    cover: e.cover,
    accent: e.accent,
    category: e.category,
    level: e.level,
    published_at: e.publishedAt,
    duration_sec: e.durationSec,
    waveform: e.waveform,
    audio_url: "",
    transcript: e.transcript,
    vocab: e.vocab,
    quiz: e.quiz,
    featured: Boolean(e.featured),
    published: true,
  }));

export const bookRows = LEARNING_BOOKS.map((b) => ({
  slug: b.id,
  title: b.title,
  publisher: b.publisher,
  level: b.level,
  cover: b.cover,
  cover_image: b.coverUrl ?? "",
  color: b.color,
  word_count: b.wordCount,
  word_ids: b.wordIds,
  published: true,
}));
