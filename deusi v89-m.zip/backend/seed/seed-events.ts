/**
 * seed رویدادها در PocketBase (تکمیل سشن ۸).
 *
 * استفاده:
 *   bun backend/seed/seed-events.ts <pb-url> <superuser-email> <password>
 *   bun backend/seed/seed-events.ts --json      # فقط خروجی JSON در backend/seed/out/
 *
 * رکوردها بر اساس `slug` upsert می‌شوند، پس اجرای چندباره امن است.
 * کاور تصاویر به‌صورت مسیر asset فرانت ذخیره می‌شود (فیلد متنی `cover`)؛
 * در صورت نیاز می‌توان بعداً فایل واقعی را در `cover_image` آپلود کرد.
 */
import { mkdir, writeFile } from "node:fs/promises";
import { MOCK_EVENTS } from "../../src/lib/deusi/events/mockEvents";

type Row = Record<string, unknown>;

export const eventRows: Row[] = MOCK_EVENTS.map((e) => ({
  slug: e.id,
  institute_id: e.instituteId,
  title: e.title,
  short_description: e.shortDescription,
  description: e.description,
  cover: e.cover,
  organizer: {
    id: e.organizer.id,
    name: e.organizer.name,
    tagline: e.organizer.tagline,
    rating: e.organizer.rating,
    reviews: e.organizer.reviews,
    verified: e.organizer.verified,
  },
  date_label: e.date,
  weekday: e.weekday,
  time_label: e.time,
  duration_label: e.duration,
  location_name: e.locationName,
  location_address: e.locationAddress,
  levels: e.levels,
  level_summary: e.levelSummary,
  bands: e.bands,
  themes_count: e.themesCount,
  groups_count: e.groupsCount,
  seats_per_group: e.seatsPerGroup,
  notes: e.notes,
  groups: e.groups ?? [],
  weekly_topics: e.weekly ?? null,
  price: 0,
  currency: "EUR",
  published: true,
}));

async function writeJson() {
  const dir = new URL("./out/", import.meta.url);
  await mkdir(dir, { recursive: true });
  await writeFile(
    new URL("./out/events.json", import.meta.url),
    JSON.stringify(eventRows, null, 2),
  );
  console.log(`✔ events.json (${eventRows.length} رکورد)`);
}

async function seed(url: string, email: string, password: string) {
  const auth = await fetch(`${url}/api/collections/_superusers/auth-with-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identity: email, password }),
  });
  if (!auth.ok) throw new Error(`ورود superuser ناموفق: ${auth.status}`);
  const { token } = (await auth.json()) as { token: string };
  const headers = { Authorization: token, "Content-Type": "application/json" };

  let ok = 0;
  for (const row of eventRows) {
    const slug = String(row["slug"]);
    const found = (await fetch(
      `${url}/api/collections/events/records?perPage=1&filter=${encodeURIComponent(`slug="${slug}"`)}`,
      { headers },
    ).then((r) => r.json())) as { items?: { id: string }[] };
    const existing = found.items?.[0]?.id;
    const res = await fetch(
      existing
        ? `${url}/api/collections/events/records/${existing}`
        : `${url}/api/collections/events/records`,
      { method: existing ? "PATCH" : "POST", headers, body: JSON.stringify(row) },
    );
    if (!res.ok) {
      console.error(`✗ events/${slug}: ${res.status} ${await res.text()}`);
      continue;
    }
    ok++;
  }
  console.log(`✔ events: ${ok}/${eventRows.length}`);
}

const [a, b, c] = process.argv.slice(2);
if (a === "--json" || !a) {
  await writeJson();
} else {
  if (!b || !c) {
    console.error("usage: bun backend/seed/seed-events.ts <pb-url> <email> <password>");
    process.exit(1);
  }
  await seed(a.replace(/\/$/, ""), b, c);
}
