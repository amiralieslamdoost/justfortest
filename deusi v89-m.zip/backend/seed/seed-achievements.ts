/**
 * seed دستاوردها و مأموریت‌ها در PocketBase (سشن ۹).
 *
 * استفاده:
 *   bun backend/seed/seed-achievements.ts --json                       # فقط JSON
 *   bun backend/seed/seed-achievements.ts <pb-url> <email> <password>  # upsert
 *
 * upsert بر اساس `slug` انجام می‌شود، پس اجرای چندباره امن است.
 * `criteria` معیار سمت سرور است و در `backend/pb_hooks/gamification.pb.js`
 * ارزیابی می‌شود: { metric, target } برای دستاوردها و { event } برای مأموریت‌ها.
 */
import { mkdir, writeFile } from "node:fs/promises";
import { ACHIEVEMENTS } from "../../src/lib/deusi/achievements";
import {
  DAILY_MISSIONS,
  RARITY_BY_ID,
  RARITY_META,
  WEEKLY_MISSIONS,
} from "../../src/lib/deusi/gamification";

type Row = Record<string, unknown>;

const CATEGORY: Record<string, string> = {
  Serie: "streak",
  Wortschatz: "vocabulary",
  Grammatik: "grammar",
  Hören: "listening",
  Lesen: "reading",
  Prüfung: "exam",
  Meilenstein: "special",
};

/** معیار سرور برای هر دستاورد. */
const CRITERIA: Record<string, { metric: string; target: number }> = {
  "streak-14": { metric: "streak", target: 14 },
  "streak-30": { metric: "streak", target: 30 },
  "streak-100": { metric: "streak", target: 100 },
  "words-100": { metric: "words_learned", target: 100 },
  "words-500": { metric: "words_learned", target: 500 },
  "words-1000": { metric: "words_learned", target: 1000 },
  "grammar-pro": { metric: "lessons_done", target: 20 },
  "grammar-cases": { metric: "lessons_done", target: 35 },
  "grammar-master": { metric: "lessons_done", target: 60 },
  "listen-5": { metric: "media_done", target: 5 },
  "listen-song": { metric: "media_done", target: 10 },
  "listen-25": { metric: "media_done", target: 25 },
  "read-first": { metric: "articles_read", target: 1 },
  "read-book": { metric: "articles_read", target: 15 },
  "exam-a2": { metric: "exams", target: 1 },
  "exam-b1": { metric: "exams", target: 3 },
  "xp-1000": { metric: "xp", target: 1000 },
  "xp-5000": { metric: "xp", target: 5000 },
};

export const achievementRows: Row[] = ACHIEVEMENTS.map((a) => {
  const rarity = RARITY_BY_ID[a.id] ?? "common";
  const criteria = CRITERIA[a.id] ?? { metric: "xp", target: 0 };
  return {
    slug: a.id,
    title: a.labelDe,
    title_fa: a.labelFa,
    description: a.sub,
    icon: a.emoji,
    category: CATEGORY[a.category] ?? "special",
    rarity,
    xp_reward: RARITY_META[rarity].xp,
    criteria: { ...criteria, color: a.color, target_label: a.progress?.target },
    hidden: false,
  };
});

/** رویداد سرور برای هر مأموریت (منبع XP). */
const MISSION_EVENT: Record<string, string> = {
  "d-words": "srs",
  "d-leitner": "srs",
  "d-listen": "media",
  "w-grammar": "lesson",
  "w-read": "reading",
  "w-exam": "exam",
};

export const missionRows: Row[] = [
  ...DAILY_MISSIONS.map((m) => ({ ...m, period: "daily" as const })),
  ...WEEKLY_MISSIONS.map((m) => ({ ...m, period: "weekly" as const })),
].map((m) => ({
  slug: m.id,
  title: m.titleDe,
  description: m.titleFa,
  period: m.period,
  target: m.target,
  xp_reward: m.xp,
  criteria: {
    event: MISSION_EVENT[m.id] ?? "srs",
    emoji: m.emoji,
    color: m.color,
    href: m.href,
  },
  active: true,
}));

async function writeJson() {
  const dir = new URL("./out/", import.meta.url);
  await mkdir(dir, { recursive: true });
  await writeFile(
    new URL("./out/achievements.json", import.meta.url),
    JSON.stringify(achievementRows, null, 2),
  );
  await writeFile(
    new URL("./out/missions.json", import.meta.url),
    JSON.stringify(missionRows, null, 2),
  );
  console.log(
    `✔ achievements.json (${achievementRows.length}) · missions.json (${missionRows.length})`,
  );
}

async function upsert(url: string, headers: Record<string, string>, col: string, rows: Row[]) {
  let ok = 0;
  for (const row of rows) {
    const slug = String(row["slug"]);
    const found = (await fetch(
      `${url}/api/collections/${col}/records?perPage=1&filter=${encodeURIComponent(`slug="${slug}"`)}`,
      { headers },
    ).then((r) => r.json())) as { items?: { id: string }[] };
    const existing = found.items?.[0]?.id;
    const res = await fetch(
      existing
        ? `${url}/api/collections/${col}/records/${existing}`
        : `${url}/api/collections/${col}/records`,
      { method: existing ? "PATCH" : "POST", headers, body: JSON.stringify(row) },
    );
    if (!res.ok) {
      console.error(`✗ ${col}/${slug}: ${res.status} ${await res.text()}`);
      continue;
    }
    ok++;
  }
  console.log(`✔ ${col}: ${ok}/${rows.length}`);
}

async function seed(url: string, email: string, password: string) {
  const auth = await fetch(`${url}/api/collections/_superusers/auth-with-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identity: email, password }),
  });
  if (!auth.ok) throw new Error(`ورود superuser ناموفق: ${auth.status}`);
  const { token } = (await auth.json()) as { token: string };
  const headers = { Authorization: token, "Content-Type": "application/json" };
  await upsert(url, headers, "achievements", achievementRows);
  await upsert(url, headers, "missions", missionRows);
}

const [a, b, c] = process.argv.slice(2);
if (a === "--json" || !a) {
  await writeJson();
} else {
  if (!b || !c) {
    console.error("usage: bun backend/seed/seed-achievements.ts <pb-url> <email> <password>");
    process.exit(1);
  }
  await seed(a.replace(/\/$/, ""), b, c);
}
