/**
 * seed مدیا در PocketBase (سشن ۵).
 *
 * استفاده:
 *   bun backend/seed/seed-media.ts <pb-url> <superuser-email> <password>
 *   bun backend/seed/seed-media.ts --json        # فقط خروجی JSON در backend/seed/out/
 *
 * رکوردها بر اساس `slug` upsert می‌شوند، پس اجرای چندباره امن است.
 */
import { mkdir, writeFile } from "node:fs/promises";
import { artistRows, bookRows, episodeRows, filmRows, showRows, songRows } from "./media";

type Row = Record<string, unknown>;

async function writeJson() {
  const dir = new URL("./out/", import.meta.url);
  await mkdir(dir, { recursive: true });
  const files: Record<string, Row[]> = {
    films: filmRows,
    artists: artistRows,
    songs: songRows(),
    podcast_shows: showRows,
    episodes: episodeRows(),
    books: bookRows,
  };
  for (const [name, rows] of Object.entries(files)) {
    await writeFile(new URL(`./out/${name}.json`, import.meta.url), JSON.stringify(rows, null, 2));
    console.log(`✔ ${name}.json (${rows.length} رکورد)`);
  }
}

async function seed(url: string, email: string, password: string) {
  const auth = await fetch(`${url}/api/collections/_superusers/auth-with-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identity: email, password }),
  });
  if (!auth.ok) throw new Error(`ورود superuser ناموفق: ${auth.status}`);
  const { token } = (await auth.json()) as { token: string };
  const headers = { Authorization: token, "Content-Type": "application/json" };

  async function upsert(collection: string, rows: Row[]): Promise<Record<string, string>> {
    const ids: Record<string, string> = {};
    for (const row of rows) {
      const slug = String(row["slug"] ?? "");
      const found = await fetch(
        `${url}/api/collections/${collection}/records?perPage=1&filter=${encodeURIComponent(`slug="${slug}"`)}`,
        { headers },
      ).then((r) => r.json() as Promise<{ items?: { id: string }[] }>);
      const existing = found.items?.[0]?.id;
      const res = await fetch(
        existing
          ? `${url}/api/collections/${collection}/records/${existing}`
          : `${url}/api/collections/${collection}/records`,
        { method: existing ? "PATCH" : "POST", headers, body: JSON.stringify(row) },
      );
      if (!res.ok) {
        console.error(`✗ ${collection}/${slug}: ${res.status} ${await res.text()}`);
        continue;
      }
      const saved = (await res.json()) as { id: string };
      ids[slug] = saved.id;
    }
    console.log(`✔ ${collection}: ${Object.keys(ids).length}/${rows.length}`);
    return ids;
  }

  await upsert("films", filmRows);
  const artistIds = await upsert("artists", artistRows);
  await upsert("songs", songRows(artistIds));
  const showIds = await upsert("podcast_shows", showRows);
  await upsert("episodes", episodeRows(showIds));
  await upsert("books", bookRows);
}

const [a, b, c] = process.argv.slice(2);
if (a === "--json" || !a) {
  await writeJson();
} else {
  if (!b || !c) {
    console.error("usage: bun backend/seed/seed-media.ts <pb-url> <email> <password>");
    process.exit(1);
  }
  await seed(a.replace(/\/$/, ""), b, c);
}
