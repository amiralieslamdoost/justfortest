# راهنمای seed محتوا

ترتیب پیشنهادی اجرای کامل (روی یک PocketBase تازه):

```bash
PB_URL=http://127.0.0.1:8090 PB_ADMIN_EMAIL=<email> PB_ADMIN_PASSWORD=<pass> bun scripts/seed-vocabulary.ts   # سشن ۳
PB_URL=http://127.0.0.1:8090 PB_ADMIN_EMAIL=<email> PB_ADMIN_PASSWORD=<pass> pnpm seed:content                  # سشن ۴
bun backend/seed/seed-media.ts        http://127.0.0.1:8090 <email> <pass>                                     # سشن ۵
bun backend/seed/seed-exams.ts        http://127.0.0.1:8090 <email> <pass>                                     # سشن ۶
bun backend/seed/seed-events.ts       http://127.0.0.1:8090 <email> <pass>                                     # سشن ۸
bun backend/seed/seed-achievements.ts http://127.0.0.1:8090 <email> <pass>                                     # سشن ۹
```

## واژگان (سشن ۳)

`scripts/seed-vocabulary.ts` کالکشن‌های `words`، `verbs`، `proverbs` و `word_families`
را از `src/lib/deusi/dictionary/*` و `src/lib/deusi/wordfamilies/*` پر می‌کند
(upsert بر اساس `slug`/`infinitive`/`de`/`root`).
**مهم:** تا وقتی این اسکریپت اجرا نشود، `srs_cards` نمی‌تواند به رکورد `words` وصل شود و
همگام‌سازی FSRS/Leitner روی سرور ذخیره نمی‌شود (فقط localStorage).

## گرامر و خواندن (سشن ۴)

`backend/seed/seed-content.ts` با runtime Node کالکشن‌های `grammar_topics`، `grammar_lessons`، `exercises` و
`articles` را از `mockGrammar.ts` و `mockReading.ts` منتقل می‌کند (upsert بر اساس `slug`). اجرای استاندارد آن `pnpm seed:content` است.

## مدیا (سشن ۵)

- `media.ts` — تبدیل داده‌های ماک (`mockKino`, `mockMusic`, `mockPodcasts`, `dictionary/books`) به رکوردهای PocketBase.
- `seed-media.ts` — اجرای seed.

```bash
bun backend/seed/seed-media.ts --json                     # فقط خروجی JSON در out/
bun backend/seed/seed-media.ts http://127.0.0.1:8090 admin@example.com pass
```

رکوردها بر اساس `slug` upsert می‌شوند؛ اجرای چندباره داده تکراری نمی‌سازد.
ترتیب: films → artists → songs (relation هنرمند) → podcast_shows → episodes → books.

## آزمون‌ها (سشن ۶)

```bash
bun backend/seed/seed-exams.ts --json                        # فقط خروجی JSON
bun backend/seed/seed-exams.ts http://127.0.0.1:8090 <email> <password>
```

`exams` بر اساس `slug` و `exam_sections` بر اساس (exam, title) upsert می‌شوند؛
اجرای دوباره رکورد تکراری نمی‌سازد. سؤال‌ها از `src/lib/deusi/exams/mockModelltests.ts`
خوانده می‌شوند، پس هر تغییری در بانک سؤال با یک بار اجرا به بک‌اند منتقل می‌شود.
