#!/usr/bin/env bash
# ایمپورت خودکار اسکیمای DEUSI در PocketBase (>= 0.23)
# استفاده: bash backend/import.sh http://127.0.0.1:8090 admin@example.com password
set -euo pipefail

URL="${1:-http://127.0.0.1:8090}"
EMAIL="${2:-}"
PASS="${3:-}"
DIR="$(cd "$(dirname "$0")" && pwd)"

if [ -z "$EMAIL" ] || [ -z "$PASS" ]; then
  echo "usage: bash backend/import.sh <pb-url> <superuser-email> <superuser-password>" >&2
  exit 1
fi

echo "→ ورود superuser به $URL"
TOKEN=$(curl -sf -X POST "$URL/api/collections/_superusers/auth-with-password" \
  -H 'Content-Type: application/json' \
  -d "{\"identity\":\"$EMAIL\",\"password\":\"$PASS\"}" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["token"])')

echo "→ ساخت payload از pb_schema.json"
python3 -c "import json,sys;print(json.dumps({'collections':json.load(open('$DIR/pb_schema.json')),'deleteMissing':True}))" > /tmp/deusi_pb_import.json

echo "→ ایمپورت کالکشن‌ها (deleteMissing=true)"
curl -sf -X PUT "$URL/api/collections/import" \
  -H "Authorization: $TOKEN" -H 'Content-Type: application/json' \
  --data-binary @/tmp/deusi_pb_import.json > /dev/null

COUNT=$(curl -sf "$URL/api/collections?perPage=200" -H "Authorization: $TOKEN" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["totalItems"])')
rm -f /tmp/deusi_pb_import.json
echo "✔ ایمپورت انجام شد. تعداد کالکشن‌ها (شامل سیستمی): $COUNT"
