/// <reference path="../pb_data/types.d.ts" />
/**
 * یکپارچگی نمرهٔ آزمون‌ها سمت سرور (اصلاح ممیزی سشن ۶).
 *
 * کلاینت اجازهٔ نوشتن روی `answers` و `exam_attempts` را دارد (مالکیت خودش)،
 * ولی هیچ‌وقت نباید نمره را خودش تعیین کند. این هوک قبل از ذخیره‌سازی
 * فیلدهای `correct`/`points` و `score`/`max_score`/`result_level` را از روی
 * سؤال‌های واقعی بخش آزمون دوباره محاسبه می‌کند و مقدار ارسالی کلاینت را
 * بازنویسی می‌کند.
 */

var LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"];

function normalize(v) {
  return String(v)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[.,;:!?"']/g, "");
}

function isManual(q) {
  return (
    q && (q.kind === "free" || q.kind === "writing" || q.kind === "speaking" || q.manual === true)
  );
}

function sameSet(a, b) {
  if (a.length !== b.length) return false;
  var x = a.slice().sort();
  var y = b.slice().sort();
  for (var i = 0; i < x.length; i++) if (x[i] !== y[i]) return false;
  return true;
}

/** همان منطق `src/lib/deusi/examScoring.ts` ولی سمت سرور. */
function gradeAnswer(q, value) {
  if (!q) return { correct: false, points: 0, manual: false };
  if (isManual(q)) return { correct: false, points: 0, manual: true };
  if (value === undefined || value === null || value === "") {
    return { correct: false, points: 0, manual: false };
  }
  var pts = Number(q.points || 0);
  switch (q.kind) {
    case "single":
      var okS = String(value) === String(q.correct);
      return { correct: okS, points: okS ? pts : 0, manual: false };
    case "truefalse":
      var okT = Boolean(value) === Boolean(q.correct);
      return { correct: okT, points: okT ? pts : 0, manual: false };
    case "gap":
      var given = normalize(value);
      var accepted = q.accepted || [];
      for (var i = 0; i < accepted.length; i++) {
        if (normalize(accepted[i]) === given) return { correct: true, points: pts, manual: false };
      }
      return { correct: false, points: 0, manual: false };
    case "multi":
      var arr = Object.prototype.toString.call(value) === "[object Array]" ? value.map(String) : [];
      var corr = (q.correct || []).map(String);
      if (sameSet(arr, corr)) return { correct: true, points: pts, manual: false };
      var hits = 0;
      for (var j = 0; j < arr.length; j++) if (corr.indexOf(arr[j]) >= 0) hits++;
      var misses = arr.length - hits;
      var ratio = Math.max(0, (hits - misses) / (corr.length || 1));
      return { correct: false, points: Math.round(pts * ratio * 100) / 100, manual: false };
    case "matching":
      var g = value || {};
      var keys = Object.keys(q.correct || {});
      var hit = 0;
      for (var k = 0; k < keys.length; k++) if (g[keys[k]] === q.correct[keys[k]]) hit++;
      return {
        correct: keys.length > 0 && hit === keys.length,
        points: keys.length ? Math.round(((pts * hit) / keys.length) * 100) / 100 : 0,
        manual: false,
      };
    default:
      return { correct: false, points: 0, manual: false };
  }
}

function sectionQuestions(sectionId) {
  if (!sectionId) return [];
  try {
    var sec = $app.findRecordById("exam_sections", sectionId);
    var raw = sec.get("questions");
    var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (!parsed) return [];
    if (Object.prototype.toString.call(parsed) === "[object Array]") return parsed;
    return parsed.questions || [];
  } catch (err) {
    $app.logger().warn("exam section load failed", "error", String(err));
    return [];
  }
}

function findQuestion(questions, id) {
  for (var i = 0; i < questions.length; i++) {
    if (String(questions[i].id) === String(id)) return questions[i];
  }
  return null;
}

function jsonValue(record, field) {
  var raw = record.get(field);
  if (typeof raw === "string") {
    try {
      return JSON.parse(raw);
    } catch (err) {
      return raw;
    }
  }
  return raw;
}

/** نمره‌دهی مجدد یک پاسخ قبل از ذخیره. */
function regradeAnswer(e) {
  try {
    var attemptId = e.record.getString("attempt");
    if (!attemptId) {
      e.next();
      return;
    }
    var attempt = $app.findRecordById("exam_attempts", attemptId);
    // مالکیت: کاربر فقط روی تلاش خودش پاسخ ثبت می‌کند.
    if (e.auth && attempt.getString("user") !== e.auth.id) {
      throw new BadRequestError("Kein Zugriff auf diesen Versuch.");
    }
    e.record.set("user", attempt.getString("user"));
    var questions = sectionQuestions(attempt.getString("section"));
    var q = findQuestion(questions, e.record.getString("question_id"));
    if (q) {
      var graded = gradeAnswer(q, jsonValue(e.record, "value"));
      e.record.set("correct", graded.correct);
      // سؤال‌های پاسخ‌آزاد نمرهٔ خودارزیابی دارند؛ کران بالا سقف سؤال است.
      if (graded.manual) {
        var given = Number(e.record.getFloat("points") || 0);
        e.record.set("points", Math.max(0, Math.min(Number(q.points || 0), given)));
      } else {
        e.record.set("points", graded.points);
      }
    } else {
      e.record.set("correct", false);
      e.record.set("points", 0);
    }
  } catch (err) {
    $app.logger().warn("answer regrade failed", "error", String(err));
    e.record.set("correct", false);
    e.record.set("points", 0);
  }
  e.next();
}

onRecordCreateRequest(regradeAnswer, "answers");
onRecordUpdateRequest(regradeAnswer, "answers");

/** نمرهٔ تلاش همیشه از جمع نمرهٔ پاسخ‌های ذخیره‌شده محاسبه می‌شود. */
function recomputeAttempt(e) {
  try {
    var status = e.record.getString("status");
    var questions = sectionQuestions(e.record.getString("section"));
    var maxScore = 0;
    for (var i = 0; i < questions.length; i++) maxScore += Number(questions[i].points || 0);
    e.record.set("max_score", maxScore);

    if (status === "submitted" || status === "scored") {
      var answers = $app.findRecordsByFilter("answers", "attempt = {:a}", "", 500, 0, {
        a: e.record.id,
      });
      var score = 0;
      for (var j = 0; j < answers.length; j++) score += Number(answers[j].getFloat("points") || 0);
      score = Math.round(score * 100) / 100;
      e.record.set("score", score);

      var percent =
        maxScore > 0 ? Math.max(0, Math.min(100, Math.round((score / maxScore) * 100))) : 0;
      var target = e.record.getString("result_level") || "B1";
      var idx = LEVELS.indexOf(target);
      if (idx < 0) idx = 2;
      var offset = percent >= 90 ? 1 : percent >= 70 ? 0 : percent >= 50 ? -1 : -2;
      e.record.set("result_level", LEVELS[Math.max(0, Math.min(LEVELS.length - 1, idx + offset))]);
    } else {
      // تا وقتی تلاش باز است هیچ نمره‌ای پذیرفته نمی‌شود.
      e.record.set("score", 0);
    }
  } catch (err) {
    $app.logger().warn("attempt recompute failed", "error", String(err));
  }
  e.next();
}

onRecordCreateRequest(recomputeAttempt, "exam_attempts");
onRecordUpdateRequest(recomputeAttempt, "exam_attempts");
