/// <reference path="../pb_data/types.d.ts" />
/**
 * گیمیفیکیشن سمت سرور (سشن ۹).
 *
 * قاعدهٔ اصلی: XP، استریک، آمار روزانه، پیشرفت مأموریت‌ها و دستاوردها
 * فقط اینجا نوشته می‌شوند. کالکشن‌های `xp_ledger`، `streaks`، `daily_stats`،
 * `user_missions` و `user_achievements` قاعدهٔ create/update برای کلاینت
 * ندارند، پس کلاینت نمی‌تواند XP جعل کند.
 *
 * منابع رویداد:
 *   - srs_cards            → مرور کارت (srs)
 *   - lesson_progress      → تکمیل درس گرامر (lesson)
 *   - reading_progress     → خواندن مقاله (reading)
 *   - media_progress       → دیدن/شنیدن رسانه (media)
 *   - exam_attempts        → پایان آزمون (exam)
 *   - session_logs         → جلسهٔ برنامه‌ریزی‌شده (planner)
 *   - posts / messages     → فعالیت جامعه (community)
 */

var XP = {
  srs: 2,
  lesson: 30,
  reading: 20,
  media: 15,
  exam: 80,
  planner: 25,
  community: 5,
};

function todayKey() {
  return new Date().toISOString().substring(0, 10);
}

function dayDiff(a, b) {
  var ms = new Date(b + "T00:00:00Z").getTime() - new Date(a + "T00:00:00Z").getTime();
  return Math.round(ms / 86400000);
}

/** افزودن XP به دفتر و به‌روزرسانی پروفایل. */
function addXp(userId, amount, source, sourceId, note) {
  if (!userId || !amount) return;
  try {
    var col = $app.findCollectionByNameOrId("xp_ledger");
    var rec = new Record(col, {
      user: userId,
      amount: amount,
      source: source,
      source_id: sourceId || "",
      note: note || "",
      earned_at: new Date().toISOString(),
    });
    $app.save(rec);
    bumpProfileXp(userId, amount);
    bumpDailyStats(userId, { xp: amount });
  } catch (err) {
    $app.logger().warn("addXp failed", "error", String(err));
  }
}

function xpForLevel(level) {
  return 250 * (level - 1) * level;
}

function levelFromXp(xp) {
  var lvl = 1;
  while (xpForLevel(lvl + 1) <= xp) lvl++;
  return lvl;
}

function findProfile(userId) {
  try {
    return $app.findFirstRecordByFilter("profiles", "user = {:u}", { u: userId });
  } catch (err) {
    return null;
  }
}

function bumpProfileXp(userId, amount) {
  var p = findProfile(userId);
  if (!p) return;
  var xp = p.getInt("xp") + amount;
  p.set("xp", xp);
  p.set("level_number", levelFromXp(xp));
  p.set("last_study_at", new Date().toISOString());
  $app.save(p);
}

/** upsert در `daily_stats` برای امروز. */
function bumpDailyStats(userId, patch) {
  try {
    var day = todayKey();
    var rec;
    try {
      rec = $app.findFirstRecordByFilter("daily_stats", "user = {:u} && day = {:d}", {
        u: userId,
        d: day,
      });
    } catch (err) {
      var col = $app.findCollectionByNameOrId("daily_stats");
      rec = new Record(col, { user: userId, day: day, skill_minutes: {} });
    }
    Object.keys(patch).forEach(function (key) {
      if (key === "skill") return;
      rec.set(key, rec.getInt(key) + patch[key]);
    });
    if (patch.skill && patch.minutes) {
      var skills = rec.get("skill_minutes") || {};
      skills[patch.skill] = (skills[patch.skill] || 0) + patch.minutes;
      rec.set("skill_minutes", skills);
    }
    $app.save(rec);
  } catch (err) {
    $app.logger().warn("bumpDailyStats failed", "error", String(err));
  }
}

/** به‌روزرسانی استریک روی اولین فعالیت هر روز. */
function touchStreak(userId) {
  try {
    var day = todayKey();
    var rec;
    try {
      rec = $app.findFirstRecordByFilter("streaks", "user = {:u}", { u: userId });
    } catch (err) {
      var col = $app.findCollectionByNameOrId("streaks");
      rec = new Record(col, {
        user: userId,
        current: 0,
        longest: 0,
        freezes_left: 2,
        week_map: [false, false, false, false, false, false, false],
      });
    }
    var last = rec.getString("last_active_day");
    if (last) last = last.substring(0, 10);
    if (last === day) return;

    var current = rec.getInt("current");
    current = last && dayDiff(last, day) === 1 ? current + 1 : 1;
    var longest = Math.max(rec.getInt("longest"), current);

    var map = rec.get("week_map") || [false, false, false, false, false, false, false];
    var idx = (new Date().getDay() + 6) % 7;
    map[idx] = true;
    if (idx === 0) map = [true, false, false, false, false, false, false];

    rec.set("current", current);
    rec.set("longest", longest);
    rec.set("last_active_day", day);
    rec.set("week_map", map);
    $app.save(rec);

    var p = findProfile(userId);
    if (p) {
      p.set("streak_days", current);
      p.set("longest_streak", longest);
      $app.save(p);
    }
    if (current > 1) addXp(userId, 10 + Math.min(current, 30), "streak", day, "Streak " + current);
    checkAchievements(userId);
  } catch (err) {
    $app.logger().warn("touchStreak failed", "error", String(err));
  }
}

/** پیشرفت مأموریت‌های فعال با معیار `event`. */
function bumpMissions(userId, event, amount) {
  try {
    var missions = $app.findRecordsByFilter("missions", "active = true", "", 200, 0);
    missions.forEach(function (m) {
      var criteria = m.get("criteria") || {};
      if (criteria.event !== event) return;
      var period = m.getString("period");
      var key = periodKey(period);
      var rec;
      try {
        rec = $app.findFirstRecordByFilter(
          "user_missions",
          "user = {:u} && mission = {:m} && period_key = {:k}",
          { u: userId, m: m.id, k: key },
        );
      } catch (err) {
        var col = $app.findCollectionByNameOrId("user_missions");
        rec = new Record(col, { user: userId, mission: m.id, period_key: key, progress: 0 });
      }
      if (rec.getBool("completed")) return;
      var progress = rec.getInt("progress") + amount;
      rec.set("progress", progress);
      var target = m.getInt("target") || 1;
      if (progress >= target) {
        rec.set("completed", true);
        rec.set("completed_at", new Date().toISOString());
      }
      $app.save(rec);
      if (progress >= target) {
        addXp(userId, m.getInt("xp_reward"), "mission", m.id, m.getString("title"));
        notifyUser(
          userId,
          "achievement",
          "Mission erledigt",
          m.getString("title"),
          "/achievements",
        );
      }
    });
  } catch (err) {
    $app.logger().warn("bumpMissions failed", "error", String(err));
  }
}

function periodKey(period) {
  var now = new Date();
  if (period === "daily") return todayKey();
  if (period === "weekly") {
    var d = new Date(now.getTime());
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    return "w" + d.toISOString().substring(0, 10);
  }
  return "s" + now.getFullYear();
}

function notifyUser(userId, kind, title, body, href) {
  try {
    var col = $app.findCollectionByNameOrId("notifications");
    $app.save(
      new Record(col, {
        user: userId,
        kind: kind,
        title: title,
        body: body,
        href: href || "",
        read: false,
      }),
    );
  } catch (err) {
    $app.logger().warn("notifyUser failed", "error", String(err));
  }
}

/**
 * بررسی دستاوردها بر اساس `criteria` کاتالوگ.
 * criteria = { metric: "streak"|"xp"|"words_learned"|"lessons_done"|"articles_read"|"exams", target: n }
 */
function metricValue(userId, metric) {
  try {
    if (metric === "streak") {
      var s = $app.findFirstRecordByFilter("streaks", "user = {:u}", { u: userId });
      return s.getInt("current");
    }
    if (metric === "xp") {
      var p = findProfile(userId);
      return p ? p.getInt("xp") : 0;
    }
    if (metric === "words_learned") {
      return $app.countRecords("user_words", $dbx.exp("user = {:u}", { u: userId }));
    }
    if (metric === "lessons_done") {
      return $app.countRecords(
        "lesson_progress",
        $dbx.exp("user = {:u} AND status = 'done'", { u: userId }),
      );
    }
    if (metric === "articles_read") {
      return $app.countRecords(
        "reading_progress",
        $dbx.exp("user = {:u} AND finished = true", { u: userId }),
      );
    }
    if (metric === "media_done") {
      return $app.countRecords(
        "media_progress",
        $dbx.exp("user = {:u} AND finished = true", { u: userId }),
      );
    }
    if (metric === "exams") {
      return $app.countRecords(
        "exam_attempts",
        $dbx.exp("user = {:u} AND status IN ('submitted','scored')", { u: userId }),
      );
    }
  } catch (err) {
    return 0;
  }
  return 0;
}

function checkAchievements(userId) {
  try {
    var all = $app.findRecordsByFilter("achievements", "id != ''", "", 500, 0);
    all.forEach(function (a) {
      var criteria = a.get("criteria") || {};
      if (!criteria.metric || !criteria.target) return;
      var value = metricValue(userId, criteria.metric);
      var rec;
      try {
        rec = $app.findFirstRecordByFilter(
          "user_achievements",
          "user = {:u} && achievement = {:a}",
          { u: userId, a: a.id },
        );
      } catch (err) {
        var col = $app.findCollectionByNameOrId("user_achievements");
        rec = new Record(col, { user: userId, achievement: a.id, progress: 0, unlocked: false });
      }
      if (rec.getBool("unlocked")) return;
      rec.set("progress", value);
      if (value >= criteria.target) {
        rec.set("unlocked", true);
        rec.set("unlocked_at", new Date().toISOString());
      }
      $app.save(rec);
      if (value >= criteria.target) {
        addXp(userId, a.getInt("xp_reward"), "achievement", a.id, a.getString("title"));
        notifyUser(
          userId,
          "achievement",
          "Neuer Erfolg: " + a.getString("title"),
          a.getString("description"),
          "/achievements",
        );
      }
    });
  } catch (err) {
    $app.logger().warn("checkAchievements failed", "error", String(err));
  }
}

/**
 * محافظت در برابر جعل XP (اصلاح ممیزی سشن ۹):
 * پاداش هر رکورد فقط یک‌بار داده می‌شود؛ PATCH تکراری روی همان رکورد
 * دیگر XP جدید تولید نمی‌کند.
 */
function alreadyRewarded(source, sourceId) {
  if (!sourceId) return false;
  try {
    $app.findFirstRecordByFilter("xp_ledger", "source = {:s} && source_id = {:i}", {
      s: source,
      i: sourceId,
    });
    return true;
  } catch (err) {
    return false; // رکوردی پیدا نشد
  }
}

/** آیا مقدار عددی یک فیلد نسبت به نسخهٔ قبلی رکورد افزایش یافته است؟ */
function intIncreased(e, field) {
  try {
    var original = e.record.original();
    var before = original ? original.getInt(field) : 0;
    return e.record.getInt(field) > before;
  } catch (err) {
    return true;
  }
}

/** آیا یک فیلد بولی تازه true شده است (گذار false → true)؟ */
function becameTrue(e, field) {
  try {
    var original = e.record.original();
    if (original && original.getBool(field)) return false;
  } catch (err) {
    /* در صورت نبود نسخهٔ قبلی، مقدار فعلی ملاک است */
  }
  return e.record.getBool(field);
}

/** آیا فیلد انتخابی تازه وارد یکی از وضعیت‌های هدف شده است؟ */
function enteredStatus(e, field, targets) {
  var now = e.record.getString(field);
  if (targets.indexOf(now) < 0) return false;
  try {
    var original = e.record.original();
    if (original && targets.indexOf(original.getString(field)) >= 0) return false;
  } catch (err) {
    /* بدون نسخهٔ قبلی: گذار در نظر گرفته می‌شود */
  }
  return true;
}

function reward(userId, source, sourceId, note, extra) {
  if (!userId) return;
  touchStreak(userId);
  addXp(userId, XP[source] || 0, source, sourceId, note);
  if (extra) bumpDailyStats(userId, extra);
  bumpMissions(userId, source, 1);
  checkAchievements(userId);
}

/* ----------------------------- رویدادها ------------------------------- */

// مرور کارت لایتنر/SRS
onRecordAfterUpdateSuccess((e) => {
  try {
    var reps = e.record.getInt("reps");
    // فقط وقتی واقعاً یک مرور تازه ثبت شده (reps افزایش یافته).
    if (reps > 0 && intIncreased(e, "reps")) {
      reward(e.record.getString("user"), "srs", e.record.id, "SRS-Review", {
        words_reviewed: 1,
        minutes: 1,
        skill: "leitner",
      });
    }
  } catch (err) {
    $app.logger().warn("srs xp failed", "error", String(err));
  }
  e.next();
}, "srs_cards");

// واژهٔ جدید در واژه‌نامهٔ کاربر
onRecordAfterCreateSuccess((e) => {
  try {
    reward(e.record.getString("user"), "srs", e.record.id, "Neues Wort", {
      words_learned: 1,
      minutes: 2,
      skill: "dictionary",
    });
  } catch (err) {
    $app.logger().warn("word xp failed", "error", String(err));
  }
  e.next();
}, "user_words");

// تکمیل درس گرامر
onRecordAfterUpdateSuccess((e) => {
  try {
    if (enteredStatus(e, "status", ["done"]) && !alreadyRewarded("lesson", e.record.id)) {
      reward(e.record.getString("user"), "lesson", e.record.id, "Grammatik-Lektion", {
        lessons_done: 1,
        minutes: 15,
        skill: "grammar",
      });
    }
  } catch (err) {
    $app.logger().warn("lesson xp failed", "error", String(err));
  }
  e.next();
}, "lesson_progress");

// خواندن مقاله
onRecordAfterUpdateSuccess((e) => {
  try {
    if (becameTrue(e, "finished") && !alreadyRewarded("reading", e.record.id)) {
      reward(e.record.getString("user"), "reading", e.record.id, "Artikel gelesen", {
        articles_read: 1,
        minutes: 10,
        skill: "reading",
      });
    }
  } catch (err) {
    $app.logger().warn("reading xp failed", "error", String(err));
  }
  e.next();
}, "reading_progress");

// پیشرفت رسانه
onRecordAfterUpdateSuccess((e) => {
  try {
    if (becameTrue(e, "finished") && !alreadyRewarded("media", e.record.id)) {
      reward(e.record.getString("user"), "media", e.record.id, "Medien abgeschlossen", {
        media_minutes: 20,
        minutes: 20,
        skill: "movies",
      });
    }
  } catch (err) {
    $app.logger().warn("media xp failed", "error", String(err));
  }
  e.next();
}, "media_progress");

// پایان آزمون
onRecordAfterUpdateSuccess((e) => {
  try {
    if (
      enteredStatus(e, "status", ["submitted", "scored"]) &&
      !alreadyRewarded("exam", e.record.id)
    ) {
      reward(e.record.getString("user"), "exam", e.record.id, "Prüfung beendet", {
        minutes: 45,
        skill: "exams",
      });
    }
  } catch (err) {
    $app.logger().warn("exam xp failed", "error", String(err));
  }
  e.next();
}, "exam_attempts");

// جلسهٔ برنامه‌ریزی‌شده
onRecordAfterCreateSuccess((e) => {
  try {
    // سقف منطقی برای جلوگیری از تورم آمار با مقادیر ساختگی.
    var minutes = Math.max(1, Math.min(240, e.record.getInt("minutes") || 25));
    reward(e.record.getString("user"), "planner", e.record.id, "Lernsession", {
      minutes: minutes,
      skill: e.record.getString("skill") || "dictionary",
    });
  } catch (err) {
    $app.logger().warn("planner xp failed", "error", String(err));
  }
  e.next();
}, "session_logs");

// فعالیت جامعه (پست)
onRecordAfterCreateSuccess((e) => {
  try {
    reward(e.record.getString("author"), "community", e.record.id, "Community-Beitrag", null);
  } catch (err) {
    $app.logger().warn("community xp failed", "error", String(err));
  }
  e.next();
}, "posts");
