/// <reference path="../pb_data/types.d.ts" />
/**
 * اعلان‌های خودکار جامعه و رویدادها (سشن ۸).
 *
 * پیام خصوصی جدید، دعوت به گروه و تأیید رزرو رویداد یک رکورد در
 * `notifications` می‌سازند تا در همهٔ دستگاه‌ها (realtime) دیده شود.
 */

function notify(userId, kind, title, body, href) {
  try {
    const col = $app.findCollectionByNameOrId("notifications");
    const rec = new Record(col, {
      user: userId,
      kind: kind,
      title: title,
      body: body,
      href: href || "",
      read: false,
    });
    $app.save(rec);
  } catch (err) {
    $app.logger().warn("notification failed", "error", String(err));
  }
}

// پیام خصوصی جدید
onRecordAfterCreateSuccess((e) => {
  try {
    const chat = $app.findRecordById("chats", e.record.getString("chat"));
    if (chat.getString("kind") !== "dm") {
      e.next();
      return;
    }
    const author = e.record.getString("author");
    const members = chat.get("members") || [];
    const preview = e.record.getString("body").substring(0, 80);
    members.forEach((memberId) => {
      if (memberId === author) return;
      notify(memberId, "community", "Neue Nachricht", preview, "/community/chat/" + chat.id);
    });
  } catch (err) {
    $app.logger().warn("dm notification failed", "error", String(err));
  }
  e.next();
}, "messages");

// تأیید رزرو رویداد
onRecordAfterCreateSuccess((e) => {
  try {
    notify(
      e.record.getString("user"),
      "event",
      "Anmeldung bestätigt",
      "Platz " + e.record.getInt("seat") + " · Gruppe " + e.record.getString("group_id"),
      "/events/" + e.record.getString("event"),
    );
  } catch (err) {
    $app.logger().warn("event notification failed", "error", String(err));
  }
  e.next();
}, "event_rsvps");
