/// <reference path="../pb_data/types.d.ts" />
/**
 * مدیریت محتوا سمت سرور (سشن ۸).
 *
 * - فیلتر واژگان توهین‌آمیز روی پیام‌ها، کامنت‌ها و آگهی‌های تاندم
 * - محدودیت نرخ ارسال پیام (anti-spam)
 * - احترام به بلاک: ارسال پیام خصوصی به کسی که تو را بلاک کرده ممنوع است
 * - بستن خودکار محتوا وقتی تعداد گزارش‌ها از حد می‌گذرد
 */

const BANNED = [
  "arschloch",
  "hurensohn",
  "wichser",
  "fotze",
  "missgeburt",
  "schlampe",
  "fuck",
  "bitch",
  "کصکش",
  "جنده",
  "کیری",
];

/** حداکثر پیام در بازهٔ زمانی. */
const RATE_LIMIT_MESSAGES = 20;
const RATE_LIMIT_WINDOW_SEC = 60;

/** بعد از این تعداد گزارش، محتوا خودکار پنهان می‌شود. */
const AUTO_HIDE_REPORTS = 3;

function containsBanned(text) {
  if (!text) return false;
  const lower = String(text).toLowerCase();
  return BANNED.some((word) => lower.indexOf(word) !== -1);
}

function maskBanned(text) {
  let out = String(text || "");
  BANNED.forEach((word) => {
    const re = new RegExp(word, "gi");
    out = out.replace(re, "*".repeat(word.length));
  });
  return out;
}

// ---------------------------------------------------------------------------
// پیام‌های چت
// ---------------------------------------------------------------------------
onRecordCreateRequest((e) => {
  const auth = e.auth;
  if (!auth) throw new ForbiddenError("Anmeldung erforderlich.");

  e.record.set("author", auth.id);
  e.record.set("deleted", false);

  const body = e.record.getString("body");
  if (body.length > 2000) throw new BadRequestError("Nachricht ist zu lang (max. 2000 Zeichen).");
  if (containsBanned(body)) e.record.set("body", maskBanned(body));

  // rate limit
  const since = new Date(Date.now() - RATE_LIMIT_WINDOW_SEC * 1000).toISOString().replace("T", " ");
  const recent = $app.countRecords(
    "messages",
    $dbx.exp("author = {:a} AND created > {:t}", { a: auth.id, t: since }),
  );
  if (recent >= RATE_LIMIT_MESSAGES) {
    throw new TooManyRequestsError("Zu viele Nachrichten. Bitte kurz warten.");
  }

  // چت باید وجود داشته باشد و کاربر عضو آن باشد (به‌جز اتاق‌های عمومی)
  const chat = $app.findRecordById("chats", e.record.getString("chat"));
  const members = chat.get("members") || [];
  const isMember = members.indexOf(auth.id) !== -1;
  if (chat.getString("kind") !== "room" && !isMember) {
    throw new ForbiddenError("Kein Zugriff auf diesen Chat.");
  }

  // بلاک: گیرندهٔ چت خصوصی نباید فرستنده را بلاک کرده باشد
  if (chat.getString("kind") === "dm") {
    members.forEach((memberId) => {
      if (memberId === auth.id) return;
      const blocks = $app.countRecords(
        "blocks",
        $dbx.exp("user = {:u} AND blocked_user = {:b}", { u: memberId, b: auth.id }),
      );
      if (blocks > 0) throw new ForbiddenError("Diese Person hat dich blockiert.");
    });
  }

  e.next();

  // شمارندهٔ خوانده‌نشده برای بقیهٔ اعضا
  try {
    chat.set("last_message_at", new Date().toISOString());
    $app.save(chat);
    members.forEach((memberId) => {
      if (memberId === auth.id) return;
      let read;
      try {
        read = $app.findFirstRecordByFilter("chat_reads", "user = {:u} && chat = {:c}", {
          u: memberId,
          c: chat.id,
        });
      } catch (_) {
        read = null;
      }
      if (read) {
        read.set("unread", read.getInt("unread") + 1);
        $app.save(read);
      } else {
        const col = $app.findCollectionByNameOrId("chat_reads");
        const rec = new Record(col, { user: memberId, chat: chat.id, unread: 1 });
        $app.save(rec);
      }
    });
  } catch (err) {
    $app.logger().warn("chat bookkeeping failed", "error", String(err));
  }
}, "messages");

// ویرایش پیام: فقط نویسنده، فقط پاک‌کردن نرم
onRecordUpdateRequest((e) => {
  const auth = e.auth;
  if (!auth) throw new ForbiddenError("Anmeldung erforderlich.");
  if (e.record.getString("author") !== auth.id) {
    throw new ForbiddenError("Nur der Autor darf die Nachricht ändern.");
  }
  const body = e.record.getString("body");
  if (containsBanned(body)) e.record.set("body", maskBanned(body));
  e.next();
}, "messages");

// ---------------------------------------------------------------------------
// آگهی‌های تاندم
// ---------------------------------------------------------------------------
onRecordCreateRequest((e) => {
  const auth = e.auth;
  if (!auth) throw new ForbiddenError("Anmeldung erforderlich.");
  e.record.set("user", auth.id);

  ["headline", "description", "goal", "availability"].forEach((field) => {
    const value = e.record.getString(field);
    if (containsBanned(value)) e.record.set(field, maskBanned(value));
  });

  const active = $app.countRecords(
    "tandem_profiles",
    $dbx.exp("user = {:u} AND active = true", { u: auth.id }),
  );
  if (active >= 3) throw new BadRequestError("Maximal drei aktive Anzeigen pro Person.");

  e.next();
}, "tandem_profiles");

// ---------------------------------------------------------------------------
// گزارش‌ها
// ---------------------------------------------------------------------------
onRecordCreateRequest((e) => {
  const auth = e.auth;
  if (!auth) throw new ForbiddenError("Anmeldung erforderlich.");
  e.record.set("reporter", auth.id);
  e.record.set("status", "open");

  const targetId = e.record.getString("target_id");
  const targetType = e.record.getString("target_type");

  const duplicate = $app.countRecords(
    "reports",
    $dbx.exp("reporter = {:r} AND target_id = {:t}", { r: auth.id, t: targetId }),
  );
  if (duplicate > 0) throw new BadRequestError("Du hast diesen Inhalt bereits gemeldet.");

  e.next();

  // پنهان‌سازی خودکار پس از چند گزارش مستقل
  try {
    const total = $app.countRecords("reports", $dbx.exp("target_id = {:t}", { t: targetId }));
    if (total < AUTO_HIDE_REPORTS) return;
    if (targetType === "message") {
      const msg = $app.findRecordById("messages", targetId);
      msg.set("deleted", true);
      msg.set("body", "");
      $app.save(msg);
    } else if (targetType === "tandem_profile") {
      const ad = $app.findRecordById("tandem_profiles", targetId);
      ad.set("active", false);
      $app.save(ad);
    } else if (targetType === "comment") {
      const comment = $app.findRecordById("comments", targetId);
      comment.set("hidden", true);
      $app.save(comment);
    }
  } catch (err) {
    $app.logger().warn("auto-moderation failed", "error", String(err));
  }
}, "reports");

// ---------------------------------------------------------------------------
// بلاک کردن
// ---------------------------------------------------------------------------
onRecordCreateRequest((e) => {
  const auth = e.auth;
  if (!auth) throw new ForbiddenError("Anmeldung erforderlich.");
  e.record.set("user", auth.id);
  if (e.record.getString("blocked_user") === auth.id) {
    throw new BadRequestError("Du kannst dich nicht selbst blockieren.");
  }
  e.next();
}, "blocks");
