/// <reference path="../pb_data/types.d.ts" />
/**
 * رزرو صندلی رویدادها (سشن ۸).
 *
 * - جلوگیری از رزرو دوبل یک صندلی (شرط یکتایی سمت سرور)
 * - هر کاربر فقط یک صندلی فعال در هر رویداد
 * - فقط صاحب رزرو می‌تواند سفارش/لغو را تغییر دهد
 */

onRecordCreateRequest((e) => {
  const auth = e.auth;
  if (!auth) throw new ForbiddenError("Anmeldung erforderlich.");

  e.record.set("user", auth.id);
  e.record.set("status", "reserved");
  e.record.set("reserved_at", new Date().toISOString());

  const eventId = e.record.getString("event");
  const groupId = e.record.getString("group_id");
  const seat = e.record.getInt("seat");

  const taken = $app.countRecords(
    "event_rsvps",
    $dbx.exp("event = {:e} AND group_id = {:g} AND seat = {:s} AND status != 'canceled'", {
      e: eventId,
      g: groupId,
      s: seat,
    }),
  );
  if (taken > 0) throw new BadRequestError("Dieser Platz ist bereits vergeben.");

  const mine = $app.countRecords(
    "event_rsvps",
    $dbx.exp("event = {:e} AND user = {:u} AND status != 'canceled'", { e: eventId, u: auth.id }),
  );
  if (mine > 0) throw new BadRequestError("Du bist für dieses Event bereits angemeldet.");

  e.next();
}, "event_rsvps");

onRecordUpdateRequest((e) => {
  const auth = e.auth;
  if (!auth) throw new ForbiddenError("Anmeldung erforderlich.");
  if (e.record.getString("user") !== auth.id) {
    throw new ForbiddenError("Nur die eigene Anmeldung darf geändert werden.");
  }
  e.next();
}, "event_rsvps");
