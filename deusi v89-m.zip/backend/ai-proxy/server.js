/**
 * DEUSI AI-Proxy (سشن ۱۰)
 * ---------------------------------------------------------------------------
 * سرویس Node مستقل که تنها نقطهٔ تماس با سرویس هوش مصنوعی است.
 * کلید API فقط اینجاست و هرگز به مرورگر نمی‌رود.
 *
 * مسیرها:
 *   GET  /health          بررسی سلامت
 *   POST /chat            گفتگو با استریم SSE
 *
 * امنیت:
 *   - هر درخواست باید هدر Authorization: Bearer <PocketBase user token> داشته باشد.
 *   - توکن با PocketBase اعتبارسنجی می‌شود (بدون کاربر معتبر → 401).
 *   - محدودیت نرخ: در دقیقه (حافظه) و در روز (کالکشن ai_usage).
 *   - پیام‌ها در ai_messages و مصرف در ai_usage با توکن ادمین سرور ذخیره می‌شود.
 *
 * اجرا: node server.js   (Node 18+ برای fetch داخلی)
 */
import http from "node:http";

/* ----------------------------- پیکربندی ---------------------------------- */

const PORT = Number(process.env.PORT || 8790);
const PB_URL = (process.env.PB_URL || "http://127.0.0.1:8090").replace(/\/+$/, "");
const PB_ADMIN_EMAIL = process.env.PB_ADMIN_EMAIL || "";
const PB_ADMIN_PASSWORD = process.env.PB_ADMIN_PASSWORD || "";

const OPENAI_BASE_URL = (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(
  /\/+$/,
  "",
);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";

const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "http://localhost:5173")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

const RATE_PER_MINUTE = Number(process.env.RATE_PER_MINUTE || 8);
const RATE_PER_DAY = Number(process.env.RATE_PER_DAY || 120);
const MAX_INPUT_CHARS = Number(process.env.MAX_INPUT_CHARS || 4000);
const MAX_HISTORY = Number(process.env.MAX_HISTORY || 12);
const UPSTREAM_TIMEOUT_MS = Number(process.env.UPSTREAM_TIMEOUT_MS || 90_000);

if (!OPENAI_API_KEY) {
  console.error("[ai-proxy] OPENAI_API_KEY تعریف نشده است. سرویس بالا نمی‌آید.");
  process.exit(1);
}

/* ----------------------------- ابزار HTTP -------------------------------- */

function corsHeaders(origin) {
  const allow = ALLOWED_ORIGINS.includes("*")
    ? "*"
    : ALLOWED_ORIGINS.includes(origin)
      ? origin
      : ALLOWED_ORIGINS[0] || "";
  return {
    "Access-Control-Allow-Origin": allow,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin",
  };
}

function sendJson(res, status, body, origin) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(payload),
    ...corsHeaders(origin),
  });
  res.end(payload);
}

function readBody(req, limitBytes = 200_000) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > limitBytes) {
        reject(new Error("payload_too_large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

/* --------------------------- PocketBase (ادمین) --------------------------- */

let adminToken = "";
let adminTokenAt = 0;

async function getAdminToken() {
  if (adminToken && Date.now() - adminTokenAt < 10 * 60_000) return adminToken;
  if (!PB_ADMIN_EMAIL || !PB_ADMIN_PASSWORD) return "";
  const res = await fetch(`${PB_URL}/api/collections/_superusers/auth-with-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identity: PB_ADMIN_EMAIL, password: PB_ADMIN_PASSWORD }),
  });
  if (!res.ok) {
    console.error("[ai-proxy] ورود ادمین PocketBase ناموفق بود:", res.status);
    return "";
  }
  const data = await res.json();
  adminToken = data.token || "";
  adminTokenAt = Date.now();
  return adminToken;
}

async function pbAdmin(path, init = {}) {
  const token = await getAdminToken();
  if (!token) return null;
  const res = await fetch(`${PB_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: token,
      ...(init.headers || {}),
    },
  });
  if (!res.ok) {
    console.error("[ai-proxy] خطای PocketBase:", path, res.status);
    return null;
  }
  return res.json().catch(() => null);
}

/** اعتبارسنجی توکن کاربر → رکورد کاربر یا null. */
async function authUser(token) {
  if (!token) return null;
  const res = await fetch(`${PB_URL}/api/collections/users/auth-refresh`, {
    method: "POST",
    headers: { Authorization: token },
  });
  if (!res.ok) return null;
  const data = await res.json().catch(() => null);
  return data?.record ?? null;
}

/* --------------------------- محدودیت نرخ --------------------------------- */

const minuteHits = new Map(); // userId -> number[] (timestamps)

function overMinuteLimit(userId) {
  const now = Date.now();
  const list = (minuteHits.get(userId) || []).filter((t) => now - t < 60_000);
  list.push(now);
  minuteHits.set(userId, list);
  return list.length > RATE_PER_MINUTE;
}

setInterval(() => {
  const now = Date.now();
  for (const [k, v] of minuteHits) {
    const keep = v.filter((t) => now - t < 60_000);
    if (keep.length) minuteHits.set(k, keep);
    else minuteHits.delete(k);
  }
}, 120_000).unref();

function today() {
  return new Date().toISOString().slice(0, 10);
}

async function getUsage(userId) {
  const day = today();
  const filter = encodeURIComponent(`user="${userId}" && day="${day}"`);
  const data = await pbAdmin(`/api/collections/ai_usage/records?perPage=1&filter=${filter}`);
  return data?.items?.[0] ?? null;
}

async function bumpUsage(userId, tokensIn, tokensOut) {
  const day = today();
  const existing = await getUsage(userId);
  if (existing) {
    await pbAdmin(`/api/collections/ai_usage/records/${existing.id}`, {
      method: "PATCH",
      body: JSON.stringify({
        requests: (existing.requests || 0) + 1,
        tokens_in: (existing.tokens_in || 0) + tokensIn,
        tokens_out: (existing.tokens_out || 0) + tokensOut,
        model: OPENAI_MODEL,
      }),
    });
    return;
  }
  await pbAdmin(`/api/collections/ai_usage/records`, {
    method: "POST",
    body: JSON.stringify({
      user: userId,
      day,
      requests: 1,
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      model: OPENAI_MODEL,
    }),
  });
}

/* ----------------------------- پرامپت سیستمی ------------------------------ */

const MODE_PROMPT = {
  coach: "Du bist ein geduldiger Deutsch-Lerncoach.",
  grammar: "Du erklärst deutsche Grammatik Schritt für Schritt mit kurzen Beispielsätzen.",
  writing: "Du korrigierst deutsche Texte: erst die korrigierte Fassung, dann kurze Begründungen.",
  conversation: "Du führst ein natürliches Gespräch auf Deutsch und stellst Rückfragen.",
  translate: "Du übersetzt zwischen Deutsch und Persisch und erklärst wichtige Nuancen.",
};

function systemPrompt(mode, level) {
  const lv = level && level !== "unknown" ? level : "A2";
  return [
    MODE_PROMPT[mode] || MODE_PROMPT.coach,
    `Das Sprachniveau des Lernenden ist ${lv}. Passe Wortschatz und Satzlänge daran an.`,
    "Antworte auf Deutsch. Wenn der Lernende auf Persisch schreibt oder um eine Erklärung bittet, ergänze eine kurze persische Erklärung.",
    "Nutze einfaches Markdown (**fett**, _kursiv_, Listen). Halte dich kurz und konkret.",
    "Erfinde keine Fakten über den Lernfortschritt des Nutzers.",
  ].join(" ");
}

/* ------------------------------ مسیر /chat -------------------------------- */

async function handleChat(req, res, origin) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim();
  const user = await authUser(token);
  if (!user) return sendJson(res, 401, { error: "unauthorized" }, origin);

  let body;
  try {
    body = JSON.parse(await readBody(req));
  } catch {
    return sendJson(res, 400, { error: "invalid_body" }, origin);
  }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  const threadId = typeof body.threadId === "string" ? body.threadId : "";
  const mode = MODE_PROMPT[body.mode] ? body.mode : "coach";
  const level = typeof body.level === "string" ? body.level : "unknown";
  const history = Array.isArray(body.history) ? body.history : [];

  if (!message) return sendJson(res, 400, { error: "empty_message" }, origin);
  if (message.length > MAX_INPUT_CHARS)
    return sendJson(res, 400, { error: "message_too_long", max: MAX_INPUT_CHARS }, origin);

  if (overMinuteLimit(user.id))
    return sendJson(res, 429, { error: "rate_limited", scope: "minute" }, origin);

  const usage = await getUsage(user.id);
  if (usage && (usage.requests || 0) >= RATE_PER_DAY)
    return sendJson(res, 429, { error: "rate_limited", scope: "day", limit: RATE_PER_DAY }, origin);

  // تاریخچهٔ ورودی: فقط user/assistant، محدود و کوتاه‌شده
  const messages = [
    { role: "system", content: systemPrompt(mode, level) },
    ...history
      .filter(
        (m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string",
      )
      .slice(-MAX_HISTORY)
      .map((m) => ({ role: m.role, content: String(m.content).slice(0, MAX_INPUT_CHARS) })),
    { role: "user", content: message },
  ];

  // مالکیت thread باید بررسی شود (اصلاح ممیزی سشن ۱۰ — IDOR):
  // بدون این بررسی، کاربر می‌توانست با توکن ادمین پروکسی در گفتگوی
  // کاربر دیگری پیام بنویسد.
  if (threadId) {
    try {
      const thread = await pbAdmin(`/api/collections/ai_threads/records/${threadId}`);
      if (!thread || thread.user !== user.id) {
        return sendJson(res, 403, { error: "forbidden_thread" }, origin);
      }
    } catch {
      return sendJson(res, 404, { error: "thread_not_found" }, origin);
    }
  }

  // ذخیرهٔ پیام کاربر (اگر thread داریم)
  if (threadId) {
    await pbAdmin(`/api/collections/ai_messages/records`, {
      method: "POST",
      body: JSON.stringify({
        user: user.id,
        thread: threadId,
        role: "user",
        content: message,
        meta: { mode },
        tokens: Math.ceil(message.length / 4),
      }),
    });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);
  req.on("close", () => controller.abort());

  let upstream;
  try {
    upstream = await fetch(`${OPENAI_BASE_URL}/chat/completions`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({ model: OPENAI_MODEL, messages, stream: true, temperature: 0.6 }),
    });
  } catch (err) {
    clearTimeout(timer);
    console.error("[ai-proxy] خطای ارتباط با سرویس هوش مصنوعی:", err?.name || err);
    return sendJson(res, 502, { error: "upstream_unavailable" }, origin);
  }

  if (!upstream.ok || !upstream.body) {
    clearTimeout(timer);
    const status = upstream.status === 429 ? 429 : 502;
    console.error("[ai-proxy] پاسخ نامعتبر از سرویس:", upstream.status);
    return sendJson(
      res,
      status,
      { error: status === 429 ? "rate_limited" : "upstream_error" },
      origin,
    );
  }

  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
    ...corsHeaders(origin),
  });

  const write = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

  let full = "";
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    for await (const chunk of upstream.body) {
      buffer += decoder.decode(chunk, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const payload = trimmed.slice(5).trim();
        if (payload === "[DONE]") continue;
        try {
          const json = JSON.parse(payload);
          const delta = json.choices?.[0]?.delta?.content;
          if (delta) {
            full += delta;
            write("delta", { text: delta });
          }
        } catch {
          /* قطعهٔ ناقص — نادیده */
        }
      }
    }
  } catch (err) {
    console.error("[ai-proxy] استریم قطع شد:", err?.name || err);
    if (!full) {
      write("error", { error: "stream_failed" });
      clearTimeout(timer);
      return res.end();
    }
  }

  clearTimeout(timer);

  const tokensIn = Math.ceil(messages.reduce((n, m) => n + m.content.length, 0) / 4);
  const tokensOut = Math.ceil(full.length / 4);

  let savedId = "";
  if (threadId && full) {
    const saved = await pbAdmin(`/api/collections/ai_messages/records`, {
      method: "POST",
      body: JSON.stringify({
        user: user.id,
        thread: threadId,
        role: "assistant",
        content: full.slice(0, 20000),
        meta: { mode, model: OPENAI_MODEL },
        tokens: tokensOut,
      }),
    });
    savedId = saved?.id || "";
    await pbAdmin(`/api/collections/ai_threads/records/${threadId}`, {
      method: "PATCH",
      body: JSON.stringify({ last_message_at: new Date().toISOString() }),
    });
  }

  await bumpUsage(user.id, tokensIn, tokensOut);

  write("done", { messageId: savedId, tokensIn, tokensOut });
  res.end();
}

/* ------------------------------ مسیر /import ------------------------------ */
/**
 * انتقال یک‌بارهٔ تاریخچهٔ محلی (localStorage) به PocketBase.
 * چون نوشتن در `ai_messages` برای کلاینت بسته است، این کار از پروکسی انجام می‌شود.
 */
async function handleImport(req, res, origin) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim();
  const user = await authUser(token);
  if (!user) return sendJson(res, 401, { error: "unauthorized" }, origin);

  let body;
  try {
    body = JSON.parse(await readBody(req, 1_000_000));
  } catch {
    return sendJson(res, 400, { error: "invalid_body" }, origin);
  }

  const threads = Array.isArray(body.threads) ? body.threads.slice(0, 50) : [];
  let imported = 0;

  for (const t of threads) {
    const messages = Array.isArray(t?.messages) ? t.messages.slice(0, 200) : [];
    if (!messages.length) continue;
    const created = await pbAdmin(`/api/collections/ai_threads/records`, {
      method: "POST",
      body: JSON.stringify({
        user: user.id,
        title: String(t.title || "Neuer Chat").slice(0, 80),
        mode: "coach",
        level: typeof body.level === "string" ? body.level : "unknown",
        last_message_at: new Date(Number(t.updatedAt) || Date.now()).toISOString(),
        archived: false,
      }),
    });
    if (!created?.id) continue;
    for (const m of messages) {
      const role = m?.role === "user" ? "user" : "assistant";
      const content = String(m?.text ?? "").slice(0, 20000);
      if (!content) continue;
      await pbAdmin(`/api/collections/ai_messages/records`, {
        method: "POST",
        body: JSON.stringify({
          user: user.id,
          thread: created.id,
          role,
          content,
          meta: { imported: true },
          tokens: Math.ceil(content.length / 4),
        }),
      });
    }
    imported += 1;
  }

  sendJson(res, 200, { ok: true, imported }, origin);
}

/* ------------------------------- سرور ------------------------------------ */

const server = http.createServer((req, res) => {
  const origin = req.headers.origin || "";
  if (req.method === "OPTIONS") {
    res.writeHead(204, corsHeaders(origin));
    return res.end();
  }
  if (req.method === "GET" && req.url === "/health") {
    return sendJson(res, 200, { ok: true, model: OPENAI_MODEL }, origin);
  }
  if (req.method === "POST" && req.url === "/chat") {
    return handleChat(req, res, origin).catch((err) => {
      console.error("[ai-proxy] خطای غیرمنتظره:", err);
      if (!res.headersSent) sendJson(res, 500, { error: "internal" }, origin);
      else res.end();
    });
  }
  if (req.method === "POST" && req.url === "/import") {
    return handleImport(req, res, origin).catch((err) => {
      console.error("[ai-proxy] خطای غیرمنتظره در import:", err);
      if (!res.headersSent) sendJson(res, 500, { error: "internal" }, origin);
      else res.end();
    });
  }
  sendJson(res, 404, { error: "not_found" }, origin);
});

server.listen(PORT, () => {
  console.log(`[ai-proxy] روی پورت ${PORT} اجرا شد — مدل: ${OPENAI_MODEL}`);
});
