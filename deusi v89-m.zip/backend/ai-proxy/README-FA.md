# AI-Proxy پروژه DEUSI (سشن ۱۰)

سرویس کوچک Node که تنها جایی است که کلید سرویس هوش مصنوعی در آن قرار دارد.
فرانت‌اند فقط این پروکسی را صدا می‌زند (`VITE_AI_PROXY_URL`) و هیچ کلیدی در مرورگر نیست.

## راه‌اندازی محلی

```bash
cd backend/ai-proxy
cp .env.example .env      # مقادیر را پر کنید
node server.js            # نیازمند Node 18+
```

سپس در فایل `.env` پروژهٔ فرانت:

```
VITE_PB_URL=http://127.0.0.1:8090
VITE_AI_PROXY_URL=http://127.0.0.1:8790
```

## مسیرها

| متد  | مسیر      | توضیح                                 |
| ---- | --------- | ------------------------------------- |
| GET  | `/health` | بررسی سلامت و مدل فعال                |
| POST | `/chat`   | گفتگو؛ پاسخ به‌صورت SSE استریم می‌شود |

بدنهٔ `/chat`:

```json
{
  "threadId": "abc123...",
  "message": "Erkläre den Konjunktiv II",
  "mode": "coach",
  "level": "B1",
  "history": [{ "role": "user", "content": "..." }]
}
```

هدر الزامی: `Authorization: Bearer <توکن کاربر PocketBase>`

رویدادهای SSE: `delta` (قطعهٔ متن)، `done` (پایان + مصرف)، `error`.

## امنیت

- توکن کاربر با `users/auth-refresh` در PocketBase اعتبارسنجی می‌شود؛ بدون کاربر معتبر → ۴۰۱.
- محدودیت نرخ: `RATE_PER_MINUTE` (حافظه) و `RATE_PER_DAY` (کالکشن `ai_usage`).
- ذخیرهٔ پیام‌ها در `ai_messages` و مصرف در `ai_usage` فقط با توکن ادمین سرور انجام می‌شود
  (قواعد این کالکشن‌ها برای کلاینت بسته است).
- CORS فقط برای دامنه‌های `ALLOWED_ORIGINS`.
- خطاهای سرویس بالادست هرگز عیناً به کلاینت برنمی‌گردند.

## اجرا روی سرور (systemd)

```bash
sudo cp -r backend/ai-proxy /opt/deusi/ai-proxy
sudo cp /opt/deusi/ai-proxy/.env.example /opt/deusi/ai-proxy/.env   # و ویرایش کنید
sudo cp /opt/deusi/ai-proxy/deusi-ai.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now deusi-ai
```

Nginx (reverse proxy روی `/ai/`) در `DEPLOY-FA.md` توضیح داده شده است.
