import { useCallback, useEffect, useState } from "react";

/** Local persistence for per-article reading state (progress, bookmark, savedWords). */
export interface ArticleState {
  progress: number; // 0..100
  bookmarked: boolean;
  savedWords: string[];
  lastReadAt?: string;
  timeSpent?: number; // seconds
}

const KEY = "deusi:lesen:state:v1";

function readAll(): Record<string, ArticleState> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Record<string, ArticleState>) : {};
  } catch {
    return {};
  }
}

function writeAll(v: Record<string, ArticleState>) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(v));
  } catch {
    /* noop */
  }
}

export function useArticleState(articleId: string, fallback?: Partial<ArticleState>) {
  const [state, setState] = useState<ArticleState>(() => ({
    progress: fallback?.progress ?? 0,
    bookmarked: fallback?.bookmarked ?? false,
    savedWords: [],
    timeSpent: 0,
  }));

  // hydrate after mount to avoid SSR hydration mismatch
  useEffect(() => {
    const all = readAll();
    if (all[articleId]) setState((prev) => ({ ...prev, ...all[articleId] }));
  }, [articleId]);

  const patch = useCallback(
    (p: Partial<ArticleState>) => {
      setState((prev) => {
        const next = { ...prev, ...p, lastReadAt: new Date().toISOString() };
        const all = readAll();
        all[articleId] = next;
        writeAll(all);
        return next;
      });
    },
    [articleId],
  );

  return [state, patch] as const;
}

export function useAllArticleStates() {
  const [all, setAll] = useState<Record<string, ArticleState>>({});
  useEffect(() => {
    setAll(readAll());
  }, []);
  return all;
}
