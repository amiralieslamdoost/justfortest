import { motion } from "framer-motion";
import { Link } from "@tanstack/react-router";
import { Compass, Home } from "lucide-react";

/**
 * Premium 404 page — used by root notFoundComponent for unknown routes.
 */
export function NotFoundPage() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center gap-6 px-4 py-16 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        className="relative"
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10 rounded-full opacity-40 blur-3xl"
          style={{ background: "radial-gradient(circle, var(--accent), transparent 65%)" }}
        />
        <div className="grid h-24 w-24 place-items-center rounded-3xl bg-[color:var(--accent)]/10 text-[color:var(--accent)] ring-1 ring-inset ring-[color:var(--accent)]/25">
          <Compass className="h-10 w-10" />
        </div>
      </motion.div>

      <div className="space-y-2">
        <h1 className="t-page-title text-4xl font-bold tracking-tight">404</h1>
        <p className="text-lg font-semibold text-foreground">Diese Seite existiert nicht</p>
        <p className="max-w-md text-sm text-muted-foreground">
          Die aufgerufene Adresse konnte nicht gefunden werden. Vielleicht wurde sie verschoben oder
          du hast dich vertippt.
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2">
        <Link to="/dashboard" className="btn btn-primary">
          <Home className="h-4 w-4" /> Zur Startseite
        </Link>
        <Link to="/dictionary" className="btn btn-outline">
          Wörterbuch entdecken
        </Link>
      </div>
    </div>
  );
}
