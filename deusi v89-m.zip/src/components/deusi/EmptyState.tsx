import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface Props {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
  compact?: boolean;
}

/**
 * Premium empty state — glass card, subtle animation, single CTA slot.
 * Consistent visual language across every module.
 */
export function EmptyState({ icon, title, description, action, className, compact }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "neu-card flex flex-col items-center justify-center gap-3 text-center",
        compact ? "p-6" : "p-10",
        className,
      )}
      role="status"
    >
      {icon !== undefined ? (
        <div
          aria-hidden
          className="grid h-14 w-14 place-items-center rounded-2xl bg-[color:var(--accent)]/10 text-[color:var(--accent)] ring-1 ring-inset ring-[color:var(--accent)]/15"
        >
          {icon}
        </div>
      ) : (
        <div aria-hidden className="text-4xl">
          ✨
        </div>
      )}
      <div className="max-w-sm space-y-1">
        <h3 className="text-base font-semibold text-foreground">{title}</h3>
        {description && <p className="text-sm text-muted-foreground">{description}</p>}
      </div>
      {action && <div className="pt-2">{action}</div>}
    </motion.div>
  );
}
