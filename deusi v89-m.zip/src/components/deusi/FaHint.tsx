import type { HTMLAttributes } from "react";

/**
 * FaHint — a small Persian companion label rendered in Yekan Bakh.
 * Placed under German titles / section headers so learners whose German is
 * still weak can quickly orient themselves. Kept subtle by design so it
 * never competes with the primary German UI.
 *
 * Variants:
 *   size="md" (default) — sits below a title (h1/h2/h3)
 *   size="sm"           — sits below a nav item / small label
 *   inline              — inline span next to another element (no block)
 */
type Props = {
  children: React.ReactNode;
  size?: "md" | "sm";
  inline?: boolean;
  className?: string;
} & Omit<HTMLAttributes<HTMLSpanElement>, "children" | "className">;

export function FaHint({ children, size = "md", inline = false, className = "", ...rest }: Props) {
  const base = inline ? "fa-hint-inline" : size === "sm" ? "fa-hint-sm" : "fa-hint";
  return (
    <span lang="fa" dir="rtl" className={`${base} ${className}`.trim()} {...rest}>
      {children}
    </span>
  );
}
