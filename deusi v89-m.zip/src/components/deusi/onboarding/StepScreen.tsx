import { Fa } from "@/components/deusi/Fa";
import { SKILL_COLOR } from "@/components/deusi/planner/parts";
import {
  GOAL_LABEL,
  INTENSITY,
  LEVEL_LABEL,
  SKILL_LABEL,
  SKILL_ORDER,
  WEEKDAY_LABEL,
} from "@/lib/deusi/planner/config";
import { formatMinutes, todayISO } from "@/lib/deusi/planner/date";
import type { CefrLevel, Intensity, SkillKey } from "@/lib/deusi/planner/types";
import {
  GOAL_OPTIONS,
  LEVEL_OPTIONS,
  MINUTE_HINT_FA,
  MINUTE_OPTIONS,
  PREFERENCE_LABEL,
  PREFERENCE_ORDER,
  STEP_TITLE,
  type StepId,
} from "@/lib/deusi/onboarding/steps";
import {
  GOAL_ICON,
  INTENSITY_ICON,
  LEVEL_ICON,
  PREFERENCE_ICON,
  SKILL_ICON,
  STEP_ICON,
  minuteIcon,
  startIcon,
} from "@/lib/deusi/onboarding/icons";
import type { OnboardingAnswers } from "@/lib/deusi/onboarding/types";
import { CalendarClock, CalendarDays, Clock, X } from "lucide-react";
import { OptionCard, QuestionShell, SkillRatingRow } from "./parts";

const DAY_ORDER = [6, 0, 1, 2, 3, 4, 5];
const START_PRESETS = [
  { h: "06:30", fa: "صبح زود" },
  { h: "08:00", fa: "صبح" },
  { h: "12:30", fa: "ظهر" },
  { h: "17:00", fa: "بعدازظهر" },
  { h: "19:00", fa: "عصر" },
  { h: "21:00", fa: "شب" },
];

function toggle<T>(list: T[], value: T): T[] {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

const inputClass =
  "w-full rounded-xl border border-border bg-background px-3 py-3 text-sm font-semibold tabular-nums outline-none transition-colors focus:border-[color:var(--section-primary)] focus:ring-4 focus:ring-[color:var(--section-primary)]/15";

const ic = "h-[18px] w-[18px]";

/**
 * Eine Onboarding-Frage. Alle Werte gehören zum Vokabular des bestehenden
 * Smart Planners — hier wird nur gefragt, nicht geplant.
 */
export function StepScreen({
  step,
  answers,
  patch,
}: {
  step: StepId;
  answers: OnboardingAnswers;
  patch: (a: Partial<OnboardingAnswers>) => void;
}) {
  const t = STEP_TITLE[step];
  const StepIcon = STEP_ICON[step];
  const shell = {
    title: t.de,
    fa: t.fa,
    hint: t.hint,
    hintFa: t.hintFa,
    accent: t.accent,
    icon: <StepIcon className="h-5 w-5" />,
  };

  switch (step) {
    case "level":
      return (
        <QuestionShell {...shell}>
          <div
            role="radiogroup"
            aria-label={t.de}
            className="grid auto-rows-fr gap-2.5 sm:grid-cols-2"
          >
            {LEVEL_OPTIONS.map((o) => {
              const Icon = LEVEL_ICON[o.value];
              return (
                <OptionCard
                  key={o.value}
                  accent={t.accent}
                  icon={<Icon className={ic} />}
                  active={answers.level === o.value}
                  onClick={() => patch({ level: o.value })}
                  title={o.label}
                  desc={o.desc}
                  descFa={o.descFa}
                />
              );
            })}
          </div>
        </QuestionShell>
      );

    case "goals":
      return (
        <QuestionShell {...shell}>
          <div role="group" aria-label={t.de} className="grid auto-rows-fr gap-2.5 sm:grid-cols-2">
            {GOAL_OPTIONS.map((o) => {
              const Icon = GOAL_ICON[o.value];
              return (
                <OptionCard
                  key={o.value}
                  multi
                  accent={t.accent}
                  icon={<Icon className={ic} />}
                  active={answers.goals.includes(o.value)}
                  onClick={() => patch({ goals: toggle(answers.goals, o.value) })}
                  title={
                    <>
                      {GOAL_LABEL[o.value].de}
                      <Fa inline>{GOAL_LABEL[o.value].fa}</Fa>
                    </>
                  }
                  desc={o.desc}
                  descFa={o.descFa}
                />
              );
            })}
          </div>
        </QuestionShell>
      );

    case "exam":
      return (
        <QuestionShell {...shell}>
          <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]">
            <div>
              <p className="mb-2 flex items-center gap-2 text-sm font-bold tracking-tight">
                <CalendarClock className="h-4 w-4 text-[color:var(--section-primary)]" />
                Zielniveau <Fa inline>سطح هدف</Fa>
              </p>
              <div
                role="radiogroup"
                aria-label="Zielniveau"
                className="grid auto-rows-fr grid-cols-2 gap-2.5 sm:grid-cols-3"
              >
                {(["A2", "B1", "B2", "C1", "C2"] as CefrLevel[]).map((l) => {
                  const Icon = LEVEL_ICON[l];
                  return (
                    <OptionCard
                      key={l}
                      compact
                      accent={t.accent}
                      icon={<Icon className={ic} />}
                      active={answers.targetLevel === l}
                      onClick={() => patch({ targetLevel: answers.targetLevel === l ? null : l })}
                      title={LEVEL_LABEL[l]}
                    />
                  );
                })}
              </div>
            </div>
            <div className="rounded-2xl border border-border/70 bg-card p-3.5">
              <label
                htmlFor="onb-exam-date"
                className="mb-2 flex items-center gap-2 text-sm font-bold tracking-tight"
              >
                <CalendarDays className="h-4 w-4 text-[color:var(--section-primary)]" />
                Prüfungstermin
                <Fa inline>تاریخ آزمون</Fa>
              </label>
              <input
                id="onb-exam-date"
                type="date"
                min={todayISO()}
                value={answers.targetDate ?? ""}
                onChange={(e) => patch({ targetDate: e.target.value || null })}
                className={inputClass}
              />
              <p
                lang="fa"
                dir="rtl"
                className="mt-2 text-right text-xs leading-6 text-muted-foreground"
              >
                اختیاری است — هرچه به تاریخ آزمون نزدیک‌تر شوی، تمرین آزمون بیشتری برایت برنامه‌ریزی
                می‌شود.
              </p>
            </div>
          </div>
        </QuestionShell>
      );

    case "time":
      return (
        <QuestionShell {...shell}>
          <div
            role="radiogroup"
            aria-label={t.de}
            className="grid auto-rows-fr gap-2.5 sm:grid-cols-2 lg:grid-cols-3"
          >
            {MINUTE_OPTIONS.map((m) => {
              const Icon = minuteIcon(m);
              return (
                <OptionCard
                  key={m}
                  accent={t.accent}
                  icon={<Icon className={ic} />}
                  active={answers.dailyMinutes === m}
                  onClick={() => patch({ dailyMinutes: m })}
                  title={formatMinutes(m)}
                  descFa={MINUTE_HINT_FA[m]}
                />
              );
            })}
          </div>
        </QuestionShell>
      );

    case "days":
      return (
        <QuestionShell {...shell}>
          <div className="flex flex-col gap-4">
            <div
              role="group"
              aria-label={t.de}
              className="grid auto-rows-fr grid-cols-2 gap-2.5 sm:grid-cols-4"
            >
              {DAY_ORDER.map((d) => (
                <OptionCard
                  key={d}
                  multi
                  compact
                  accent={t.accent}
                  active={answers.studyDays.includes(d)}
                  onClick={() => patch({ studyDays: toggle(answers.studyDays, d) })}
                  title={
                    <>
                      {WEEKDAY_LABEL[d]!.de}
                      <Fa inline>{WEEKDAY_LABEL[d]!.fa}</Fa>
                    </>
                  }
                />
              ))}
            </div>
            <div>
              <p className="mb-2 text-sm font-bold tracking-tight">
                Ruhetag <Fa inline>روز استراحت</Fa>
              </p>
              <div
                role="radiogroup"
                aria-label="Ruhetag"
                className="grid auto-rows-fr gap-2.5 sm:grid-cols-2"
              >
                <OptionCard
                  accent={t.accent}
                  active={answers.restDays === "auto"}
                  onClick={() => patch({ restDays: "auto" })}
                  title="Ruhetag erlauben"
                  desc="DEUSI darf einen Tag frei lassen, wenn die Woche voll ist."
                  descFa="اگر هفته پر باشد، DEUSI یک روز را آزاد می‌گذارد."
                />
                <OptionCard
                  accent={t.accent}
                  active={answers.restDays === "none"}
                  onClick={() => patch({ restDays: "none" })}
                  title="Jeden gewählten Tag lernen"
                  desc="Kein automatischer Ruhetag."
                  descFa="همه‌ی روزهای انتخابی، بدون روز استراحت خودکار."
                />
              </div>
            </div>
          </div>
        </QuestionShell>
      );

    case "start":
      return (
        <QuestionShell {...shell}>
          <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_16rem]">
            <div
              role="radiogroup"
              aria-label={t.de}
              className="grid auto-rows-fr gap-2.5 sm:grid-cols-2 lg:grid-cols-3"
            >
              {START_PRESETS.map((p) => {
                const Icon = startIcon(p.h);
                return (
                  <OptionCard
                    key={p.h}
                    accent={t.accent}
                    icon={<Icon className={ic} />}
                    active={answers.preferredStartTime === p.h}
                    onClick={() => patch({ preferredStartTime: p.h })}
                    title={`${p.h} Uhr`}
                    descFa={p.fa}
                  />
                );
              })}
            </div>
            <div className="rounded-2xl border border-border/70 bg-card p-3.5">
              <label
                htmlFor="onb-start"
                className="mb-2 flex items-center gap-2 text-sm font-bold tracking-tight"
              >
                <Clock className="h-4 w-4 text-[color:var(--section-primary)]" />
                Eigene Uhrzeit
                <Fa inline>ساعت دلخواه</Fa>
              </label>
              <input
                id="onb-start"
                type="time"
                value={answers.preferredStartTime}
                onChange={(e) => patch({ preferredStartTime: e.target.value || "19:00" })}
                className={inputClass}
              />
            </div>
          </div>
        </QuestionShell>
      );

    case "target":
      return (
        <QuestionShell {...shell}>
          <div className="mx-auto flex w-full max-w-md flex-col gap-3 rounded-2xl border border-border/70 bg-card p-5">
            <label
              htmlFor="onb-target"
              className="flex items-center gap-2 text-sm font-bold tracking-tight"
            >
              <CalendarDays className="h-4 w-4 text-[color:var(--section-primary)]" />
              Ziel-Datum
              <Fa inline>تاریخ هدف</Fa>
            </label>
            <input
              id="onb-target"
              type="date"
              min={todayISO()}
              value={answers.targetDate ?? ""}
              onChange={(e) => patch({ targetDate: e.target.value || null })}
              className={inputClass}
            />
            {answers.targetDate ? (
              <button
                type="button"
                onClick={() => patch({ targetDate: null })}
                className="inline-flex items-center gap-1.5 self-start rounded-full px-2 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" />
                Datum entfernen · حذف تاریخ
              </button>
            ) : null}
          </div>
        </QuestionShell>
      );

    case "intensity":
      return (
        <QuestionShell {...shell}>
          <div
            role="radiogroup"
            aria-label={t.de}
            className="grid auto-rows-fr gap-2.5 sm:grid-cols-3"
          >
            {(Object.keys(INTENSITY) as Intensity[]).map((i) => {
              const Icon = INTENSITY_ICON[i];
              return (
                <OptionCard
                  key={i}
                  accent={t.accent}
                  icon={<Icon className={ic} />}
                  active={answers.intensity === i}
                  onClick={() => patch({ intensity: i })}
                  title={
                    <>
                      {INTENSITY[i].label}
                      <Fa inline>{INTENSITY[i].fa}</Fa>
                    </>
                  }
                  desc={
                    i === "light"
                      ? "Flexible, leichtere Lernroutine"
                      : i === "steady"
                        ? "Regelmäßiges Lernen mit stabilem Tempo"
                        : "Mehr Fokus und schnelleres Fortschreiten"
                  }
                  descFa={
                    i === "light"
                      ? "سبک و منعطف — مناسب هفته‌های شلوغ"
                      : i === "steady"
                        ? "منظم و پیوسته — انتخاب پیشنهادی"
                        : "فشرده و سریع — برای پیشرفت سریع‌تر"
                  }
                />
              );
            })}
          </div>
        </QuestionShell>
      );

    case "skills": {
      const rate = (s: SkillKey): "weak" | "ok" | "strong" =>
        answers.weakSkills.includes(s)
          ? "weak"
          : answers.strongSkills.includes(s)
            ? "strong"
            : "ok";
      const set = (s: SkillKey, v: "weak" | "ok" | "strong") =>
        patch({
          weakSkills:
            v === "weak"
              ? [...new Set([...answers.weakSkills, s])]
              : answers.weakSkills.filter((x) => x !== s),
          strongSkills:
            v === "strong"
              ? [...new Set([...answers.strongSkills, s])]
              : answers.strongSkills.filter((x) => x !== s),
        });
      return (
        <QuestionShell {...shell}>
          <div className="grid auto-rows-fr gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {SKILL_ORDER.map((s) => {
              const Icon = SKILL_ICON[s];
              return (
                <SkillRatingRow
                  key={s}
                  label={SKILL_LABEL[s].de}
                  labelFa={SKILL_LABEL[s].fa}
                  color={SKILL_COLOR[s]}
                  icon={<Icon className="h-4 w-4" />}
                  value={rate(s)}
                  onChange={(v) => set(s, v)}
                />
              );
            })}
          </div>
          <p lang="fa" dir="rtl" className="text-right text-xs leading-6 text-muted-foreground">
            مهارت‌های «ضعیف» تا ۱٫۶ برابر زمان بیشتری می‌گیرند و مهارت‌های «قوی» کمتر تکرار می‌شوند.
          </p>
        </QuestionShell>
      );
    }

    case "preferences":
      return (
        <QuestionShell {...shell}>
          <div
            role="group"
            aria-label={t.de}
            className="grid auto-rows-fr gap-2.5 sm:grid-cols-2 lg:grid-cols-4"
          >
            {PREFERENCE_ORDER.map((p) => {
              const Icon = PREFERENCE_ICON[p];
              return (
                <OptionCard
                  key={p}
                  multi
                  compact
                  accent={t.accent}
                  icon={<Icon className={ic} />}
                  active={answers.preferences.includes(p)}
                  onClick={() => patch({ preferences: toggle(answers.preferences, p) })}
                  title={
                    <>
                      {PREFERENCE_LABEL[p].de}
                      <Fa inline>{PREFERENCE_LABEL[p].fa}</Fa>
                    </>
                  }
                />
              );
            })}
          </div>
        </QuestionShell>
      );
  }
}
