import { Link } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import { useLearnerProfile } from "@/lib/deusi/onboarding/useLearnerProfile";

/**
 * Einstiegspunkt, um ein übersprungenes Onboarding später nachzuholen.
 * Öffnet immer denselben Onboarding-Flow (/onboarding) — es gibt nur einen.
 */
export function LearnerProfilePrompt({ compact }: { compact?: boolean }) {
  const { loading, hasProfile } = useLearnerProfile();
  if (loading || hasProfile) return null;

  return (
    <section
      className="neu-card flex flex-wrap items-center justify-between gap-4 p-5"
      aria-label="Lernprofil vervollständigen"
    >
      <div className="min-w-0">
        <h2 className="text-sm font-black uppercase tracking-[0.14em] text-[color:var(--section-primary)]">
          Dein Lernprofil ist noch nicht vollständig
        </h2>
        <p className="mt-1 max-w-xl text-sm text-muted-foreground">
          Erstelle dein Profil, damit DEUSI deinen Lernplan besser personalisieren kann.
        </p>
        {compact ? null : <Fa>پروفایل یادگیری‌ات را کامل کن</Fa>}
      </div>
      <Link
        to="/onboarding"
        className="inline-flex items-center gap-2 rounded-full bg-[color:var(--section-primary)] px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-px"
      >
        <Sparkles className="h-4 w-4" />
        Profil erstellen
      </Link>
    </section>
  );
}
