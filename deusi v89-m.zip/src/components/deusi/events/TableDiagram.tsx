import { motion } from "framer-motion";
import type { EventGroup } from "@/lib/deusi/events/mockEvents";

interface Props {
  group: EventGroup;
  mySeat?: number;
  size?: number; // max intrinsic size in px; component fills its container up to this width
  interactive?: boolean;
  compact?: boolean;
}

const LEVEL_COLOR: Record<string, string> = {
  "B1-B2": "#8B5CF6",
  "C1-C2": "#22C55E",
};

/**
 * Responsive table diagram — fills its container width up to `size`,
 * keeps a 1:1 aspect ratio, and positions all seats/table via percentages,
 * so nothing overflows the parent card even at narrow widths.
 */
export function TableDiagram({ group, mySeat, size = 220, compact = false }: Props) {
  const color = LEVEL_COLOR[group.level] ?? "#8B5CF6";
  const takenSet = new Set(group.reservations.map((r) => r.seat));

  // All coordinates below are percentages of the square container.
  const orbitPct = 38; // seat orbit radius (% of half-width)
  const seatSizePct = 18; // seat diameter (% of container)
  const tableSizePct = orbitPct * 1.44; // slightly smaller than orbit
  const center = 50;

  return (
    <div className="relative mx-auto w-full" style={{ maxWidth: size, aspectRatio: "1 / 1" }}>
      {/* Table */}
      <motion.div
        initial={{ scale: 0.92, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 120, damping: 18 }}
        className="absolute rounded-full"
        style={{
          left: `${center - tableSizePct}%`,
          top: `${center - tableSizePct}%`,
          width: `${tableSizePct * 2}%`,
          height: `${tableSizePct * 2}%`,
          background: `radial-gradient(circle at 30% 25%, ${color}33, ${color}11 60%, transparent 75%)`,
          border: `1px solid ${color}55`,
          boxShadow: `inset 0 2px 12px ${color}22, 0 12px 40px -20px ${color}66`,
        }}
      >
        <div className="grid h-full w-full place-items-center text-center">
          <div>
            <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              Tisch
            </div>
            <div className="text-2xl font-bold" style={{ color }}>
              {group.tableNumber}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Seats */}
      {Array.from({ length: group.seats }).map((_, i) => {
        const seat = i + 1;
        const angle = (i / group.seats) * Math.PI * 2 - Math.PI / 2;
        const x = center + orbitPct * Math.cos(angle);
        const y = center + orbitPct * Math.sin(angle);
        const isMine = seat === mySeat;
        const isTaken = takenSet.has(seat);

        let bg = "var(--card)";
        let fg = "var(--muted-foreground)";
        let border = "var(--border)";
        let shadow = "0 2px 6px rgba(0,0,0,.06)";
        if (isMine) {
          bg = color;
          fg = "#fff";
          border = color;
          shadow = `0 0 0 3px ${color}33, 0 8px 24px -6px ${color}88`;
        } else if (isTaken) {
          bg = `${color}22`;
          fg = color;
          border = `${color}44`;
        }

        return (
          <motion.div
            key={seat}
            initial={{ scale: 0, opacity: 0 }}
            animate={{
              scale: isMine ? [1, 1.25, 1] : 1,
              opacity: 1,
            }}
            transition={{
              delay: 0.04 * i,
              duration: isMine ? 0.7 : 0.35,
              type: isMine ? "tween" : "spring",
            }}
            className="absolute grid place-items-center rounded-full font-semibold"
            style={{
              left: `${x - seatSizePct / 2}%`,
              top: `${y - seatSizePct / 2}%`,
              width: `${seatSizePct}%`,
              height: `${seatSizePct}%`,
              background: bg,
              color: fg,
              border: `1px solid ${border}`,
              boxShadow: shadow,
              fontSize: compact ? 10 : 12,
            }}
            title={
              isMine
                ? `Dein Sitz ${group.id}${seat}`
                : isTaken
                  ? `Sitz ${seat} · reserviert`
                  : `Sitz ${seat} · frei`
            }
          >
            {seat}
          </motion.div>
        );
      })}
    </div>
  );
}
