import type { ReactNode } from "react";
import { useState } from "react";
import type { Settings2 } from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";

export function MiniHero(props: {
  Icon: typeof Settings2;
  label: string;
  title: string;
  highlight?: string;
  fa: string;
  desc: string;
  descFa: string;
  base: string;
  primary: string;
  accent: string;
}) {
  const { Icon, label, title, highlight, fa, desc, descFa, base, primary, accent } = props;
  const idx = highlight ? title.indexOf(highlight) : -1;
  const before = idx >= 0 ? title.slice(0, idx) : title;
  const mid = idx >= 0 ? title.slice(idx, idx + (highlight?.length ?? 0)) : "";
  const after = idx >= 0 ? title.slice(idx + (highlight?.length ?? 0)) : "";
  return (
    <header
      className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
      style={{
        backgroundImage: `linear-gradient(135deg, ${base} 0%, ${primary} 55%, ${accent} 130%)`,
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div
          className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
          style={{ backgroundColor: accent, opacity: 0.35 }}
        />
      </div>
      <div className="relative flex min-w-0 items-center gap-3 sm:gap-4">
        <div
          className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16"
          style={{ color: primary }}
        >
          <Icon className="h-8 w-8" />
        </div>
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
            {label}
          </div>
          <h1 className="mt-2 text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
            {before}
            {mid && (
              <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
                {mid}
              </span>
            )}
            {after}
          </h1>
          <FaHint className="!text-white/85">{fa}</FaHint>
          <p className="mt-2 max-w-2xl text-sm text-white/80">{desc}</p>
          <FaHint className="!text-white/70">{descFa}</FaHint>
        </div>
      </div>
    </header>
  );
}

export function Panel({
  title,
  fa,
  tone = "default",
  children,
}: {
  title: string;
  fa?: string;
  tone?: "default" | "warn";
  children: ReactNode;
}) {
  return (
    <section
      className={`glass-strong rounded-[28px] p-5 sm:p-6 ${tone === "warn" ? "ring-1 ring-amber-400/20" : ""}`}
    >
      <header className="mb-4">
        <h2 className="text-[15px] font-semibold tracking-tight">{title}</h2>
        {fa && <FaHint>{fa}</FaHint>}
      </header>
      {children}
    </section>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}
export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className="w-full rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none transition focus:border-foreground/40 focus:ring-4 focus:ring-foreground/5"
    />
  );
}
export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className="w-full rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none transition focus:border-foreground/40 focus:ring-4 focus:ring-foreground/5"
    />
  );
}

export function PrimaryBtn({ children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...p}
      className="inline-flex items-center gap-1.5 rounded-xl bg-foreground px-4 py-2 text-sm font-bold text-background transition hover:opacity-90"
    >
      {children}
    </button>
  );
}
export function GhostBtn({ children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...p}
      className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-background/40 px-4 py-2 text-sm font-semibold text-foreground/80 transition hover:bg-foreground/5"
    >
      {children}
    </button>
  );
}
export function DangerBtn({ children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...p}
      className="inline-flex items-center gap-1.5 rounded-xl bg-destructive/10 px-4 py-2 text-sm font-bold text-destructive ring-1 ring-inset ring-destructive/30 transition hover:bg-destructive/15"
    >
      {children}
    </button>
  );
}

export function Row({
  Icon,
  title,
  fa,
  desc,
  tone = "default",
  children,
}: {
  Icon?: typeof Settings2;
  title: string;
  fa?: string;
  desc?: string;
  tone?: "default" | "danger";
  children?: ReactNode;
}) {
  return (
    <div
      className={`flex items-start gap-3 rounded-2xl border p-3 ${tone === "danger" ? "border-destructive/25 bg-destructive/5" : "border-border bg-background/40"}`}
    >
      {Icon && (
        <span
          className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${tone === "danger" ? "bg-destructive/10 text-destructive" : "bg-foreground/5"}`}
        >
          <Icon className="h-5 w-5" />
        </span>
      )}
      <div className="min-w-0 flex-1">
        <div className="text-sm font-semibold">{title}</div>
        {fa && <FaHint>{fa}</FaHint>}
        {desc && <p className="mt-0.5 text-xs text-muted-foreground">{desc}</p>}
      </div>
      {children}
    </div>
  );
}

export function ToggleRow({
  Icon,
  title,
  fa,
  desc,
  checked,
  defaultChecked,
  onChange,
}: {
  Icon?: typeof Settings2;
  title: string;
  fa?: string;
  desc?: string;
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (v: boolean) => void;
}) {
  const [inner, setInner] = useState(defaultChecked ?? false);
  const value = checked ?? inner;
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-border bg-background/40 p-3 transition hover:border-foreground/20">
      {Icon && (
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-foreground/5">
          <Icon className="h-5 w-5" />
        </span>
      )}
      <div className="min-w-0 flex-1">
        <div className="text-sm font-semibold">{title}</div>
        {fa && <FaHint>{fa}</FaHint>}
        {desc && <p className="mt-0.5 text-xs text-muted-foreground">{desc}</p>}
      </div>
      <span className="relative inline-flex h-6 w-11 shrink-0">
        <input
          type="checkbox"
          checked={value}
          onChange={(e) => (onChange ? onChange(e.target.checked) : setInner(e.target.checked))}
          className="peer sr-only"
        />
        <span className="absolute inset-0 rounded-full bg-foreground/15 transition peer-checked:bg-foreground" />
        <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition peer-checked:translate-x-5" />
      </span>
    </label>
  );
}
