import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useTheme } from "@/lib/deusi/theme";
import {
  Bell,
  Shield,
  Download,
  LogOut,
  Trash2,
  Check,
  Moon,
  Sun,
  Monitor,
  Mail,
  Smartphone,
  Globe,
  Sparkles,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { useSettings } from "@/lib/api/useSettings";
import {
  Panel,
  Field,
  Input,
  Select,
  PrimaryBtn,
  GhostBtn,
  DangerBtn,
  Row,
  ToggleRow,
} from "@/components/deusi/settings/SettingsPrimitives";

export function AccountPanel() {
  return (
    <>
      <Panel title="Profildaten" fa="اطلاعات پروفایل">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Anzeigename">
            <Input defaultValue="Max Mustermann" />
          </Field>
          <Field label="Benutzername">
            <Input defaultValue="max.mustermann" />
          </Field>
          <Field label="E-Mail">
            <Input type="email" defaultValue="max@deusi.app" />
          </Field>
          <Field label="Telefonnummer">
            <Input type="tel" placeholder="+49 …" />
          </Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <GhostBtn>Abbrechen</GhostBtn>
          <PrimaryBtn>
            <Check className="h-4 w-4" /> Speichern
          </PrimaryBtn>
        </div>
      </Panel>

      <Panel title="Konto-Aktionen" fa="اقدامات حساب" tone="warn">
        <div className="space-y-3">
          <Row
            Icon={Download}
            title="Daten exportieren"
            fa="دریافت خروجی از داده‌ها"
            desc="Lade eine Kopie deiner Lerndaten als JSON."
          >
            <GhostBtn>Exportieren</GhostBtn>
          </Row>
          <Row
            Icon={LogOut}
            title="Von allen Geräten abmelden"
            fa="خروج از همه دستگاه‌ها"
            desc="Beendet alle aktiven Sitzungen."
          >
            <GhostBtn>Abmelden</GhostBtn>
          </Row>
          <Row
            Icon={Trash2}
            title="Konto löschen"
            fa="حذف حساب"
            desc="Unwiderruflich. Alle Daten werden entfernt."
            tone="danger"
          >
            <DangerBtn>Konto löschen</DangerBtn>
          </Row>
        </div>
      </Panel>
    </>
  );
}

export function NotifPanel() {
  /* سشن ۹: تنظیمات اعلان روی بک‌اند ذخیره می‌شود. */
  const { settings, save } = useSettings();
  const prefs = settings.notification_prefs;
  const setPref = (key: keyof typeof prefs, value: boolean) =>
    save({ notification_prefs: { ...prefs, [key]: value } });

  return (
    <Panel title="Benachrichtigungen" fa="اعلان‌ها">
      <div className="space-y-3">
        <ToggleRow
          Icon={Bell}
          title="Tägliche Lernerinnerung"
          fa="یادآوری روزانه مطالعه"
          checked={prefs.srs}
          onChange={(v) => setPref("srs", v)}
        />
        <ToggleRow
          Icon={Mail}
          title="Wöchentliche Zusammenfassung per E-Mail"
          fa="خلاصه هفتگی از طریق ایمیل"
          checked={settings.email_digest}
          onChange={(v) => save({ email_digest: v })}
        />
        <ToggleRow
          Icon={Smartphone}
          title="Push auf mobilen Geräten"
          fa="اعلان روی موبایل"
          checked={settings.push_enabled}
          onChange={(v) => save({ push_enabled: v })}
        />
        <ToggleRow
          Icon={Sparkles}
          title="Neue Missionen & Erfolge"
          fa="مأموریت‌ها و دستاوردهای جدید"
          checked={prefs.achievement}
          onChange={(v) => setPref("achievement", v)}
        />
        <ToggleRow
          Icon={Globe}
          title="Community-Events in deiner Nähe"
          fa="رویدادها در نزدیکی تو"
          checked={prefs.event}
          onChange={(v) => setPref("event", v)}
        />
      </div>

      <div className="mt-6 rounded-2xl border border-border bg-background/40 p-4">
        <div className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
          Ruhezeiten
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Von">
            <Input type="time" defaultValue="22:00" />
          </Field>
          <Field label="Bis">
            <Input type="time" defaultValue="07:00" />
          </Field>
        </div>
      </div>
    </Panel>
  );
}

export function PrivacyPanel() {
  return (
    <Panel title="Datenschutz" fa="حریم خصوصی">
      <div className="space-y-3">
        <ToggleRow title="Profil öffentlich zeigen" fa="نمایش عمومی پروفایل" defaultChecked />
        <ToggleRow title="In Leaderboards erscheinen" fa="نمایش در جدول امتیازات" defaultChecked />
        <ToggleRow
          title="Anonyme Nutzungsstatistiken teilen"
          fa="ارسال آمار ناشناس"
          defaultChecked
        />
        <ToggleRow
          title="Personalisierte Empfehlungen"
          fa="پیشنهادهای شخصی‌سازی‌شده"
          defaultChecked
        />
        <ToggleRow title="Kontaktbar per E-Mail" fa="تماس از طریق ایمیل" />
      </div>
      <div className="mt-6 flex flex-wrap gap-2 text-xs">
        <Link
          to="/datenschutz"
          className="rounded-full border border-border px-3 py-1.5 font-semibold text-foreground/80 hover:bg-foreground/5"
        >
          Datenschutzerklärung ansehen
        </Link>
        <Link
          to="/agb"
          className="rounded-full border border-border px-3 py-1.5 font-semibold text-foreground/80 hover:bg-foreground/5"
        >
          AGB ansehen
        </Link>
      </div>
    </Panel>
  );
}

export function AppearancePanel() {
  const { theme: activeTheme, setTheme: applyTheme } = useTheme();
  /* سشن ۹: انتخاب حالت رنگ در تنظیمات کاربر ذخیره می‌شود. */
  const { settings, save } = useSettings();
  const theme = settings.theme;
  const setTheme = (t: "system" | "light" | "dark") => {
    save({ theme: t });
    applyTheme(t);
  };
  useEffect(() => {
    if (settings.theme !== "system" && settings.theme !== activeTheme) applyTheme(settings.theme);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.theme]);
  const [density, setDensity] = useState<"comfort" | "compact">("comfort");
  const [motionReduce, setMotion] = useState(false);
  return (
    <Panel title="Erscheinungsbild" fa="ظاهر">
      <div className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        Farbmodus
      </div>
      <div className="grid gap-2 sm:grid-cols-3">
        {[
          { key: "system", label: "System", Icon: Monitor },
          { key: "light", label: "Hell", Icon: Sun },
          { key: "dark", label: "Dunkel", Icon: Moon },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTheme(t.key as typeof theme)}
            className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
              theme === t.key
                ? "border-foreground bg-foreground/5"
                : "border-border hover:border-foreground/30"
            }`}
          >
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-foreground/5">
              <t.Icon className="h-5 w-5" />
            </span>
            <span className="text-sm font-semibold">{t.label}</span>
            {theme === t.key && <Check className="ml-auto h-4 w-4" />}
          </button>
        ))}
      </div>

      <div className="mt-6 mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        Dichte
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {[
          { key: "comfort", label: "Komfortabel", fa: "راحت" },
          { key: "compact", label: "Kompakt", fa: "فشرده" },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setDensity(t.key as typeof density)}
            className={`rounded-2xl border p-4 text-left transition ${
              density === t.key
                ? "border-foreground bg-foreground/5"
                : "border-border hover:border-foreground/30"
            }`}
          >
            <div className="text-sm font-semibold">{t.label}</div>
            <FaHint>{t.fa}</FaHint>
          </button>
        ))}
      </div>

      <div className="mt-6">
        <ToggleRow
          title="Animationen reduzieren"
          fa="کاهش انیمیشن‌ها"
          checked={motionReduce}
          onChange={setMotion}
        />
      </div>
    </Panel>
  );
}

export function LanguagePanel() {
  /* سشن ۹: زبان رابط از تنظیمات کاربر می‌آید. */
  const { settings, save } = useSettings();
  return (
    <Panel title="Sprache & Region" fa="زبان و منطقه">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Oberflächensprache">
          <Select
            value={settings.ui_language}
            onChange={(e) => save({ ui_language: e.target.value as "de" | "fa" })}
          >
            <option value="de">Deutsch</option>
            <option value="fa">فارسی</option>
          </Select>
        </Field>
        <Field label="Muttersprache">
          <Select defaultValue="fa">
            <option value="fa">Persisch (فارسی)</option>
            <option value="tr">Türkçe</option>
            <option value="ar">العربية</option>
            <option value="en">English</option>
          </Select>
        </Field>
        <Field label="Zeitzone">
          <Select defaultValue="Europe/Berlin">
            <option>Europe/Berlin</option>
            <option>Asia/Tehran</option>
            <option>Europe/Vienna</option>
            <option>Europe/Zurich</option>
          </Select>
        </Field>
        <Field label="CEFR-Ziel">
          <Select defaultValue="B2">
            {["A1", "A2", "B1", "B2", "C1", "C2"].map((l) => (
              <option key={l}>{l}</option>
            ))}
          </Select>
        </Field>
      </div>
    </Panel>
  );
}

export function SecurityPanel() {
  return (
    <>
      <Panel title="Passwort ändern" fa="تغییر رمز عبور">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Aktuelles Passwort">
            <Input type="password" />
          </Field>
          <div />
          <Field label="Neues Passwort">
            <Input type="password" />
          </Field>
          <Field label="Neues Passwort bestätigen">
            <Input type="password" />
          </Field>
        </div>
        <div className="mt-4 flex justify-between">
          <Link
            to="/passwort-vergessen"
            className="text-xs font-semibold text-muted-foreground hover:text-foreground"
          >
            Passwort vergessen?
          </Link>
          <PrimaryBtn>
            <Check className="h-4 w-4" /> Aktualisieren
          </PrimaryBtn>
        </div>
      </Panel>

      <Panel title="Zwei-Faktor-Authentifizierung" fa="احراز هویت دومرحله‌ای">
        <ToggleRow
          Icon={Shield}
          title="2FA aktivieren"
          fa="فعال‌سازی احراز دو مرحله‌ای"
          desc="Zusätzlicher Code beim Anmelden."
        />
      </Panel>

      <Panel title="Aktive Sitzungen" fa="نشست‌های فعال">
        <div className="space-y-2">
          {[
            { d: "MacBook Pro · Chrome", loc: "Berlin, DE", now: true },
            { d: "iPhone 15 · DEUSI App", loc: "Berlin, DE", now: false },
            { d: "iPad · Safari", loc: "München, DE", now: false },
          ].map((s, i) => (
            <div
              key={i}
              className="flex items-center justify-between rounded-xl border border-border bg-background/40 p-3"
            >
              <div>
                <div className="text-sm font-semibold">{s.d}</div>
                <div className="text-xs text-muted-foreground">
                  {s.loc} {s.now && "· Diese Sitzung"}
                </div>
              </div>
              {!s.now && <GhostBtn>Beenden</GhostBtn>}
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}
