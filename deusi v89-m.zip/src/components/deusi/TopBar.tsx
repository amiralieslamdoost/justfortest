import { useDeusi } from "@/lib/deusi/store";
import { Link, useRouter } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { BookOpen, Search, Bell, Bookmark, Settings2, LifeBuoy, Crown, X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { Logo } from "./Logo";

export function TopBar() {
  const { currentUser, logout } = useDeusi();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (!currentUser) return null;

  const hour = new Date().getHours();
  const greet = hour < 12 ? "Guten Morgen" : hour < 18 ? "Guten Tag" : "Guten Abend";
  const displayName = currentUser.username || currentUser.email?.split("@")[0] || "Lerner";
  const initials = displayName.slice(0, 2).toUpperCase();

  const handleLogout = () => {
    setOpen(false);
    logout();
    router.navigate({ to: "/login" });
  };

  return (
    <header className="mb-5 grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 border-b border-border/50 px-1 pb-3 sm:mb-6 sm:gap-4 sm:pb-4 sm:px-2">
      <div className="flex items-center gap-2">
        <Link to="/" className="lg:hidden" aria-label="DEUSI">
          <Logo compact />
        </Link>
      </div>

      {/* Greeting — hidden on small screens to reduce redundancy with in-page hero.
          Kept visible on md+ where there is enough horizontal space. */}
      <div className="hidden min-w-0 md:block">
        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          {greet}
        </div>
        <div className="mt-0.5 truncate text-xl font-bold tracking-tight md:text-2xl">
          <span>{displayName}</span> <span aria-hidden>👋</span>
        </div>
      </div>
      {/* Spacer for mobile so the right cluster stays right-aligned */}
      <div className="md:hidden" aria-hidden />

      <div className="flex items-center gap-1.5 sm:gap-2">
        <Link
          to="/suche"
          title="Suche"
          aria-label="Suche"
          className="grid h-11 w-11 place-items-center rounded-full border border-border/60 bg-card text-foreground shadow-sm transition hover:bg-accent hover:text-accent-foreground"
        >
          <Search className="h-5 w-5" />
        </Link>
        <Link
          to="/benachrichtigungen"
          title="Benachrichtigungen"
          aria-label="Benachrichtigungen"
          className="relative grid h-11 w-11 place-items-center rounded-full border border-border/60 bg-card text-foreground shadow-sm transition hover:bg-accent hover:text-accent-foreground"
        >
          <Bell className="h-5 w-5" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[color:var(--flag-red)] ring-2 ring-[color:var(--card)]" />
        </Link>
        <Link
          to="/docs"
          title="راهنما"
          aria-label="راهنما"
          className="grid h-11 w-11 place-items-center rounded-full border border-border/60 bg-card text-foreground shadow-sm transition hover:bg-accent hover:text-accent-foreground"
        >
          <BookOpen className="h-5 w-5" />
        </Link>

        <div ref={menuRef} className="relative">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-haspopup="menu"
            aria-expanded={open}
            aria-label="Profilmenü öffnen"
            className="group relative grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-full text-xs font-black text-white shadow-[0_8px_20px_-8px_rgba(139,92,246,.55)] transition-transform duration-200 hover:-translate-y-0.5 active:translate-y-0"
            style={{ background: "linear-gradient(135deg, #8B5CF6, #DD2222)" }}
          >
            {initials}
            <span
              className="absolute -bottom-0.5 -right-0.5 grid h-3.5 w-3.5 place-items-center rounded-full border-2 border-[color:var(--background)] bg-[#F7C948]"
              aria-hidden
            >
              <span className="h-1 w-1 rounded-full bg-[#7c5a00]" />
            </span>
          </button>

          <AnimatePresence>
            {open && (
              <motion.div
                role="menu"
                initial={{ opacity: 0, y: -8, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.97 }}
                transition={{ duration: 0.2, ease: [0.2, 0.8, 0.2, 1] }}
                className="absolute end-0 top-[calc(100%+10px)] z-50 w-64 origin-top-right overflow-hidden rounded-2xl border border-border/60 bg-[color:var(--card)] shadow-[0_20px_50px_-20px_rgba(0,0,0,.35),0_2px_6px_rgba(0,0,0,.06)]"
              >
                {/* Header */}
                <div
                  className="relative px-4 py-4 text-white"
                  style={{ background: "linear-gradient(135deg, #8B5CF6, #6D28D9 60%, #DD2222)" }}
                >
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    aria-label="Menü schließen"
                    className="absolute end-2 top-2 grid h-7 w-7 place-items-center rounded-full bg-white/15 text-white transition hover:bg-white/30"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                  <div className="flex items-center gap-3">
                    <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white/15 text-sm font-black backdrop-blur">
                      {initials}
                    </div>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold">{displayName}</div>
                      <div className="truncate text-[11px] text-white/75">
                        Level A2 · 14 Tage Serie
                      </div>
                    </div>
                  </div>
                  {/* Subscription pill */}
                  <div className="mt-3 flex items-center justify-between gap-2 rounded-xl bg-white/12 px-3 py-2 backdrop-blur">
                    <div className="flex items-center gap-2">
                      <span
                        aria-hidden
                        className="grid h-6 w-6 place-items-center rounded-lg bg-[#F7C948] text-[11px]"
                      >
                        👑
                      </span>
                      <div className="min-w-0">
                        <div className="text-[10px] font-semibold uppercase tracking-wider text-white/70">
                          Abonnement
                        </div>
                        <div className="text-xs font-bold">Premium · Aktiv</div>
                      </div>
                    </div>
                    <span className="rounded-full bg-[#22C55E] px-1.5 py-0.5 text-[9px] font-bold text-white">
                      28 T
                    </span>
                  </div>
                </div>

                {/* Menu items */}
                <div className="p-1.5">
                  <MenuItem
                    to="/profil"
                    onSelect={() => setOpen(false)}
                    icon={<UserIcon />}
                    label="Mein Profil"
                    sub="Statistiken & Einstellungen"
                  />
                  <MenuItem
                    to="/lesezeichen"
                    onSelect={() => setOpen(false)}
                    icon={<Bookmark className="h-3.5 w-3.5" />}
                    label="Lesezeichen"
                    sub="Gespeicherte Inhalte"
                  />
                  <MenuItem
                    to="/abonnement"
                    onSelect={() => setOpen(false)}
                    icon={<Crown className="h-3.5 w-3.5" />}
                    label="Mein Abonnement"
                    sub="Premium · verlängert am 15. Aug"
                    accent="#F7C948"
                  />
                  <MenuItem
                    to="/einstellungen"
                    onSelect={() => setOpen(false)}
                    icon={<Settings2 className="h-3.5 w-3.5" />}
                    label="Einstellungen"
                    sub="Konto, Datenschutz, Sprache"
                  />
                  <MenuItem
                    to="/statistiken"
                    onSelect={() => setOpen(false)}
                    icon={<ChartIcon />}
                    label="Statistiken"
                    sub="Dein Lernverlauf"
                  />
                  <MenuItem
                    to="/support"
                    onSelect={() => setOpen(false)}
                    icon={<LifeBuoy className="h-3.5 w-3.5" />}
                    label="Hilfe & Support"
                    sub="FAQ, Kontakt, Fehler melden"
                  />
                  <div className="my-1 h-px bg-border/60" />
                  <button
                    type="button"
                    role="menuitem"
                    onClick={handleLogout}
                    className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-[color:var(--flag-red)]/10"
                  >
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[color:var(--flag-red)]/12 text-[color:var(--flag-red)]">
                      <LogoutIcon />
                    </span>
                    <span className="flex-1">
                      <span className="block text-sm font-semibold text-[color:var(--flag-red)]">
                        Abmelden
                      </span>
                      <span className="block text-[11px] text-muted-foreground">
                        Sitzung beenden
                      </span>
                    </span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}

function MenuItem({
  to,
  hash,
  icon,
  label,
  sub,
  accent,
  onSelect,
}: {
  to: "/profil" | "/statistiken" | "/lesezeichen" | "/abonnement" | "/einstellungen" | "/support";
  hash?: string;
  icon: React.ReactNode;
  label: string;
  sub?: string;
  accent?: string;
  onSelect?: () => void;
}) {
  return (
    <Link
      to={to}
      hash={hash}
      onClick={onSelect}
      role="menuitem"
      className="flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors hover:bg-secondary"
    >
      <span
        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg"
        style={{ background: (accent ?? "#8B5CF6") + "1f", color: accent ?? "#6D28D9" }}
      >
        {icon}
      </span>
      <span className="flex-1 min-w-0">
        <span className="block truncate text-sm font-semibold text-foreground">{label}</span>
        {sub && <span className="block truncate text-[11px] text-muted-foreground">{sub}</span>}
      </span>
      <span aria-hidden className="text-muted-foreground">
        ›
      </span>
    </Link>
  );
}

function UserIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" />
    </svg>
  );
}
function CrownIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 8l4 6 5-9 5 9 4-6-2 12H5L3 8z" />
    </svg>
  );
}
function ChartIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 20V10" />
      <path d="M10 20V4" />
      <path d="M16 20v-8" />
      <path d="M22 20H2" />
    </svg>
  );
}
function LogoutIcon() {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
      <path d="M10 17l-5-5 5-5" />
      <path d="M15 12H5" />
    </svg>
  );
}
