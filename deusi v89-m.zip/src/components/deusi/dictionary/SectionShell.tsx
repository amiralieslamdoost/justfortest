import type { ReactNode } from "react";

interface Props {
  index: number;
  icon: string;
  title: string;
  subtitle?: string;
  /** Hex color driving the accent (badge, stripe, glow). */
  accent: string;
  /** Optional action rendered top-right (e.g. filter toggle, small button). */
  action?: ReactNode;
  /** Optional anchor id so the section-nav can jump to it. */
  anchorId?: string;
  /** Optional ref for scroll targeting. */
  innerRef?: React.Ref<HTMLElement>;
  children: ReactNode;
  /** Extra class merged onto the section root. */
  className?: string;
}

/**
 * Shared "chapter" shell for dictionary sections.
 * Provides a consistent visual signal — numbered chip, colored icon,
 * accent stripe, and soft accent glow — so the user can tell where one
 * section ends and the next begins while scrolling.
 */
export function SectionShell({
  index,
  icon,
  title,
  subtitle,
  accent,
  action,
  anchorId,
  innerRef,
  children,
  className = "",
}: Props) {
  return (
    <section
      ref={innerRef}
      id={anchorId}
      className={`neu-card relative scroll-mt-24 overflow-hidden p-4 sm:p-6 ${className}`}
    >
      {/* Left accent stripe — the strongest section signal */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-y-6 left-0 w-1 rounded-r-full"
        style={{ background: `linear-gradient(180deg, ${accent}, ${accent}55)` }}
      />
      {/* Soft accent glow in the top-right */}
      <span
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-30 blur-3xl"
        style={{ background: `radial-gradient(circle, ${accent}80, transparent 70%)` }}
      />

      <header className="relative mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 sm:mb-5">
        <div className="flex min-w-0 items-center gap-3">
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-xl shadow-sm ring-1"
            style={{
              background: `linear-gradient(135deg, ${accent}22, ${accent}0d)`,
              color: accent,
              boxShadow: `0 6px 18px -8px ${accent}80`,
              // @ts-expect-error CSS custom prop
              "--tw-ring-color": `${accent}40`,
            }}
          >
            <span aria-hidden>{icon}</span>
          </span>
          <div className="min-w-0">
            <div className="mb-0.5 flex items-center gap-1.5">
              <span
                className="rounded-full px-1.5 py-px text-[9px] font-black tracking-widest"
                style={{ background: `${accent}1a`, color: accent }}
              >
                {String(index).padStart(2, "0")}
              </span>
              <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                Abschnitt
              </span>
            </div>
            <h2 className="truncate text-base font-black tracking-tight sm:text-lg">{title}</h2>
            {subtitle && (
              <p className="mt-0.5 truncate text-[11px] text-muted-foreground sm:text-xs">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        {action && <div className="hidden shrink-0 sm:block">{action}</div>}
      </header>

      {/* On phones the action (filters, toggles) gets its own full-width row
          so long German labels never squeeze the section title. */}
      {action && <div className="relative mb-4 sm:hidden">{action}</div>}

      <div className="relative">{children}</div>
    </section>
  );
}
