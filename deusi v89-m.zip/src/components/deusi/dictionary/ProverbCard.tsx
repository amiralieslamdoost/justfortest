import { useState } from "react";
import type { Proverb } from "@/lib/deusi/dictionary/proverbs";

/** Flip-Karte für Sprichwörter & Redewendungen. */
export function ProverbCard({ p }: { p: Proverb }) {
  const [flipped, setFlipped] = useState(false);
  return (
    <button
      onClick={() => setFlipped((v) => !v)}
      aria-pressed={flipped}
      className={`group relative flex min-h-[170px] cursor-pointer flex-col justify-between overflow-hidden rounded-2xl p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${
        flipped ? "border-2 shadow-lg ring-2 ring-offset-1" : "border border-border/70 bg-card"
      }`}
      style={
        flipped
          ? {
              background: `linear-gradient(135deg, ${p.color}30, ${p.color}12 60%, ${p.color}05)`,
              borderColor: p.color,
              boxShadow: `0 8px 24px -8px ${p.color}55`,
            }
          : { background: `linear-gradient(135deg, ${p.color}12, transparent 70%)` }
      }
    >
      <div className="flex items-start justify-between gap-2">
        <span
          className="grid h-9 w-9 place-items-center rounded-xl text-lg"
          style={{ background: `${p.color}22`, color: p.color }}
        >
          {p.icon}
        </span>
        <span
          className="rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider"
          style={{ background: `${p.color}18`, color: p.color }}
        >
          {p.kind === "sprichwort" ? "Sprichwort" : "Redewendung"} · {p.cefr}
        </span>
      </div>
      {!flipped ? (
        <div>
          <p className="mt-3 text-sm font-bold leading-snug">„{p.de}"</p>
          <p className="mt-1 text-[11px] italic text-muted-foreground">{p.literal}</p>
        </div>
      ) : (
        <div>
          <p className="mt-3 text-xs leading-relaxed">{p.meaning}</p>
          <p
            dir="rtl"
            lang="fa"
            className="mt-2 text-sm font-semibold"
            style={{ fontFamily: "Vazirmatn, Sora, sans-serif", color: p.color }}
          >
            {p.fa}
          </p>
          {p.example && (
            <p className="mt-1 text-[11px] italic text-muted-foreground">„{p.example}"</p>
          )}
        </div>
      )}
      <span className="mt-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
        {flipped ? "Zurück" : "Tippen für Bedeutung"}
      </span>
    </button>
  );
}
