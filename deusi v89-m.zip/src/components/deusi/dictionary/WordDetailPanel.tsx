import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import { POS_LABEL } from "@/lib/deusi/dictionary/categories";
import { CefrBadge, ArticlePill, FrequencyBar } from "./Badges";
import { AiToolsPanel } from "./AiTools";
import { findById, ALL_WORDS } from "@/lib/deusi/dictionary/mockWords";

type Tab = "overview" | "examples" | "grammar" | "family";
const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "overview", label: "Info", icon: "📖" },
  { id: "examples", label: "Sätze", icon: "💬" },
  { id: "grammar", label: "Gramm.", icon: "🔤" },
  { id: "family", label: "Familie", icon: "🌿" },
];

function posColor(pos: string): string {
  return (
    (
      {
        noun: "#2563eb",
        verb: "#F97316",
        adjective: "#F7C948",
        adverb: "#0EA5E9",
        preposition: "#8B5CF6",
        conjunction: "#EAB308",
        pronoun: "#EC4899",
      } as Record<string, string>
    )[pos] ?? "#94A3B8"
  );
}

function speak(text: string, lang = "de-DE") {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang;
    window.speechSynthesis.speak(u);
  } catch (err) {
    console.warn("speech synthesis unavailable", err);
  }
}

interface Props {
  word: DictWord;
  favorite: boolean;
  inLeitner?: boolean;
  bookmarked?: boolean;
  onClose: () => void;
  onToggleFavorite: () => void;
  onToggleLeitner?: () => void;
  onToggleBookmark?: () => void;
  onOpenWord: (id: string) => void;
}

export function WordDetailPanel({
  word,
  favorite,
  inLeitner,
  bookmarked,
  onClose,
  onToggleFavorite,
  onToggleLeitner,
  onToggleBookmark,
  onOpenWord,
}: Props) {
  const [tab, setTab] = useState<Tab>("overview");
  const article = word.nounGrammar?.article;
  const isNoun = word.pos === "noun";
  const bannerColor =
    isNoun && article
      ? article === "der"
        ? "#2563eb"
        : article === "die"
          ? "#DD2222"
          : "#22C55E"
      : posColor(word.pos);
  return (
    <motion.aside
      key={word.id}
      initial={{ x: 40, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 40, opacity: 0 }}
      transition={{ type: "spring", stiffness: 220, damping: 26 }}
      className="glass-strong relative flex h-full min-h-0 w-full flex-col overflow-hidden rounded-3xl"
    >
      {/* Header */}
      <div className="relative z-10 flex items-center justify-between border-b border-white/10 px-5 py-3">
        <button onClick={onClose} className="btn-back">
          <span aria-hidden>←</span> Zurück
        </button>
        <div className="flex items-center gap-1">
          {onToggleLeitner && (
            <button
              onClick={onToggleLeitner}
              title={inLeitner ? "Im Leitner-Kasten" : "Zum Leitner-Kasten"}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                inLeitner
                  ? "bg-red-500 text-white shadow-md hover:bg-red-600"
                  : "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow hover:shadow-lg"
              }`}
              aria-label="Leitner"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill={inLeitner ? "currentColor" : "none"}
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinejoin="round"
              >
                <path d="M3 7l9-4 9 4-9 4-9-4z" />
                <path d="M3 12l9 4 9-4" />
                <path d="M3 17l9 4 9-4" />
              </svg>
              {inLeitner ? "Im Kasten" : "Leitner"}
            </button>
          )}
          {onToggleBookmark && (
            <button
              onClick={onToggleBookmark}
              title={bookmarked ? "Lesezeichen entfernen" : "Lesezeichen setzen"}
              aria-label="Lesezeichen"
              aria-pressed={bookmarked}
              className={`grid h-8 w-8 place-items-center rounded-full transition ${
                bookmarked
                  ? "bg-amber-400 text-white shadow-md hover:bg-amber-500"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill={bookmarked ? "currentColor" : "none"}
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinejoin="round"
              >
                <path d="M6 3h12v18l-6-4-6 4V3z" />
              </svg>
            </button>
          )}
        </div>
      </div>

      <div className="min-h-0 flex-1 touch-pan-y overflow-y-auto overscroll-contain px-4 py-4 sm:px-5">
        {/* Word title */}
        <div className="flex items-start justify-between gap-3 sm:gap-4">
          <div className="flex-1">
            <div className="flex min-w-0 flex-wrap items-baseline gap-2 sm:gap-3">
              {word.nounGrammar && <ArticlePill article={word.nounGrammar.article} />}
              <h1 className="min-w-0 break-words text-3xl font-bold tracking-tight sm:text-4xl">
                {word.headword}
              </h1>
              <button
                onClick={() => speak(word.headword)}
                className="grid h-9 w-9 place-items-center rounded-full text-white shadow-lg transition hover:scale-105"
                style={{ background: "linear-gradient(135deg, #8B5CF6, #EC4899)" }}
                aria-label="Aussprache"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3 10v4h4l5 5V5L7 10H3zm14.5 2a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4z" />
                </svg>
              </button>
            </div>
            <div className="mt-1 text-sm text-muted-foreground">{word.ipa}</div>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span className="font-medium capitalize">{POS_LABEL[word.pos]}</span>
              {word.verbGrammar && (
                <>
                  <span>·</span>
                  <span>{word.verbGrammar.regular ? "regelmäßig" : "unregelmäßig"}</span>
                  <span>·</span>
                  <span>{word.verbGrammar.aux}</span>
                </>
              )}
              {word.nounGrammar && (
                <>
                  <span>·</span>
                  <span>Plural: {word.nounGrammar.plural}</span>
                </>
              )}
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <CefrBadge level={word.cefr} size="md" />
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span>Häufigkeit:</span>
                <FrequencyBar value={word.frequency} />
              </div>
            </div>
          </div>
          <button
            onClick={onToggleFavorite}
            className="grid h-10 w-10 place-items-center rounded-full transition hover:scale-110"
            aria-label="Favorit"
          >
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill={favorite ? "#DD2222" : "none"}
              stroke={favorite ? "#DD2222" : "currentColor"}
              strokeWidth="1.8"
            >
              <path d="M12 21s-7-4.35-7-10a4.5 4.5 0 0 1 8-2.9 4.5 4.5 0 0 1 8 2.9c0 5.65-9 10-9 10z" />
            </svg>
          </button>
        </div>

        {/* Primary meaning — always visible at a glance */}
        <PrimaryMeaningCard word={word} tint={bannerColor} />

        {/* Tabs — fit-to-width, no scroll */}
        <div className="mt-5 grid grid-cols-4 gap-1 rounded-full bg-muted/50 p-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex min-w-0 items-center justify-center gap-1 rounded-full px-1 py-1.5 text-[11px] font-semibold transition sm:text-xs ${
                tab === t.id
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <span aria-hidden className="text-[13px] leading-none">
                {t.icon}
              </span>
              <span className="truncate">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Tab body */}
        <div className="mt-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.18 }}
            >
              {tab === "overview" && <OverviewTab word={word} />}
              {tab === "examples" && <ExamplesTab word={word} />}
              {tab === "grammar" && <GrammarTab word={word} />}
              {tab === "family" && <FamilyTab word={word} onOpen={onOpenWord} />}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* AI tools */}
        <div className="mt-6">
          <AiToolsPanel word={word} />
        </div>
      </div>
    </motion.aside>
  );
}

// ============ Primary meaning hero ============

function PrimaryMeaningCard({ word, tint }: { word: DictWord; tint: string }) {
  const primary = word.meanings?.[0];
  if (!primary) return null;
  const extraCount = (word.meanings?.length ?? 1) - 1;
  return (
    <div
      className="relative mt-5 overflow-hidden rounded-2xl border p-4 sm:p-5"
      style={{
        borderColor: `${tint}55`,
        background: `linear-gradient(135deg, ${tint}18 0%, ${tint}08 60%, transparent 100%)`,
        boxShadow: `0 8px 24px -12px ${tint}55`,
      }}
    >
      <div className="flex items-center gap-2">
        <span
          className="rounded-full px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-white shadow-sm"
          style={{ background: tint }}
        >
          Bedeutung
        </span>
        {extraCount > 0 && (
          <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            +{extraCount} weitere
          </span>
        )}
      </div>
      <p className="mt-2 text-lg font-semibold leading-snug text-foreground sm:text-xl">
        {primary.de}
      </p>
      {(primary.en || primary.fa) && (
        <div className="mt-3 flex flex-col gap-1.5">
          {primary.fa && (
            <div className="flex items-baseline gap-2">
              <span className="rounded bg-white/70 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-muted-foreground shadow-sm dark:bg-slate-900/60">
                FA
              </span>
              <span dir="rtl" className="fa-inline text-base font-medium text-foreground/90">
                {primary.fa}
              </span>
            </div>
          )}
          {primary.en && (
            <div className="flex items-baseline gap-2">
              <span className="rounded bg-white/70 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-muted-foreground shadow-sm dark:bg-slate-900/60">
                EN
              </span>
              <span className="text-sm italic text-foreground/80">{primary.en}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============ Overview ============

function OverviewTab({ word }: { word: DictWord }) {
  const extraMeanings = word.meanings.slice(1);
  return (
    <div className="space-y-4">
      {extraMeanings.length > 0 && (
        <Section title="Weitere Bedeutungen">
          <ol className="space-y-2 text-sm">
            {extraMeanings.map((m, i) => (
              <li key={i} className="flex gap-2.5">
                <span className="mt-1 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-primary/10 text-[9px] font-bold text-primary">
                  {i + 2}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-sm leading-snug">{m.de}</div>
                  {(m.en || m.fa) && (
                    <div className="mt-0.5 flex flex-wrap items-baseline gap-x-3 gap-y-0.5 text-[11px]">
                      {m.fa && (
                        <span dir="rtl" className="fa-inline text-foreground/70">
                          {m.fa}
                        </span>
                      )}
                      {m.en && <span className="italic text-muted-foreground">{m.en}</span>}
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </Section>
      )}

      <Section title="Details">
        <div className="flex flex-wrap gap-1.5">
          <InfoChip k="Wortart" v={POS_LABEL[word.pos]} />
          <InfoChip k="Niveau" v={word.cefr} />
          <InfoChip k="Häufigkeit" v={`${word.frequency}%`} />
          <InfoChip k="Schwierigkeit" v={"⭐".repeat(word.difficulty)} />
          {word.nounGrammar && (
            <>
              <InfoChip
                k="Genus"
                v={{ m: "maskulin", f: "feminin", n: "neutral" }[word.nounGrammar.gender]}
              />
              <InfoChip k="Plural" v={word.nounGrammar.plural} />
              <InfoChip k="Genitiv" v={word.nounGrammar.genitive} />
            </>
          )}
        </div>
        {word.usage && <p className="mt-3 text-xs italic text-muted-foreground">{word.usage}</p>}
      </Section>
    </div>
  );
}

function InfoChip({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <span className="inline-flex items-baseline gap-1 rounded-full border border-border/60 bg-muted/40 px-2.5 py-1 text-[11px]">
      <span className="font-semibold text-muted-foreground">{k}</span>
      <span className="font-medium text-foreground">{v}</span>
    </span>
  );
}

// ============ Examples ============

function ExamplesTab({ word }: { word: DictWord }) {
  return (
    <Section title="Beispielsätze">
      <div className="space-y-2">
        {word.examples.map((e) => (
          <div key={e.id} className="rounded-2xl border border-border/60 bg-card p-3">
            <div className="flex items-start justify-between gap-2">
              <p className="text-sm">{highlightWord(e.de, word.headword)}</p>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => speak(e.de)}
                  className="grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition hover:bg-muted"
                  aria-label="Vorlesen"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3 10v4h4l5 5V5L7 10H3z" />
                  </svg>
                </button>
                <button
                  className="grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition hover:bg-muted"
                  aria-label="Übersetzen"
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                  >
                    <path d="M4 5h9M9 3v2c0 5-2 8-6 10M5 9c0 4 4 7 9 8" />
                    <path d="M13 20l4-9 4 9M15 17h4" />
                  </svg>
                </button>
                <button
                  className="grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition hover:bg-muted"
                  aria-label="Merken"
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                  >
                    <path d="M6 3h12v18l-6-4-6 4V3z" />
                  </svg>
                </button>
              </div>
            </div>
            <p className="mt-1 text-xs italic text-muted-foreground">{e.en}</p>
            {e.fa && (
              <p dir="rtl" className="fa-inline mt-0.5 text-xs text-foreground/70">
                {e.fa}
              </p>
            )}
          </div>
        ))}
      </div>
    </Section>
  );
}

function highlightWord(text: string, word: string) {
  const stem = word.replace(/en$/, "").replace(/e$/, "");
  const re = new RegExp(`(${stem}\\w*)`, "gi");
  const parts = text.split(re);
  return parts.map((p, i) =>
    re.test(p) ? (
      <mark
        key={i}
        className="rounded bg-purple-100 px-1 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300"
      >
        {p}
      </mark>
    ) : (
      <span key={i}>{p}</span>
    ),
  );
}

// ============ Grammar ============

function GrammarTab({ word }: { word: DictWord }) {
  if (word.nounGrammar) {
    const g = word.nounGrammar;
    const color =
      g.article === "der" ? "var(--der)" : g.article === "die" ? "var(--die)" : "var(--das)";
    return (
      <div className="space-y-3">
        <div className="rounded-2xl border border-border/60 bg-card p-4">
          <div className="mb-2 text-xs uppercase tracking-widest text-muted-foreground">
            Substantiv
          </div>
          <div className="flex flex-wrap items-baseline gap-3">
            <span className="text-2xl font-bold" style={{ color }}>
              {g.article}
            </span>
            <span className="text-2xl font-bold">{word.headword}</span>
          </div>
          <dl className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <Fact k="Genus" v={{ m: "maskulin", f: "feminin", n: "neutral" }[g.gender]} />
            <Fact k="Plural" v={g.plural} />
            <Fact k="Genitiv" v={g.genitive} />
            <Fact k="Deklination" v={g.declension ?? "regulär"} />
          </dl>
        </div>
      </div>
    );
  }
  if (word.verbGrammar) {
    const v = word.verbGrammar;
    const preps: NonNullable<typeof v.governedPrepositions> = [
      ...(v.governedPrepositions ?? []),
      ...(v.governedPreposition ? [v.governedPreposition] : []),
    ];
    const caseColor: Record<string, string> = { Akk: "#DD2222", Dat: "#2563EB", Gen: "#059669" };
    return (
      <div className="space-y-4">
        {/* Verb grammar summary badges */}
        <div className="flex flex-wrap gap-1.5">
          <GrammarBadge
            label={v.regular ? "regelmäßig" : "unregelmäßig"}
            tint={v.regular ? "#059669" : "#DC2626"}
          />
          <GrammarBadge
            label={`Hilfsverb: ${v.aux}`}
            tint={v.aux === "haben" ? "#2563EB" : "#7C3AED"}
          />
          {v.separable && <GrammarBadge label="trennbar" tint="#F59E0B" />}
          {v.reflexive && <GrammarBadge label="reflexiv (sich)" tint="#EC4899" />}
          {v.objectCase && v.objectCase !== "none" && (
            <GrammarBadge
              label={`Objekt: ${v.objectCase}`}
              tint={caseColor[v.objectCase] ?? "#6B7280"}
            />
          )}
          {v.objectCase === "none" && <GrammarBadge label="intransitiv" tint="#6B7280" />}
        </div>

        {preps.length > 0 && (
          <div className="rounded-2xl border border-border/60 bg-gradient-to-br from-purple-50 to-pink-50 p-4 dark:from-purple-950/40 dark:to-pink-950/40">
            <div className="mb-2 text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
              Feste Präpositionen
            </div>
            <div className="space-y-2">
              {preps.map((p, i) => (
                <div
                  key={i}
                  className="flex flex-wrap items-center gap-2 rounded-xl bg-white/80 p-2 dark:bg-slate-900/60"
                >
                  <span className="font-bold">{word.headword}</span>
                  <span className="text-muted-foreground">+</span>
                  <span className="rounded-lg bg-purple-600 px-2 py-0.5 text-sm font-bold text-white">
                    {p.text}
                  </span>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-black text-white shadow"
                    style={{ background: caseColor[p.case] ?? "#6B7280" }}
                  >
                    + {p.case}
                  </span>
                  {p.example && (
                    <span className="basis-full text-xs italic text-muted-foreground">
                      „{p.example}"
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <Section title="Konjugation (Präsens)">
          <ConjTable c={v.praesens} />
        </Section>
        <Section title="Konjugation (Präteritum)">
          <ConjTable c={v.praeteritumConj} />
        </Section>
        <Section title="Perfekt">
          <ConjTable c={v.perfektConj} />
        </Section>
        <div className="rounded-2xl border border-border/60 bg-card p-3">
          <dl className="grid grid-cols-2 gap-2 text-xs">
            <Fact k="Trennbar" v={v.separable ? "ja" : "nein"} />
            <Fact k="Regelmäßig" v={v.regular ? "ja" : "nein"} />
            <Fact k="Hilfsverb" v={v.aux} />
            <Fact k="Präteritum" v={v.praeteritum} />
            <Fact k="Perfekt" v={v.perfekt} />
            <Fact k="Partizip II" v={v.partizipII} />
            {v.objectCase && (
              <Fact k="Objekt-Kasus" v={v.objectCase === "none" ? "intransitiv" : v.objectCase} />
            )}
            {v.reflexive != null && <Fact k="Reflexiv" v={v.reflexive ? "ja" : "nein"} />}
          </dl>
        </div>
      </div>
    );
  }
  if (word.adjectiveGrammar) {
    const a = word.adjectiveGrammar;
    return (
      <div className="space-y-3">
        <div className="rounded-2xl border border-border/60 bg-card p-4">
          <div className="grid grid-cols-3 gap-2 text-center text-sm">
            <div>
              <div className="text-xs text-muted-foreground">Positiv</div>
              <div className="font-semibold">{word.headword}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Komparativ</div>
              <div className="font-semibold">{a.comparative}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Superlativ</div>
              <div className="font-semibold">{a.superlative}</div>
            </div>
          </div>
        </div>
        <Section title="Attributive Endungen">
          <dl className="grid grid-cols-2 gap-2 text-xs">
            <Fact k="Nominativ" v={a.attributive.nom} />
            <Fact k="Akkusativ" v={a.attributive.akk} />
            <Fact k="Dativ" v={a.attributive.dat} />
            <Fact k="Genitiv" v={a.attributive.gen} />
          </dl>
        </Section>
        <Section title="Häufige Verbindungen">
          <div className="flex flex-wrap gap-1.5">
            {a.collocations.map((c) => (
              <span key={c} className="rounded-full bg-muted px-2.5 py-1 text-xs">
                {c}
              </span>
            ))}
          </div>
        </Section>
      </div>
    );
  }
  if (word.adverbGrammar) {
    return (
      <div className="space-y-3">
        <Section title="Verwendung">
          <p className="text-sm">{word.adverbGrammar.usage}</p>
        </Section>
        <Section title="Satzposition">
          <p className="text-sm">{word.adverbGrammar.position}</p>
        </Section>
      </div>
    );
  }
  if (word.prepositionGrammar) {
    const p = word.prepositionGrammar;
    return (
      <div className="space-y-3">
        <Section title="Benötigter Kasus">
          <div className="flex gap-2">
            {p.cases.map((c) => (
              <span
                key={c}
                className="rounded-full bg-purple-100 px-3 py-1 text-xs font-semibold text-purple-700 dark:bg-purple-900/40 dark:text-purple-300"
              >
                {c}
              </span>
            ))}
          </div>
        </Section>
        <Section title="Beispiele">
          <ul className="space-y-1 text-sm">
            {p.examples.map((ex, i) => (
              <li key={i}>• {ex}</li>
            ))}
          </ul>
        </Section>
      </div>
    );
  }
  return <p className="text-sm text-muted-foreground">Keine Grammatikinformationen verfügbar.</p>;
}

function ConjTable({ c }: { c: NonNullable<DictWord["verbGrammar"]>["praesens"] }) {
  const rows: [string, string, string, string][] = [
    ["ich", c.ich, "wir", c.wir],
    ["du", c.du, "ihr", c.ihr],
    ["er/sie/es", c.er, "sie/Sie", c.sie],
  ];
  return (
    <div className="overflow-hidden rounded-2xl border border-border/60 bg-card">
      <table className="w-full text-sm">
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={i % 2 ? "bg-muted/40" : ""}>
              <td className="px-3 py-2 text-xs text-muted-foreground">{r[0]}</td>
              <td className="px-3 py-2 font-medium">{r[1]}</td>
              <td className="px-3 py-2 text-xs text-muted-foreground">{r[2]}</td>
              <td className="px-3 py-2 font-medium">{r[3]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============ Word Family ============

function FamilyTab({ word, onOpen }: { word: DictWord; onOpen: (id: string) => void }) {
  const f = word.family;
  const groups: [string, string[]][] = [
    ["Synonyme", f.synonyms],
    ["Antonyme", f.antonyms],
    ["Ähnliche Wörter", f.similar],
    ["Zusammensetzungen", f.compounds],
    ["Verwandte Verben", f.relatedVerbs],
    ["Verwandte Substantive", f.relatedNouns],
    ["Verwandte Adjektive", f.relatedAdjectives],
  ];
  return (
    <div className="space-y-3">
      {groups.map(([label, items]) =>
        items.length ? (
          <Section key={label} title={label}>
            <div className="flex flex-wrap gap-1.5">
              {items.map((item) => {
                const target = findByHeadword(item);
                return (
                  <button
                    key={item}
                    onClick={() => target && onOpen(target.id)}
                    disabled={!target}
                    className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                      target
                        ? "bg-muted hover:bg-primary hover:text-primary-foreground"
                        : "bg-muted/60 text-muted-foreground"
                    }`}
                  >
                    {item}
                  </button>
                );
              })}
            </div>
          </Section>
        ) : null,
      )}
    </div>
  );
}

function findByHeadword(hw: string): DictWord | undefined {
  const norm = hw.toLowerCase();
  return ALL_WORDS.find((w) => w.headword.toLowerCase() === norm || w.lemma === norm);
}
export function _findByHeadword(hw: string) {
  return findById(hw);
}

// ============ Small primitives ============

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border/60 bg-card/60 p-4">
      <div className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        {title}
      </div>
      {children}
    </div>
  );
}
function Fact({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl bg-muted/50 px-3 py-2">
      <dt className="text-[10px] uppercase tracking-wider text-muted-foreground">{k}</dt>
      <dd className="mt-0.5 font-medium">{v}</dd>
    </div>
  );
}
function GrammarBadge({ label, tint }: { label: string; tint: string }) {
  return (
    <span
      className="rounded-full px-2.5 py-1 text-[11px] font-semibold text-white shadow-sm"
      style={{ background: tint }}
    >
      {label}
    </span>
  );
}
