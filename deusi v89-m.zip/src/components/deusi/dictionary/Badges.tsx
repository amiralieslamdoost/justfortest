import { CEFR_COLOR, POS_COLOR, POS_SHORT } from "@/lib/deusi/dictionary/categories";
import type { CEFR, DictPos, Article } from "@/lib/deusi/dictionary/types";

export function CefrBadge({ level, size = "sm" }: { level: CEFR; size?: "sm" | "md" }) {
  const color = CEFR_COLOR[level];
  const px = size === "md" ? "px-2.5 py-1 text-xs" : "px-2 py-0.5 text-[10px]";
  return (
    <span
      className={`inline-flex items-center rounded-full font-semibold tracking-wide ${px}`}
      style={{ background: color + "1a", color }}
    >
      {level}
    </span>
  );
}

export function PosBadge({ pos }: { pos: DictPos }) {
  const color = POS_COLOR[pos];
  return (
    <span
      className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[9px] font-medium leading-tight"
      style={{ background: color + "1a", color }}
    >
      {POS_SHORT[pos]}
    </span>
  );
}

export function ArticlePill({ article }: { article: Article }) {
  const color = article === "der" ? "var(--der)" : article === "die" ? "var(--die)" : "var(--das)";
  return (
    <span
      className="inline-flex items-center rounded-md px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-widest"
      style={{ background: `color-mix(in oklab, ${color} 12%, transparent)`, color }}
    >
      {article}
    </span>
  );
}

export function FrequencyBar({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full"
          style={{ width: `${value}%`, background: "linear-gradient(90deg, #8B5CF6, #EC4899)" }}
        />
      </div>
      <span className="text-[10px] text-muted-foreground">{value}%</span>
    </div>
  );
}

export function ProgressBar({ value, color = "#8B5CF6" }: { value: number; color?: string }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
      <div
        className="h-full rounded-full transition-all"
        style={{ width: `${value}%`, background: color }}
      />
    </div>
  );
}
