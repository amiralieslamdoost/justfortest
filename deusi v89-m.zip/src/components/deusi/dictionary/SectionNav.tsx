import { useEffect, useState } from "react";

interface Item {
  id: string;
  label: string;
  icon: string;
  accent: string;
}

interface Props {
  items: Item[];
}

/**
 * Sticky chip bar that jumps to dictionary sections and highlights
 * the section currently on screen. Purely presentational — sections
 * mount their own IntersectionObserver signal via the shared id.
 */
export function SectionNav({ items }: Props) {
  const [active, setActive] = useState<string>(items[0]?.id ?? "");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const targets = items
      .map((i) => document.getElementById(i.id))
      .filter((el): el is HTMLElement => Boolean(el));
    if (!targets.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        // Pick the entry closest to the top of the viewport.
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]?.target.id) setActive(visible[0].target.id);
      },
      { rootMargin: "-30% 0px -60% 0px", threshold: 0 },
    );
    targets.forEach((t) => observer.observe(t));
    return () => observer.disconnect();
  }, [items]);

  const jump = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div
      role="navigation"
      aria-label="Abschnitte des Wörterbuchs"
      className="sticky top-0 z-30 -mx-1 rounded-2xl bg-background/70 px-1 py-2 backdrop-blur-xl"
    >
      <div className="flex gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {items.map((it, i) => {
          const isActive = active === it.id;
          return (
            <button
              key={it.id}
              onClick={() => jump(it.id)}
              className={`group flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
                isActive
                  ? "border-transparent text-white shadow-md"
                  : "border-border/60 bg-card/80 text-muted-foreground hover:-translate-y-0.5 hover:text-foreground"
              }`}
              style={
                isActive
                  ? { background: `linear-gradient(135deg, ${it.accent}, ${it.accent}cc)` }
                  : undefined
              }
              aria-current={isActive ? "true" : undefined}
            >
              <span
                className={`text-[9px] font-black tracking-widest ${
                  isActive ? "text-white/80" : ""
                }`}
                style={!isActive ? { color: it.accent } : undefined}
              >
                {String(i + 1).padStart(2, "0")}
              </span>
              <span aria-hidden>{it.icon}</span>
              <span>{it.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
