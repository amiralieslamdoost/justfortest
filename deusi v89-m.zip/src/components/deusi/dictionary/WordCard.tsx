import { motion } from "framer-motion";
import type { KeyboardEvent, MouseEvent } from "react";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import { CefrBadge, PosBadge, ArticlePill, ProgressBar } from "./Badges";

type OpenEvent = MouseEvent<HTMLElement> | KeyboardEvent<HTMLElement>;

interface WordCardProps {
  word: DictWord;
  progress?: number; // 0..100
  bookmarked?: boolean;
  inLeitner?: boolean;
  variant?: "recommended" | "compact" | "grid" | "row";
  imageUrl?: string;
  onOpen: (event: OpenEvent) => void;
  onToggleBookmark: () => void;
  onToggleLeitner?: () => void;
}

export function WordCard({
  word,
  progress = 0,
  bookmarked = false,
  inLeitner = false,
  variant = "grid",
  imageUrl,
  onOpen,
  onToggleBookmark,
  onToggleLeitner,
}: WordCardProps) {
  const isNoun = word.pos === "noun";
  const article = word.nounGrammar?.article;

  if (variant === "recommended") {
    return (
      <motion.div
        onClick={(event) => onOpen(event)}
        whileHover={{ y: -4 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onOpen(e)}
        className="neu-card group relative flex w-full cursor-pointer flex-col overflow-hidden p-0 text-left"
      >
        <div
          className="relative h-32 w-full overflow-hidden"
          style={{
            background: imageUrl
              ? `url(${imageUrl}) center/cover`
              : `linear-gradient(135deg, ${gradientFor(word)}) `,
          }}
        >
          <div className="absolute right-2 top-2 flex flex-col gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleBookmark();
              }}
              className="grid h-8 w-8 place-items-center rounded-full bg-white/70 backdrop-blur transition hover:bg-white"
              aria-label={bookmarked ? "Lesezeichen entfernen" : "Lesezeichen setzen"}
              aria-pressed={bookmarked}
            >
              <BookmarkIcon filled={bookmarked} />
            </button>
            {onToggleLeitner && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleLeitner();
                }}
                title={inLeitner ? "Im Leitner-Kasten" : "Zum Leitner-Kasten hinzufügen"}
                aria-label="Leitner"
                className={`grid h-8 w-8 place-items-center rounded-full backdrop-blur transition ${
                  inLeitner
                    ? "bg-red-500 text-white shadow-md"
                    : "bg-white/70 text-slate-700 hover:bg-white"
                }`}
              >
                <LeitnerIcon filled={inLeitner} />
              </button>
            )}
          </div>
        </div>
        <div className="flex flex-1 flex-col gap-2 p-4">
          <div className="flex items-baseline justify-between gap-2">
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold">{word.headword}</span>
              <CefrBadge level={word.cefr} />
            </div>
          </div>
          <div className="text-xs font-medium text-muted-foreground">
            {isNoun && article
              ? `${article}, ${genderLabel(article)}`
              : capitalize(posLabel(word.pos))}
          </div>
          <MeaningTriplet word={word} clamp={2} />
          <div className="mt-auto pt-2">
            <div className="mb-1 flex items-center justify-between text-[10px] text-muted-foreground">
              <span>{progress}% bekannt</span>
            </div>
            <ProgressBar value={progress} color={progressColor(progress)} />
          </div>
        </div>
      </motion.div>
    );
  }

  if (variant === "compact") {
    return (
      <button
        onClick={(event) => onOpen(event)}
        className="glass flex items-center gap-2 rounded-2xl px-3 py-2 text-left transition hover:-translate-y-0.5 hover:shadow-lg"
      >
        <span
          className="grid h-8 w-8 place-items-center rounded-full text-sm"
          style={{ background: gradientBg(word) }}
        >
          {iconFor(word.pos)}
        </span>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="truncate text-sm font-semibold">{word.headword}</span>
            <CefrBadge level={word.cefr} />
          </div>
        </div>
      </button>
    );
  }

  if (variant === "row") {
    const rowStripe =
      isNoun && article
        ? article === "der"
          ? "#2563eb"
          : article === "die"
            ? "#DD2222"
            : "#22C55E"
        : posStripe(word.pos);
    return (
      <motion.div
        onClick={(event) => onOpen(event)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onOpen(e)}
        className="neu-card group relative flex cursor-pointer items-center gap-3 overflow-hidden border border-border/70 bg-card p-3 pl-4 text-left shadow-sm ring-1 ring-black/[0.03] transition-all hover:border-border hover:shadow-md dark:ring-white/[0.04]"
      >
        <span
          aria-hidden
          className="absolute inset-y-0 left-0 w-1.5"
          style={{ background: rowStripe }}
        />
        <div className="flex w-[38%] min-w-0 items-baseline gap-2 sm:w-[30%]">
          {isNoun && article && (
            <span className="shrink-0">
              <ArticlePill article={article} />
            </span>
          )}
          <span className="block min-w-0 flex-1" style={{ containerType: "inline-size" }}>
            <span
              className="block whitespace-nowrap font-bold leading-tight tracking-tight"
              style={headwordStyle(word.headword)}
            >
              {word.headword}
            </span>
          </span>
        </div>
        <div className="hidden shrink-0 flex-nowrap items-center gap-1.5 sm:flex">
          <PosBadge pos={word.pos} />
          <CefrBadge level={word.cefr} />
        </div>
        <div className="min-w-0 flex-1">
          <MeaningTriplet word={word} clamp={1} />
        </div>
        <CardActions
          bookmarked={bookmarked}
          inLeitner={inLeitner}
          onToggleBookmark={onToggleBookmark}
          onToggleLeitner={onToggleLeitner}
        />
      </motion.div>
    );
  }

  // grid

  const stripeColor =
    isNoun && article
      ? article === "der"
        ? "#2563eb"
        : article === "die"
          ? "#DD2222"
          : "#22C55E"
      : posStripe(word.pos);

  return (
    <motion.div
      onClick={(event) => onOpen(event)}
      whileHover={{ y: -3 }}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onOpen(e)}
      className="neu-card group relative flex cursor-pointer flex-col gap-2 overflow-hidden border border-border/70 bg-card p-4 pb-5 text-left shadow-sm ring-1 ring-black/[0.03] transition-all hover:-translate-y-0.5 hover:border-border hover:shadow-lg dark:ring-white/[0.04]"
    >
      <div className="flex min-h-8 items-baseline gap-2 overflow-hidden">
        {isNoun && article && (
          <span className="shrink-0">
            <ArticlePill article={article} />
          </span>
        )}
        <span className="block min-w-0 flex-1" style={{ containerType: "inline-size" }}>
          <span
            className="block whitespace-nowrap font-bold leading-tight tracking-tight"
            style={headwordStyle(word.headword)}
          >
            {word.headword}
          </span>
        </span>
      </div>
      <div className="flex min-h-7 items-center justify-between gap-1.5">
        <div className="flex shrink-0 flex-nowrap items-center gap-1.5">
          <PosBadge pos={word.pos} />
          <CefrBadge level={word.cefr} />
        </div>
        <CardActions
          bookmarked={bookmarked}
          inLeitner={inLeitner}
          onToggleBookmark={onToggleBookmark}
          onToggleLeitner={onToggleLeitner}
        />
      </div>
      <MeaningTriplet word={word} clamp={2} />

      <span
        aria-hidden
        className="absolute inset-x-0 bottom-0 h-1.5 overflow-hidden rounded-b-2xl opacity-90 transition-all group-hover:h-2 group-hover:opacity-100"
      >
        <span
          className="block h-full w-full"
          style={{
            background: `linear-gradient(90deg, ${stripeColor} 0%, ${stripeColor}cc 50%, ${stripeColor}66 100%)`,
            boxShadow: `0 -2px 8px -2px ${stripeColor}80`,
          }}
        />
        <span
          aria-hidden
          className="pointer-events-none absolute inset-y-0 -left-full block h-full w-1/2 -skew-x-12 bg-white/50 transition-transform duration-700 group-hover:translate-x-[400%]"
        />
      </span>
    </motion.div>
  );
}

export function LeitnerIcon({ filled, small }: { filled?: boolean; small?: boolean }) {
  const s = small ? 13 : 15;
  return (
    <svg
      width={s}
      height={s}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 7l9-4 9 4-9 4-9-4z" />
      <path d="M3 12l9 4 9-4" />
      <path d="M3 17l9 4 9-4" />
    </svg>
  );
}

function posStripe(p: string): string {
  return (
    (
      {
        verb: "#F97316",
        adjective: "#F7C948",
        adverb: "#0EA5E9",
        preposition: "#8B5CF6",
        conjunction: "#EAB308",
        pronoun: "#EC4899",
      } as Record<string, string>
    )[p] ?? "#94A3B8"
  );
}

// helpers
function gradientFor(w: DictWord): string {
  const map: Record<string, string> = {
    noun: "#dbeafe, #a5b4fc",
    verb: "#ede9fe, #ddd6fe",
    adjective: "#dcfce7, #bbf7d0",
    adverb: "#e0f2fe, #bae6fd",
    preposition: "#fce7f3, #fbcfe8",
    conjunction: "#fef3c7, #fde68a",
    pronoun: "#fee2e2, #fecaca",
  };
  return map[w.pos] ?? "#f3f4f6, #e5e7eb";
}
function gradientBg(w: DictWord) {
  return `linear-gradient(135deg, ${gradientFor(w)})`;
}
function progressColor(v: number) {
  if (v >= 80) return "#22C55E";
  if (v >= 50) return "#3B82F6";
  if (v >= 25) return "#8B5CF6";
  return "#F59E0B";
}
function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function posLabel(p: string) {
  return (
    (
      {
        noun: "Substantiv",
        verb: "Verb",
        adjective: "Adjektiv",
        adverb: "Adverb",
        preposition: "Präposition",
        conjunction: "Konjunktion",
        pronoun: "Pronomen",
      } as Record<string, string>
    )[p] ?? p
  );
}
function genderLabel(a: string) {
  return a === "der" ? "maskulin" : a === "die" ? "feminin" : "neutral";
}
function iconFor(p: string) {
  return (
    (
      {
        noun: "📘",
        verb: "⚡",
        adjective: "🎨",
        adverb: "🌀",
        preposition: "🧭",
        conjunction: "🔗",
        pronoun: "👤",
      } as Record<string, string>
    )[p] ?? "•"
  );
}

export function BookmarkIcon({ filled, small }: { filled?: boolean; small?: boolean }) {
  const s = small ? 14 : 16;
  return (
    <svg
      width={s}
      height={s}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      className={filled ? "text-primary" : ""}
    >
      <path d="M6 3h12v18l-6-4-6 4V3z" />
    </svg>
  );
}

// Compact bilingual meaning block used on word cards.
// Shows: EN gloss, then Persian gloss (RTL, YekanBakh). German short definition is omitted.
function MeaningTriplet({ word, clamp = 2 }: { word: DictWord; clamp?: 1 | 2 | 3 }) {
  const en = word.meanings[0]?.en;
  const fa = word.meanings[0]?.fa;
  void clamp;
  return (
    <div className="space-y-0.5">
      {en && (
        <p className="line-clamp-1 text-[11px] italic leading-snug text-muted-foreground/80">
          {en}
        </p>
      )}
      {fa && (
        <p dir="rtl" className="fa-inline line-clamp-1 text-[11px] leading-snug text-foreground/70">
          {fa}
        </p>
      )}
    </div>
  );
}

// Scales the headword font to the available container width so long words stay
// on a single line and are always fully visible (never truncated).
function headwordStyle(headword: string) {
  const len = Math.max(headword.length, 1);
  return {
    fontSize: `clamp(9px, calc(100cqi / ${(len * 0.58).toFixed(2)}), 17px)`,
  };
}

function CardActions({
  bookmarked,
  inLeitner,
  onToggleBookmark,
  onToggleLeitner,
}: {
  bookmarked?: boolean;
  inLeitner?: boolean;
  onToggleBookmark: () => void;
  onToggleLeitner?: () => void;
}) {
  return (
    <div className="flex shrink-0 items-center gap-0.5">
      {onToggleLeitner && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleLeitner();
          }}
          title={inLeitner ? "Im Leitner-Kasten" : "Zum Leitner-Kasten hinzufügen"}
          aria-label="Leitner"
          className={`grid h-8 w-8 shrink-0 place-items-center rounded-full transition ${
            inLeitner
              ? "bg-red-500 text-white shadow-sm"
              : "text-muted-foreground/70 hover:bg-red-50 hover:text-red-600"
          }`}
        >
          <LeitnerIcon filled={inLeitner} small />
        </button>
      )}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onToggleBookmark();
        }}
        className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted-foreground/70 transition hover:bg-muted hover:text-foreground"
        aria-label={bookmarked ? "Lesezeichen entfernen" : "Lesezeichen setzen"}
        aria-pressed={bookmarked}
      >
        <BookmarkIcon filled={bookmarked} small />
      </button>
    </div>
  );
}
