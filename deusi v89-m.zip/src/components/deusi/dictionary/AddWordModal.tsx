import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import type { NewWordInput } from "@/lib/deusi/dictionary/customWords";
import { CATEGORIES, CEFR_LEVELS, POS_LABEL } from "@/lib/deusi/dictionary/categories";
import type { DictPos, CEFR } from "@/lib/deusi/dictionary/types";

interface Props {
  open: boolean;
  onClose: () => void;
  onSubmit: (w: NewWordInput) => void;
}

const POS_OPTIONS: DictPos[] = [
  "noun",
  "verb",
  "adjective",
  "adverb",
  "preposition",
  "conjunction",
  "pronoun",
];

export function AddWordModal({ open, onClose, onSubmit }: Props) {
  const [pos, setPos] = useState<DictPos>("noun");
  const [headword, setHeadword] = useState("");
  const [shortMeaning, setShortMeaning] = useState("");
  const [translationFa, setTranslationFa] = useState("");
  const [translationEn, setTranslationEn] = useState("");
  const [cefr, setCefr] = useState<CEFR>("A2");
  const [category, setCategory] = useState<string>(CATEGORIES[0].id);
  const [ipa, setIpa] = useState("");
  // noun
  const [article, setArticle] = useState<"der" | "die" | "das">("der");
  const [plural, setPlural] = useState("");
  const [genitive, setGenitive] = useState("");
  // verb
  const [aux, setAux] = useState<"haben" | "sein">("haben");
  const [praeteritum, setPraeteritum] = useState("");
  const [partizipII, setPartizipII] = useState("");
  const [separable, setSeparable] = useState(false);
  const [regular, setRegular] = useState(true);
  const [objectCase, setObjectCase] = useState<"Akk" | "Dat" | "Gen" | "none">("Akk");
  const [reflexive, setReflexive] = useState(false);
  const [prepositionText, setPrepositionText] = useState("");
  const [prepositionCase, setPrepositionCase] = useState<"Akk" | "Dat" | "Gen">("Akk");
  // adjective
  const [comparative, setComparative] = useState("");
  const [superlative, setSuperlative] = useState("");
  // examples
  const [ex1, setEx1] = useState("");
  const [ex2, setEx2] = useState("");

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const reset = () => {
    setHeadword("");
    setShortMeaning("");
    setTranslationFa("");
    setTranslationEn("");
    setIpa("");
    setPlural("");
    setGenitive("");
    setPraeteritum("");
    setPartizipII("");
    setSeparable(false);
    setRegular(true);
    setReflexive(false);
    setPrepositionText("");
    setComparative("");
    setSuperlative("");
    setEx1("");
    setEx2("");
  };

  const submit = () => {
    if (!headword.trim() || !shortMeaning.trim()) return;
    onSubmit({
      headword,
      pos,
      cefr,
      category,
      shortMeaning,
      translationFa,
      translationEn,
      ipa,
      article: pos === "noun" ? article : undefined,
      plural: pos === "noun" ? plural : undefined,
      genitive: pos === "noun" ? genitive : undefined,
      aux: pos === "verb" ? aux : undefined,
      praeteritum: pos === "verb" ? praeteritum : undefined,
      partizipII: pos === "verb" ? partizipII : undefined,
      separable: pos === "verb" ? separable : undefined,
      regular: pos === "verb" ? regular : undefined,
      objectCase: pos === "verb" ? objectCase : undefined,
      reflexive: pos === "verb" ? reflexive : undefined,
      prepositionText: pos === "verb" ? prepositionText.trim() || undefined : undefined,
      prepositionCase: pos === "verb" ? prepositionCase : undefined,
      comparative: pos === "adjective" ? comparative : undefined,
      superlative: pos === "adjective" ? superlative : undefined,
      examples: [ex1, ex2].filter(Boolean),
    });
    reset();
    onClose();
  };

  if (typeof document === "undefined") return null;

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          key="add-word-backdrop"
          className="fixed inset-0 z-[200] flex items-start justify-center overflow-y-auto bg-black/50 p-4 backdrop-blur-sm sm:items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={onClose}
        >
          <motion.div
            key="add-word-modal"
            onMouseDown={(e) => e.stopPropagation()}
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 26 }}
            className="relative w-full max-w-2xl overflow-hidden rounded-3xl bg-card shadow-2xl ring-1 ring-border/70"
          >
            {/* Header */}
            <div
              className="relative overflow-hidden px-6 py-5"
              style={{ background: "linear-gradient(135deg, #8B5CF6, #EC4899)" }}
            >
              <div className="relative z-10 flex items-start justify-between gap-3 text-white">
                <div>
                  <h2 className="text-xl font-bold">Neues Wort hinzufügen</h2>
                  <p className="mt-0.5 text-sm text-white/85">
                    Erweitere dein persönliches Vokabular.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="grid h-9 w-9 place-items-center rounded-full bg-white/20 text-lg font-bold text-white transition hover:bg-white/30"
                  aria-label="Schließen"
                >
                  ×
                </button>
              </div>
              <div
                aria-hidden
                className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/20 blur-2xl"
              />
            </div>

            {/* Body */}
            <div className="max-h-[75vh] overflow-y-auto px-6 py-5">
              {/* POS pills */}
              <Field label="Wortart">
                <div className="flex flex-wrap gap-1.5">
                  {POS_OPTIONS.map((p) => (
                    <button
                      key={p}
                      onClick={() => setPos(p)}
                      className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                        pos === p
                          ? "bg-primary text-primary-foreground shadow"
                          : "border border-border bg-card hover:bg-muted"
                      }`}
                    >
                      {POS_LABEL[p]}
                    </button>
                  ))}
                </div>
              </Field>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Wort *">
                  <Input value={headword} onChange={setHeadword} placeholder="z.B. Freundschaft" />
                </Field>
                <Field label="Aussprache (IPA)">
                  <Input value={ipa} onChange={setIpa} placeholder="[ˈfʁɔɪ̯ntʃaft]" />
                </Field>
              </div>

              <Field label="Kurze Bedeutung *">
                <Input
                  value={shortMeaning}
                  onChange={setShortMeaning}
                  placeholder="einzeilige Definition auf Deutsch"
                />
              </Field>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Übersetzung (Farsi)">
                  <Input
                    value={translationFa}
                    onChange={setTranslationFa}
                    placeholder="دوستی"
                    dir="rtl"
                  />
                </Field>
                <Field label="Übersetzung (Englisch)">
                  <Input
                    value={translationEn}
                    onChange={setTranslationEn}
                    placeholder="friendship"
                  />
                </Field>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Niveau (CEFR)">
                  <div className="flex gap-1.5">
                    {CEFR_LEVELS.map((l) => (
                      <button
                        key={l}
                        onClick={() => setCefr(l)}
                        className={`flex-1 rounded-lg px-2 py-1.5 text-xs font-bold transition ${
                          cefr === l
                            ? "bg-primary text-primary-foreground shadow"
                            : "border border-border bg-card hover:bg-muted"
                        }`}
                      >
                        {l}
                      </button>
                    ))}
                  </div>
                </Field>
                <Field label="Kategorie">
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.icon} {c.label}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>

              {/* POS-specific fields */}
              {pos === "noun" && (
                <div className="rounded-2xl border border-border/60 bg-secondary/30 p-4">
                  <div className="mb-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                    Substantiv-Grammatik
                  </div>
                  <Field label="Artikel">
                    <div className="flex gap-2">
                      {(["der", "die", "das"] as const).map((a) => {
                        const bg = a === "der" ? "#2563EB" : a === "die" ? "#DD2222" : "#059669";
                        return (
                          <button
                            key={a}
                            onClick={() => setArticle(a)}
                            className={`flex-1 rounded-lg px-4 py-2 text-sm font-bold transition ${
                              article === a
                                ? "text-white shadow-lg"
                                : "border border-border bg-card hover:bg-muted"
                            }`}
                            style={article === a ? { background: bg } : {}}
                          >
                            {a}
                          </button>
                        );
                      })}
                    </div>
                  </Field>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Plural">
                      <Input value={plural} onChange={setPlural} placeholder="die Freundschaften" />
                    </Field>
                    <Field label="Genitiv">
                      <Input
                        value={genitive}
                        onChange={setGenitive}
                        placeholder="der Freundschaft"
                      />
                    </Field>
                  </div>
                </div>
              )}

              {pos === "verb" && (
                <div className="rounded-2xl border border-border/60 bg-secondary/30 p-4">
                  <div className="mb-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                    Verb-Grammatik
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Hilfsverb">
                      <div className="flex gap-2">
                        {(["haben", "sein"] as const).map((a) => (
                          <button
                            key={a}
                            onClick={() => setAux(a)}
                            className={`flex-1 rounded-lg px-3 py-2 text-sm font-semibold transition ${
                              aux === a
                                ? "bg-primary text-primary-foreground shadow"
                                : "border border-border bg-card hover:bg-muted"
                            }`}
                          >
                            {a}
                          </button>
                        ))}
                      </div>
                    </Field>
                    <Field label="Objekt-Kasus">
                      <div className="flex gap-1.5">
                        {(["Akk", "Dat", "Gen", "none"] as const).map((c) => (
                          <button
                            key={c}
                            onClick={() => setObjectCase(c)}
                            className={`flex-1 rounded-lg px-2 py-2 text-xs font-bold transition ${
                              objectCase === c
                                ? "bg-primary text-primary-foreground shadow"
                                : "border border-border bg-card hover:bg-muted"
                            }`}
                          >
                            {c === "none" ? "—" : c}
                          </button>
                        ))}
                      </div>
                    </Field>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Präteritum">
                      <Input value={praeteritum} onChange={setPraeteritum} placeholder="lernte" />
                    </Field>
                    <Field label="Partizip II">
                      <Input value={partizipII} onChange={setPartizipII} placeholder="gelernt" />
                    </Field>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Checkbox label="regelmäßig" checked={regular} onChange={setRegular} />
                    <Checkbox label="trennbar" checked={separable} onChange={setSeparable} />
                    <Checkbox label="reflexiv (sich)" checked={reflexive} onChange={setReflexive} />
                  </div>
                  <Field label="Feste Präposition (optional)">
                    <div className="flex gap-2">
                      <input
                        value={prepositionText}
                        onChange={(e) => setPrepositionText(e.target.value)}
                        placeholder="auf, für, an ..."
                        className="flex-1 rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                      />
                      <select
                        value={prepositionCase}
                        onChange={(e) =>
                          setPrepositionCase(e.target.value as "Akk" | "Dat" | "Gen")
                        }
                        className="rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
                      >
                        <option value="Akk">+ Akk</option>
                        <option value="Dat">+ Dat</option>
                        <option value="Gen">+ Gen</option>
                      </select>
                    </div>
                  </Field>
                </div>
              )}

              {pos === "adjective" && (
                <div className="rounded-2xl border border-border/60 bg-secondary/30 p-4">
                  <div className="mb-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                    Adjektiv-Grammatik
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Komparativ">
                      <Input value={comparative} onChange={setComparative} placeholder="schöner" />
                    </Field>
                    <Field label="Superlativ">
                      <Input
                        value={superlative}
                        onChange={setSuperlative}
                        placeholder="am schönsten"
                      />
                    </Field>
                  </div>
                </div>
              )}

              <Field label="Beispielsätze (optional)">
                <Input value={ex1} onChange={setEx1} placeholder="Beispiel 1 auf Deutsch" />
                <div className="h-2" />
                <Input value={ex2} onChange={setEx2} placeholder="Beispiel 2 auf Deutsch" />
              </Field>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-2 border-t border-border/60 bg-secondary/30 px-6 py-4">
              <button
                onClick={onClose}
                className="rounded-xl border border-border bg-card px-4 py-2 text-sm font-medium transition hover:bg-muted"
              >
                Abbrechen
              </button>
              <button
                onClick={submit}
                disabled={!headword.trim() || !shortMeaning.trim()}
                className="rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 px-5 py-2 text-sm font-semibold text-white shadow-md transition hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-40"
              >
                Wort speichern
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
        {label}
      </label>
      {children}
    </div>
  );
}
function Input({
  value,
  onChange,
  placeholder,
  dir,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  dir?: "ltr" | "rtl";
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      dir={dir}
      className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15"
    />
  );
}
function Checkbox({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label
      className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-medium transition ${
        checked
          ? "border-primary bg-primary/10 text-primary"
          : "border-border bg-card hover:bg-muted"
      }`}
    >
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-3.5 w-3.5"
      />
      {label}
    </label>
  );
}
