const QUOTES = [
  {
    text: "Die Grenzen meiner Sprache bedeuten die Grenzen meiner Welt.",
    author: "Ludwig Wittgenstein",
  },
  {
    text: "Geschwindigkeit ist nicht alles, aber ohne Geschwindigkeit ist alles nichts.",
    author: "Max Planck",
  },
  {
    text: "Wer fremde Sprachen nicht kennt, weiß nichts von seiner eigenen.",
    author: "J. W. von Goethe",
  },
];

export function QuoteCard({ index = 0 }: { index?: number }) {
  const q = QUOTES[index % QUOTES.length];
  return (
    <aside className="hidden xl:block w-64 shrink-0">
      <div className="sticky top-6 space-y-4">
        <div className="rounded-3xl border border-border bg-card p-5">
          <div className="text-3xl leading-none text-muted-foreground">&ldquo;</div>
          <p className="mt-1 text-sm leading-relaxed">{q.text}</p>
          <div className="mt-3 text-xs text-muted-foreground">— {q.author}</div>
        </div>
        <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-5">
          <div className="text-xs font-bold text-muted-foreground">Berlin</div>
          <svg
            viewBox="0 0 200 240"
            className="mx-auto mt-3 h-40 text-muted-foreground opacity-60"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.2"
          >
            {/* Brandenburger Tor / Fernsehturm silhouette */}
            <path d="M20 220h160" />
            <path d="M40 220V120h120v100" />
            <path d="M55 120v-15h90v15" />
            {[0, 1, 2, 3, 4].map((i) => (
              <rect key={i} x={50 + i * 22} y="130" width="14" height="85" />
            ))}
            <path d="M95 105V70h10v35" />
            <circle cx="100" cy="55" r="10" />
            <path d="M100 45V15" />
            <path d="M92 25h16" />
          </svg>
        </div>
      </div>
    </aside>
  );
}
