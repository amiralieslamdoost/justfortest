import { motion } from "framer-motion";
import type { PodcastCategory, PodcastCategoryKey } from "@/lib/deusi/mockPodcasts";

interface Props {
  categories: PodcastCategory[];
  active: PodcastCategoryKey;
  onChange: (key: PodcastCategoryKey) => void;
}

export function CategoryChips({ categories, active, onChange }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {categories.map((c) => {
        const on = c.key === active;
        return (
          <motion.button
            key={c.key}
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => onChange(c.key)}
            className={`rounded-full px-4 py-2 text-xs font-semibold transition-shadow ${
              on ? "text-white shadow-lg" : "neu-pill text-muted-foreground hover:text-foreground"
            }`}
            style={
              on
                ? {
                    background: "var(--flag-red)",
                    boxShadow: "0 12px 24px -12px rgba(221,34,34,.5)",
                  }
                : undefined
            }
          >
            {c.label}
          </motion.button>
        );
      })}
    </div>
  );
}
