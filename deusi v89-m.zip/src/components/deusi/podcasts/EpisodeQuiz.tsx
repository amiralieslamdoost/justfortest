import { motion } from "framer-motion";
import { useMemo, useState } from "react";
import type { QuizQuestion } from "@/lib/deusi/mockPodcasts";

export function EpisodeQuiz({ questions }: { questions: QuizQuestion[] }) {
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState(false);

  const score = useMemo(() => {
    return questions.reduce((s, q) => s + (answers[q.id] === q.answerIndex ? 1 : 0), 0);
  }, [answers, questions]);

  return (
    <div className="space-y-4">
      {questions.map((q, qi) => (
        <div key={q.id} className="rounded-2xl border border-border bg-secondary/40 p-4">
          <div className="mb-3 text-sm font-semibold">
            <span className="mr-2 text-muted-foreground">{qi + 1}.</span>
            {q.question}
          </div>
          <div className="grid gap-2">
            {q.options.map((opt, i) => {
              const chosen = answers[q.id] === i;
              const correct = submitted && i === q.answerIndex;
              const wrong = submitted && chosen && i !== q.answerIndex;
              return (
                <motion.button
                  key={i}
                  whileHover={!submitted ? { x: 2 } : undefined}
                  disabled={submitted}
                  onClick={() => setAnswers((a) => ({ ...a, [q.id]: i }))}
                  className={`flex items-center justify-between rounded-xl border px-3 py-2 text-left text-sm transition ${
                    correct
                      ? "border-[color:var(--easy)] bg-[color:var(--easy)]/10 text-foreground"
                      : wrong
                        ? "border-[color:var(--again)] bg-[color:var(--again)]/10 text-foreground"
                        : chosen
                          ? "border-[color:var(--flag-red)] bg-accent text-accent-foreground"
                          : "border-border bg-background hover:bg-secondary"
                  }`}
                >
                  <span>{opt}</span>
                  {correct && <span>✓</span>}
                  {wrong && <span>✕</span>}
                </motion.button>
              );
            })}
          </div>
          {submitted && <p className="mt-2 text-xs text-muted-foreground">{q.explanation}</p>}
        </div>
      ))}

      <div className="flex items-center justify-between rounded-2xl bg-secondary/60 px-4 py-3">
        <div className="text-sm">
          {submitted ? (
            <span>
              Ergebnis:{" "}
              <span className="font-black">
                {score} / {questions.length}
              </span>{" "}
              richtig
            </span>
          ) : (
            <span className="text-muted-foreground">
              Beantworte alle Fragen und prüfe dein Verständnis.
            </span>
          )}
        </div>
        {submitted ? (
          <button
            onClick={() => {
              setAnswers({});
              setSubmitted(false);
            }}
            className="rounded-xl border border-border bg-background px-4 py-2 text-xs font-semibold hover:bg-accent hover:text-accent-foreground"
          >
            Neu starten
          </button>
        ) : (
          <button
            onClick={() => setSubmitted(true)}
            disabled={Object.keys(answers).length < questions.length}
            className="rounded-xl bg-[color:var(--flag-red)] px-4 py-2 text-xs font-semibold text-white shadow-md hover:-translate-y-0.5 transition disabled:opacity-50"
          >
            Prüfen
          </button>
        )}
      </div>
    </div>
  );
}
