import { useEffect, useMemo, useRef, useState } from "react";
import type { PodcastEpisode, PodcastVocab, TranscriptLine } from "@/lib/deusi/mockPodcasts";

interface Props {
  episode: PodcastEpisode;
  currentTime: number;
  onSeek: (sec: number) => void;
  onSaveWord?: (vocab: PodcastVocab) => void;
}

export function InteractiveTranscript({ episode, currentTime, onSeek, onSaveWord }: Props) {
  const vocabMap = useMemo(() => new Map(episode.vocab.map((v) => [v.id, v])), [episode.vocab]);
  const [openVocab, setOpenVocab] = useState<PodcastVocab | null>(null);
  const activeLine = useMemo(
    () => episode.transcript.find((l) => currentTime >= l.start && currentTime <= l.end)?.id,
    [episode.transcript, currentTime],
  );
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Only auto-scroll after playback has actually started, and scroll ONLY
    // inside the transcript container — never the whole page (which used to
    // steal focus away from the section header on first open).
    if (!activeLine || !scrollRef.current || currentTime <= 0.25) return;
    const container = scrollRef.current;
    const el = container.querySelector<HTMLElement>(`[data-line-id="${activeLine}"]`);
    if (!el) return;
    const top = el.offsetTop - container.clientHeight / 2 + el.clientHeight / 2;
    container.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
  }, [activeLine, currentTime]);

  return (
    <div className="relative">
      <div ref={scrollRef} className="max-h-[380px] space-y-3 overflow-y-auto pr-2">
        {episode.transcript.map((line) => (
          <TranscriptLineRow
            key={line.id}
            line={line}
            active={line.id === activeLine}
            onLineClick={() => onSeek(line.start)}
            onWordClick={(wordId) => {
              const v = vocabMap.get(wordId);
              if (v) setOpenVocab(v);
            }}
          />
        ))}
      </div>

      {openVocab && (
        <VocabPopover
          vocab={openVocab}
          onClose={() => setOpenVocab(null)}
          onSave={() => {
            onSaveWord?.(openVocab);
            setOpenVocab(null);
          }}
        />
      )}
    </div>
  );
}

function TranscriptLineRow({
  line,
  active,
  onLineClick,
  onWordClick,
}: {
  line: TranscriptLine;
  active: boolean;
  onLineClick: () => void;
  onWordClick: (wordId: string) => void;
}) {
  return (
    <div
      data-line-id={line.id}
      onClick={onLineClick}
      className={`cursor-pointer rounded-2xl border p-3 transition ${
        active
          ? "border-transparent bg-[color:var(--accent)] shadow-sm"
          : "border-border bg-secondary/40 hover:bg-secondary"
      }`}
    >
      <div className="mb-1 flex items-center gap-2 text-[10px] uppercase tracking-wide text-muted-foreground">
        <span className="tabular-nums">{fmt(line.start)}</span>
        {line.speaker && (
          <span className="rounded-full bg-background/60 px-2 py-0.5">{line.speaker}</span>
        )}
      </div>
      <p className="text-sm leading-relaxed text-foreground">
        {line.words.map((w, i) => (
          <span key={i}>
            {w.wordId ? (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onWordClick(w.wordId!);
                }}
                className="font-semibold text-[color:var(--flag-red)] underline decoration-dotted underline-offset-4 hover:opacity-80"
              >
                {w.w}
              </button>
            ) : (
              <span>{w.w}</span>
            )}
            {i < line.words.length - 1 ? " " : ""}
          </span>
        ))}
      </p>
      <p className="mt-1 text-xs italic text-muted-foreground">{line.translation}</p>
    </div>
  );
}

function VocabPopover({
  vocab,
  onClose,
  onSave,
}: {
  vocab: PodcastVocab;
  onClose: () => void;
  onSave: () => void;
}) {
  const articleColor =
    vocab.article === "der"
      ? "var(--der)"
      : vocab.article === "die"
        ? "var(--die)"
        : vocab.article === "das"
          ? "var(--das)"
          : "var(--muted-foreground)";
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-4 sm:items-center"
      onClick={onClose}
    >
      <div
        className="neu-card w-full max-w-md animate-fade p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-start gap-3">
          {vocab.article && (
            <span
              className="rounded-lg px-2 py-1 text-xs font-black text-white"
              style={{ background: articleColor }}
            >
              {vocab.article}
            </span>
          )}
          <div className="flex-1">
            <div className="text-2xl font-black">{vocab.word}</div>
            <div className="text-xs text-muted-foreground">
              /{vocab.ipa}/ · {vocab.pos} · {vocab.level}
            </div>
          </div>
          <button
            className="text-muted-foreground hover:text-foreground"
            onClick={onClose}
            aria-label="Schließen"
          >
            ✕
          </button>
        </div>
        <div className="rounded-xl bg-secondary/50 p-3 text-sm">{vocab.meaning}</div>
        <div className="mt-3 rounded-xl border border-dashed border-border p-3 text-sm italic text-muted-foreground">
          {vocab.example}
        </div>
        <div className="mt-4 flex gap-2">
          <button
            onClick={onSave}
            className="flex-1 rounded-xl bg-[color:var(--flag-red)] px-4 py-2 text-sm font-semibold text-white shadow-md hover:-translate-y-0.5 transition"
          >
            + Zu meinen Vokabeln
          </button>
          <button
            className="rounded-xl border border-border bg-secondary px-4 py-2 text-sm font-semibold hover:bg-accent hover:text-accent-foreground"
            aria-label="Aussprache"
          >
            🔊
          </button>
        </div>
      </div>
    </div>
  );
}

function fmt(sec: number) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
