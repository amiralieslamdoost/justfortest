import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";

interface Props {
  waveform: number[];
  durationSec: number;
  accent?: string;
  initialSec?: number;
  onSeek?: (sec: number) => void;
  onTimeUpdate?: (sec: number) => void;
  compact?: boolean;
}

// Mock audio player: no real <audio>, but simulates a playhead that advances in real time
// and lets the user click the waveform to seek. Exposes onTimeUpdate so the transcript can sync.
export function AudioPlayer({
  waveform,
  durationSec,
  accent = "#DD2222",
  initialSec = 0,
  onSeek,
  onTimeUpdate,
  compact = false,
}: Props) {
  const [playing, setPlaying] = useState(false);
  const [rate, setRate] = useState(1);
  const [pos, setPos] = useState(initialSec);
  const barRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number | null>(null);
  const lastTsRef = useRef<number | null>(null);

  useEffect(() => {
    setPos(initialSec);
  }, [initialSec]);

  useEffect(() => {
    if (!playing) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      lastTsRef.current = null;
      return;
    }
    const tick = (ts: number) => {
      if (lastTsRef.current == null) lastTsRef.current = ts;
      const dt = (ts - lastTsRef.current) / 1000;
      lastTsRef.current = ts;
      setPos((p) => {
        const next = Math.min(durationSec, p + dt * rate);
        onTimeUpdate?.(next);
        if (next >= durationSec) setPlaying(false);
        return next;
      });
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [playing, rate, durationSec, onTimeUpdate]);

  const progress = Math.max(0, Math.min(1, pos / durationSec));

  function seekFromEvent(e: React.MouseEvent) {
    if (!barRef.current) return;
    const rect = barRef.current.getBoundingClientRect();
    const p = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const s = p * durationSec;
    setPos(s);
    onSeek?.(s);
    onTimeUpdate?.(s);
  }

  const rates = [0.75, 1, 1.25, 1.5];

  return (
    <div className="flex w-full min-w-0 flex-wrap items-center gap-3 sm:flex-nowrap sm:gap-4">
      <motion.button
        whileTap={{ scale: 0.92 }}
        whileHover={{ scale: 1.05 }}
        onClick={() => setPlaying((p) => !p)}
        aria-label={playing ? "Pause" : "Abspielen"}
        className="grid shrink-0 place-items-center rounded-full text-white shadow-lg"
        style={{
          background: accent,
          width: compact ? 44 : 56,
          height: compact ? 44 : 56,
          boxShadow: `0 12px 28px -10px ${accent}80`,
        }}
      >
        {playing ? (
          <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
            <rect x="6" y="5" width="4" height="14" rx="1" />
            <rect x="14" y="5" width="4" height="14" rx="1" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        )}
      </motion.button>

      <div className="min-w-0 flex-1">
        <div
          ref={barRef}
          onClick={seekFromEvent}
          className="relative flex h-12 cursor-pointer items-end gap-[2px] overflow-hidden select-none"
        >
          {waveform.map((v, i) => {
            const barP = i / waveform.length;
            const active = barP <= progress;
            return (
              <div
                key={i}
                className="flex-1 rounded-full transition-colors"
                style={{
                  height: `${Math.max(10, v * 100)}%`,
                  background: active
                    ? accent
                    : "color-mix(in oklab, currentColor 18%, transparent)",
                }}
              />
            );
          })}
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-3 text-xs tabular-nums text-muted-foreground">
        <span className="font-semibold text-foreground">{fmt(pos)}</span>
        <span>/</span>
        <span>{fmt(durationSec)}</span>
        {!compact && (
          <button
            onClick={() => setRate((r) => rates[(rates.indexOf(r) + 1) % rates.length])}
            className="ml-2 rounded-full border border-border bg-secondary px-2 py-1 text-[11px] font-semibold text-foreground hover:bg-accent hover:text-accent-foreground"
            aria-label="Wiedergabegeschwindigkeit"
          >
            {rate}x
          </button>
        )}
      </div>
    </div>
  );
}

function fmt(sec: number) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
