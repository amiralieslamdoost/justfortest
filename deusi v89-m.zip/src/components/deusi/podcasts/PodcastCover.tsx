import type { CSSProperties } from "react";

interface Props {
  title: string;
  publisher?: string;
  background: string;
  className?: string;
  style?: CSSProperties;
  size?: "sm" | "md" | "lg";
}

// Placeholder cover: pure CSS gradient with the show's title. No external assets required.
export function PodcastCover({
  title,
  publisher,
  background,
  className = "",
  style,
  size = "md",
}: Props) {
  const font = size === "sm" ? "text-[11px]" : size === "lg" ? "text-lg" : "text-sm";
  return (
    <div
      className={`relative flex flex-col justify-between overflow-hidden rounded-2xl text-white shadow-inner ${className}`}
      style={{ background, ...style }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-black/20"
      />
      {publisher && (
        <div
          className={`relative px-3 pt-2 text-[10px] font-semibold uppercase tracking-wide text-white/70 ${size === "sm" ? "text-[9px]" : ""}`}
        >
          {publisher}
        </div>
      )}
      <div className={`relative px-3 pb-3 font-black leading-tight ${font}`}>{title}</div>
    </div>
  );
}
