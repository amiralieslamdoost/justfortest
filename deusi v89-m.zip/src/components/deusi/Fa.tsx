import type { ReactNode } from "react";

/**
 * Fa — tiny Persian hint rendered under a German title or beside a label.
 *
 * The site is primarily in German. To help Iranian learners whose German is
 * still developing, we place a small, readable Persian caption near titles,
 * section headers and stat labels. It uses the YekanBakh font and is styled
 * subtly so it never competes with the primary German text.
 *
 * Variants:
 *  - block  (default): sits on its own line under the title.
 *  - inline: sits on the same line, separated by a soft dot.
 */
export function Fa({
  children,
  inline = false,
  className = "",
}: {
  children: ReactNode;
  inline?: boolean;
  className?: string;
}) {
  return (
    <span aria-hidden="true" className={`${inline ? "fa-hint-inline" : "fa-hint"} ${className}`}>
      {children}
    </span>
  );
}
