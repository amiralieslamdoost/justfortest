import { useState } from "react";
import { Check, Search, UserPlus } from "lucide-react";
import { Modal } from "@/components/deusi/Modal";
import { FaHint } from "@/components/deusi/FaHint";
import { useUserSearch } from "@/lib/deusi/community/store";
import type { Chat } from "@/lib/deusi/community/types";
import { LevelBadge, UserAvatar } from "./parts";

/** Mitglieder über die @ID finden und der Gruppe / dem Talar hinzufügen. */
export function AddMemberModal({
  open,
  chat,
  onClose,
  onAdd,
}: {
  open: boolean;
  chat: Chat;
  onClose: () => void;
  onAdd: (userId: string) => void;
}) {
  const [query, setQuery] = useState("");
  const results = useUserSearch(query);

  return (
    <Modal
      open={open}
      onClose={() => {
        setQuery("");
        onClose();
      }}
      title="Mitglied hinzufügen"
    >
      <div className="space-y-4">
        <FaHint size="sm">با آیدی (@) دوستت را پیدا کن و به گروه اضافه کن</FaHint>

        <div className="relative">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="@id oder Name suchen…"
            aria-label="Mitglied suchen"
            className="h-11 w-full rounded-2xl border border-border/70 bg-card/80 pl-9 pr-3 text-sm outline-none focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
          />
        </div>

        <ul className="space-y-1.5">
          {query.trim() && results.length === 0 && (
            <li className="py-6 text-center text-sm text-muted-foreground">
              Keine Person mit dieser ID gefunden.
            </li>
          )}
          {results.map((u) => {
            const member = chat.members.includes(u.id);
            return (
              <li
                key={u.id}
                className="flex items-center gap-3 rounded-2xl p-2 hover:bg-foreground/5"
              >
                <UserAvatar user={u} size={38} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-sm font-bold">{u.name}</span>
                    <LevelBadge level={u.level} />
                  </div>
                  <span className="text-xs text-muted-foreground">{u.handle}</span>
                </div>
                <button
                  type="button"
                  disabled={member}
                  onClick={() => onAdd(u.id)}
                  className={`inline-flex shrink-0 items-center gap-1.5 rounded-2xl px-3 py-2 text-xs font-bold transition ${
                    member
                      ? "bg-foreground/5 text-muted-foreground"
                      : "bg-[color:var(--section-primary,#c2410c)] text-white active:scale-95"
                  }`}
                >
                  {member ? (
                    <>
                      <Check className="h-4 w-4" aria-hidden /> Dabei
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4" aria-hidden /> Hinzufügen
                    </>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </Modal>
  );
}
