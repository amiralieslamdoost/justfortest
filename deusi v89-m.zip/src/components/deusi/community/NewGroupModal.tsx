import { useState } from "react";
import { Modal } from "@/components/deusi/Modal";
import { FaHint } from "@/components/deusi/FaHint";

export function NewGroupModal({
  open,
  onClose,
  onCreate,
}: {
  open: boolean;
  onClose: () => void;
  onCreate: (input: { name: string; description: string; private: boolean }) => void;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isPrivate, setIsPrivate] = useState(true);

  const reset = () => {
    setName("");
    setDescription("");
    setIsPrivate(true);
  };

  return (
    <Modal
      open={open}
      onClose={() => {
        reset();
        onClose();
      }}
      title="Neue Gruppe"
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!name.trim()) return;
          onCreate({ name, description, private: isPrivate });
          reset();
        }}
        className="space-y-4"
      >
        <FaHint size="sm">یک گروه دوستانه بساز و با هم تمرین کنید</FaHint>

        <label className="block space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
            Name
          </span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 40))}
            required
            placeholder="z. B. B1 Abendrunde"
            className="h-11 w-full rounded-2xl border border-border/70 bg-card/80 px-4 text-sm outline-none focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
          />
        </label>

        <label className="block space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
            Beschreibung
          </span>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value.slice(0, 140))}
            rows={2}
            placeholder="Worum geht es in der Gruppe?"
            className="w-full resize-none rounded-2xl border border-border/70 bg-card/80 px-4 py-3 text-sm outline-none focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
          />
        </label>

        <div className="flex gap-2">
          {[
            { key: true, label: "Privat", fa: "خصوصی" },
            { key: false, label: "Öffentlich", fa: "عمومی" },
          ].map((opt) => (
            <button
              key={String(opt.key)}
              type="button"
              onClick={() => setIsPrivate(opt.key)}
              className={`flex-1 rounded-2xl px-3 py-2.5 text-sm font-bold ring-1 transition ${
                isPrivate === opt.key
                  ? "bg-[color:var(--section-primary,#c2410c)] text-white ring-transparent"
                  : "bg-card/70 text-muted-foreground ring-border/70"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <button
          type="submit"
          className="h-11 w-full rounded-2xl bg-[color:var(--section-primary,#c2410c)] text-sm font-bold text-white shadow-sm"
        >
          Gruppe erstellen
        </button>
      </form>
    </Modal>
  );
}
