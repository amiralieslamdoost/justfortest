import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, CornerUpLeft, Flag, ImagePlus, Send, Trash2, UserPlus, X } from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { getUser } from "@/lib/deusi/community/mockCommunity";
import type { Chat, Message } from "@/lib/deusi/community/types";
import type { Draft } from "@/lib/deusi/community/store";
import { ChatAvatar, KIND_STYLE, KindBadge, UserAvatar } from "./parts";
import { AddMemberModal } from "./AddMemberModal";
import { ChatInfoModal } from "./ChatInfoModal";
import { UserProfileModal } from "./UserProfileModal";
import { ReportModal, type ReportSubject } from "./ReportModal";
import type { CommunityUser } from "@/lib/deusi/community/types";

export function ChatWindow({
  chat,
  onSend,
  onToggleJoined,
  onDeleteMessage,
  onAddMember,
}: {
  chat: Chat;
  onSend: (draft: Draft) => void;
  onToggleJoined: () => void;
  onDeleteMessage: (messageId: string) => void;
  onAddMember: (userId: string) => void;
}) {
  const [draft, setDraft] = useState("");
  const [image, setImage] = useState<string | undefined>();
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [infoOpen, setInfoOpen] = useState(false);
  const [profile, setProfile] = useState<CommunityUser | null>(null);
  const [report, setReport] = useState<ReportSubject>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const style = KIND_STYLE[chat.kind];

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [chat.id, chat.messages.length]);

  useEffect(() => {
    setReplyTo(null);
    setImage(undefined);
    setDraft("");
  }, [chat.id]);

  const submit = () => {
    if (!draft.trim() && !image) return;
    onSend({ body: draft, imageUrl: image, replyToId: replyTo?.id });
    setDraft("");
    setImage(undefined);
    setReplyTo(null);
  };

  const pickImage = (file?: File) => {
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => setImage(String(reader.result));
    reader.readAsDataURL(file);
  };

  const partner = chat.partnerId ? getUser(chat.partnerId) : null;
  const subtitle =
    chat.kind === "dm"
      ? `${partner?.handle ?? ""} · ${partner?.online ? "online" : "zuletzt online"}`
      : `${chat.members.length + 1} Mitglieder`;

  return (
    <div className="neu-card flex h-full min-h-0 flex-col overflow-hidden">
      {/* Header — tinted per chat kind */}
      <div
        className={`flex items-center gap-2 border-b border-border/60 p-2.5 sm:gap-3 sm:p-3 ${style.surface}`}
      >
        <Link
          to="/community"
          aria-label="Zurück zur Übersicht"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-muted-foreground transition hover:bg-foreground/5 hover:text-foreground lg:hidden"
        >
          <ArrowLeft className="h-5 w-5" aria-hidden />
        </Link>
        <button
          type="button"
          onClick={() => (chat.kind === "dm" && partner ? setProfile(partner) : setInfoOpen(true))}
          aria-label={chat.kind === "dm" ? "Profil ansehen" : "Info & Einstellungen"}
          className="shrink-0 rounded-2xl transition active:scale-95"
        >
          <ChatAvatar chat={chat} size={40} />
        </button>
        <button
          type="button"
          onClick={() => (chat.kind === "dm" && partner ? setProfile(partner) : setInfoOpen(true))}
          className="min-w-0 flex-1 text-left"
        >
          <div className="flex min-w-0 items-center gap-2">
            <h2 className="truncate text-sm font-black">
              {chat.kind === "room" ? `#${chat.title}` : chat.title}
            </h2>
            <span className="hidden shrink-0 sm:inline-flex">
              <KindBadge kind={chat.kind} />
            </span>
          </div>
          <p className="truncate text-[11px] text-muted-foreground">{subtitle}</p>
        </button>
        {chat.kind !== "dm" && chat.joined && (
          <button
            type="button"
            onClick={() => setAddOpen(true)}
            aria-label="Mitglied hinzufügen"
            className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-muted-foreground ring-1 ring-border/70 transition hover:text-foreground"
          >
            <UserPlus className="h-4.5 w-4.5" aria-hidden />
          </button>
        )}
        {chat.kind === "group" && (
          <button
            type="button"
            onClick={onToggleJoined}
            style={chat.joined ? undefined : { background: style.accent }}
            className={`shrink-0 rounded-2xl px-2.5 py-2 text-xs font-bold ring-1 transition sm:px-3 ${
              chat.joined
                ? "bg-card/70 text-muted-foreground ring-border/70 hover:text-foreground"
                : "text-white ring-transparent"
            }`}
          >
            {chat.joined ? "Verlassen" : "Beitreten"}
          </button>
        )}
      </div>

      {/* Messages */}
      <div
        className={`min-h-0 flex-1 space-y-3 overflow-y-auto px-2.5 py-4 sm:px-5 ${style.surface}`}
      >
        {chat.messages.length === 0 && (
          <div className="py-14 text-center">
            <p className="text-sm text-muted-foreground">Schreib die erste Nachricht.</p>
            <FaHint size="sm">اولین پیام را بنویس</FaHint>
          </div>
        )}
        {chat.messages.map((msg) => {
          const mine = msg.authorId === "me";
          const author = getUser(msg.authorId);
          const quoted = msg.replyToId
            ? chat.messages.find((x) => x.id === msg.replyToId)
            : undefined;
          return (
            <div key={msg.id}>
              {msg.day && (
                <div className="my-4 flex items-center gap-3">
                  <span className="h-px flex-1 bg-border/70" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                    {msg.day}
                  </span>
                  <span className="h-px flex-1 bg-border/70" />
                </div>
              )}
              <div
                className={`group flex items-end gap-2 ${mine ? "justify-end" : "justify-start"}`}
              >
                {!mine && (
                  <button
                    type="button"
                    onClick={() => setProfile(author)}
                    aria-label={`Profil von ${author.name}`}
                    className="shrink-0 rounded-full transition active:scale-95"
                  >
                    <UserAvatar user={author} size={28} />
                  </button>
                )}
                {mine && !msg.deleted && (
                  <MessageActions
                    onReply={() => setReplyTo(msg)}
                    onDelete={() => onDeleteMessage(msg.id)}
                  />
                )}
                <div
                  style={mine && !msg.deleted ? { background: style.accent } : undefined}
                  className={`max-w-[85%] rounded-2xl px-3 py-2.5 text-sm shadow-sm sm:max-w-[75%] sm:px-3.5 ${
                    msg.deleted
                      ? "bg-foreground/5 italic text-muted-foreground ring-1 ring-border/60"
                      : mine
                        ? "rounded-br-md text-white"
                        : "rounded-bl-md bg-card/90 text-foreground ring-1 ring-border/70"
                  }`}
                >
                  {msg.deleted ? (
                    <p>Nachricht gelöscht</p>
                  ) : (
                    <>
                      {!mine && chat.kind !== "dm" && (
                        <span
                          className="mb-0.5 block text-[11px] font-black"
                          style={{ color: author.color }}
                        >
                          {author.name}
                        </span>
                      )}
                      {quoted && (
                        <span
                          className={`mb-1.5 block border-l-2 pl-2 text-[11px] leading-snug ${
                            mine
                              ? "border-white/50 text-white/80"
                              : "border-border text-muted-foreground"
                          }`}
                        >
                          <span className="block font-bold">
                            {quoted.authorId === "me" ? "Du" : getUser(quoted.authorId).name}
                          </span>
                          <span className="line-clamp-2">
                            {quoted.deleted ? "Nachricht gelöscht" : quoted.body || "📷 Bild"}
                          </span>
                        </span>
                      )}
                      {msg.imageUrl && (
                        <button
                          type="button"
                          onClick={() => setLightbox(msg.imageUrl!)}
                          className="mb-1.5 block overflow-hidden rounded-xl"
                        >
                          <img
                            decoding="async"
                            src={msg.imageUrl}
                            alt="Gesendetes Bild"
                            loading="lazy"
                            className="max-h-56 w-full object-cover"
                          />
                        </button>
                      )}
                      {msg.body && <p className="whitespace-pre-wrap break-words">{msg.body}</p>}
                    </>
                  )}
                  <span
                    className={`mt-1 block text-[10px] ${mine && !msg.deleted ? "text-white/70" : "text-muted-foreground"}`}
                  >
                    {msg.time}
                  </span>
                </div>
                {!mine && !msg.deleted && (
                  <MessageActions
                    onReply={() => setReplyTo(msg)}
                    onReport={() =>
                      setReport({
                        type: "message",
                        id: msg.id,
                        label: `Nachricht von ${author.name}`,
                      })
                    }
                  />
                )}
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      {/* Composer */}
      <div className="border-t border-border/60 p-3">
        {chat.kind === "group" && !chat.joined ? (
          <button
            type="button"
            onClick={onToggleJoined}
            style={{ background: style.accent }}
            className="h-11 w-full rounded-2xl text-sm font-bold text-white"
          >
            Gruppe beitreten, um zu schreiben
          </button>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
            className="space-y-2"
          >
            {replyTo && (
              <div className="flex items-center gap-2 rounded-2xl bg-foreground/5 px-3 py-2">
                <CornerUpLeft className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                <span className="min-w-0 flex-1 truncate text-xs text-muted-foreground">
                  <b className="text-foreground">
                    {replyTo.authorId === "me" ? "Du" : getUser(replyTo.authorId).name}
                  </b>{" "}
                  {replyTo.body || "📷 Bild"}
                </span>
                <button
                  type="button"
                  onClick={() => setReplyTo(null)}
                  aria-label="Antwort abbrechen"
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" aria-hidden />
                </button>
              </div>
            )}
            {image && (
              <div className="relative inline-block">
                <img
                  loading="lazy"
                  decoding="async"
                  src={image}
                  alt="Vorschau"
                  className="h-20 rounded-xl object-cover"
                />
                <button
                  type="button"
                  onClick={() => setImage(undefined)}
                  aria-label="Bild entfernen"
                  className="absolute -right-2 -top-2 grid h-6 w-6 place-items-center rounded-full bg-foreground text-background"
                >
                  <X className="h-3.5 w-3.5" aria-hidden />
                </button>
              </div>
            )}
            <div className="flex items-end gap-2">
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  pickImage(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                aria-label="Bild senden"
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-muted-foreground ring-1 ring-border/70 transition hover:text-foreground"
              >
                <ImagePlus className="h-5 w-5" aria-hidden />
              </button>
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value.slice(0, 1000))}
                rows={1}
                placeholder="Nachricht schreiben…"
                aria-label="Nachricht schreiben"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    submit();
                  }
                }}
                className="min-h-[44px] max-h-32 flex-1 resize-none rounded-2xl border border-border/70 bg-card/80 px-4 py-3 text-sm outline-none transition focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
              />
              <button
                type="submit"
                disabled={!draft.trim() && !image}
                aria-label="Senden"
                style={{ background: style.accent }}
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-sm transition disabled:opacity-40"
              >
                <Send className="h-4.5 w-4.5" aria-hidden />
              </button>
            </div>
          </form>
        )}
      </div>

      {chat.kind !== "dm" && (
        <ChatInfoModal
          chat={chat}
          open={infoOpen}
          onClose={() => setInfoOpen(false)}
          onSelectUser={(u) => {
            setInfoOpen(false);
            setProfile(u);
          }}
        />
      )}

      <UserProfileModal user={profile} onClose={() => setProfile(null)} />

      <ReportModal subject={report} onClose={() => setReport(null)} />

      <AddMemberModal
        open={addOpen}
        chat={chat}
        onClose={() => setAddOpen(false)}
        onAdd={(userId) => onAddMember(userId)}
      />

      {lightbox && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-6"
          onClick={() => setLightbox(null)}
        >
          <img
            loading="lazy"
            decoding="async"
            src={lightbox}
            alt="Bild groß"
            className="max-h-full max-w-full rounded-2xl"
          />
        </div>
      )}
    </div>
  );
}

function MessageActions({
  onReply,
  onDelete,
  onReport,
}: {
  onReply: () => void;
  onDelete?: () => void;
  onReport?: () => void;
}) {
  return (
    <span className="flex shrink-0 gap-1 opacity-60 transition focus-within:opacity-100 lg:opacity-0 lg:group-hover:opacity-100">
      <button
        type="button"
        onClick={onReply}
        aria-label="Antworten"
        className="grid h-7 w-7 place-items-center rounded-full bg-card text-muted-foreground ring-1 ring-border/70 hover:text-foreground"
      >
        <CornerUpLeft className="h-3.5 w-3.5" aria-hidden />
      </button>
      {onReport && (
        <button
          type="button"
          onClick={onReport}
          aria-label="Nachricht melden"
          className="grid h-7 w-7 place-items-center rounded-full bg-card text-muted-foreground ring-1 ring-border/70 hover:text-red-500"
        >
          <Flag className="h-3.5 w-3.5" aria-hidden />
        </button>
      )}
      {onDelete && (
        <button
          type="button"
          onClick={onDelete}
          aria-label="Nachricht löschen"
          className="grid h-7 w-7 place-items-center rounded-full bg-card text-muted-foreground ring-1 ring-border/70 hover:text-red-500"
        >
          <Trash2 className="h-3.5 w-3.5" aria-hidden />
        </button>
      )}
    </span>
  );
}
