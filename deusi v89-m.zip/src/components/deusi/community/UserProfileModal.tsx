import { useNavigate } from "@tanstack/react-router";
import { Ban, Flag, MessageSquare, Sparkles } from "lucide-react";
import { Modal } from "@/components/deusi/Modal";
import { FaHint } from "@/components/deusi/FaHint";
import { useCommunity } from "@/lib/deusi/community/store";
import type { CommunityUser } from "@/lib/deusi/community/types";
import { LevelBadge, UserAvatar } from "./parts";
import { ReportModal, type ReportSubject } from "./ReportModal";
import { useState } from "react";

/** Profilkarte eines Mitglieds — Infos + direkt privat schreiben. */
export function UserProfileModal({
  user,
  onClose,
}: {
  user: CommunityUser | null;
  onClose: () => void;
}) {
  const { openDirectChat, blockUser, unblockUser, isBlocked } = useCommunity();
  const navigate = useNavigate();
  const [report, setReport] = useState<ReportSubject>(null);
  if (!user) return null;

  const isMe = user.id === "me";
  const blocked = isBlocked(user.id);

  return (
    <Modal open onClose={onClose} title="Profil">
      <div className="space-y-5">
        <div className="flex items-center gap-4">
          <UserAvatar user={user} size={68} />
          <div className="min-w-0">
            <h4 className="truncate text-lg font-black">{user.name}</h4>
            <p className="mt-0.5 text-sm font-semibold text-muted-foreground">{user.handle}</p>
            <p className="mt-1.5 flex items-center gap-2 text-sm font-bold">
              <span
                aria-hidden
                className={`h-2 w-2 rounded-full ${user.online ? "bg-emerald-500" : "bg-muted-foreground/40"}`}
              />
              <span
                className={
                  user.online ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"
                }
              >
                {user.online ? "online" : "offline"}
              </span>
              <LevelBadge level={user.level} />
            </p>
          </div>
        </div>

        <p className="flex items-start gap-2 rounded-2xl bg-foreground/5 p-3 text-sm leading-relaxed text-foreground/80">
          <Sparkles className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
          Lernt Deutsch auf DEUSI und ist in der Community aktiv.
        </p>

        {!isMe && !blocked && (
          <button
            type="button"
            onClick={() => {
              const id = openDirectChat(user.id);
              onClose();
              navigate({ to: "/community/chat/$chatId", params: { chatId: id } });
            }}
            className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-2xl bg-[color:var(--section-primary,#c2410c)] text-sm font-bold text-white active:scale-[0.99]"
          >
            <MessageSquare className="h-4 w-4" aria-hidden />
            Privat schreiben
          </button>
        )}

        {!isMe && (
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => (blocked ? unblockUser(user.id) : blockUser(user.id))}
              className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-2xl bg-foreground/5 text-sm font-bold text-muted-foreground transition hover:text-red-500"
            >
              <Ban className="h-4 w-4" aria-hidden />
              {blocked ? "Blockierung aufheben" : "Blockieren"}
            </button>
            <button
              type="button"
              onClick={() => setReport({ type: "user", id: user.id, label: user.name })}
              className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-2xl bg-foreground/5 text-sm font-bold text-muted-foreground transition hover:text-red-500"
            >
              <Flag className="h-4 w-4" aria-hidden />
              Melden
            </button>
          </div>
        )}

        <FaHint size="sm">
          {blocked
            ? "این کاربر بلاک شده و پیام‌هایش را نمی‌بینی"
            : "با کلیک روی عکس پروفایل هر کاربر، اطلاعات او را می‌بینی"}
        </FaHint>

        <ReportModal subject={report} onClose={() => setReport(null)} />
      </div>
    </Modal>
  );
}
