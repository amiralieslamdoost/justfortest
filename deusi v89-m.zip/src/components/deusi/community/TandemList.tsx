import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  CalendarClock,
  Flag,
  Languages,
  MessageCircle,
  Plus,
  Search,
  Target,
  Trash2,
  Users2,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { getUser } from "@/lib/deusi/community/mockCommunity";
import { useCommunity } from "@/lib/deusi/community/store";
import type { CommunityLevel } from "@/lib/deusi/community/types";
import { FilterChip, LevelBadge, UserAvatar } from "./parts";
import { ReportModal, type ReportSubject } from "./ReportModal";

const LEVELS: CommunityLevel[] = ["A1", "A2", "B1", "B2", "C1", "C2"];

/** Anzeigenbrett: jede Person schreibt ihre eigene Sprechpartner-Anzeige. */
export function TandemList({ onCreate }: { onCreate: () => void }) {
  const { tandemAds, openDirectChat, deleteAd } = useCommunity();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [report, setReport] = useState<ReportSubject>(null);
  const [level, setLevel] = useState<CommunityLevel | "alle">("alle");

  const q = query.trim().toLowerCase();
  const list = useMemo(
    () =>
      tandemAds
        .filter((a) => (level === "alle" ? true : a.level === level))
        .filter(
          (a) =>
            !q ||
            a.headline.toLowerCase().includes(q) ||
            a.description.toLowerCase().includes(q) ||
            a.goal.toLowerCase().includes(q) ||
            a.nativeLanguage.toLowerCase().includes(q),
        ),
    [tandemAds, q, level],
  );

  return (
    <div className="space-y-4">
      {/* CTA */}
      <div className="neu-card grid gap-3 p-4 ring-1 ring-border/50 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:p-5">
        <div className="min-w-0">
          <h2 className="flex items-center gap-2 text-base font-black">
            <Users2
              className="h-5 w-5 shrink-0 text-[color:var(--section-primary,#c2410c)]"
              aria-hidden
            />
            Finde deinen Sprechpartner
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Gib eine eigene Anzeige auf oder schreibe jemanden direkt an — kostenlos und ohne
            Termin.
          </p>
          <FaHint size="sm">آگهی بگذار یا مستقیم پیام بده</FaHint>
        </div>
        <button
          type="button"
          onClick={onCreate}
          className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-[color:var(--section-primary,#c2410c)] px-4 py-3 text-sm font-bold text-white shadow-sm transition active:scale-95 sm:w-auto"
        >
          <Plus className="h-4 w-4" aria-hidden />
          Anzeige aufgeben
        </button>
      </div>

      {/* Toolbar */}
      <div className="space-y-2">
        <div className="relative">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Anzeigen durchsuchen…"
            aria-label="Anzeigen durchsuchen"
            className="h-11 w-full rounded-2xl border border-border/70 bg-card/70 pl-9 pr-3 text-sm outline-none transition focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
          />
        </div>
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          <FilterChip active={level === "alle"} onClick={() => setLevel("alle")}>
            Alle Niveaus
          </FilterChip>
          {LEVELS.map((l) => (
            <FilterChip key={l} active={level === l} onClick={() => setLevel(l)}>
              {l}
            </FilterChip>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <div className="neu-card py-14 text-center ring-1 ring-border/50">
          <p className="text-sm text-muted-foreground">Keine passende Anzeige.</p>
          <FaHint size="sm">آگهی‌ای پیدا نشد</FaHint>
        </div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((ad) => {
            const user = getUser(ad.userId);
            return (
              <li
                key={ad.id}
                className="neu-card flex flex-col gap-3 p-4 ring-1 ring-border/50 transition hover:ring-border"
              >
                <div className="flex items-start gap-3">
                  <span className="relative shrink-0">
                    <UserAvatar user={user} size={44} />
                    {user.online && (
                      <span
                        aria-hidden
                        className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-card"
                      />
                    )}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-base font-black leading-snug">{ad.headline}</h3>
                    <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-foreground/70">
                      <span className="truncate font-semibold">
                        {ad.mine ? "Deine Anzeige" : user.name}
                      </span>
                      <LevelBadge level={ad.level} />
                    </p>
                  </div>
                </div>

                {ad.description && (
                  <p className="text-sm leading-relaxed text-foreground/80">{ad.description}</p>
                )}

                <div className="flex flex-wrap gap-1.5">
                  <Tag icon={<Languages className="h-3.5 w-3.5" />}>{ad.nativeLanguage}</Tag>
                  <Tag icon={<Target className="h-3.5 w-3.5" />}>{ad.goal}</Tag>
                  <Tag icon={<CalendarClock className="h-3.5 w-3.5" />}>{ad.availability}</Tag>
                </div>

                <div className="mt-auto flex gap-2 pt-1">
                  {ad.mine ? (
                    <button
                      type="button"
                      onClick={() => deleteAd(ad.id)}
                      className="inline-flex w-full items-center justify-center gap-1.5 rounded-2xl bg-foreground/5 px-3 py-2.5 text-sm font-bold text-muted-foreground transition hover:text-red-500"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden />
                      Anzeige löschen
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        const chatId = openDirectChat(ad.userId);
                        navigate({ to: "/community/chat/$chatId", params: { chatId } });
                      }}
                      className="inline-flex w-full items-center justify-center gap-1.5 rounded-2xl bg-[color:var(--section-primary,#c2410c)] px-3 py-2.5 text-sm font-bold text-white shadow-sm transition active:scale-95"
                    >
                      <MessageCircle className="h-4 w-4" aria-hidden />
                      Privat schreiben
                    </button>
                  )}
                  {!ad.mine && (
                    <button
                      type="button"
                      onClick={() =>
                        setReport({ type: "tandem_profile", id: ad.id, label: ad.headline })
                      }
                      aria-label="Anzeige melden"
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-foreground/5 text-muted-foreground transition hover:text-red-500"
                    >
                      <Flag className="h-4 w-4" aria-hidden />
                    </button>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <ReportModal subject={report} onClose={() => setReport(null)} />
    </div>
  );
}

function Tag({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-foreground/5 px-2.5 py-1 text-xs font-semibold text-foreground/70">
      {icon}
      {children}
    </span>
  );
}
