import { useState } from "react";
import { Flag } from "lucide-react";
import { Modal } from "@/components/deusi/Modal";
import { FaHint } from "@/components/deusi/FaHint";
import { REPORT_REASONS, useCommunity } from "@/lib/deusi/community/store";
import type { ReportReason, ReportTarget } from "@/lib/deusi/community/store";

export type ReportSubject = { type: ReportTarget; id: string; label: string } | null;

/** Meldung eines Inhalts oder Mitglieds — landet serverseitig in `reports`. */
export function ReportModal({ subject, onClose }: { subject: ReportSubject; onClose: () => void }) {
  const { reportContent } = useCommunity();
  const [reason, setReason] = useState<ReportReason>("spam");
  const [details, setDetails] = useState("");
  const [sent, setSent] = useState(false);

  if (!subject) return null;

  const submit = async () => {
    await reportContent({
      targetType: subject.type,
      targetId: subject.id,
      reason,
      details: details.trim(),
    });
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setDetails("");
      setReason("spam");
      onClose();
    }, 1200);
  };

  return (
    <Modal open onClose={onClose} title="Melden">
      {sent ? (
        <div className="space-y-2 py-6 text-center">
          <p className="text-sm font-bold">Danke! Unser Team prüft die Meldung.</p>
          <FaHint size="sm">گزارش شما ثبت شد و بررسی می‌شود</FaHint>
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Du meldest: <span className="font-bold text-foreground">{subject.label}</span>
          </p>

          <fieldset className="space-y-2">
            <legend className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">
              Grund
            </legend>
            {REPORT_REASONS.map((r) => (
              <label
                key={r.value}
                className={`flex cursor-pointer items-center justify-between gap-3 rounded-2xl px-3 py-2.5 text-sm ring-1 transition ${
                  reason === r.value
                    ? "bg-foreground/5 font-bold ring-border"
                    : "ring-border/50 hover:ring-border"
                }`}
              >
                <span>{r.de}</span>
                <span className="text-xs text-muted-foreground">{r.fa}</span>
                <input
                  type="radio"
                  name="report-reason"
                  className="sr-only"
                  checked={reason === r.value}
                  onChange={() => setReason(r.value)}
                />
              </label>
            ))}
          </fieldset>

          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            rows={3}
            maxLength={500}
            placeholder="Zusätzliche Hinweise (optional)"
            className="w-full rounded-2xl bg-foreground/5 p-3 text-sm outline-none ring-1 ring-border/50 focus:ring-border"
          />

          <button
            type="button"
            onClick={() => void submit()}
            className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-2xl bg-red-500 text-sm font-bold text-white active:scale-[0.99]"
          >
            <Flag className="h-4 w-4" aria-hidden />
            Meldung senden
          </button>
          <FaHint size="sm">گزارش محتوای نامناسب برای بررسی تیم پشتیبانی</FaHint>
        </div>
      )}
    </Modal>
  );
}
