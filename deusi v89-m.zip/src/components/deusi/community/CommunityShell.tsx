import { useState, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useCommunity } from "@/lib/deusi/community/store";
import { CommunityNav } from "./CommunityNav";
import { ChatList } from "./ChatList";
import { NewGroupModal } from "./NewGroupModal";

/**
 * Chat layout: hero + nav, chat list on the left (desktop) and the current
 * chat on the right. On mobile only one of them shows; an open chat takes the
 * whole screen (hero and app chrome are hidden by the root shell).
 */
export function CommunityShell({
  activeChatId,
  showListOnMobile,
  children,
}: {
  activeChatId?: string;
  /** true on the overview, false on an open chat */
  showListOnMobile: boolean;
  children?: ReactNode;
}) {
  const { chats, createGroup } = useCommunity();
  const [newGroup, setNewGroup] = useState(false);
  const navigate = useNavigate();

  // On an open chat the mobile view is fullscreen: no hero, no page padding.
  const fullscreen = !showListOnMobile;

  return (
    <div className={fullscreen ? "lg:space-y-4 lg:pb-16" : "space-y-4 pb-16"}>
      <CommunityNav className={fullscreen ? "hidden lg:block" : ""} />

      <div className="grid items-start gap-4 lg:grid-cols-[300px_minmax(0,1fr)] xl:grid-cols-[360px_minmax(0,1fr)]">
        <div
          className={`min-w-0 ${showListOnMobile ? "" : "hidden lg:block"} lg:h-[calc(100dvh-15rem)] lg:min-h-[420px]`}
        >
          <ChatList chats={chats} activeId={activeChatId} onNewGroup={() => setNewGroup(true)} />
        </div>
        <div
          className={`min-w-0 max-lg:[&>*]:rounded-none ${showListOnMobile ? "hidden lg:block" : "h-[100dvh]"} lg:h-[calc(100dvh-15rem)] lg:min-h-[420px]`}
        >
          {children}
        </div>
      </div>

      <NewGroupModal
        open={newGroup}
        onClose={() => setNewGroup(false)}
        onCreate={(input) => {
          const id = createGroup(input);
          setNewGroup(false);
          navigate({ to: "/community/chat/$chatId", params: { chatId: id } });
        }}
      />
    </div>
  );
}
