import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { HeartHandshake, MessagesSquare } from "lucide-react";
import { SectionHero } from "@/components/deusi/SectionHero";
import { FaHint } from "@/components/deusi/FaHint";

/** Section hero + the two community nav pills (chats / tandem). */
export function CommunityNav({ className = "" }: { className?: string }) {
  return (
    <SectionHero
      className={className}
      sectionKey="community"
      right={
        <nav className="grid w-full grid-cols-2 gap-2 sm:flex sm:w-auto">
          <NavPill
            to="/community"
            icon={<MessagesSquare className="h-4 w-4" />}
            de="Chats"
            fa="گفت‌وگوها"
          />
          <NavPill
            to="/community/tandem"
            icon={<HeartHandshake className="h-4 w-4" />}
            de="Sprechpartner"
            fa="پارتنر مکالمه"
          />
        </nav>
      }
    />
  );
}

function NavPill({
  to,
  icon,
  de,
  fa,
}: {
  to: "/community" | "/community/tandem";
  icon: ReactNode;
  de: string;
  fa: string;
}) {
  return (
    <Link
      to={to}
      activeOptions={{ exact: true }}
      // keep the reading position when switching between the two views
      resetScroll={false}
      activeProps={{ className: "!bg-white !text-[color:var(--section-primary,#c2410c)]" }}
      className="inline-flex min-w-0 flex-1 items-center justify-center gap-2 rounded-2xl bg-white/15 px-3 py-2.5 text-sm font-bold text-white ring-1 ring-white/25 backdrop-blur transition hover:bg-white/25 sm:flex-none sm:px-4"
    >
      <span className="shrink-0">{icon}</span>
      <span className="min-w-0 leading-tight">
        <span className="block truncate">{de}</span>
        <FaHint size="sm" className="!text-current !opacity-70">
          {fa}
        </FaHint>
      </span>
    </Link>
  );
}
