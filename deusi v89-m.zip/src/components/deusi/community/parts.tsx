import type { ReactNode } from "react";
import { Hash, Lock, Users2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Chat, ChatKind, CommunityUser } from "@/lib/deusi/community/types";

/**
 * Every chat kind has its own visual language so rooms, groups and private
 * chats never look alike: shape, accent colour, badge and background tint.
 */
export const KIND_STYLE: Record<
  ChatKind,
  {
    de: string;
    fa: string;
    /** Accent hex used for badges, bubbles and rails */
    accent: string;
    /** Avatar corner radius */
    radius: number;
    badge: string;
    rail: string;
    surface: string;
  }
> = {
  room: {
    de: "Talar",
    fa: "تالار عمومی",
    accent: "#0284c7",
    radius: 14,
    badge: "bg-sky-500/12 text-sky-700 dark:text-sky-300 ring-sky-500/25",
    rail: "bg-sky-500",
    surface: "bg-sky-500/[0.06]",
  },
  group: {
    de: "Gruppe",
    fa: "گروه",
    accent: "#7c3aed",
    radius: 22,
    badge: "bg-violet-500/12 text-violet-700 dark:text-violet-300 ring-violet-500/25",
    rail: "bg-violet-500",
    surface: "bg-violet-500/[0.06]",
  },
  dm: {
    de: "Privat",
    fa: "خصوصی",
    accent: "#0f766e",
    radius: 999,
    badge: "bg-teal-500/12 text-teal-700 dark:text-teal-300 ring-teal-500/25",
    rail: "bg-teal-500",
    surface: "bg-teal-500/[0.06]",
  },
};

export const KIND_LABEL: Record<ChatKind, { de: string; fa: string }> = {
  room: { de: KIND_STYLE.room.de, fa: KIND_STYLE.room.fa },
  group: { de: KIND_STYLE.group.de, fa: KIND_STYLE.group.fa },
  dm: { de: KIND_STYLE.dm.de, fa: KIND_STYLE.dm.fa },
};

/** Round initials avatar tinted with the user's accent color. */
export function UserAvatar({
  user,
  size = 40,
  className,
}: {
  user: CommunityUser;
  size?: number;
  className?: string;
}) {
  return (
    <span
      aria-hidden
      className={cn(
        "grid shrink-0 place-items-center rounded-full font-black ring-1 ring-inset",
        className,
      )}
      style={{
        width: size,
        height: size,
        fontSize: Math.round(size * 0.36),
        background: `linear-gradient(135deg, ${user.color}2e, ${user.color}12)`,
        color: user.color,
        // @ts-expect-error CSS custom prop
        "--tw-ring-color": `${user.color}45`,
      }}
    >
      {user.initials}
    </span>
  );
}

/** Avatar for any chat: shape differs per kind (square-ish room, soft group, round DM). */
export function ChatAvatar({ chat, size = 44 }: { chat: Chat; size?: number }) {
  const style = KIND_STYLE[chat.kind];
  const initials = chat.title
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
  return (
    <span className="relative shrink-0" style={{ width: size, height: size }}>
      <span
        aria-hidden
        className="grid h-full w-full place-items-center font-black ring-1 ring-inset"
        style={{
          borderRadius: style.radius,
          fontSize: Math.round(size * 0.42),
          background: `linear-gradient(135deg, ${chat.color}33, ${chat.color}14)`,
          color: chat.color,
          // @ts-expect-error CSS custom prop
          "--tw-ring-color": `${chat.color}40`,
        }}
      >
        {chat.emoji ?? initials}
      </span>
      <span
        aria-hidden
        className="absolute -bottom-1 -right-1 grid h-[18px] w-[18px] place-items-center rounded-full text-white ring-2 ring-card"
        style={{ background: style.accent }}
      >
        <KindIcon kind={chat.kind} className="h-2.5 w-2.5" />
      </span>
    </span>
  );
}

export function KindIcon({ kind, className }: { kind: ChatKind; className?: string }) {
  const Icon = kind === "room" ? Hash : kind === "group" ? Users2 : Lock;
  return <Icon className={cn("h-3.5 w-3.5 shrink-0", className)} aria-hidden />;
}

export function KindBadge({ kind, className }: { kind: ChatKind; className?: string }) {
  const style = KIND_STYLE[kind];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-black ring-1",
        style.badge,
        className,
      )}
    >
      <KindIcon kind={kind} className="h-3 w-3" />
      {style.de}
    </span>
  );
}

export function LevelBadge({ level }: { level: string }) {
  return (
    <span className="rounded-full bg-foreground/8 px-2 py-0.5 text-[10px] font-black tracking-wider text-foreground/70">
      {level}
    </span>
  );
}

export function FilterChip({
  active,
  onClick,
  children,
  accent,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  accent?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={active && accent ? { background: accent } : undefined}
      className={cn(
        "rounded-full px-3 py-1.5 text-xs font-semibold ring-1 transition",
        active
          ? "bg-[color:var(--section-primary,#c2410c)] text-white shadow-sm ring-transparent"
          : "bg-card/70 text-muted-foreground ring-border/70 hover:text-foreground hover:ring-border",
      )}
    >
      {children}
    </button>
  );
}
