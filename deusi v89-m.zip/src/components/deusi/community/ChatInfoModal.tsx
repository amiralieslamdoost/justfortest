import { useEffect, useState } from "react";
import { Crown, Info, Lock, Settings2, Trash2, Unlock, Users2 } from "lucide-react";
import { Modal } from "@/components/deusi/Modal";
import { FaHint } from "@/components/deusi/FaHint";
import { getUser } from "@/lib/deusi/community/mockCommunity";
import { useCommunity } from "@/lib/deusi/community/store";
import type { Chat, CommunityUser } from "@/lib/deusi/community/types";
import { ChatAvatar, KindBadge, KIND_STYLE, LevelBadge, UserAvatar } from "./parts";

const EMOJIS = ["✨", "📐", "🧩", "🎧", "📝", "🌙", "🤝", "🎬", "🚀", "☕️", "🔥", "🎯"];

/** Info- und Einstellungsfenster für Talare und Gruppen. */
export function ChatInfoModal({
  chat,
  open,
  onClose,
  onSelectUser,
}: {
  chat: Chat;
  open: boolean;
  onClose: () => void;
  onSelectUser: (user: CommunityUser) => void;
}) {
  const { updateChat, removeMember, toggleJoined } = useCommunity();
  const isAdmin = chat.ownerId === "me";
  const style = KIND_STYLE[chat.kind];

  const [tab, setTab] = useState<"info" | "settings">("info");
  const [title, setTitle] = useState(chat.title);
  const [description, setDescription] = useState(chat.description ?? "");
  const [emoji, setEmoji] = useState(chat.emoji ?? "✨");
  const [isPrivate, setIsPrivate] = useState(Boolean(chat.private));
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setTitle(chat.title);
    setDescription(chat.description ?? "");
    setEmoji(chat.emoji ?? "✨");
    setIsPrivate(Boolean(chat.private));
    setTab("info");
  }, [chat.id, chat.title, chat.description, chat.emoji, chat.private]);

  const members = chat.members.map(getUser);
  const owner = chat.ownerId ? getUser(chat.ownerId) : null;

  const save = () => {
    updateChat(chat.id, {
      title: title.trim() || chat.title,
      description: description.trim() || undefined,
      emoji,
      private: isPrivate,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 1600);
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={chat.kind === "room" ? "Talar-Info" : "Gruppen-Info"}
    >
      <div className="space-y-5">
        <div className="flex items-center gap-4">
          <ChatAvatar chat={chat} size={62} />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h4 className="truncate text-lg font-black">
                {chat.kind === "room" ? `#${chat.title}` : chat.title}
              </h4>
              <KindBadge kind={chat.kind} />
            </div>
            <p className="text-xs text-muted-foreground">
              {chat.members.length + 1} Mitglieder · {chat.private ? "privat" : "öffentlich"}
            </p>
          </div>
        </div>

        {isAdmin && (
          <div className="flex gap-1.5 rounded-2xl bg-foreground/5 p-1">
            {(["info", "settings"] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                style={tab === t ? { background: style.accent } : undefined}
                className={`flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition ${
                  tab === t ? "text-white" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t === "info" ? (
                  <>
                    <Info className="h-4 w-4" aria-hidden /> Info
                  </>
                ) : (
                  <>
                    <Settings2 className="h-4 w-4" aria-hidden /> Einstellungen
                  </>
                )}
              </button>
            ))}
          </div>
        )}

        {tab === "info" || !isAdmin ? (
          <div className="space-y-4">
            <p className="rounded-2xl bg-foreground/5 p-3 text-sm text-muted-foreground">
              {chat.description || "Keine Beschreibung vorhanden."}
            </p>

            {owner && (
              <div className="flex items-center gap-3 rounded-2xl p-2 ring-1 ring-border/70">
                <UserAvatar user={owner} size={36} />
                <div className="min-w-0 flex-1">
                  <span className="truncate text-sm font-bold">
                    {owner.id === "me" ? "Du" : owner.name}
                  </span>
                  <p className="text-[11px] text-muted-foreground">Admin</p>
                </div>
                <Crown className="h-4 w-4 text-amber-500" aria-hidden />
              </div>
            )}

            <div>
              <h5 className="mb-2 flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-muted-foreground">
                <Users2 className="h-4 w-4" aria-hidden /> Mitglieder ({members.length})
              </h5>
              <ul className="space-y-1">
                {members.map((u) => (
                  <li
                    key={u.id}
                    className="flex items-center gap-3 rounded-2xl p-2 hover:bg-foreground/5"
                  >
                    <button
                      type="button"
                      onClick={() => onSelectUser(u)}
                      aria-label={`Profil von ${u.name}`}
                    >
                      <UserAvatar user={u} size={36} />
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectUser(u)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <span className="flex items-center gap-2">
                        <span className="truncate text-sm font-bold">{u.name}</span>
                        <LevelBadge level={u.level} />
                      </span>
                      <span className="text-xs text-muted-foreground">{u.handle}</span>
                    </button>
                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => removeMember(chat.id, u.id)}
                        aria-label={`${u.name} entfernen`}
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-muted-foreground ring-1 ring-border/70 transition hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" aria-hidden />
                      </button>
                    )}
                  </li>
                ))}
                {members.length === 0 && (
                  <li className="py-4 text-center text-sm text-muted-foreground">
                    Noch keine weiteren Mitglieder.
                  </li>
                )}
              </ul>
            </div>

            {chat.kind === "group" && (
              <button
                type="button"
                onClick={() => {
                  toggleJoined(chat.id);
                  onClose();
                }}
                className="h-11 w-full rounded-2xl text-sm font-bold ring-1 ring-border/70 transition hover:text-red-500"
              >
                {chat.joined ? "Gruppe verlassen" : "Gruppe beitreten"}
              </button>
            )}

            <FaHint size="sm">برای دیدن اطلاعات هر عضو روی عکس پروفایلش بزن</FaHint>
          </div>
        ) : (
          <div className="space-y-4">
            <FaHint size="sm">تو ادمین این گروه هستی و می‌توانی تنظیمات را تغییر دهی</FaHint>

            <label className="block">
              <span className="mb-1 block text-xs font-bold text-muted-foreground">Name</span>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value.slice(0, 40))}
                className="h-11 w-full rounded-2xl border border-border/70 bg-card/80 px-3 text-sm outline-none focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-xs font-bold text-muted-foreground">
                Beschreibung
              </span>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value.slice(0, 200))}
                rows={3}
                className="w-full resize-none rounded-2xl border border-border/70 bg-card/80 p-3 text-sm outline-none focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
              />
            </label>

            <div>
              <span className="mb-1.5 block text-xs font-bold text-muted-foreground">Symbol</span>
              <div className="flex flex-wrap gap-1.5">
                {EMOJIS.map((e) => (
                  <button
                    key={e}
                    type="button"
                    onClick={() => setEmoji(e)}
                    className={`grid h-10 w-10 place-items-center rounded-2xl text-lg ring-1 transition ${
                      emoji === e
                        ? "bg-foreground/10 ring-foreground/30"
                        : "ring-border/70 hover:bg-foreground/5"
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsPrivate((v) => !v)}
              className="flex w-full items-center gap-3 rounded-2xl p-3 text-left ring-1 ring-border/70"
            >
              {isPrivate ? (
                <Lock className="h-4 w-4 shrink-0" aria-hidden />
              ) : (
                <Unlock className="h-4 w-4 shrink-0" aria-hidden />
              )}
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-bold">
                  {isPrivate ? "Privat" : "Öffentlich"}
                </span>
                <span className="block text-xs text-muted-foreground">
                  {isPrivate
                    ? "Nur mit Einladung beitreten"
                    : "Alle können die Gruppe finden und beitreten"}
                </span>
              </span>
              <span
                className={`h-6 w-11 shrink-0 rounded-full p-0.5 transition ${
                  isPrivate ? "bg-foreground/80" : "bg-foreground/20"
                }`}
              >
                <span
                  className={`block h-5 w-5 rounded-full bg-card transition ${
                    isPrivate ? "translate-x-5" : ""
                  }`}
                />
              </span>
            </button>

            <button
              type="button"
              onClick={save}
              style={{ background: style.accent }}
              className="h-11 w-full rounded-2xl text-sm font-bold text-white active:scale-[0.99]"
            >
              {saved ? "Gespeichert ✓" : "Änderungen speichern"}
            </button>
          </div>
        )}
      </div>
    </Modal>
  );
}
