import { useState } from "react";
import { Modal } from "@/components/deusi/Modal";
import { FaHint } from "@/components/deusi/FaHint";
import type { CommunityLevel, TandemProfile } from "@/lib/deusi/community/types";

const LEVELS: CommunityLevel[] = ["A1", "A2", "B1", "B2", "C1", "C2"];

const field =
  "h-11 w-full rounded-2xl border border-border/70 bg-card/80 px-4 text-sm outline-none focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10";

/** Eigene Sprechpartner-Anzeige aufgeben. */
export function TandemAdModal({
  open,
  onClose,
  onCreate,
}: {
  open: boolean;
  onClose: () => void;
  onCreate: (input: Omit<TandemProfile, "id" | "userId" | "mine">) => void;
}) {
  const [headline, setHeadline] = useState("");
  const [nativeLanguage, setNativeLanguage] = useState("Persisch");
  const [level, setLevel] = useState<CommunityLevel>("B1");
  const [goal, setGoal] = useState("");
  const [availability, setAvailability] = useState("");
  const [description, setDescription] = useState("");

  const reset = () => {
    setHeadline("");
    setGoal("");
    setAvailability("");
    setDescription("");
  };

  return (
    <Modal
      open={open}
      onClose={() => {
        reset();
        onClose();
      }}
      title="Anzeige aufgeben"
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!headline.trim()) return;
          onCreate({
            headline: headline.trim(),
            nativeLanguage,
            level,
            goal: goal.trim() || "Sprechen üben",
            availability: availability.trim() || "Flexibel",
            description: description.trim(),
          });
          reset();
        }}
        className="space-y-4"
      >
        <FaHint size="sm">آگهی خودت را بنویس تا دیگران پیدایت کنند</FaHint>

        <Label text="Überschrift">
          <input
            value={headline}
            onChange={(e) => setHeadline(e.target.value.slice(0, 70))}
            required
            placeholder="z. B. B1 sprechen — jeden Abend 20 Minuten"
            className={field}
          />
        </Label>

        <div className="grid gap-3 sm:grid-cols-2">
          <Label text="Muttersprache">
            <input
              value={nativeLanguage}
              onChange={(e) => setNativeLanguage(e.target.value.slice(0, 30))}
              className={field}
            />
          </Label>
          <Label text="Mein Niveau">
            <div className="flex flex-wrap gap-1.5">
              {LEVELS.map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setLevel(l)}
                  className={`rounded-full px-3 py-1.5 text-xs font-black ring-1 transition ${
                    level === l
                      ? "bg-[color:var(--section-primary,#c2410c)] text-white ring-transparent"
                      : "bg-card/70 text-muted-foreground ring-border/70"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </Label>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <Label text="Ziel">
            <input
              value={goal}
              onChange={(e) => setGoal(e.target.value.slice(0, 40))}
              placeholder="telc B2 Sprechteil"
              className={field}
            />
          </Label>
          <Label text="Verfügbarkeit">
            <input
              value={availability}
              onChange={(e) => setAvailability(e.target.value.slice(0, 40))}
              placeholder="Abends / Wochenende"
              className={field}
            />
          </Label>
        </div>

        <Label text="Beschreibung">
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value.slice(0, 400))}
            rows={4}
            placeholder="Erzähl kurz, wie du üben möchtest."
            className="w-full resize-none rounded-2xl border border-border/70 bg-card/80 px-4 py-3 text-sm outline-none focus:border-foreground/30 focus:ring-4 focus:ring-foreground/10"
          />
        </Label>

        <button
          type="submit"
          className="h-11 w-full rounded-2xl bg-[color:var(--section-primary,#c2410c)] text-sm font-bold text-white shadow-sm"
        >
          Anzeige veröffentlichen
        </button>
      </form>
    </Modal>
  );
}

function Label({ text, children }: { text: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
        {text}
      </span>
      {children}
    </label>
  );
}
