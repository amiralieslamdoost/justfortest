import * as React from "react";
import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

type Tone = "surface" | "hero";
type Size = "sm" | "md" | "lg";

type Props = {
  value: string;
  onValueChange: (v: string) => void;
  placeholder?: string;
  tone?: Tone;
  size?: Size;
  className?: string;
  inputClassName?: string;
  trailing?: React.ReactNode;
  autoFocus?: boolean;
  clearable?: boolean;
  ariaLabel?: string;
  onKeyDown?: React.KeyboardEventHandler<HTMLInputElement>;
  onFocus?: React.FocusEventHandler<HTMLInputElement>;
  onBlur?: React.FocusEventHandler<HTMLInputElement>;
};

const shell: Record<Tone, string> = {
  surface:
    "border border-border/70 bg-card/80 text-foreground shadow-[0_8px_24px_-18px_rgb(0_0_0/0.45)] backdrop-blur-sm " +
    "hover:border-border focus-within:border-foreground/35 focus-within:ring-4 focus-within:ring-foreground/10",
  hero:
    "border border-white/25 bg-white/12 text-white shadow-[0_18px_40px_-26px_rgb(0_0_0/0.7)] backdrop-blur-md " +
    "hover:bg-white/16 focus-within:border-white/55 focus-within:bg-white/20 focus-within:ring-4 focus-within:ring-white/20",
};

const sizes: Record<Size, { box: string; icon: string; text: string; gap: string }> = {
  sm: { box: "h-10 rounded-xl px-3", icon: "h-4 w-4", text: "text-xs", gap: "gap-2" },
  md: { box: "h-11 rounded-2xl px-3.5", icon: "h-4 w-4", text: "text-sm", gap: "gap-2.5" },
  lg: { box: "h-14 rounded-2xl px-4", icon: "h-5 w-5", text: "text-base", gap: "gap-3" },
};

/** Einheitliches Suchfeld / فیلد جستجوی یکسان در کل سایت */
export function SearchField({
  value,
  onValueChange,
  placeholder = "Suchen…",
  tone = "surface",
  size = "md",
  className,
  inputClassName,
  trailing,
  autoFocus,
  clearable = true,
  ariaLabel,
  onKeyDown,
  onFocus,
  onBlur,
}: Props) {
  const s = sizes[size];
  return (
    <div
      className={cn(
        "group relative flex w-full min-w-0 items-center transition-all duration-200",
        s.box,
        s.gap,
        shell[tone],
        className,
      )}
    >
      <Search
        aria-hidden
        className={cn(
          "shrink-0 transition-colors",
          s.icon,
          tone === "hero"
            ? "text-white/70 group-focus-within:text-white"
            : "text-muted-foreground group-focus-within:text-foreground",
        )}
      />
      <input
        value={value}
        onChange={(e) => onValueChange(e.target.value)}
        onKeyDown={onKeyDown}
        onFocus={onFocus}
        onBlur={onBlur}
        autoFocus={autoFocus}
        placeholder={placeholder}
        aria-label={ariaLabel ?? placeholder}
        className={cn(
          "min-w-0 flex-1 bg-transparent font-medium outline-none",
          s.text,
          tone === "hero"
            ? "text-white placeholder:text-white/60"
            : "text-foreground placeholder:text-muted-foreground",
          inputClassName,
        )}
      />
      {clearable && value ? (
        <button
          type="button"
          onClick={() => onValueChange("")}
          aria-label="Suche löschen"
          className={cn(
            "grid shrink-0 place-items-center rounded-full transition",
            size === "lg" ? "h-8 w-8" : "h-6 w-6",
            tone === "hero"
              ? "text-white/70 hover:bg-white/20 hover:text-white"
              : "text-muted-foreground hover:bg-secondary hover:text-foreground",
          )}
        >
          <X className={size === "lg" ? "h-4 w-4" : "h-3.5 w-3.5"} />
        </button>
      ) : null}
      {trailing}
    </div>
  );
}
