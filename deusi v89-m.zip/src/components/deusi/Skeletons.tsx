import { cn } from "@/lib/utils";

type SkelProps = React.HTMLAttributes<HTMLDivElement>;

/**
 * Base shimmer bar. All skeleton compositions build on this.
 */
export function Skel({ className, ...props }: SkelProps) {
  return (
    <div
      aria-hidden
      className={cn("animate-pulse rounded-[var(--r-sm)] bg-foreground/10", className)}
      {...props}
    />
  );
}

/** Full "card + rows" placeholder used across list views. */
export function SkelCard({ rows = 3, className }: { rows?: number; className?: string }) {
  return (
    <div
      className={cn("neu-card space-y-3 p-5", className)}
      role="status"
      aria-label="Wird geladen"
    >
      <Skel className="h-4 w-1/3" />
      <Skel className="h-3 w-2/3" />
      <div className="space-y-2 pt-2">
        {Array.from({ length: rows }).map((_, i) => (
          <Skel key={i} className="h-3 w-full" style={{ opacity: 1 - i * 0.15 }} />
        ))}
      </div>
    </div>
  );
}

/** Grid of card skeletons matching typical dashboard layouts. */
export function SkelGrid({ count = 6, className }: { count?: number; className?: string }) {
  return (
    <div className={cn("grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3", className)}>
      {Array.from({ length: count }).map((_, i) => (
        <SkelCard key={i} />
      ))}
    </div>
  );
}

/** Header + body page skeleton — default pendingComponent. */
export function SkelPage() {
  return (
    <div className="space-y-5 p-2" role="status" aria-label="Seite wird geladen">
      <div className="neu-card p-6">
        <Skel className="mb-3 h-6 w-1/3" />
        <Skel className="h-4 w-2/3" />
      </div>
      <SkelGrid count={6} />
    </div>
  );
}
