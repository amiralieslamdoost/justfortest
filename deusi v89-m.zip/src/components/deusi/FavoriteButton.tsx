import { motion, AnimatePresence } from "framer-motion";
import { Heart } from "lucide-react";
import { useInteractions, type InteractionType, type ItemMeta } from "@/lib/deusi/interactions";
import { cn } from "@/lib/utils";

interface Props extends ItemMeta {
  type: InteractionType;
  id: string;
  label?: string;
  size?: number;
  className?: string;
}

export function FavoriteButton({
  type,
  id,
  label,
  size = 18,
  className,
  title,
  sub,
  level,
  to,
}: Props) {
  const { isFavorited, toggleFavorite } = useInteractions();
  const active = isFavorited(type, id);

  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.85 }}
      whileHover={{ scale: 1.06 }}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleFavorite(type, id, { title: title ?? label, sub, level, to });
      }}
      aria-pressed={active}
      aria-label={active ? "Aus Favoriten entfernen" : "Zu Favoriten hinzufügen"}
      className={cn(
        "focus-ring relative inline-grid h-8 w-8 place-items-center rounded-full transition-colors hover:bg-foreground/5",
        active && "text-rose-500",
        className,
      )}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={active ? "on" : "off"}
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.4, opacity: 0 }}
          transition={{ type: "spring", stiffness: 500, damping: 20 }}
          className="inline-grid place-items-center"
        >
          <Heart
            width={size}
            height={size}
            className={active ? "fill-current" : ""}
            strokeWidth={1.8}
          />
        </motion.span>
      </AnimatePresence>
      {active && (
        <motion.span
          aria-hidden
          initial={{ scale: 0, opacity: 0.5 }}
          animate={{ scale: 1.8, opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="pointer-events-none absolute inset-0 rounded-full bg-rose-400/30"
        />
      )}
    </motion.button>
  );
}
