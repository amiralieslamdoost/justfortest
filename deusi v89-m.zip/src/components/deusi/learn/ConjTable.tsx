import type { VerbWord } from "@/lib/deusi/types";

interface ConjTableProps {
  v: VerbWord;
}

export function ConjTable({ v }: ConjTableProps) {
  const pronouns: Array<keyof VerbWord["praesens"]> = ["ich", "du", "er", "wir", "ihr", "sie"];
  const label: Record<string, string> = {
    ich: "ich",
    du: "du",
    er: "er / sie / es",
    wir: "wir",
    ihr: "ihr",
    sie: "sie / Sie",
  };
  const auxCls = v.aux === "sein" ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-700";
  return (
    <div>
      <div className="mb-3 text-center">
        <div className="text-4xl font-bold">{v.infinitive}</div>
        <div className="mt-1 text-sm text-muted-foreground">
          Hilfsverb:{" "}
          <span className={`inline-block rounded-md px-1.5 py-0.5 font-semibold ${auxCls}`}>
            {v.aux}
          </span>
        </div>
      </div>
      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-start text-sm">
          <thead className="text-xs text-muted-foreground">
            <tr>
              <th className="p-3 text-start font-medium">Person</th>
              <th className="p-3 text-start font-medium">Präsens</th>
              <th className="p-3 text-start font-medium">Präteritum</th>
              <th className="p-3 text-start font-medium">Perfekt</th>
            </tr>
          </thead>
          <tbody>
            {pronouns.map((p) => {
              const [auxW, ...rest] = String(v.perfektConj[p]).split(" ");
              return (
                <tr key={p} className="border-t border-border">
                  <td className="p-3 text-muted-foreground">{label[p]}</td>
                  <td className="p-3 font-semibold">{v.praesens[p]}</td>
                  <td className="p-3 font-semibold">{v.praeteritumConj[p]}</td>
                  <td className="p-3 font-semibold">
                    <span className={`inline-block rounded-md px-1.5 py-0.5 ${auxCls}`}>
                      {auxW}
                    </span>{" "}
                    {rest.join(" ")}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
