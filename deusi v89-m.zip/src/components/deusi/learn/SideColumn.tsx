import type { Word } from "@/lib/deusi/types";
import { NodeBox, attributesFor } from "@/components/deusi/learn/NodeBox";

interface SideColumnProps {
  side: "left" | "right";
  word: Word;
  revealed: boolean;
  accent: string;
}

export function SideColumn({ side, word, revealed, accent }: SideColumnProps) {
  const nodes = attributesFor(word, side);
  return (
    <div className="flex flex-col gap-4">
      {nodes.map((n, i) => (
        <div
          key={`${word.id}-${side}-${i}`}
          className={`relative ${revealed ? "node-in" : "opacity-0 pointer-events-none"}`}
          style={
            revealed ? { animationDelay: `${i * 110 + (side === "left" ? 40 : 120)}ms` } : undefined
          }
        >
          <NodeBox spec={n} accent={accent} />
          {/* Verbindungslinie zur Mitte */}
          <span
            aria-hidden
            className="absolute top-1/2 hidden h-px md:block"
            style={{
              [side === "left" ? "right" : "left"]: "-4rem",
              width: "4rem",
              background: `linear-gradient(${side === "left" ? "to right" : "to left"}, ${accent}00, ${accent}aa)`,
            }}
          />
          <span
            aria-hidden
            className="absolute top-1/2 hidden h-2 w-2 -translate-y-1/2 rounded-full md:block"
            style={{
              [side === "left" ? "right" : "left"]: "-4.35rem",
              background: accent,
              boxShadow: `0 0 0 3px ${accent}22`,
            }}
          />
        </div>
      ))}
    </div>
  );
}
