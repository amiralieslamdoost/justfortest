import type { Word, VerbWord, NounWord, AdjectiveWord, PrepositionWord } from "@/lib/deusi/types";
import {
  POS_DE,
  primaryOf,
  articleColor,
  prepPattern,
  speak,
  discClass,
  CaseShape,
  SpeakerIcon,
} from "@/components/deusi/learn/learnHelpers";

interface CenterStageProps {
  word: Word;
  revealed: boolean;
  onFlip: () => void;
  onOpenConj: () => void;
}

export function CenterStage({ word, revealed, onFlip, onOpenConj }: CenterStageProps) {
  const article = word.pos === "noun" ? word.article : undefined;

  return (
    <div className="relative mx-auto w-full max-w-[360px] sm:max-w-[440px]">
      {/* Rotating conic gradient disc */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 grid place-items-center"
      >
        <div className="relative h-[112%] w-[112%]">
          <div className={`pos-disc ${discClass(word)}`} />
          <div className={`pos-disc b2 ${discClass(word)}`} />
        </div>
      </div>

      <div className="flip-scene">
        <div
          className={`flip-card ${revealed ? "is-flipped" : ""}`}
          onClick={onFlip}
          role="button"
          tabIndex={0}
          aria-label="Karte umdrehen"
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onFlip();
            }
          }}
        >
          {/* FRONT */}
          <div className="flip-face card-glass front w-full min-h-[360px] sm:min-h-[380px] md:min-h-[420px] lg:min-h-[440px] p-5 sm:p-8 md:p-10 flex flex-col items-center justify-center text-center">
            {article && (
              <div
                className="mb-2 text-xl font-bold tracking-tight sm:mb-4 sm:text-2xl"
                style={{ color: articleColor(article) }}
              >
                {article}
              </div>
            )}
            <h2 className="text-4xl font-bold tracking-tight sm:text-6xl md:text-7xl">
              {primaryOf(word)}
            </h2>

            <div className="mt-3 flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground sm:mt-6 sm:text-xs">
              <span className="h-px w-8 bg-border" />
              <span>{POS_DE[word.pos]}</span>
              <span className="h-px w-8 bg-border" />
            </div>

            <span
              onClick={(e) => {
                e.stopPropagation();
                speak(primaryOf(word));
              }}
              role="button"
              tabIndex={0}
              className="mt-3 grid h-10 w-10 place-items-center rounded-full bg-white/80 text-muted-foreground shadow hover:bg-white transition sm:mt-6 sm:h-11 sm:w-11"
              aria-label="Aussprache"
            >
              <SpeakerIcon />
            </span>
          </div>

          {/* BACK */}
          <div className="flip-face card-glass back w-full min-h-[360px] sm:min-h-[380px] md:min-h-[420px] lg:min-h-[440px] p-5 sm:p-8 flex flex-col items-center justify-center text-center">
            {article && (
              <div className="text-lg font-bold" style={{ color: articleColor(article) }}>
                {article}
              </div>
            )}
            <h2 className="mt-1 text-3xl font-bold tracking-tight sm:text-5xl">
              {primaryOf(word)}
            </h2>

            {word.pos === "adjective" && (
              <div className="mt-4 flex items-center gap-2 text-base font-semibold">
                <span>{(word as AdjectiveWord).positive}</span>
                <span className="text-muted-foreground">·</span>
                <span style={{ color: "var(--hard)" }}>{(word as AdjectiveWord).comparative}</span>
                <span className="text-muted-foreground">·</span>
                <span style={{ color: "var(--again)" }}>{(word as AdjectiveWord).superlative}</span>
              </div>
            )}
            {word.pos === "verb" && (
              <div className="mt-4 text-sm text-muted-foreground">
                {(word as VerbWord).praeteritum} · {(word as VerbWord).perfekt}
                {(word as VerbWord).governedPreposition && (
                  <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[color:var(--accent)] px-3 py-1 text-xs font-bold text-[color:var(--accent-foreground)]">
                    <span>+ {(word as VerbWord).governedPreposition!.text}</span>
                    <span className="rounded-md bg-white/70 px-1.5 py-0.5 text-[10px] font-black text-slate-900">
                      {(word as VerbWord).governedPreposition!.case}
                    </span>
                  </div>
                )}
              </div>
            )}
            {word.pos === "noun" && (
              <div className="mt-4 text-sm text-muted-foreground">
                Plural: die {(word as NounWord).plural}
              </div>
            )}
            {word.pos === "preposition" &&
              (() => {
                const pat = prepPattern(word as PrepositionWord);
                return (
                  <div className="mt-4 flex flex-col items-center gap-2">
                    <div
                      className="relative grid place-items-center"
                      style={{ width: 96, height: 96 }}
                    >
                      <CaseShape shape={pat.shape} color={pat.color} tint={pat.tint} size={92} />
                      <span
                        className="absolute text-xs font-black uppercase tracking-wider"
                        style={{
                          color: pat.color,
                          transform: pat.shape === "diamond" ? "rotate(0deg)" : undefined,
                        }}
                      >
                        {(word as PrepositionWord).cases.join(" / ")}
                      </span>
                    </div>
                    <div className="text-xs font-bold" style={{ color: pat.color }}>
                      {pat.label}
                    </div>
                  </div>
                );
              })()}

            {word.example && (
              <p className="mt-5 max-w-[85%] text-sm italic text-foreground/80">„{word.example}"</p>
            )}

            <div
              dir="rtl"
              lang="fa"
              className="mt-6 rounded-2xl bg-white/70 px-5 py-3 text-lg font-semibold shadow-sm text-slate-900"
              style={{ fontFamily: "Vazirmatn, Sora, sans-serif" }}
            >
              {word.translation}
            </div>

            {word.pos === "verb" && (
              <span
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenConj();
                }}
                role="button"
                className="mt-5 rounded-full bg-white/85 px-4 py-1.5 text-xs font-semibold shadow-sm hover:bg-white text-slate-900"
              >
                ▤ Konjugation ansehen
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
