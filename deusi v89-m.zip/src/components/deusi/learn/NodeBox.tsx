import type { ReactNode } from "react";
import type { Word, NounWord, VerbWord, AdjectiveWord, PrepositionWord } from "@/lib/deusi/types";
import { articleColor } from "@/components/deusi/learn/learnHelpers";

export type NodeSpec = { icon: string; label: string; value: ReactNode; hint?: string };

interface NodeBoxProps {
  spec: NodeSpec;
  accent?: string;
  delay?: number;
}

export function NodeBox({ spec, accent, delay }: NodeBoxProps) {
  return (
    <div
      className="node-card"
      style={{
        borderColor: accent ? `${accent}33` : undefined,
        animationDelay: delay !== undefined ? `${delay}ms` : undefined,
      }}
    >
      <div className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground">
        <span style={{ color: accent }}>{spec.icon}</span>
        <span>{spec.label}</span>
      </div>
      <div className="text-sm font-semibold leading-snug">{spec.value}</div>
      {spec.hint && <div className="mt-0.5 text-[11px] text-muted-foreground">{spec.hint}</div>}
    </div>
  );
}

export function attributesFor(w: Word, side: "left" | "right"): NodeSpec[] {
  if (w.pos === "noun") {
    const n = w as NounWord;
    if (side === "left")
      return [
        { icon: "↕", label: "Plural", value: `die ${n.plural}` },
        { icon: "✎", label: "Beispiel", value: n.example ?? "—" },
        { icon: "🖼", label: "Bild", value: "—" },
      ];
    return [
      {
        icon: "◫",
        label: "Artikel",
        value: (
          <span style={{ color: articleColor(n.article) }}>
            {n.article} ({n.article === "der" ? "Mask." : n.article === "die" ? "Fem." : "Neutr."})
          </span>
        ),
      },
      { icon: "☰", label: "Wortart", value: "Nomen" },
      { icon: "★", label: "Häufigkeit", value: "B1 · Häufig" },
    ];
  }
  if (w.pos === "verb") {
    const v = w as VerbWord;
    if (side === "left")
      return [
        {
          icon: "→",
          label: "Präsens",
          value: `${v.praesens.ich} · ${v.praesens.du} · ${v.praesens.er}`,
        },
        { icon: "II", label: "Partizip II", value: v.perfekt.split(" ").slice(1).join(" ") || "—" },
        { icon: "✎", label: "Beispiel", value: v.example ?? "—" },
      ];
    return [
      { icon: "☰", label: "Wortart", value: "Verb" },
      {
        icon: "≡",
        label: "Hilfsverb",
        value: (
          <span style={{ color: v.aux === "sein" ? "var(--hard)" : "var(--again)" }}>{v.aux}</span>
        ),
      },
      { icon: "★", label: "Häufigkeit", value: "A1 · Sehr häufig" },
    ];
  }
  if (w.pos === "adjective") {
    const a = w as AdjectiveWord;
    if (side === "left")
      return [
        { icon: "↗", label: "Komparativ", value: a.comparative },
        { icon: "✎", label: "Beispiel", value: a.example ?? "—" },
        { icon: "⇋", label: "Gegenteil", value: a.antonym ?? "—" },
      ];
    return [
      { icon: "☰", label: "Wortart", value: "Adjektiv" },
      { icon: "▲", label: "Steigerung", value: "Pos · Komp · Sup" },
      { icon: "★", label: "Häufigkeit", value: "A2 · Grundwort" },
    ];
  }
  const p = w as PrepositionWord;
  if (side === "left")
    return [
      { icon: "✎", label: "Beispiel", value: p.example ?? "—" },
      { icon: "⇋", label: "Bedeutung", value: p.translation, hint: "Persisch" },
      {
        icon: "◫",
        label: "Muster",
        value: p.cases.length === 2 ? "Wechselpräposition" : `Immer mit ${p.cases[0]}`,
      },
    ];
  return [
    { icon: "☰", label: "Wortart", value: "Präposition" },
    { icon: "◈", label: "Kasus", value: p.cases.join(" / ") },
    { icon: "★", label: "Häufigkeit", value: "A2 · Häufig" },
  ];
}
