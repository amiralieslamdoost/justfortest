import type { Rating } from "@/lib/deusi/fsrs";

interface RateBtnProps {
  kind: Rating;
  title: string;
  onClick: () => void;
  onHover?: (r: Rating | null) => void;
  compact?: boolean;
}

export function RateBtn({ kind, title, onClick, onHover, compact = false }: RateBtnProps) {
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => onHover?.(kind)}
      onMouseLeave={() => onHover?.(null)}
      onFocus={() => onHover?.(kind)}
      onBlur={() => onHover?.(null)}
      onTouchStart={() => onHover?.(kind)}
      onTouchEnd={() => onHover?.(null)}
      className={`rate-pill ${kind}${compact ? " rate-pill--compact" : ""}`}
    >
      <span className="dot" />
      <span>{title}</span>
    </button>
  );
}
