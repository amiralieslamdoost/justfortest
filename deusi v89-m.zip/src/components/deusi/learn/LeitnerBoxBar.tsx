import { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { DeckCard } from "@/lib/deusi/types";
import type { Rating } from "@/lib/deusi/fsrs";
import { schedule } from "@/lib/deusi/fsrs";

type Box = 1 | 2 | 3 | 4 | 5;

const BOX_META: Record<Box, { label: string; color: string }> = {
  1: { label: "Neu", color: "#EF4444" },
  2: { label: "Lernend", color: "#F97316" },
  3: { label: "Vertraut", color: "#F7C948" },
  4: { label: "Gefestigt", color: "#84CC16" },
  5: { label: "Beherrscht", color: "#22C55E" },
};

const RATINGS: Rating[] = ["again", "hard", "good", "easy"];

interface Props {
  deck: DeckCard[];
  current: DeckCard;
  previewRating?: Rating | null;
}

export function LeitnerBoxBar({ deck, current, previewRating }: Props) {
  const counts = useMemo(() => {
    const c: Record<Box, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    for (const d of deck) c[d.box] += 1;
    return c;
  }, [deck]);

  const targets = useMemo(() => {
    const map = {} as Record<Rating, Box>;
    for (const r of RATINGS) map[r] = schedule(current, r).box as Box;
    return map;
  }, [current]);

  const currentBox = current.box as Box;
  const previewTarget = previewRating ? targets[previewRating] : null;

  return (
    <div className="rounded-2xl border border-border/70 bg-card/60 px-3 py-3 backdrop-blur">
      <div className="grid grid-cols-5 gap-1.5">
        {([1, 2, 3, 4, 5] as Box[]).map((b) => {
          const meta = BOX_META[b];
          const isCurrent = b === currentBox;
          const isTarget = previewTarget === b;
          return (
            <motion.div
              key={b}
              animate={{
                scale: isTarget ? 1.06 : 1,
                y: isTarget ? -2 : 0,
              }}
              transition={{ type: "spring", stiffness: 320, damping: 20 }}
              className="relative overflow-hidden rounded-xl border px-1 py-2 text-center"
              style={{
                borderColor: isTarget || isCurrent ? meta.color : "var(--border)",
                background: isTarget
                  ? `color-mix(in srgb, ${meta.color} 20%, transparent)`
                  : isCurrent
                    ? `color-mix(in srgb, ${meta.color} 9%, transparent)`
                    : "transparent",
                boxShadow: isTarget ? `0 6px 18px -8px ${meta.color}` : undefined,
              }}
              title={`Box ${b} · ${meta.label} · ${counts[b]}`}
            >
              <div
                className="text-[10px] font-bold uppercase tracking-wide"
                style={{ color: isCurrent || isTarget ? meta.color : "var(--muted-foreground)" }}
              >
                Box {b}
              </div>
              <div className="text-sm font-black tabular-nums text-foreground">{counts[b]}</div>

              <AnimatePresence>
                {isTarget && (
                  <motion.span
                    key="in"
                    initial={{ opacity: 0, y: -8, scale: 0.6 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.6 }}
                    transition={{ type: "spring", stiffness: 400, damping: 22 }}
                    className="absolute right-1 top-1 grid h-4 w-4 place-items-center rounded-full text-[9px] font-black text-white"
                    style={{ background: meta.color }}
                  >
                    ↓
                  </motion.span>
                )}
              </AnimatePresence>

              {isCurrent && (
                <span
                  aria-hidden
                  className="absolute inset-x-0 bottom-0 h-[2px]"
                  style={{ background: meta.color }}
                />
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
