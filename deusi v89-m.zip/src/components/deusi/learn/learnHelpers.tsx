import type { Word, PrepositionWord } from "@/lib/deusi/types";

export const POS_DE = {
  noun: "Substantiv",
  verb: "Verb",
  adjective: "Adjektiv",
  preposition: "Präposition",
} as const;

export function primaryOf(w: Word) {
  if (w.pos === "noun") return w.singular;
  if (w.pos === "verb") return w.infinitive;
  if (w.pos === "adjective") return w.positive;
  return w.preposition;
}
export function articleColor(a?: "der" | "die" | "das") {
  return a === "der" ? "var(--der)" : a === "die" ? "var(--die)" : "var(--das)";
}
export function accentColor(w: Word) {
  if (w.pos === "noun") return articleColor(w.article);
  if (w.pos === "verb") return "#F97316";
  if (w.pos === "adjective") return "#F7C948";
  return prepAccent(w as PrepositionWord);
}

/** Different color/shape per preposition case pattern for visual memory */
export function prepPattern(p: PrepositionWord): {
  color: string;
  tint: string;
  label: string;
  shape: "circle" | "square" | "diamond" | "hex";
} {
  const set = new Set(p.cases);
  const hasAkk = set.has("Akk");
  const hasDat = set.has("Dat");
  const hasGen = (set as Set<string>).has("Gen");
  if (hasAkk && hasDat)
    return {
      color: "#8B5CF6",
      tint: "#EDE9FE",
      label: "Wechselpräposition (Akk/Dat)",
      shape: "hex",
    };
  if (hasAkk) return { color: "#DD2222", tint: "#FEE9E7", label: "Akkusativ", shape: "circle" };
  if (hasDat) return { color: "#2563eb", tint: "#DBEAFE", label: "Dativ", shape: "square" };
  if (hasGen) return { color: "#059669", tint: "#D1FAE5", label: "Genitiv", shape: "diamond" };
  return { color: "#8B5CF6", tint: "#EDE9FE", label: p.cases.join("/"), shape: "hex" };
}
export function prepAccent(p: PrepositionWord) {
  return prepPattern(p).color;
}

export function CaseShape({
  shape,
  color,
  tint,
  size = 96,
}: {
  shape: "circle" | "square" | "diamond" | "hex";
  color: string;
  tint: string;
  size?: number;
}) {
  const common = { width: size, height: size } as const;
  if (shape === "circle")
    return (
      <div
        style={{
          ...common,
          background: tint,
          border: `3px solid ${color}`,
          borderRadius: "9999px",
        }}
      />
    );
  if (shape === "square")
    return (
      <div
        style={{ ...common, background: tint, border: `3px solid ${color}`, borderRadius: 12 }}
      />
    );
  if (shape === "diamond")
    return (
      <div
        style={{
          ...common,
          background: tint,
          border: `3px solid ${color}`,
          borderRadius: 8,
          transform: "rotate(45deg)",
        }}
      />
    );
  return (
    <div
      style={{
        ...common,
        background: tint,
        border: `3px solid ${color}`,
        clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
      }}
    />
  );
}
export function speak(t: string) {
  try {
    const u = new SpeechSynthesisUtterance(t);
    u.lang = "de-DE";
    speechSynthesis.speak(u);
  } catch {
    /* noop */
  }
}
export function discClass(w: Word) {
  if (w.pos === "noun") {
    return w.article === "der"
      ? "disc-noun-der"
      : w.article === "die"
        ? "disc-noun-die"
        : "disc-noun-das";
  }
  return `disc-${w.pos}`;
}

export function SpeakerIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="18"
      height="18"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
    >
      <path d="M4 10v4h4l5 4V6L8 10H4z" />
      <path d="M16 9a4 4 0 0 1 0 6" />
    </svg>
  );
}
