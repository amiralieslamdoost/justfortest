/**
 * کارت «آزمون آنلاین» در صفحهٔ جزئیات آزمون — سشن ۶.
 * فهرست بخش‌های Modelltest + تاریخچهٔ تلاش‌های کاربر.
 */
import { Link } from "@tanstack/react-router";
import { Clock, History, Play } from "lucide-react";
import { useExamAttempts, useExamSections } from "@/lib/api/useExams";
import { percentOf, verdictOf } from "@/lib/deusi/examScoring";

const SKILL_FA: Record<string, string> = {
  Lesen: "خواندن",
  Hoeren: "شنیدن",
  Schreiben: "نوشتن",
  Sprechen: "صحبت کردن",
  Modelltest: "آزمون کامل",
};

export function OnlineModelltests({ examId }: { examId: string }) {
  const { sections } = useExamSections(examId);
  const { attempts } = useExamAttempts(examId);

  if (!sections.length) return null;

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        {sections.map((s) => {
          const last = attempts.find((a) => a.sectionId === s.id && a.status !== "in-progress");
          const open = attempts.find((a) => a.sectionId === s.id && a.status === "in-progress");
          return (
            <div key={s.id} className="glass flex flex-col gap-3 rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-sm font-semibold leading-snug">{s.title}</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">
                    {s.skill} · {s.questions.length} Fragen · {s.maxPoints} P.
                    <span className="ms-1 opacity-70">{SKILL_FA[s.skill] ?? ""}</span>
                  </div>
                </div>
                <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-secondary/70 px-2.5 py-1 text-[11px] font-bold">
                  <Clock className="h-3.5 w-3.5" aria-hidden /> {s.durationMin}′
                </span>
              </div>

              {last ? (
                <div className="text-xs text-muted-foreground">
                  Letztes Ergebnis:{" "}
                  <strong className="text-foreground">
                    {percentOf(last.score, last.maxScore)}%
                  </strong>{" "}
                  · {verdictOf(percentOf(last.score, last.maxScore)).label}
                </div>
              ) : null}

              <Link
                to="/pruefungen/$examId/test"
                params={{ examId }}
                search={{ section: s.id }}
                className="inline-flex items-center justify-center gap-1.5 rounded-full bg-[color:var(--section-primary)] px-4 py-2 text-xs font-semibold text-white transition hover:opacity-90"
              >
                <Play className="h-3.5 w-3.5" aria-hidden />
                {open ? "Test fortsetzen" : "Test starten"}
              </Link>
            </div>
          );
        })}
      </div>

      {attempts.length ? (
        <div className="glass rounded-2xl p-4">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <History className="h-4 w-4 text-[color:var(--section-primary)]" aria-hidden />
            Deine Versuche
          </div>
          <ul className="mt-3 divide-y divide-border/60">
            {attempts.slice(0, 8).map((a) => {
              const pct = percentOf(a.score, a.maxScore);
              return (
                <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                  <span className="min-w-0 text-xs text-muted-foreground">
                    {new Date(a.startedAt).toLocaleDateString("de-DE")} ·{" "}
                    {SKILL_FA[a.skill] ?? a.skill}
                  </span>
                  <span className="flex items-center gap-2">
                    <span className="text-xs font-bold">
                      {a.status === "in-progress" ? "läuft…" : `${pct}%`}
                    </span>
                    {a.status !== "in-progress" ? (
                      <Link
                        to="/pruefungen/$examId/ergebnis/$attemptId"
                        params={{ examId, attemptId: a.id }}
                        className="rounded-full border border-border/70 px-3 py-1 text-[11px] font-semibold transition hover:border-[color:var(--section-primary)]/60"
                      >
                        Ergebnis
                      </Link>
                    ) : null}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
