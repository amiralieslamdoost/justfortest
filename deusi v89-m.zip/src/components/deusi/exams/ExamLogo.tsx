import type { LogoKind } from "@/lib/deusi/exams/mockExams";

const CONFIG: Record<LogoKind, { label: string; className: string; italic?: boolean }> = {
  testdaf: {
    label: "TestDaF",
    className: "bg-gradient-to-br from-slate-100 to-slate-200 text-slate-800",
  },
  telc: {
    label: "telc",
    className: "bg-gradient-to-br from-sky-500 to-sky-600 text-white",
    italic: true,
  },
  oesd: {
    label: "ÖSD",
    className: "bg-gradient-to-br from-red-500 to-red-600 text-white",
  },
  goethe: {
    label: "Goethe",
    className: "bg-gradient-to-br from-emerald-500 to-emerald-700 text-white",
  },
  dsh: {
    label: "DSH",
    className: "bg-gradient-to-br from-violet-500 to-violet-700 text-white",
  },
};

export function ExamLogo({ kind, size = 56 }: { kind: LogoKind; size?: number }) {
  const { label, className, italic } = CONFIG[kind];
  // fit the wordmark inside the tile: average glyph width ≈ 0.62em
  const fontSize = Math.min(size * 0.4, (size * 0.86) / (label.length * 0.6));

  return (
    <div
      style={{ width: size, height: size }}
      className={`grid shrink-0 place-items-center overflow-hidden rounded-2xl px-1 shadow-sm ${className}`}
    >
      <span
        style={{ fontSize, lineHeight: 1 }}
        className={`whitespace-nowrap font-black tracking-tight ${italic ? "italic" : ""}`}
      >
        {label}
      </span>
    </div>
  );
}
