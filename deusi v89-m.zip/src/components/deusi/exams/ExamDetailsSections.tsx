import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import {
  BookOpen,
  Building2,
  CalendarClock,
  ExternalLink,
  FileText,
  HelpCircle,
  Layers,
  MessageSquareQuote,
  Search,
  Star,
} from "lucide-react";
import {
  type Exam,
  type ExamBook,
  type ExamCenter,
  type ExamResource,
  type Experience,
  type PracticeFile,
} from "@/lib/deusi/exams/mockExams";
import { ExamLogo } from "@/components/deusi/exams/ExamLogo";
import { BookCard } from "@/components/deusi/exams/BookCard";
import { DownloadButton } from "@/components/deusi/exams/DownloadButton";
import { PrepTimeline } from "@/components/deusi/exams/PrepTimeline";
import { FaHint } from "@/components/deusi/FaHint";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";
import { SearchField } from "@/components/deusi/SearchField";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";
import { OnlineModelltests } from "@/components/deusi/exams/OnlineModelltests";

const SECTION_TITLE_FA: Record<string, string> = {
  "Buch-Bibliothek": "کتابخانه کتاب‌ها",
  Lernressourcen: "منابع یادگیری",
  Musterprüfungen: "نمونه آزمون‌ها",
  Vorbereitungsplan: "برنامه آماده‌سازی",
  "Erfahrungen von Teilnehmenden": "تجربه‌های شرکت‌کنندگان",
  "Prüfungszentren in Iran": "مراکز برگزاری آزمون در ایران",
  "Häufige Fragen": "پرسش‌های متداول",
};
function translateSectionTitle(t: string): string {
  if (SECTION_TITLE_FA[t]) return SECTION_TITLE_FA[t];
  if (t.startsWith("Über ")) return "درباره این آزمون";
  return "";
}

const TABS = [
  { id: "uebersicht", label: "Übersicht", icon: Layers },
  { id: "buecher", label: "Bücher", icon: BookOpen },
  { id: "ressourcen", label: "Ressourcen", icon: FileText },
  { id: "modelltests", label: "Modelltests", icon: FileText },
  { id: "plan", label: "Vorbereitungsplan", icon: CalendarClock },
  { id: "erfahrungen", label: "Erfahrungen", icon: MessageSquareQuote },
  { id: "institute", label: "Prüfungszentren", icon: Building2 },
  { id: "faq", label: "FAQ", icon: HelpCircle },
] as const;

export function Hero({ exam }: { exam: Exam }) {
  const t = SECTION_THEME.exams;
  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
      style={{
        backgroundImage: `linear-gradient(135deg, ${t.base} 0%, ${t.primary} 55%, ${t.accent} 135%)`,
      }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
        style={{ background: t.accent, opacity: 0.4 }}
      />

      <div className="relative flex flex-col gap-5 md:flex-row md:items-start">
        <div className="grid h-20 w-20 shrink-0 place-items-center rounded-2xl bg-white/95 p-2 shadow-lg ring-1 ring-white/40 sm:h-24 sm:w-24">
          <ExamLogo kind={exam.logo} size={72} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold uppercase tracking-widest backdrop-blur">
            {t.label}
          </div>
          <h1 className="mt-2 text-xl font-black leading-tight sm:text-2xl md:text-3xl">
            {exam.name}{" "}
            <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
              {exam.tagline}
            </span>
          </h1>
          <p className="mt-2.5 max-w-3xl text-sm leading-relaxed text-white/85">
            {exam.longDescription}
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-1.5">
            <BookmarkButton
              type="exam"
              id={exam.id}
              title={exam.name}
              sub={exam.tagline}
              level={exam.recommendedLevel}
              to={`/pruefungen/${exam.id}`}
              variant="chip"
              className="bg-white/15 text-white hover:bg-white/25"
            />
            {exam.levels.map((l) => (
              <span
                key={l}
                className="rounded-full bg-white/15 px-2.5 py-1 text-xs font-bold backdrop-blur"
              >
                {l}
              </span>
            ))}
          </div>

          <div className="mt-5 grid gap-2.5 sm:grid-cols-3">
            <HeroChip icon="⏱" title={exam.comparison.duration} subtitle="Prüfungsdauer" />
            <HeroChip icon="💶" title={exam.comparison.cost} subtitle="Prüfungsgebühr" />
            <HeroChip icon="📬" title={exam.comparison.results} subtitle="bis zum Ergebnis" />
          </div>
        </div>
      </div>
    </motion.section>
  );
}

function HeroChip({ icon, title, subtitle }: { icon: string; title: string; subtitle: string }) {
  return (
    <div className="flex min-w-0 items-center gap-3 rounded-2xl border border-white/20 bg-white/10 p-3 backdrop-blur">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/20 text-base">
        {icon}
      </span>
      <div className="min-w-0">
        <div className="truncate text-sm font-semibold text-white">{title}</div>
        <div className="truncate text-xs text-white/70">{subtitle}</div>
      </div>
    </div>
  );
}

export function StickyTabs() {
  const [active, setActive] = useState<string>("uebersicht");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-96px 0px -70% 0px", threshold: 0 },
    );
    TABS.forEach((t) => {
      const el = document.getElementById(t.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const onClick = (id: string) => {
    setActive(id);
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const current = TABS.find((t) => t.id === active) ?? TABS[0];
  const CurrentIcon = current.icon;

  return (
    <div className="sticky top-2 z-20 sm:top-3">
      <div className="glass-strong rounded-2xl p-1.5 shadow-sm sm:rounded-full">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          className="flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold sm:hidden"
        >
          <span className="flex min-w-0 items-center gap-2">
            <CurrentIcon
              className="h-4 w-4 shrink-0 text-[color:var(--section-primary)]"
              aria-hidden
            />
            <span className="truncate">{current.label}</span>
          </span>
          <span
            className={`shrink-0 text-xs text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`}
            aria-hidden
          >
            ▾
          </span>
        </button>

        <div
          className={`${open ? "mt-1 grid" : "hidden"} grid-cols-2 gap-1 sm:mt-0 sm:flex sm:flex-wrap sm:justify-center`}
        >
          {TABS.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => onClick(t.id)}
                aria-current={active === t.id ? "true" : undefined}
                className={`inline-flex min-w-0 items-center justify-start gap-2 rounded-xl px-3 py-2.5 text-xs font-semibold transition sm:justify-center sm:rounded-full sm:px-3.5 sm:py-2 ${
                  active === t.id
                    ? "bg-[color:var(--section-primary)] text-white shadow-sm"
                    : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" aria-hidden />
                <span className="truncate">{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Section({
  id,
  title,
  subtitle,
  action,
  children,
}: {
  id: string;
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <motion.section
      id={id}
      initial={{ opacity: 0, y: 8 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      className="neu-card scroll-mt-28 p-5 sm:p-6"
    >
      <div className="mb-5 grid grid-cols-[minmax(0,1fr)] gap-3 sm:flex sm:flex-wrap sm:items-end sm:justify-between">
        <div className="min-w-0">
          <h2 className="text-lg font-bold">{title}</h2>
          <FaHint size="sm">{translateSectionTitle(title)}</FaHint>
          {subtitle && (
            <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-muted-foreground">
              {subtitle}
            </p>
          )}
        </div>
        {action}
      </div>
      {children}
    </motion.section>
  );
}

export function Overview({ exam }: { exam: Exam }) {
  return (
    <Section id="uebersicht" title={`Über ${exam.shortName}`}>
      <p className="max-w-3xl text-sm leading-relaxed text-muted-foreground">
        {exam.longDescription}
      </p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {exam.highlights.map((h) => (
          <div key={h.title} className="glass rounded-2xl p-4">
            <div className="text-2xl">{h.icon}</div>
            <div className="mt-2 text-sm font-semibold">{h.title}</div>
            <div className="mt-1 text-xs leading-relaxed text-muted-foreground">{h.text}</div>
          </div>
        ))}
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <FactRow label="Empfohlenes Niveau" value={exam.recommendedLevel} />
        <FactRow label="Format" value={exam.comparison.format} />
        <FactRow label="Gültigkeit" value={exam.comparison.validity} />
        <FactRow label="Am besten für" value={exam.comparison.bestFor} />
        <FactRow label="Kosten (ca.)" value={exam.comparison.cost} />
        <FactRow label="Ergebnis nach" value={exam.comparison.results} />
      </div>
    </Section>
  );
}

function FactRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-2xl px-4 py-3">
      <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className="mt-0.5 text-sm font-semibold">{value}</div>
    </div>
  );
}

const BOOK_SKILLS: ExamBook["skill"][] = [
  "Komplett",
  "Schreiben",
  "Lesen",
  "Hören",
  "Sprechen",
  "Wortschatz",
  "Grammatik",
];

export function Books({ exam }: { exam: Exam }) {
  const [skill, setSkill] = useState<string>("Alle");
  const [q, setQ] = useState("");

  const list = useMemo(
    () =>
      exam.books.filter(
        (b) =>
          (skill === "Alle" || b.skill === skill) &&
          (q === "" || `${b.title} ${b.publisher}`.toLowerCase().includes(q.toLowerCase())),
      ),
    [exam.books, skill, q],
  );

  const available = BOOK_SKILLS.filter((s) => exam.books.some((b) => b.skill === s));

  return (
    <Section
      id="buecher"
      title="Buch-Bibliothek"
      subtitle={`${exam.books.length} empfohlene Bücher – kostenlos herunterladen und direkt loslegen.`}
      action={
        <div className="flex h-9 items-center gap-2 rounded-full border border-border/70 bg-card/60 px-3 sm:w-56">
          <Search className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Titel oder Verlag…"
            aria-label="Bücher suchen"
            className="w-full bg-transparent text-xs outline-none"
          />
        </div>
      }
    >
      <div className="mb-4 flex flex-wrap gap-1.5">
        {["Alle", ...available].map((s) => (
          <Pill key={s} active={skill === s} onClick={() => setSkill(s)}>
            {s}
          </Pill>
        ))}
      </div>
      {list.length === 0 ? (
        <EmptyState text="Keine Bücher gefunden. Bitte Filter anpassen." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {list.map((b, i) => (
            <BookCard key={b.id} book={b} index={i} />
          ))}
        </div>
      )}
    </Section>
  );
}

function Pill({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${
        active
          ? "border-transparent bg-[color:var(--section-primary)] text-white"
          : "border-border/70 bg-card/60 text-muted-foreground hover:border-[color:var(--section-primary)]/40 hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

export function Resources({ resources }: { resources: ExamResource[] }) {
  const cats = ["Alle", ...Array.from(new Set(resources.map((r) => r.category)))];
  const [cat, setCat] = useState<string>("Alle");
  const [q, setQ] = useState("");
  const list = useMemo(
    () =>
      resources.filter(
        (r) =>
          (cat === "Alle" || r.category === cat) &&
          (q === "" || r.title.toLowerCase().includes(q.toLowerCase())),
      ),
    [resources, cat, q],
  );

  return (
    <Section
      id="ressourcen"
      title="Lernressourcen"
      subtitle="PDFs, Wortschatzlisten, Grammatik, Audio und Videos zur Prüfung."
      action={
        <SearchField
          value={q}
          onValueChange={setQ}
          size="sm"
          placeholder="Ressourcen suchen…"
          className="rounded-full sm:w-56"
        />
      }
    >
      <div className="mb-4 flex flex-wrap gap-1.5">
        {cats.map((c) => (
          <Pill key={c} active={cat === c} onClick={() => setCat(c)}>
            {c}
          </Pill>
        ))}
      </div>
      {list.length === 0 ? (
        <EmptyState text="Keine Ressourcen gefunden." />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((r) => (
            <div
              key={r.id}
              className="glass flex items-start justify-between gap-3 rounded-2xl p-4 sm:p-5 transition hover:shadow-md"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-[color:var(--section-primary)]/10 px-1.5 py-0.5 text-[11px] font-bold uppercase text-[color:var(--section-primary)]">
                    {r.type}
                  </span>
                  <span className="text-[11px] font-semibold text-muted-foreground">{r.level}</span>
                </div>
                <div className="mt-1.5 truncate text-sm font-semibold">{r.title}</div>
                <div className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                  {r.description}
                </div>
                <div className="mt-2 text-[11px] text-muted-foreground">
                  Hinzugefügt: {r.uploadDate}
                  {r.size ? ` · ${r.size}` : ""}
                </div>
              </div>
              <DownloadButton title={r.title} note={r.description} variant="icon" />
            </div>
          ))}
        </div>
      )}
    </Section>
  );
}

export function Practice({ exam, files }: { exam: Exam; files: PracticeFile[] }) {
  return (
    <Section
      id="modelltests"
      title="Musterprüfungen"
      subtitle="Übe unter echten Prüfungsbedingungen – am besten mit Timer."
      action={
        <DownloadButton
          title={`${exam.shortName} Modelltest-Paket`}
          label="Alle Tests"
          variant="ghost"
        />
      }
    >
      <OnlineModelltests examId={exam.id} />

      <div className="mt-5 grid gap-3">
        {files.map((f) => (
          <div
            key={f.id}
            className="glass grid grid-cols-[minmax(0,1fr)] gap-3 rounded-2xl p-4 sm:flex sm:flex-wrap sm:items-center sm:justify-between"
          >
            <div className="flex min-w-0 flex-1 items-center gap-3">
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[color:var(--section-primary)]/10 text-[11px] font-bold text-[color:var(--section-primary)]">
                {f.fileType}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold leading-snug">{f.title}</div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  {f.skill} · {f.size} · {f.uploadDate}
                </div>
              </div>
            </div>
            <DownloadButton
              title={f.title}
              note={`${f.skill} · ${f.size}`}
              className="w-full sm:w-auto sm:shrink-0"
            />
          </div>
        ))}
      </div>
    </Section>
  );
}

export function PlanSection({ exam }: { exam: Exam }) {
  return (
    <Section
      id="plan"
      title="Vorbereitungsplan"
      subtitle="Ein 12-Wochen-Fahrplan. Hake ab, was du geschafft hast – dein Fortschritt bleibt gespeichert."
    >
      <PrepTimeline examId={exam.id} plan={exam.prepPlan} />
    </Section>
  );
}

export function Experiences({ items }: { items: Experience[] }) {
  const [sort, setSort] = useState<"neu" | "hilfreich" | "niveau">("neu");
  const sorted = useMemo(() => {
    const arr = [...items];
    if (sort === "neu") arr.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (sort === "hilfreich") arr.sort((a, b) => b.helpful - a.helpful);
    if (sort === "niveau") arr.sort((a, b) => a.level.localeCompare(b.level));
    return arr;
  }, [items, sort]);

  return (
    <Section
      id="erfahrungen"
      title="Erfahrungen von Teilnehmenden"
      action={
        <div className="flex gap-1 rounded-full bg-secondary p-1 text-xs font-semibold">
          {[
            { id: "neu", label: "Neueste" },
            { id: "hilfreich", label: "Hilfreichste" },
            { id: "niveau", label: "Niveau" },
          ].map((o) => (
            <button
              key={o.id}
              onClick={() => setSort(o.id as typeof sort)}
              className={`rounded-full px-3 py-1 transition ${
                sort === o.id ? "bg-foreground text-background" : "text-muted-foreground"
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>
      }
    >
      <div className="grid gap-3 md:grid-cols-2">
        {sorted.map((e) => (
          <div key={e.id} className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex min-w-0 items-center gap-2.5">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[color:var(--section-primary)]/10 text-xs font-bold text-[color:var(--section-primary)]">
                  {e.username.slice(0, 2).toUpperCase()}
                </span>
                <div className="min-w-0">
                  <div className="truncate text-sm font-semibold">{e.username}</div>
                  <div className="truncate text-xs text-muted-foreground">
                    Niveau {e.level} · {e.examDate}
                  </div>
                </div>
              </div>
              <div
                className="flex shrink-0 items-center gap-0.5"
                title={`Schwierigkeit: ${e.difficulty}/5`}
              >
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-3.5 w-3.5 ${i < e.difficulty ? "fill-amber-500 text-amber-500" : "text-muted-foreground/30"}`}
                    aria-hidden
                  />
                ))}
              </div>
            </div>
            <div className="mt-3 grid gap-1.5 text-xs">
              <TipRow label="Schreiben" text={e.writingTips} />
              <TipRow label="Sprechen" text={e.speakingTips} />
              <TipRow label="Lesen" text={e.readingTips} />
              <TipRow label="Hören" text={e.listeningTips} />
            </div>
            <p className="mt-3 border-t border-border pt-3 text-xs italic text-muted-foreground">
              „{e.notes}"
            </p>
            <div className="mt-2 text-[11px] text-muted-foreground">
              👍 {e.helpful} fanden das hilfreich · {e.createdAt}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

function TipRow({ label, text }: { label: string; text: string }) {
  return (
    <div className="flex gap-2">
      <span className="w-16 shrink-0 rounded-md bg-secondary px-1.5 py-0.5 text-center text-[11px] font-bold uppercase">
        {label}
      </span>
      <span className="min-w-0 leading-relaxed text-foreground/85">{text}</span>
    </div>
  );
}

export function Centers({ centers }: { centers: ExamCenter[] }) {
  return (
    <Section id="institute" title="Prüfungszentren in Iran">
      <div className="grid gap-3 md:grid-cols-2">
        {centers.map((c) => (
          <div key={c.id} className="glass rounded-2xl p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <div className="truncate text-sm font-bold">{c.name}</div>
                  {c.badge && (
                    <span
                      className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                        c.badge === "Offiziell"
                          ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                          : "bg-sky-500/15 text-sky-700 dark:text-sky-300"
                      }`}
                    >
                      {c.badge}
                    </span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground">{c.city}</div>
              </div>
            </div>
            <div className="mt-3 space-y-1.5 text-xs leading-relaxed">
              <div>📍 {c.address}</div>
              <div>
                📞{" "}
                <a href={`tel:${c.phone}`} className="hover:underline">
                  {c.phone}
                </a>
              </div>
              <div>
                🌐{" "}
                <a
                  href={c.website}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="hover:underline"
                >
                  {c.website.replace(/^https?:\/\//, "")}
                </a>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {c.examTypes.map((t) => (
                <span
                  key={t}
                  className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold"
                >
                  {t}
                </span>
              ))}
            </div>
            {c.upcomingSessions.length > 0 && (
              <div className="mt-3 rounded-xl bg-secondary/60 p-2.5 text-xs">
                <div className="mb-1 font-semibold">Nächste Termine</div>
                {c.upcomingSessions.map((s, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <span>
                      {s.date} · {s.level}
                    </span>
                    <span className="text-muted-foreground">{s.seatsLeft} Plätze frei</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </Section>
  );
}

export function FAQSection({ faq }: { faq: { q: string; a: string }[] }) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq" title="Häufige Fragen">
      <div className="space-y-2">
        {faq.map((item, i) => {
          const isOpen = open === i;
          return (
            <div key={i} className="glass overflow-hidden rounded-2xl">
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                aria-expanded={isOpen}
                className="flex w-full items-center justify-between gap-3 p-4 text-left text-sm font-semibold"
              >
                <span className="min-w-0">{item.q}</span>
                <span
                  className={`shrink-0 text-lg transition-transform ${isOpen ? "rotate-45" : ""}`}
                >
                  +
                </span>
              </button>
              {isOpen && (
                <div className="border-t border-border px-4 pb-4 pt-3 text-xs leading-relaxed text-muted-foreground">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </Section>
  );
}

export function StructureCard({ exam }: { exam: Exam }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="neu-card p-5"
    >
      <h3 className="text-sm font-bold">Aufbau der Prüfung</h3>
      <div className="mt-4 space-y-3">
        {exam.structure.map((s) => (
          <div key={s.skill}>
            <div className="flex items-center justify-between gap-3 text-xs">
              <span className="font-semibold">{s.skill}</span>
              <span className="text-muted-foreground">
                {s.minutes} Min. · {s.weight}%
              </span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-[color:var(--section-primary)]"
                style={{ width: `${s.weight * 2}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 rounded-xl bg-secondary/60 p-3 text-xs text-muted-foreground">
        Gesamtdauer: {exam.comparison.duration}
      </div>
    </motion.div>
  );
}

export function QuickFacts({ exam }: { exam: Exam }) {
  return (
    <div className="neu-card p-5">
      <h3 className="text-sm font-bold">Wichtige Informationen</h3>
      <ul className="mt-3 space-y-2.5 text-xs leading-relaxed text-muted-foreground">
        <li>⏱ Ergebnisse: {exam.comparison.results}</li>
        <li>♾ Gültigkeit: {exam.comparison.validity}</li>
        <li>💶 Gebühr: {exam.comparison.cost}</li>
        <li>🖥 Format: {exam.comparison.format}</li>
        <li>🔁 Wiederholung: jederzeit möglich</li>
      </ul>
    </div>
  );
}

export function QuickCentersCard({ centers }: { centers: ExamCenter[] }) {
  return (
    <div className="neu-card p-5">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="min-w-0 truncate text-sm font-bold">Prüfungsinstitute in Iran</h3>
        <a
          href="#institute"
          className="shrink-0 text-[11px] font-semibold text-[color:var(--section-primary)]"
        >
          Alle anzeigen
        </a>
      </div>
      <ul className="space-y-3">
        {centers.slice(0, 4).map((c) => (
          <li key={c.id} className="flex items-center gap-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-secondary text-[11px] font-bold">
              {c.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-semibold">{c.name}</div>
              <div className="truncate text-[11px] text-muted-foreground">{c.city}</div>
            </div>
            <span className="shrink-0 text-[11px] font-semibold text-amber-500">
              ★ 4.{5 + (c.name.length % 4)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="glass rounded-2xl p-8 text-center text-xs text-muted-foreground">{text}</div>
  );
}
