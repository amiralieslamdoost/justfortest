import { useEffect, useRef, useState } from "react";
import { Check, Download, Loader2 } from "lucide-react";

function triggerMockDownload(filename: string, body: string) {
  const blob = new Blob([body], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function slugify(s: string) {
  return s
    .toLowerCase()
    .replace(/[äöüß]/g, (c) => ({ ä: "ae", ö: "oe", ü: "ue", ß: "ss" })[c] ?? c)
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

type Variant = "solid" | "ghost" | "icon";

export function DownloadButton({
  title,
  note,
  label = "Download",
  variant = "solid",
  className = "",
}: {
  title: string;
  note?: string;
  label?: string;
  variant?: Variant;
  className?: string;
}) {
  const [state, setState] = useState<"idle" | "loading" | "done">("idle");
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const start = () => {
    if (state !== "idle") return;
    setState("loading");
    timers.current.push(
      setTimeout(() => {
        triggerMockDownload(
          `${slugify(title)}.txt`,
          `DEUSI – Demo-Download\n\n${title}\n${note ?? ""}\n\nDiese Datei ist ein Platzhalter. Die echten Materialien werden bald verknüpft.\n`,
        );
        setState("done");
      }, 900),
    );
    timers.current.push(setTimeout(() => setState("idle"), 2600));
  };

  const Icon = state === "loading" ? Loader2 : state === "done" ? Check : Download;
  const iconCls = `h-4 w-4 ${state === "loading" ? "animate-spin" : ""}`;

  if (variant === "icon") {
    return (
      <button
        type="button"
        onClick={start}
        aria-label={`${label}: ${title}`}
        className={`grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[color:var(--section-primary)]/10 text-[color:var(--section-primary)] transition hover:bg-[color:var(--section-primary)] hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--section-primary)] ${className}`}
      >
        <Icon className={iconCls} aria-hidden />
      </button>
    );
  }

  const base =
    "inline-flex items-center justify-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--section-primary)]";
  const skin =
    variant === "solid"
      ? "bg-[color:var(--section-primary)] text-white hover:opacity-90"
      : "border border-border/70 bg-card/60 text-foreground hover:border-[color:var(--section-primary)]/50";

  return (
    <button type="button" onClick={start} className={`${base} ${skin} ${className}`}>
      <Icon className={iconCls} aria-hidden />
      <span>
        {state === "done" ? "Gespeichert" : state === "loading" ? "Wird geladen…" : label}
      </span>
    </button>
  );
}
