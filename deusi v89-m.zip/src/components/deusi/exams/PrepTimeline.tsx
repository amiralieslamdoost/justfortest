import { useEffect, useMemo, useState } from "react";
import { CalendarDays, CheckCircle2, Circle } from "lucide-react";
import type { PrepWeek } from "@/lib/deusi/exams/mockExams";

function storageKey(examId: string) {
  return `deusi.exam.prep.${examId}`;
}
function dateKey(examId: string) {
  return `deusi.exam.date.${examId}`;
}

export function useExamDate(examId: string) {
  const [date, setDate] = useState("");
  useEffect(() => {
    setDate(localStorage.getItem(dateKey(examId)) ?? "");
  }, [examId]);
  const update = (v: string) => {
    setDate(v);
    if (v) localStorage.setItem(dateKey(examId), v);
    else localStorage.removeItem(dateKey(examId));
  };
  const daysLeft = useMemo(() => {
    if (!date) return null;
    const diff = new Date(`${date}T00:00:00`).getTime() - new Date().setHours(0, 0, 0, 0);
    return Math.round(diff / 86400000);
  }, [date]);
  return { date, setDate: update, daysLeft };
}

export function ExamDateCard({ examId }: { examId: string }) {
  const { date, setDate, daysLeft } = useExamDate(examId);
  return (
    <div className="neu-card p-5">
      <div className="flex items-center gap-2">
        <CalendarDays className="h-4 w-4 text-[color:var(--section-primary)]" aria-hidden />
        <h3 className="text-sm font-bold">Mein Prüfungstermin</h3>
      </div>
      <input
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
        className="mt-3 w-full rounded-xl border border-border/70 bg-card/60 px-3 py-2 text-xs outline-none focus:border-[color:var(--section-primary)]"
      />
      {daysLeft !== null && (
        <div className="mt-3 rounded-2xl bg-[color:var(--section-primary)]/10 p-3 text-center">
          <div className="text-2xl font-black text-[color:var(--section-primary)]">
            {daysLeft > 0 ? daysLeft : 0}
          </div>
          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            {daysLeft > 0 ? "Tage bis zur Prüfung" : "Viel Erfolg!"}
          </div>
        </div>
      )}
      {daysLeft === null && (
        <p className="mt-3 text-xs text-muted-foreground">
          Trage dein Datum ein – wir zeigen dir den Countdown und passen den Lernplan an.
        </p>
      )}
    </div>
  );
}

export function PrepTimeline({ examId, plan }: { examId: string; plan: PrepWeek[] }) {
  const [done, setDone] = useState<Record<string, boolean>>({});
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      setDone(JSON.parse(localStorage.getItem(storageKey(examId)) ?? "{}"));
    } catch {
      setDone({});
    }
    setReady(true);
  }, [examId]);

  const toggle = (id: string) => {
    setDone((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      localStorage.setItem(storageKey(examId), JSON.stringify(next));
      return next;
    });
  };

  const total = plan.reduce((s, w) => s + w.tasks.length, 0);
  const completed = Object.values(done).filter(Boolean).length;
  const pct = total ? Math.round((completed / total) * 100) : 0;

  return (
    <div>
      <div className="glass mb-5 flex flex-wrap items-center gap-4 rounded-2xl p-4">
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span>Dein Fortschritt</span>
            <span className="text-[color:var(--section-primary)]">
              {ready ? `${completed}/${total}` : "…"}
            </span>
          </div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-secondary">
            <div
              className="h-full rounded-full bg-[color:var(--section-primary)] transition-all duration-500"
              style={{ width: `${ready ? pct : 0}%` }}
            />
          </div>
        </div>
        <div className="text-2xl font-black text-[color:var(--section-primary)]">
          {ready ? pct : 0}%
        </div>
      </div>

      <ol className="relative space-y-4 border-l border-dashed border-border pl-6">
        {plan.map((w, wi) => {
          const weekDone = w.tasks.every((_, ti) => done[`${wi}-${ti}`]);
          return (
            <li key={w.week} className="relative">
              <span
                className={`absolute -left-[31px] grid h-5 w-5 place-items-center rounded-full text-[11px] font-bold ring-4 ring-background ${
                  weekDone
                    ? "bg-[color:var(--section-primary)] text-white"
                    : "bg-secondary text-muted-foreground"
                }`}
                aria-hidden
              >
                {wi + 1}
              </span>
              <div className="glass rounded-2xl p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-sm font-bold">{w.focus}</div>
                    <div className="text-xs text-muted-foreground">{w.week}</div>
                  </div>
                  {weekDone && (
                    <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] font-bold uppercase text-emerald-700 dark:text-emerald-300">
                      Erledigt
                    </span>
                  )}
                </div>
                <ul className="mt-3 space-y-1.5">
                  {w.tasks.map((t, ti) => {
                    const id = `${wi}-${ti}`;
                    const checked = !!done[id];
                    return (
                      <li key={id}>
                        <button
                          type="button"
                          onClick={() => toggle(id)}
                          className="flex w-full items-start gap-2 rounded-lg px-1.5 py-1 text-left text-xs transition hover:bg-secondary/60"
                          aria-pressed={checked}
                        >
                          {checked ? (
                            <CheckCircle2
                              className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--section-primary)]"
                              aria-hidden
                            />
                          ) : (
                            <Circle
                              className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground/50"
                              aria-hidden
                            />
                          )}
                          <span
                            className={
                              checked ? "text-muted-foreground line-through" : "text-foreground/85"
                            }
                          >
                            {t}
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
