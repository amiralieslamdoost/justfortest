/**
 * رندر یک سؤال آزمون (همهٔ انواع) — سشن ۶.
 * حالت آزمون (قابل پاسخ) و حالت مرور نتیجه (فقط‌خواندنی + پاسخ درست).
 */
import { Check, X } from "lucide-react";
import type { ExamQuestion, QuestionOption } from "@/lib/deusi/exams/mockModelltests";

export interface QuestionCardProps {
  question: ExamQuestion;
  index: number;
  total: number;
  value: unknown;
  onChange?: (value: unknown) => void;
  /** حالت مرور نتیجه */
  review?: boolean;
  earnedPoints?: number;
}

function asArray(value: unknown): string[] {
  return Array.isArray(value) ? (value as string[]) : [];
}

function asRecord(value: unknown): Record<string, string> {
  return value && typeof value === "object" ? (value as Record<string, string>) : {};
}

export function QuestionCard({
  question,
  index,
  total,
  value,
  onChange,
  review = false,
  earnedPoints,
}: QuestionCardProps) {
  const disabled = review || !onChange;

  return (
    <article className="glass rounded-3xl p-5 sm:p-6">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
            Frage {index + 1} / {total}
          </div>
          <h3 className="mt-1 text-base font-semibold leading-snug">{question.prompt}</h3>
        </div>
        <span className="shrink-0 rounded-full bg-secondary/70 px-3 py-1 text-xs font-bold">
          {review && earnedPoints !== undefined
            ? `${earnedPoints} / ${question.points} P.`
            : `${question.points} P.`}
        </span>
      </header>

      {question.passage ? (
        <div className="mt-4 whitespace-pre-line rounded-2xl border border-border/60 bg-card/50 p-4 text-sm leading-relaxed text-muted-foreground">
          {question.passage}
        </div>
      ) : null}

      <div className="mt-4 space-y-2">
        {question.kind === "single" ? (
          <ChoiceList
            options={question.options}
            selected={typeof value === "string" ? [value] : []}
            correct={review ? [question.correct] : undefined}
            multiple={false}
            disabled={disabled}
            onToggle={(id) => onChange?.(id)}
          />
        ) : null}

        {question.kind === "multi" ? (
          <ChoiceList
            options={question.options}
            selected={asArray(value)}
            correct={review ? question.correct : undefined}
            multiple
            disabled={disabled}
            onToggle={(id) => {
              const current = asArray(value);
              onChange?.(current.includes(id) ? current.filter((x) => x !== id) : [...current, id]);
            }}
          />
        ) : null}

        {question.kind === "truefalse" ? (
          <ChoiceList
            options={[
              { id: "true", text: "Richtig" },
              { id: "false", text: "Falsch" },
            ]}
            selected={value === true ? ["true"] : value === false ? ["false"] : []}
            correct={review ? [String(question.correct)] : undefined}
            multiple={false}
            disabled={disabled}
            onToggle={(id) => onChange?.(id === "true")}
          />
        ) : null}

        {question.kind === "gap" ? (
          <div>
            <input
              type="text"
              value={typeof value === "string" ? value : ""}
              disabled={disabled}
              onChange={(e) => onChange?.(e.target.value)}
              placeholder="Antwort eingeben…"
              className="w-full rounded-2xl border border-border/70 bg-card/60 px-4 py-3 text-sm outline-none transition focus:border-[color:var(--section-primary)]/60 disabled:opacity-70"
            />
            {review ? (
              <p className="mt-2 text-xs text-muted-foreground">
                Richtig: <strong>{question.accepted.join(" / ")}</strong>
              </p>
            ) : null}
          </div>
        ) : null}

        {question.kind === "matching" ? (
          <div className="space-y-2">
            {question.left.map((l) => {
              const chosen = asRecord(value)[l.id] ?? "";
              const isRight = review && chosen === question.correct[l.id];
              return (
                <div
                  key={l.id}
                  className="grid gap-2 rounded-2xl border border-border/60 bg-card/50 p-3 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] sm:items-center"
                >
                  <span className="text-sm font-medium">{l.text}</span>
                  <div className="flex items-center gap-2">
                    <select
                      value={chosen}
                      disabled={disabled}
                      onChange={(e) => onChange?.({ ...asRecord(value), [l.id]: e.target.value })}
                      className="w-full rounded-xl border border-border/70 bg-background px-3 py-2 text-sm outline-none disabled:opacity-70"
                    >
                      <option value="">— auswählen —</option>
                      {question.right.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.text}
                        </option>
                      ))}
                    </select>
                    {review ? (
                      isRight ? (
                        <Check className="h-4 w-4 shrink-0 text-emerald-500" aria-hidden />
                      ) : (
                        <X className="h-4 w-4 shrink-0 text-rose-500" aria-hidden />
                      )
                    ) : null}
                  </div>
                  {review && !isRight ? (
                    <p className="text-xs text-muted-foreground sm:col-span-2">
                      Richtig:{" "}
                      {question.right.find((r) => r.id === question.correct[l.id])?.text ?? "—"}
                    </p>
                  ) : null}
                </div>
              );
            })}
          </div>
        ) : null}

        {question.kind === "free" ? (
          <div>
            <textarea
              rows={8}
              value={typeof value === "string" ? value : ""}
              disabled={disabled}
              onChange={(e) => onChange?.(e.target.value)}
              placeholder="Schreibe deinen Text hier…"
              className="w-full rounded-2xl border border-border/70 bg-card/60 px-4 py-3 text-sm leading-relaxed outline-none transition focus:border-[color:var(--section-primary)]/60 disabled:opacity-70"
            />
            <div className="mt-1.5 flex flex-wrap justify-between gap-2 text-xs text-muted-foreground">
              <span>
                {typeof value === "string" && value.trim() ? value.trim().split(/\s+/).length : 0} /
                mind. {question.minWords} Wörter
              </span>
              <span>Bewertung: Selbsteinschätzung im Ergebnis</span>
            </div>
            {review && question.sample ? (
              <details className="mt-3 rounded-2xl border border-border/60 bg-card/50 p-3 text-sm">
                <summary className="cursor-pointer font-semibold">Musterlösung</summary>
                <p className="mt-2 whitespace-pre-line leading-relaxed text-muted-foreground">
                  {question.sample}
                </p>
              </details>
            ) : null}
          </div>
        ) : null}
      </div>

      {question.hint && !review ? (
        <p className="mt-3 text-xs text-muted-foreground">💡 {question.hint}</p>
      ) : null}

      {review && question.explanation ? (
        <p className="mt-3 rounded-2xl bg-secondary/50 p-3 text-xs leading-relaxed text-muted-foreground">
          {question.explanation}
        </p>
      ) : null}
    </article>
  );
}

function ChoiceList({
  options,
  selected,
  correct,
  multiple,
  disabled,
  onToggle,
}: {
  options: QuestionOption[];
  selected: string[];
  correct?: string[];
  multiple: boolean;
  disabled: boolean;
  onToggle: (id: string) => void;
}) {
  return (
    <div className="grid gap-2">
      {options.map((o) => {
        const isSelected = selected.includes(o.id);
        const isCorrect = correct?.includes(o.id);
        const tone = correct
          ? isCorrect
            ? "border-emerald-500/60 bg-emerald-500/10"
            : isSelected
              ? "border-rose-500/60 bg-rose-500/10"
              : "border-border/60"
          : isSelected
            ? "border-[color:var(--section-primary)] bg-[color:var(--section-primary)]/10"
            : "border-border/60 hover:border-[color:var(--section-primary)]/50";
        return (
          <button
            key={o.id}
            type="button"
            disabled={disabled}
            aria-pressed={isSelected}
            onClick={() => onToggle(o.id)}
            className={`flex items-center gap-3 rounded-2xl border bg-card/50 px-4 py-3 text-start text-sm transition disabled:cursor-default ${tone}`}
          >
            <span
              className={`grid h-5 w-5 shrink-0 place-items-center border text-[10px] font-bold ${
                multiple ? "rounded-md" : "rounded-full"
              } ${isSelected ? "border-transparent bg-[color:var(--section-primary)] text-white" : "border-border"}`}
              aria-hidden
            >
              {isSelected ? "✓" : ""}
            </span>
            <span className="min-w-0 flex-1">{o.text}</span>
          </button>
        );
      })}
    </div>
  );
}
