/**
 * Shared DEUSI navigation icon set.
 * These are the icons used in the sidebar menu — section headers reuse the
 * exact same glyphs so every area of the app has one consistent symbol.
 */
import type { ReactNode, SVGProps } from "react";

export type NavIconProps = SVGProps<SVGSVGElement> & { size?: number };

function I({ children, size = 20, ...rest }: NavIconProps & { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...rest}
    >
      {children}
    </svg>
  );
}

export function HomeIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M3 11 12 3l9 8" />
      <path d="M5 10v10h14V10" />
    </I>
  );
}

export function BookIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2V5z" />
      <path d="M8 7h7M8 11h7" />
    </I>
  );
}

export function ReadIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M2 6c3-1 6-1 9 1v13c-3-2-6-2-9-1V6z" />
      <path d="M22 6c-3-1-6-1-9 1v13c3-2 6-2 9-1V6z" />
    </I>
  );
}

export function ChatIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M4 12a8 8 0 1 1 3.2 6.4L4 20l1.2-3.6" />
    </I>
  );
}

export function HeadphoneIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M4 14v-2a8 8 0 1 1 16 0v2" />
      <path d="M4 14h3v6H5a1 1 0 0 1-1-1v-5zM20 14h-3v6h2a1 1 0 0 0 1-1v-5z" />
    </I>
  );
}

export function PencilIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
    </I>
  );
}

export function ChartIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M4 20V10" />
      <path d="M10 20V4" />
      <path d="M16 20v-8" />
      <path d="M22 20H2" />
    </I>
  );
}

export function GearIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1" />
    </I>
  );
}

export function GrammarNavIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M4 4h16v4H4z" />
      <path d="M4 12h10v4H4z" />
      <path d="M4 20h6" />
      <path d="M18 12l3 3-3 3" />
    </I>
  );
}

export function BoxIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M3 7l9-4 9 4-9 4-9-4z" />
      <path d="M3 12l9 4 9-4" />
      <path d="M3 17l9 4 9-4" />
    </I>
  );
}

export function CalendarIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </I>
  );
}

export function SparkleIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3z" />
      <path d="M19 14l.9 2.1 2.1.9-2.1.9L19 20l-.9-2.1-2.1-.9 2.1-.9L19 14z" />
    </I>
  );
}

export function UserIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </I>
  );
}

export function CertificateIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <rect x="4" y="3" width="16" height="14" rx="2" />
      <path d="M8 21l4-3 4 3v-6" />
      <circle cx="12" cy="10" r="2" />
    </I>
  );
}

export function FilmIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" />
    </I>
  );
}

export function DocsIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2V5z" />
      <path d="M8 7h7M8 11h7" />
    </I>
  );
}

/** Wortfamilien — a shared root in the middle with related words branching off. */
export function WordFamilyIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 9V5.6M12 15v3.4M9 12H5.6M15 12h3.4" />
      <circle cx="12" cy="4" r="1.8" />
      <circle cx="12" cy="20" r="1.8" />
      <circle cx="4" cy="12" r="1.8" />
      <circle cx="20" cy="12" r="1.8" />
    </I>
  );
}

export function SearchIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.2-3.2" />
    </I>
  );
}

export function TrophyIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M8 4h8v5a4 4 0 0 1-8 0V4z" />
      <path d="M8 5H5v2a3 3 0 0 0 3 3M16 5h3v2a3 3 0 0 1-3 3" />
      <path d="M10 17h4M9 21h6" />
      <path d="M12 13v4" />
    </I>
  );
}

export function BookmarkIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M6 3h12v18l-6-4-6 4V3z" />
    </I>
  );
}

export function BellIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M18 8a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7" />
      <path d="M10.5 20a2 2 0 0 0 3 0" />
    </I>
  );
}

export function CrownIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M3 7l4 4 5-6 5 6 4-4v11H3V7z" />
    </I>
  );
}

export function LifebuoyIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="3.5" />
      <path d="m5.6 5.6 3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9" />
    </I>
  );
}

export function MusicNoteIcon({ size = 20, ...rest }: NavIconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...rest}
    >
      <path d="M10 18V6l9-2v12" />
      <circle cx="7.5" cy="18" r="2.4" fill="currentColor" stroke="none" />
      <circle cx="16.5" cy="16" r="2.4" fill="currentColor" stroke="none" />
    </svg>
  );
}
/** Exam sheet with a checked answer — used for the Prüfungen section. */
export function ExamIcon(p: NavIconProps) {
  return (
    <I {...p}>
      <path d="M6 3h9l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" />
      <path d="M14 3v5h5" />
      <path d="M8.5 13.2l1.7 1.7 3.6-3.6" />
      <path d="M8 17.5h8" />
    </I>
  );
}
