/**
 * DEUSI "Visual Alphabet" section icons.
 * Each icon is drawn on a 24×24 canvas with `currentColor` so it inherits
 * the surrounding text color (used both inside the colored PageHeader
 * badge and on any tinted surface elsewhere).
 */
import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function base({ size = 20, ...rest }: IconProps) {
  return {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2.2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    ...rest,
  };
}

/* 01 · Dashboard — broken ring + inner dot + orbiting dot */
export function DashboardIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M4 12a8 8 0 1 1 8 8" />
      <circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" />
      <circle cx="19.5" cy="14.5" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* 02 · Dictionary — filled book with corner tab */
/* Achievements — trophy cup */
export function AchievementsIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M7 4h10v5a5 5 0 0 1-10 0V4Z" fill="currentColor" stroke="none" />
      <path d="M7 5H4.5v1.5A3.5 3.5 0 0 0 8 10" />
      <path d="M17 5h2.5v1.5A3.5 3.5 0 0 1 16 10" />
      <path d="M12 14v3" />
      <path d="M8.5 20h7" />
    </svg>
  );
}

export function DictionaryIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path
        d="M6 4h11a1 1 0 0 1 1 1v13H7a2 2 0 0 0-2 2V6a2 2 0 0 1 2-2Z"
        fill="currentColor"
        stroke="none"
      />
      <rect x="16" y="15" width="3" height="3" rx="0.4" fill="currentColor" stroke="none" />
      <path d="M9 12h5" stroke="var(--section-primary, #fff)" strokeOpacity=".85" />
    </svg>
  );
}

/* 03 · AI Coach — half-ring + dot + satellite */
export function AiCoachIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M4 12a8 8 0 1 0 8-8" />
      <circle cx="10" cy="12" r="1.6" fill="currentColor" stroke="none" />
      <circle cx="18.5" cy="12" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* 04 · Grammar — two bars + dot (visual alphabet lines) */
export function GrammarIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M5 9h11" strokeWidth="3" />
      <path d="M5 15h7" strokeWidth="3" />
      <circle cx="17" cy="15" r="1.6" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* 05 · Flashcards — card with dot */
export function FlashcardsIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M5 8a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v6H5Z" />
      <path d="M4 17h16" strokeWidth="3" />
      <circle cx="9" cy="11" r="1.2" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* 06 · Leitner — three ranked bars + dot */
export function LeitnerIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M5 7h12" strokeWidth="3" />
      <path d="M5 12h9" strokeWidth="3" />
      <path d="M5 17h6" strokeWidth="3" />
      <circle cx="17" cy="17" r="1.6" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* 07 · Reading — quarter arc (open book curve) */
export function ReadingIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M6 20V8a12 12 0 0 1 12 12" strokeWidth="2.6" />
      <path d="M10 20v-4a4 4 0 0 1 4 4" />
    </svg>
  );
}

/* 08 · Podcasts — waveform bars */
export function PodcastsIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <circle cx="5.5" cy="12" r="1.6" fill="currentColor" stroke="none" />
      <path d="M10 7v10" strokeWidth="3" />
      <path d="M14 4v16" strokeWidth="3" />
      <path d="M18.5 8v8" strokeWidth="3" />
    </svg>
  );
}

/* 09 · Movies — dots + play triangle */
export function MoviesIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <circle cx="5" cy="7" r="1.2" fill="currentColor" stroke="none" />
      <circle cx="5" cy="12" r="1.6" fill="currentColor" stroke="none" />
      <circle cx="5" cy="17" r="1.2" fill="currentColor" stroke="none" />
      <path d="M10 6.5v11l9-5.5Z" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* 10 · Statistics — ascending bars + dot */
export function StatisticsIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <circle cx="5" cy="18" r="1.4" fill="currentColor" stroke="none" />
      <path d="M9 14v4" strokeWidth="3" />
      <path d="M13 10v8" strokeWidth="3" />
      <path d="M17 5v13" strokeWidth="3" />
    </svg>
  );
}

/* 11 · Exams — target crosshair */
export function ExamsIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <circle cx="12" cy="12" r="4.5" />
      <circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" />
      <path d="M12 3v3M12 18v3M3 12h3M18 12h3" strokeWidth="2.4" />
    </svg>
  );
}

/* 12 · Profile — headset ring + person */
export function ProfileIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M4 15a8 8 0 1 1 16 0" strokeWidth="2.4" />
      <circle cx="12" cy="15" r="2.2" fill="currentColor" stroke="none" />
      <path d="M4 15v3M20 15v3" strokeWidth="2.4" />
    </svg>
  );
}

/* 13 · Events — cluster of people + spark */
export function EventsIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <circle cx="9" cy="9" r="2.4" fill="currentColor" stroke="none" />
      <circle cx="16" cy="10" r="1.8" fill="currentColor" stroke="none" />
      <path d="M4 19c.6-3 2.6-4.5 5-4.5s4.4 1.5 5 4.5" strokeWidth="2.4" />
      <path d="M14 19c.4-2 1.6-3 3-3s2.6 1 3 3" strokeWidth="2.2" />
    </svg>
  );
}

/* 14 · Music — note + equalizer bars */
export function MusicIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M10 18V6l9-2v12" strokeWidth="2.2" />
      <circle cx="7.5" cy="18" r="2.6" fill="currentColor" stroke="none" />
      <circle cx="16.5" cy="16" r="2.6" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* 15 · Schreiben — pen nib over a baseline */
export function WritingIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M15.5 4.5l4 4L9 19H5v-4L15.5 4.5Z" />
      <path d="M13.5 6.5l4 4" />
      <path d="M4 22h16" strokeWidth="2.6" />
    </svg>
  );
}

/* 16 · Verben — bolt of action */
export function VerbsIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M13 2 4.5 13.5H11L9.5 22 19 10.5h-6.5L13 2Z" fill="currentColor" stroke="none" />
    </svg>
  );
}

/** Word-family net: a root node in the center with connected relatives. */
export function WordNetIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path d="M12 12 5 5M12 12l7-7M12 12l-7 7M12 12l7 7" />
      <circle cx="12" cy="12" r="3.2" fill="currentColor" stroke="none" />
      <circle cx="4.5" cy="4.5" r="2" />
      <circle cx="19.5" cy="4.5" r="2" />
      <circle cx="4.5" cy="19.5" r="2" />
      <circle cx="19.5" cy="19.5" r="2" />
    </svg>
  );
}

/* 17 · Community — two overlapping speech bubbles */
export function CommunityIcon(p: IconProps) {
  return (
    <svg {...base(p)}>
      <path
        d="M3 8.5A3.5 3.5 0 0 1 6.5 5h6A3.5 3.5 0 0 1 16 8.5v2A3.5 3.5 0 0 1 12.5 14H8l-4 3v-3.2A3.5 3.5 0 0 1 3 10.5v-2Z"
        fill="currentColor"
        stroke="none"
      />
      <path d="M18 9.2h.5A2.5 2.5 0 0 1 21 11.7v2.6a2.5 2.5 0 0 1-1.5 2.3V20l-3-2.3h-2.2" />
    </svg>
  );
}
