import { useTheme } from "@/lib/deusi/theme";

export function ThemeToggle() {
  const { theme, toggle } = useTheme();
  const dark = theme === "dark";
  return (
    <button
      onClick={toggle}
      aria-label={dark ? "Zum Hellmodus wechseln" : "Zum Dunkelmodus wechseln"}
      title={dark ? "Hellmodus" : "Dunkelmodus"}
      className="neu-pill relative grid h-11 w-11 place-items-center overflow-hidden text-muted-foreground hover:text-foreground hover:-translate-y-0.5"
    >
      <span
        className="absolute inset-0 grid place-items-center transition-all duration-500"
        style={{
          opacity: dark ? 0 : 1,
          transform: dark ? "rotate(-90deg) scale(.6)" : "rotate(0) scale(1)",
        }}
      >
        <svg
          viewBox="0 0 24 24"
          width="18"
          height="18"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
        </svg>
      </span>
      <span
        className="absolute inset-0 grid place-items-center transition-all duration-500"
        style={{
          opacity: dark ? 1 : 0,
          transform: dark ? "rotate(0) scale(1)" : "rotate(90deg) scale(.6)",
        }}
      >
        <svg
          viewBox="0 0 24 24"
          width="18"
          height="18"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
        </svg>
      </span>
    </button>
  );
}
