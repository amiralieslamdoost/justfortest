import type { ReactNode } from "react";
import { FaHint } from "@/components/deusi/FaHint";
import { Scale, Shield, FileText } from "lucide-react";
import { Link } from "@tanstack/react-router";

type Kind = "impressum" | "datenschutz" | "agb";

const META: Record<
  Kind,
  {
    label: string;
    title: string;
    highlight: string;
    fa: string;
    desc: string;
    descFa: string;
    Icon: typeof Scale;
    base: string;
    primary: string;
    accent: string;
  }
> = {
  impressum: {
    label: "Impressum",
    title: "Rechtliche Angaben",
    highlight: "Angaben",
    fa: "اطلاعات قانونی",
    desc: "Anbieterkennzeichnung nach § 5 TMG.",
    descFa: "شناسه‌ی ارائه‌دهنده طبق قانون رسانه‌های آلمان.",
    Icon: Scale,
    base: "#1a1d24",
    primary: "#3a3f4d",
    accent: "#8b93a6",
  },
  datenschutz: {
    label: "Datenschutz",
    title: "Deine Daten, dein Recht",
    highlight: "dein Recht",
    fa: "داده‌های تو، حق تو",
    desc: "Informationen zur Verarbeitung personenbezogener Daten nach DSGVO.",
    descFa: "توضیحات درباره‌ی پردازش داده‌ها بر اساس GDPR.",
    Icon: Shield,
    base: "#0a1547",
    primary: "#1b3fbf",
    accent: "#4d8cff",
  },
  agb: {
    label: "AGB",
    title: "Nutzungsbedingungen im Klartext",
    highlight: "Klartext",
    fa: "شرایط استفاده به زبان ساده",
    desc: "Die Bedingungen, unter denen du DEUSI verwendest.",
    descFa: "قوانین استفاده از پلتفرم دِیوزی.",
    Icon: FileText,
    base: "#04321a",
    primary: "#128a3c",
    accent: "#4be27a",
  },
};

const LINKS: { kind: Kind; to: "/impressum" | "/datenschutz" | "/agb" }[] = [
  { kind: "impressum", to: "/impressum" },
  { kind: "datenschutz", to: "/datenschutz" },
  { kind: "agb", to: "/agb" },
];

export function LegalShell({
  kind,
  updated,
  children,
}: {
  kind: Kind;
  updated: string;
  children: ReactNode;
}) {
  const m = META[kind];
  const Icon = m.Icon;
  const idx = m.title.indexOf(m.highlight);
  const before = idx >= 0 ? m.title.slice(0, idx) : m.title;
  const mid = idx >= 0 ? m.title.slice(idx, idx + m.highlight.length) : "";
  const after = idx >= 0 ? m.title.slice(idx + m.highlight.length) : "";

  return (
    <div className="space-y-6 pb-10 animate-fade">
      <header
        className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
        style={{
          backgroundImage: `linear-gradient(135deg, ${m.base} 0%, ${m.primary} 55%, ${m.accent} 130%)`,
        }}
      >
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          <div
            className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
            style={{ backgroundColor: m.accent, opacity: 0.4 }}
          />
        </div>
        <div className="relative flex min-w-0 items-center gap-3 sm:gap-4">
          <div
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16"
            style={{ color: m.primary }}
          >
            <Icon className="h-8 w-8" />
          </div>
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
              {m.label}
            </div>
            <h1 className="mt-2 text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
              {before}
              {mid && (
                <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
                  {mid}
                </span>
              )}
              {after}
            </h1>
            <FaHint className="!text-white/85">{m.fa}</FaHint>
            <p className="mt-2 max-w-2xl text-sm text-white/80">{m.desc}</p>
            <FaHint className="!text-white/70">{m.descFa}</FaHint>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
        <aside className="glass-strong h-fit rounded-[24px] p-2">
          {LINKS.map((l) => {
            const active = l.kind === kind;
            return (
              <Link
                key={l.kind}
                to={l.to}
                className={`block rounded-xl px-3 py-2.5 text-sm font-semibold transition ${
                  active
                    ? "bg-foreground text-background"
                    : "text-foreground/70 hover:bg-foreground/5 hover:text-foreground"
                }`}
              >
                {META[l.kind].label}
              </Link>
            );
          })}
          <div className="mx-3 mb-2 mt-3 border-t border-border pt-3 text-[11px] text-muted-foreground">
            Zuletzt aktualisiert:
            <br />
            <span className="font-semibold text-foreground/80">{updated}</span>
          </div>
        </aside>

        <article className="glass-strong rounded-[28px] p-6 sm:p-8">
          <div className="prose prose-sm max-w-none text-foreground/85 [&_h2]:mb-3 [&_h2]:mt-6 [&_h2]:text-lg [&_h2]:font-bold [&_h2]:text-foreground [&_h3]:mb-2 [&_h3]:mt-4 [&_h3]:text-sm [&_h3]:font-bold [&_h3]:text-foreground [&_p]:mb-3 [&_p]:leading-relaxed [&_ul]:mb-3 [&_ul]:ml-5 [&_ul]:list-disc [&_ul]:space-y-1 [&_a]:font-semibold [&_a]:text-foreground [&_a]:underline">
            {children}
          </div>
        </article>
      </div>
    </div>
  );
}
