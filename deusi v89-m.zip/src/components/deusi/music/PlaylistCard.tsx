import { Fa } from "@/components/deusi/Fa";
import type { Artist, Playlist } from "@/lib/deusi/mockMusic";

export function PlaylistCard({
  playlist,
  onOpen,
}: {
  playlist: Playlist;
  onOpen?: (id: string) => void;
}) {
  return (
    <button
      onClick={() => onOpen?.(playlist.id)}
      className="group relative overflow-hidden rounded-2xl border border-border/60 bg-card p-3 text-left transition hover:-translate-y-0.5 hover:shadow-lg"
    >
      <div
        className="relative aspect-square w-full overflow-hidden rounded-xl"
        style={{ background: playlist.cover }}
      >
        {playlist.coverUrl && (
          <img
            decoding="async"
            src={playlist.coverUrl}
            alt={playlist.title}
            loading="lazy"
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
        <span className="absolute right-2 top-2 rounded-full bg-black/50 px-2 py-0.5 text-[10px] font-bold text-white backdrop-blur">
          {playlist.level}
        </span>
        <span className="absolute bottom-2 left-2 text-[10px] font-bold text-white/90">
          {playlist.songIds.length} Songs
        </span>
        <span
          className="absolute bottom-2 right-2 grid h-9 w-9 translate-y-2 place-items-center rounded-full text-white opacity-0 shadow-lg transition group-hover:translate-y-0 group-hover:opacity-100"
          style={{ background: playlist.accent }}
        >
          <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        </span>
      </div>
      <div className="pt-2.5">
        <div className="truncate text-[13px] font-black">{playlist.title}</div>
        <Fa className="fa-hint-xs">{playlist.titleFa}</Fa>
      </div>
    </button>
  );
}

export function ArtistCard({
  artist,
  onSelect,
}: {
  artist: Artist;
  onSelect?: (id: string) => void;
}) {
  return (
    <button
      onClick={() => onSelect?.(artist.id)}
      className="group flex w-full items-center gap-3 rounded-2xl border border-border/60 bg-card p-2.5 text-left transition hover:bg-secondary/60"
    >
      <span
        className="relative h-11 w-11 shrink-0 overflow-hidden rounded-full ring-2 ring-transparent transition group-hover:ring-2"
        style={{ background: artist.cover, ["--tw-ring-color" as never]: artist.accent }}
      >
        {artist.coverUrl && (
          <img
            decoding="async"
            src={artist.coverUrl}
            alt={artist.name}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        )}
      </span>
      <div className="min-w-0 flex-1">
        <div className="truncate text-[13px] font-black">{artist.name}</div>
        <div className="truncate text-[11px] text-muted-foreground">
          {artist.listeners} Hörer:innen
        </div>
      </div>
      <svg
        viewBox="0 0 24 24"
        width="14"
        height="14"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-muted-foreground opacity-0 transition group-hover:opacity-100"
      >
        <path d="m9 18 6-6-6-6" />
      </svg>
    </button>
  );
}
