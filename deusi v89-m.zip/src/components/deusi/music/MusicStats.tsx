import { Fa } from "@/components/deusi/Fa";
import { musicStats } from "@/lib/deusi/mockMusic";

const DAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];

export function MusicStats({ savedCount, accent }: { savedCount: number; accent: string }) {
  const max = Math.max(...musicStats.weekly, 1);

  return (
    <section className="neu-card p-4">
      <div className="mb-3">
        <div className="text-sm font-black">Deine Hörwoche</div>
        <Fa className="fa-hint-xs">هفته‌ی شنیداری تو</Fa>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Kpi
          label="Minuten"
          value={`${musicStats.minutesThisWeek}`}
          fa="دقیقه این هفته"
          accent={accent}
        />
        <Kpi
          label="Songs"
          value={`${musicStats.songsFinished}`}
          fa="آهنگ کامل‌شده"
          accent={accent}
        />
        <Kpi
          label="Wörter"
          value={`${musicStats.wordsSaved + savedCount}`}
          fa="واژه ذخیره‌شده"
          accent={accent}
        />
        <Kpi label="Streak" value={`${musicStats.streakDays}`} fa="روز پیاپی" accent={accent} />
      </div>

      <div className="mt-4 flex h-20 items-end gap-1.5">
        {musicStats.weekly.map((v, i) => (
          <div key={i} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
            <div
              className="w-full rounded-t-lg"
              style={{
                height: `${(v / max) * 100}%`,
                background: accent,
                opacity: 0.35 + (v / max) * 0.65,
              }}
            />
            <span className="text-[9px] font-bold text-muted-foreground">{DAYS[i]}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Kpi({
  label,
  value,
  fa,
  accent,
}: {
  label: string;
  value: string;
  fa: string;
  accent: string;
}) {
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-2.5">
      <div className="text-lg font-black tabular-nums" style={{ color: accent }}>
        {value}
      </div>
      <div className="text-[11px] font-bold text-muted-foreground">{label}</div>
      <Fa className="fa-hint-xs">{fa}</Fa>
    </div>
  );
}
