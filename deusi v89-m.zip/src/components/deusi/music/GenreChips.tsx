import { Fa } from "@/components/deusi/Fa";
import type { MusicGenre, MusicGenreKey } from "@/lib/deusi/mockMusic";

/** Distinct accent per genre so chips read as bold, colorful categories. */
export const genreAccent: Record<MusicGenreKey, string> = {
  "fuer-dich": "#8b5cf6",
  alle: "#64748b",
  pop: "#ec4899",
  rap: "#f97316",
  rock: "#ef4444",
  schlager: "#14b8a6",
  indie: "#a855f7",
  klassiker: "#f59e0b",
};

const genreEmoji: Record<MusicGenreKey, string> = {
  "fuer-dich": "✨",
  alle: "♪",
  pop: "🎤",
  rap: "🎧",
  rock: "🎸",
  schlager: "💃",
  indie: "🌙",
  klassiker: "🎻",
};

export function GenreChips({
  genres,
  active,
  onChange,
}: {
  genres: MusicGenre[];
  active: MusicGenreKey;
  onChange: (k: MusicGenreKey) => void;
}) {
  return (
    <div className="grid grid-cols-4 gap-2 sm:flex sm:flex-wrap sm:gap-2.5">
      {genres.map((g) => {
        const on = g.key === active;
        const color = genreAccent[g.key];
        return (
          <button
            key={g.key}
            type="button"
            onClick={() => onChange(g.key)}
            aria-pressed={on}
            className={`group relative flex flex-col items-center justify-center gap-0.5 overflow-hidden rounded-2xl px-2 py-2.5 text-center transition-all duration-200 sm:flex-row sm:gap-2 sm:px-4 sm:py-2.5 ${
              on ? "text-white" : "bg-card text-foreground hover:-translate-y-0.5"
            }`}
            style={
              on
                ? {
                    background: `linear-gradient(135deg, ${color}, color-mix(in oklab, ${color} 55%, #000000))`,
                    border: `2px solid ${color}`,
                    boxShadow: `0 14px 28px -10px ${color}`,
                  }
                : {
                    border: `2px solid color-mix(in oklab, ${color} 45%, transparent)`,
                  }
            }
            onMouseEnter={(e) => {
              if (on) return;
              const el = e.currentTarget as HTMLElement;
              el.style.boxShadow = `0 12px 24px -10px ${color}`;
              el.style.borderColor = color;
            }}
            onMouseLeave={(e) => {
              if (on) return;
              const el = e.currentTarget as HTMLElement;
              el.style.boxShadow = "";
              el.style.borderColor = `color-mix(in oklab, ${color} 45%, transparent)`;
            }}
          >
            <span className={`text-base leading-none ${on ? "" : "opacity-90"}`} aria-hidden>
              {genreEmoji[g.key]}
            </span>
            <span className="flex flex-col items-center sm:items-start">
              <span className="text-[12px] font-black leading-tight sm:text-sm">{g.label}</span>
              <Fa
                inline
                className={`fa-hint-xs !text-[10px] leading-tight ${on ? "!text-white/85" : "!text-muted-foreground"}`}
              >
                {g.labelFa}
              </Fa>
            </span>
          </button>
        );
      })}
    </div>
  );
}

export function LevelFilter({
  levels,
  active,
  onChange,
}: {
  levels: string[];
  active: string | null;
  onChange: (l: string | null) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
        Niveau
      </span>
      <button
        type="button"
        onClick={() => onChange(null)}
        aria-pressed={active === null}
        className={`rounded-xl px-2.5 py-1 text-xs font-bold transition ${
          active === null
            ? "bg-secondary text-foreground"
            : "text-muted-foreground hover:bg-secondary"
        }`}
      >
        Alle
      </button>
      {levels.map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => onChange(active === l ? null : l)}
          aria-pressed={active === l}
          className={`rounded-xl px-2.5 py-1 text-xs font-bold transition ${
            active === l
              ? "bg-secondary text-foreground"
              : "text-muted-foreground hover:bg-secondary"
          }`}
        >
          {l}
        </button>
      ))}
    </div>
  );
}
