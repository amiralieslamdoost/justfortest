import { Fa } from "@/components/deusi/Fa";
import type { Song, SongVocab } from "@/lib/deusi/mockMusic";

export function SongVocabList({
  song,
  savedIds,
  onSave,
  onSaveAll,
}: {
  song: Song;
  savedIds: string[];
  onSave: (v: SongVocab) => void;
  onSaveAll: () => void;
}) {
  if (song.vocab.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-5 text-center">
        <p className="text-sm font-semibold text-muted-foreground">
          Noch keine Vokabelliste für diesen Song.
        </p>
        <Fa className="fa-hint-xs mt-1">هنوز فهرست واژگان برای این آهنگ آماده نشده.</Fa>
      </div>
    );
  }

  const allSaved = song.vocab.every((v) => savedIds.includes(v.id));

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-sm font-black">{song.vocab.length} Schlüsselwörter</div>
          <Fa className="fa-hint-xs">واژه‌های کلیدی این آهنگ</Fa>
        </div>
        <button
          onClick={onSaveAll}
          disabled={allSaved}
          className="rounded-xl px-3 py-1.5 text-xs font-bold text-white transition disabled:opacity-60"
          style={{ background: song.accent }}
        >
          {allSaved ? "Alle gespeichert ✓" : "Alle in die Leitner-Box"}
        </button>
      </div>

      <ul className="grid gap-2 sm:grid-cols-2">
        {song.vocab.map((v) => {
          const saved = savedIds.includes(v.id);
          return (
            <li key={v.id} className="rounded-2xl border border-border/60 bg-card p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    {v.article && (
                      <span
                        className="rounded-md px-1.5 py-0.5 text-[10px] font-bold text-white"
                        style={{ background: song.accent }}
                      >
                        {v.article}
                      </span>
                    )}
                    <span className="truncate text-sm font-black">{v.term}</span>
                  </div>
                  <Fa className="fa-hint-xs mt-0.5">{v.translation}</Fa>
                </div>
                <button
                  onClick={() => onSave(v)}
                  disabled={saved}
                  aria-label="In die Leitner-Box"
                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-xl border border-border transition ${
                    saved ? "text-muted-foreground" : "hover:bg-secondary"
                  }`}
                >
                  {saved ? (
                    <svg
                      viewBox="0 0 24 24"
                      width="14"
                      height="14"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m20 6-11 11-5-5" />
                    </svg>
                  ) : (
                    <svg
                      viewBox="0 0 24 24"
                      width="14"
                      height="14"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                    >
                      <path d="M12 5v14M5 12h14" />
                    </svg>
                  )}
                </button>
              </div>
              <p className="mt-1.5 line-clamp-2 text-[11px] italic text-muted-foreground">
                „{v.example}“
              </p>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
