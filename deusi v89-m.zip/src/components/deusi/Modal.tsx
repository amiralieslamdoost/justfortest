import { useEffect, type ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * Dialog der App.
 *
 * Bewusst leicht statt „schwer": eine ruhige, deckende Fläche (keine dicke
 * Glasscheibe), gut lesbare Typografie, ein fixierter Kopf und ein optionaler
 * fixierter Fuß für Aktionen — nur der Inhalt dazwischen scrollt.
 */
export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  wide = false,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4">
      <div
        className="animate-fade absolute inset-0 bg-foreground/25 backdrop-blur-[2px]"
        onClick={onClose}
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          "animate-fade relative z-10 flex max-h-[92dvh] w-full flex-col overflow-hidden bg-background text-foreground",
          "rounded-t-3xl border border-border/70 shadow-[0_40px_80px_-40px_rgb(0_0_0/0.45)] sm:rounded-3xl",
          wide ? "sm:max-w-3xl" : "sm:max-w-xl",
        )}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 top-0 h-24 opacity-[0.07]"
          style={{
            background:
              "radial-gradient(80% 100% at 0% 0%, var(--section-primary, currentColor), transparent 70%)",
          }}
        />

        <header className="relative flex items-start justify-between gap-4 border-b border-border/70 px-5 py-4 sm:px-6 sm:py-5">
          <div className="min-w-0">
            <h3 className="truncate text-lg font-black tracking-tight sm:text-xl">{title}</h3>
            {subtitle ? (
              <div className="mt-0.5 text-sm leading-relaxed text-muted-foreground">{subtitle}</div>
            ) : null}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-border/70 text-lg font-bold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            aria-label="Schließen"
          >
            ×
          </button>
        </header>

        <div className="relative flex-1 overflow-y-auto overscroll-contain px-5 py-5 sm:px-6">
          {children}
        </div>

        {footer ? (
          <footer className="relative border-t border-border/70 bg-background/95 px-5 py-4 sm:px-6">
            {footer}
          </footer>
        ) : null}
      </div>
    </div>
  );
}
