import { motion, AnimatePresence } from "framer-motion";
import { Volume2, Bookmark, X } from "lucide-react";
import { createPortal } from "react-dom";
import { useEffect, useState } from "react";
import type { VocabItem } from "@/lib/deusi/mockReading";

interface Props {
  vocab: VocabItem | null;
  onClose: () => void;
  onSave?: (v: VocabItem) => void;
}

const ARTICLE_COLOR: Record<string, string> = {
  der: "#2563eb",
  die: "#DD2222",
  das: "#F7C948",
};

export function WordPopup({ vocab, onClose, onSave }: Props) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);
  const content = (
    <AnimatePresence>
      {vocab && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/20 backdrop-blur-[2px]"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 300, damping: 26 }}
            className="fixed left-1/2 top-1/2 z-50 w-[min(92vw,380px)] -translate-x-1/2 -translate-y-1/2 glass-strong rounded-3xl p-5 shadow-2xl"
          >
            <div className="flex items-start gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline gap-2">
                  {vocab.article && (
                    <span
                      className="rounded-full px-2 py-0.5 text-xs font-bold text-white"
                      style={{ background: ARTICLE_COLOR[vocab.article] }}
                    >
                      {vocab.article}
                    </span>
                  )}
                  <h3 className="truncate text-2xl font-black">{vocab.word}</h3>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <span className="rounded-full bg-secondary px-2 py-0.5 font-semibold">
                    {vocab.pos}
                  </span>
                  <span className="rounded-full bg-secondary px-2 py-0.5 font-semibold">
                    {vocab.level}
                  </span>
                  <span className="font-mono">{vocab.pronunciation}</span>
                </div>
              </div>
              <button
                onClick={onClose}
                className="grid h-8 w-8 place-items-center rounded-full transition hover:bg-secondary"
                title="Schließen"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 rounded-2xl bg-secondary/60 p-3">
              <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                Übersetzung
              </div>
              <div className="mt-0.5 text-base font-semibold">{vocab.translation}</div>
            </div>

            <div className="mt-3 rounded-2xl bg-secondary/60 p-3">
              <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                Beispiel
              </div>
              <div className="mt-0.5 text-sm italic">„{vocab.example}“</div>
            </div>

            <div className="mt-4 flex items-center gap-2">
              <button
                onClick={() =>
                  window.speechSynthesis?.speak(new SpeechSynthesisUtterance(vocab.word))
                }
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl bg-secondary px-4 py-2.5 text-sm font-semibold transition hover:bg-muted"
              >
                <Volume2 className="h-4 w-4" /> Aussprache
              </button>
              <button
                onClick={() => onSave?.(vocab)}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold text-white shadow-lg transition hover:-translate-y-0.5"
                style={{ background: "var(--flag-red)" }}
              >
                <Bookmark className="h-4 w-4" /> Speichern
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
  if (!mounted || typeof document === "undefined") return null;
  return createPortal(content, document.body);
}
