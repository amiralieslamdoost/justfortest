import { useMemo } from "react";
import type { Paragraph, VocabItem } from "@/lib/deusi/mockReading";

interface Props {
  content: Paragraph[];
  vocab: VocabItem[];
  fontSize: number;
  onWordClick: (v: VocabItem) => void;
}

/**
 * Parses [[word]] or [[key|label]] markers in the text and turns them into
 * interactive spans that open the word popup on click.
 */
export function InteractiveText({ content, vocab, fontSize, onWordClick }: Props) {
  const lookup = useMemo(() => {
    const map = new Map<string, VocabItem>();
    for (const v of vocab) map.set(v.word.toLowerCase(), v);
    return map;
  }, [vocab]);

  return (
    <article
      className="prose prose-neutral max-w-none space-y-5 leading-relaxed dark:prose-invert"
      style={{ fontSize: `${fontSize}px`, lineHeight: 1.75 }}
    >
      {content.map((p, i) => (
        <p key={i}>{renderParagraph(p.text, lookup, onWordClick)}</p>
      ))}
    </article>
  );
}

function renderParagraph(
  text: string,
  lookup: Map<string, VocabItem>,
  onWordClick: (v: VocabItem) => void,
) {
  const parts: (string | { key: string; label: string })[] = [];
  const re = /\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    parts.push({ key: m[1], label: m[2] ?? m[1] });
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));

  return parts.map((part, i) => {
    if (typeof part === "string") return <span key={i}>{part}</span>;
    const v = lookup.get(part.key.toLowerCase());
    if (!v) return <span key={i}>{part.label}</span>;
    const bg =
      v.pos === "Substantiv"
        ? "bg-red-100/70 text-red-700 dark:bg-red-500/15 dark:text-red-300"
        : v.pos === "Verb"
          ? "bg-blue-100/70 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300"
          : v.pos === "Adjektiv"
            ? "bg-green-100/70 text-green-700 dark:bg-green-500/15 dark:text-green-300"
            : "bg-yellow-100/70 text-yellow-800 dark:bg-yellow-500/15 dark:text-yellow-300";
    return (
      <button
        key={i}
        onClick={() => onWordClick(v)}
        className={`inline-flex items-baseline rounded-md px-1 py-0 align-baseline font-semibold transition hover:brightness-110 ${bg}`}
      >
        {part.label}
      </button>
    );
  });
}
