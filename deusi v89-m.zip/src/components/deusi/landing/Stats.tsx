import { useEffect, useRef, useState } from "react";
import { EASE, FA } from "./data";
import { useInView, animate } from "framer-motion";

export function Stats() {
  const items = [
    { n: 12000, s: "+", label: "Vokabeln kuratiert", labelFa: "واژه انتخاب‌شده" },
    { n: 96, s: "%", label: "Retention nach 30 Tagen", labelFa: "ماندگاری بعد ۳۰ روز" },
    { n: 6, s: "", label: "Sprachniveaus (A1–C2)", labelFa: "سطح زبانی" },
    { n: 0, s: "", label: "Kosten, keine Werbung", labelFa: "هزینه، بدون تبلیغ", suffix: "€" },
  ];
  return (
    <section className="mx-auto max-w-[1400px] px-5 lg:px-12 py-16 sm:px-8">
      <div className="relative overflow-hidden rounded-[2rem] border border-border bg-card p-8 sm:p-12">
        <div
          aria-hidden
          className="absolute -right-24 -top-24 h-64 w-64 rounded-full opacity-40 blur-3xl"
          style={{ background: "var(--flag-red)" }}
        />
        <div
          aria-hidden
          className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full opacity-40 blur-3xl"
          style={{ background: "var(--flag-gold)" }}
        />
        <div className="relative grid grid-cols-2 gap-8 lg:grid-cols-4">
          {items.map((it, i) => (
            <StatItem key={i} {...it} />
          ))}
        </div>
      </div>
    </section>
  );
}

export function StatItem({
  n,
  s,
  label,
  labelFa,
  suffix,
}: {
  n: number;
  s: string;
  label: string;
  labelFa: string;
  suffix?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, n, {
      duration: 1.6,
      ease: EASE,
      onUpdate: (val: number) => setV(Math.round(val)),
    });
    return () => controls.stop();
  }, [inView, n]);
  return (
    <div>
      <div className="flex items-baseline gap-1">
        {suffix && (
          <span className="font-display text-2xl font-black text-muted-foreground">{suffix}</span>
        )}
        <span
          ref={ref}
          className="font-display text-4xl font-black tracking-tight sm:text-5xl"
          style={{ color: "var(--flag-red)" }}
        >
          {v}
        </span>
        <span className="font-display text-2xl font-black">{s}</span>
      </div>
      <div className="mt-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <FA className="mt-0.5 block text-xs text-muted-foreground/85">{labelFa}</FA>
    </div>
  );
}
