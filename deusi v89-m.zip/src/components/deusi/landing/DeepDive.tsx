import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion, animate } from "framer-motion";
import {
  ArrowRight,
  BookOpen,
  Layers,
  Headphones,
  GraduationCap,
  BarChart3,
  Check,
  Users,
  type LucideIcon,
} from "lucide-react";
import { EASE, FA } from "./data";
import { SectionHeader } from "./SectionHeader";

export type DeepDiveTab = {
  id: string;
  label: string;
  labelFa: string;
  icon: LucideIcon;
  color: string;
  title: string;
  titleFa: string;
  desc: string;
  descFa: string;
  points: Array<[string, string]>;
  chips: string[];
  to: string;
  cta: string;
};

export const DEEP_DIVE: DeepDiveTab[] = [
  {
    id: "wortschatz",
    label: "Wortschatz-System",
    labelFa: "سیستم واژگان",
    icon: Layers,
    color: "#DD2222",
    title: "Ein Wort, der ganze Weg — vom Entdecken bis zum Beherrschen",
    titleFa: "یک واژه، تمام مسیر — از کشف تا تسلط",
    desc: "Jedes Wort startet im Wörterbuch, wandert in deine Listen, wird zur Karte und landet im Leitner-Kasten. Nichts geht verloren, nichts wird doppelt gelernt.",
    descFa:
      "هر واژه از دیکشنری شروع می‌شود، به فهرست‌های تو می‌رود، کارت می‌شود و در جعبه‌ی لایتنر جا می‌گیرد. هیچ چیز گم نمی‌شود.",
    points: [
      [
        "Wörterbuch mit Artikel, Plural, Konjugation, Beispielsätzen und Aussprache",
        "دیکشنری با حرف تعریف، جمع، صرف، جمله‌ی نمونه و تلفظ",
      ],
      [
        "Eigene Wortlisten & Wortschatz-Bücher nach Thema und Niveau",
        "فهرست‌های شخصی و کتاب‌های واژگان بر اساس موضوع و سطح",
      ],
      [
        "Dynamische Karten: Nomen, Verben und Adjektive werden unterschiedlich abgefragt",
        "کارت‌های پویا: اسم، فعل و صفت هرکدام جور دیگری پرسیده می‌شوند",
      ],
      [
        "FSRS 5 + Leitner planen jede Wiederholung auf den optimalen Tag",
        "FSRS ۵ و لایتنر هر مرور را برای بهترین روز زمان‌بندی می‌کنند",
      ],
    ],
    chips: ["Wörterbuch", "Meine Wörter", "Flashcards", "Leitner", "Bücher"],
    to: "/dictionary",
    cta: "Wörterbuch ansehen",
  },
  {
    id: "grammatik",
    label: "Grammatik & Schreiben",
    labelFa: "گرامر و نوشتن",
    icon: BookOpen,
    color: "#2563eb",
    title: "Regeln verstehen, Sätze bauen, Texte schreiben",
    titleFa: "قاعده را بفهم، جمله بساز، متن بنویس",
    desc: "Geführte Grammatik-Pfade mit interaktiven Sätzen und Mini-Übungen — und ein Schreibtrainer, der deine Texte Satz für Satz korrigiert.",
    descFa:
      "مسیرهای گرامری گام‌به‌گام با جمله‌های تعاملی و تمرین کوتاه — به‌همراه تمرین نوشتن که متن‌ات را جمله‌به‌جمله اصلاح می‌کند.",
    points: [
      [
        "Roadmap von A1 bis C2: jedes Thema mit Lektion, Beispielen und Übung",
        "نقشه‌راه از A1 تا C2: هر موضوع با درس، مثال و تمرین",
      ],
      [
        "Interaktive Sätze — tippe auf ein Satzglied und sieh, warum es dort steht",
        "جمله‌های تعاملی — روی هر جزء بزن و ببین چرا آنجاست",
      ],
      [
        "Wortfamilien: Wortstamm, Präfixe, Suffixe und Wortbildung als Baum",
        "خانواده‌ی واژه: ریشه، پیشوند، پسوند و واژه‌سازی به‌شکل درختی",
      ],
      [
        "Schreibtrainer mit KI-Feedback zu Grammatik, Stil, Register und Struktur",
        "تمرین نوشتن با بازخورد هوش مصنوعی درباره‌ی گرامر، سبک و ساختار",
      ],
    ],
    chips: ["Grammatik", "Wortfamilien", "Schreiben", "KI-Coach"],
    to: "/grammatik",
    cta: "Grammatik entdecken",
  },
  {
    id: "immersion",
    label: "Hören & Immersion",
    labelFa: "شنیدن و غوطه‌وری",
    icon: Headphones,
    color: "#16A34A",
    title: "Echtes Deutsch: Podcasts, Musik, Filme und Texte",
    titleFa: "آلمانیِ واقعی: پادکست، موزیک، فیلم و متن",
    desc: "Hören, mitlesen, verstehen. Jedes Transkript ist anklickbar — unbekannte Wörter wandern mit einem Tap in deine Lernkarten.",
    descFa:
      "گوش کن، هم‌زمان بخوان، بفهم. هر متن قابل لمس است — واژه‌های ناآشنا با یک لمس به کارت‌هایت اضافه می‌شوند.",
    points: [
      [
        "Podcasts mit interaktivem Transkript, Tempo-Regler und Quiz danach",
        "پادکست با متن تعاملی، تنظیم سرعت و آزمون پایانی",
      ],
      [
        "Musik im Karaoke-Modus: Zeile für Zeile mitlesen und Vokabeln sammeln",
        "موزیک در حالت کارائوکه: خط‌به‌خط بخوان و واژه جمع کن",
      ],
      [
        "Kino & Serien: Szenen, Dialoge und Redewendungen aus echten Filmen",
        "سینما و سریال: صحنه‌ها، دیالوگ‌ها و اصطلاح‌های فیلم‌های واقعی",
      ],
      [
        "Lesen mit Wort-Popup, Lesefortschritt und Flashcards aus dem Text",
        "خواندن با پاپ‌آپ واژه، پیشرفت مطالعه و ساخت کارت از دل متن",
      ],
    ],
    chips: ["Podcasts", "Musik", "Kino", "Lesen", "Lesezeichen"],
    to: "/podcasts",
    cta: "Podcasts hören",
  },
  {
    id: "pruefung",
    label: "Prüfungen & KI-Coach",
    labelFa: "آزمون و کوچ هوشمند",
    icon: GraduationCap,
    color: "#8B5CF6",
    title: "Bereit für Goethe, telc und ÖSD — mit Coach an deiner Seite",
    titleFa: "آماده‌ی گوته، telc و ÖSD — با یک مربی کنارت",
    desc: "Prüfungsformate üben, Zeit im Blick behalten und sofort auswerten. Der KI-Coach erklärt jede Korrektur auf deinem Niveau.",
    descFa:
      "قالب‌های آزمون را تمرین کن، زمان را زیر نظر داشته باش و بلافاصله نتیجه بگیر. کوچ هوشمند هر اصلاح را در سطح خودت توضیح می‌دهد.",
    points: [
      [
        "Aufgabentypen für Lesen, Hören, Schreiben und Sprechen pro Niveau",
        "انواع سؤال خواندن، شنیدن، نوشتن و صحبت‌کردن برای هر سطح",
      ],
      [
        "Vergleichstabelle der Prüfungen plus Vorbereitungs-Zeitplan",
        "جدول مقایسه‌ی آزمون‌ها به‌همراه برنامه‌ی زمانی آمادگی",
      ],
      [
        "Einstufungstest bestimmt dein Startniveau in wenigen Minuten",
        "آزمون تعیین سطح، نقطه‌ی شروعت را در چند دقیقه مشخص می‌کند",
      ],
      [
        "KI-Coach für Erklärungen, Konversation, Korrekturen und Beispielsätze",
        "کوچ هوشمند برای توضیح، مکالمه، اصلاح و جمله‌ی نمونه",
      ],
    ],
    chips: ["Prüfungen", "Einstufungstest", "KI-Coach"],
    to: "/pruefungen",
    cta: "Prüfungen ansehen",
  },
  {
    id: "community",
    label: "Community & Events",
    labelFa: "جامعه و رویدادها",
    icon: Users,
    color: "#0EA5E9",
    title: "Sprache lebt von Menschen — nicht nur von Karten",
    titleFa: "زبان با آدم‌ها زنده است — نه فقط با کارت",
    desc: "Chats, Lerngruppen, Tandem-Partner und echte Sprachtreffs. Übe das, was du gelernt hast, sofort im Gespräch.",
    descFa:
      "گفت‌وگو، گروه‌های یادگیری، شریک زبانی و دیدارهای واقعی. آنچه یاد گرفته‌ای را همان‌جا در گفت‌وگو تمرین کن.",
    points: [
      [
        "Öffentliche Talare, eigene Gruppen und private Chats",
        "تالارهای عمومی، گروه‌های شخصی و گفت‌وگوی خصوصی",
      ],
      [
        "Tandem-Börse: finde Sprechpartner nach Niveau und Interessen",
        "تابلوی تندم: شریک گفت‌وگو بر اساس سطح و علاقه پیدا کن",
      ],
      [
        "Events online und vor Ort — mit Tischplan und Platzreservierung",
        "رویدادهای آنلاین و حضوری — با نقشه‌ی میز و رزرو جا",
      ],
      [
        "Profile mit Niveau, Zielen und Lernstatistik der Mitglieder",
        "پروفایل اعضا با سطح، اهداف و آمار یادگیری",
      ],
    ],
    chips: ["Community", "Tandem", "Events", "Profil"],
    to: "/community",
    cta: "Community entdecken",
  },
  {
    id: "fortschritt",
    label: "Fortschritt & Motivation",
    labelFa: "پیشرفت و انگیزه",
    icon: BarChart3,
    color: "#F59E0B",
    title: "Sieh schwarz auf weiß, dass du besser wirst",
    titleFa: "سیاه روی سفید ببین که بهتر می‌شوی",
    desc: "Heatmaps, Serien, Retention und Skill-Verteilung — plus Missionen und Medaillen, die aus Lernen ein tägliches Ritual machen.",
    descFa:
      "هیت‌مپ، سری‌ها، ماندگاری و توزیع مهارت — به‌همراه ماموریت و مدال که یادگیری را به آیین روزانه تبدیل می‌کند.",
    points: [
      [
        "Tagesziel, Lernzeit-Charts und Wochentag-Profil deiner Gewohnheiten",
        "هدف روزانه، نمودار زمان مطالعه و پروفایل روزهای هفته",
      ],
      [
        "Vokabel-Heatmap und Retention pro Wortart und Niveau",
        "هیت‌مپ واژگان و ماندگاری بر اساس نوع کلمه و سطح",
      ],
      [
        "Missionen, Seasons, Medaillen und Leaderboard mit Freunden",
        "ماموریت، فصل‌ها، مدال و جدول رتبه‌بندی با دوستان",
      ],
      [
        "Serien-Schutz und Erinnerungen, damit die Streak nicht reißt",
        "محافظ سری و یادآوری، تا زنجیره‌ات پاره نشود",
      ],
    ],
    chips: ["Statistiken", "Erfolge", "Dashboard", "Benachrichtigungen"],
    to: "/statistiken",
    cta: "Statistiken ansehen",
  },
];

export function DeepDive() {
  const [active, setActive] = useState(0);
  const tab = DEEP_DIVE[active]!;
  const Icon = tab.icon;

  return (
    <section
      id="deep-dive"
      className="relative mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-28 lg:px-12"
    >
      <SectionHeader
        kicker="Im Detail"
        kickerFa="با جزئیات"
        title={
          <>
            Was dich in DEUSI erwartet.
            <br />
            <span style={{ color: "var(--flag-red)" }}>Bereich für Bereich.</span>
          </>
        }
        titleFa={
          <>
            چه چیزی در دئوسی در انتظارت است —{" "}
            <span style={{ color: "var(--flag-red)" }}>بخش به بخش.</span>
          </>
        }
        subtitle="Sechs zusammenhängende Systeme statt zwölf einzelner Apps — hier siehst du genau, was jedes davon für dich tut."
        subtitleFa="شش سیستم به‌هم‌پیوسته به‌جای دوازده اپ جدا — اینجا دقیقاً می‌بینی هرکدام چه کاری برایت می‌کنند."
      />

      <div className="mt-12 grid gap-5 lg:grid-cols-[300px_minmax(0,1fr)] lg:gap-8">
        {/* Tabs — horizontal scroller on mobile, vertical list on desktop */}
        <div
          role="tablist"
          aria-label="Funktionsbereiche"
          className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:flex lg:flex-col"
        >
          {DEEP_DIVE.map((t, i) => {
            const TIcon = t.icon;
            const on = i === active;
            return (
              <button
                key={t.id}
                role="tab"
                aria-selected={on}
                onClick={() => setActive(i)}
                className={`flex w-full min-w-0 items-center gap-2.5 rounded-2xl border px-3 py-3 text-left transition sm:gap-3 sm:px-4 ${
                  on
                    ? "border-transparent bg-card shadow-lg"
                    : "border-border bg-card/50 hover:bg-card"
                }`}
                style={on ? { boxShadow: `0 12px 30px -18px ${t.color}` } : undefined}
              >
                <span
                  aria-hidden
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white"
                  style={{
                    background: on
                      ? `linear-gradient(135deg, ${t.color}, ${t.color}bb)`
                      : "var(--muted, #f1f1f1)",
                    color: on ? "#fff" : t.color,
                  }}
                >
                  <TIcon className="h-4.5 w-4.5" size={18} />
                </span>
                <span className="min-w-0">
                  <span className="block text-[12.5px] leading-tight font-bold break-words hyphens-auto sm:text-sm">
                    {t.label}
                  </span>
                  <FA className="mt-0.5 block text-[10px] leading-tight text-muted-foreground sm:text-[11px]">
                    {t.labelFa}
                  </FA>
                </span>
              </button>
            );
          })}
        </div>

        {/* Panel */}
        <motion.div
          key={tab.id}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: EASE }}
          role="tabpanel"
          className="relative overflow-hidden rounded-3xl border border-border bg-card p-5 sm:p-8"
        >
          <div
            aria-hidden
            className="pointer-events-none absolute -right-16 -top-16 h-52 w-52 rounded-full opacity-25 blur-3xl"
            style={{ background: tab.color }}
          />
          <div className="relative">
            <div className="flex items-center gap-3">
              <span
                aria-hidden
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-lg"
                style={{ background: `linear-gradient(135deg, ${tab.color}, ${tab.color}bb)` }}
              >
                <Icon className="h-5 w-5" />
              </span>
              <span
                className="rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-widest"
                style={{ background: `${tab.color}18`, color: tab.color }}
              >
                {tab.label}
              </span>
            </div>

            <h3 className="mt-5 text-balance text-xl font-black leading-tight sm:text-2xl md:text-3xl">
              {tab.title}
            </h3>
            <FA className="mt-1 block text-sm text-muted-foreground">{tab.titleFa}</FA>
            <p className="mt-3 max-w-2xl text-sm text-muted-foreground sm:text-base">{tab.desc}</p>
            <FA className="mt-1 block text-xs text-muted-foreground/80 sm:text-sm">{tab.descFa}</FA>

            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {tab.points.map(([de, fa], i) => (
                <motion.li
                  key={de}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 * i, duration: 0.4, ease: EASE }}
                  className="flex gap-3 rounded-2xl bg-secondary/50 p-3.5"
                >
                  <span
                    aria-hidden
                    className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-white"
                    style={{ background: tab.color }}
                  >
                    <Check className="h-3 w-3" strokeWidth={3} />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold leading-snug">{de}</span>
                    <FA className="mt-0.5 block text-[11px] text-muted-foreground">{fa}</FA>
                  </span>
                </motion.li>
              ))}
            </ul>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              {tab.chips.map((c) => (
                <span
                  key={c}
                  className="rounded-full border border-border px-3 py-1 text-[11px] font-semibold text-muted-foreground"
                >
                  {c}
                </span>
              ))}
              <Link
                to={tab.to}
                className="ml-auto inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold text-white transition hover:opacity-90"
                style={{ background: tab.color }}
              >
                {tab.cta} <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
