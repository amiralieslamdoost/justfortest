import { useRef, useState } from "react";
import {
  motion,
  useScroll,
  useSpring,
  useTransform,
  useMotionValueEvent,
  useVelocity,
  type MotionValue,
} from "framer-motion";
import { FA } from "./data";

export function Manifest() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });

  // Live scroll velocity → smoothed → normalized
  const rawVel = useVelocity(scrollY);
  const smoothVel = useSpring(rawVel, { stiffness: 120, damping: 30, mass: 0.5 });
  const velFactor = useTransform(smoothVel, [-3000, 0, 3000], [-1, 0, 1]);

  const lines: Array<{ de: string; fa: string; capDe: string; capFa: string; color: string }> = [
    {
      de: "Jeder Artikel hat eine Farbe.",
      fa: "هر حرف تعریف، یک رنگ دارد.",
      capDe: "der · die · das",
      capFa: "سه رنگ، سه هویت",
      color: "#DD2222",
    },
    {
      de: "Jede Karte kennt ihr Wort.",
      fa: "هر کارت، معنای خودش را می‌شناسد.",
      capDe: "Nomen, Verben, Adjektive",
      capFa: "کارت‌های زنده",
      color: "#F7C948",
    },
    {
      de: "Jede Wiederholung zählt.",
      fa: "هر مرور، یک قدم است.",
      capDe: "FSRS 5 · Leitner",
      capFa: "دو الگوریتم، یک آیین",
      color: "#2563eb",
    },
    {
      de: "Jeder Tag ein Ritual.",
      fa: "هر روز، یک آیین.",
      capDe: "Streak · Retention",
      capFa: "پیوستگی، ماندگاری",
      color: "#1a1a1a",
    },
  ];

  const activeIndex = useTransform(scrollYProgress, (p: number) => {
    const inner = Math.min(Math.max((p - 0.15) / 0.7, 0), 0.9999);
    return Math.floor(inner * lines.length);
  });

  return (
    <section
      ref={ref}
      className="relative mx-auto max-w-[1500px] overflow-hidden px-5 py-24 sm:px-8 sm:py-32 lg:px-12"
    >
      {/* Ambient glows */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div
          className="absolute left-1/3 top-24 h-[420px] w-[420px] rounded-full opacity-25 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(221,34,34,.45), transparent 60%)" }}
        />
        <div
          className="absolute right-8 bottom-16 h-[360px] w-[360px] rounded-full opacity-25 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(247,201,72,.5), transparent 60%)" }}
        />
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: "radial-gradient(currentColor 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
        />
      </div>

      {/* Section chrome */}
      <div className="mb-14 flex items-center justify-between gap-6">
        <div className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.4em] text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--flag-red)" }} />
          Manifest <span className="opacity-50">·</span>
          <FA className="tracking-normal">مانیفست</FA>
        </div>
        <div className="hidden text-[10px] font-bold uppercase tracking-[0.4em] text-muted-foreground sm:block">
          Vier Prinzipien <span className="opacity-50">·</span>
          <FA className="tracking-normal ml-1">چهار اصل</FA>
        </div>
      </div>

      {/* Body — sticky rail + lines */}
      <div className="grid gap-8 lg:grid-cols-[120px_1fr] lg:gap-12">
        <div className="hidden lg:block">
          <div className="sticky top-32">
            <ManifestRail
              progress={scrollYProgress}
              total={lines.length}
              activeIndex={activeIndex}
            />
          </div>
        </div>

        <div className="flex flex-col divide-y divide-border/60">
          {lines.map((l, i) => (
            <ManifestLine
              key={i}
              index={i}
              total={lines.length}
              de={l.de}
              fa={l.fa}
              capDe={l.capDe}
              capFa={l.capFa}
              color={l.color}
              progress={scrollYProgress}
              velFactor={velFactor}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

export function ManifestRail({
  progress,
  total,
  activeIndex,
}: {
  progress: MotionValue<number>;
  total: number;
  activeIndex: MotionValue<number>;
}) {
  const h = useTransform(progress, [0.1, 0.9], ["0%", "100%"]);
  const [active, setActive] = useState(0);
  useMotionValueEvent(activeIndex, "change", (v) => setActive(Math.min(total - 1, Math.max(0, v))));
  return (
    <div className="flex flex-col gap-6">
      <div className="text-[10px] font-bold uppercase tracking-[0.4em] text-muted-foreground">
        {String(active + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}
      </div>
      <div className="relative h-64 w-[3px] overflow-hidden rounded-full bg-border">
        <motion.div style={{ height: h }} className="absolute inset-x-0 top-0 rounded-full">
          <div
            className="h-full w-full"
            style={{ background: "linear-gradient(180deg, #F7C948, #DD2222)" }}
          />
        </motion.div>
      </div>
      <div className="text-[10px] font-bold uppercase tracking-[0.35em] text-muted-foreground">
        Scroll ↓ <FA className="tracking-normal">پایین بیا</FA>
      </div>
    </div>
  );
}

export function ManifestLine({
  de,
  fa,
  capDe,
  capFa,
  color,
  index,
  total,
  progress,
  velFactor,
}: {
  de: string;
  fa: string;
  capDe: string;
  capFa: string;
  color: string;
  index: number;
  total: number;
  progress: MotionValue<number>;
  velFactor: MotionValue<number>;
}) {
  const seg = 1 / total;
  const start = 0.1 + index * seg * 0.75;
  const peak = start + seg * 0.4;
  const end = start + seg * 1.15;

  // Subtle enter from left (DE) / right (FA), then settle and stay put
  const xDe = useTransform(progress, [start, peak, end], [-40, 0, 0]);
  const xFa = useTransform(progress, [start, peak, end], [40, 0, 0]);
  const opacity = useTransform(progress, [start, peak, end], [0.15, 1, 0.85]);
  const scale = useTransform(progress, [start, peak, end], [0.97, 1, 1]);

  // Keep velocity as a tiny visual cue only (no skew, minimal push)
  void velFactor;

  const accent = useTransform(progress, [start, peak, end], ["#8A8B92", color, "#8A8B92"]);

  return (
    <motion.div
      style={{ opacity, scale }}
      className="grid gap-6 py-10 sm:py-14 md:grid-cols-[80px_1fr_1fr] md:gap-10 md:py-16"
    >
      {/* Number */}
      <div className="flex items-start gap-3 md:block">
        <motion.div
          style={{ color: accent }}
          className="font-display text-4xl font-black leading-none tracking-tight sm:text-5xl"
        >
          {String(index + 1).padStart(2, "0")}
        </motion.div>
        <div className="hidden h-px w-10 translate-y-4 bg-border md:block" />
      </div>

      {/* DE side */}
      <motion.div style={{ x: xDe }} className="will-change-transform">
        <div className="font-display text-3xl font-black leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
          {de}
        </div>
        <div className="mt-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.35em] text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
          {capDe}
        </div>
      </motion.div>

      {/* FA side */}
      <motion.div dir="rtl" style={{ x: xFa }} className="text-right will-change-transform">
        <div
          className="fa-inline text-2xl font-black leading-[1.15] sm:text-4xl md:text-5xl"
          style={{ color }}
        >
          {fa}
        </div>
        <div className="mt-3 flex items-center justify-end gap-2 text-[10px] font-bold tracking-[0.2em] text-muted-foreground">
          <FA className="tracking-normal">{capFa}</FA>
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
        </div>
      </motion.div>
    </motion.div>
  );
}
