import { useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Logo } from "@/components/deusi/Logo";
import { EASE } from "./data";

/* ---------- NAV ---------- */
export function Nav() {
  const { scrollY } = useScroll();
  const [scrolled, setScrolled] = useState(false);
  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 20));

  const items: Array<[string, string, string]> = [
    ["Features", "فیچرها", "#features"],
    ["Bereiche", "بخش‌ها", "#deep-dive"],
    ["Karten", "کارت‌ها", "#cards"],
    ["Reise", "مسیر", "#journey"],
    ["Stimmen", "نظرها", "#testimonials"],
  ];

  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: EASE }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "py-2" : "py-4"}`}
    >
      <motion.div
        layout
        transition={{ duration: 0.5, ease: EASE }}
        className={`mx-auto flex items-center justify-between rounded-full px-3 transition-all duration-500 sm:px-5 ${
          scrolled
            ? "border border-border bg-card/80 py-1.5 shadow-[0_20px_60px_-25px_rgba(20,22,26,0.35)] backdrop-blur-xl"
            : "border border-transparent bg-card/40 py-2 backdrop-blur-md"
        }`}
        style={{ maxWidth: scrolled ? "60rem" : "92rem" }}
      >
        <Link to="/" className="group relative flex items-center gap-2">
          <motion.span
            aria-hidden
            className="absolute -inset-3 -z-10 rounded-full opacity-0 blur-xl transition-opacity duration-500 group-hover:opacity-70"
            style={{ background: "radial-gradient(circle, rgba(221,34,34,.5), transparent 70%)" }}
          />
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 text-sm font-semibold text-muted-foreground md:flex">
          {items.map(([de, fa, h], i) => (
            <motion.a
              key={h}
              href={h}
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 + i * 0.06, duration: 0.5, ease: EASE }}
              className="group relative rounded-full px-3.5 py-2 transition-colors hover:text-foreground"
            >
              <span
                aria-hidden
                className="absolute inset-0 -z-10 scale-90 rounded-full opacity-0 transition-all duration-300 group-hover:scale-100 group-hover:opacity-100"
                style={{
                  background: "linear-gradient(135deg, rgba(221,34,34,.10), rgba(247,201,72,.14))",
                }}
              />
              <span className="nav-flip align-middle">
                <span className="flip-de whitespace-nowrap">{de}</span>
                <span
                  className="flip-fa fa-inline whitespace-nowrap font-bold"
                  dir="rtl"
                  style={{ color: "var(--flag-red)" }}
                >
                  {fa}
                </span>
              </span>
              <span
                aria-hidden
                className="absolute inset-x-3 -bottom-0.5 h-[2px] origin-left scale-x-0 rounded-full transition-transform duration-500 group-hover:scale-x-100"
                style={{ background: "linear-gradient(90deg, #1a1a1a, #DD2222, #F7C948)" }}
              />
            </motion.a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/login"
            className="hidden rounded-full px-3.5 py-2 text-sm font-semibold text-muted-foreground transition hover:text-foreground sm:inline-flex"
          >
            <span className="nav-flip">
              <span className="flip-de">Anmelden</span>
              <span
                className="flip-fa fa-inline font-bold"
                dir="rtl"
                style={{ color: "var(--flag-red)" }}
              >
                ورود
              </span>
            </span>
          </Link>
          <MagneticLink to="/register" />
        </div>
      </motion.div>
    </motion.header>
  );
}

export function MagneticLink({ to }: { to: string }) {
  const ref = useRef<HTMLAnchorElement>(null);
  const [t, setT] = useState({ x: 0, y: 0 });
  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    setT({
      x: (e.clientX - (r.left + r.width / 2)) * 0.25,
      y: (e.clientY - (r.top + r.height / 2)) * 0.3,
    });
  };
  return (
    <Link
      to={to}
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setT({ x: 0, y: 0 })}
      style={{
        background: "linear-gradient(135deg, #1a1a1a 0%, #B01818 55%, #DD2222 100%)",
        boxShadow: "0 12px 30px -12px rgba(221,34,34,0.6)",
        transform: `translate(${t.x}px, ${t.y}px)`,
        transition: "transform .35s cubic-bezier(.2,.8,.2,1), box-shadow .35s ease",
      }}
      className="shine-on-hover magnetic group inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-bold text-white"
    >
      <span className="nav-flip">
        <span className="flip-de">Start</span>
        <span className="flip-fa fa-inline" dir="rtl">
          شروع
        </span>
      </span>
      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
    </Link>
  );
}
