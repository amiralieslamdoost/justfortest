import { useRef, useMemo } from "react";
import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { useIsMobile } from "@/hooks/use-mobile";
import { EASE, FA } from "./data";

export function AppShowcase() {
  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });

  const modules = [
    {
      tag: "Karten",
      tagFa: "کارت‌ها",
      title: "Deine tägliche Karten-Session",
      titleFa: "جلسهٔ روزانهٔ کارت‌های تو",
      c: "#DD2222",
      body: (
        <div className="grid grid-cols-3 gap-2">
          {[
            ["der", "der Baum", "درخت", "#2563eb"],
            ["die", "die Sonne", "خورشید", "#DD2222"],
            ["das", "das Licht", "نور", "#F7C948"],
            ["der", "der Weg", "راه", "#2563eb"],
            ["die", "die Welt", "جهان", "#DD2222"],
            ["das", "das Herz", "دل", "#F7C948"],
          ].map(([tag, w, fa, col]) => (
            <div key={w} className="rounded-2xl border border-border bg-card p-3">
              <span
                className="inline-block rounded-full px-2 py-0.5 text-[9px] font-bold uppercase text-white"
                style={{ background: col }}
              >
                {tag}
              </span>
              <div className="mt-2 font-display text-sm font-black tracking-tight">{w}</div>
              <div
                dir="rtl"
                className="fa-inline text-[11px] font-bold"
                style={{ color: col as string }}
              >
                {fa}
              </div>
            </div>
          ))}
        </div>
      ),
    },
    {
      tag: "Grammatik",
      tagFa: "گرامر",
      title: "Grammatik als Landkarte",
      titleFa: "گرامر مثل نقشه",
      c: "#F7C948",
      body: (
        <div className="relative h-40">
          {[
            ["Nomen", 10, 20],
            ["Verben", 40, 55],
            ["Artikel", 8, 90],
            ["Kasus", 55, 30],
            ["Passiv", 78, 70],
          ].map(([t, x, y], i) => (
            <div
              key={i}
              className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold shadow"
              style={{ left: `${x}%`, top: `${y}%` }}
            >
              {t as string}
            </div>
          ))}
          <svg
            className="absolute inset-0 h-full w-full"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
          >
            <path
              d="M10,20 Q30,10 40,55 T55,30 T78,70"
              stroke="#F7C948"
              strokeDasharray="3 3"
              strokeWidth="0.5"
              fill="none"
            />
          </svg>
        </div>
      ),
    },
    {
      tag: "KI-Coach",
      tagFa: "مربی هوشمند",
      title: "Sprich frei — bekomme Korrekturen",
      titleFa: "آزاد حرف بزن، اصلاح بگیر",
      c: "#8B5CF6",
      body: (
        <div className="space-y-2 text-sm">
          <div className="ml-auto max-w-[80%] rounded-2xl rounded-br-sm bg-secondary px-3 py-2">
            Gestern ich habe Pizza gegessen.
          </div>
          <div className="max-w-[85%] rounded-2xl rounded-bl-sm border border-border bg-card px-3 py-2">
            <span className="font-bold text-[#8B5CF6]">
              Gestern <span className="line-through opacity-60">ich habe</span>{" "}
              <span className="underline">habe ich</span> Pizza gegessen.
            </span>
            <div className="mt-1 text-xs text-muted-foreground">
              Im Nebensatz mit Zeitangabe steht das Verb zuerst.
            </div>
            <FA className="mt-1 block text-[11px] text-muted-foreground/85">
              در جمله با قید زمان، فعل اول می‌آید.
            </FA>
          </div>
        </div>
      ),
    },
    {
      tag: "Statistik",
      tagFa: "آمار",
      title: "Dein Rhythmus, sichtbar",
      titleFa: "ریتم تو، قابل‌دیدن",
      c: "#22C55E",
      body: <HeatmapPreview />,
    },
  ];

  return (
    <section
      ref={ref}
      className="relative mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12"
      style={{ height: isMobile ? "auto" : `${modules.length * 100}vh` }}
    >
      {isMobile ? (
        <MobileShowcaseStack modules={modules} />
      ) : (
        <div className="sticky top-0 grid h-screen place-items-center py-10">
          <div className="w-full">
            <div className="mb-6 text-center">
              <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-muted-foreground backdrop-blur">
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ background: "var(--flag-red)" }}
                />
                Live-Vorschau · <FA className="tracking-normal">پیش‌نمایش زنده</FA>
              </div>
            </div>
            <div className="relative mx-auto h-[62vh] max-w-3xl">
              {modules.map((m, i) => (
                <ShowcaseCard
                  key={i}
                  {...m}
                  index={i}
                  total={modules.length}
                  progress={scrollYProgress}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/* Static heatmap grid — deterministic (no Math.random ⇒ no SSR mismatch, no re-render churn). */
export function HeatmapPreview() {
  const cells = useMemo(
    () =>
      Array.from({ length: 14 * 7 }).map((_, i) => {
        const v = ((i * 2654435761) >>> 0) / 0xffffffff;
        return v < 0.15
          ? "rgb(var(--shadow-color)/.06)"
          : v < 0.5
            ? "#86efac"
            : v < 0.8
              ? "#22c55e"
              : "#166534";
      }),
    [],
  );
  return (
    <div className="grid gap-1" style={{ gridTemplateColumns: "repeat(14, minmax(0, 1fr))" }}>
      {cells.map((bg, i) => (
        <span key={i} className="aspect-square rounded-[3px]" style={{ background: bg }} />
      ))}
    </div>
  );
}

export type ShowcaseModule = {
  tag: string;
  tagFa: string;
  title: string;
  titleFa: string;
  body: React.ReactNode;
  c: string;
};

/* Mobile-friendly plain stack — no scroll-linked transforms, no sticky, no pinned viewport. */
export function MobileShowcaseStack({ modules }: { modules: ShowcaseModule[] }) {
  return (
    <div className="py-16">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-muted-foreground backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--flag-red)" }} />
          Live-Vorschau · <FA className="tracking-normal">پیش‌نمایش زنده</FA>
        </div>
      </div>
      <div className="mx-auto grid max-w-3xl gap-5">
        {modules.map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-10% 0px" }}
            transition={{ duration: 0.5, ease: EASE }}
            className="relative overflow-hidden rounded-[1.75rem] border border-border bg-card p-6 shadow-[0_30px_60px_-40px_rgba(20,22,26,0.35)]"
          >
            <div
              className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-40 blur-3xl"
              style={{ background: m.c }}
            />
            <div className="relative">
              <span
                className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest"
                style={{ color: m.c }}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: m.c }} />
                {m.tag} <span className="opacity-60">·</span>{" "}
                <FA className="tracking-normal">{m.tagFa}</FA>
              </span>
              <h3 className="mt-3 font-display text-2xl font-black leading-tight tracking-tight">
                {m.title}
              </h3>
              <div dir="rtl" className="fa-inline mt-1 text-lg font-black" style={{ color: m.c }}>
                {m.titleFa}
              </div>
              <div className="mt-4 rounded-2xl border border-border bg-secondary/50 p-4">
                {m.body}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export function ShowcaseCard({
  tag,
  tagFa,
  title,
  titleFa,
  body,
  c,
  index,
  total,
  progress,
}: {
  tag: string;
  tagFa: string;
  title: string;
  titleFa: string;
  body: React.ReactNode;
  c: string;
  index: number;
  total: number;
  progress: MotionValue<number>;
}) {
  const seg = 1 / total;
  const start = index * seg;
  const mid = start + seg * 0.55;
  const end = (index + 1) * seg;
  const scale = useTransform(progress, [start, mid, end], [0.94, 1, 0.9]);
  const y = useTransform(progress, [start, mid, end], [40, 0, -60]);
  const opacity = useTransform(
    progress,
    [start, mid - seg * 0.2, mid, end - seg * 0.05, end],
    [0, 1, 1, 1, 0],
  );
  const rot = useTransform(progress, [start, mid, end], [3, 0, -3]);

  return (
    <motion.div
      style={{ scale, y, opacity, rotate: rot, zIndex: 10 + index }}
      className="absolute inset-0 overflow-hidden rounded-[2rem] border border-border bg-card p-6 shadow-[0_40px_100px_-40px_rgba(20,22,26,0.35)] sm:p-10"
    >
      <div
        className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full opacity-40 blur-3xl"
        style={{ background: c }}
      />
      <div className="relative grid gap-6 md:grid-cols-[1.1fr_1fr]">
        <div>
          <span
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest"
            style={{ color: c }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} />
            {tag} <span className="opacity-60">·</span> <FA className="tracking-normal">{tagFa}</FA>
          </span>
          <h3 className="mt-4 font-display text-3xl font-black leading-tight tracking-tight sm:text-4xl">
            {title}
          </h3>
          <div dir="rtl" className="fa-inline mt-2 text-xl font-black" style={{ color: c }}>
            {titleFa}
          </div>
          <div className="mt-5 flex items-center gap-2 text-xs font-bold text-muted-foreground">
            <span
              className="grid h-6 w-6 place-items-center rounded-full text-white"
              style={{ background: c }}
            >
              {index + 1}
            </span>
            von <span className="opacity-70">{total}</span> · <FA>از {total}</FA>
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-secondary/50 p-4 sm:p-5">{body}</div>
      </div>
    </motion.div>
  );
}
