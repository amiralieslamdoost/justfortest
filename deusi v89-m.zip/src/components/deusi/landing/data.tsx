export const EASE = [0.22, 1, 0.36, 1] as const;

/* Small bilingual helpers */
export function FA({
  children,
  className = "",
  style,
}: {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <span className={`fa-inline ${className}`} dir="rtl" style={style}>
      {children}
    </span>
  );
}
