import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { EASE, FA } from "./data";
import { SectionHeader } from "./SectionHeader";

export function Journey() {
  const steps = [
    {
      n: "01",
      t: "Anmelden in 60 s",
      tFa: "ثبت‌نام در ۶۰ ثانیه",
      d: "Benutzername, E-Mail, fertig. Kein Kreditkarten-Zwang.",
      dFa: "نام کاربری، ایمیل، تمام. بدون کارت اعتباری.",
      c: "#1a1a1a",
    },
    {
      n: "02",
      t: "Niveau wählen",
      tFa: "انتخاب سطح",
      d: "A1 bis C2 — DEUSI stellt deinen Pfad zusammen.",
      dFa: "از A1 تا C2 — دئوسی مسیرت را می‌سازد.",
      c: "#DD2222",
    },
    {
      n: "03",
      t: "Täglich üben",
      tFa: "تمرین روزانه",
      d: "10 Minuten reichen. FSRS wählt die richtigen Karten.",
      dFa: "ده دقیقه کافی‌ست. FSRS کارت‌های درست را انتخاب می‌کند.",
      c: "#F7C948",
    },
    {
      n: "04",
      t: "Fortschritt sehen",
      tFa: "دیدن پیشرفت",
      d: "Heatmap, Serien, Retention — visualisiert und ehrlich.",
      dFa: "هیت‌مپ، سری‌ها، ماندگاری — تصویری و صادقانه.",
      c: "#22C55E",
    },
  ];

  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const lineScale = useTransform(scrollYProgress, [0.2, 0.85], [0, 1]);

  return (
    <section
      id="journey"
      ref={ref}
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="So funktioniert es"
        kickerFa="چطور کار می‌کند"
        title={
          <>
            Vier Schritte.
            <br />
            <span style={{ color: "var(--flag-red)" }}>Ein neuer Alltag.</span>
          </>
        }
        titleFa={
          <>
            چهار قدم. <span style={{ color: "var(--flag-red)" }}>یک آیین تازه.</span>
          </>
        }
        subtitle="Kein Schnickschnack, kein Auswendiglernen alter Listen — nur ein Ritual, das trägt."
        subtitleFa="بدون شلوغی، بدون حفظ لیست‌های خشک — فقط یک آیین که تو را می‌برد."
      />
      <div className="relative mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-6 top-14 hidden h-px lg:block bg-border"
        />
        <motion.div
          aria-hidden
          className="pointer-events-none absolute inset-x-6 top-14 hidden h-[2px] lg:block"
          style={{
            scaleX: lineScale,
            transformOrigin: "0% 50%",
            background: "linear-gradient(90deg, #1a1a1a, #DD2222 45%, #F7C948)",
          }}
        />
        {steps.map((s, i) => (
          <motion.div
            key={s.n}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ delay: i * 0.1, duration: 0.6, ease: EASE }}
            whileHover={{ y: -6 }}
            className="relative rounded-3xl border border-border bg-card p-6 transition-shadow hover:shadow-2xl"
          >
            <div
              className="relative z-10 grid h-14 w-14 place-items-center rounded-2xl font-display text-lg font-black text-white shadow-lg"
              style={{
                background: `linear-gradient(135deg, ${s.c}, ${s.c}aa)`,
                boxShadow: `0 20px 30px -15px ${s.c}80`,
              }}
            >
              {s.n}
            </div>
            <h3 className="mt-5 font-display text-lg font-black tracking-tight">{s.t}</h3>
            <FA className="mt-0.5 block text-sm font-bold" style={{ color: s.c }}>
              {s.tFa}
            </FA>
            <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            <FA className="mt-2 block text-sm text-muted-foreground/85">{s.dFa}</FA>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
