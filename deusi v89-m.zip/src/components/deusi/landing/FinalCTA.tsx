import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { EASE, FA } from "./data";

export function FinalCTA() {
  return (
    <section className="mx-auto max-w-[1400px] px-4 pb-24 sm:px-8">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7, ease: EASE }}
        className="relative overflow-hidden rounded-[2.5rem] p-8 text-white sm:p-16"
        style={{
          background: "linear-gradient(135deg, #0d0d0d 0%, #2a1010 45%, #DD2222 85%, #F7C948 140%)",
          boxShadow: "0 60px 120px -50px rgba(221,34,34,0.7)",
        }}
      >
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-black/40 blur-3xl" />
          <svg
            className="absolute right-8 top-8 h-32 w-32 opacity-15"
            viewBox="0 0 100 100"
            fill="none"
          >
            <polygon points="50,4 96,27 96,73 50,96 4,73 4,27" stroke="white" strokeWidth="1" />
            <polygon points="50,20 80,35 80,65 50,80 20,65 20,35" stroke="white" strokeWidth="1" />
          </svg>
        </div>
        <div className="relative max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold uppercase tracking-widest backdrop-blur">
            <Sparkles className="h-3.5 w-3.5" style={{ color: "#F7C948" }} /> Bereit?{" "}
            <FA className="tracking-normal">· آماده‌ای؟</FA>
          </div>
          <h2 className="mt-5 font-display text-4xl font-black leading-[1.05] tracking-tight sm:text-6xl">
            Dein Deutsch
            <br />
            beginnt <span style={{ color: "#F7C948" }}>jetzt.</span>
          </h2>
          <p dir="rtl" className="fa-inline mt-3 text-2xl font-black leading-tight sm:text-4xl">
            آلمانی‌ات از <span style={{ color: "#F7C948" }}>همین حالا</span> شروع می‌شود.
          </p>
          <p className="mt-4 max-w-lg text-white/80">
            Erstelle dein kostenloses Konto und lerne heute noch deine ersten fünf Karten.
          </p>
          <p dir="rtl" className="fa-inline mt-1 max-w-lg text-white/75">
            حساب رایگانت را بساز و همین امروز پنج کارت اولت را یاد بگیر.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/register"
              className="group inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-3.5 text-sm font-bold text-[#0d0d0d] shadow-2xl transition hover:scale-[1.02]"
            >
              Kostenlos starten <FA className="text-[#0d0d0d]/70">· رایگان شروع کن</FA>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 rounded-2xl border border-white/25 bg-white/10 px-5 py-3.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
            >
              Ich habe schon ein Konto <FA className="text-white/70">· حساب دارم</FA>
            </Link>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
