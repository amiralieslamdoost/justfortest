import { motion, animate } from "framer-motion";
import { FA } from "./data";

export function Marquee() {
  const items = [
    ["Wortschatz", "واژه"],
    ["Grammatik", "گرامر"],
    ["Prüfungen", "آزمون"],
    ["Konjugation", "صرف فعل"],
    ["Deklination", "صرف اسم"],
    ["Redewendungen", "اصطلاح"],
    ["Aussprache", "تلفظ"],
    ["Lesen", "خواندن"],
    ["Podcasts", "پادکست"],
    ["KI-Coach", "مربی هوش مصنوعی"],
  ];
  const doubled = [...items, ...items];
  return (
    <div className="relative my-4 overflow-hidden border-y border-border/60 bg-card/40 py-5 backdrop-blur">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-20 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-20 bg-gradient-to-l from-background to-transparent" />
      <motion.div
        className="flex gap-8 whitespace-nowrap"
        animate={{ x: ["0%", "-50%"] }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
      >
        {doubled.map(([de, fa], i) => (
          <span
            key={i}
            className="flex items-center gap-4 font-display text-2xl font-black tracking-tight text-muted-foreground sm:text-3xl"
          >
            {de}
            <FA className="text-xl font-bold opacity-70">{fa}</FA>
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ background: i % 3 === 0 ? "#DD2222" : i % 3 === 1 ? "#F7C948" : "#1a1a1a" }}
            />
          </span>
        ))}
      </motion.div>
    </div>
  );
}
