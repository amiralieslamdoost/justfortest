import { useState } from "react";
import { motion, animate } from "framer-motion";
import { EASE, FA } from "./data";
import { SectionHeader } from "./SectionHeader";

export function FlashcardShowcase() {
  const [flipped, setFlipped] = useState(false);
  const cards = [
    {
      front: "die Sehnsucht",
      back: "longing · desire",
      fa: "دلتنگی",
      ex: "Er spürt eine große Sehnsucht nach der Heimat.",
      exFa: "او دلتنگی بزرگی برای وطن حس می‌کند.",
    },
    {
      front: "der Feierabend",
      back: "end of workday",
      fa: "پایان روز کاری",
      ex: "Nach dem Feierabend gehen wir spazieren.",
      exFa: "بعد از پایان کار، پیاده‌روی می‌کنیم.",
    },
    {
      front: "das Fernweh",
      back: "wanderlust",
      fa: "شوق سفر",
      ex: "Das Fernweh packt mich jedes Frühjahr.",
      exFa: "شوق سفر هر بهار سراغم می‌آید.",
    },
  ];
  const [i, setI] = useState(0);
  const c = cards[i];

  return (
    <section
      id="cards"
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <div>
          <SectionHeader
            align="left"
            kicker="Karten mit Charakter"
            kickerFa="کارت‌هایی با شخصیت"
            title={
              <>
                Klick sie um.
                <br />
                <span style={{ color: "var(--flag-red)" }}>Fühl das Deutsche.</span>
              </>
            }
            titleFa={
              <>
                روی کارت کلیک کن. <span style={{ color: "var(--flag-red)" }}>آلمانی را حس کن.</span>
              </>
            }
            subtitle="Jede Karte kennt ihre Wortart — mit Artikel, Kontextsatz und einem Klick zur Bedeutung. FSRS entscheidet, wann du sie wiedersiehst."
            subtitleFa="هر کارت نوع کلمه‌اش را می‌شناسد — با حرف تعریف، جمله و یک کلیک تا معنی. FSRS تصمیم می‌گیرد کِی دوباره ببینی‌اش."
          />
          <ul className="mt-8 space-y-3">
            {[
              ["Artikel-Farbcode für der/die/das", "کد رنگی برای der/die/das"],
              ["Beispielsätze aus echten Texten", "جمله‌های نمونه از متن‌های واقعی"],
              [
                "Vier Bewertungen: Nochmal · Schwer · Gut · Leicht",
                "چهار درجه: دوباره · سخت · خوب · آسان",
              ],
              ["Automatische Wiederholung durch FSRS 5", "مرور خودکار با FSRS 5"],
            ].map(([de, fa], k) => (
              <motion.li
                key={de}
                initial={{ opacity: 0, x: -12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: k * 0.08, duration: 0.5 }}
                className="flex items-start gap-3 text-sm"
              >
                <span
                  className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-bold text-white"
                  style={{ background: "var(--flag-red)" }}
                >
                  ✓
                </span>
                <span className="min-w-0">
                  <span>{de}</span>
                  <FA className="ml-2 text-muted-foreground">· {fa}</FA>
                </span>
              </motion.li>
            ))}
          </ul>
        </div>

        <div className="flex flex-col items-center gap-6">
          <div className="flip-scene w-full max-w-sm" style={{ perspective: 1400 }}>
            <motion.button
              type="button"
              onClick={() => setFlipped((f) => !f)}
              whileHover={{ y: -4 }}
              animate={{ rotateY: flipped ? 180 : 0 }}
              transition={{ duration: 0.8, ease: EASE }}
              className="relative aspect-[3/4] w-full cursor-pointer"
              style={{ transformStyle: "preserve-3d" }}
              aria-label="Karte umdrehen"
            >
              {/* FRONT */}
              <div
                className="card-glass absolute inset-0 flex flex-col justify-between p-8"
                style={{ backfaceVisibility: "hidden" }}
              >
                <div
                  className="inline-flex w-fit items-center gap-2 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider"
                  style={{
                    background: c.front.startsWith("der")
                      ? "#2563eb"
                      : c.front.startsWith("die")
                        ? "#DD2222"
                        : "#22C55E",
                    color: "#fff",
                  }}
                >
                  {c.front.split(" ")[0]}
                </div>
                <div className="text-center">
                  <div className="font-display text-4xl font-black tracking-tight">{c.front}</div>
                  <div dir="rtl" className="fa-inline mt-2 text-lg font-bold text-muted-foreground">
                    {c.fa}
                  </div>
                  <div className="mt-4 text-xs text-muted-foreground">
                    Klicke, um zu drehen <FA>· برای برگرداندن کلیک کن</FA>
                  </div>
                </div>
                <div className="flex justify-center gap-1.5">
                  {cards.map((_, k) => (
                    <span
                      key={k}
                      className={`h-1.5 rounded-full transition-all ${k === i ? "w-6 bg-foreground" : "w-1.5 bg-muted-foreground/30"}`}
                    />
                  ))}
                </div>
              </div>
              {/* BACK */}
              <div
                className="card-glass absolute inset-0 flex flex-col justify-between p-8"
                style={{
                  backfaceVisibility: "hidden",
                  transform: "rotateY(180deg)",
                  background: "linear-gradient(160deg, #1a1a1a 0%, #2a1010 55%, #DD2222 130%)",
                  color: "#fff",
                }}
              >
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/70">
                  Bedeutung <FA className="text-white/60">· معنی</FA>
                </div>
                <div className="text-center">
                  <div
                    className="font-display text-3xl font-black tracking-tight"
                    style={{ color: "#F7C948" }}
                  >
                    {c.back}
                  </div>
                  <p className="mt-4 text-sm italic text-white/80">„{c.ex}"</p>
                  <p dir="rtl" className="fa-inline mt-2 text-sm italic text-white/70">
                    «{c.exFa}»
                  </p>
                </div>
                <div className="flex justify-center gap-1.5">
                  {["#EF4444", "#F59E0B", "#3B82F6", "#22C55E"].map((color) => (
                    <span
                      key={color}
                      className="h-2 w-6 rounded-full"
                      style={{ background: color }}
                    />
                  ))}
                </div>
              </div>
            </motion.button>
          </div>
          <div className="flex items-center gap-2">
            {cards.map((_, k) => (
              <button
                key={k}
                onClick={() => {
                  setFlipped(false);
                  setI(k);
                }}
                className={`h-2 rounded-full transition-all ${k === i ? "w-8 bg-foreground" : "w-2 bg-muted-foreground/30 hover:bg-muted-foreground/60"}`}
                aria-label={`Karte ${k + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
