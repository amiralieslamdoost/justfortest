import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/deusi/Logo";

export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-[1400px] flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-8">
        <Logo />
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} DEUSI · Deutsch. Einfach. Meistern.
        </p>
        <div className="flex gap-4 text-xs font-semibold text-muted-foreground">
          <Link to="/impressum" className="hover:text-foreground">
            Impressum
          </Link>
          <Link to="/datenschutz" className="hover:text-foreground">
            Datenschutz
          </Link>
          <Link to="/support" className="hover:text-foreground">
            Kontakt
          </Link>
        </div>
      </div>
    </footer>
  );
}
