import { useRef } from "react";
import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { BookOpen, Brain, Headphones, GraduationCap, BarChart3, MessageSquare } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { EASE, FA } from "./data";

export function HorizontalFeatures() {
  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const x = useTransform(scrollYProgress, [0, 1], ["2%", "-78%"]);

  const panels = [
    {
      n: "01",
      de: "Wortschatz",
      fa: "واژه",
      desc: "12 000 kuratierte Wörter mit Artikel, Beispiel und Ton.",
      descFa: "دوازده هزار واژهٔ گزیده با حرف تعریف، جمله و صدا.",
      c: "#DD2222",
      icon: BookOpen,
    },
    {
      n: "02",
      de: "Grammatik",
      fa: "گرامر",
      desc: "Interaktive Pfade von A1 bis C2 — Fälle, Zeiten, Modi.",
      descFa: "مسیر تعاملی از A1 تا C2 — حالت‌ها، زمان‌ها، وجوه.",
      c: "#F7C948",
      icon: Brain,
    },
    {
      n: "03",
      de: "KI-Coach",
      fa: "کوچ هوشمند",
      desc: "Chatte auf deinem Niveau, bekomme Korrekturen mit Erklärung.",
      descFa: "در سطح خودت گفت‌وگو کن، اصلاح و توضیح بگیر.",
      c: "#8B5CF6",
      icon: MessageSquare,
    },
    {
      n: "04",
      de: "Podcasts",
      fa: "پادکست",
      desc: "Echte Stimmen mit interaktivem Transkript und Wörterbuch.",
      descFa: "صداهای واقعی با متن تعاملی و دیکشنری زیر انگشت.",
      c: "#22C55E",
      icon: Headphones,
    },
    {
      n: "05",
      de: "Prüfungen",
      fa: "آزمون",
      desc: "Original-nahe Goethe / telc / ÖSD-Simulationen.",
      descFa: "شبیه‌سازهای نزدیک به اصل گوته، telc و ÖSD.",
      c: "#0EA5E9",
      icon: GraduationCap,
    },
    {
      n: "06",
      de: "Statistik",
      fa: "آمار",
      desc: "Heatmap, Serien, Wortarten — dein Rhythmus in Echtzeit.",
      descFa: "هیت‌مپ، سری‌ها و اجزای کلام — ریتم تو، لحظه‌ای.",
      c: "#EF4444",
      icon: BarChart3,
    },
  ];

  return (
    <section ref={ref} className="relative" data-h-features>
      {isMobile ? (
        <div className="mx-auto max-w-3xl px-5 py-16">
          <div className="mb-8 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.4em]">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#DD2222" }} />
            Universum · <FA className="tracking-normal">جهان دئوسی</FA>
          </div>
          <div className="grid gap-4">
            {panels.map((p) => {
              const Icon = p.icon;
              return (
                <motion.div
                  key={p.n}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-10% 0px" }}
                  transition={{ duration: 0.45, ease: EASE }}
                  className="rounded-2xl border border-border bg-card p-5"
                >
                  <div className="mb-3 flex items-center justify-between">
                    <span
                      className="grid h-9 w-9 place-items-center rounded-xl text-white"
                      style={{ background: p.c }}
                    >
                      <Icon className="h-4.5 w-4.5" />
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-[0.35em] text-muted-foreground">
                      {p.n}
                    </span>
                  </div>
                  <div className="font-display text-xl font-black tracking-tight">{p.de}</div>
                  <div
                    dir="rtl"
                    className="fa-inline mt-0.5 text-base font-black"
                    style={{ color: p.c }}
                  >
                    {p.fa}
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
                  <p dir="rtl" className="fa-inline mt-1 text-xs text-muted-foreground/85">
                    {p.descFa}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      ) : (
        <div style={{ height: `${panels.length * 90}vh` }}>
          <div className="sticky top-0 flex h-screen items-center overflow-hidden">
            <div className="absolute inset-x-0 top-8 z-10 flex items-center justify-between px-6 sm:px-10">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.4em]">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#DD2222" }} />
                Universum · <FA className="tracking-normal">جهان دئوسی</FA>
              </div>
              <HorizontalProgress progress={scrollYProgress} total={panels.length} />
            </div>

            <motion.div
              style={{ x }}
              className="flex gap-6 pl-[6vw] pr-[20vw] will-change-transform"
            >
              {panels.map((p, i) => (
                <HorizontalPanel
                  key={p.n}
                  {...p}
                  index={i}
                  total={panels.length}
                  progress={scrollYProgress}
                />
              ))}
            </motion.div>

            <div className="pointer-events-none absolute bottom-6 left-0 right-0 flex justify-center text-[10px] font-bold uppercase tracking-[0.4em] opacity-60">
              Scroll ↓ · <FA className="ml-1 tracking-normal">پایین بیا</FA>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

export function HorizontalProgress({
  progress,
  total,
}: {
  progress: MotionValue<number>;
  total: number;
}) {
  const w = useTransform(progress, [0, 1], ["0%", "100%"]);
  return (
    <div className="hidden items-center gap-3 sm:flex">
      <span className="text-[10px] font-bold uppercase tracking-[0.4em] opacity-70">
        01 / {String(total).padStart(2, "0")}
      </span>
      <div className="relative h-[3px] w-40 overflow-hidden rounded-full bg-current/15">
        <motion.div style={{ width: w }} className="h-full rounded-full">
          <div
            className="h-full w-full"
            style={{ background: "linear-gradient(90deg, #F7C948, #DD2222)" }}
          />
        </motion.div>
      </div>
    </div>
  );
}

export function HorizontalPanel({
  n,
  de,
  fa,
  desc,
  descFa,
  c,
  icon: Icon,
  index,
  total,
  progress,
}: {
  n: string;
  de: string;
  fa: string;
  desc: string;
  descFa: string;
  c: string;
  icon: typeof BookOpen;
  index: number;
  total: number;
  progress: MotionValue<number>;
}) {
  const start = index / total;
  const mid = start + 1 / total / 2;
  const end = (index + 1) / total;
  const scale = useTransform(progress, [start, mid, end], [0.92, 1, 0.92]);
  const glow = useTransform(progress, [start, mid, end], [0.15, 0.9, 0.15]);
  // Arc — cards tilt at the edges, straighten in the middle.
  // Cards flow right → left, so before centre they lean right, after centre they lean left.
  const rotate = useTransform(progress, [start, mid, end], [7, 0, -7]);
  const yArc = useTransform(progress, [start, mid, end], [28, 0, 28]);

  return (
    <motion.div
      style={{ scale, rotate, y: yArc, transformOrigin: "50% 90%" }}
      className="relative flex h-[74vh] w-[78vw] shrink-0 flex-col justify-between overflow-hidden rounded-[2.5rem] border border-border bg-card p-8 sm:w-[62vw] sm:p-12 md:w-[46vw] lg:w-[38vw]"
    >
      <div
        className="absolute inset-0"
        style={{ background: `linear-gradient(160deg, ${c}18 0%, transparent 40%, ${c}30 100%)` }}
      />
      <motion.div
        aria-hidden
        style={{ opacity: glow }}
        className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full blur-3xl"
      >
        <div className="h-full w-full rounded-full" style={{ background: c }} />
      </motion.div>
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage: "radial-gradient(currentColor 1px, transparent 1px)",
          backgroundSize: "22px 22px",
        }}
      />

      <div className="relative flex items-start justify-between">
        <div
          className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-2xl"
          style={{
            background: `linear-gradient(135deg, ${c}, ${c}bb)`,
            boxShadow: `0 25px 60px -20px ${c}`,
          }}
        >
          <Icon className="h-7 w-7" />
        </div>
        <span className="font-display text-6xl font-black leading-none opacity-15 sm:text-8xl">
          {n}
        </span>
      </div>

      <div className="relative">
        <div className="font-display text-5xl font-black tracking-tight sm:text-7xl">{de}</div>
        <div
          dir="rtl"
          className="fa-inline mt-2 text-3xl font-black sm:text-4xl"
          style={{ color: c }}
        >
          {fa}
        </div>
        <p className="mt-5 max-w-md text-base opacity-80 sm:text-lg">{desc}</p>
        <p dir="rtl" className="fa-inline mt-2 max-w-md text-sm opacity-70 sm:text-base">
          {descFa}
        </p>
        <div className="mt-6 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.4em] opacity-70">
          <span className="h-px w-10 bg-current" />
          Modul {index + 1} / {total}
          <FA className="tracking-normal">· بخش</FA>
        </div>
      </div>
    </motion.div>
  );
}
