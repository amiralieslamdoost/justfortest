import { useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Check,
  Crown,
  Rocket,
  Flame,
  Infinity as InfinityIcon,
  type LucideIcon,
} from "lucide-react";
import { EASE, FA } from "./data";
import { SectionHeader } from "./SectionHeader";

export function Pricing() {
  const [yearly, setYearly] = useState(true);
  const tiers: PricingTier[] = [
    {
      name: "Frei",
      nameFa: "رایگان",
      icon: Rocket,
      c: "#1a1a1a",
      m: 0,
      y: 0,
      tag: "Für den Start",
      tagFa: "برای شروع",
      features: [
        ["500 Karten", "۵۰۰ کارت"],
        ["FSRS 5 & Leitner", "FSRS و لایتنر"],
        ["Grammatik A1–B1", "گرامر A1 تا B1"],
        ["Ohne KI-Coach", "بدون مربی هوشمند"],
      ],
      cta: "Kostenlos starten",
      ctaFa: "شروع رایگان",
    },
    {
      name: "Pro",
      nameFa: "حرفه‌ای",
      icon: Crown,
      c: "#DD2222",
      m: 9,
      y: 79,
      tag: "Meist gewählt",
      tagFa: "پرطرفدارترین",
      featured: true,
      features: [
        ["Unbegrenzte Karten", "کارت‌های نامحدود"],
        ["KI-Coach ohne Limit", "کوچ AI بدون سقف"],
        ["Alle Grammatik-Pfade", "همهٔ مسیرهای گرامر"],
        ["Podcasts & Lesen", "پادکست و خواندن"],
        ["Prüfungssimulationen", "شبیه‌ساز آزمون"],
      ],
      cta: "Pro werden",
      ctaFa: "پرو شو",
    },
    {
      name: "Team",
      nameFa: "تیم",
      icon: Flame,
      c: "#F7C948",
      m: 24,
      y: 219,
      tag: "Für Kurse & Familien",
      tagFa: "برای دوره و خانواده",
      features: [
        ["Bis zu 5 Konten", "تا ۵ حساب"],
        ["Gemeinsame Decks", "دِک مشترک"],
        ["Lehrer-Dashboard", "داشبورد معلم"],
        ["Alles aus Pro", "همهٔ امکانات پرو"],
      ],
      cta: "Team einrichten",
      ctaFa: "تیم بساز",
    },
  ];

  return (
    <section
      id="preise"
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="Preise"
        kickerFa="تعرفه"
        title={
          <>
            Fair. Ehrlich.
            <br />
            <span style={{ color: "var(--flag-red)" }}>Ohne Kleingedrucktes.</span>
          </>
        }
        titleFa={
          <>
            منصفانه، صادقانه، <span style={{ color: "var(--flag-red)" }}>بدون شرط‌های ریز.</span>
          </>
        }
        subtitle="Starte kostenlos, wachse mit Pro. Jederzeit kündbar — kein Vertrag, keine versteckten Gebühren."
        subtitleFa="رایگان شروع کن، با پرو رشد کن. هر وقت خواستی لغو کن — بدون قرارداد، بدون هزینهٔ پنهان."
      />

      {/* Toggle */}
      <div className="mt-10 flex justify-center">
        <div className="relative flex items-center gap-1 rounded-full border border-border bg-card p-1 text-sm font-bold shadow-lg">
          <motion.span
            layout
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="absolute inset-y-1 w-1/2 rounded-full"
            style={{
              left: yearly ? "50%" : "0.25rem",
              right: yearly ? "0.25rem" : "50%",
              background: "linear-gradient(135deg, #1a1a1a, #DD2222)",
            }}
          />
          <button
            onClick={() => setYearly(false)}
            className={`relative z-10 rounded-full px-5 py-2 transition ${!yearly ? "text-white" : "text-muted-foreground hover:text-foreground"}`}
          >
            Monatlich <FA className="text-[10px] opacity-80">· ماهانه</FA>
          </button>
          <button
            onClick={() => setYearly(true)}
            className={`relative z-10 rounded-full px-5 py-2 transition ${yearly ? "text-white" : "text-muted-foreground hover:text-foreground"}`}
          >
            Jährlich <FA className="text-[10px] opacity-80">· سالانه</FA>
            <span className="ml-1.5 rounded-full bg-[#F7C948] px-1.5 py-0.5 text-[9px] font-black text-[#1a1a1a]">
              -27%
            </span>
          </button>
        </div>
      </div>

      <div className="mt-12 grid gap-5 md:grid-cols-3 md:items-stretch">
        {tiers.map((t, i) => (
          <PricingCard key={t.name} tier={t} yearly={yearly} index={i} />
        ))}
      </div>

      <p className="mt-8 text-center text-xs text-muted-foreground">
        Alle Preise in EUR inkl. MwSt. · <FA>همه با احتساب مالیات</FA>
      </p>
    </section>
  );
}

export type PricingTier = {
  name: string;
  nameFa: string;
  icon: LucideIcon;
  c: string;
  m: number;
  y: number;
  tag: string;
  tagFa: string;
  featured?: boolean;
  features: [string, string][];
  cta: string;
  ctaFa: string;
};

export function PricingCard({
  tier,
  yearly,
  index,
}: {
  tier: PricingTier;
  yearly: boolean;
  index: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0 });
  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    setTilt({ rx: -py * 8, ry: px * 10 });
  };
  const Icon = tier.icon;
  const price = yearly ? tier.y : tier.m;

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setTilt({ rx: 0, ry: 0 })}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ delay: index * 0.1, duration: 0.7, ease: EASE }}
      style={{
        transform: `perspective(1200px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
        transition: "transform .35s cubic-bezier(.2,.8,.2,1)",
      }}
      className={`relative flex flex-col overflow-hidden rounded-[2rem] border p-7 sm:p-8 ${
        tier.featured
          ? "border-transparent text-white shadow-[0_50px_120px_-40px_rgba(221,34,34,0.7)]"
          : "border-border bg-card shadow-[0_20px_60px_-30px_rgba(20,22,26,0.35)]"
      }`}
    >
      {tier.featured && (
        <>
          <div
            className="absolute inset-0 -z-10"
            style={{ background: "linear-gradient(155deg, #0d0d0d 0%, #2a1010 45%, #DD2222 100%)" }}
          />
          <div
            aria-hidden
            className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-[#F7C948]/40 blur-3xl"
          />
        </>
      )}

      {tier.featured && (
        <div className="absolute right-5 top-5 rounded-full bg-[#F7C948] px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-[#1a1a1a]">
          {tier.tag} · <FA>{tier.tagFa}</FA>
        </div>
      )}

      <div className="flex items-center gap-3">
        <div
          className={`grid h-11 w-11 place-items-center rounded-2xl text-white shadow-lg`}
          style={{
            background: tier.featured
              ? "rgba(255,255,255,.15)"
              : `linear-gradient(135deg, ${tier.c}, ${tier.c}bb)`,
          }}
        >
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="font-display text-xl font-black tracking-tight">{tier.name}</div>
          <FA
            className={`text-xs font-bold ${tier.featured ? "text-white/80" : "text-muted-foreground"}`}
          >
            {tier.nameFa}
          </FA>
        </div>
      </div>

      <div className="mt-6 flex items-baseline gap-1">
        <span className="font-display text-6xl font-black tracking-tight">
          {price === 0 ? "0" : price}
        </span>
        <span
          className={`font-display text-2xl font-black ${tier.featured ? "text-white/80" : "text-muted-foreground"}`}
        >
          €
        </span>
        <span
          className={`ml-1 text-xs font-bold ${tier.featured ? "text-white/70" : "text-muted-foreground"}`}
        >
          / {yearly ? "Jahr" : "Monat"} · <FA>{yearly ? "سال" : "ماه"}</FA>
        </span>
      </div>
      {yearly && tier.m > 0 && (
        <div
          className={`mt-1 text-xs ${tier.featured ? "text-white/60" : "text-muted-foreground/80"}`}
        >
          entspricht {(tier.y / 12).toFixed(2)}€/Monat · <FA>معادل ماهانه</FA>
        </div>
      )}

      <ul className="mt-6 space-y-2.5">
        {tier.features.map((f: [string, string], k: number) => (
          <motion.li
            key={f[0]}
            initial={{ opacity: 0, x: -10 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.05 * k + index * 0.1, duration: 0.4 }}
            className="flex items-start gap-2.5 text-sm"
          >
            <span
              className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] font-bold ${
                tier.featured ? "bg-white text-[#DD2222]" : "text-white"
              }`}
              style={tier.featured ? undefined : { background: tier.c }}
            >
              <Check className="h-3 w-3" strokeWidth={3} />
            </span>
            <span className="min-w-0">
              <span>{f[0]}</span>
              <FA className={`ml-2 ${tier.featured ? "text-white/70" : "text-muted-foreground"}`}>
                · {f[1]}
              </FA>
            </span>
          </motion.li>
        ))}
      </ul>

      <Link
        to="/register"
        className={`mt-8 inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition ${
          tier.featured
            ? "bg-white text-[#1a1a1a] hover:scale-[1.02] shadow-xl"
            : "border border-border bg-secondary text-foreground hover:bg-foreground hover:text-background"
        }`}
      >
        {tier.cta}{" "}
        <FA className={`text-[11px] ${tier.featured ? "text-[#1a1a1a]/70" : "opacity-70"}`}>
          · {tier.ctaFa}
        </FA>
        <ArrowRight className="h-4 w-4" />
      </Link>

      {tier.featured && (
        <div className="mt-4 flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest text-white/70">
          <InfinityIcon className="h-3 w-3" /> 14 Tage Geld-zurück · <FA>۱۴ روز ضمانت</FA>
        </div>
      )}
    </motion.div>
  );
}
