import { useRef } from "react";
import { motion, useMotionValue, useInView, animate, useMotionTemplate } from "framer-motion";
import {
  ArrowRight,
  BookOpen,
  Brain,
  Layers,
  Headphones,
  GraduationCap,
  BarChart3,
  MessageSquare,
  ShieldCheck,
  Music,
  Film,
  Network,
  PenLine,
  Users,
  CalendarDays,
  Trophy,
  Library,
} from "lucide-react";
import { EASE, FA } from "./data";
import { SectionHeader } from "./SectionHeader";

export const FEATURES = [
  {
    icon: Layers,
    title: "Dynamische Karten",
    fa: "کارت‌های هوشمند",
    desc: "Jede Karte passt sich der Wortart an — Nomen mit Artikel, Verben mit Konjugation, Adjektive mit Steigerung.",
    descFa: "هر کارت با نوع کلمه تغییر می‌کند: اسم با حرف تعریف، فعل با صرف، صفت با درجه‌ها.",
    color: "#DD2222",
    tag: "Karten",
  },
  {
    icon: Brain,
    title: "FSRS 5 + Leitner",
    fa: "الگوریتم مرور",
    desc: "Zwei bewährte Systeme, ein Ritual. Wiederhole genau dann, wenn dein Gehirn es braucht.",
    descFa: "دو سیستم اثبات‌شده، یک آیین. درست وقتی مرور کن که مغزت نیاز دارد.",
    color: "#F7C948",
    tag: "Algorithmus",
  },
  {
    icon: BookOpen,
    title: "Grammatik-Pfade",
    fa: "مسیر گرامر",
    desc: "Von Artikeln bis Konjunktiv II — geführte Lektionen mit Beispielen und Mini-Übungen.",
    descFa: "از حرف تعریف تا کنیونکتیو ۲ — درس‌های گام‌به‌گام با مثال و تمرین.",
    color: "#2563eb",
    tag: "Grammatik",
  },
  {
    icon: MessageSquare,
    title: "KI-Coach",
    fa: "کوچ هوش مصنوعی",
    desc: "Dialog auf deinem Niveau. Frage nach Erklärungen, übe Konversation, bekomme Korrekturen.",
    descFa: "گفت‌وگو در سطح خودت. توضیح بخواه، مکالمه تمرین کن، اصلاح بگیر.",
    color: "#8B5CF6",
    tag: "KI",
  },
  {
    icon: Headphones,
    title: "Podcasts & Lesen",
    fa: "پادکست و خواندن",
    desc: "Authentische Texte und Hörbeiträge, gefiltert nach A1 bis C2 — mit Wörterbuch-Tap.",
    descFa: "متن‌ها و پادکست‌های واقعی، از A1 تا C2 — با لمس روی هر کلمه.",
    color: "#22C55E",
    tag: "Immersion",
  },
  {
    icon: GraduationCap,
    title: "Prüfungen üben",
    fa: "آمادگی آزمون",
    desc: "Original-nahe Aufgaben für Goethe, telc und ÖSD mit sofortiger Auswertung.",
    descFa: "سوال‌های نزدیک به اصل گوته، telc و ÖSD با ارزیابی فوری.",
    color: "#EF4444",
    tag: "Prüfung",
  },
  {
    icon: BarChart3,
    title: "Statistiken",
    fa: "آمار رشد",
    desc: "Heatmap, Wortarten-Fortschritt, Serien und Retention — sieh, wie du wächst.",
    descFa: "هیت‌مپ، پیشرفت اجزای کلام، سری‌ها و ماندگاری — رشدت را ببین.",
    color: "#0EA5E9",
    tag: "Analyse",
  },
  {
    icon: ShieldCheck,
    title: "100% offline",
    fa: "کاملاً آفلاین",
    desc: "Alle Daten leben in deinem Browser. Kein Konto-Zwang, kein Tracking, kein Umweg.",
    descFa: "همه چیز در مرورگر خودت. بدون حساب اجباری، بدون ردیابی.",
    color: "#1a1a1a",
    tag: "Privatsphäre",
  },
  {
    icon: Music,
    title: "Musik & Karaoke",
    fa: "موزیک و کارائوکه",
    desc: "Deutsche Songs Zeile für Zeile mitlesen, Vokabeln direkt aus dem Text sammeln.",
    descFa: "آهنگ‌های آلمانی را خط‌به‌خط بخوان و واژه‌ها را از دل متن ذخیره کن.",
    color: "#DB2777",
    tag: "Neu",
  },
  {
    icon: Film,
    title: "Kino & Serien",
    fa: "سینما و سریال",
    desc: "Szenen mit Untertiteln, Redewendungen und Wortschatz aus echten Filmen.",
    descFa: "صحنه‌ها با زیرنویس، اصطلاح‌ها و واژگان از فیلم‌های واقعی.",
    color: "#7C3AED",
    tag: "Neu",
  },
  {
    icon: Network,
    title: "Wortfamilien",
    fa: "خانواده واژه‌ها",
    desc: "Ein Wortstamm, seine ganze Familie — Präfixe, Suffixe und Wortbildung visuell.",
    descFa: "یک ریشه و همه‌ی هم‌خانواده‌هایش — پیشوند، پسوند و ساخت واژه به‌صورت تصویری.",
    color: "#0D9488",
    tag: "Neu",
  },
  {
    icon: PenLine,
    title: "Schreibtrainer",
    fa: "تمرین نوشتن",
    desc: "Briefe und Aufsätze schreiben, mit KI-Feedback zu Grammatik, Stil und Struktur.",
    descFa: "نامه و انشا بنویس و بازخورد هوش مصنوعی درباره‌ی گرامر، سبک و ساختار بگیر.",
    color: "#EA580C",
    tag: "Neu",
  },
  {
    icon: Users,
    title: "Community & Tandem",
    fa: "جامعه و همتا",
    desc: "Chats, Lerngruppen und Tandem-Partner — Deutsch üben mit echten Menschen.",
    descFa: "گفت‌وگو، گروه‌های یادگیری و شریک زبانی همتا — تمرین آلمانی با آدم‌های واقعی.",
    color: "#2563EB",
    tag: "Neu",
  },
  {
    icon: CalendarDays,
    title: "Events & Stammtisch",
    fa: "رویدادها",
    desc: "Sprach-Events online und vor Ort finden, Platz reservieren und teilnehmen.",
    descFa: "رویدادهای زبانی آنلاین و حضوری را پیدا کن، جا رزرو کن و شرکت کن.",
    color: "#16A34A",
    tag: "Neu",
  },
  {
    icon: Trophy,
    title: "Erfolge & Serien",
    fa: "دستاوردها",
    desc: "Missionen, Medaillen, Season-Ziele und Leaderboard — Motivation, die bleibt.",
    descFa: "ماموریت‌ها، مدال‌ها، اهداف فصلی و جدول رتبه‌بندی — انگیزه‌ای که می‌ماند.",
    color: "#F59E0B",
    tag: "Neu",
  },
  {
    icon: Library,
    title: "Bücher & Sprichwörter",
    fa: "کتاب‌ها و ضرب‌المثل‌ها",
    desc: "Kuratierte Wortschatz-Bücher, eigene Wortlisten und deutsche Redewendungen.",
    descFa: "کتاب‌های واژگان، فهرست‌های شخصی و ضرب‌المثل‌های آلمانی.",
    color: "#0EA5E9",
    tag: "Neu",
  },
];

export function Features() {
  return (
    <section
      id="features"
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="Was DEUSI kann"
        kickerFa="دئوسی چه می‌کند"
        title={
          <>
            Alles, was du für Deutsch brauchst.
            <br />
            <span style={{ color: "var(--flag-red)" }}>An einem Ort.</span>
          </>
        }
        titleFa={
          <>
            هر چیزی که برای آلمانی نیاز داری —{" "}
            <span style={{ color: "var(--flag-red)" }}>یکجا.</span>
          </>
        }
        subtitle="Ein Werkzeugkasten, der mitwächst — vom ersten Artikel bis zum Konjunktiv II."
        subtitleFa="جعبه‌ابزاری که با تو رشد می‌کند — از اولین حرف تعریف تا کنیونکتیو ۲."
      />

      <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map((f, i) => (
          <FeatureCard key={f.title} {...f} index={i} />
        ))}
      </div>
    </section>
  );
}

export function FeatureCard({
  icon: Icon,
  title,
  fa,
  desc,
  descFa,
  color,
  tag,
  index,
}: (typeof FEATURES)[number] & { index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const mx = useMotionValue(0),
    my = useMotionValue(0);
  const spotlight = useMotionTemplate`radial-gradient(280px circle at ${mx}px ${my}px, ${color}22, transparent 70%)`;

  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set(e.clientX - r.left);
    my.set(e.clientY - r.top);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, ease: EASE, delay: (index % 4) * 0.08 }}
      whileHover={{ y: -6 }}
      className="group relative overflow-hidden rounded-3xl border border-border bg-card p-6 transition-shadow hover:shadow-2xl"
    >
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -inset-px rounded-3xl opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{ background: spotlight }}
      />
      <div
        aria-hidden
        className="absolute -right-8 -top-8 h-28 w-28 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-70"
        style={{ background: color }}
      />

      <div className="relative">
        <div className="flex items-start justify-between">
          <motion.div
            whileHover={{ rotate: -6, scale: 1.05 }}
            transition={{ type: "spring", stiffness: 250, damping: 15 }}
            className="grid h-12 w-12 place-items-center rounded-2xl text-white shadow-lg"
            style={{
              background: `linear-gradient(135deg, ${color}, ${color}cc)`,
              boxShadow: `0 15px 30px -12px ${color}80`,
            }}
          >
            <Icon className="h-5 w-5" />
          </motion.div>
          <span className="rounded-full border border-border px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
            {tag}
          </span>
        </div>
        <h3 className="mt-5 font-display text-lg font-black tracking-tight">{title}</h3>
        <div dir="rtl" className="fa-inline mt-0.5 text-sm font-bold" style={{ color }}>
          {fa}
        </div>
        <p className="mt-3 text-sm text-muted-foreground">{desc}</p>
        <p dir="rtl" className="fa-inline mt-2 text-sm text-muted-foreground/85">
          {descFa}
        </p>
        <div className="mt-5 flex items-center gap-1.5 text-xs font-bold" style={{ color }}>
          Mehr <FA className="opacity-80">· بیشتر</FA>
          <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
        </div>
      </div>
    </motion.div>
  );
}
