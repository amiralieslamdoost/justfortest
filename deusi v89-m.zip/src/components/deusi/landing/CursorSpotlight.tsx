import { useEffect } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useIsMobile } from "@/hooks/use-mobile";

/* ---------- CURSOR SPOTLIGHT ---------- */
export function CursorSpotlight() {
  const isMobile = useIsMobile();
  const x = useMotionValue(-500);
  const y = useMotionValue(-500);
  const sx = useSpring(x, { stiffness: 160, damping: 22, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 160, damping: 22, mass: 0.4 });
  useEffect(() => {
    if (isMobile) return;
    const onMove = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };
    const onLeave = () => {
      x.set(-500);
      y.set(-500);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseleave", onLeave);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseleave", onLeave);
    };
  }, [x, y, isMobile]);
  if (isMobile) return null;
  return (
    <motion.div aria-hidden className="cursor-spot hidden md:block" style={{ left: sx, top: sy }} />
  );
}
