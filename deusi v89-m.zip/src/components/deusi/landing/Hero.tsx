import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion, useMotionValue, useScroll, useSpring, useTransform } from "framer-motion";
import { ArrowRight, Sparkles, Play, Zap, Globe, ShieldCheck } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { EASE, FA } from "./data";

/* ---------- HERO ---------- */
export function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const sx = useSpring(mx, { stiffness: 60, damping: 20 });
  const sy = useSpring(my, { stiffness: 60, damping: 20 });
  const rx = useTransform(sy, [0, 1], [10, -10]);
  const ry = useTransform(sx, [0, 1], [-14, 14]);
  const px1 = useTransform(sx, [0, 1], [-20, 20]);
  const py1 = useTransform(sy, [0, 1], [-14, 14]);
  const px1Neg = useTransform(px1, (v: number) => -v);
  const py1Neg = useTransform(py1, (v: number) => -v);

  // Scroll parallax on hero content — desktop only. On mobile the cards live
  // below the copy and would get faded/blurred out of view before the user
  // ever scrolled to them.
  const { scrollY } = useScroll();
  const [isDesktop, setIsDesktop] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(min-width: 1024px)");
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  const heroYRaw = useTransform(scrollY, [0, 600], [0, 120]);
  const heroOpacityRaw = useTransform(scrollY, [0, 500], [1, 0.15]);
  const heroY = useTransform(heroYRaw, (v: number) => (isDesktop ? v : 0));
  const heroOpacity = useTransform(heroOpacityRaw, (v: number) => (isDesktop ? v : 1));

  const isMobile = useIsMobile();
  const onMove = (e: React.MouseEvent) => {
    if (isMobile) return;
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set((e.clientX - r.left) / r.width);
    my.set((e.clientY - r.top) / r.height);
  };

  const words = ["Deutsch.", "Einfach.", "Meistern."];
  const wordsFa = ["آلمانی.", "ساده.", "مسلط."];

  return (
    <section
      ref={ref}
      onMouseMove={onMove}
      className="relative min-h-[100svh] overflow-hidden pt-28 sm:pt-32"
    >
      {/* Cinematic backdrop */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <motion.div
          style={{
            x: px1,
            y: py1,
            background: "radial-gradient(circle, rgba(221,34,34,0.55), transparent 60%)",
          }}
          className="absolute -top-32 -left-32 h-[560px] w-[560px] rounded-full blur-3xl"
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.7 }}
          transition={{ duration: 1.4, ease: EASE }}
        />
        <motion.div
          style={{
            x: px1Neg,
            y: py1Neg,
            background: "radial-gradient(circle, rgba(247,201,72,0.55), transparent 60%)",
          }}
          className="absolute -bottom-40 -right-24 h-[560px] w-[560px] rounded-full blur-3xl"
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.7 }}
          transition={{ duration: 1.4, ease: EASE, delay: 0.15 }}
        />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: "radial-gradient(rgba(20,22,26,0.07) 1px, transparent 1px)",
            backgroundSize: "24px 24px",
            maskImage: "radial-gradient(ellipse at center, black 40%, transparent 75%)",
          }}
        />
      </div>

      <motion.div
        style={{ y: heroY, opacity: heroOpacity }}
        className="mx-auto grid max-w-[1500px] items-center gap-10 px-5 pb-16 sm:px-8 lg:grid-cols-[1.1fr_1fr] lg:gap-16 lg:px-16"
      >
        {/* LEFT */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: EASE }}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-semibold backdrop-blur"
          >
            <span
              className="grid h-4 w-4 place-items-center rounded-full"
              style={{ background: "var(--flag-red)" }}
            >
              <Sparkles className="h-2.5 w-2.5 text-white" />
            </span>
            Neu · FSRS 5 & KI-Coach{" "}
            <span className="hidden sm:inline text-muted-foreground">·</span>
            <FA className="hidden sm:inline text-muted-foreground">جدید · مربی هوش مصنوعی</FA>
          </motion.div>

          <h1 className="mt-5 font-display text-5xl font-black leading-[0.95] tracking-tight sm:text-6xl md:text-7xl">
            {words.map((w, i) => (
              <span key={w} className="block overflow-hidden">
                <motion.span
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.9, ease: EASE, delay: 0.1 + i * 0.12 }}
                  className="block"
                  style={
                    i === 1
                      ? { color: "var(--flag-red)" }
                      : i === 2
                        ? { color: "#F7C948", WebkitTextStroke: "1px rgba(20,22,26,0.15)" }
                        : undefined
                  }
                >
                  {w}
                </motion.span>
              </span>
            ))}
          </h1>

          {/* Farsi mirror headline */}
          <div className="mt-3 overflow-hidden">
            <motion.h2
              dir="rtl"
              initial={{ y: "110%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.9, ease: EASE, delay: 0.55 }}
              className="fa-inline font-black leading-tight text-2xl sm:text-3xl md:text-4xl text-muted-foreground"
            >
              {wordsFa[0]} <span style={{ color: "var(--flag-red)" }}>{wordsFa[1]}</span>{" "}
              <span style={{ color: "#B8912A" }}>{wordsFa[2]}</span>
            </motion.h2>
          </div>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE, delay: 0.7 }}
            className="mt-5 max-w-xl text-base text-muted-foreground sm:text-lg"
          >
            DEUSI vereint Leitner, FSRS 5, dynamische Karten pro Wortart, Grammatik, Lesen, Podcasts
            und einen KI-Coach — zu einem Lernritual, das wirklich hängen bleibt.
          </motion.p>
          <motion.p
            dir="rtl"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE, delay: 0.8 }}
            className="fa-inline mt-3 max-w-xl text-sm text-muted-foreground/90 sm:text-base"
          >
            دئوسی، لایتنر و اف‌اس‌آر‌اس ۵ را کنار کارت‌های هوشمند، گرامر، خواندن، پادکست و یک مربی
            هوش مصنوعی می‌گذارد — یک آیین ساده که واقعاً می‌ماند.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: EASE, delay: 0.9 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <Link
              to="/register"
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-2xl px-6 py-3.5 text-sm font-bold text-white shadow-xl transition"
              style={{
                background: "linear-gradient(135deg, #1a1a1a 0%, #B01818 55%, #DD2222 100%)",
                boxShadow: "0 25px 45px -20px rgba(221,34,34,0.7)",
              }}
            >
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              <span className="relative">Kostenlos starten</span>
              <FA className="relative text-white/90 text-[11px]">· رایگان شروع کن</FA>
              <ArrowRight className="relative h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/login"
              className="group inline-flex items-center gap-2 rounded-2xl border border-border bg-card/70 px-5 py-3.5 text-sm font-semibold backdrop-blur transition hover:bg-secondary"
            >
              <Play className="h-4 w-4 transition-transform group-hover:scale-110" />
              Demo ansehen
              <FA className="text-[11px] text-muted-foreground">· دموی زنده</FA>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.05, duration: 0.7 }}
            className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 text-xs text-muted-foreground"
          >
            <Badge icon={<ShieldCheck className="h-3.5 w-3.5" />}>
              100% offline <FA>· دیتات پیش خودت</FA>
            </Badge>
            <Badge icon={<Globe className="h-3.5 w-3.5" />}>A1 – C2</Badge>
            <Badge icon={<Zap className="h-3.5 w-3.5" />}>
              Keine Anmeldegebühr <FA>· بدون هزینه</FA>
            </Badge>
          </motion.div>
        </div>

        {/* RIGHT — 3D stack of cards */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85, rotateY: 15 }}
          animate={{ opacity: 1, scale: 1, rotateY: 0 }}
          transition={{ duration: 1, ease: EASE, delay: 0.3 }}
          style={{ perspective: 1400 }}
          className="relative mx-auto h-[420px] w-full max-w-md scale-[0.78] sm:h-[480px] sm:max-w-lg sm:scale-100"
        >
          <motion.div
            style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d" }}
            className="relative h-full w-full"
          >
            <FloatingCard
              depth={-60}
              rotate={-10}
              offsetX={-70}
              offsetY={-30}
              delay={0}
              tint="der"
              word="der Mann"
              fa="مرد"
              pos="Nomen · maskulin"
              plural="die Männer"
            />
            <FloatingCard
              depth={20}
              rotate={4}
              offsetX={0}
              offsetY={0}
              delay={0.15}
              tint="das"
              word="das Leben"
              fa="زندگی"
              pos="Nomen · neutrum"
              plural="die Leben"
              front
            />
            <FloatingCard
              depth={80}
              rotate={12}
              offsetX={70}
              offsetY={40}
              delay={0.3}
              tint="die"
              word="die Freiheit"
              fa="آزادی"
              pos="Nomen · feminin"
              plural="die Freiheiten"
            />
          </motion.div>

          {/* orbiting chips */}
          {[
            { t: "Leitner", top: "-6%", left: "-10%", color: "#DD2222" },
            { t: "FSRS 5", top: "12%", right: "-14%", color: "#F7C948" },
            { t: "KI-Coach", bottom: "10%", left: "-14%", color: "#1a1a1a" },
            { t: "Offline", bottom: "-4%", right: "-8%", color: "#2563eb" },
          ].map((c, i) => (
            <motion.div
              key={c.t}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 + i * 0.12, duration: 0.6, ease: EASE }}
              className="absolute z-20 flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold shadow-lg backdrop-blur"
              style={{ top: c.top, left: c.left, right: c.right, bottom: c.bottom, color: c.color }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: c.color }} />
              {c.t}
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.6 }}
        className="pointer-events-none absolute inset-x-0 bottom-6 flex justify-center"
      >
        <div className="flex flex-col items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          <span>
            Scroll · <FA>پایین بیا</FA>
          </span>
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
            className="h-8 w-[2px] rounded-full"
            style={{ background: "linear-gradient(180deg, transparent, var(--flag-red))" }}
          />
        </div>
      </motion.div>
    </section>
  );
}

export function Badge({ children, icon }: { children: React.ReactNode; icon: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/60 px-2.5 py-1 backdrop-blur">
      <span className="text-[var(--flag-red)]">{icon}</span> {children}
    </span>
  );
}

export function FloatingCard({
  depth,
  rotate,
  delay,
  word,
  fa,
  pos,
  plural,
  tint,
  front,
  offsetX = 0,
  offsetY = 0,
}: {
  depth: number;
  rotate: number;
  delay: number;
  word: string;
  fa: string;
  pos: string;
  plural: string;
  tint: "der" | "die" | "das";
  front?: boolean;
  offsetX?: number;
  offsetY?: number;
}) {
  const bg = tint === "der" ? "#2563eb" : tint === "die" ? "#DD2222" : "#22C55E";
  return (
    <div
      className="absolute inset-0 mx-auto"
      style={{
        transform: `translate3d(${offsetX}px, ${offsetY}px, ${depth}px) rotate(${rotate}deg)`,
      }}
    >
      <motion.div
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 6 + delay * 2, repeat: Infinity, ease: "easeInOut", delay }}
        className="h-full w-full"
      >
        <div
          className="card-glass relative flex h-full flex-col justify-between p-6 sm:p-8"
          style={{
            background: "#ffffff",
            boxShadow: front
              ? "0 40px 90px -25px rgba(20,22,26,0.35), inset 0 1px 0 rgba(255,255,255,1)"
              : "0 25px 55px -20px rgba(20,22,26,0.22), inset 0 1px 0 rgba(255,255,255,1)",
            border: "1px solid rgba(20,22,26,0.08)",
          }}
        >
          <div>
            <div
              className="inline-flex items-center gap-2 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white"
              style={{ background: bg }}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-white" /> {tint}
            </div>
            <div className="mt-4 font-display text-3xl font-black tracking-tight sm:text-4xl">
              {word}
            </div>
            <div className="mt-1.5 text-sm text-muted-foreground">{pos}</div>
            <div dir="rtl" className="fa-inline mt-2 text-lg font-bold" style={{ color: bg }}>
              {fa}
            </div>
          </div>
          <div className="mt-6 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                Plural
              </div>
              <div className="text-sm font-semibold">{plural}</div>
            </div>
            <div className="flex gap-1.5">
              {["#EF4444", "#F59E0B", "#3B82F6", "#22C55E"].map((c) => (
                <div
                  key={c}
                  className="h-2 w-6 rounded-full"
                  style={{ background: c, opacity: 0.85 }}
                />
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
