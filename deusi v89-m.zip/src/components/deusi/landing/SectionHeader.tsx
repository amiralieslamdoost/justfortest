import { motion } from "framer-motion";
import { EASE, FA } from "./data";

export function SectionHeader({
  kicker,
  kickerFa,
  title,
  titleFa,
  subtitle,
  subtitleFa,
  align = "center",
}: {
  kicker: string;
  kickerFa?: string;
  title: React.ReactNode;
  titleFa?: React.ReactNode;
  subtitle?: string;
  subtitleFa?: string;
  align?: "center" | "left";
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, ease: EASE }}
      className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-xl"}
    >
      <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-muted-foreground backdrop-blur">
        <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--flag-red)" }} />
        {kicker}
        {kickerFa && (
          <>
            <span className="opacity-50">·</span>
            <FA className="tracking-normal">{kickerFa}</FA>
          </>
        )}
      </div>
      <h2 className="mt-4 font-display text-4xl font-black leading-[1.05] tracking-tight sm:text-5xl">
        {title}
      </h2>
      {titleFa && (
        <div
          dir="rtl"
          className={`fa-inline mt-3 text-2xl font-black leading-tight text-muted-foreground sm:text-3xl ${align === "left" ? "text-right" : ""}`}
        >
          {titleFa}
        </div>
      )}
      {subtitle && <p className="mt-4 text-base text-muted-foreground">{subtitle}</p>}
      {subtitleFa && (
        <p
          dir="rtl"
          className={`fa-inline mt-2 text-base text-muted-foreground/85 ${align === "left" ? "text-right" : ""}`}
        >
          {subtitleFa}
        </p>
      )}
    </motion.div>
  );
}
