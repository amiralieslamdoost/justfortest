import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { EASE, FA } from "./data";
import { SectionHeader } from "./SectionHeader";

export function Testimonials() {
  const items = [
    {
      name: "Lena K.",
      role: "B2 Vorbereitung",
      roleFa: "آمادگی B2",
      text: "Nach zwei Monaten DEUSI habe ich meine telc B2 mit 89% bestanden. Der FSRS-Rhythmus macht den Unterschied.",
      textFa: "بعد از دو ماه دئوسی، telc B2 را با ۸۹٪ قبول شدم. ریتم FSRS همه‌چیز را عوض می‌کند.",
      init: "L",
      c: "#DD2222",
    },
    {
      name: "Ahmad R.",
      role: "Neu in Berlin",
      roleFa: "تازه‌وارد برلین",
      text: "Endlich eine App, die der/die/das nicht als Nebensache behandelt. Die Farbcodes bleiben einfach hängen.",
      textFa: "بالاخره اپی که der/die/das را فرعی نگرفت. کد رنگی‌اش تو ذهن می‌ماند.",
      init: "A",
      c: "#F7C948",
    },
    {
      name: "Marta S.",
      role: "C1 Prüfungsvorbereitung",
      roleFa: "آمادگی C1",
      text: "Die Prüfungssimulationen sind erstaunlich nah am Original. Und der KI-Coach erklärt geduldig.",
      textFa: "شبیه‌ساز آزمون‌ها فوق‌العاده نزدیک به اصل است. مربی هوشمندش هم با صبر توضیح می‌دهد.",
      init: "M",
      c: "#2563eb",
    },
  ];
  return (
    <section
      id="testimonials"
      className="mx-auto max-w-[1400px] px-5 lg:px-12 py-24 sm:px-8 sm:py-32"
    >
      <SectionHeader
        kicker="Stimmen von Lernenden"
        kickerFa="صدای یادگیرنده‌ها"
        title={
          <>
            Von Menschen,
            <br />
            <span style={{ color: "var(--flag-red)" }}>die es geschafft haben.</span>
          </>
        }
        titleFa={
          <>
            از کسانی که <span style={{ color: "var(--flag-red)" }}>موفق شدند.</span>
          </>
        }
      />
      <div className="mt-14 grid gap-5 md:grid-cols-3">
        {items.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.6, ease: EASE }}
            whileHover={{ y: -6 }}
            className="relative rounded-3xl border border-border bg-card p-6 transition-shadow hover:shadow-2xl"
          >
            <div className="mb-3 flex gap-0.5" style={{ color: "#F7C948" }}>
              {Array.from({ length: 5 }).map((_, k) => (
                <Star key={k} className="h-4 w-4 fill-current" />
              ))}
            </div>
            <p className="text-sm leading-relaxed text-foreground">„{t.text}"</p>
            <p dir="rtl" className="fa-inline mt-2 text-sm leading-relaxed text-muted-foreground">
              «{t.textFa}»
            </p>
            <div className="mt-6 flex items-center gap-3 border-t border-border pt-4">
              <div
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full font-display text-sm font-black text-white"
                style={{ background: t.c }}
              >
                {t.init}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-bold">{t.name}</div>
                <div className="text-xs text-muted-foreground">
                  {t.role} <FA>· {t.roleFa}</FA>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
