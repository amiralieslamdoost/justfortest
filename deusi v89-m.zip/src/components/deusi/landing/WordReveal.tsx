import { useRef } from "react";
import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { FA } from "./data";

export function WordReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const rotate = useTransform(scrollYProgress, [0, 1], [-6, 6]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.85, 1.05, 0.85]);

  const pairs: Array<[string, string, string]> = [
    ["der Anfang", "آغاز", "#2563eb"],
    ["die Reise", "سفر", "#DD2222"],
    ["das Ziel", "هدف", "#22C55E"],
    ["der Rhythmus", "ریتم", "#8B5CF6"],
    ["die Freude", "شادی", "#22C55E"],
    ["das Wort", "کلمه", "#EF4444"],
  ];

  return (
    <section
      ref={ref}
      className="relative mx-auto max-w-[1400px] px-5 lg:px-12 py-16 sm:px-8 sm:py-24"
    >
      <div className="mb-10 flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-[0.4em] text-muted-foreground">
        <span className="h-px w-8 bg-border" />
        Wörter · <FA className="tracking-normal">کلمه‌ها</FA>
        <span className="h-px w-8 bg-border" />
      </div>
      <motion.div style={{ rotate, scale }} className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {pairs.map(([de, fa, c], i) => (
          <WordRevealCard
            key={de}
            de={de}
            fa={fa}
            color={c}
            index={i}
            total={pairs.length}
            progress={scrollYProgress}
          />
        ))}
      </motion.div>
    </section>
  );
}

export function WordRevealCard({
  de,
  fa,
  color,
  index,
  total,
  progress,
}: {
  de: string;
  fa: string;
  color: string;
  index: number;
  total: number;
  progress: MotionValue<number>;
}) {
  const p = (index + 1) / (total + 1);
  const dir = index % 2 === 0 ? 1 : -1;
  const y = useTransform(progress, [0, 1], [80 * dir, -80 * dir]);
  const op = useTransform(
    progress,
    [Math.max(0, p - 0.35), p, Math.min(1, p + 0.35)],
    [0.2, 1, 0.2],
  );
  return (
    <motion.div
      style={{ y, opacity: op }}
      whileHover={{ scale: 1.04, y: 0 }}
      className="group relative overflow-hidden rounded-3xl border border-border bg-card p-5 sm:p-6"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-30 blur-3xl transition-opacity duration-500 group-hover:opacity-70"
        style={{ background: color }}
      />
      <div className="relative">
        <div className="font-display text-2xl font-black tracking-tight sm:text-3xl">{de}</div>
        <div dir="rtl" className="fa-inline mt-1 text-xl font-black" style={{ color }}>
          {fa}
        </div>
        <div className="mt-3 flex gap-1">
          {[0, 1, 2, 3].map((k) => (
            <span
              key={k}
              className="h-1 flex-1 rounded-full"
              style={{ background: color, opacity: 0.15 + k * 0.2 }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}
