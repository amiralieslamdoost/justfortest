import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import type { GrammarTopic } from "@/lib/deusi/mockGrammar";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";

export function GrammarCard({ topic, index = 0 }: { topic: GrammarTopic; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.4, delay: index * 0.03 }}
      whileHover={{ y: -4 }}
      className="relative"
    >
      <Link
        to="/grammatik/$topicId"
        params={{ topicId: topic.id }}
        className="glass group relative flex h-full flex-col gap-3 overflow-hidden rounded-3xl p-5 transition-shadow hover:shadow-xl"
      >
        <div
          className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-40 blur-3xl transition-opacity group-hover:opacity-70"
          style={{ background: topic.accent }}
        />
        <div className="flex items-start justify-between gap-3">
          <div
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-2xl shadow-inner"
            style={{ background: `${topic.accent}22`, color: topic.accent }}
          >
            {topic.emoji}
          </div>
          <div className="flex items-center gap-1">
            <span
              className="rounded-full px-2.5 py-1 text-[11px] font-semibold"
              style={{ background: `${topic.accent}22`, color: topic.accent }}
            >
              {topic.difficulty}
            </span>
            <BookmarkButton
              type="grammar"
              id={topic.id}
              title={topic.name}
              sub={topic.subtitle}
              level={topic.difficulty}
              to={`/grammatik/${topic.id}`}
            />
          </div>
        </div>
        <div className="min-w-0">
          <h3 className="truncate text-lg font-bold text-foreground">{topic.name}</h3>
          <p className="line-clamp-2 text-sm text-muted-foreground">{topic.subtitle}</p>
        </div>
        <div className="mt-auto space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>⏱ {topic.duration} Min</span>
            <span className="font-semibold text-foreground">{topic.completion}%</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <motion.div
              initial={{ width: 0 }}
              whileInView={{ width: `${topic.completion}%` }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="h-full rounded-full"
              style={{ background: topic.accent }}
            />
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
