import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import type { Exercise } from "@/lib/deusi/mockGrammar";

export function ExerciseBlock({
  exercise,
  accent = "#7c5cff",
  onResult,
}: {
  exercise: Exercise;
  accent?: string;
  onResult?: (correct: boolean, value: string | string[]) => void;
}) {
  const [answer, setAnswer] = useState<string | string[]>(
    exercise.type === "build-sentence" || exercise.type === "rearrange" ? [] : "",
  );
  const [checked, setChecked] = useState<null | "right" | "wrong">(null);

  function check() {
    const expected = exercise.data.answer;
    const isRight = Array.isArray(expected)
      ? Array.isArray(answer) && expected.join("|") === (answer as string[]).join("|")
      : answer === expected;
    setChecked(isRight ? "right" : "wrong");
    onResult?.(isRight, answer);
  }
  function reset() {
    setChecked(null);
    setAnswer(exercise.type === "build-sentence" || exercise.type === "rearrange" ? [] : "");
  }

  return (
    <div className="glass rounded-3xl p-5">
      <p className="mb-4 text-sm font-semibold text-foreground">{exercise.prompt}</p>
      {(exercise.type === "multiple-choice" || exercise.type === "select") && (
        <MultipleChoice
          options={exercise.data.options ?? []}
          answer={answer as string}
          setAnswer={setAnswer}
          accent={accent}
          disabled={checked === "right"}
        />
      )}
      {(exercise.type === "build-sentence" || exercise.type === "rearrange") && (
        <BuildSentence
          tokens={exercise.data.tokens ?? []}
          answer={answer as string[]}
          setAnswer={setAnswer}
          accent={accent}
        />
      )}
      {exercise.type === "fill-blank" && (
        <FillBlank
          prompt={exercise.prompt}
          answer={answer as string}
          setAnswer={setAnswer}
          accent={accent}
        />
      )}
      {exercise.type === "error-correction" && (
        <ErrorCorrection
          wrong={exercise.data.wrong ?? ""}
          answer={answer as string}
          setAnswer={setAnswer}
        />
      )}
      {exercise.type === "match" && <Match pairs={exercise.data.pairs ?? []} accent={accent} />}

      <div className="mt-4 flex items-center gap-2">
        <button
          onClick={check}
          className="rounded-full px-4 py-2 text-sm font-semibold text-white shadow-md transition-transform hover:scale-105"
          style={{ background: accent }}
        >
          Überprüfen
        </button>
        <button
          onClick={reset}
          className="rounded-full bg-muted px-4 py-2 text-sm font-semibold hover:bg-accent"
        >
          Zurücksetzen
        </button>
      </div>
      <AnimatePresence>
        {checked && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className={`mt-4 rounded-xl px-4 py-3 text-sm font-medium ${
              checked === "right"
                ? "bg-emerald-500/15 text-emerald-600"
                : "bg-rose-500/15 text-rose-600"
            }`}
          >
            {checked === "right"
              ? "✅ Richtig! Super gemacht."
              : "❌ Nicht ganz. Versuch es nochmal!"}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MultipleChoice({
  options,
  answer,
  setAnswer,
  accent,
  disabled,
}: {
  options: string[];
  answer: string;
  setAnswer: (v: string) => void;
  accent: string;
  disabled: boolean;
}) {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {options.map((opt) => {
        const active = answer === opt;
        return (
          <button
            key={opt}
            disabled={disabled}
            onClick={() => setAnswer(opt)}
            className={`rounded-2xl border-2 px-4 py-3 text-left text-sm font-medium transition-all ${
              active ? "shadow-lg" : "border-transparent bg-muted hover:bg-accent"
            }`}
            style={
              active ? { borderColor: accent, background: `${accent}18`, color: accent } : undefined
            }
          >
            {opt}
          </button>
        );
      })}
    </div>
  );
}

function BuildSentence({
  tokens,
  answer,
  setAnswer,
  accent,
}: {
  tokens: string[];
  answer: string[];
  setAnswer: (v: string[]) => void;
  accent: string;
}) {
  const remaining = tokens.filter((t) => !answer.includes(t));
  return (
    <div className="space-y-3">
      <div className="min-h-[52px] rounded-2xl border-2 border-dashed border-border/60 p-3">
        <div className="flex flex-wrap gap-2">
          {answer.length === 0 && (
            <span className="text-xs text-muted-foreground">
              Wähle Wörter unten, um den Satz zu bauen …
            </span>
          )}
          {answer.map((t, i) => (
            <motion.button
              layout
              key={t + i}
              onClick={() => setAnswer(answer.filter((_, j) => j !== i))}
              className="rounded-full px-3 py-1 text-sm font-semibold text-white shadow"
              style={{ background: accent }}
            >
              {t}
            </motion.button>
          ))}
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        {remaining.map((t) => (
          <motion.button
            layout
            key={t}
            onClick={() => setAnswer([...answer, t])}
            className="rounded-full bg-muted px-3 py-1 text-sm font-semibold hover:bg-accent"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {t}
          </motion.button>
        ))}
      </div>
    </div>
  );
}

function FillBlank({
  prompt,
  answer,
  setAnswer,
  accent,
}: {
  prompt: string;
  answer: string;
  setAnswer: (v: string) => void;
  accent: string;
}) {
  return (
    <input
      value={answer}
      onChange={(e) => setAnswer(e.target.value)}
      placeholder="Deine Antwort…"
      className="w-full rounded-2xl border-2 border-border/60 bg-background px-4 py-3 text-sm outline-none focus:border-transparent focus:ring-2"
      style={{ boxShadow: `0 0 0 0 ${accent}` }}
      aria-label={prompt}
    />
  );
}

function ErrorCorrection({
  wrong,
  answer,
  setAnswer,
}: {
  wrong: string;
  answer: string;
  setAnswer: (v: string) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="rounded-xl bg-rose-500/10 px-3 py-2 text-sm text-rose-600">
        Fehlerhaft: {wrong}
      </div>
      <input
        value={answer}
        onChange={(e) => setAnswer(e.target.value)}
        placeholder="Korrigiere den Satz…"
        className="w-full rounded-2xl border-2 border-border/60 bg-background px-4 py-3 text-sm"
      />
    </div>
  );
}

function Match({ pairs, accent }: { pairs: { left: string; right: string }[]; accent: string }) {
  const [left, setLeft] = useState<string | null>(null);
  const [matches, setMatches] = useState<Record<string, string>>({});
  const rights = useMemo(
    () => [...pairs].map((p) => p.right).sort(() => Math.random() - 0.5),
    [pairs],
  );
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div className="space-y-2">
        {pairs.map((p) => (
          <button
            key={p.left}
            onClick={() => setLeft(p.left)}
            className={`w-full rounded-xl px-3 py-2 text-left text-sm font-medium ${matches[p.left] ? "bg-emerald-500/15 text-emerald-700" : left === p.left ? "" : "bg-muted"}`}
            style={left === p.left ? { background: `${accent}22`, color: accent } : undefined}
          >
            {p.left} {matches[p.left] && <span className="text-xs">→ {matches[p.left]}</span>}
          </button>
        ))}
      </div>
      <div className="space-y-2">
        {rights.map((r) => (
          <button
            key={r}
            onClick={() => {
              if (left) setMatches({ ...matches, [left]: r });
              setLeft(null);
            }}
            className="w-full rounded-xl bg-muted px-3 py-2 text-left text-sm font-medium hover:bg-accent"
          >
            {r}
          </button>
        ))}
      </div>
    </div>
  );
}
