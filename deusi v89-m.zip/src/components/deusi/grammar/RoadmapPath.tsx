import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

/**
 * Vertical curved path drawn as SVG. Animates its dashoffset as the
 * container scrolls into view, giving a "journey progress" feel.
 */
export function RoadmapPath({ steps, accent }: { steps: number; accent: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const dashOffset = useTransform(scrollYProgress, [0, 1], [1, 0]);

  const H = 240 * steps;
  const path: string[] = [];
  for (let i = 0; i < steps; i++) {
    const y0 = i * 240 + 40;
    const y1 = y0 + 240;
    const x0 = i % 2 === 0 ? 60 : 40;
    const x1 = i % 2 === 0 ? 40 : 60;
    if (i === 0) path.push(`M ${x0} ${y0}`);
    path.push(`C ${x0} ${y0 + 120}, ${x1} ${y1 - 120}, ${x1} ${y1}`);
  }

  return (
    <div ref={ref} className="pointer-events-none absolute inset-0 hidden md:block">
      <svg
        className="absolute left-1/2 top-0 h-full -translate-x-1/2"
        width="100"
        height={H}
        viewBox={`0 0 100 ${H}`}
        fill="none"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="rm-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={accent} stopOpacity="0.9" />
            <stop offset="100%" stopColor={accent} stopOpacity="0.2" />
          </linearGradient>
        </defs>
        <path d={path.join(" ")} stroke={`${accent}22`} strokeWidth="3" strokeDasharray="6 8" />
        <motion.path
          d={path.join(" ")}
          stroke="url(#rm-grad)"
          strokeWidth="3"
          strokeLinecap="round"
          pathLength={1}
          strokeDasharray={1}
          style={{ strokeDashoffset: dashOffset }}
        />
      </svg>
    </div>
  );
}
