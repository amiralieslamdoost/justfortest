import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";

const TOOLS = [
  { id: "simple", label: "Einfach erklären", emoji: "💡" },
  { id: "persian", label: "Auf Persisch", emoji: "🇮🇷" },
  { id: "more", label: "Mehr Beispiele", emoji: "📚" },
  { id: "generate", label: "Neue Beispiele", emoji: "✨" },
  { id: "english", label: "Mit Englisch vergleichen", emoji: "🇬🇧" },
  { id: "prev", label: "Mit vorheriger Lektion", emoji: "🔁" },
  { id: "flash", label: "Flashcards erstellen", emoji: "🃏" },
  { id: "quiz", label: "Quiz generieren", emoji: "🧠" },
];

const CANNED: Record<string, string> = {
  simple:
    "Kurz gesagt: Diese Regel zeigt dir, wer im Satz die Handlung macht. Frage einfach: Wer? oder Was?",
  persian: "به‌طور ساده: این قاعده به شما نشان می‌دهد چه کسی یا چه چیزی در جمله عمل انجام می‌دهد.",
  more: "• Der Hund bellt laut.\n• Die Lehrerin erklärt die Aufgabe.\n• Das Kind spielt draußen.",
  generate:
    "• Der Bäcker backt frisches Brot.\n• Meine Freundin lernt jeden Tag Deutsch.\n• Der Zug fährt nach München.",
  english:
    "Deutsch markiert die Rolle über den Artikel (der/den/dem). Englisch nutzt fast nur Wortstellung.",
  prev: "Im vorigen Thema hast du bestimmte Artikel gelernt — der Nominativ nutzt genau diese Formen.",
  flash: "3 Flashcards wurden für dich erstellt und deinem Deck hinzugefügt.",
  quiz: "Ein neues 5-Fragen-Quiz zu diesem Thema steht für dich bereit.",
};

export function AITools({ accent = "#7c5cff" }: { accent?: string }) {
  const [open, setOpen] = useState<string | null>(null);
  const [ask, setAsk] = useState("");
  const [askAnswer, setAskAnswer] = useState<string | null>(null);

  return (
    <div className="glass rounded-3xl p-5">
      <div className="mb-3 flex items-center gap-2">
        <span
          className="grid h-8 w-8 place-items-center rounded-xl text-white"
          style={{ background: accent }}
        >
          ✨
        </span>
        <h3 className="text-base font-bold">DEUSI KI-Werkzeuge</h3>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {TOOLS.map((t) => (
          <button
            key={t.id}
            onClick={() => setOpen(open === t.id ? null : t.id)}
            className={`flex items-center gap-2 rounded-2xl px-3 py-2 text-left text-sm font-medium transition-all ${open === t.id ? "shadow-md" : "bg-muted hover:bg-accent"}`}
            style={open === t.id ? { background: `${accent}18`, color: accent } : undefined}
          >
            <span>{t.emoji}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </div>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 whitespace-pre-line rounded-2xl bg-background/70 p-3 text-sm text-foreground"
          >
            {CANNED[open]}
          </motion.div>
        )}
      </AnimatePresence>
      <div className="mt-4 space-y-2">
        <label className="text-xs font-semibold text-muted-foreground">
          Frag die KI zu dieser Lektion
        </label>
        <div className="flex gap-2">
          <input
            value={ask}
            onChange={(e) => setAsk(e.target.value)}
            placeholder="z. B. Warum steht hier der Nominativ?"
            className="flex-1 rounded-full border border-border bg-background px-4 py-2 text-sm outline-none focus:border-transparent focus:ring-2"
          />
          <button
            onClick={() =>
              setAskAnswer(
                ask.trim()
                  ? `Gute Frage! Kurz: ${ask.trim()} — die Antwort hängt vom Fall und der Position im Satz ab. In dieser Lektion nutzt du den Nominativ, weil das Subjekt beschrieben wird.`
                  : null,
              )
            }
            className="rounded-full px-4 py-2 text-sm font-semibold text-white"
            style={{ background: accent }}
          >
            Fragen
          </button>
        </div>
        {askAnswer && <div className="rounded-2xl bg-muted p-3 text-sm">{askAnswer}</div>}
      </div>
    </div>
  );
}
