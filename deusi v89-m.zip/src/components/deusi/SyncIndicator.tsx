import { CloudOff } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useOfflineQueueStatus } from "@/lib/api/offline-queue";

/**
 * نشانگر کوچک «در انتظار همگام‌سازی».
 * فقط وقتی صف آفلاین خالی نیست دیده می‌شود.
 */
export function SyncIndicator() {
  const { pending } = useOfflineQueueStatus();

  return (
    <AnimatePresence>
      {pending > 0 && (
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 20, opacity: 0 }}
          role="status"
          aria-live="polite"
          className="fixed bottom-3 left-3 z-[55]"
        >
          <div className="flex items-center gap-2 rounded-full border border-border/60 bg-card/80 px-3 py-1.5 text-[11px] font-semibold text-muted-foreground shadow-[var(--elev-1)] backdrop-blur-xl">
            <CloudOff className="h-3.5 w-3.5" />
            {pending} Änderung(en) warten auf Synchronisierung
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
