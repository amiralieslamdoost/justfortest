/**
 * Strukturierte Daten (schema.org) als JSON-LD.
 * دادهٔ ساخت‌یافته برای موتورهای جست‌وجو.
 */
export function JsonLd({ data }: { data: Record<string, unknown> }) {
  return (
    <script
      type="application/ld+json"
      // JSON.stringify کافی است؛ داده‌ها ثابت و داخلی هستند.
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }}
    />
  );
}

/** Basisdaten der Organisation / اطلاعات پایهٔ سازمان */
export const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  name: "DEUSI",
  alternateName: "Deutsch Sprach Ingenieur",
  description: "Lernplattform für Deutsch mit Leitner-Boxen, FSRS-Algorithmus und KI-Coach.",
  inLanguage: ["de", "fa"],
} as const;

/** Website + Suchfunktion / وب‌سایت و جست‌وجوی داخلی */
export const websiteJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "DEUSI",
  inLanguage: ["de", "fa"],
  potentialAction: {
    "@type": "SearchAction",
    target: {
      "@type": "EntryPoint",
      urlTemplate: "/suche?q={search_term_string}",
    },
    "query-input": "required name=search_term_string",
  },
} as const;
