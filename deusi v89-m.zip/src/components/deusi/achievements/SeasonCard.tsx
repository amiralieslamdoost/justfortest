import { motion } from "framer-motion";
import { Fa } from "@/components/deusi/Fa";
import {
  CURRENT_LEAGUE,
  LEAGUES,
  CURRENT_LEAGUE_INDEX,
  NEXT_LEAGUE,
  SEASON,
} from "@/lib/deusi/gamification";

export function SeasonCard({ rank }: { rank: number }) {
  const pct = Math.max(6, Math.round(((6 - Math.min(rank, 6)) / 5) * 100));

  return (
    <section
      className="relative overflow-hidden rounded-[1.75rem] p-4 text-white shadow-2xl sm:p-6"
      style={{
        backgroundImage:
          "radial-gradient(110% 110% at 10% 0%, #6D28D9 0%, transparent 55%), linear-gradient(135deg, #1E1B4B 0%, #4C1D95 55%, #B45309 130%)",
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-amber-300/25 blur-3xl" />
        <div className="absolute -bottom-16 left-4 h-40 w-40 rounded-full bg-violet-400/25 blur-3xl" />
      </div>

      <div className="relative grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.14em] backdrop-blur sm:text-[10px]">
            {SEASON.nameDe} · noch {SEASON.daysLeft} Tage
          </div>
          <h2 className="mt-2 text-lg font-black leading-tight sm:text-2xl">
            {CURRENT_LEAGUE.emoji} {CURRENT_LEAGUE.de}-Liga
          </h2>
          <Fa className="fa-hint-xs !text-white/85">لیگ {CURRENT_LEAGUE.fa} — فصل تابستان</Fa>
        </div>
        <div className="shrink-0 rounded-2xl bg-white/15 px-3 py-2 text-center ring-1 ring-white/25 backdrop-blur sm:px-4">
          <div className="text-xl font-black tabular-nums sm:text-2xl">#{rank}</div>
          <div className="text-[9px] font-bold uppercase tracking-widest text-white/85 sm:text-[10px]">
            dein Platz
          </div>
        </div>
      </div>

      {/* League ladder */}
      <div className="relative mt-5">
        <div aria-hidden className="absolute left-4 right-4 top-5 h-0.5 rounded-full bg-white/20" />
        <div className="relative flex items-start justify-between gap-1">
          {LEAGUES.map((l, i) => {
            const done = i <= CURRENT_LEAGUE_INDEX;
            const current = i === CURRENT_LEAGUE_INDEX;
            return (
              <div key={l.id} className="flex min-w-0 flex-1 flex-col items-center gap-1">
                <motion.div
                  initial={{ scale: 0.7, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: i * 0.07, type: "spring", stiffness: 200 }}
                  className={`grid h-9 w-9 place-items-center rounded-full text-base ring-2 sm:h-10 sm:w-10 sm:text-lg ${
                    current
                      ? "bg-white/95 ring-white shadow-[0_0_18px_rgba(255,255,255,0.6)]"
                      : done
                        ? "bg-white/25 ring-white/40"
                        : "bg-white/10 ring-white/20 opacity-60"
                  }`}
                >
                  <span aria-hidden>{l.emoji}</span>
                </motion.div>
                <span
                  className={`w-full truncate text-center text-[8px] font-bold uppercase tracking-wide sm:text-[9px] ${
                    current ? "text-white" : "text-white/75"
                  }`}
                >
                  {l.de}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="relative mt-4">
        <div className="h-2.5 w-full overflow-hidden rounded-full bg-black/25 ring-1 ring-white/20">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.9, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-amber-200 to-amber-400 shadow-[0_0_18px_rgba(251,191,36,0.7)]"
          />
        </div>
        <p className="mt-2 text-[11px] font-semibold leading-relaxed text-white/85 sm:text-xs">
          Bleib in den Top {SEASON.promoteRank} und steige in die {NEXT_LEAGUE.emoji}{" "}
          {NEXT_LEAGUE.de}-Liga auf.
        </p>
      </div>
    </section>
  );
}
