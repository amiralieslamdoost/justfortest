import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { CheckCircle2, ChevronRight, Gift, Sparkles, Timer } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import {
  DAILY_MISSIONS,
  WEEKLY_MISSIONS,
  DAILY_DONE,
  DAILY_XP_OPEN,
  missionPct,
  type Mission,
} from "@/lib/deusi/gamification";

type Tab = "Täglich" | "Wöchentlich";

export function MissionsBoard({ onCelebrate }: { onCelebrate?: () => void }) {
  const [tab, setTab] = useState<Tab>("Täglich");
  const missions = tab === "Täglich" ? DAILY_MISSIONS : WEEKLY_MISSIONS;

  return (
    <section className="neu-card relative overflow-hidden p-4 sm:p-6">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-20 -top-20 h-52 w-52 rounded-full bg-primary/10 blur-3xl"
      />
      <div className="relative flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <h2 className="flex items-center gap-2 text-base font-black leading-tight sm:text-lg">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-primary/12 text-primary">
              <Sparkles className="h-4 w-4" aria-hidden />
            </span>
            Missionen
          </h2>
          <Fa className="fa-hint-xs">ماموریت‌های تو</Fa>
        </div>

        <div className="flex w-full flex-wrap items-center justify-between gap-2 sm:w-auto sm:justify-end">
          <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-[9px] font-bold uppercase tracking-widest text-muted-foreground sm:text-[10px]">
            <Timer className="h-3 w-3" aria-hidden />
            {tab === "Täglich" ? "Reset 07:12 Std." : "Reset So."}
          </span>
          <div className="flex rounded-full bg-secondary p-1">
            {(["Täglich", "Wöchentlich"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`rounded-full px-3 py-1 text-[11px] font-bold transition sm:text-xs ${
                  tab === t
                    ? "bg-foreground text-background shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Daily combo strip */}
      {tab === "Täglich" && (
        <div className="relative mt-4 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-x-3 gap-y-3 rounded-2xl bg-secondary/70 p-3 ring-1 ring-border/60 sm:flex sm:flex-nowrap">
          <div className="flex items-center gap-1.5">
            {DAILY_MISSIONS.map((m, i) => (
              <span
                key={m.id}
                className={`grid h-7 w-7 place-items-center rounded-full text-xs font-black ring-1 ${
                  m.current >= m.target
                    ? "bg-primary text-primary-foreground ring-primary shadow-sm"
                    : "bg-background text-muted-foreground ring-border"
                }`}
              >
                {m.current >= m.target ? "✓" : i + 1}
              </span>
            ))}
          </div>
          <div className="min-w-0 flex-1 text-[11px] font-semibold leading-snug text-muted-foreground sm:text-xs">
            <b className="text-foreground">{DAILY_DONE}/3</b> erledigt · noch{" "}
            <b className="text-foreground">{DAILY_XP_OPEN} XP</b> zu holen
            <Fa className="fa-hint-xs">همه را کامل کن و جعبه جایزه را باز کن</Fa>
          </div>
          <button
            disabled={DAILY_DONE < 3}
            onClick={onCelebrate}
            className="col-span-2 inline-flex shrink-0 items-center justify-center gap-1.5 rounded-full bg-foreground px-3 py-2 text-xs font-black text-background transition enabled:hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40 sm:col-auto sm:py-1.5"
          >
            <Gift className="h-3.5 w-3.5" aria-hidden />
            Bonus-Truhe
          </button>
        </div>
      )}

      <div className="relative mt-4 space-y-2.5">
        {missions.map((m, i) => (
          <MissionRow key={m.id} mission={m} index={i} onCelebrate={onCelebrate} />
        ))}
      </div>
    </section>
  );
}

function MissionRow({
  mission: m,
  index,
  onCelebrate,
}: {
  mission: Mission;
  index: number;
  onCelebrate?: () => void;
}) {
  const pct = missionPct(m);
  const done = m.current >= m.target;

  return (
    <motion.div
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="group relative grid grid-cols-[auto_minmax(0,1fr)] items-center gap-x-3 gap-y-2.5 overflow-hidden rounded-2xl p-3 ring-1 ring-border transition hover:-translate-y-0.5 hover:shadow-lg sm:flex sm:flex-nowrap"
      style={{
        backgroundImage: done
          ? `linear-gradient(135deg, color-mix(in oklab, ${m.color} 16%, transparent), transparent)`
          : undefined,
      }}
    >
      {done && (
        <span
          aria-hidden
          className="absolute inset-y-0 left-0 w-1 rounded-r-full"
          style={{ background: m.color }}
        />
      )}
      <div
        className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-xl text-white shadow-md"
        style={{
          backgroundImage: `linear-gradient(135deg, ${m.color}, color-mix(in oklab, ${m.color} 60%, #000))`,
        }}
      >
        <span aria-hidden>{m.emoji}</span>
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="min-w-0 truncate text-[13px] font-black leading-tight sm:text-sm">
            {m.titleDe}
          </span>
          <span
            className="shrink-0 rounded-full px-2 py-0.5 text-[10px] font-black"
            style={{
              background: `color-mix(in oklab, ${m.color} 18%, transparent)`,
              color: m.color,
            }}
          >
            +{m.xp} XP
          </span>
        </div>
        <Fa className="fa-hint-xs">{m.titleFa}</Fa>
        <div className="mt-1.5 flex items-center gap-2">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${pct}%` }}
              transition={{ duration: 0.7, delay: index * 0.05 }}
              className="h-full rounded-full"
              style={{
                background: `linear-gradient(90deg, ${m.color}, color-mix(in oklab, ${m.color} 55%, #fff))`,
              }}
            />
          </div>
          <span className="shrink-0 text-[10px] font-bold tabular-nums text-muted-foreground">
            {Math.min(m.current, m.target)}/{m.target}
          </span>
        </div>
      </div>

      {done ? (
        <button
          onClick={onCelebrate}
          className="col-span-2 inline-flex shrink-0 items-center justify-center gap-1 rounded-full bg-foreground px-3 py-2 text-[11px] font-black text-background transition hover:opacity-90 sm:col-auto sm:py-1.5"
        >
          <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />
          Einlösen
        </button>
      ) : (
        <Link
          to={m.href}
          className="col-span-2 inline-flex shrink-0 items-center justify-center gap-0.5 rounded-full bg-secondary px-3 py-2 text-[11px] font-black text-foreground transition hover:bg-foreground hover:text-background sm:col-auto sm:py-1.5"
        >
          Los
          <ChevronRight className="h-3.5 w-3.5" aria-hidden />
        </Link>
      )}
    </motion.div>
  );
}
