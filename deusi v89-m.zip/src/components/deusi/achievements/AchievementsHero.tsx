import { motion } from "framer-motion";
import { Trophy } from "lucide-react";

/** Soft, blurred white orbs drifting inside the hero — replaces the old emojis. */
export function FloatingDot({
  size = 28,
  className = "",
  delay = 0,
  opacity = 0.5,
}: {
  size?: number;
  className?: string;
  delay?: number;
  opacity?: number;
}) {
  return (
    <motion.span
      aria-hidden
      className={`absolute rounded-full ${className}`}
      style={{
        width: size,
        height: size,
        background: "rgba(255,255,255,0.9)",
        boxShadow: "0 0 10px 2px rgba(255,255,255,0.45)",
        filter: "blur(1px)",
        opacity,
      }}

      initial={{ y: 0 }}
      animate={{ y: [-10, 10, -10], opacity: [opacity * 0.6, opacity, opacity * 0.6] }}
      transition={{ duration: 7, repeat: Infinity, delay, ease: "easeInOut" }}
    />
  );
}

export function HeroChip({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold ring-1 ring-white/20 backdrop-blur sm:text-[11px]">
      {children}
    </span>
  );
}

export function XpRing({ pct, level }: { pct: number; level: number }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <motion.div
      initial={{ scale: 0.6, rotate: -18, opacity: 0 }}
      animate={{ scale: 1, rotate: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 180, damping: 13 }}
      className="relative h-[68px] w-[68px] shrink-0 sm:h-20 sm:w-20"
    >
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="rgba(0,0,0,0.22)" strokeWidth="6" />
        <motion.circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          stroke="url(#xpgrad)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - (c * Math.min(100, pct)) / 100 }}
          transition={{ duration: 1.1, ease: "easeOut" }}
        />
        <defs>
          <linearGradient id="xpgrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#FDE68A" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-[9px] grid place-items-center rounded-full bg-white/95 shadow-inner">
        <Trophy className="h-6 w-6 sm:h-7 sm:w-7" style={{ color: "#EA580C" }} aria-hidden />
      </div>
      <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full bg-foreground px-1.5 py-px text-[9px] font-black text-background shadow">
        LV {level}
      </span>
    </motion.div>
  );
}

export function HeroKpi({
  value,
  label,
  icon,
}: {
  value: string | number;
  label: string;
  icon?: string;
}) {
  return (
    <div className="rounded-2xl bg-white/12 p-2.5 text-center shadow-[inset_0_1px_0_rgba(255,255,255,0.35)] ring-1 ring-white/25 backdrop-blur sm:p-3">
      {icon && (
        <div className="text-base leading-none sm:text-lg" aria-hidden>
          {icon}
        </div>
      )}
      <div className="mt-0.5 text-lg font-black tabular-nums sm:text-2xl">{value}</div>
      <div className="mt-0.5 truncate text-[9px] font-semibold uppercase tracking-wider text-white/85 sm:text-[10px]">
        {label}
      </div>
    </div>
  );
}
