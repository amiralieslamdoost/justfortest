import { motion, AnimatePresence, useMotionValue, useTransform, animate } from "framer-motion";
import { useEffect, useState, type ReactNode } from "react";
import { CEFR_COLOR, POS_SHORT, POS_COLOR } from "@/lib/deusi/dictionary/categories";
import type { CEFR, DictPos } from "@/lib/deusi/dictionary/types";
import type {
  LeitnerBoxInfo,
  QueueItem,
  WeeklyPoint,
  HeatCell,
  Preset,
  AIInsight,
  SessionPreview,
} from "@/lib/deusi/leitner/mockLeitner";
import { Fa } from "@/components/deusi/Fa";

/* ---------------- Animated counter ---------------- */

export function Counter({
  to,
  suffix = "",
  decimals = 0,
}: {
  to: number;
  suffix?: string;
  decimals?: number;
}) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (latest) => {
    const n = decimals ? latest.toFixed(decimals) : Math.round(latest).toLocaleString("de-DE");
    return `${n}${suffix}`;
  });
  useEffect(() => {
    const controls = animate(mv, to, { duration: 1.1, ease: [0.2, 0.8, 0.2, 1] });
    return controls.stop;
  }, [to, mv]);
  return <motion.span>{rounded}</motion.span>;
}

/* ---------------- Ring ---------------- */

export function Ring({
  value,
  size = 96,
  stroke = 8,
  color = "#8B5CF6",
  track = "var(--secondary)",
  children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  track?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (Math.min(100, Math.max(0, value)) / 100) * c;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={c}
          strokeLinecap="round"
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: off }}
          transition={{ duration: 1.1, ease: [0.2, 0.8, 0.2, 1] }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

/* ---------------- Stat glass card ---------------- */

export function StatGlass({
  icon,
  label,
  fa,
  value,
  sub,
  color = "#8B5CF6",
  tint = "#F3ECFF",
  delay = 0,
}: {
  icon: ReactNode;
  label: string;
  fa?: string;
  value: ReactNode;
  sub?: string;
  color?: string;
  tint?: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: [0.2, 0.8, 0.2, 1] }}
      className="glass-strong rounded-[1.75rem] p-5 hover:-translate-y-0.5 transition-transform"
    >
      <div className="flex items-center justify-between">
        <div
          className="grid h-11 w-11 place-items-center rounded-2xl text-lg"
          style={{ background: tint, color }}
        >
          {icon}
        </div>
        <span
          className="rounded-xl px-2 py-1 text-[10px] font-semibold"
          style={{ background: tint, color }}
        >
          Live
        </span>
      </div>
      <div className="mt-4 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      {fa && <Fa className="fa-hint-xs">{fa}</Fa>}
      <div className="mt-1 text-2xl font-black tabular-nums">{value}</div>
      {sub && <div className="mt-1 text-[11px] text-muted-foreground">{sub}</div>}
    </motion.div>
  );
}

/* ---------------- Leitner Box card ---------------- */

export function BoxCard({ b, i, words = [] }: { b: LeitnerBoxInfo; i: number; words?: string[] }) {
  const [open, setOpen] = useState(false);
  const [page, setPage] = useState(0);
  const perPage = 5;
  const pageCount = Math.max(1, Math.ceil(words.length / perPage));
  const currentPage = Math.min(page, pageCount - 1);
  const start = currentPage * perPage;
  const pageWords = words.slice(start, start + perPage);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay: 0.06 * i, ease: [0.2, 0.8, 0.2, 1] }}
      className="group relative flex flex-col overflow-hidden rounded-[1.5rem] border-2 bg-card p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_24px_50px_-20px]"
      style={{
        borderColor: `${b.color}55`,
        ["--tw-shadow-color" as string]: `${b.color}55`,
      }}
    >
      {/* Ambient glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-40 blur-3xl transition-opacity duration-500 group-hover:opacity-70"
        style={{ background: b.tint }}
      />

      {/* Header: numbered badge + interval pill, then the label on its own line */}
      <div className="relative">
        <div className="flex items-center justify-between gap-2">
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm font-black text-white shadow-sm"
            style={{ background: b.color }}
          >
            {b.box}
          </span>
          <span
            className="shrink-0 rounded-full px-2 py-0.5 text-[10px] font-black tabular-nums"
            style={{ background: b.tint, color: b.color }}
          >
            {b.intervalDays}T
          </span>
        </div>
        <div className="mt-2 break-words text-sm font-black leading-tight text-foreground lg:text-base">
          {b.label}
        </div>
      </div>

      {/* Big number + progress % */}
      <div className="relative mt-5 flex items-end justify-between gap-3">
        <div className="min-w-0">
          <div
            className="text-5xl font-black leading-none tabular-nums tracking-tight"
            style={{ color: b.color }}
          >
            <Counter to={b.cards} />
          </div>
          <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.15em] text-muted-foreground">
            Karten
          </div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-black tabular-nums" style={{ color: b.color }}>
            {b.progress}%
          </div>
          <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.15em] text-muted-foreground">
            Progress
          </div>
        </div>
      </div>

      {/* Progress bar */}
      <div className="relative mt-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary/70">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${b.progress}%` }}
          transition={{ duration: 1, delay: 0.1 + 0.06 * i, ease: [0.2, 0.8, 0.2, 1] }}
          className="h-full rounded-full"
          style={{ background: b.color }}
        />
      </div>

      {/* Next review row */}
      <div className="relative mt-4 rounded-xl bg-secondary/50 px-3 py-2">
        <div className="text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground">
          Nächste Wiederholung
        </div>
        <div className="mt-0.5 text-xs font-black text-foreground">{b.nextReviewIn}</div>
      </div>

      {/* Words disclosure */}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="relative mt-4 flex w-full items-center justify-between rounded-2xl border-2 px-3 py-2 text-xs font-black transition hover:opacity-90"
        style={{
          borderColor: `${b.color}44`,
          background: open ? b.tint : "transparent",
          color: b.color,
        }}
        aria-expanded={open}
      >
        <span className="flex items-center gap-1.5">
          <span aria-hidden>▢</span>
          <span className="tabular-nums">{words.length} Wörter</span>
        </span>
        <span
          className={`grid h-5 w-5 place-items-center rounded-full transition-transform duration-200 ${open ? "rotate-180" : ""}`}
          style={{ background: `${b.color}22` }}
          aria-hidden
        >
          ▾
        </span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="words"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.24, ease: [0.2, 0.8, 0.2, 1] }}
            className="relative overflow-hidden"
          >
            <div className="mt-3">
              {words.length === 0 ? (
                <div className="rounded-lg bg-secondary/40 px-2 py-3 text-center text-[11px] text-muted-foreground">
                  Keine Wörter in dieser Box.
                </div>
              ) : (
                <>
                  <ul className="flex flex-wrap gap-1.5">
                    {pageWords.map((w) => (
                      <li
                        key={w}
                        className="rounded-lg border px-2 py-1 text-[11px] font-semibold text-foreground"
                        style={{ borderColor: `${b.color}55` }}
                      >
                        {w}
                      </li>
                    ))}
                  </ul>
                  {pageCount > 1 && (
                    <div className="mt-3 flex items-center justify-center gap-3 text-[11px] font-semibold text-muted-foreground">
                      <button
                        type="button"
                        onClick={() => setPage((p) => Math.max(0, p - 1))}
                        disabled={currentPage === 0}
                        className="grid h-6 w-6 place-items-center rounded-full border border-border transition hover:bg-secondary disabled:opacity-40"
                        aria-label="Vorherige"
                      >
                        ‹
                      </button>
                      <span className="tabular-nums">
                        {start + 1}–{Math.min(words.length, start + perPage)} von {words.length}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
                        disabled={currentPage >= pageCount - 1}
                        className="grid h-6 w-6 place-items-center rounded-full border border-border transition hover:bg-secondary disabled:opacity-40"
                        aria-label="Nächste"
                      >
                        ›
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* ---------------- Preset card ---------------- */

export function PresetCard({
  p,
  active,
  onPick,
}: {
  p: Preset;
  active: boolean;
  onPick: () => void;
}) {
  return (
    <motion.button
      whileHover={{ y: -3 }}
      whileTap={{ scale: 0.98 }}
      onClick={onPick}
      className={`glass-strong text-left rounded-[1.5rem] p-5 transition ${
        active ? "ring-2 ring-offset-2 ring-offset-background" : ""
      }`}
      style={
        active
          ? { boxShadow: `0 20px 60px -20px ${p.color}55`, ["--tw-ring-color" as string]: p.color }
          : undefined
      }
    >
      <div className="mb-3 flex items-center justify-between">
        <span
          className="rounded-xl px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider"
          style={{ background: p.tint, color: p.color }}
        >
          {p.duration}
        </span>
        {p.recommended && (
          <span className="rounded-xl bg-[color:var(--flag-red)] px-2.5 py-1 text-[10px] font-bold text-white">
            Empfohlen
          </span>
        )}
      </div>
      <h3 className="text-lg font-black">{p.title}</h3>
      <p className="mt-1 text-xs text-muted-foreground">{p.tagline}</p>
      <ul className="mt-3 space-y-1.5">
        {p.bullets.map((b) => (
          <li key={b} className="flex items-center gap-2 text-xs">
            <span
              className="grid h-4 w-4 place-items-center rounded-full text-[9px] font-black"
              style={{ background: p.tint, color: p.color }}
            >
              ✓
            </span>
            <span>{b}</span>
          </li>
        ))}
      </ul>
    </motion.button>
  );
}

/* ---------------- Weekly chart ---------------- */

export function WeeklyBars({ data }: { data: WeeklyPoint[] }) {
  const max = Math.max(...data.map((d) => d.count));
  return (
    <div className="flex h-[140px] items-end gap-2">
      {data.map((d, i) => {
        const h = Math.round((d.count / max) * 100);
        return (
          <div key={d.day} className="flex flex-1 flex-col items-center gap-1.5">
            <div className="text-[10px] font-semibold tabular-nums text-muted-foreground">
              {d.count}
            </div>
            <div className="relative flex w-full flex-1 items-end">
              <motion.div
                className="w-full rounded-t-xl bg-gradient-to-t from-[#8B5CF6] to-[#c4b5fd]"
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ duration: 0.9, delay: 0.05 * i, ease: "easeOut" }}
              />
            </div>
            <div className="text-[10px] text-muted-foreground">{d.day}</div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------- Heatmap ---------------- */

export function Heatmap({ data }: { data: HeatCell[] }) {
  const colors = ["#EEF2F7", "#C4B5FD", "#8B5CF6", "#6D28D9", "#4C1D95"];
  return (
    <div className="grid grid-cols-12 gap-1">
      {data.map((c, i) => (
        <motion.div
          key={c.date}
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.25, delay: i * 0.005 }}
          className="aspect-square rounded-[6px]"
          style={{ background: colors[Math.min(4, c.value)] }}
          title={`${c.value} Reviews`}
        />
      ))}
    </div>
  );
}

/* ---------------- Queue item ---------------- */

export function QueueRow({ q }: { q: QueueItem }) {
  const cefr = CEFR_COLOR[q.cefr];
  const pos = POS_COLOR[q.pos];
  return (
    <motion.li
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex items-center gap-3 rounded-2xl border border-border bg-secondary/40 p-3 hover:bg-secondary/70 transition"
    >
      <span
        className="grid h-9 w-9 place-items-center rounded-xl text-[11px] font-black"
        style={{ background: `${cefr}22`, color: cefr }}
      >
        {q.cefr}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-sm font-bold">{q.headword}</span>
          {q.favorite && <span title="Favorit">⭐</span>}
          {q.difficult && <span title="Schwierig">🔥</span>}
        </div>
        <div className="mt-0.5 flex items-center gap-2 text-[10px] text-muted-foreground">
          <span
            className="rounded-md px-1.5 py-0.5 font-semibold"
            style={{ background: `${pos}18`, color: pos }}
          >
            {POS_SHORT[q.pos]}
          </span>
          <span>Box {q.box}</span>
          <span>· {q.dueLabel}</span>
        </div>
      </div>
    </motion.li>
  );
}

/* ---------------- Insight card ---------------- */

export function InsightCard({ i }: { i: AIInsight }) {
  const tint = i.tone === "success" ? "#E7F8EE" : i.tone === "warning" ? "#FFF4D6" : "#F3ECFF";
  const color = i.tone === "success" ? "#059669" : i.tone === "warning" ? "#B45309" : "#7C3AED";
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl p-4 hover:-translate-y-0.5 transition-transform"
    >
      <div className="flex items-start gap-3">
        <div
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-lg"
          style={{ background: tint, color }}
        >
          {i.icon}
        </div>
        <div className="min-w-0">
          <div className="text-sm font-bold">{i.title}</div>
          <p className="mt-1 text-xs text-muted-foreground">{i.body}</p>
        </div>
      </div>
    </motion.div>
  );
}

/* ---------------- Session preview panel ---------------- */

export function SessionPreviewCard({ p }: { p: SessionPreview }) {
  const rows: Array<[string, ReactNode, string]> = [
    ["Karten", <Counter to={p.totalCards} />, "#8B5CF6"],
    ["Minuten", <Counter to={p.estimatedMinutes} />, "#0EA5E9"],
    [
      "XP",
      <>
        +<Counter to={p.estimatedXp} />
      </>,
      "#F59E0B",
    ],
  ];
  return (
    <div className="card-glass p-5">
      <div className="mb-3">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Session-Vorschau
        </div>
        <h3 className="text-base font-black">Was dich erwartet</h3>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {rows.map(([label, val, color]) => (
          <div key={label} className="glass rounded-2xl p-3 text-center">
            <div className="text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
              {label}
            </div>
            <div className="mt-1 text-lg font-black tabular-nums" style={{ color }}>
              {val}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Toggle & chip ---------------- */

export function Toggle({
  on,
  onChange,
  label,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="flex w-full items-center justify-between rounded-xl border border-border bg-secondary/40 px-3 py-2 text-left hover:bg-secondary/70 transition"
    >
      <span className="text-xs font-semibold">{label}</span>
      <span
        className={`relative h-5 w-9 rounded-full transition ${on ? "bg-[color:var(--flag-red)]" : "bg-muted"}`}
      >
        <motion.span
          className="absolute top-0.5 h-4 w-4 rounded-full bg-white shadow"
          animate={{ x: on ? 18 : 2 }}
          transition={{ type: "spring", stiffness: 400, damping: 30 }}
        />
      </span>
    </button>
  );
}

export function ChipGroup<T extends string>({
  options,
  value,
  onChange,
  colors,
}: {
  options: T[];
  value: T[];
  onChange: (v: T[]) => void;
  colors?: Record<string, string>;
}) {
  const toggle = (o: T) => {
    onChange(value.includes(o) ? value.filter((x) => x !== o) : [...value, o]);
  };
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map((o) => {
        const on = value.includes(o);
        const c = colors?.[o] ?? "#8B5CF6";
        return (
          <button
            key={o}
            onClick={() => toggle(o)}
            className="rounded-lg px-2.5 py-1 text-[11px] font-bold transition"
            style={{
              background: on ? c : "transparent",
              color: on ? "#fff" : c,
              border: `1px solid ${c}55`,
            }}
          >
            {o}
          </button>
        );
      })}
    </div>
  );
}

export function NumberField({
  label,
  value,
  onChange,
  min = 0,
  max = 200,
  step = 1,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-semibold text-muted-foreground">{label}</span>
      <div className="flex items-center gap-2 rounded-xl border border-border bg-secondary/40 px-2">
        <button
          className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"
          onClick={() => onChange(Math.max(min, value - step))}
        >
          −
        </button>
        <input
          type="number"
          value={value}
          min={min}
          max={max}
          onChange={(e) => onChange(Math.min(max, Math.max(min, Number(e.target.value) || 0)))}
          className="w-full bg-transparent py-1.5 text-center text-sm font-bold tabular-nums outline-none"
        />
        <button
          className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"
          onClick={() => onChange(Math.min(max, value + step))}
        >
          +
        </button>
      </div>
    </label>
  );
}

export function Select<T extends string>({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: T;
  onChange: (v: T) => void;
  options: Array<{ value: T; label: string }>;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-semibold text-muted-foreground">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
        className="w-full rounded-xl border border-border bg-secondary/40 px-3 py-2 text-sm font-semibold outline-none focus:bg-secondary"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
