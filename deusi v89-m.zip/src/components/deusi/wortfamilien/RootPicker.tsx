import { Search } from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import type { WordRoot } from "@/lib/deusi/wordfamilies/types";
import { SearchField } from "@/components/deusi/SearchField";

type Props = {
  roots: WordRoot[];
  activeId: string;
  query: string;
  onQuery: (q: string) => void;
  onPick: (id: string) => void;
};

export function RootPicker({ roots, activeId, query, onQuery, onPick }: Props) {
  return (
    <div className="rounded-3xl border border-border/60 bg-card p-4">
      <SearchField
        value={query}
        onValueChange={onQuery}
        placeholder="Wort oder Wortstamm suchen…"
      />
      <FaHint className="mt-2">جستجوی ریشه یا هر واژه‌ی هم‌خانواده</FaHint>

      <div className="mt-3 max-h-[420px] space-y-1.5 overflow-y-auto pr-1 lg:max-h-[560px]">
        {roots.map((r) => {
          const active = r.id === activeId;
          return (
            <button
              key={r.id}
              type="button"
              onClick={() => onPick(r.id)}
              className={`flex w-full items-center justify-between gap-2 rounded-xl border px-3 py-2 text-left transition ${
                active
                  ? "border-[color:var(--section-accent)] bg-secondary"
                  : "border-border/60 hover:bg-secondary"
              }`}
            >
              <span className="min-w-0">
                <span className="block truncate font-mono text-sm font-black">{r.root}-</span>
                <span className="block truncate text-[11px] text-muted-foreground">{r.label}</span>
                <span className="block truncate text-[11px] text-muted-foreground" dir="rtl">
                  {r.meaningFa}
                </span>
              </span>
              <span className="flex shrink-0 flex-col items-end gap-1">
                <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[9px] font-bold">
                  {r.cefr}
                </span>
                <span className="text-[10px] font-bold text-muted-foreground">
                  {r.members.length} Wörter
                </span>
              </span>
            </button>
          );
        })}
        {roots.length === 0 && (
          <div className="rounded-xl border border-dashed border-border/60 p-4 text-center text-xs text-muted-foreground">
            Kein Treffer.
          </div>
        )}
      </div>
    </div>
  );
}
