import { ArrowRight, BookOpen, Layers, Lightbulb, Volume2 } from "lucide-react";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";
import { FaHint } from "@/components/deusi/FaHint";
import { MorphemeBreakdown } from "./MorphemeBreakdown";
import { PREFIXES, SUFFIXES } from "@/lib/deusi/wordfamilies/prefixes";
import { POS_COLOR, POS_LABEL, type FamilyMember } from "@/lib/deusi/wordfamilies/types";

type Props = {
  member: FamilyMember | null;
  inLeitner: boolean;
  onToggleLeitner: () => void;
  onOpenFamily?: (familyId: string) => void;
  /** All members of the current family, used for the “related words” row. */
  siblings?: FamilyMember[];
  onSelect?: (member: FamilyMember) => void;
};

export function NodeDetailPanel({
  member,
  inLeitner,
  onToggleLeitner,
  onOpenFamily,
  siblings = [],
  onSelect,
}: Props) {
  if (!member) {
    return (
      <div className="rounded-3xl border border-dashed border-border/60 bg-card p-6 text-center">
        <Layers className="mx-auto h-6 w-6 text-muted-foreground" />
        <div className="mt-2 text-sm font-bold">Wähle ein Wort im Netz</div>
        <FaHint className="mt-1">روی یکی از واژه‌های اطراف ریشه بزن تا جزئیاتش را ببینی.</FaHint>
      </div>
    );
  }

  const color = POS_COLOR[member.pos];
  const prefixInfo = member.prefix ? PREFIXES.find((p) => p.prefix === member.prefix) : undefined;
  const suffixInfo = member.suffix ? SUFFIXES.find((p) => p.prefix === member.suffix) : undefined;
  const related = siblings
    .filter((s) => s.id !== member.id && (s.prefix === member.prefix || s.pos === member.pos))
    .slice(0, 8);

  const speak = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const u = new SpeechSynthesisUtterance(member.word);
    u.lang = "de-DE";
    window.speechSynthesis.speak(u);
  };

  return (
    <div className="rounded-3xl border border-border/60 bg-card p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <span
            className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider"
            style={{ background: `${color}22`, color }}
          >
            {POS_LABEL[member.pos].de}
          </span>
          <h2 className="mt-1.5 flex flex-wrap items-center gap-2 text-2xl font-black">
            {member.article && <span className="text-muted-foreground">{member.article}</span>}
            {member.word}
            <button
              type="button"
              onClick={speak}
              aria-label="Aussprache"
              className="grid h-8 w-8 place-items-center rounded-full border border-border/60 text-muted-foreground hover:bg-secondary"
            >
              <Volume2 className="h-4 w-4" />
            </button>
          </h2>
          <div className="text-sm text-muted-foreground">{member.meaningDe}</div>
          <div className="text-sm font-semibold" dir="rtl">
            {member.meaningFa}
          </div>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1.5">
          <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold">
            {member.cefr}
          </span>
          <BookmarkButton type="word" id={`wf:${member.id}`} label={member.word} variant="chip" />
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-border/60 bg-secondary/50 p-3">
        <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
          Wortbau
        </div>
        <MorphemeBreakdown member={member} size="md" showLegend />
      </div>

      <div className="mt-3 rounded-2xl border border-border/60 p-3">
        <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
          <BookOpen className="h-3.5 w-3.5" /> Beispiel
        </div>
        <p className="mt-1 text-sm font-semibold">{member.example}</p>
      </div>

      {(prefixInfo || suffixInfo) && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {prefixInfo && (
            <MorphemeCard
              tag={`${prefixInfo.prefix}-`}
              title={prefixInfo.meaningDe}
              fa={prefixInfo.meaningFa}
              note={`${prefixInfo.separable ? "trennbar" : "nicht trennbar"} · z. B. ${prefixInfo.example}`}
            />
          )}
          {suffixInfo && (
            <MorphemeCard
              tag={`-${suffixInfo.prefix}`}
              title={suffixInfo.meaningDe}
              fa={suffixInfo.meaningFa}
              note={`z. B. ${suffixInfo.example}`}
            />
          )}
        </div>
      )}

      {member.pos === "verb" && member.separable !== undefined && (
        <div className="mt-3 flex items-start gap-2 rounded-2xl border border-border/60 bg-secondary/40 p-3 text-xs">
          <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
          <div>
            <span className="font-bold">
              {member.separable ? "Trennbares Verb" : "Nicht trennbares Verb"}
            </span>
            <FaHint className="mt-0.5">
              {member.separable
                ? "پیشوند جدا می‌شود و به آخر جمله می‌رود."
                : "پیشوند جدا نمی‌شود و همیشه چسبیده می‌ماند."}
            </FaHint>
          </div>
        </div>
      )}

      {related.length > 0 && onSelect && (
        <div className="mt-3">
          <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            Verwandte Wörter
          </div>
          <div className="flex flex-wrap gap-1.5">
            {related.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => onSelect(r)}
                className="rounded-full border border-border/60 px-2.5 py-1 text-[11px] font-bold transition hover:bg-secondary"
                style={{ borderColor: `${POS_COLOR[r.pos]}55` }}
              >
                {r.article ? `${r.article} ` : ""}
                {r.word}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={onToggleLeitner}
          className={`rounded-xl px-3 py-2 text-xs font-bold transition ${
            inLeitner ? "border border-border/60 bg-secondary text-foreground" : "text-white"
          }`}
          style={inLeitner ? undefined : { background: "var(--section-primary)" }}
        >
          {inLeitner ? "Im Leitner-Kasten ✓" : "In Leitner-Kasten"}
        </button>
        {member.familyId && onOpenFamily && (
          <button
            type="button"
            onClick={() => onOpenFamily(member.familyId!)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-border/60 px-3 py-2 text-xs font-bold hover:bg-secondary"
          >
            Eigene Wortfamilie <ArrowRight className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
    </div>
  );
}

function MorphemeCard({
  tag,
  title,
  fa,
  note,
}: {
  tag: string;
  title: string;
  fa: string;
  note: string;
}) {
  return (
    <div className="rounded-2xl border border-border/60 bg-secondary/40 p-3">
      <div className="font-mono text-sm font-black" style={{ color: "var(--section-primary)" }}>
        {tag}
      </div>
      <div className="mt-0.5 text-xs font-semibold">{title}</div>
      <FaHint className="mt-0.5">{fa}</FaHint>
      <div className="mt-1 text-[10px] text-muted-foreground">{note}</div>
    </div>
  );
}
