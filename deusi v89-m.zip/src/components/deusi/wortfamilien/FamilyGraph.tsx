import { motion } from "framer-motion";
import { Maximize2, Minus, Plus, RotateCcw } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  POS_COLOR,
  POS_LABEL,
  type FamilyMember,
  type WfPos,
  type WordRoot,
} from "@/lib/deusi/wordfamilies/types";

type Props = {
  root: WordRoot;
  members: FamilyMember[];
  selectedId: string | null;
  onSelect: (member: FamilyMember) => void;
};

const NODE_H = 42;
const GAP = 24; // minimum horizontal gap between two neighbours
const RING_GAP = 96; // distance between rings
const FIRST_RING = 196; // radius of the innermost ring
const SQUASH = 0.9; // vertical squash so the map stays wide, not tall
const MIN_ZOOM = 0.45;
const MAX_ZOOM = 2.6;
const POS_ORDER: WfPos[] = ["verb", "noun", "adjective", "adverb"];

type Placed = { member: FamilyMember; x: number; y: number; w: number; ring: number };

function labelOf(m: FamilyMember) {
  return `${m.article ? `${m.article} ` : ""}${m.word}`;
}
function widthOf(m: FamilyMember) {
  return Math.round(Math.max(78, labelOf(m).length * 8.7 + 34));
}
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const r2 = (v: number) => Math.round(v * 100) / 100;

/**
 * Sector layout: each part of speech owns its own angular sector (so verbs,
 * nouns, adjectives and adverbs form readable clusters), and inside a sector
 * every node claims an angular slice proportional to its own pixel width.
 * A node moves to the next ring as soon as its slice no longer fits, which
 * makes label overlap impossible.
 */
function layout(members: FamilyMember[]) {
  const groups = POS_ORDER.map((pos) => ({
    pos,
    list: members
      .filter((m) => m.pos === pos)
      .sort((a, b) => a.cefr.localeCompare(b.cefr) || a.word.localeCompare(b.word, "de")),
  })).filter((g) => g.list.length > 0);

  const totalCount = groups.reduce((s, g) => s + g.list.length, 0) || 1;
  const TAU = Math.PI * 2;
  const PAD = groups.length > 1 ? 0.1 : 0; // breathing room between sectors

  type Slot = { member: FamilyMember; angle: number; ring: number };
  const slots: Slot[] = [];
  let maxRing = 0;
  let cursor = -Math.PI / 2 - Math.PI / 6; // start slightly above-left

  groups.forEach((g) => {
    const span = TAU * (g.list.length / totalCount);
    const usable = Math.max(span - PAD, span * 0.6);
    const start = cursor + (span - usable) / 2;
    cursor += span;

    // fill rings inside this sector, outward, keeping every label separated
    let ring = 0;
    let a = start;
    let placedInRing = 0;
    g.list.forEach((m) => {
      const radius = FIRST_RING + ring * RING_GAP;
      const need = (widthOf(m) + GAP) / (radius * SQUASH);
      if (placedInRing && a + need > start + usable) {
        ring += 1;
        a = start;
        placedInRing = 0;
      }
      const r2adius = FIRST_RING + ring * RING_GAP;
      const need2 = (widthOf(m) + GAP) / (r2adius * SQUASH);
      slots.push({ member: m, angle: a + need2 / 2, ring });
      a += need2;
      placedInRing += 1;
      maxRing = Math.max(maxRing, ring);
    });

    // centre each ring's content inside the sector for a tidy fan shape
    for (let ri = 0; ri <= maxRing; ri++) {
      const inRing = slots.filter((s) => s.ring === ri && g.list.includes(s.member));
      if (inRing.length < 2) continue;
      const first = inRing[0].angle;
      const last = inRing[inRing.length - 1].angle;
      const shift = start + usable / 2 - (first + last) / 2;
      inRing.forEach((s) => {
        s.angle += shift;
      });
    }
  });

  const ringRadii = Array.from({ length: maxRing + 1 }, (_, i) => FIRST_RING + i * RING_GAP);
  const half = (ringRadii[ringRadii.length - 1] ?? FIRST_RING) + 140;
  const size = half * 2;
  const c = half;

  const placed: Placed[] = slots.map((s) => {
    const radius = FIRST_RING + s.ring * RING_GAP;
    return {
      member: s.member,
      x: r2(c + Math.cos(s.angle) * radius),
      y: r2(c + Math.sin(s.angle) * radius * SQUASH),
      w: widthOf(s.member),
      ring: s.ring,
    };
  });

  return { placed, size, c, rings: ringRadii };
}

/**
 * Radial word-family map: the shared root sits in the middle, every derived
 * word orbits around it on a collision-free ring.
 */
export function FamilyGraph({ root, members, selectedId, onSelect }: Props) {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [hover, setHover] = useState<string | null>(null);
  const drag = useRef<{ x: number; y: number; px: number; py: number; moved: boolean } | null>(
    null,
  );
  const movedRef = useRef(false);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const { placed, size, c, rings } = useMemo(() => layout(members), [members]);
  const reset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const hovered = placed.find((p) => p.member.id === hover)?.member ?? null;
  const focusId = hover ?? selectedId;

  /** Zoom around a point given in viewBox units. */
  const zoomAt = useCallback((next: number, px: number, py: number) => {
    setZoom((prevZoom) => {
      const target = clamp(next, MIN_ZOOM, MAX_ZOOM);
      const k = target / prevZoom;
      setPan((prev) => ({
        x: r2(px - (px - prev.x) * k),
        y: r2(py - (py - prev.y) * k),
      }));
      return target;
    });
  }, []);

  const zoomAtRef = useRef(zoomAt);
  zoomAtRef.current = zoomAt;
  const zoomStateRef = useRef(zoom);
  zoomStateRef.current = zoom;
  const sizeRef = useRef(size);
  sizeRef.current = size;

  // Scrolling over the graph must scroll the page, not zoom the graph.
  // Zoom stays available via the buttons and via Ctrl/⌘ + wheel (pinch-zoom).
  useEffect(() => {
    const el = svgRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return; // let the page scroll
      e.preventDefault();
      const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1);
      const rect = el.getBoundingClientRect();
      const k = sizeRef.current / (rect.width || 1);
      const px = (e.clientX - rect.left) * k;
      const py = (e.clientY - rect.top) * k;
      zoomAtRef.current(zoomStateRef.current * Math.exp(-dy * 0.0018), px, py);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  return (
    <div className="relative overflow-hidden rounded-3xl border border-border/60 bg-gradient-to-br from-secondary/70 to-card">
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
        style={{ background: "var(--section-accent)", opacity: 0.16 }}
      />

      <div className="absolute right-3 top-3 z-10 flex flex-col gap-1.5">
        <GraphButton label="Vergrößern" onClick={() => zoomAt(zoom * 1.25, size / 2, size / 2)}>
          <Plus className="h-4 w-4" />
        </GraphButton>
        <GraphButton label="Verkleinern" onClick={() => zoomAt(zoom / 1.25, size / 2, size / 2)}>
          <Minus className="h-4 w-4" />
        </GraphButton>
        <GraphButton label="Einpassen" onClick={reset}>
          <Maximize2 className="h-4 w-4" />
        </GraphButton>
        <GraphButton label="Zurücksetzen" onClick={reset}>
          <RotateCcw className="h-4 w-4" />
        </GraphButton>
      </div>

      {hovered && (
        <div className="pointer-events-none absolute left-3 top-3 z-10 max-w-[62%] rounded-2xl border border-border/60 bg-card/95 px-3 py-2 shadow-sm backdrop-blur">
          <div className="flex items-center gap-2 text-sm font-black">
            {labelOf(hovered)}
            <span className="rounded-md bg-secondary px-1.5 py-0.5 text-[9px] font-black">
              {hovered.cefr}
            </span>
          </div>
          <div className="text-[11px] text-muted-foreground">{hovered.meaningDe}</div>
          <div className="text-[11px] font-semibold" dir="rtl">
            {hovered.meaningFa}
          </div>
          <div className="mt-1 font-mono text-[10px] text-muted-foreground">
            {[hovered.prefix, hovered.root, hovered.suffix].filter(Boolean).join(" + ")}
          </div>
        </div>
      )}

      <svg
        ref={svgRef}
        viewBox={`0 0 ${size} ${size}`}
        className="block h-auto w-full cursor-grab touch-pan-y select-none active:cursor-grabbing"
        role="img"
        aria-label={`Wortfamilie von ${root.label}`}
        onPointerDown={(e) => {
          drag.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y, moved: false };
          movedRef.current = false;
        }}
        onPointerMove={(e) => {
          if (!drag.current) return;
          const el = e.currentTarget as SVGSVGElement;
          const k = size / el.getBoundingClientRect().width;
          const dx = e.clientX - drag.current.x;
          const dy = e.clientY - drag.current.y;
          if (Math.abs(dx) + Math.abs(dy) > 6) {
            if (!drag.current.moved) {
              // Only capture once it is really a pan — capturing on pointerdown
              // would retarget the click to the <svg> and kill node selection.
              try {
                el.setPointerCapture(e.pointerId);
              } catch {
                /* ignore */
              }
            }
            drag.current.moved = true;
            movedRef.current = true;
            setPan({ x: drag.current.px + dx * k, y: drag.current.py + dy * k });
          }
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
        onPointerCancel={() => {
          drag.current = null;
        }}
      >
        <g
          transform={`translate(${pan.x} ${pan.y}) translate(${c} ${c}) scale(${zoom}) translate(${-c} ${-c})`}
        >
          {rings.map((r) => (
            <ellipse
              key={r}
              cx={c}
              cy={c}
              rx={r}
              ry={r * SQUASH}
              fill="none"
              stroke="currentColor"
              strokeOpacity={0.08}
              strokeDasharray="4 7"
              className="text-foreground"
            />
          ))}

          {/* links */}
          {placed.map(({ member, x, y }, i) => {
            const mx = Math.round(((c + x) / 2 + (y - c) * 0.14) * 100) / 100;
            const my = Math.round(((c + y) / 2 - (x - c) * 0.14) * 100) / 100;
            const active = focusId === member.id;
            const dim = focusId !== null && !active;
            return (
              <motion.path
                key={`l-${member.id}`}
                d={`M ${c} ${c} Q ${mx} ${my} ${x} ${y}`}
                fill="none"
                stroke={POS_COLOR[member.pos]}
                strokeWidth={active ? 3.6 : 1.7}
                strokeOpacity={active ? 0.95 : dim ? 0.14 : 0.34}
                strokeLinecap="round"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ pathLength: 1, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.03 * i, ease: "easeOut" }}
              />
            );
          })}

          {/* nodes */}
          {placed.map(({ member, x, y, w }, i) => {
            const active = selectedId === member.id;
            const hot = hover === member.id;
            const color = POS_COLOR[member.pos];
            const dim = focusId !== null && focusId !== member.id;
            return (
              <motion.g
                key={member.id}
                initial={{ opacity: 0, scale: 0.72 }}
                animate={{ opacity: dim ? 0.42 : 1, scale: active || hot ? 1.07 : 1 }}
                transition={{
                  type: "spring",
                  stiffness: 260,
                  damping: 22,
                  delay: 0.04 + 0.028 * i,
                }}
                style={{ transformOrigin: `${x}px ${y}px`, cursor: "pointer" }}
                onClick={() => {
                  if (!movedRef.current) onSelect(member);
                }}
                onPointerEnter={() => setHover(member.id)}
                onPointerLeave={() => setHover((h) => (h === member.id ? null : h))}
                tabIndex={0}
                role="button"
                aria-label={`${member.word} — ${member.meaningDe}`}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") onSelect(member);
                }}
                onFocus={() => setHover(member.id)}
                onBlur={() => setHover((h) => (h === member.id ? null : h))}
              >
                <rect
                  x={x - w / 2}
                  y={y - NODE_H / 2}
                  width={w}
                  height={NODE_H}
                  rx={13}
                  fill="var(--card)"
                  stroke={color}
                  strokeWidth={active ? 2.8 : 1.4}
                />
                <rect
                  x={x - w / 2}
                  y={y - NODE_H / 2}
                  width={w}
                  height={NODE_H}
                  rx={13}
                  fill={color}
                  opacity={active ? 0.22 : hot ? 0.14 : 0.07}
                />
                <circle cx={x - w / 2 + 13} cy={y} r={3.6} fill={color} />
                <text
                  x={x + 7}
                  y={y + 1}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  className="fill-foreground"
                  style={{ fontSize: 14.5, fontWeight: 700 }}
                >
                  {labelOf(member)}
                </text>
                <text
                  x={x + w / 2 - 8}
                  y={y - NODE_H / 2 + 8}
                  textAnchor="end"
                  dominantBaseline="middle"
                  fill={color}
                  style={{ fontSize: 9, fontWeight: 800 }}
                >
                  {member.cefr}
                </text>
              </motion.g>
            );
          })}

          {/* root in the center */}
          <motion.g
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 18 }}
            style={{ transformOrigin: `${c}px ${c}px` }}
          >
            <circle cx={c} cy={c} r={92} fill="var(--section-accent)" opacity={0.15} />
            <circle cx={c} cy={c} r={72} fill="var(--section-primary)" />
            <text
              x={c}
              y={c - 10}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="#fff"
              style={{ fontSize: 24, fontWeight: 900 }}
            >
              {root.root}-
            </text>
            <text
              x={c}
              y={c + 16}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="#fff"
              opacity={0.85}
              style={{ fontSize: 12, fontWeight: 600 }}
            >
              {root.meaningDe}
            </text>
          </motion.g>
        </g>
      </svg>

      <div className="flex flex-wrap items-center gap-3 border-t border-border/60 px-4 py-2.5 text-[10px] font-semibold text-muted-foreground">
        {POS_ORDER.map((pos) => (
          <span key={pos} className="flex items-center gap-1.5">
            <i className="h-2.5 w-2.5 rounded-full" style={{ background: POS_COLOR[pos] }} />
            {POS_LABEL[pos].de} · {POS_LABEL[pos].fa}
          </span>
        ))}
        <span className="ml-auto hidden sm:inline">Ziehen · Scrollen zum Zoomen · Tab + Enter</span>
      </div>
    </div>
  );
}

function GraphButton({
  children,
  label,
  onClick,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className="grid h-8 w-8 place-items-center rounded-lg border border-border/60 bg-card/90 text-muted-foreground backdrop-blur transition hover:bg-secondary"
    >
      {children}
    </button>
  );
}
