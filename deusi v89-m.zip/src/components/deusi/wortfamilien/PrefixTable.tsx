import { useState } from "react";
import { FaHint } from "@/components/deusi/FaHint";
import { PREFIXES, SUFFIXES } from "@/lib/deusi/wordfamilies/prefixes";

type Props = {
  /** Filter the word list by clicking a prefix */
  onPickPrefix?: (prefix: string) => void;
  activePrefix?: string | null;
};

export function PrefixTable({ onPickPrefix, activePrefix }: Props) {
  const [tab, setTab] = useState<"prefix" | "suffix">("prefix");
  const rows = tab === "prefix" ? PREFIXES : SUFFIXES;

  return (
    <section className="rounded-3xl border border-border/60 bg-card p-4 sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-black">Präfixe & Suffixe</h2>
          <FaHint>جدول پیشوندها و پسوندهای پرکاربرد — کلیک کن تا واژه‌های مرتبط فیلتر شوند.</FaHint>
        </div>
        <div className="flex gap-1 rounded-xl border border-border/60 bg-secondary/60 p-1">
          {(["prefix", "suffix"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${
                tab === t ? "bg-card shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === "prefix" ? "Präfixe" : "Suffixe"}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {rows.map((p) => {
          const active = activePrefix === p.prefix;
          const clickable = tab === "prefix" && !!onPickPrefix;
          return (
            <button
              key={p.prefix}
              type="button"
              disabled={!clickable}
              onClick={() => onPickPrefix?.(active ? "" : p.prefix)}
              className={`rounded-2xl border p-3 text-left transition ${
                active ? "border-[color:var(--section-accent)] bg-secondary" : "border-border/60"
              } ${clickable ? "hover:bg-secondary" : "cursor-default"}`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-sm font-black">
                  {tab === "prefix" ? `${p.prefix}-` : `-${p.prefix}`}
                </span>
                {tab === "prefix" && (
                  <span
                    className={`rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase ${
                      p.separable
                        ? "bg-emerald-500/12 text-emerald-600"
                        : "bg-rose-500/12 text-rose-600"
                    }`}
                  >
                    {p.separable ? "trennbar" : "nicht trennbar"}
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">{p.meaningDe}</div>
              <div className="text-xs" dir="rtl">
                {p.meaningFa}
              </div>
              <div className="mt-1.5 text-xs font-bold">
                {p.example}{" "}
                <span className="font-normal text-muted-foreground" dir="rtl">
                  {p.exampleMeaningFa}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
