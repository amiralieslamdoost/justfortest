import type { FamilyMember } from "@/lib/deusi/wordfamilies/types";

type Props = {
  member: FamilyMember;
  size?: "sm" | "md" | "lg";
  showLegend?: boolean;
};

const SIZES = {
  sm: "text-xs px-1.5 py-0.5",
  md: "text-sm px-2 py-1",
  lg: "text-lg px-2.5 py-1.5",
} as const;

/**
 * Colored split of a word into prefix + root + suffix, so learners can *see*
 * how German builds words out of a shared root.
 */
export function MorphemeBreakdown({ member, size = "md", showLegend = false }: Props) {
  const pad = SIZES[size];
  // The word may contain umlaut changes, so we render the authored morphemes
  // rather than slicing the string.
  const rest = member.word
    .replace(new RegExp(`^${member.prefix ?? ""}`, "i"), "")
    .replace(new RegExp(`${member.suffix ?? ""}$`, "i"), "");

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-1 font-mono font-bold">
        {member.prefix && (
          <span className={`rounded-md bg-[#f9731615] ${pad} text-[#ea580c]`} title="Präfix">
            {member.prefix}
          </span>
        )}
        <span
          className={`rounded-md bg-[color:var(--section-accent)]/15 ${pad} text-[color:var(--section-primary)] dark:text-[color:var(--section-accent)]`}
          title="Wortstamm"
        >
          {rest || member.root}
        </span>
        {member.suffix && (
          <span className={`rounded-md bg-[#8b5cf615] ${pad} text-[#7c3aed]`} title="Suffix">
            {member.suffix}
          </span>
        )}
        {member.prefix && (
          <span
            className={`ml-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
              member.separable
                ? "bg-emerald-500/12 text-emerald-600"
                : "bg-rose-500/12 text-rose-600"
            }`}
          >
            {member.separable ? "trennbar" : "nicht trennbar"}
          </span>
        )}
      </div>
      {showLegend && (
        <div className="flex flex-wrap gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <i className="h-2 w-2 rounded-full bg-[#ea580c]" /> Präfix · پیشوند
          </span>
          <span className="flex items-center gap-1">
            <i className="h-2 w-2 rounded-full bg-[color:var(--section-accent)]" /> Stamm · ریشه
          </span>
          <span className="flex items-center gap-1">
            <i className="h-2 w-2 rounded-full bg-[#7c3aed]" /> Suffix · پسوند
          </span>
        </div>
      )}
    </div>
  );
}
