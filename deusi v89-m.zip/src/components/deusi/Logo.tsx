export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5" dir="ltr">
      <div
        aria-label="DEUSI"
        role="img"
        className="flex h-10 w-10 shrink-0 items-end justify-center gap-[3px] rounded-xl bg-white px-1.5 pb-1.5 pt-1 shadow-sm ring-1 ring-black/5 dark:ring-white/10"
      >
        <span
          className="deusi-bar block w-1.5 rounded-sm"
          style={{
            height: "70%",
            background: "var(--flag-black)",
            ["--rest" as string]: "0.5",
            animationDelay: "0s",
          }}
        />
        <span
          className="deusi-bar block w-1.5 rounded-sm"
          style={{
            height: "70%",
            background: "var(--flag-red)",
            ["--rest" as string]: "0.75",
            animationDelay: "0.2s",
          }}
        />
        <span
          className="deusi-bar block w-1.5 rounded-sm"
          style={{
            height: "70%",
            background: "var(--flag-gold)",
            ["--rest" as string]: "0.9",
            animationDelay: "0.4s",
          }}
        />
      </div>
      {!compact && (
        <div className="leading-none">
          <div className="text-xl font-bold tracking-tight">DEUSI</div>
          <div className="mt-1 text-[10px] text-muted-foreground">Deutsch. Einfach. Meistern.</div>
        </div>
      )}
    </div>
  );
}
