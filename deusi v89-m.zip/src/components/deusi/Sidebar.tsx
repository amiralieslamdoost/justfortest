import { Link, useRouterState } from "@tanstack/react-router";

import { type ReactNode } from "react";
import { Logo } from "./Logo";
import {
  HomeIcon,
  SearchIcon,
  BookIcon,
  WordFamilyIcon,
  BookmarkIcon,
  GrammarNavIcon as GrammarIcon,
  PencilIcon,
  ReadIcon,
  BoxIcon,
  SparkleIcon,
  HeadphoneIcon,
  MusicNoteIcon,
  FilmIcon,
  CertificateIcon,
  CalendarIcon,
  ChatIcon,
  ChartIcon,
  TrophyIcon,
  UserIcon,
  CrownIcon,
  BellIcon,
  GearIcon,
  LifebuoyIcon,
  DocsIcon,
} from "@/components/deusi/icons/NavIcons";

type Item = {
  to?:
    | "/learn"
    | "/planer"
    | "/dictionary"
    | "/dashboard"
    | "/statistiken"
    | "/podcasts"
    | "/musik"
    | "/lesen"
    | "/grammatik"
    | "/leitner"
    | "/events"
    | "/profil"
    | "/pruefungen"
    | "/ki-coach"
    | "/kino"
    | "/docs"
    | "/verben"
    | "/schreiben"
    | "/community"
    | "/achievements"
    | "/lesezeichen"
    | "/suche"
    | "/abonnement"
    | "/einstellungen"
    | "/benachrichtigungen"
    | "/support";
  label: string;
  icon: ReactNode;
  comingSoon?: boolean;
};

type Group = { title: string; items: Item[] };

const groups: Group[] = [
  {
    title: "Übersicht",
    items: [
      { to: "/dashboard", label: "Start", icon: <HomeIcon /> },
      { to: "/planer", label: "Smart Planner", icon: <CalendarIcon /> },
      { to: "/suche", label: "Suche", icon: <SearchIcon /> },
    ],
  },
  {
    title: "Werkzeuge",
    items: [
      { to: "/dictionary", label: "Wörterbuch", icon: <BookIcon /> },
      { to: "/verben", label: "Wortfamilien", icon: <WordFamilyIcon /> },
      { to: "/lesezeichen", label: "Lesezeichen", icon: <BookmarkIcon /> },
    ],
  },
  {
    title: "Lernen",
    items: [
      { to: "/grammatik", label: "Grammatik", icon: <GrammarIcon /> },
      { to: "/schreiben", label: "Schreiben", icon: <PencilIcon /> },
      { to: "/lesen", label: "Lesen", icon: <ReadIcon /> },
      { to: "/leitner", label: "Leitner-Box", icon: <BoxIcon /> },
      { to: "/ki-coach", label: "KI-Coach", icon: <SparkleIcon /> },
    ],
  },
  {
    title: "Medien",
    items: [
      { to: "/podcasts", label: "Podcasts", icon: <HeadphoneIcon /> },
      { to: "/musik", label: "Musik", icon: <MusicNoteIcon /> },
      { to: "/kino", label: "Filme & Serien", icon: <FilmIcon /> },
    ],
  },
  {
    title: "Informationen",
    items: [
      { to: "/pruefungen", label: "Prüfungen", icon: <CertificateIcon /> },
      { to: "/events", label: "Events", icon: <CalendarIcon /> },
    ],
  },
  {
    title: "Community",
    items: [{ to: "/community", label: "Community", icon: <ChatIcon /> }],
  },
  {
    title: "Fortschritt",
    items: [
      { to: "/statistiken", label: "Statistik", icon: <ChartIcon /> },
      { to: "/achievements", label: "Erfolge", icon: <TrophyIcon /> },
    ],
  },
  {
    title: "Konto",
    items: [
      { to: "/profil", label: "Profil", icon: <UserIcon /> },
      { to: "/abonnement", label: "Abonnement", icon: <CrownIcon /> },
      { to: "/benachrichtigungen", label: "Benachrichtigungen", icon: <BellIcon /> },
      { to: "/einstellungen", label: "Einstellungen", icon: <GearIcon /> },
      { to: "/support", label: "Support", icon: <LifebuoyIcon /> },
      { to: "/docs", label: "Dokumentation", icon: <DocsIcon /> },
    ],
  },
];

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <aside className="sidebar-pill sticky top-5 hidden h-[calc(100vh-2.5rem)] w-[240px] shrink-0 flex-col gap-3 px-2.5 py-5 lg:flex">
      <div className="flex items-center justify-center">
        <Link to="/" className="grid h-11 min-w-0 place-items-center" aria-label="DEUSI">
          <Logo compact />
        </Link>
      </div>

      <div className="relative min-h-0 flex-1">
        <nav className="sidebar-scroll flex h-full flex-col overflow-y-auto pb-6 pr-0.5">
          {groups.map((group) => (
            <div key={group.title} className="mb-1.5 flex flex-col gap-0.5">
              <div className="px-3 pb-1 pt-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/70">
                {group.title}
              </div>
              {group.items.map((it, i) => renderItem(it, `${group.title}-${i}`, pathname))}
            </div>
          ))}
        </nav>
        <div
          aria-hidden
          className="sidebar-fade pointer-events-none absolute inset-x-0 bottom-0 h-8"
        />
      </div>
    </aside>
  );
}

function renderItem(it: Item, key: string, pathname: string) {
  const active = it.to && (pathname === it.to || pathname.startsWith(`${it.to}/`));

  if (it.comingSoon || !it.to) {
    return (
      <div
        key={key}
        role="link"
        aria-disabled="true"
        title={`${it.label} (bald)`}
        className="side-item pointer-events-none select-none opacity-50"
      >
        <span className="grid h-9 w-9 shrink-0 place-items-center">{it.icon}</span>
        <span className="side-label flex-1">{it.label}</span>
      </div>
    );
  }

  return (
    <Link
      key={key}
      to={it.to}
      title={it.label}
      aria-current={active ? "page" : undefined}
      className={`side-item relative ${active ? "active" : ""}`}
    >
      <span className="relative z-10 grid h-9 w-9 shrink-0 place-items-center">{it.icon}</span>
      <span className="side-label relative z-10 flex-1">{it.label}</span>
    </Link>
  );
}
