import { Fa } from "@/components/deusi/Fa";

export interface DailyTipCardProps {
  className?: string;
}

export function DailyTipCard({ className = "" }: DailyTipCardProps) {
  return (
    <div
      className={`group relative overflow-hidden rounded-[1.75rem] p-6 text-white shadow-[0_24px_60px_-24px_rgba(221,34,34,0.55)] sm:p-7 ${className}`}
      style={{
        background: "linear-gradient(135deg, #b91c1c 0%, #dd2222 42%, #f59e0b 100%)",
      }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-28 h-72 w-72 rounded-full bg-white/25 blur-3xl transition-transform duration-700 group-hover:scale-110"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-24 -left-20 h-64 w-64 rounded-full bg-black/20 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />
      <div className="relative">
        <div className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-white ring-1 ring-white/30 backdrop-blur">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
          Tipp des Tages
        </div>
        <Fa className="fa-hint-xs mt-1 !text-[11px] !text-white/85 !opacity-100">نکته‌ی روز</Fa>
      </div>
      <blockquote className="relative mt-4 text-lg font-black leading-snug sm:text-xl">
        „Kleine Fortschritte führen zu großen Veränderungen."
      </blockquote>
      <Fa className="fa-hint-xs relative mt-1 !text-sm !text-white/90 !opacity-100">
        پیشرفت‌های کوچک، تغییرات بزرگ می‌سازند.
      </Fa>
      <p className="relative mt-4 text-sm text-white/85">
        Lerne täglich nur 15 Minuten — Konstanz schlägt Intensität. Wiederhole schwierige Karten aus
        Box 2 vor dem Schlafengehen für die beste Erinnerung.
      </p>
    </div>
  );
}
