import { useEffect } from "react";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { Fa } from "@/components/deusi/Fa";

function AnimatedNumber({ value, duration = 1.1 }: { value: number; duration?: number }) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (latest: number) => Math.round(latest).toLocaleString("de-DE"));
  useEffect(() => {
    const controls = animate(mv, value, { duration, ease: [0.2, 0.8, 0.2, 1] });
    return controls.stop;
  }, [value, duration, mv]);
  return <motion.span>{rounded}</motion.span>;
}

export interface DailyGoalRingCardProps {
  done: number;
  goal: number;
  pct: number;
  className?: string;
}

export function DailyGoalRingCard({ done, goal, pct, className = "" }: DailyGoalRingCardProps) {
  const ringSize = 148;
  const ringPadding = 18;
  const size = ringSize + ringPadding * 2;
  const stroke = 13;
  const center = size / 2;
  const r = (ringSize - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;

  return (
    <div className={`group relative ${className}`}>
      <div
        className="relative flex h-full flex-col items-center justify-center overflow-hidden rounded-3xl px-4 py-6 text-center text-white ring-1 ring-white/10 sm:px-5"
        style={{ background: "var(--daily-goal-bg)" }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute right-0 top-0 h-40 w-40 -translate-y-1/4 translate-x-1/4 rounded-full bg-[color:var(--flag-gold)]/25 blur-3xl transition-transform duration-700 group-hover:scale-110"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute bottom-0 left-0 h-40 w-40 translate-y-1/4 -translate-x-1/4 rounded-full bg-[color:var(--flag-red)]/35 blur-3xl"
        />

        <div className="relative z-10 flex flex-col items-center">
          <span className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] ring-1 ring-white/25 backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--flag-gold)]" />
            Tagesziel
          </span>

          <div className="relative" style={{ width: size, height: size }}>
            <svg
              width={size}
              height={size}
              viewBox={`0 0 ${size} ${size}`}
              className="-rotate-90 overflow-visible"
            >
              <defs>
                <linearGradient id="dailyGoalGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="var(--daily-goal-ring-start)" />
                  <stop offset="100%" stopColor="var(--daily-goal-ring-end)" />
                </linearGradient>
              </defs>
              <circle
                cx={center}
                cy={center}
                r={r}
                fill="none"
                stroke="rgba(255,255,255,0.15)"
                strokeWidth={stroke}
              />
              <motion.circle
                cx={center}
                cy={center}
                r={r}
                fill="none"
                stroke="url(#dailyGoalGrad)"
                strokeWidth={stroke}
                strokeLinecap="round"
                strokeDasharray={c}
                initial={{ strokeDashoffset: c }}
                animate={{ strokeDashoffset: offset }}
                transition={{ duration: 1.2, ease: [0.2, 0.8, 0.2, 1] }}
                style={{ filter: "drop-shadow(0 0 8px var(--daily-goal-ring-glow))" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-3xl font-black tabular-nums leading-none">
                <AnimatedNumber value={pct} />
                <span className="text-lg opacity-80">%</span>
              </div>
              <div className="mt-1 text-[10px] font-bold tracking-wider text-white/75">
                {done}/{goal} XP
              </div>
            </div>
          </div>

          <Fa className="fa-hint-xs mt-1 !text-base !font-black !text-white/90 !opacity-100">
            هدف روزانه
          </Fa>
        </div>
      </div>
    </div>
  );
}
