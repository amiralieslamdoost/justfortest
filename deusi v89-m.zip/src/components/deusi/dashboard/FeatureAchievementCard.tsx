import { Fa } from "@/components/deusi/Fa";

export interface FeatureAchievementCardProps {
  className?: string;
}

export function FeatureAchievementCard({ className = "" }: FeatureAchievementCardProps) {
  return (
    <div
      className={`relative flex flex-col items-center justify-center overflow-hidden rounded-[1.75rem] p-6 text-center text-white shadow-xl ${className}`}
      style={{
        background: "linear-gradient(135deg, #F7C948 0%, #DD8912 60%, #92400E 130%)",
      }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/20 blur-2xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-white/10 blur-2xl"
      />
      <div className="relative">
        <div className="grid h-16 w-16 place-items-center rounded-full border border-white/40 bg-white/20 backdrop-blur">
          <span className="text-3xl">🏆</span>
        </div>
      </div>
      <div className="relative mt-4 text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">
        Nächstes Ziel
      </div>
      <h3 className="relative mt-1 text-xl font-black uppercase tracking-tight leading-tight">
        14-Tage-Serie
      </h3>
      <Fa className="fa-hint-xs relative !text-white/85">سری ۱۴ روزه</Fa>
      <div className="relative mt-4 w-full">
        <div className="h-2 w-full overflow-hidden rounded-full bg-white/25">
          <div className="dash-bar h-full rounded-full bg-white/90" style={{ width: "78%" }} />
        </div>
        <div className="mt-1.5 text-[10px] font-bold opacity-90">
          11 / 14 Tage · fast geschafft!
        </div>
      </div>
    </div>
  );
}
