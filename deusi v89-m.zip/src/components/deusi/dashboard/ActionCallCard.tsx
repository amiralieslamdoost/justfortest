import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import { SECTION_THEME, type SectionKey } from "@/lib/deusi/sectionTheme";
import { ArrowRightIcon } from "./icons";

export interface ActionCallCardProps {
  className?: string;
  sectionKey: SectionKey;
  eyebrow: string;
  eyebrowFa: string;
  title: string;
  subtitle: string;
  subtitleFa: string;
  cta: { to: string; label: string };
  emoji: string;
  chips?: string[];
  progress?: { label: string; pct: number };
}

export function ActionCallCard({
  className = "",
  sectionKey,
  eyebrow,
  eyebrowFa,
  title,
  subtitle,
  subtitleFa,
  cta,
  emoji,
  chips = [],
  progress,
}: ActionCallCardProps) {
  const theme = SECTION_THEME[sectionKey];
  return (
    <div className={`neu-card group relative flex flex-col overflow-hidden p-0 ${className}`}>
      {/* Colored top band */}
      <div
        className="relative flex items-center gap-3 px-5 py-4 text-white sm:px-6"
        style={{
          backgroundImage: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.accent} 100%)`,
        }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute -right-8 -top-10 h-28 w-28 rounded-full bg-white/25 blur-2xl transition-transform duration-700 group-hover:scale-110"
        />
        <div className="relative grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/20 text-2xl ring-1 ring-white/30 backdrop-blur">
          {emoji}
        </div>
        <div className="relative min-w-0">
          <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/90">
            {eyebrow}
          </div>
          <Fa className="fa-hint-xs !text-[10px] !text-white/80 !opacity-100">{eyebrowFa}</Fa>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <div className="text-lg font-black leading-tight">{title}</div>
        <div className="mt-1 text-xs text-muted-foreground">{subtitle}</div>
        <Fa className="fa-hint-xs">{subtitleFa}</Fa>

        {chips.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {chips.map((ch) => (
              <span
                key={ch}
                className="rounded-full px-2.5 py-1 text-[10px] font-bold tabular-nums"
                style={{
                  background: `color-mix(in oklab, ${theme.primary} 14%, transparent)`,
                  color: theme.primary,
                }}
              >
                {ch}
              </span>
            ))}
          </div>
        )}

        {progress && (
          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between text-[10px] font-bold text-muted-foreground">
              <span>{progress.label}</span>
              <span className="tabular-nums">{progress.pct}%</span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-[color:var(--muted)]">
              <div
                className="h-full rounded-full transition-[width] duration-700"
                style={{
                  width: `${progress.pct}%`,
                  backgroundImage: `linear-gradient(90deg, ${theme.primary}, ${theme.accent})`,
                }}
              />
            </div>
          </div>
        )}

        <Link
          to={cta.to as never}
          className="mt-auto inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5 pt-3"
          style={{
            marginTop: "1.25rem",
            backgroundImage: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.accent} 100%)`,
          }}
        >
          {cta.label} <ArrowRightIcon />
        </Link>
      </div>
    </div>
  );
}
