import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import { SECTION_THEME, type SectionKey } from "@/lib/deusi/sectionTheme";
import { ArrowRightIcon } from "./icons";

type ShortcutMeta = {
  key: SectionKey;
  to:
    | "/dictionary"
    | "/learn"
    | "/grammatik"
    | "/leitner"
    | "/lesen"
    | "/podcasts"
    | "/musik"
    | "/kino"
    | "/statistiken"
    | "/pruefungen"
    | "/events"
    | "/schreiben"
    | "/verben"
    | "/ki-coach"
    | "/achievements";
  labelDe: string;
  labelFa: string;
  stat: string;
  span: string;
  h?: string;
};

const SHORTCUTS: ShortcutMeta[] = [
  {
    key: "dictionary",
    to: "/dictionary",
    labelDe: "Wörterbuch",
    labelFa: "دیکشنری",
    stat: "356 Wörter",
    span: "md:col-span-5",
  },
  {
    key: "grammar",
    to: "/grammatik",
    labelDe: "Grammatik",
    labelFa: "دستور زبان",
    stat: "8 Lektionen · 45%",
    span: "md:col-span-3",
  },
  {
    key: "verbs",
    to: "/verben",
    labelDe: "Wortfamilien",
    labelFa: "خانواده واژه‌ها",
    stat: "Wortstämme & Präfixe",

    span: "md:col-span-4",
  },

  {
    key: "leitner",
    to: "/leitner",
    labelDe: "Leitner Box",
    labelFa: "لایتنر",
    stat: "5 Boxen · fällig",
    span: "md:col-span-3",
  },
  {
    key: "reading",
    to: "/lesen",
    labelDe: "Lesen",
    labelFa: "خواندن",
    stat: "40 Artikel",
    span: "md:col-span-3",
  },
  {
    key: "podcasts",
    to: "/podcasts",
    labelDe: "Podcasts",
    labelFa: "پادکست",
    stat: "12 Episoden",
    span: "md:col-span-6",
  },

  {
    key: "music",
    to: "/musik",
    labelDe: "Musik",
    labelFa: "موزیک",
    stat: "13 Songs",
    span: "md:col-span-4",
  },
  {
    key: "movies",
    to: "/kino",
    labelDe: "Kino",
    labelFa: "فیلم",
    stat: "5 Filme",
    span: "md:col-span-4",
  },
  {
    key: "ai-coach",
    to: "/ki-coach",
    labelDe: "KI Coach",
    labelFa: "مربی هوش مصنوعی",
    stat: "24/7 · Chat",
    span: "md:col-span-4",
  },

  {
    key: "writing",
    to: "/schreiben",
    labelDe: "Schreiben",
    labelFa: "نوشتن",
    stat: "KI-Feedback",
    span: "md:col-span-4",
  },
  {
    key: "statistics",
    to: "/statistiken",
    labelDe: "Statistik",
    labelFa: "آمار",
    stat: "Dein Verlauf",
    span: "md:col-span-5",
  },
  {
    key: "exams",
    to: "/pruefungen",
    labelDe: "Prüfungen",
    labelFa: "آزمون‌ها",
    stat: "Goethe · telc",
    span: "md:col-span-3",
  },

  {
    key: "events",
    to: "/events",
    labelDe: "Events",
    labelFa: "رویدادها",
    stat: "5 offen",
    span: "md:col-span-6",
  },
  {
    key: "achievements",
    to: "/achievements",
    labelDe: "Erfolge",
    labelFa: "دستاوردها",
    stat: "18 Abzeichen",
    span: "md:col-span-6",
  },
];

export function SectionBento() {
  return (
    <div className="dash-stagger grid grid-cols-2 gap-3 md:grid-cols-12 md:gap-4">
      {SHORTCUTS.map((s) => (
        <SectionTile
          key={s.key}
          meta={s}
          className={`aspect-square md:aspect-auto md:min-h-[168px] ${s.span} ${s.h ?? ""}`}
        />
      ))}
    </div>
  );
}

function SectionTile({ meta, className = "" }: { meta: ShortcutMeta; className?: string }) {
  const theme = SECTION_THEME[meta.key];
  const Icon = theme.Icon;

  return (
    <Link
      to={meta.to}
      className={`group relative col-span-1 flex flex-col justify-between overflow-hidden rounded-3xl p-4 text-white shadow-lg transition-all duration-300 ease-out will-change-transform hover:-translate-y-1 hover:shadow-2xl sm:p-5 ${className}`}
      style={{
        // Saturated take on each section's hero color: primary -> accent, no white wash.
        backgroundImage: `linear-gradient(135deg, ${theme.primary} 0%, color-mix(in oklab, ${theme.accent} 55%, ${theme.primary}) 58%, ${theme.accent} 100%)`,
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden rounded-3xl">
        <div className="absolute -right-10 -top-12 h-36 w-36 rounded-full bg-white/10 blur-2xl transition-all duration-700 group-hover:scale-125 group-hover:bg-white/20" />
        <div
          className="absolute -bottom-12 -left-8 h-32 w-32 rounded-full blur-2xl transition-transform duration-700 group-hover:scale-125"
          style={{ backgroundColor: theme.accent, opacity: 0.45 }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-white/0 transition-colors duration-300 group-hover:bg-white/[0.07]" />
      </div>

      <div className="relative flex items-start justify-between gap-2">
        <div
          aria-hidden
          className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white/95 shadow-md ring-1 ring-white/50 transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110 sm:h-12 sm:w-12"
          style={{ color: theme.primary }}
        >
          <Icon size={22} />
        </div>
        <ArrowRightIcon className="shrink-0 text-white/70 transition-all duration-300 group-hover:translate-x-1 group-hover:text-white" />
      </div>

      <div className="relative mt-4 min-w-0">
        <div className="flex items-end justify-between gap-2">
          <div className="truncate text-lg font-black leading-tight sm:text-xl">{meta.labelDe}</div>
        </div>
        <div className="mt-1 flex items-center justify-between gap-2">
          <span className="inline-flex max-w-full items-center truncate rounded-full bg-white/20 px-2.5 py-1 text-[11px] font-bold tabular-nums text-white/95 backdrop-blur transition-colors duration-300 group-hover:bg-white/30">
            {meta.stat}
          </span>
          <Fa className="!m-0 shrink-0 !text-[0.72rem] !font-medium !leading-[1.5] !text-white/85">
            {meta.labelFa}
          </Fa>
        </div>
      </div>
    </Link>
  );
}
