import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import { dailySessions, learnerProfile } from "@/lib/deusi/mockStats";
import { ArrowRightIcon } from "./icons";

const ACTIVITY_GOAL_MIN = learnerProfile.dailyGoalMinutes;

/** Green when the daily learning goal is reached, red when it is missed. */
function activityTone(minutes: number) {
  const ratio = minutes / ACTIVITY_GOAL_MIN;
  if (minutes <= 0) return { kind: "empty" as const, ratio: 0 };
  if (ratio >= 1) return { kind: "goal" as const, ratio: Math.min(ratio, 1.6) };
  return { kind: "miss" as const, ratio };
}

export interface LearningActivityCardProps {
  className?: string;
}

export function LearningActivityCard({ className = "" }: LearningActivityCardProps) {
  const last14 = dailySessions.slice(-14);
  const maxMin = Math.max(...last14.map((d) => d.minutes), 1);
  const totalMin = last14.reduce((s, d) => s + d.minutes, 0);
  const hours = Math.floor(totalMin / 60);
  const mins = totalMin % 60;
  const goalDays = last14.filter((d) => d.minutes >= ACTIVITY_GOAL_MIN).length;

  return (
    <div className={`neu-card p-6 sm:p-7 ${className}`}>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <h3 className="text-lg font-black">Lernaktivität · 14 Tage</h3>
          <Fa className="fa-hint-xs">فعالیت یادگیری در ۱۴ روز اخیر</Fa>
          <div className="mt-1 text-xs text-muted-foreground">
            Insgesamt{" "}
            <span className="font-bold text-foreground">
              {hours}h {mins}m
            </span>{" "}
            ·{" "}
            <span className="tabular-nums">
              {goalDays}/14 Tage Ziel erreicht ({ACTIVITY_GOAL_MIN} Min)
            </span>
          </div>
        </div>
        <Link
          to="/statistiken"
          className="inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold text-foreground transition hover:-translate-y-0.5"
        >
          Alle Statistiken <ArrowRightIcon />
        </Link>
      </div>

      <div className="grid grid-cols-7 gap-2 sm:gap-3 md:grid-cols-14">
        {last14.map((d, i) => {
          const tone = activityTone(d.minutes);
          const date = new Date(d.date);
          const weekday = date.toLocaleDateString("de-DE", { weekday: "short" });
          const day = date.getDate();
          const fillPct =
            tone.kind === "empty" ? 0 : Math.max(22, Math.round((d.minutes / maxMin) * 100));
          const gradient =
            tone.kind === "goal"
              ? "linear-gradient(180deg, var(--act-goal-top), var(--act-goal-bottom))"
              : "linear-gradient(180deg, var(--act-miss-top), var(--act-miss-bottom))";
          return (
            <div key={d.date} className="flex flex-col items-center gap-1.5">
              <div
                className="dash-grow relative flex w-full items-end overflow-hidden rounded-xl bg-secondary/70"
                style={{ height: "72px", animationDelay: `${i * 40}ms` }}
                title={`${weekday} ${day} · ${d.minutes} Min · ${
                  tone.kind === "goal" ? "Ziel erreicht" : "Ziel verfehlt"
                }`}
              >
                {tone.kind !== "empty" && (
                  <div
                    className="relative w-full rounded-xl transition-all"
                    style={{
                      height: `${fillPct}%`,
                      background: gradient,
                      boxShadow:
                        tone.kind === "goal"
                          ? "0 -4px 16px -6px var(--act-goal-glow)"
                          : "0 -4px 16px -6px var(--act-miss-glow)",
                    }}
                  >
                    {fillPct > 34 && (
                      <span className="absolute inset-x-0 bottom-1 text-center text-[9px] font-bold tabular-nums text-white/95">
                        {d.minutes}
                      </span>
                    )}
                  </div>
                )}
              </div>
              <div className="text-[9px] font-semibold text-muted-foreground tabular-nums">
                {day}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-end gap-3 text-[10px] font-bold text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span
            className="h-3 w-3 rounded-sm"
            style={{
              background: "linear-gradient(180deg, var(--act-goal-top), var(--act-goal-bottom))",
            }}
          />
          ZIEL ERREICHT
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span
            className="h-3 w-3 rounded-sm"
            style={{
              background: "linear-gradient(180deg, var(--act-miss-top), var(--act-miss-bottom))",
            }}
          />
          ZIEL VERFEHLT
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-sm bg-secondary" />
          PAUSE
        </span>
      </div>
    </div>
  );
}
