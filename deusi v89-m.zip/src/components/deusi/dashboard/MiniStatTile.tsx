import type { ReactNode } from "react";
import { Fa } from "@/components/deusi/Fa";

export interface MiniStatTileProps {
  emoji: string;
  value: ReactNode;
  label: string;
  labelFa: string;
  gradient: string;
  glow: string;
  dot: string;
}

export function MiniStatTile({
  emoji,
  value,
  label,
  labelFa,
  gradient,
  glow,
  dot,
}: MiniStatTileProps) {
  return (
    <div className="group relative">
      <div
        className="relative flex h-full min-h-36 flex-col items-center justify-center overflow-hidden rounded-3xl p-4 text-center text-white ring-1 ring-white/10 transition-transform duration-300 group-hover:-translate-y-0.5"
        style={{ background: gradient }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute right-0 top-0 h-28 w-28 -translate-y-1/3 translate-x-1/3 rounded-full blur-3xl transition-transform duration-700 group-hover:scale-110"
          style={{ background: glow }}
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-10 left-1/2 h-24 w-24 -translate-x-1/2 rounded-full bg-white/20 blur-2xl"
        />

        <span className="relative mb-2 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.18em] ring-1 ring-white/25 backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: dot }} />
          {label}
        </span>

        <div className="relative grid h-10 w-10 place-items-center rounded-2xl bg-white/10 text-xl ring-1 ring-white/20 backdrop-blur">
          {emoji}
        </div>

        <div className="relative mt-2 text-2xl font-black leading-none tabular-nums">{value}</div>
        <Fa className="fa-hint-xs mt-1 !text-[10px] !text-white/80 !opacity-100">{labelFa}</Fa>
      </div>
    </div>
  );
}
