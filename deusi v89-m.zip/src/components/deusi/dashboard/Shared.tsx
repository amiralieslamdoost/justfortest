import type { ReactNode } from "react";
import { Fa } from "@/components/deusi/Fa";

export function HeroChip({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-2xl bg-white/15 px-3 py-2 text-white ring-1 ring-white/20 backdrop-blur">
      <div className="text-[10px] font-bold uppercase tracking-[0.14em] opacity-80">{label}</div>
      <div className="text-sm font-black tabular-nums leading-tight">{value}</div>
    </div>
  );
}

export function BlockHeader({
  title,
  fa,
  subtitle,
  action,
}: {
  title: string;
  fa: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4 px-1">
      <div className="min-w-0">
        <h2 className="text-xl font-black leading-tight sm:text-2xl">{title}</h2>
        <Fa className="fa-hint-xs mt-0.5">{fa}</Fa>
        {subtitle && <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
