import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import type { DeusiEvent } from "@/lib/deusi/events/mockEvents";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";
import { ArrowRightIcon, ClockIcon, PinIcon } from "./icons";

export interface NextEventCardProps {
  event: DeusiEvent;
  className?: string;
}

export function NextEventCard({ event, className = "" }: NextEventCardProps) {
  const theme = SECTION_THEME.events;
  const dateParts = event.dateShort.split(".");
  const day = dateParts[0]?.trim() ?? "25";
  const month =
    event.dateShort
      .match(/\b([A-Za-zäöüÄÖÜ]+)\b/)?.[1]
      ?.slice(0, 3)
      .toUpperCase() ?? "MAI";

  return (
    <Link
      to="/events/$eventId"
      params={{ eventId: event.id }}
      className={`neu-card group relative flex flex-col overflow-hidden p-0 transition hover:-translate-y-1 ${className}`}
    >
      <div
        className="relative h-32 w-full overflow-hidden"
        style={{
          background: `linear-gradient(135deg, ${theme.base} 0%, ${theme.primary} 60%, ${theme.accent} 130%)`,
        }}
      >
        <div
          aria-hidden
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage: `url(${event.cover})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            mixBlendMode: "overlay",
          }}
        />
        <div className="absolute left-4 top-4 flex flex-col items-center rounded-2xl bg-white/95 px-3 py-2 text-center shadow-lg">
          <span className="text-lg font-black leading-none tabular-nums text-foreground">
            {day}
          </span>
          <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
            {month}
          </span>
        </div>
        <div className="absolute right-4 top-4 rounded-full bg-white/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-white backdrop-blur">
          Nächstes Event
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="text-sm font-black leading-tight">{event.title}</div>
        <Fa className="fa-hint-xs">رویداد بعدی</Fa>
        <div className="mt-2 space-y-1 text-[11px] text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <ClockIcon /> {event.time} · {event.duration}
          </div>
          <div className="flex items-center gap-1.5 truncate">
            <PinIcon /> {event.locationName}
          </div>
        </div>
        <div className="mt-auto pt-4">
          <span
            className="inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold text-white transition group-hover:translate-x-0.5"
            style={{ background: theme.primary }}
          >
            Details ansehen <ArrowRightIcon />
          </span>
        </div>
      </div>
    </Link>
  );
}
