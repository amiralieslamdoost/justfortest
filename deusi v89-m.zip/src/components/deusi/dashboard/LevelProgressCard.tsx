import { Fa } from "@/components/deusi/Fa";
import { vocabularyHeatmap, learnerProfile } from "@/lib/deusi/mockStats";
import { BlockHeader } from "./Shared";

export interface LevelProgressCardProps {
  className?: string;
  levelPct: number;
  wordsLearned: number;
  wordsGoal: number;
  xp: number;
  xpGoal: number;
  totalHours: number;
  activeDays: number;
}

export function LevelProgressCard({
  className = "",
  levelPct,
  wordsLearned,
  wordsGoal,
  xp,
  xpGoal,
  totalHours,
  activeDays,
}: LevelProgressCardProps) {
  const heat = vocabularyHeatmap;

  return (
    <div className={`neu-card p-6 sm:p-7 ${className}`}>
      <BlockHeader
        title="Sprachniveau · A2 → B1"
        fa="سطح زبان — پیشرفت به B1"
        subtitle={`Insgesamt ${totalHours || learnerProfile.totalStudyHours}h · ${
          activeDays || learnerProfile.activeDays
        } aktive Tage`}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <ProgressStat
          label="Niveau"
          fa="سطح"
          value={`${levelPct}%`}
          pct={levelPct}
          color="var(--flag-red)"
        />
        <ProgressStat
          label="Wörter"
          fa="واژگان"
          value={`${wordsLearned}/${wordsGoal}`}
          pct={Math.round((wordsLearned / wordsGoal) * 100)}
          color="#8B5CF6"
        />
        <ProgressStat
          label="XP heute"
          fa="امتیاز امروز"
          value={`${xp}/${xpGoal}`}
          pct={Math.round((xp / xpGoal) * 100)}
          color="#F7C948"
        />
      </div>

      {/* Compact vocabulary heatmap strip (last 12 weeks) */}
      <div className="mt-6">
        <div className="mb-2 flex items-center justify-between">
          <div className="text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
            Wortschatz · 12 Wochen
          </div>
          <Fa className="fa-hint-xs !text-[10px]">واژگان — ۱۲ هفته اخیر</Fa>
        </div>
        <div className="space-y-1">
          {heat.slice(0, 7).map((row, ri) => (
            <div
              key={ri}
              className="grid gap-1"
              style={{ gridTemplateColumns: `repeat(12, minmax(0,1fr))` }}
            >
              {row.slice(-12).map((v, ci) => (
                <div
                  key={ci}
                  className="aspect-square rounded-[4px]"
                  style={{
                    background:
                      v < 0.05
                        ? "var(--secondary)"
                        : `color-mix(in oklab, var(--flag-red) ${Math.round(v * 100)}%, transparent)`,
                  }}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ProgressStat({
  label,
  fa,
  value,
  pct,
  color,
}: {
  label: string;
  fa: string;
  value: string;
  pct: number;
  color: string;
}) {
  return (
    <div className="rounded-2xl border border-border/60 bg-secondary/40 p-4">
      <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-tight text-muted-foreground">
        <span>{label}</span>
        <Fa className="fa-hint-xs !text-[10px]">{fa}</Fa>
      </div>
      <div className="mt-1 text-lg font-black tabular-nums">{value}</div>
      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-background">
        <div
          className="dash-bar h-full rounded-full"
          style={{ width: `${Math.min(100, pct)}%`, background: color }}
        />
      </div>
    </div>
  );
}
