import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import { SECTION_THEME, type SectionKey } from "@/lib/deusi/sectionTheme";

type Spotlight = {
  key: SectionKey;
  to: "/ki-coach" | "/kino" | "/musik" | "/community";
  eyebrow: string;
  titleDe: string;
  titleFa: string;
  descDe: string;
  descFa: string;
  cta: string;
  emoji: string;
  bullets: Array<{ icon: string; de: string; fa: string }>;
  stat: { v: string; l: string };
  preview: { label: string; rows: Array<{ de: string; fa: string }> };
};

const SPOTLIGHTS: Spotlight[] = [
  {
    key: "ai-coach",
    to: "/ki-coach",
    eyebrow: "Neu in DEUSI",
    titleDe: "KI-Coach",
    titleFa: "مربی هوش مصنوعی",
    descDe:
      "Sprich frei, lass deine Sätze sofort korrigieren und erhalte Erklärungen auf Persisch.",
    descFa: "آزاد صحبت کن، جمله‌هایت را فوری اصلاح کن و توضیح فارسی بگیر.",
    cta: "Jetzt ausprobieren",
    emoji: "✨",
    bullets: [
      { icon: "💬", de: "Dialoge in Echtzeit", fa: "گفت‌وگوی زنده" },
      { icon: "📝", de: "Korrektur & Erklärung", fa: "اصلاح و توضیح" },
      { icon: "🎯", de: "Auf dein Niveau", fa: "متناسب با سطح تو" },
    ],
    stat: { v: "24/7", l: "verfügbar" },
    preview: {
      label: "Live-Dialog",
      rows: [
        { de: "Du: „Ich habe gestern nach Berlin gefahren.“", fa: "تو: جمله‌ی اولیه" },
        { de: "Coach: „Ich bin gestern nach Berlin gefahren.“", fa: "مربی: نسخه‌ی اصلاح‌شده" },
        { de: "Grund: Bewegungsverb → sein", fa: "دلیل: فعل حرکتی با sein" },
      ],
    },
  },
  {
    key: "movies",
    to: "/kino",
    eyebrow: "Empfohlen für dich",
    titleDe: "Filme & Serien",
    titleFa: "فیلم و سریال",
    descDe: "Lerne Deutsch mit Szenen, zweisprachigen Untertiteln und Vokabelkarten aus dem Film.",
    descFa: "با سکانس‌ها، زیرنویس دوزبانه و فلش‌کارت فیلم آلمانی یاد بگیر.",
    cta: "Kino entdecken",
    emoji: "🎬",
    bullets: [
      { icon: "🍿", de: "Kurze Lern-Szenen", fa: "سکانس‌های کوتاه" },
      { icon: "🔤", de: "Untertitel DE/FA", fa: "زیرنویس دوزبانه" },
      { icon: "📇", de: "Vokabeln speichern", fa: "ذخیره واژه‌ها" },
    ],
    stat: { v: "60+", l: "Titel" },
    preview: {
      label: "Szene des Tages",
      rows: [
        { de: "„Das kann doch nicht dein Ernst sein!“", fa: "«این که نمی‌تونه جدی باشه!»" },
        { de: "der Ernst — جدیت · B1", fa: "واژه‌ی سکانس" },
        { de: "Szene 2:14 · Untertitel DE/FA", fa: "زیرنویس دوزبانه" },
      ],
    },
  },
  {
    key: "music",
    to: "/musik",
    eyebrow: "Beliebt diese Woche",
    titleDe: "Musik & Karaoke",
    titleFa: "موسیقی و کارائوکه",
    descDe: "Songtexte Zeile für Zeile mitlesen, Aussprache trainieren und Wörter sammeln.",
    descFa: "متن آهنگ را خط‌به‌خط بخوان، تلفظ تمرین کن و واژه جمع کن.",
    cta: "Musik starten",
    emoji: "🎵",
    bullets: [
      { icon: "🎤", de: "Karaoke-Modus", fa: "حالت کارائوکه" },
      { icon: "🗣️", de: "Aussprache üben", fa: "تمرین تلفظ" },
      { icon: "⭐", de: "Playlists nach Niveau", fa: "لیست بر اساس سطح" },
    ],
    stat: { v: "120+", l: "Songs" },
    preview: {
      label: "Karaoke-Zeile",
      rows: [
        { de: "„Über den Wolken muss die Freiheit …“", fa: "«بالای ابرها آزادی باید…»" },
        { de: "die Freiheit — آزادی · B1", fa: "واژه‌ی ذخیره‌شده" },
        { de: "Aussprache: 92 % Treffer", fa: "دقت تلفظ" },
      ],
    },
  },
];

const SPOTLIGHT_DURATION = 4200;

export interface SpotlightCardProps {
  className?: string;
}

export function SpotlightCard({ className = "" }: SpotlightCardProps) {
  const [idx, setIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);
  const [drag, setDrag] = useState(0);
  const dragStart = useRef<number | null>(null);
  const progressRef = useRef(0);

  const s = SPOTLIGHTS[idx];
  const theme = SECTION_THEME[s.key];

  const go = (dir: number) => {
    setIdx((i) => (i + dir + SPOTLIGHTS.length) % SPOTLIGHTS.length);
    progressRef.current = 0;
    setProgress(0);
  };

  useEffect(() => {
    if (paused) return;
    let raf = 0;
    let start = performance.now() - progressRef.current * SPOTLIGHT_DURATION;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / SPOTLIGHT_DURATION);
      if (p >= 1) {
        start = now;
        progressRef.current = 0;
        setProgress(0);
        setIdx((i) => (i + 1) % SPOTLIGHTS.length);
      } else {
        progressRef.current = p;
        setProgress(p);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [paused]);

  const onDown = (e: React.PointerEvent) => {
    dragStart.current = e.clientX;
    setPaused(true);
  };
  const onMove = (e: React.PointerEvent) => {
    if (dragStart.current === null) return;
    setDrag(e.clientX - dragStart.current);
  };
  const onUp = () => {
    if (dragStart.current !== null && Math.abs(drag) > 60) go(drag < 0 ? 1 : -1);
    dragStart.current = null;
    setDrag(0);
    setPaused(false);
  };

  return (
    <div
      className={`neu-card min-w-0 overflow-hidden p-0 ${className}`}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => {
        dragStart.current = null;
        setDrag(0);
        setPaused(false);
      }}
    >
      <div
        className="relative flex h-full min-w-0 touch-pan-y select-none flex-col p-5 text-white sm:p-6"
        style={{
          backgroundImage: [
            `radial-gradient(110% 130% at 88% -20%, ${theme.accent}66 0%, transparent 55%)`,
            `radial-gradient(90% 120% at 5% 115%, ${theme.primary}88 0%, transparent 60%)`,
            `linear-gradient(135deg, ${theme.base} 0%, ${theme.primary} 55%, ${theme.accent} 130%)`,
          ].join(", "),
          transition: "background-image 400ms ease",
        }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
      >
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-white/10 blur-3xl" />
          <div
            className="absolute -bottom-24 -left-12 h-52 w-52 rounded-full blur-3xl"
            style={{ backgroundColor: theme.accent, opacity: 0.35 }}
          />
        </div>

        <div
          key={idx}
          className="animate-fade-in relative flex min-w-0 flex-1 flex-col"
          style={{
            transform: `translateX(${drag * 0.35}px)`,
            transition: dragStart.current === null ? "transform 300ms ease" : "none",
          }}
        >
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
            <div className="min-w-0">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
                {s.eyebrow}
              </span>
              <h3 className="mt-2 text-balance text-xl font-black leading-tight sm:text-2xl">
                {s.emoji} {s.titleDe}
              </h3>
              <Fa className="fa-hint-xs !text-white/85">{s.titleFa}</Fa>
            </div>
            <div className="shrink-0 rounded-2xl bg-white/15 px-3 py-2 text-center backdrop-blur">
              <div className="text-base font-black leading-none tabular-nums">{s.stat.v}</div>
              <div className="mt-1 text-[9px] font-semibold uppercase tracking-wider text-white/80">
                {s.stat.l}
              </div>
            </div>
          </div>

          <p className="mt-3 max-w-xl text-sm text-white/85">{s.descDe}</p>
          <Fa className="fa-hint-xs !text-white/70">{s.descFa}</Fa>

          <ul className="mt-4 grid gap-2 sm:grid-cols-3">
            {s.bullets.map((b) => (
              <li
                key={b.de}
                className="flex min-w-0 items-center gap-2 rounded-2xl bg-white/12 p-2.5 backdrop-blur"
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/20 text-sm">
                  {b.icon}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[12px] font-bold">{b.de}</span>
                  <Fa className="fa-hint-xs !text-[9px] !text-white/70">{b.fa}</Fa>
                </span>
              </li>
            ))}
          </ul>

          {/* Mock-Vorschau – füllt den Raum auf großen Bildschirmen */}
          <div className="mt-4 flex min-h-0 flex-1 flex-col rounded-3xl bg-black/20 p-4 ring-1 ring-white/15 backdrop-blur">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-white/70" />
              <span className="h-2 w-2 rounded-full bg-white/40" />
              <span className="h-2 w-2 rounded-full bg-white/25" />
              <span className="ml-auto text-[10px] font-bold uppercase tracking-widest text-white/70">
                {s.preview.label}
              </span>
            </div>
            <div className="mt-3 flex flex-1 flex-col justify-center gap-2">
              {s.preview.rows.map((r, i) => (
                <div
                  key={r.de}
                  className={`min-w-0 rounded-2xl px-3 py-2 ${
                    i === 1 ? "bg-white/22 ring-1 ring-white/25" : "bg-white/10"
                  }`}
                >
                  <div className="truncate text-[12px] font-semibold sm:text-[13px]">{r.de}</div>
                  <Fa className="fa-hint-xs !text-[9px] !text-white/70">{r.fa}</Fa>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-auto grid gap-3 pt-5 sm:flex sm:items-center sm:justify-between">
            <Link
              to={s.to}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-black shadow-lg transition hover:-translate-y-0.5 sm:w-auto"
              style={{ color: theme.primary }}
              draggable={false}
            >
              {s.cta} <ArrowRightIconInline />
            </Link>

            <div className="flex items-center justify-center gap-2 sm:justify-end">
              {SPOTLIGHTS.map((sp, i) => (
                <button
                  key={sp.key}
                  type="button"
                  onClick={() => {
                    setIdx(i);
                    setProgress(0);
                  }}
                  aria-label={sp.titleDe}
                  aria-current={i === idx ? "true" : undefined}
                  className={`h-2 overflow-hidden rounded-full transition-all duration-500 ease-out ${
                    i === idx ? "w-10 bg-white/35" : "w-2 bg-white/40 hover:bg-white/70"
                  }`}
                >
                  {i === idx && (
                    <span
                      className="block h-full rounded-full bg-white"
                      style={{ width: `${progress * 100}%`, transition: "width 180ms ease-out" }}
                    />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ArrowRightIconInline() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}
