import { Link } from "@tanstack/react-router";
import { Fa } from "@/components/deusi/Fa";
import { AchievementMedalCard } from "@/components/deusi/achievements/AchievementMedalCard";
import { useAchievements } from "@/lib/api/useGamification";
import { ACHIEVEMENTS as ALL_ACHIEVEMENTS } from "@/lib/deusi/achievements";
import { BlockHeader } from "./Shared";

const BADGES = ALL_ACHIEVEMENTS.slice(0, 6);

export interface AchievementsCardProps {
  className?: string;
}

export function AchievementsCard({ className = "" }: AchievementsCardProps) {
  /* سشن ۹: وضعیت دستاوردها از بک‌اند. */
  const { achievements } = useAchievements();
  const unlocked = achievements.filter((b) => b.unlocked).length;
  const total = achievements.length;
  const pct = Math.round((unlocked / Math.max(total, 1)) * 100);
  return (
    <div className={`neu-card p-6 ${className}`}>
      <BlockHeader
        title="Erfolge"
        fa="دستاوردها"
        subtitle={`${unlocked} von ${total} freigeschaltet`}
        action={
          <div className="hidden items-center gap-2 sm:flex">
            <div className="h-1.5 w-24 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full"
                style={{
                  width: `${pct}%`,
                  background: "linear-gradient(90deg, #F97316, #F7C948)",
                }}
              />
            </div>
            <span className="text-[11px] font-black tabular-nums text-muted-foreground">
              {pct}%
            </span>
          </div>
        }
      />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {BADGES.map((b, i) => (
          <AchievementMedalCard key={b.id} achievement={b} index={i} compact />
        ))}
      </div>

      {/* Big, distinct CTA to view all achievements */}
      <Link
        to="/achievements"
        className="group relative mt-5 flex items-center justify-between gap-4 overflow-hidden rounded-2xl p-4 text-white shadow-lg ring-1 ring-white/20 transition hover:-translate-y-0.5 hover:shadow-xl sm:p-5"
        style={{
          backgroundImage: "linear-gradient(135deg, #7C2D12 0%, #F97316 55%, #F7C948 130%)",
        }}
      >
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute -bottom-12 -left-6 h-32 w-32 rounded-full bg-yellow-200/30 blur-3xl" />
          <div className="absolute inset-x-0 -top-24 h-24 rotate-12 bg-gradient-to-r from-transparent via-white/25 to-transparent opacity-0 transition duration-700 group-hover:top-full group-hover:opacity-100" />
        </div>
        <div className="relative flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-white/95 text-2xl shadow ring-1 ring-white/40">
            <span aria-hidden>🏆</span>
          </div>
          <div className="min-w-0">
            <div className="text-sm font-black leading-tight sm:text-base">
              Alle Erfolge ansehen
            </div>
            <Fa className="fa-hint-xs !text-white/85">مشاهده همه‌ی دستاوردها</Fa>
            <div className="mt-0.5 text-[11px] font-semibold text-white/85">
              {unlocked} / {total} freigeschaltet · {pct}%
            </div>
          </div>
        </div>
        <div className="relative flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1.5 text-xs font-black backdrop-blur transition group-hover:bg-white/30">
          <span>Öffnen</span>
          <span aria-hidden className="transition group-hover:translate-x-0.5">
            →
          </span>
        </div>
      </Link>
    </div>
  );
}
