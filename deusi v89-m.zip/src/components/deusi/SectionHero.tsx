import type { CSSProperties, ReactNode } from "react";
import { Fa } from "@/components/deusi/Fa";
import { SECTION_THEME, type SectionKey } from "@/lib/deusi/sectionTheme";

type SectionHeroProps = {
  sectionKey: SectionKey;
  /** Override German title */
  titleDe?: string;
  /** Farsi hint line under H1 */
  titleFa?: string;
  /** German paragraph */
  descDe?: string;
  descFa?: string;
  /** Portion of the H1 that gets the bright gradient (defaults to theme.highlight) */
  highlight?: string;
  /** Right-hand slot: search, filter, action buttons, KPI chips… */
  right?: ReactNode;
  /** Optional full-width content rendered below the title row (e.g. dashboard daily goal card) */
  children?: ReactNode;
  /** Let children overflow the header (e.g. a search dropdown) */
  allowOverflow?: boolean;
  className?: string;
};

/**
 * Unified section header — shared across all 12 top-level sections of DEUSI.
 * Structure & rhythm are borrowed from the original Podcasts header; the
 * gradient, badge color, and icon come from each section's theme.
 */
export function SectionHero({
  sectionKey,
  titleDe,
  titleFa,
  descDe,
  descFa,
  highlight,
  right,
  children,
  allowOverflow = false,
  className = "",
}: SectionHeroProps) {
  const theme = SECTION_THEME[sectionKey];
  const Icon = theme.Icon;

  const de = titleDe ?? theme.titleDe;
  const fa = titleFa ?? theme.titleFa;
  const description = descDe ?? theme.descDe;
  const descriptionFa = descFa ?? theme.descFa;
  const highlightWord = highlight ?? theme.highlight;

  // Split H1 into [before][highlight][after] so the highlighted word gets a
  // light-on-dark gradient span, matching the Podcasts pattern.
  let before: string = de;
  let mid: string = "";
  let after: string = "";
  if (highlightWord) {
    const idx = de.indexOf(highlightWord);
    if (idx >= 0) {
      before = de.slice(0, idx);
      mid = de.slice(idx, idx + highlightWord.length);
      after = de.slice(idx + highlightWord.length);
    }
  }

  const style: CSSProperties = {
    // Header uses inline CSS vars so utility classes can stay generic while
    // colors follow the section theme.
    ["--section-base" as never]: theme.base,
    ["--section-primary" as never]: theme.primary,
    ["--section-accent" as never]: theme.accent,
    backgroundImage: [
      `radial-gradient(110% 130% at 88% -20%, ${theme.accent}66 0%, transparent 55%)`,
      `radial-gradient(90% 120% at 5% 115%, ${theme.primary}88 0%, transparent 60%)`,
      `linear-gradient(135deg, ${theme.base} 0%, ${theme.primary} 55%, ${theme.accent} 130%)`,
    ].join(", "),
  };

  return (
    <header
      style={style}
      className={`relative rounded-3xl p-4 text-white shadow-xl sm:p-7 ${allowOverflow ? "" : "overflow-hidden"} ${className}`}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden rounded-3xl">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div
          className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
          style={{ backgroundColor: theme.accent, opacity: 0.4 }}
        />
      </div>

      <div className="relative grid gap-3 sm:gap-4 xl:grid-cols-[minmax(0,1fr)_auto] xl:items-center">
        <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 sm:gap-4">
          {/* Big prominent section icon — memorable visual anchor */}
          <div
            aria-hidden
            className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16"
            style={{ color: theme.primary }}
          >
            <Icon size={26} strokeWidth={2} className="sm:hidden" />
            <Icon size={34} strokeWidth={2} className="hidden sm:block" />
          </div>
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
              {theme.label}
            </div>
            <h1 className="mt-1.5 text-balance text-xl font-black leading-tight sm:mt-2 sm:text-3xl md:text-4xl">
              {before}
              {mid && (
                <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
                  {mid}
                </span>
              )}
              {after}
            </h1>
            {fa && <Fa className="fa-hint-xs !text-white/85">{fa}</Fa>}
            {description && (
              <p className="mt-2 hidden max-w-2xl text-sm text-white/80 sm:block">{description}</p>
            )}
            {descriptionFa && (
              <Fa className="fa-hint-xs hidden !text-white/70 sm:block">{descriptionFa}</Fa>
            )}
          </div>
        </div>
        {right && (
          <div className="flex w-full min-w-0 flex-wrap items-center gap-2 xl:w-auto">{right}</div>
        )}
      </div>
      {children && <div className="relative mt-4 sm:mt-5">{children}</div>}
    </header>
  );
}
