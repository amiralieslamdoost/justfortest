/**
 * "Zum Inhalt springen" — Tastatur-Nutzer überspringen die Navigation.
 * پیوند پرش به محتوا؛ فقط هنگام فوکوس با کیبورد دیده می‌شود.
 */
export function SkipLink() {
  return (
    <a
      href="#hauptinhalt"
      className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:rounded-[var(--r-sm)] focus:bg-foreground focus:px-4 focus:py-2 focus:text-background focus:shadow-lg"
    >
      Zum Inhalt springen
    </a>
  );
}
