/**
 * Lazy geladene Diagramme (recharts wird erst beim Sichtbarwerden geladen).
 * چارت‌ها تنبل بارگذاری می‌شوند تا حجم اولیهٔ صفحه کمتر شود؛
 * ظاهر و props دقیقاً مثل نسخهٔ مستقیم است.
 */
import { lazy, Suspense, type ComponentProps } from "react";
import { Skel } from "@/components/deusi/Skeletons";

import type { StudyTimeChart as StudyTimeChartType } from "./StudyTimeChart";
import type { LearningActivityChart as LearningActivityChartType } from "./LearningActivityChart";
import type { StudyHoursChart as StudyHoursChartType } from "./StudyHoursChart";
import type { SkillDistributionRing as SkillDistributionRingType } from "./SkillDistributionRing";

const StudyTimeChartLazy = lazy(() =>
  import("./StudyTimeChart").then((m) => ({ default: m.StudyTimeChart })),
);
const LearningActivityChartLazy = lazy(() =>
  import("./LearningActivityChart").then((m) => ({ default: m.LearningActivityChart })),
);
const StudyHoursChartLazy = lazy(() =>
  import("./StudyHoursChart").then((m) => ({ default: m.StudyHoursChart })),
);
const SkillDistributionRingLazy = lazy(() =>
  import("./SkillDistributionRing").then((m) => ({ default: m.SkillDistributionRing })),
);

function ChartFallback({ height }: { height: number }) {
  return <Skel className="w-full rounded-xl" style={{ height }} />;
}

export function StudyTimeChart(props: ComponentProps<typeof StudyTimeChartType>) {
  return (
    <Suspense fallback={<ChartFallback height={props.height ?? 260} />}>
      <StudyTimeChartLazy {...props} />
    </Suspense>
  );
}

export function LearningActivityChart(props: ComponentProps<typeof LearningActivityChartType>) {
  return (
    <Suspense fallback={<ChartFallback height={props.height ?? 240} />}>
      <LearningActivityChartLazy {...props} />
    </Suspense>
  );
}

export function StudyHoursChart(props: ComponentProps<typeof StudyHoursChartType>) {
  return (
    <Suspense fallback={<ChartFallback height={220} />}>
      <StudyHoursChartLazy {...props} />
    </Suspense>
  );
}

export function SkillDistributionRing(props: ComponentProps<typeof SkillDistributionRingType>) {
  return (
    <Suspense fallback={<ChartFallback height={props.size ?? 220} />}>
      <SkillDistributionRingLazy {...props} />
    </Suspense>
  );
}
