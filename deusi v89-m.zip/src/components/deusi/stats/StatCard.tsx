import type { CSSProperties, ReactNode } from "react";
import { Fa } from "@/components/deusi/Fa";

interface Props {
  title: string;
  fa?: string;
  /** Small right-aligned slot: chips, totals, legends. */
  action?: ReactNode;
  /** Optional lucide icon rendered in a colored chip left of the title. */
  icon?: ReactNode;
  /** Accent color for the rail, tint and icon chip. */
  accent?: string;
  children: ReactNode;
  className?: string;
}

/**
 * Shared shell for every statistics card.
 * A single accent color drives the top rail, the corner tint and the icon
 * chip, so the whole page reads as one system instead of 9 unrelated boxes.
 */
export function StatCard({ title, fa, action, icon, accent, children, className = "" }: Props) {
  const style = accent ? ({ ["--stat-accent" as never]: accent } as CSSProperties) : undefined;

  return (
    <section
      style={style}
      className={`stat-surface stat-surface-hover flex h-full min-w-0 flex-col p-4 sm:p-5 ${className}`}
    >
      <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-x-3 gap-y-2">
        <div className="flex min-w-0 items-center gap-2.5">
          {icon && <span className="stat-icon h-8 w-8 shrink-0 sm:h-9 sm:w-9">{icon}</span>}
          <span className="min-w-0">
            <h3 className="truncate text-[13px] font-bold leading-tight tracking-tight sm:text-sm">
              {title}
            </h3>
            {fa && <Fa className="fa-hint-xs mt-0.5 block truncate">{fa}</Fa>}
          </span>
        </div>
        {action && <div className="shrink-0 self-center">{action}</div>}
      </div>

      <div className="min-w-0 flex-1">{children}</div>
    </section>
  );
}
