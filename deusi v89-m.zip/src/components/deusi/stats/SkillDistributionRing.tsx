import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";

interface Slice {
  key: string;
  label: string;
  value: number;
  color: string;
}

interface Props {
  data: Slice[];
  centerValue: number;
  centerLabel: string;
  size?: number;
}

export function SkillDistributionRing({ data, centerValue, centerLabel, size = 220 }: Props) {
  return (
    <div className="relative flex items-center justify-center" style={{ height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            innerRadius={size * 0.32}
            outerRadius={size * 0.46}
            paddingAngle={3}
            dataKey="value"
            stroke="none"
          >
            {data.map((d) => (
              <Cell key={d.key} fill={d.color} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              background: "var(--card)",
              border: "1px solid var(--border)",
              borderRadius: 12,
              fontSize: 12,
            }}
            formatter={(v: number) => [`${v}%`, ""]}
          />
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-[11px] text-muted-foreground">{centerLabel}</div>
        <div className="text-3xl font-black tabular-nums">{centerValue}%</div>
      </div>
    </div>
  );
}
