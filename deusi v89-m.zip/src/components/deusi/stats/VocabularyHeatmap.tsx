interface Props {
  data: number[][]; // 7 rows (Mo..So) x N weeks
  months?: string[];
}

const ROWS_DE = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const SHOW_ROW = [true, false, true, false, true, false, true];

function cellColor(v: number) {
  if (v < 0.05) return "color-mix(in oklab, var(--muted-foreground) 12%, transparent)";
  const pct = 18 + Math.round(v * 82);
  return `color-mix(in oklab, var(--stat-accent, var(--flag-red)) ${pct}%, transparent)`;
}

export function VocabularyHeatmap({ data, months = [] }: Props) {
  const cols = data[0]?.length ?? 0;
  const monthTickEvery = months.length ? Math.max(1, Math.round(cols / months.length)) : cols;
  const template = `20px repeat(${cols}, minmax(9px,18px))`;

  return (
    <div className="w-full min-w-0">
      <div className="no-scrollbar -mx-1 overflow-x-auto px-1 pb-1">
        <div className="w-fit min-w-[440px] sm:min-w-[520px]">
          {/* month labels */}
          <div
            className="mb-1.5 grid text-[10px] font-medium text-muted-foreground"
            style={{ gridTemplateColumns: template, gap: "3px" }}
          >
            <div />
            {Array.from({ length: cols }).map((_, i) => {
              const idx = Math.floor(i / monthTickEvery);
              const show = i % monthTickEvery === 0 && idx < months.length;
              return (
                <div key={i} className="relative h-3">
                  {show && (
                    <span className="absolute left-0 top-0 whitespace-nowrap">{months[idx]}</span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="grid" style={{ gap: "3px" }}>
            {data.map((row, ri) => (
              <div
                key={ri}
                className="grid items-center"
                style={{ gridTemplateColumns: template, gap: "3px" }}
              >
                <div className="text-[10px] leading-none text-muted-foreground">
                  {SHOW_ROW[ri] ? ROWS_DE[ri] : ""}
                </div>
                {row.map((v, ci) => (
                  <div
                    key={ci}
                    className="aspect-square w-full rounded-[4px] transition-transform duration-150 hover:scale-125"
                    style={{ background: cellColor(v) }}
                    title={`${ROWS_DE[ri]} — ${Math.round(v * 100)} %`}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-end gap-1.5 text-[10px] text-muted-foreground">
        <span className="mr-1">Wenig</span>
        {[0, 0.25, 0.5, 0.75, 1].map((v) => (
          <span
            key={v}
            className="h-[10px] w-[10px] rounded-[3px]"
            style={{ background: cellColor(v) }}
          />
        ))}
        <span className="ml-1">Viel</span>
      </div>
    </div>
  );
}
