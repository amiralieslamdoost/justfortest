import { Fa } from "@/components/deusi/Fa";
import { formatMinutes } from "@/lib/deusi/mockStudyStats";

export interface WeekdayPoint {
  /** 0 = Monday … 6 = Sunday */
  index: number;
  label: string;
  labelFa: string;
  minutes: number;
}

/**
 * Average study time per weekday. Answers a question the learner can act on:
 * which days carry the week and which ones regularly fall through.
 */
export function WeekdayProfile({ data, accent }: { data: WeekdayPoint[]; accent: string }) {
  const max = Math.max(...data.map((d) => d.minutes), 1);
  const best = data.reduce((a, b) => (b.minutes > a.minutes ? b : a), data[0]);
  const worst = data.reduce((a, b) => (b.minutes < a.minutes ? b : a), data[0]);
  const avg = Math.round(data.reduce((s, d) => s + d.minutes, 0) / Math.max(data.length, 1));

  return (
    <div style={{ ["--stat-accent" as never]: accent }} className="min-w-0">
      <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5">
        {data.map((d) => {
          const isBest = d.index === best?.index;
          return (
            <div key={d.index} className="flex min-w-0 flex-col items-center gap-1.5">
              <span
                className={`text-[10px] font-bold tabular-nums sm:text-[11px] ${
                  isBest ? "text-[color:var(--stat-accent)]" : "text-muted-foreground"
                }`}
              >
                {d.minutes}
              </span>
              <div className="flex h-[120px] w-full items-end sm:h-[140px]">
                <div
                  title={`${d.label}: ${formatMinutes(d.minutes)}`}
                  className="w-full rounded-t-xl transition-[height] duration-700"
                  style={{
                    height: `${Math.max(6, (d.minutes / max) * 100)}%`,
                    background: isBest
                      ? `linear-gradient(180deg, color-mix(in oklab, var(--stat-accent) 45%, white), var(--stat-accent))`
                      : `linear-gradient(180deg, color-mix(in oklab, var(--stat-accent) 22%, transparent), color-mix(in oklab, var(--stat-accent) 42%, transparent))`,
                  }}
                />
              </div>
              <span
                className={`w-full truncate text-center text-[10px] font-semibold sm:text-[11px] ${
                  isBest ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                {d.label}
              </span>
            </div>
          );
        })}
      </div>

      <div className="mt-4 grid gap-2 border-t border-border/60 pt-3 sm:grid-cols-3">
        <Metric label="Ø pro Wochentag" fa="میانگین هر روز هفته" value={`${avg} Min`} />
        <Metric
          label="Stärkster Tag"
          fa="قوی‌ترین روز"
          value={`${best?.label ?? "—"} · ${best?.minutes ?? 0} Min`}
          highlight
        />
        <Metric
          label="Schwächster Tag"
          fa="ضعیف‌ترین روز"
          value={`${worst?.label ?? "—"} · ${worst?.minutes ?? 0} Min`}
        />
      </div>
    </div>
  );
}

function Metric({
  label,
  fa,
  value,
  highlight,
}: {
  label: string;
  fa: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="min-w-0 rounded-2xl bg-secondary/50 px-3 py-2">
      <div className="truncate text-[10px] font-semibold text-muted-foreground">{label}</div>
      <Fa className="fa-hint-xs block truncate">{fa}</Fa>
      <div
        className={`mt-1 truncate text-[12px] font-bold tabular-nums ${
          highlight ? "text-[color:var(--stat-accent)]" : "text-foreground/90"
        }`}
      >
        {value}
      </div>
    </div>
  );
}
