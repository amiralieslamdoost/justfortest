import { Fa } from "@/components/deusi/Fa";
import { formatMinutes, type StudyDay } from "@/lib/deusi/mockStudyStats";

const DAYS_DE = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];

interface Props {
  todayMinutes: number;
  goalMinutes: number;
  week: StudyDay[];
}

export function DailyGoalCard({ todayMinutes, goalMinutes, week }: Props) {
  const pct = Math.min(100, Math.round((todayMinutes / goalMinutes) * 100));
  const reached = week.filter((d) => d.minutes >= goalMinutes).length;
  const done = todayMinutes >= goalMinutes;

  return (
    <div
      style={{ ["--stat-accent" as never]: done ? "var(--easy)" : "var(--flag-red)" }}
      className="stat-surface stat-surface-hover flex h-full min-w-0 flex-col p-4 sm:p-5"
    >
      <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-[13px] font-bold leading-tight sm:text-sm">Tagesziel</h3>
          <Fa className="fa-hint-xs block truncate">هدف روزانه</Fa>
        </div>
        <span className="stat-chip shrink-0">{reached}/7 erreicht</span>
      </div>

      <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4">
        <GoalRing value={pct} />
        <div className="min-w-0">
          <div className="truncate text-[28px] font-black leading-none tabular-nums">
            {formatMinutes(todayMinutes)}
          </div>
          <div className="mt-1.5 truncate text-[11px] text-muted-foreground">
            von {goalMinutes} Min heute
          </div>
          <div
            className="mt-2 inline-flex max-w-full truncate rounded-full px-2 py-0.5 text-[11px] font-bold"
            style={{
              color: done ? "var(--easy)" : "var(--flag-red)",
              background: done
                ? "color-mix(in oklab, var(--easy) 12%, transparent)"
                : "color-mix(in oklab, var(--flag-red) 10%, transparent)",
            }}
          >
            {done ? "Ziel erreicht 🎉" : `noch ${goalMinutes - todayMinutes} Min`}
          </div>
        </div>
      </div>

      <div className="mt-auto pt-5">
        <div className="mb-2.5 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-t border-border/60 pt-3 text-[11px] font-semibold text-muted-foreground">
          <span className="truncate">Diese Woche</span>
          <Fa className="fa-hint-xs shrink-0">این هفته</Fa>
        </div>
        <div className="flex min-w-0 items-end gap-1 sm:gap-1.5">
          {week.map((d) => {
            const h = Math.min(100, (d.minutes / Math.max(goalMinutes, 1)) * 100);
            const hit = d.minutes >= goalMinutes;
            return (
              <div key={d.date} className="flex min-w-0 flex-1 flex-col items-center gap-1.5">
                <div className="flex h-16 w-full items-end overflow-hidden rounded-xl bg-secondary/70">
                  <div
                    className="w-full rounded-xl transition-[height] duration-700"
                    style={{
                      height: `${Math.max(6, h)}%`,
                      background: hit
                        ? "linear-gradient(180deg, color-mix(in oklab, var(--easy) 65%, white), var(--easy))"
                        : "linear-gradient(180deg, color-mix(in oklab, var(--flag-gold) 65%, white), var(--flag-gold))",
                    }}
                    title={formatMinutes(d.minutes)}
                  />
                </div>
                <span className="text-[10px] font-semibold text-muted-foreground">
                  {DAYS_DE[new Date(d.date).getDay()]}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function GoalRing({ value }: { value: number }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  const off = c - (value / 100) * c;
  return (
    <div className="relative h-[86px] w-[86px] shrink-0">
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} stroke="var(--secondary)" strokeWidth="7" fill="none" />
        <circle
          cx="40"
          cy="40"
          r={r}
          stroke="var(--stat-accent)"
          strokeWidth="7"
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={off}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 900ms cubic-bezier(.2,.8,.2,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-[15px] font-black tabular-nums">
        {value}%
      </div>
    </div>
  );
}
