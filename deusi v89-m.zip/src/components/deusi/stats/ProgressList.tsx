interface Row {
  label: string;
  value: number;
  color?: string;
}

export function ProgressList({ rows, valueSuffix = "%" }: { rows: Row[]; valueSuffix?: string }) {
  return (
    <div className="space-y-3.5">
      {rows.map((r) => {
        const color = r.color ?? "var(--flag-red)";
        return (
          <div key={r.label} className="min-w-0">
            <div className="mb-1.5 grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 text-xs">
              <span
                aria-hidden
                className="h-2 w-2 shrink-0 rounded-full"
                style={{ background: color }}
              />
              <span className="min-w-0 truncate font-semibold text-foreground/85">{r.label}</span>
              <span className="shrink-0 tabular-nums text-[11px] font-bold text-muted-foreground">
                {r.value}
                {valueSuffix}
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full transition-[width] duration-700"
                style={{
                  width: `${r.value}%`,
                  background: `linear-gradient(90deg, color-mix(in oklab, ${color} 55%, white), ${color})`,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
