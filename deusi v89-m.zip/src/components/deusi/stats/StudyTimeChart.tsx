import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from "recharts";

type Point = { date: string; minutes: number };

interface Props {
  data: Point[];
  height?: number;
  dataKey?: string;
  color?: string;
  gradientId?: string;
  /** Optional horizontal daily-goal marker. */
  goal?: number;
}

export function StudyTimeChart({
  data,
  height = 260,
  dataKey = "minutes",
  color = "#DD2222",
  gradientId = "studyGrad",
  goal,
}: Props) {
  const step = Math.max(1, Math.ceil(data.length / 60));
  const trimmed = data
    .filter((_, i) => i % step === 0 || i === data.length - 1)
    .map((d) => ({
      ...d,
      label: new Date(d.date).toLocaleDateString("de-DE", { day: "2-digit", month: "short" }),
    }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={trimmed} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.35} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
        <XAxis
          dataKey="label"
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
          interval="preserveStartEnd"
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
          width={40}
        />
        <Tooltip
          contentStyle={{
            background: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: 12,
            fontSize: 12,
            boxShadow: "0 10px 30px rgba(0,0,0,.06)",
          }}
          formatter={(v: number) => [`${v} Min`, "Lernzeit"]}
        />
        {goal ? (
          <ReferenceLine
            y={goal}
            stroke="var(--flag-gold)"
            strokeDasharray="4 4"
            label={{
              value: `Ziel ${goal} Min`,
              position: "insideTopRight",
              fill: "var(--muted-foreground)",
              fontSize: 10,
            }}
          />
        ) : null}
        <Area
          type="monotone"
          dataKey={dataKey}
          stroke={color}
          strokeWidth={2.5}
          fill={`url(#${gradientId})`}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
