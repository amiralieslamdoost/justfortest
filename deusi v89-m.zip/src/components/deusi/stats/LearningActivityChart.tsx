import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";

type MonthPoint = { label: string; minutes: number };

interface Props {
  data: MonthPoint[];
  height?: number;
}

export function LearningActivityChart({ data, height = 240 }: Props) {
  const maxIdx = data.reduce((best, d, i) => (d.minutes > data[best].minutes ? i : best), 0);

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 20, right: 10, left: -10, bottom: 0 }}>
        <XAxis
          dataKey="label"
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
          width={40}
          tickFormatter={(v: number) => `${Math.round(v / 60)}h`}
        />
        <Tooltip
          cursor={{ fill: "rgba(0,0,0,0.03)" }}
          contentStyle={{
            background: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: 12,
            fontSize: 12,
            boxShadow: "0 10px 30px rgba(0,0,0,.06)",
          }}
          formatter={(v: number) => {
            const h = Math.floor(v / 60);
            const m = v % 60;
            return [`${h}h ${m}m`, "Lernzeit"];
          }}
        />
        <Bar dataKey="minutes" radius={[8, 8, 8, 8]}>
          {data.map((_, i) => (
            <Cell key={i} fill={i === maxIdx ? "#DD2222" : "#FDD8D5"} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
