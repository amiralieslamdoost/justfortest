import type { CSSProperties, ReactNode } from "react";
import { Fa } from "@/components/deusi/Fa";

interface Props {
  icon: ReactNode;
  /** Accent color driving rail, icon chip and sparkline. */
  accent: string;
  label: string;
  labelFa?: string;
  value: string | number;
  sub?: string;
  /** Optional 0-100 meter under the value. */
  progress?: number;
  /** Optional trend series rendered as a mini sparkline. */
  spark?: number[];
}

/**
 * Headline metric tile. Deliberately taller and louder than a regular card:
 * these four numbers are the first thing the page has to communicate.
 */
export function StatKpi({ icon, accent, label, labelFa, value, sub, progress, spark }: Props) {
  const style = { ["--stat-accent" as never]: accent } as CSSProperties;

  return (
    <div
      style={style}
      className="stat-surface stat-surface-hover flex h-full min-w-0 flex-col gap-3 p-4 sm:p-5"
    >
      <div className="flex min-w-0 items-start gap-2.5">
        <span className="stat-icon h-9 w-9 shrink-0 sm:h-10 sm:w-10">{icon}</span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[11px] font-semibold leading-tight text-muted-foreground sm:text-xs">
            {label}
          </span>
          {labelFa && <Fa className="fa-hint-xs block truncate">{labelFa}</Fa>}
        </span>
      </div>

      <div className="min-w-0">
        <div className="truncate text-[26px] font-black leading-none tracking-tight tabular-nums sm:text-[32px]">
          {value}
        </div>
        {sub && (
          <div className="mt-1.5 truncate text-[11px] leading-tight text-muted-foreground">
            {sub}
          </div>
        )}
      </div>

      {typeof progress === "number" ? (
        <div className="mt-auto h-1.5 overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full rounded-full transition-[width] duration-700"
            style={{
              width: `${Math.max(3, Math.min(100, progress))}%`,
              background: "var(--stat-accent)",
            }}
          />
        </div>
      ) : spark && spark.length > 1 ? (
        <Sparkline values={spark} />
      ) : null}
    </div>
  );
}

function Sparkline({ values }: { values: number[] }) {
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const span = Math.max(max - min, 1);
  const w = 100;
  const h = 26;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * w;
    const y = h - ((v - min) / span) * (h - 3) - 1.5;
    return `${x.toFixed(2)},${y.toFixed(2)}`;
  });

  return (
    <svg
      aria-hidden
      viewBox={`0 0 ${w} ${h}`}
      preserveAspectRatio="none"
      className="mt-auto h-7 w-full"
    >
      <polyline
        points={`0,${h} ${pts.join(" ")} ${w},${h}`}
        fill="color-mix(in oklab, var(--stat-accent) 16%, transparent)"
        stroke="none"
      />
      <polyline
        points={pts.join(" ")}
        fill="none"
        stroke="var(--stat-accent)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
