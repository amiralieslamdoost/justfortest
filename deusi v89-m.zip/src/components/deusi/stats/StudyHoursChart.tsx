import { Fa } from "@/components/deusi/Fa";
import { formatMinutes, type HourBucket } from "@/lib/deusi/mockStudyStats";

const BANDS = [
  { from: 5, to: 11, label: "Morgen", fa: "صبح" },
  { from: 12, to: 17, label: "Nachmittag", fa: "بعدازظهر" },
  { from: 18, to: 23, label: "Abend", fa: "شب" },
  { from: 0, to: 4, label: "Nacht", fa: "شبانه" },
];

/**
 * 24-hour bar strip. Bars shrink with the container (min-w-0 everywhere) so
 * the card never forces horizontal page scroll on a phone.
 */
export function StudyHoursChart({ data }: { data: HourBucket[] }) {
  const max = Math.max(...data.map((d) => d.minutes), 1);
  const peak = data.reduce((best, d) => (d.minutes > best.minutes ? d : best), data[0]);
  const band =
    BANDS.find((b) => peak.hour >= b.from && peak.hour <= b.to) ?? BANDS[BANDS.length - 1];

  return (
    <div className="min-w-0">
      <div className="flex h-32 min-w-0 items-end gap-[2px] sm:gap-[3px]">
        {data.map((d) => {
          const isPeak = d.hour === peak.hour;
          return (
            <div
              key={d.hour}
              className="group relative min-w-0 flex-1 rounded-t-[5px] transition-all duration-700"
              style={{
                height: `${Math.max(4, (d.minutes / max) * 100)}%`,
                background: isPeak
                  ? "linear-gradient(180deg, color-mix(in oklab, var(--stat-accent) 70%, white) 0%, var(--stat-accent) 100%)"
                  : `color-mix(in oklab, var(--stat-accent) ${16 + Math.round((d.minutes / max) * 52)}%, transparent)`,
                boxShadow: isPeak
                  ? "0 6px 16px -8px color-mix(in oklab, var(--stat-accent) 90%, transparent)"
                  : undefined,
              }}
              title={`${`${d.hour}`.padStart(2, "0")}:00 — ${formatMinutes(d.minutes)}`}
            />
          );
        })}
      </div>

      <div className="mt-2 flex justify-between text-[10px] tabular-nums text-muted-foreground">
        <span>00</span>
        <span>06</span>
        <span>12</span>
        <span>18</span>
        <span>23</span>
      </div>

      <div className="mt-4 flex items-center justify-between gap-2 rounded-2xl bg-secondary/60 px-3 py-2">
        <div className="min-w-0">
          <div className="truncate text-[11px] font-semibold">Produktivste Zeit · {band.label}</div>
          <Fa className="fa-hint-xs block truncate">پربازده‌ترین زمان تو، {band.fa} است</Fa>
        </div>
        <span className="stat-chip shrink-0">{`${peak.hour}`.padStart(2, "0")}:00</span>
      </div>
    </div>
  );
}
