import { useState } from "react";
import { Fa } from "@/components/deusi/Fa";
import {
  GOAL_LABEL,
  INTENSITY,
  LEVEL_LABEL,
  SKILL_LABEL,
  SKILL_ORDER,
  WEEKDAY_LABEL,
} from "@/lib/deusi/planner/config";
import { formatMinutes, todayISO } from "@/lib/deusi/planner/date";
import type {
  CefrLevel,
  GoalKey,
  Intensity,
  PlannerPrefs,
  SkillKey,
} from "@/lib/deusi/planner/types";
import { SkillRatingRow } from "@/components/deusi/onboarding/parts";
import { ChoiceChip, FieldLabel, SKILL_COLOR } from "./parts";

const LEVELS: CefrLevel[] = ["unknown", "A1", "A2", "B1", "B2", "C1", "C2"];
const GOALS: GoalKey[] = [
  "general",
  "migration",
  "university",
  "work",
  "goethe",
  "testdaf",
  "conversation",
  "travel",
];
const DAY_ORDER = [6, 0, 1, 2, 3, 4, 5];
const MINUTE_PRESETS = [20, 30, 45, 60, 90, 120];

/**
 * Profil-Formular des Planers — dient als Onboarding und als „Plan anpassen“.
 * Reine Eingabe: das Rechnen übernimmt die Engine nach dem Speichern.
 */
export function PlannerSetup({
  prefs,
  busy,
  onSubmit,
  onCancel,
  submitLabel = "Plan erstellen",
}: {
  prefs: PlannerPrefs | null;
  busy?: boolean;
  onSubmit: (input: Partial<PlannerPrefs>) => void;
  onCancel?: () => void;
  submitLabel?: string;
}) {
  const [level, setLevel] = useState<CefrLevel>(prefs?.level ?? "unknown");
  const [goals, setGoals] = useState<GoalKey[]>(prefs?.goals ?? ["general"]);
  const [dailyMinutes, setDailyMinutes] = useState(prefs?.dailyMinutes ?? 45);
  const [days, setDays] = useState<number[]>(prefs?.availableDays ?? [6, 0, 1, 2, 3, 4]);
  const [startHour, setStartHour] = useState(prefs?.startHour ?? "19:00");
  const [intensity, setIntensity] = useState<Intensity>(prefs?.intensity ?? "steady");
  const [weak, setWeak] = useState<SkillKey[]>(prefs?.weakSkills ?? []);
  const [strong, setStrong] = useState<SkillKey[]>(prefs?.strongSkills ?? []);
  const [targetDate, setTargetDate] = useState(prefs?.targetDate ?? "");
  const [restDays, setRestDays] = useState<"auto" | "none">(prefs?.restDays ?? "auto");

  const toggle = <T,>(list: T[], value: T, set: (v: T[]) => void, min = 0) => {
    const next = list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
    if (next.length < min) return;
    set(next);
  };

  const weeklyTotal = days.length * Math.round(dailyMinutes * INTENSITY[intensity].factor);

  return (
    <form
      className="flex flex-col gap-6 text-[15px] leading-relaxed"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({
          level,
          goals: goals.length ? goals : ["general"],
          dailyMinutes,
          availableDays: days.length ? days : [6, 0, 1, 2, 3],
          startHour,
          intensity,
          weakSkills: weak,
          strongSkills: strong,
          targetDate: targetDate || null,
          restDays,
        });
      }}
    >
      <section>
        <FieldLabel fa="سطح تو">Dein Niveau</FieldLabel>
        <div className="flex flex-wrap gap-2">
          {LEVELS.map((l) => (
            <ChoiceChip key={l} active={level === l} onClick={() => setLevel(l)}>
              {LEVEL_LABEL[l]}
            </ChoiceChip>
          ))}
        </div>
      </section>

      <section>
        <FieldLabel fa="هدف تو">Warum lernst du Deutsch?</FieldLabel>
        <div className="flex flex-wrap gap-2">
          {GOALS.map((g) => (
            <ChoiceChip
              key={g}
              active={goals.includes(g)}
              onClick={() => toggle(goals, g, setGoals, 1)}
            >
              {GOAL_LABEL[g].de}
            </ChoiceChip>
          ))}
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Mehrfachauswahl möglich — der Planer mischt die Schwerpunkte.
        </p>
      </section>

      <section>
        <FieldLabel htmlFor="planner-minutes" fa="زمان روزانه">
          Zeit pro Lerntag
        </FieldLabel>
        <div className="flex flex-wrap gap-2">
          {MINUTE_PRESETS.map((m) => (
            <ChoiceChip key={m} active={dailyMinutes === m} onClick={() => setDailyMinutes(m)}>
              {formatMinutes(m)}
            </ChoiceChip>
          ))}
        </div>
        <input
          id="planner-minutes"
          type="range"
          min={10}
          max={180}
          step={5}
          value={dailyMinutes}
          onChange={(e) => setDailyMinutes(Number(e.target.value))}
          className="mt-3 w-full accent-[color:var(--section-primary)]"
          aria-label="Minuten pro Lerntag"
        />
        <div className="mt-1 text-sm font-semibold">{formatMinutes(dailyMinutes)} pro Tag</div>
      </section>

      <section>
        <FieldLabel fa="روزهای هفته">An welchen Tagen kannst du lernen?</FieldLabel>
        <div className="flex flex-wrap gap-2">
          {DAY_ORDER.map((d) => (
            <ChoiceChip
              key={d}
              active={days.includes(d)}
              onClick={() => toggle(days, d, setDays, 1)}
              title={WEEKDAY_LABEL[d]!.de}
            >
              {WEEKDAY_LABEL[d]!.short}
            </ChoiceChip>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <ChoiceChip active={restDays === "auto"} onClick={() => setRestDays("auto")}>
            Ruhetag erlauben
          </ChoiceChip>
          <ChoiceChip active={restDays === "none"} onClick={() => setRestDays("none")}>
            Jeden gewählten Tag lernen
          </ChoiceChip>
        </div>
      </section>

      <div className="grid gap-6 sm:grid-cols-2">
        <section>
          <FieldLabel htmlFor="planner-start" fa="ساعت شروع">
            Startzeit
          </FieldLabel>
          <input
            id="planner-start"
            type="time"
            value={startHour}
            onChange={(e) => setStartHour(e.target.value || "19:00")}
            className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm font-semibold tabular-nums outline-none transition-colors focus:border-[color:var(--section-primary)] focus:ring-4 focus:ring-[color:var(--section-primary)]/15"
          />
        </section>
        <section>
          <FieldLabel htmlFor="planner-target" fa="تاریخ آزمون">
            Prüfung / Ziel-Datum
          </FieldLabel>
          <input
            id="planner-target"
            type="date"
            min={todayISO()}
            value={targetDate}
            onChange={(e) => setTargetDate(e.target.value)}
            className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm font-semibold tabular-nums outline-none transition-colors focus:border-[color:var(--section-primary)] focus:ring-4 focus:ring-[color:var(--section-primary)]/15"
          />
          <p className="mt-1 text-xs text-muted-foreground">
            Optional. Näher am Termin plant DEUSI mehr Prüfungstraining ein.
          </p>
        </section>
      </div>

      <section>
        <FieldLabel fa="شدت">Intensität</FieldLabel>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(INTENSITY) as Intensity[]).map((i) => (
            <ChoiceChip key={i} active={intensity === i} onClick={() => setIntensity(i)}>
              {INTENSITY[i].label}
            </ChoiceChip>
          ))}
        </div>
      </section>

      <section>
        <FieldLabel fa="مهارت‌ها">Wie schätzt du deine Fertigkeiten ein?</FieldLabel>
        <div className="flex flex-col gap-2.5">
          {SKILL_ORDER.map((s) => (
            <SkillRatingRow
              key={s}
              label={SKILL_LABEL[s].de}
              labelFa={SKILL_LABEL[s].fa}
              color={SKILL_COLOR[s]}
              value={weak.includes(s) ? "weak" : strong.includes(s) ? "strong" : "ok"}
              onChange={(v) => {
                setWeak(v === "weak" ? [...new Set([...weak, s])] : weak.filter((x) => x !== s));
                setStrong(
                  v === "strong" ? [...new Set([...strong, s])] : strong.filter((x) => x !== s),
                );
              }}
            />
          ))}
        </div>
        <p lang="fa" dir="rtl" className="mt-2 text-right text-xs leading-6 text-muted-foreground">
          مهارت‌های «ضعیف» زمان بیشتری می‌گیرند و مهارت‌های «قوی» کمتر تکرار می‌شوند.
        </p>
      </section>

      <div className="sticky bottom-0 -mx-1 mt-1 flex flex-wrap items-center justify-between gap-3 border-t border-border/70 bg-background/95 px-1 py-3 backdrop-blur">
        <p className="text-sm text-muted-foreground">
          Ergibt <strong className="text-foreground">{formatMinutes(weeklyTotal)}</strong> pro Woche
          <Fa inline>در هفته</Fa>
        </p>
        <div className="flex gap-2">
          {onCancel ? (
            <button
              type="button"
              onClick={onCancel}
              className="rounded-full border border-border px-4 py-2 text-sm font-semibold hover:bg-muted"
            >
              Abbrechen
            </button>
          ) : null}
          <button
            type="submit"
            disabled={busy}
            className="rounded-full bg-[color:var(--section-primary)] px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-px disabled:translate-y-0 disabled:opacity-60"
          >
            {busy ? "Wird geplant …" : submitLabel}
          </button>
        </div>
      </div>
    </form>
  );
}
