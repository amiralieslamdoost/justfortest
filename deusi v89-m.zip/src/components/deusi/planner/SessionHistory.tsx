import { Fa } from "@/components/deusi/Fa";
import { SkillDot } from "@/components/deusi/planner/parts";
import { SKILL_LABEL } from "@/lib/deusi/planner/config";
import { formatDayLong, formatMinutes } from "@/lib/deusi/planner/date";
import type { LogSummary, SessionLogEntry } from "@/lib/api/planner";

/**
 * Wochenprotokoll: tatsächlich gelernte Minuten aus `session_logs`.
 * Die Daten kommen geräteübergreifend vom Server (im MOCK-Modus lokal).
 */
export function SessionHistory({
  logs,
  summary,
  limit = 6,
}: {
  logs: SessionLogEntry[];
  summary: LogSummary;
  limit?: number;
}) {
  const skills = Object.entries(summary.bySkill)
    .filter(([, minutes]) => (minutes ?? 0) > 0)
    .sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0));

  return (
    <section aria-label="Lernprotokoll" className="neu-card min-w-0 p-4 sm:p-5">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3">
        <div className="min-w-0">
          <h2 className="text-base font-black tracking-tight">Wirklich gelernt</h2>
          <Fa>آنچه واقعاً انجام شده</Fa>
        </div>
        <span className="shrink-0 rounded-full bg-[color:var(--section-primary)]/12 px-2.5 py-1 text-[11px] font-bold tabular-nums text-[color:var(--section-primary)]">
          {formatMinutes(summary.totalMinutes)}
        </span>
      </div>

      <dl className="mt-3 grid grid-cols-3 gap-2 text-center">
        <div className="rounded-2xl bg-muted/60 px-2 py-2">
          <dt className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/80">
            Blöcke
          </dt>
          <dd className="text-lg font-black tabular-nums">{summary.sessionCount}</dd>
        </div>
        <div className="rounded-2xl bg-muted/60 px-2 py-2">
          <dt className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/80">
            Lerntage
          </dt>
          <dd className="text-lg font-black tabular-nums">{summary.activeDays}</dd>
        </div>
        <div className="rounded-2xl bg-muted/60 px-2 py-2">
          <dt className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/80">
            Streak
          </dt>
          <dd className="text-lg font-black tabular-nums">{summary.streak}</dd>
        </div>
      </dl>

      {skills.length ? (
        <ul className="mt-3 flex flex-wrap gap-2">
          {skills.map(([skill, minutes]) => (
            <li
              key={skill}
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1 text-[11px] font-semibold"
            >
              <SkillDot skill={skill as keyof typeof SKILL_LABEL} />
              {SKILL_LABEL[skill as keyof typeof SKILL_LABEL].de}
              <span className="tabular-nums text-muted-foreground">
                {formatMinutes(minutes ?? 0)}
              </span>
            </li>
          ))}
        </ul>
      ) : null}

      <ul className="mt-3 flex flex-col gap-2">
        {logs.length ? (
          logs.slice(0, limit).map((log) => (
            <li
              key={log.id}
              className="flex items-center justify-between gap-3 rounded-2xl border border-border px-3 py-2 text-sm"
            >
              <span className="flex min-w-0 items-center gap-2">
                <SkillDot skill={log.skill} />
                <span className="truncate font-semibold">
                  {SKILL_LABEL[log.skill].de}
                  {log.itemsDone ? ` · ${log.itemsDone} Karten` : ""}
                </span>
              </span>
              <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                {formatDayLong((log.startedAt ?? log.createdAt).slice(0, 10))} ·{" "}
                {formatMinutes(log.minutes)}
              </span>
            </li>
          ))
        ) : (
          <li className="rounded-2xl border border-dashed border-border px-3 py-4 text-center text-sm text-muted-foreground">
            Noch nichts abgeschlossen — هنوز چیزی ثبت نشده
          </li>
        )}
      </ul>
    </section>
  );
}
