import { useState } from "react";
import { ACTIVITIES } from "@/lib/deusi/planner/activities";
import { SESSION_RULES, SKILL_LABEL, SKILL_ORDER } from "@/lib/deusi/planner/config";
import {
  addClock,
  formatDayShort,
  formatMinutes,
  weekDates,
  weekdayLabel,
} from "@/lib/deusi/planner/date";
import type { PlannerSession, SkillKey } from "@/lib/deusi/planner/types";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";
import { ChoiceChip, FormSection, SkillDot, SKILL_COLOR } from "./parts";

const MINUTES = [10, 15, 20, 25, 30, 45];

const timeInput =
  "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm font-semibold tabular-nums outline-none transition-colors focus:border-[color:var(--section-primary)] focus:ring-4 focus:ring-[color:var(--section-primary)]/15";

const textInput =
  "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm font-semibold outline-none transition-colors placeholder:font-normal placeholder:text-muted-foreground/70 focus:border-[color:var(--section-primary)] focus:ring-4 focus:ring-[color:var(--section-primary)]/15";

/**
 * Session bearbeiten — als vollwertige Seite statt Dialog.
 * Auf dem Handy deutlich angenehmer als ein Popup.
 */
export function SessionEditForm({
  session,
  weekStart,
  onSave,
  onRemove,
  onCancel,
}: {
  session: PlannerSession;
  weekStart: string;
  onSave: (patch: Partial<PlannerSession>) => void;
  onRemove: () => void;
  onCancel: () => void;
}) {
  const [date, setDate] = useState(session.date);
  const [start, setStart] = useState(session.start);
  const [minutes, setMinutes] = useState(session.minutes);
  const module = SECTION_THEME[session.module];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="flex items-center gap-1.5 rounded-full bg-muted/70 px-2.5 py-1 font-semibold">
          <SkillDot skill={session.skill} />
          {SKILL_LABEL[session.skill].de}
          <span lang="fa" dir="rtl">
            {SKILL_LABEL[session.skill].fa}
          </span>
        </span>
        <span
          className="rounded-full px-2.5 py-1 font-semibold"
          style={{ backgroundColor: `${module.primary}14`, color: module.primary }}
        >
          {module.label}
        </span>
        <span className="rounded-full bg-muted/70 px-2.5 py-1 font-semibold tabular-nums">
          {start} – {addClock(start, minutes)}
        </span>
      </div>

      {session.description ? (
        <p className="text-sm leading-relaxed text-muted-foreground">{session.description}</p>
      ) : null}

      <FormSection title="Tag" fa="روز" hint="روزی که این بلوک باید انجام شود.">
        <div className="flex flex-wrap gap-2">
          {weekDates(weekStart).map((d) => (
            <ChoiceChip key={d} active={date === d} onClick={() => setDate(d)}>
              {weekdayLabel(d).short} · {formatDayShort(d)}
            </ChoiceChip>
          ))}
        </div>
      </FormSection>

      <div className="grid gap-5 sm:grid-cols-2">
        <FormSection title="Startzeit" fa="ساعت" htmlFor="session-start">
          <input
            id="session-start"
            type="time"
            value={start}
            onChange={(e) => setStart(e.target.value || session.start)}
            className={timeInput}
          />
        </FormSection>
        <FormSection title="Dauer" fa="مدت">
          <div className="flex flex-wrap gap-2">
            {MINUTES.filter((m) => m <= SESSION_RULES.maxMinutes).map((m) => (
              <ChoiceChip key={m} active={minutes === m} onClick={() => setMinutes(m)}>
                {formatMinutes(m)}
              </ChoiceChip>
            ))}
          </div>
        </FormSection>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border/70 pt-4">
        <button
          type="button"
          onClick={onRemove}
          className="rounded-full px-3 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
        >
          Entfernen · حذف
        </button>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-full border border-border px-4 py-2 text-sm font-semibold transition-colors hover:bg-muted"
          >
            Abbrechen
          </button>
          <button
            type="button"
            onClick={() => onSave({ date, start, minutes })}
            className="rounded-full bg-[color:var(--section-primary)] px-5 py-2 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-px"
          >
            Speichern
          </button>
        </div>
      </div>
    </div>
  );
}

/** Eigene Session: aus dem DEUSI-Katalog **oder** komplett frei formuliert. */
export function SessionAddForm({
  date,
  defaultStart,
  onAdd,
  onAddCustom,
  onCancel,
}: {
  date: string;
  defaultStart: string;
  onAdd: (input: { activityId: string; date: string; start: string; minutes: number }) => void;
  onAddCustom: (input: {
    title: string;
    description: string;
    skill: SkillKey;
    date: string;
    start: string;
    minutes: number;
  }) => void;
  onCancel: () => void;
}) {
  const [mode, setMode] = useState<"catalog" | "custom">("catalog");
  const [skill, setSkill] = useState<SkillKey>("vocabulary");
  const [activityId, setActivityId] = useState<string>("");
  const [start, setStart] = useState(defaultStart);
  const [minutes, setMinutes] = useState(20);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const pool = ACTIVITIES.filter((a) => a.skill === skill);
  const isCustom = mode === "custom";

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-2 gap-1 rounded-2xl border border-border/70 bg-muted/40 p-1">
        {(
          [
            { key: "catalog", de: "DEUSI-Aktivität", fa: "از فعالیت‌های سایت" },
            { key: "custom", de: "Eigene Aktivität", fa: "فعالیت دلخواه من" },
          ] as const
        ).map((t) => (
          <button
            key={t.key}
            type="button"
            aria-pressed={mode === t.key}
            onClick={() => setMode(t.key)}
            className={`min-w-0 rounded-xl px-3 py-2 text-center text-sm font-bold transition-all ${
              mode === t.key
                ? "bg-[color:var(--section-primary)] text-white shadow-sm"
                : "text-muted-foreground hover:bg-background/70 hover:text-foreground"
            }`}
          >
            <span className="block truncate">{t.de}</span>
            <span
              lang="fa"
              dir="rtl"
              className="block truncate text-[11px] font-semibold opacity-80"
            >
              {t.fa}
            </span>
          </button>
        ))}
      </div>

      <p className="text-sm font-semibold text-muted-foreground">
        {weekdayLabel(date).de}, {formatDayShort(date)} · {start} – {addClock(start, minutes)}
      </p>

      {isCustom ? (
        <>
          <FormSection
            title="Titel"
            fa="عنوان"
            htmlFor="custom-title"
            hint="مثلاً: خواندن کتاب درسی، کلاس آموزشگاه، تماشای فیلم آلمانی…"
          >
            <input
              id="custom-title"
              type="text"
              value={title}
              maxLength={80}
              placeholder="z. B. Kursbuch Kapitel 4"
              onChange={(e) => setTitle(e.target.value)}
              className={textInput}
            />
          </FormSection>

          <FormSection title="Notiz" fa="توضیح (اختیاری)" htmlFor="custom-desc">
            <textarea
              id="custom-desc"
              rows={3}
              value={description}
              maxLength={240}
              placeholder="Was genau machst du in diesem Block?"
              onChange={(e) => setDescription(e.target.value)}
              className={`${textInput} resize-none leading-relaxed`}
            />
          </FormSection>
        </>
      ) : null}

      <FormSection
        title="Fertigkeit"
        fa="مهارت"
        hint={isCustom ? "این فعالیت روی کدام مهارت کار می‌کند؟" : "اول مهارت را انتخاب کن."}
      >
        <div className="flex flex-wrap gap-2">
          {SKILL_ORDER.map((s) => {
            const active = skill === s;
            return (
              <button
                key={s}
                type="button"
                aria-pressed={active}
                onClick={() => {
                  setSkill(s);
                  setActivityId("");
                }}
                style={
                  active
                    ? { backgroundColor: SKILL_COLOR[s], borderColor: "transparent" }
                    : undefined
                }
                className={`rounded-full border px-3.5 py-2 text-sm font-semibold transition-all ${
                  active
                    ? "text-white shadow-sm"
                    : "border-border/70 bg-background text-muted-foreground hover:bg-muted/50 hover:text-foreground"
                }`}
              >
                {SKILL_LABEL[s].de}
              </button>
            );
          })}
        </div>
      </FormSection>

      {!isCustom ? (
        <FormSection title="Aktivität" fa="فعالیت">
          <ul className="grid gap-2 sm:grid-cols-2">
            {pool.map((a) => {
              const active = activityId === a.id;
              return (
                <li key={a.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setActivityId(a.id);
                      setMinutes(Math.max(a.minMinutes, Math.min(minutes, a.maxMinutes)));
                    }}
                    aria-pressed={active}
                    style={
                      active
                        ? {
                            borderColor: SKILL_COLOR[a.skill],
                            backgroundColor: `color-mix(in oklab, ${SKILL_COLOR[a.skill]} 8%, transparent)`,
                          }
                        : undefined
                    }
                    className={`h-full w-full rounded-2xl border p-3.5 text-left transition-all ${
                      active
                        ? ""
                        : "border-border/70 hover:-translate-y-px hover:border-border hover:bg-muted/40"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <SkillDot skill={a.skill} />
                      <span className="text-sm font-bold tracking-tight">{a.titleDe}</span>
                    </div>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{a.descDe}</p>
                    <p className="mt-2 text-[11px] font-semibold tabular-nums text-muted-foreground/80">
                      {formatMinutes(a.minMinutes)} – {formatMinutes(a.maxMinutes)}
                    </p>
                  </button>
                </li>
              );
            })}
          </ul>
        </FormSection>
      ) : null}

      <div className="grid gap-5 sm:grid-cols-2">
        <FormSection title="Startzeit" fa="ساعت" htmlFor="picker-start">
          <input
            id="picker-start"
            type="time"
            value={start}
            onChange={(e) => setStart(e.target.value || defaultStart)}
            className={timeInput}
          />
        </FormSection>
        <FormSection title="Dauer" fa="مدت">
          <div className="flex flex-wrap gap-2">
            {(isCustom ? [...MINUTES, 60, 90] : MINUTES).map((m) => (
              <ChoiceChip key={m} active={minutes === m} onClick={() => setMinutes(m)}>
                {formatMinutes(m)}
              </ChoiceChip>
            ))}
          </div>
        </FormSection>
      </div>

      <div className="flex flex-wrap items-center justify-end gap-2 border-t border-border/70 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-full border border-border px-4 py-2 text-sm font-semibold transition-colors hover:bg-muted"
        >
          Abbrechen
        </button>
        <button
          type="button"
          disabled={isCustom ? !title.trim() : !activityId}
          onClick={() =>
            isCustom
              ? onAddCustom({ title, description, skill, date, start, minutes })
              : onAdd({ activityId, date, start, minutes })
          }
          className="rounded-full bg-[color:var(--section-primary)] px-5 py-2 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-px disabled:translate-y-0 disabled:opacity-45"
        >
          Hinzufügen
        </button>
      </div>
    </div>
  );
}
