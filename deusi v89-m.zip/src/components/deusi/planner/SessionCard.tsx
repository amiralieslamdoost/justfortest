import { Link } from "@tanstack/react-router";
import { Check, Pencil, SkipForward, Trash2, Undo2 } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import { SKILL_LABEL } from "@/lib/deusi/planner/config";
import { formatMinutes } from "@/lib/deusi/planner/date";
import type { PlannerSession } from "@/lib/deusi/planner/types";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";
import { cn } from "@/lib/utils";
import { PriorityFlag, SkillDot, StatusBadge } from "./parts";

/** Kleiner runder Icon-Button für die Session-Aktionen. */
function IconAction({
  label,
  onClick,
  children,
  tone = "neutral",
  active,
}: {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
  tone?: "neutral" | "success" | "danger";
  active?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      className={cn(
        "grid h-9 w-9 shrink-0 place-items-center rounded-full border transition-all",
        "focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[color:var(--section-primary)]/20",
        active
          ? "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-300"
          : "border-border/70 text-muted-foreground hover:-translate-y-px hover:bg-muted",
        tone === "success" && !active && "hover:border-emerald-500/40 hover:text-emerald-600",
        tone === "danger" && "hover:border-destructive/40 hover:text-destructive",
      )}
    >
      {children}
    </button>
  );
}

/**
 * Session-Karte — das Herzstück des Kalenders.
 *
 * Design: weiche getönte Modul-Fläche, ruhiger Rest, Aktionen als runde
 * Icon-Buttons, damit die Karte auch auf Mobil kompakt bleibt.
 */
export function SessionCard({
  session,
  variant = "full",
  dueVocabCount = 0,
  onToggleDone,
  onSkip,
  onEdit,
  onRemove,
}: {
  session: PlannerSession;
  variant?: "compact" | "full";
  /** Fällige Karten aus dem Leitner-/FSRS-System (nur für Wortschatz-Blöcke). */
  dueVocabCount?: number;
  onToggleDone?: () => void;
  onSkip?: () => void;
  onEdit?: () => void;
  onRemove?: () => void;
}) {
  const module = SECTION_THEME[session.module];
  const ModuleIcon = module.Icon;
  const done = session.status === "done";
  const skipped = session.status === "skipped";
  const showDue = session.skill === "vocabulary" && dueVocabCount > 0 && !done;

  if (variant === "compact") {
    return (
      <button
        type="button"
        onClick={onEdit}
        className={cn(
          "group relative w-full overflow-hidden rounded-2xl border border-border/60 bg-background/80 p-2.5 pl-3 text-left transition-all",
          "hover:-translate-y-px hover:border-border hover:shadow-[0_10px_24px_-16px_rgb(0_0_0/0.45)]",
          done && "opacity-70",
          skipped && "opacity-45",
        )}
      >
        <span
          aria-hidden
          className="pointer-events-none absolute inset-y-1.5 left-1 w-1 rounded-full"
          style={{ background: `linear-gradient(180deg, ${module.primary}, ${module.accent})` }}
        />
        <span
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.06] transition-opacity group-hover:opacity-[0.12]"
          style={{
            background: `radial-gradient(120% 80% at 0% 0%, ${module.primary}, transparent 70%)`,
          }}
        />
        <span className="relative ml-1.5 flex items-center justify-between gap-2">
          <span
            className="rounded-lg px-1.5 py-0.5 text-[11px] font-bold tabular-nums"
            style={{ backgroundColor: `${module.primary}1f`, color: module.primary }}
          >
            {session.start}
          </span>
          <span className="text-[11px] font-semibold tabular-nums text-muted-foreground">
            {formatMinutes(session.minutes)}
          </span>
        </span>
        <span
          className={cn(
            "relative ml-1.5 mt-1.5 line-clamp-2 block text-[13px] font-bold leading-snug tracking-tight",
            (done || skipped) && "line-through decoration-1",
          )}
        >
          {session.title}
        </span>
        <span className="relative ml-1.5 mt-1.5 flex items-center gap-1.5">
          <SkillDot skill={session.skill} />
          <span className="truncate text-[11px] text-muted-foreground">
            {SKILL_LABEL[session.skill].de}
          </span>
          {done ? <Check className="ml-auto h-3.5 w-3.5 text-emerald-500" /> : null}
        </span>
      </button>
    );
  }

  return (
    <article
      className={cn(
        "group relative overflow-hidden rounded-3xl border border-border/60 bg-card p-3.5 transition-all sm:p-4",
        "hover:-translate-y-[2px] hover:border-border hover:shadow-[0_22px_44px_-30px_rgb(0_0_0/0.5)]",
        "flex flex-col gap-3 sm:flex-row sm:items-start sm:gap-4",
        done && "opacity-80",
        skipped && "opacity-60",
      )}
    >
      <span
        aria-hidden
        className="pointer-events-none absolute inset-y-0 left-0 w-[3px]"
        style={{ background: `linear-gradient(180deg, ${module.primary}, ${module.accent})` }}
      />
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.05]"
        style={{
          background: `radial-gradient(80% 120% at 0% 0%, ${module.primary}, transparent 60%)`,
        }}
      />

      {/* Zeit-Block */}
      <div
        className="relative flex w-full shrink-0 items-center justify-between gap-3 rounded-2xl px-3 py-2.5 ring-1 ring-inset sm:w-[92px] sm:flex-col sm:items-start sm:justify-start sm:gap-0.5"
        style={{
          backgroundColor: `${module.primary}12`,
          // @ts-expect-error CSS custom ring color
          "--tw-ring-color": `${module.primary}22`,
        }}
      >
        <span
          className="text-xl font-black tabular-nums tracking-tight"
          style={{ color: module.primary }}
        >
          {session.start}
        </span>
        <span className="text-xs font-semibold tabular-nums text-muted-foreground">
          {formatMinutes(session.minutes)}
        </span>
      </div>

      <div className="relative min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span
            aria-hidden
            className="grid h-7 w-7 shrink-0 place-items-center rounded-xl"
            style={{ backgroundColor: `${module.primary}16`, color: module.primary }}
          >
            <ModuleIcon className="h-4 w-4" />
          </span>
          <h3
            className={cn(
              "min-w-0 text-[15px] font-black tracking-tight sm:text-base",
              skipped && "line-through decoration-1",
            )}
          >
            {session.title}
          </h3>
          <StatusBadge status={session.status} />
          <PriorityFlag session={session} />
        </div>

        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
          {session.description}
        </p>

        <div className="mt-2.5 flex flex-wrap items-center gap-x-2 gap-y-1.5 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5 rounded-full bg-muted/70 px-2 py-0.5">
            <SkillDot skill={session.skill} />
            {SKILL_LABEL[session.skill].de}
            <Fa inline>{SKILL_LABEL[session.skill].fa}</Fa>
          </span>
          <span
            className="rounded-full px-2 py-0.5 font-semibold"
            style={{ backgroundColor: `${module.primary}14`, color: module.primary }}
          >
            {module.label}
          </span>
          {showDue ? (
            <span className="rounded-full bg-amber-500/15 px-2 py-0.5 font-semibold text-amber-600 dark:text-amber-300">
              {dueVocabCount} fällige Karten
              <Fa inline>{dueVocabCount} کارت سررسیدشده</Fa>
            </span>
          ) : null}
          {session.edited ? (
            <span className="rounded-full bg-muted/70 px-2 py-0.5">manuell angepasst</span>
          ) : null}
        </div>

        <div className="mt-3.5 flex flex-wrap items-center gap-2">
          <Link
            to={session.href}
            className="rounded-full px-4 py-2 text-sm font-bold text-white shadow-[0_10px_24px_-14px_var(--section-primary)] transition-transform hover:-translate-y-px"
            style={{
              background: `linear-gradient(135deg, ${module.primary}, color-mix(in oklab, ${module.primary} 72%, black))`,
            }}
          >
            {session.cta}
          </Link>
          {onToggleDone ? (
            <IconAction
              label={done ? "Wieder öffnen · بازگرداندن" : "Erledigt · انجام شد"}
              tone="success"
              active={done}
              onClick={onToggleDone}
            >
              {done ? <Undo2 className="h-4 w-4" /> : <Check className="h-4 w-4" />}
            </IconAction>
          ) : null}
          {onSkip && !done ? (
            <IconAction
              label={skipped ? "Zurückholen · برگرداندن" : "Überspringen · رد کردن"}
              onClick={onSkip}
              active={false}
            >
              <SkipForward className={cn("h-4 w-4", skipped && "text-foreground")} />
            </IconAction>
          ) : null}
          {onEdit ? (
            <IconAction label="Bearbeiten · ویرایش" onClick={onEdit}>
              <Pencil className="h-4 w-4" />
            </IconAction>
          ) : null}
          {onRemove ? (
            <IconAction label="Entfernen · حذف" tone="danger" onClick={onRemove}>
              <Trash2 className="h-4 w-4" />
            </IconAction>
          ) : null}
        </div>
      </div>
    </article>
  );
}
