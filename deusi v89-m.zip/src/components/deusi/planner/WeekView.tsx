import { Plus } from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import { formatDayShort, formatMinutes, weekDates, weekdayOf } from "@/lib/deusi/planner/date";
import { WEEKDAY_LABEL } from "@/lib/deusi/planner/config";
import type { PlannerSession } from "@/lib/deusi/planner/types";
import { cn } from "@/lib/utils";
import { SessionCard } from "./SessionCard";

/**
 * Wochenansicht.
 *
 * Mobil: die sieben Tage stapeln sich als volle Karten (kein horizontales
 * Scrollen, nichts wird abgeschnitten). Ab `lg` wieder das klassische
 * 7-Spalten-Raster.
 */
export function WeekView({
  weekStart,
  sessions,
  today,
  onOpenDay,
  onOpenSession,
  onAddAt,
}: {
  weekStart: string;
  sessions: PlannerSession[];
  today: string;
  onOpenDay: (date: string) => void;
  onOpenSession: (session: PlannerSession) => void;
  onAddAt: (date: string) => void;
}) {
  const days = weekDates(weekStart);

  return (
    <div className="-mx-1 overflow-x-auto overscroll-x-contain px-1 pb-2 [scrollbar-width:thin] lg:mx-0 lg:overflow-visible lg:px-0 lg:pb-0">
      <div className="flex snap-x snap-mandatory gap-2.5 lg:grid lg:grid-cols-7 lg:snap-none">
        {days.map((date) => {
          const daySessions = sessions.filter((s) => s.date === date);
          const minutes = daySessions.reduce((a, s) => a + s.minutes, 0);
          const done = daySessions.filter((s) => s.status === "done").length;
          const isToday = date === today;
          const label = WEEKDAY_LABEL[weekdayOf(date)]!;
          const pct = daySessions.length ? Math.round((done / daySessions.length) * 100) : 0;

          return (
            <section
              key={date}
              aria-label={`${label.de}, ${formatDayShort(date)}`}
              className={cn(
                "flex w-[70vw] max-w-[15rem] shrink-0 snap-start flex-col gap-2 rounded-3xl border p-2 transition-all sm:w-[16rem] lg:w-auto lg:min-w-0 lg:max-w-none lg:shrink lg:min-h-[240px]",
                isToday
                  ? "border-[color:var(--section-primary)]/40 bg-[color:var(--section-primary)]/[0.06] shadow-[0_14px_36px_-26px_var(--section-primary)]"
                  : "border-border/50 bg-muted/25 hover:border-border/80 hover:bg-muted/40",
              )}
            >
              <button
                type="button"
                onClick={() => onOpenDay(date)}
                className="min-w-0 rounded-2xl px-2 py-1.5 text-left transition-colors hover:bg-background/70"
              >
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-2">
                  <span className="min-w-0 truncate text-sm font-black tracking-tight">
                    {label.short}
                    <span className="ml-1 font-semibold text-muted-foreground lg:hidden">
                      {label.de}
                    </span>
                  </span>
                  <span
                    className={cn(
                      "shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold tabular-nums",
                      isToday
                        ? "bg-[color:var(--section-primary)] text-white shadow-[0_6px_14px_-8px_var(--section-primary)]"
                        : "text-muted-foreground",
                    )}
                  >
                    {formatDayShort(date)}
                  </span>
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-[11px] tabular-nums text-muted-foreground">
                  <span>{minutes ? formatMinutes(minutes) : "frei"}</span>
                  {daySessions.length ? (
                    <span className="rounded-full bg-background/70 px-1.5 font-semibold">
                      {done}/{daySessions.length}
                    </span>
                  ) : null}
                </div>
                {daySessions.length ? (
                  <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-background/70">
                    <div
                      className="h-full rounded-full transition-[width] duration-500"
                      style={{
                        width: `${pct}%`,
                        background:
                          "linear-gradient(90deg, color-mix(in oklab, var(--section-primary) 55%, white), var(--section-primary))",
                      }}
                    />
                  </div>
                ) : null}
              </button>

              <div className="flex min-w-0 flex-1 flex-col gap-2">
                {daySessions.map((s) => (
                  <SessionCard
                    key={s.id}
                    session={s}
                    variant="compact"
                    onEdit={() => onOpenSession(s)}
                  />
                ))}
                {!daySessions.length ? (
                  <div className="flex flex-1 flex-col items-center justify-center rounded-2xl border border-dashed border-border/50 px-2 py-4 text-center">
                    <p className="text-[11px] font-semibold text-muted-foreground">Ruhetag</p>
                    <Fa>روز استراحت</Fa>
                  </div>
                ) : null}
              </div>

              <button
                type="button"
                onClick={() => onAddAt(date)}
                aria-label={`Session am ${formatDayShort(date)} hinzufügen`}
                className="inline-flex items-center justify-center gap-1 rounded-2xl border border-dashed border-border/70 px-2 py-2 text-[11px] font-semibold text-muted-foreground transition-colors hover:border-[color:var(--section-primary)]/50 hover:bg-background/60 hover:text-foreground"
              >
                <Plus className="h-3.5 w-3.5" />
                Session
              </button>
            </section>
          );
        })}
      </div>
    </div>
  );
}
