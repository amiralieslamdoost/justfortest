import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

/**
 * Rahmen für die eigenständigen Planer-Unterseiten.
 * Bewusst kein Dialog: eigene Seite, eigener Zurück-Weg, viel Platz.
 */
export function PlannerSubPage({
  title,
  titleFa,
  intro,
  introFa,
  children,
}: {
  title: string;
  titleFa: string;
  intro?: string;
  introFa?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-5">
      <Link
        to="/planer"
        className="inline-flex w-fit items-center gap-2 rounded-full border border-border px-4 py-2 text-sm font-semibold transition-colors hover:bg-muted"
      >
        <ArrowLeft className="h-4 w-4" />
        Zurück zum Planer
        <span lang="fa" dir="rtl">
          · بازگشت
        </span>
      </Link>

      <header
        className="neu-card overflow-hidden p-5 sm:p-7"
        style={{
          background:
            "linear-gradient(135deg, color-mix(in oklab, var(--section-primary) 14%, transparent), transparent 65%)",
        }}
      >
        <h1 className="text-2xl font-black tracking-tight sm:text-3xl">{title}</h1>
        <p
          lang="fa"
          dir="rtl"
          className="mt-1 text-right text-base font-bold text-[color:var(--section-primary)]"
        >
          {titleFa}
        </p>
        {intro ? <p className="mt-3 text-sm text-muted-foreground">{intro}</p> : null}
        {introFa ? (
          <p
            lang="fa"
            dir="rtl"
            className="mt-1 text-right text-[13px] leading-7 text-muted-foreground"
          >
            {introFa}
          </p>
        ) : null}
      </header>

      <section className="neu-card p-5 sm:p-7">{children}</section>
    </div>
  );
}
