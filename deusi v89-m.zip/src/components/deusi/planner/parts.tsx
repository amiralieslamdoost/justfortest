import type { ReactNode } from "react";
import { Fa } from "@/components/deusi/Fa";
import { SKILL_LABEL } from "@/lib/deusi/planner/config";
import { formatMinutes } from "@/lib/deusi/planner/date";
import type { PlannerSession, SessionStatus, SkillKey } from "@/lib/deusi/planner/types";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";
import { cn } from "@/lib/utils";

/** Farbe einer Fertigkeit — bewusst aus den bestehenden Modul-Themes abgeleitet. */
export const SKILL_COLOR: Record<SkillKey, string> = {
  vocabulary: SECTION_THEME.dictionary.primary,
  grammar: SECTION_THEME.grammar.primary,
  listening: SECTION_THEME.podcasts.primary,
  speaking: SECTION_THEME["ai-coach"].primary,
  reading: SECTION_THEME.reading.primary,
  writing: SECTION_THEME.writing.primary,
};

export function SkillDot({ skill, className }: { skill: SkillKey; className?: string }) {
  return (
    <span
      aria-hidden
      className={cn("inline-block h-2 w-2 shrink-0 rounded-full", className)}
      style={{ backgroundColor: SKILL_COLOR[skill] }}
    />
  );
}

export function StatTile({
  label,
  labelFa,
  value,
  hint,
  compact,
}: {
  label: string;
  labelFa?: string;
  value: ReactNode;
  hint?: string;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "neu-card flex flex-col gap-0.5 transition-transform hover:-translate-y-px",
        compact ? "p-3" : "p-4",
      )}
    >
      <div className="truncate text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/80">
        {label}
      </div>
      <div className={cn("font-black tracking-tight", compact ? "text-xl" : "text-2xl")}>
        {value}
      </div>
      {labelFa ? <Fa>{labelFa}</Fa> : null}
      {hint ? <div className="text-xs text-muted-foreground">{hint}</div> : null}
    </div>
  );
}

/** Waagerechte Verteilungsleiste über alle Fertigkeiten. */
export function SkillBalance({
  distribution,
  progress,
}: {
  distribution: { skill: SkillKey; minutes: number }[];
  progress?: number;
}) {
  const total = distribution.reduce((a, d) => a + d.minutes, 0);
  if (!total) return null;
  const bright = (c: string) => `color-mix(in oklab, ${c} 72%, white)`;
  return (
    <div className="neu-card p-4">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h3 className="text-sm font-bold tracking-tight">Balance der Fertigkeiten</h3>
        <Fa inline>توازن مهارت‌ها</Fa>
      </div>
      <div
        className="flex h-4 w-full gap-1 overflow-hidden rounded-full bg-muted/70 p-0.5"
        role="img"
        aria-label={distribution
          .map((d) => `${SKILL_LABEL[d.skill].de}: ${formatMinutes(d.minutes)}`)
          .join(", ")}
      >
        {distribution.map((d) => (
          <span
            key={d.skill}
            className="rounded-full"
            style={{
              width: `${(d.minutes / total) * 100}%`,
              background: `linear-gradient(180deg, ${bright(SKILL_COLOR[d.skill])}, ${SKILL_COLOR[d.skill]})`,
              boxShadow: `0 2px 10px -4px ${SKILL_COLOR[d.skill]}`,
            }}
          />
        ))}
      </div>
      <ul className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5">
        {distribution.map((d) => (
          <li key={d.skill} className="flex min-w-0 items-center gap-1.5 text-xs">
            <span
              aria-hidden
              className="inline-block h-2.5 w-2.5 shrink-0 rounded-full"
              style={{
                background: `linear-gradient(180deg, ${bright(SKILL_COLOR[d.skill])}, ${SKILL_COLOR[d.skill]})`,
              }}
            />
            <span className="min-w-0 truncate font-semibold text-foreground">
              {SKILL_LABEL[d.skill].de}
            </span>
            <span className="ml-auto shrink-0 tabular-nums text-muted-foreground">
              {formatMinutes(d.minutes)}
            </span>
          </li>
        ))}
      </ul>
      {typeof progress === "number" ? (
        <div className="mt-3 border-t border-border/70 pt-3">
          <div className="mb-1.5 flex items-baseline justify-between text-[11px] font-semibold text-muted-foreground">
            <span>Wochenfortschritt · پیشرفت هفته</span>
            <span className="tabular-nums text-foreground">{progress}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full transition-[width] duration-500"
              style={{
                width: `${Math.min(100, Math.max(0, progress))}%`,
                background:
                  "linear-gradient(90deg, color-mix(in oklab, var(--section-primary) 60%, white), var(--section-primary))",
              }}
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

export const STATUS_LABEL: Record<SessionStatus, string> = {
  planned: "Geplant",
  done: "Erledigt",
  skipped: "Übersprungen",
};

export function StatusBadge({ status }: { status: SessionStatus }) {
  const tone =
    status === "done"
      ? "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300"
      : status === "skipped"
        ? "bg-muted text-muted-foreground"
        : "bg-[color:var(--section-primary)]/12 text-[color:var(--section-primary)]";
  return (
    <span className={cn("rounded-full px-2 py-0.5 text-[11px] font-bold", tone)}>
      {STATUS_LABEL[status]}
    </span>
  );
}

export function PriorityFlag({ session }: { session: PlannerSession }) {
  if (session.priority !== "high") return null;
  return (
    <span
      className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[11px] font-bold text-amber-700 dark:text-amber-300"
      title="Schwerpunkt dieser Woche"
    >
      Fokus
    </span>
  );
}

/** Segmentierter Umschalter (Woche / Tag, Intensität …). */
export function Segmented<T extends string>({
  value,
  options,
  onChange,
  ariaLabel,
  fullWidth,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
  ariaLabel: string;
  /** Auf Mobil sinnvoll: der Umschalter füllt die ganze Breite. */
  fullWidth?: boolean;
}) {
  return (
    <div
      role="tablist"
      aria-label={ariaLabel}
      className={cn("rounded-full bg-muted/70 p-1", fullWidth ? "flex w-full" : "inline-flex")}
    >
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(o.value)}
            className={cn(
              "rounded-full px-3.5 py-2 text-sm font-semibold transition-colors sm:py-1.5",
              fullWidth && "flex-1",
              active
                ? "bg-[color:var(--section-primary)] text-white shadow-sm"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

export function ChoiceChip({
  active,
  onClick,
  children,
  title,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  title?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      title={title}
      className={cn(
        "rounded-full border px-3.5 py-2 text-sm font-semibold outline-none transition-all",
        "focus-visible:ring-4 focus-visible:ring-[color:var(--section-primary)]/20",
        active
          ? "border-transparent bg-[color:var(--section-primary)] text-white shadow-sm"
          : "border-border/70 bg-background text-muted-foreground hover:border-border hover:bg-muted/50 hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

export function FieldLabel({
  children,
  fa,
  htmlFor,
}: {
  children: ReactNode;
  fa?: string;
  htmlFor?: string;
}) {
  return (
    <label
      htmlFor={htmlFor}
      className="mb-2 flex items-baseline gap-2 text-sm font-bold tracking-tight"
    >
      {children}
      {fa ? <Fa inline>{fa}</Fa> : null}
    </label>
  );
}

/** Beschrifteter Abschnitt in Planer-Formularen und Dialogen. */
export function FormSection({
  title,
  fa,
  hint,
  htmlFor,
  children,
}: {
  title: string;
  fa?: string;
  hint?: string;
  htmlFor?: string;
  children: ReactNode;
}) {
  return (
    <section>
      <FieldLabel htmlFor={htmlFor} fa={fa}>
        {title}
      </FieldLabel>
      {children}
      {hint ? <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{hint}</p> : null}
    </section>
  );
}
