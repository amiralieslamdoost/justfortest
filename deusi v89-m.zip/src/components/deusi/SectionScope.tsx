import type { CSSProperties, ReactNode } from "react";
import { SECTION_THEME, type SectionKey } from "@/lib/deusi/sectionTheme";

type SectionScopeProps = {
  sectionKey: SectionKey | null;
  children: ReactNode;
  className?: string;
};

/**
 * Wraps a page in its section's color identity.
 *
 * It only publishes CSS variables (--section-base/primary/accent) and lets
 * `src/styles.css` derive very soft tints from them (rings, chips, hovers,
 * borders, an ambient wash). Nothing here paints strong color directly —
 * the goal is a subtle, memorable tint per section, not a repaint.
 */
export function SectionScope({ sectionKey, children, className = "" }: SectionScopeProps) {
  if (!sectionKey) return <>{children}</>;

  const theme = SECTION_THEME[sectionKey];
  const style: CSSProperties = {
    ["--section-base" as never]: theme.base,
    ["--section-primary" as never]: theme.primary,
    ["--section-accent" as never]: theme.accent,
  };

  return (
    <div data-section={sectionKey} style={style} className={`section-scope ${className}`}>
      {children}
    </div>
  );
}
