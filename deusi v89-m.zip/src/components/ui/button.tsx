import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

/**
 * DEUSI Button — unified with the DEUSI design system (see styles.css utilities
 * `btn`, `btn-primary`, `btn-secondary`, `btn-ghost`, `btn-outline`,
 * `btn-danger`, `btn-sm`, `btn-lg`, `btn-icon`, `btn-loading`).
 */
const buttonVariants = cva("btn", {
  variants: {
    variant: {
      default: "btn-primary",
      primary: "btn-primary",
      secondary: "btn-secondary",
      outline: "btn-outline",
      ghost: "btn-ghost",
      destructive: "btn-danger",
      link: "!bg-transparent !shadow-none !h-auto !px-0 text-primary underline-offset-4 hover:underline",
    },
    size: {
      default: "",
      sm: "btn-sm",
      lg: "btn-lg",
      icon: "btn-icon",
    },
    loading: {
      true: "btn-loading",
      false: "",
    },
  },
  defaultVariants: {
    variant: "default",
    size: "default",
    loading: false,
  },
});

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, asChild = false, disabled, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, loading, className }))}
        ref={ref}
        disabled={disabled ?? Boolean(loading)}
        aria-busy={loading ? true : undefined}
        {...props}
      />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
