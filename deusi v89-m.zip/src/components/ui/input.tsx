import * as React from "react";

import { cn } from "@/lib/utils";

/** DEUSI Input — unified with the `field-base` utility in styles.css. */
const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return <input type={type} className={cn("field-base", className)} ref={ref} {...props} />;
  },
);
Input.displayName = "Input";

export { Input };
