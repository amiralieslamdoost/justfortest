import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

/**
 * DEUSI Badge — unified with the `badge-*` utilities in styles.css.
 */
const badgeVariants = cva("badge-base", {
  variants: {
    variant: {
      default: "badge-solid",
      solid: "badge-solid",
      secondary: "badge-soft",
      soft: "badge-soft",
      accent: "badge-accent",
      outline: "badge-outline",
      success: "badge-success",
      warning: "badge-warning",
      destructive: "badge-danger",
      danger: "badge-danger",
    },
  },
  defaultVariants: {
    variant: "default",
  },
});

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
