import { useEffect, useState, useCallback } from "react";
import type { DictWord, DictPos, CEFR } from "./types";
import { useDeusi } from "@/lib/deusi/store";
import {
  createCustomWord,
  deleteCustomWord,
  listCustomWords,
  updateCustomWord,
} from "@/lib/api/vocabulary";
import { startOfflineQueue } from "@/lib/api/offline-queue";

export interface NewWordInput {
  headword: string;
  pos: DictPos;
  cefr: CEFR;
  category: string;
  shortMeaning: string;
  translationFa?: string;
  translationEn?: string;
  ipa?: string;
  // noun
  article?: "der" | "die" | "das";
  plural?: string;
  genitive?: string;
  // verb
  aux?: "haben" | "sein";
  praeteritum?: string;
  partizipII?: string;
  separable?: boolean;
  regular?: boolean;
  objectCase?: "Akk" | "Dat" | "Gen" | "none";
  reflexive?: boolean;
  prepositionText?: string;
  prepositionCase?: "Akk" | "Dat" | "Gen";
  // adjective
  comparative?: string;
  superlative?: string;
  // examples (up to 3)
  examples?: string[];
}

export function inputToDictWord(input: NewWordInput): DictWord {
  const id = "custom-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
  const base: DictWord = {
    id,
    headword: input.headword.trim(),
    lemma: input.headword.trim().toLowerCase(),
    pos: input.pos,
    cefr: input.cefr,
    category: input.category,
    frequency: 50,
    ipa: input.ipa ?? "",
    shortMeaning: input.shortMeaning.trim(),
    meanings: [
      {
        de: input.shortMeaning.trim(),
        fa: input.translationFa,
        en: input.translationEn,
      },
    ],
    difficulty: 3,
    examples: (input.examples ?? []).filter(Boolean).map((de, i) => ({
      id: `${id}-ex-${i}`,
      de,
      en: "",
    })),
    family: {
      synonyms: [],
      antonyms: [],
      similar: [],
      compounds: [],
      relatedVerbs: [],
      relatedNouns: [],
      relatedAdjectives: [],
    },
  };
  if (input.pos === "noun" && input.article) {
    base.nounGrammar = {
      article: input.article,
      gender: input.article === "der" ? "m" : input.article === "die" ? "f" : "n",
      plural: input.plural ?? "",
      genitive: input.genitive ?? "",
    };
  }
  if (input.pos === "verb") {
    const empty = { ich: "", du: "", er: "", wir: "", ihr: "", sie: "" };
    base.verbGrammar = {
      separable: input.separable ?? false,
      regular: input.regular ?? true,
      aux: input.aux ?? "haben",
      praeteritum: input.praeteritum ?? "",
      perfekt:
        `${(input.aux ?? "haben") === "sein" ? "ist" : "hat"} ${input.partizipII ?? ""}`.trim(),
      partizipII: input.partizipII ?? "",
      praesens: empty,
      praeteritumConj: empty,
      perfektConj: empty,
      objectCase: input.objectCase,
      reflexive: input.reflexive,
      governedPrepositions:
        input.prepositionText && input.prepositionCase
          ? [{ text: input.prepositionText, case: input.prepositionCase }]
          : undefined,
    };
  }
  if (input.pos === "adjective") {
    base.adjectiveGrammar = {
      comparative: input.comparative ?? "",
      superlative: input.superlative ?? "",
      attributive: { nom: "", akk: "", dat: "", gen: "" },
      collocations: [],
    };
  }
  return base;
}

/**
 * واژه‌های شخصی کاربر.
 * امضای هوک تغییری نکرده؛ داده از لایهٔ API می‌آید (سرور: `user_words`،
 * حالت MOCK: localStorage) و نوشتن‌ها در نبود شبکه به صف آفلاین می‌روند.
 */
export function useCustomWords() {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const [words, setWords] = useState<DictWord[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let alive = true;
    startOfflineQueue();
    void listCustomWords(userId).then((list) => {
      if (!alive) return;
      setWords(list);
      setHydrated(true);
    });
    return () => {
      alive = false;
    };
  }, [userId]);

  const add = useCallback(
    (input: NewWordInput) => {
      const w = inputToDictWord(input);
      setWords((prev) => [w, ...prev]);
      void createCustomWord(userId, w);
      return w;
    },
    [userId],
  );
  const remove = useCallback(
    (id: string) => {
      setWords((prev) => prev.filter((w) => w.id !== id));
      void deleteCustomWord(userId, id);
    },
    [userId],
  );
  const update = useCallback(
    (id: string, patch: Partial<DictWord>) => {
      setWords((prev) => prev.map((w) => (w.id === id ? { ...w, ...patch } : w)));
      void updateCustomWord(userId, id, patch);
    },
    [userId],
  );

  return { words, hydrated, add, remove, update };
}
