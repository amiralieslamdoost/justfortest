// Sprichwörter & Redewendungen — deutsche Redewendungen mit Übersetzung
export type ProverbKind = "sprichwort" | "redewendung";

export interface Proverb {
  id: string;
  kind: ProverbKind;
  de: string;
  literal: string; // literal English gloss
  fa: string; // Persian meaning
  meaning: string; // German explanation
  example?: string;
  cefr: "A2" | "B1" | "B2" | "C1";
  icon: string;
  color: string;
}

export const PROVERBS: Proverb[] = [
  {
    id: "p1",
    kind: "sprichwort",
    de: "Übung macht den Meister.",
    literal: "Practice makes the master.",
    fa: "کار نیکو کردن از پُر کردن است.",
    meaning: "Wer viel übt, wird sehr gut in einer Sache.",
    example: "Spiel jeden Tag Klavier — Übung macht den Meister!",
    cefr: "A2",
    icon: "🎯",
    color: "#DD2222",
  },
  {
    id: "p2",
    kind: "sprichwort",
    de: "Morgenstund hat Gold im Mund.",
    literal: "The morning hour has gold in its mouth.",
    fa: "سحرخیز باش تا کامروا شوی.",
    meaning: "Wer früh aufsteht, schafft viel und hat Erfolg.",
    cefr: "B1",
    icon: "🌅",
    color: "#F7C948",
  },
  {
    id: "p3",
    kind: "sprichwort",
    de: "Aller Anfang ist schwer.",
    literal: "Every beginning is hard.",
    fa: "شروع هر کاری دشوار است.",
    meaning: "Am Anfang einer Sache ist immer alles neu und ungewohnt.",
    cefr: "A2",
    icon: "🌱",
    color: "#22C55E",
  },
  {
    id: "p4",
    kind: "redewendung",
    de: "Tomaten auf den Augen haben.",
    literal: "To have tomatoes on the eyes.",
    fa: "چشم داشتن و ندیدن.",
    meaning: "Etwas Offensichtliches nicht sehen.",
    example: "Der Schlüssel liegt direkt vor dir — hast du Tomaten auf den Augen?",
    cefr: "B1",
    icon: "🍅",
    color: "#EF4444",
  },
  {
    id: "p5",
    kind: "redewendung",
    de: "Ich verstehe nur Bahnhof.",
    literal: "I only understand train station.",
    fa: "چیزی سرم نمی‌شود.",
    meaning: "Ich verstehe gar nichts von dem, was du sagst.",
    cefr: "B1",
    icon: "🚉",
    color: "#0EA5E9",
  },
  {
    id: "p6",
    kind: "sprichwort",
    de: "Wer A sagt, muss auch B sagen.",
    literal: "Who says A must also say B.",
    fa: "چون گفتی «الف»، «ب» را هم بگو.",
    meaning: "Wer etwas beginnt, sollte es zu Ende bringen.",
    cefr: "B1",
    icon: "🔤",
    color: "#8B5CF6",
  },
  {
    id: "p7",
    kind: "redewendung",
    de: "Das ist mir Wurst.",
    literal: "That is sausage to me.",
    fa: "برایم فرقی نمی‌کند.",
    meaning: "Das ist mir egal.",
    cefr: "A2",
    icon: "🌭",
    color: "#F97316",
  },
  {
    id: "p8",
    kind: "sprichwort",
    de: "In der Kürze liegt die Würze.",
    literal: "In brevity lies the spice.",
    fa: "کم‌گو و گزیده‌گو.",
    meaning: "Kurze, prägnante Aussagen sind oft am besten.",
    cefr: "B2",
    icon: "✂️",
    color: "#EC4899",
  },
];
