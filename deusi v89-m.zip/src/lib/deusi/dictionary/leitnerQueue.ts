import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useDeusi } from "@/lib/deusi/store";
import {
  listLeitnerItems,
  removeLeitnerItem,
  upsertLeitnerItem,
  type LeitnerItem,
} from "@/lib/api/vocabulary";
import { startOfflineQueue } from "@/lib/api/offline-queue";

export type LeitnerBoxNum = 1 | 2 | 3 | 4 | 5;

export interface LeitnerQueueItem {
  id: string;
  box: LeitnerBoxNum;
}

/**
 * صف Leitner کاربر.
 * امضای هوک مثل قبل است، اما داده از لایهٔ API می‌آید:
 * روی سرور در `srs_cards` و در حالت MOCK روی localStorage.
 * نوشتن‌ها خوش‌بینانه‌اند و در نبود شبکه به صف آفلاین می‌روند.
 */
export function useLeitnerQueue() {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const [items, setItems] = useState<LeitnerQueueItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let alive = true;
    startOfflineQueue();
    void listLeitnerItems(userId).then((list) => {
      if (!alive) return;
      setItems(list.map((i) => ({ id: i.id, box: i.box })));
      setHydrated(true);
    });
    return () => {
      alive = false;
    };
  }, [userId]);

  const persist = useCallback(
    (item: LeitnerItem) => {
      void upsertLeitnerItem(userId, item);
    },
    [userId],
  );

  const ids = useMemo(() => items.map((i) => i.id), [items]);
  const has = useCallback((id: string) => items.some((i) => i.id === id), [items]);

  const add = useCallback(
    (id: string, label?: string) => {
      setItems((prev) =>
        prev.some((i) => i.id === id) ? prev : [{ id, box: 1 as LeitnerBoxNum }, ...prev],
      );
      persist({ id, box: 1 });
      toast.success("Zu Box 1 hinzugefügt", { description: label ?? "Wort" });
    },
    [persist],
  );

  const remove = useCallback(
    (id: string, label?: string) => {
      setItems((prev) => prev.filter((i) => i.id !== id));
      void removeLeitnerItem(userId, id);
      toast.success("Aus Leitner-Kasten entfernt", { description: label ?? "Wort" });
    },
    [userId],
  );

  const toggle = useCallback(
    (id: string, label?: string) => {
      if (items.some((i) => i.id === id)) remove(id, label);
      else add(id, label);
    },
    [items, add, remove],
  );

  const idsInBox = useCallback(
    (box: LeitnerBoxNum) => items.filter((i) => i.box === box).map((i) => i.id),
    [items],
  );

  /** افزودن گروهی (مثلاً یک خانوادهٔ واژگان) با یک toast. */
  const addMany = useCallback(
    (newIds: string[], label?: string) => {
      let added = 0;
      setItems((prev) => {
        const known = new Set(prev.map((i) => i.id));
        const fresh = newIds
          .filter((id) => !known.has(id))
          .map((id) => ({ id, box: 1 as LeitnerBoxNum }));
        added = fresh.length;
        fresh.forEach((i) => persist({ id: i.id, box: 1 }));
        return fresh.length ? [...fresh, ...prev] : prev;
      });
      toast.success(`${newIds.length} Wörter zu Box 1 hinzugefügt`, { description: label });
      return added;
    },
    [persist],
  );

  /** ثبت نتیجهٔ مرور (خروجی fsrs.ts) و همگام‌سازی با سرور. */
  const applyReview = useCallback(
    (card: {
      wordId: string;
      box: number;
      reps: number;
      lapses: number;
      ease: number;
      interval: number;
      due: number;
    }) => {
      const box = Math.min(5, Math.max(1, card.box)) as LeitnerBoxNum;
      setItems((prev) =>
        prev.some((i) => i.id === card.wordId)
          ? prev.map((i) => (i.id === card.wordId ? { ...i, box } : i))
          : [{ id: card.wordId, box }, ...prev],
      );
      persist({
        id: card.wordId,
        box,
        reps: card.reps,
        lapses: card.lapses,
        ease: card.ease,
        interval: card.interval,
        dueAt: new Date(card.due).toISOString(),
      });
    },
    [persist],
  );

  return {
    items,
    ids,
    count: items.length,
    hydrated,
    has,
    add,
    addMany,
    remove,
    toggle,
    idsInBox,
    applyReview,
  };
}
