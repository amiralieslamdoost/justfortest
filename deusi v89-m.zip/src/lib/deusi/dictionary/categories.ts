import type { DictionaryCategory } from "./types";

export const CATEGORIES: DictionaryCategory[] = [
  { id: "menschen", label: "Menschen", icon: "👤", color: "#F59E0B" },
  { id: "zeit", label: "Zeit & Daten", icon: "🕐", color: "#EF4444" },
  { id: "essen", label: "Essen & Trinken", icon: "☕", color: "#8B5CF6" },
  { id: "reisen", label: "Reisen & Orte", icon: "📍", color: "#EC4899" },
  { id: "natur", label: "Natur & Umwelt", icon: "🌱", color: "#22C55E" },
  { id: "bildung", label: "Bildung & Beruf", icon: "💼", color: "#8B5A2B" },
  { id: "gefuehl", label: "Gefühle", icon: "💛", color: "#F97316" },
  { id: "haus", label: "Haus & Zuhause", icon: "🏠", color: "#0EA5E9" },
  { id: "koerper", label: "Körper & Gesundheit", icon: "🫀", color: "#DD2222" },
  { id: "technik", label: "Technik & Medien", icon: "💻", color: "#6366F1" },
  { id: "kunst", label: "Kunst & Kultur", icon: "🎨", color: "#A855F7" },
  { id: "verkehr", label: "Verkehr", icon: "🚉", color: "#0891B2" },
  { id: "sport", label: "Sport & Freizeit", icon: "⚽", color: "#059669" },
  { id: "abstrakt", label: "Abstrakte Begriffe", icon: "✨", color: "#7C3AED" },
];

export const CEFR_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"] as const;

export const POS_LABEL: Record<string, string> = {
  noun: "Substantiv",
  verb: "Verb",
  adjective: "Adjektiv",
  adverb: "Adverb",
  preposition: "Präposition",
  conjunction: "Konjunktion",
  pronoun: "Pronomen",
};

export const POS_SHORT: Record<string, string> = {
  noun: "Nomen",
  verb: "Verb",
  adjective: "Adj.",
  adverb: "Adv.",
  preposition: "Präp.",
  conjunction: "Konj.",
  pronoun: "Pron.",
};

export const POS_COLOR: Record<string, string> = {
  noun: "#2563eb",
  verb: "#8B5CF6",
  adjective: "#22C55E",
  adverb: "#0EA5E9",
  preposition: "#EC4899",
  conjunction: "#F59E0B",
  pronoun: "#EF4444",
};

export const CEFR_COLOR: Record<string, string> = {
  A1: "#22C55E",
  A2: "#3B82F6",
  B1: "#8B5CF6",
  B2: "#F59E0B",
  C1: "#EF4444",
  C2: "#7C3AED",
};
