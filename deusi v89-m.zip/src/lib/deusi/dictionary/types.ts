// ============ Dictionary Module Types ============
// Self-contained types for the new Dictionary module.
// Kept separate from the legacy Word type in ../types.ts so this module can
// evolve independently and be replaced by real backend APIs later.

export type CEFR = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type DictPos =
  "noun" | "verb" | "adjective" | "adverb" | "preposition" | "conjunction" | "pronoun";

export type Article = "der" | "die" | "das";
export type Gender = "m" | "f" | "n";

export interface Meaning {
  de: string; // definition in German
  fa?: string; // Persian gloss
  en?: string; // English gloss
}

export interface ExampleSentence {
  id: string;
  de: string;
  en: string;
  fa?: string;
}

export interface Conjugation {
  ich: string;
  du: string;
  er: string;
  wir: string;
  ihr: string;
  sie: string;
}

export interface NounGrammar {
  article: Article;
  gender: Gender;
  plural: string;
  genitive: string;
  declension?: string; // e.g. "n-deklination"
}

export type VerbCase = "Akk" | "Dat" | "Gen" | "none";

export interface GovernedPreposition {
  text: string;
  case: "Akk" | "Dat" | "Gen";
  example?: string;
}

export interface VerbGrammar {
  separable: boolean;
  regular: boolean;
  aux: "haben" | "sein";
  praeteritum: string;
  perfekt: string; // "hat gelernt"
  partizipII: string;
  praesens: Conjugation;
  praeteritumConj: Conjugation;
  perfektConj: Conjugation;
  /** Which case the direct object takes (transitive verbs). */
  objectCase?: VerbCase;
  /** Whether the verb is (typically) reflexive (sich ...). */
  reflexive?: boolean;
  /** Single fixed preposition (legacy shape, still supported). */
  governedPreposition?: GovernedPreposition;
  /** Multiple governed prepositions (preferred going forward). */
  governedPrepositions?: GovernedPreposition[];
}

export interface AdjectiveGrammar {
  comparative: string;
  superlative: string;
  attributive: { nom: string; akk: string; dat: string; gen: string };
  collocations: string[];
}

export interface AdverbGrammar {
  usage: string;
  position: string;
}

export interface PrepositionGrammar {
  cases: Array<"Nom" | "Akk" | "Dat" | "Gen">;
  examples: string[];
}

export interface WordFamily {
  synonyms: string[];
  antonyms: string[];
  similar: string[];
  compounds: string[];
  relatedVerbs: string[];
  relatedNouns: string[];
  relatedAdjectives: string[];
}

export interface DictWord {
  id: string;
  headword: string; // display word (with capitalization)
  lemma: string; // lowercase base
  pos: DictPos;
  cefr: CEFR;
  category: string; // one of CATEGORIES keys
  frequency: number; // 0..100 how common
  ipa: string; // phonetic
  shortMeaning: string; // one-line
  meanings: Meaning[];
  usage?: string; // common usage note
  difficulty: 1 | 2 | 3 | 4 | 5;
  examples: ExampleSentence[];
  family: WordFamily;
  memoryTip?: string;
  imagePrompt?: string; // used for illustration cards
  // grammar (only the relevant one populated)
  nounGrammar?: NounGrammar;
  verbGrammar?: VerbGrammar;
  adjectiveGrammar?: AdjectiveGrammar;
  adverbGrammar?: AdverbGrammar;
  prepositionGrammar?: PrepositionGrammar;
}

export interface UserWordState {
  wordId: string;
  bookmarked: boolean;
  progress: number; // 0..100 mastery
  status: "new" | "learning" | "known";
  lastSeen: number; // timestamp
  views: number;
}

export interface DictionaryCategory {
  id: string;
  label: string;
  icon: string; // emoji fallback
  color: string; // hex accent
}
