export type BookLevel = "A1" | "A2" | "B1" | "B2" | "C1";

export type LearningBook = {
  id: string;
  title: string;
  publisher: string;
  level: BookLevel;
  cover: string; // emoji fallback
  coverUrl?: string; // real book image (fill in later)
  color: string;
  wordCount: number;
  wordIds: string[];
};

// Mock data — word ids reference entries in mockWords.ts
export const LEARNING_BOOKS: LearningBook[] = [
  {
    id: "menschen-a1",
    title: "Menschen A1",
    publisher: "Hueber",
    level: "A1",
    cover: "📕",
    color: "#22C55E",
    wordCount: 620,
    wordIds: ["zeit", "freund", "morgen", "lernen"],
  },
  {
    id: "menschen-a2",
    title: "Menschen A2",
    publisher: "Hueber",
    level: "A2",
    cover: "📗",
    color: "#3B82F6",
    wordCount: 780,
    wordIds: ["lernen", "wunderbar", "geniessen", "morgen"],
  },
  {
    id: "menschen-b1",
    title: "Menschen B1",
    publisher: "Hueber",
    level: "B1",
    cover: "📘",
    color: "#8B5CF6",
    wordCount: 950,
    wordIds: ["entwickeln", "abenteuer", "wunderbar", "traumhaft"],
  },
  {
    id: "netzwerk-a1",
    title: "Netzwerk Neu A1",
    publisher: "Klett",
    level: "A1",
    cover: "📙",
    color: "#22C55E",
    wordCount: 590,
    wordIds: ["zeit", "morgen", "freund"],
  },
  {
    id: "netzwerk-b1",
    title: "Netzwerk Neu B1",
    publisher: "Klett",
    level: "B1",
    cover: "📓",
    color: "#8B5CF6",
    wordCount: 910,
    wordIds: ["entwickeln", "geniessen", "abenteuer"],
  },
  {
    id: "aspekte-b2",
    title: "Aspekte Neu B2",
    publisher: "Klett",
    level: "B2",
    cover: "📔",
    color: "#F59E0B",
    wordCount: 1240,
    wordIds: ["entwickeln", "traumhaft", "abenteuer", "wunderbar"],
  },
  {
    id: "sicher-c1",
    title: "Sicher! C1",
    publisher: "Hueber",
    level: "C1",
    cover: "📚",
    color: "#EF4444",
    wordCount: 1580,
    wordIds: ["entwickeln", "traumhaft", "geniessen"],
  },
  {
    id: "studio-a2",
    title: "Studio [21] A2",
    publisher: "Cornelsen",
    level: "A2",
    cover: "📒",
    color: "#3B82F6",
    wordCount: 720,
    wordIds: ["lernen", "morgen", "freund", "wunderbar"],
  },
];
