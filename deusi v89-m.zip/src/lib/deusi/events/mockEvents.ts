import cafeCover from "@/assets/events/sprachpraxis-cafe.jpg";
import spieleCover from "@/assets/events/spieleabend.jpg";
import filmCover from "@/assets/events/filmabend.jpg";
import grammatikCover from "@/assets/events/grammatik.jpg";
import ausspracheCover from "@/assets/events/aussprache.jpg";

export type CefrLevel = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";
export type LevelBand = "B1-B2" | "C1-C2";

export interface Organizer {
  id: string;
  name: string;
  tagline: string;
  rating: number;
  reviews: number;
  events: number;
  participants: string;
  satisfaction: string;
  verified: boolean;
}

export interface GroupLeader {
  id: string;
  name: string;
  role: string; // Tischleiterin / Tischleiter
}

export interface SeatReservation {
  seat: number; // 1..10
  participantName: string;
  order?: string; // café order
}

export interface EventGroup {
  id: string; // "A".."G"
  name: string; // "Gruppe A"
  level: LevelBand;
  tableNumber: number;
  seats: number; // total, 10
  leader: GroupLeader;
  reservations: SeatReservation[]; // pre-filled demo seats
}

export interface WeeklyTopics {
  weekLabel: string; // "KW 21 · 20.–26. Mai"
  topics: Record<LevelBand, string[]>;
}

export interface DeusiEvent {
  id: string;
  /** شناسهٔ رکورد PocketBase (فقط در حالت BACKEND پر می‌شود؛ برای رابطهٔ RSVP) */
  recordId?: string;
  instituteId: string; // multi-tenant
  title: string;
  shortDescription: string;
  description: string;
  cover: string;
  organizer: Organizer;
  date: string; // "Samstag, 25. Mai 2024"
  dateShort: string; // "25. Mai 2024"
  weekday: string; // "Samstag"
  time: string; // "16:00 – 18:00"
  duration: string; // "2 Stunden"
  locationName: string;
  locationAddress: string;
  levels: CefrLevel[];
  levelSummary: string; // "B1 – C1"
  bands: LevelBand[];
  themesCount: number;
  groupsCount: number;
  seatsPerGroup: number;
  notes: string[];
  hasRegistration: boolean; // only true for the fully wired event
  groups?: EventGroup[];
  weekly?: WeeklyTopics;
}

const deutschMashhad: Organizer = {
  id: "org_deutsch_mashhad",
  name: "Deutsch Mashhad",
  tagline: "Professionelle Deutschkurse & Sprachpraxis",
  rating: 4.9,
  reviews: 230,
  events: 23,
  participants: "1.250+",
  satisfaction: "98%",
  verified: true,
};

const goetheClub: Organizer = {
  id: "org_goethe_club",
  name: "Goethe Klub Berlin",
  tagline: "Deutsche Kultur, Sprache & Community",
  rating: 4.8,
  reviews: 187,
  events: 41,
  participants: "3.400+",
  satisfaction: "97%",
  verified: true,
};

const leaders: GroupLeader[] = [
  { id: "l_anna", name: "Anna Müller", role: "Tischleiterin" },
  { id: "l_lena", name: "Lena Fischer", role: "Tischleiterin" },
  { id: "l_tobias", name: "Tobias Krüger", role: "Tischleiter" },
  { id: "l_hannah", name: "Hannah Vogel", role: "Tischleiterin" },
  { id: "l_jonas", name: "Jonas Bauer", role: "Tischleiter" },
  { id: "l_marlene", name: "Marlene Kaiser", role: "Tischleiterin" },
  { id: "l_niklas", name: "Niklas Böhm", role: "Tischleiter" },
];

const sampleOrders = [
  "Cappuccino",
  "Latte Macchiato",
  "Espresso",
  "Wasser",
  "Schwarzer Tee",
  "Käsekuchen",
  "Apfelschorle",
  "Heiße Schokolade",
  "Orangensaft",
  "Croissant",
];
const sampleNames = [
  "Max Mustermann",
  "Sarah Müller",
  "Leon Schmidt",
  "Anna Weber",
  "Thomas Becker",
  "Julia Hoffmann",
  "Lukas Wagner",
  "Lea Fischer",
  "Paul Klein",
  "Mia Richter",
  "Felix Braun",
  "Emma Schulz",
  "Noah Neumann",
  "Clara Zimmermann",
  "David Hartmann",
];

function makeGroup(
  letter: string,
  level: LevelBand,
  table: number,
  leader: GroupLeader,
  filledSeats: number[],
): EventGroup {
  const reservations: SeatReservation[] = filledSeats.map((seat, i) => ({
    seat,
    participantName: sampleNames[(seat + table * 3 + i) % sampleNames.length],
    order:
      Math.random() > 0.35 ? sampleOrders[(seat + i + table) % sampleOrders.length] : undefined,
  }));
  return {
    id: letter,
    name: `Gruppe ${letter}`,
    level,
    tableNumber: table,
    seats: 10,
    leader,
    reservations,
  };
}

const sprachpraxisGroups: EventGroup[] = [
  makeGroup("A", "B1-B2", 1, leaders[0], [1, 2, 4, 5, 6, 7, 8, 9, 10]), // 9/10
  makeGroup("B", "B1-B2", 3, leaders[1], [1, 2, 4, 5, 6, 8, 9, 10]), // 8/10 → seat 3 & 7 free (7 will be assigned)
  makeGroup("C", "B1-B2", 5, leaders[2], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), // 10/10 voll
  makeGroup("D", "C1-C2", 2, leaders[3], [1, 3, 5, 6, 7, 8]), // 6/10
  makeGroup("E", "C1-C2", 4, leaders[4], [1, 2, 3, 5, 6, 8, 10]), // 7/10
  makeGroup("F", "C1-C2", 6, leaders[5], [2, 4, 5, 7, 9, 10]), // 6/10
  makeGroup("G", "C1-C2", 7, leaders[6], [1, 3, 5, 7, 9]), // 5/10
];

const sprachpraxisWeekly: WeeklyTopics = {
  weekLabel: "Diese Woche · KW 21",
  topics: {
    "B1-B2": ["Reisen", "Arbeit"],
    "C1-C2": ["Künstliche Intelligenz", "Gesellschaft"],
  },
};

export const MOCK_EVENTS: DeusiEvent[] = [
  {
    id: "sprachpraxis-cafe",
    instituteId: deutschMashhad.id,
    title: "Sprachpraxis im Café",
    shortDescription:
      "Sprechen üben, neue Leute treffen und Deutsch in entspannter Atmosphäre verbessern.",
    description:
      "Ein wöchentliches Treffen für Deutschlernende, die ihr Sprechen in einer warmen Café-Atmosphäre trainieren möchten. Sieben kleine Gruppen, feste Tischleiter:innen und jede Woche neue Konversationsthemen.",
    cover: cafeCover,
    organizer: deutschMashhad,
    date: "Samstag, 25. Mai 2024",
    dateShort: "25. Mai 2024",
    weekday: "Samstag",
    time: "16:00 – 18:00",
    duration: "2 Stunden",
    locationName: "Café Central",
    locationAddress: "Leipziger Str. 56, 10117 Berlin",
    levels: ["B1", "B2", "C1"],
    levelSummary: "B1 – C1",
    bands: ["B1-B2", "C1-C2"],
    themesCount: 4,
    groupsCount: 7,
    seatsPerGroup: 10,
    notes: [
      "Bitte sei pünktlich.",
      "Mindestens eine Bestellung ist Pflicht.",
      "Respektvoll miteinander sprechen.",
      "Viel Spaß und gutes Lernen! 🙂",
    ],
    hasRegistration: true,
    groups: sprachpraxisGroups,
    weekly: sprachpraxisWeekly,
  },
  {
    id: "spieleabend",
    instituteId: deutschMashhad.id,
    title: "Spieleabend auf Deutsch",
    shortDescription: "Brettspiele und Kartenspiele auf Deutsch – lernen, spielen, lachen.",
    description:
      "Ein entspannter Abend mit deutschen Brett- und Kartenspielen. Perfekt zum Wortschatztraining.",
    cover: spieleCover,
    organizer: deutschMashhad,
    date: "Freitag, 31. Mai 2024",
    dateShort: "31. Mai 2024",
    weekday: "Freitag",
    time: "19:00 – 22:00",
    duration: "3 Stunden",
    locationName: "Deutsch Mashhad Studio",
    locationAddress: "Torstraße 123, 10119 Berlin",
    levels: ["A2", "B1", "B2"],
    levelSummary: "A2 – B2",
    bands: ["B1-B2"],
    themesCount: 3,
    groupsCount: 4,
    seatsPerGroup: 6,
    notes: ["Getränke sind inklusive.", "Bitte pünktlich sein."],
    hasRegistration: false,
  },
  {
    id: "filmabend",
    instituteId: goetheClub.id,
    title: "Filmabend",
    shortDescription: "Ein deutscher Klassiker mit Untertiteln und anschließender Diskussion.",
    description:
      "Wir zeigen einen deutschen Filmklassiker und sprechen anschließend gemeinsam über Handlung, Sprache und Kultur.",
    cover: filmCover,
    organizer: goetheClub,
    date: "Sonntag, 2. Juni 2024",
    dateShort: "2. Juni 2024",
    weekday: "Sonntag",
    time: "18:30 – 21:30",
    duration: "3 Stunden",
    locationName: "Kino Central",
    locationAddress: "Rosenthaler Str. 39, 10178 Berlin",
    levels: ["B2", "C1", "C2"],
    levelSummary: "B2 – C2",
    bands: ["C1-C2"],
    themesCount: 1,
    groupsCount: 1,
    seatsPerGroup: 40,
    notes: ["Popcorn inklusive.", "Deutsche Untertitel verfügbar."],
    hasRegistration: false,
  },
  {
    id: "grammatik-workshop",
    instituteId: deutschMashhad.id,
    title: "Grammatik Workshop",
    shortDescription: "Intensives Training zu Akkusativ, Dativ und Genitiv.",
    description:
      "Praxisnaher Workshop rund um die deutschen Kasus – mit vielen Übungen und Beispielen.",
    cover: grammatikCover,
    organizer: deutschMashhad,
    date: "Samstag, 8. Juni 2024",
    dateShort: "8. Juni 2024",
    weekday: "Samstag",
    time: "10:00 – 13:00",
    duration: "3 Stunden",
    locationName: "Online (Zoom)",
    locationAddress: "Live · Zoom-Link nach Anmeldung",
    levels: ["A2", "B1"],
    levelSummary: "A2 – B1",
    bands: ["B1-B2"],
    themesCount: 3,
    groupsCount: 2,
    seatsPerGroup: 15,
    notes: ["Materialien werden bereitgestellt.", "Notizblock empfohlen."],
    hasRegistration: false,
  },
  {
    id: "aussprache-training",
    instituteId: goetheClub.id,
    title: "Aussprache Training",
    shortDescription: "Perfektioniere deine deutsche Aussprache mit gezielten Übungen.",
    description:
      "Fokus auf schwierige Laute, Betonung und Rhythmus. Kleine Gruppen für viel Sprechzeit.",
    cover: ausspracheCover,
    organizer: goetheClub,
    date: "Mittwoch, 12. Juni 2024",
    dateShort: "12. Juni 2024",
    weekday: "Mittwoch",
    time: "18:00 – 19:30",
    duration: "90 Minuten",
    locationName: "Studio Prenzlauer Berg",
    locationAddress: "Kastanienallee 82, 10435 Berlin",
    levels: ["A2", "B1", "B2"],
    levelSummary: "A2 – B2",
    bands: ["B1-B2"],
    themesCount: 2,
    groupsCount: 3,
    seatsPerGroup: 8,
    notes: ["Kopfhörer mitbringen.", "Wasser wird bereitgestellt."],
    hasRegistration: false,
  },
];

export function getEvent(id: string): DeusiEvent | undefined {
  return MOCK_EVENTS.find((e) => e.id === id);
}
