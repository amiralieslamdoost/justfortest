import { useCallback, useEffect, useState } from "react";
import { MOCK_EVENTS, type DeusiEvent, type EventGroup } from "./mockEvents";
import * as api from "@/lib/api/events";
import type { EventState, Registration } from "@/lib/api/events";
import { useDeusi } from "@/lib/deusi/store";

/**
 * Anmeldungen & Bestellungen eines Events.
 *
 * Lesen/Schreiben laufen über die Datenschicht (`@/lib/api/events`:
 * PocketBase `event_rsvps`, sonst lokaler Spiegel pro
 * `${instituteId}::${eventId}`). Realtime hält Sitzplätze geräteübergreifend
 * aktuell; doppelte Plätze werden beim Reservieren erkannt.
 */

export type { Registration } from "@/lib/api/events";

const EMPTY: EventState = { reservations: {}, myRegistration: null };

// Merge seed reservations + persisted extras
export function mergedGroups(event: DeusiEvent, state: EventState): EventGroup[] {
  if (!event.groups) return [];
  return event.groups.map((g) => {
    const extra = state.reservations[g.id] ?? [];
    const merged = [
      ...g.reservations,
      ...extra.filter((e) => !g.reservations.some((r) => r.seat === e.seat)),
    ];
    return { ...g, reservations: merged };
  });
}

export function useEventState(event: DeusiEvent) {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const [state, setState] = useState<EventState>(EMPTY);
  const [hydrated, setHydrated] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    const next = await api.loadEventState(userId, event);
    setState(next);
    setHydrated(true);
  }, [userId, event]);

  useEffect(() => {
    void reload();
  }, [reload]);

  // Sitzplätze anderer Teilnehmer live übernehmen.
  useEffect(() => {
    return api.subscribeEvent(event.recordId ?? event.id, () => {
      void reload();
    });
  }, [event.id, reload]);

  const groups = mergedGroups(event, state);

  const findFirstFreeSeat = useCallback((): { group: EventGroup; seat: number } | null => {
    for (const g of groups) {
      const taken = new Set(g.reservations.map((r) => r.seat));
      for (let s = 1; s <= g.seats; s++) {
        if (!taken.has(s)) return { group: g, seat: s };
      }
    }
    return null;
  }, [groups]);

  const register = useCallback(
    (participantName: string): Registration | null => {
      if (state.myRegistration) return state.myRegistration;
      const spot = findFirstFreeSeat();
      if (!spot) {
        setError("Alle Plätze sind belegt.");
        return null;
      }

      const reg: Registration = {
        eventId: event.id,
        instituteId: event.instituteId,
        groupId: spot.group.id,
        tableNumber: spot.group.tableNumber,
        seat: spot.seat,
        level: spot.group.level,
        leaderName: spot.group.leader.name,
        registeredAt: Date.now(),
      };

      setError(null);
      void api
        .reserveSeat(userId, event, reg, participantName)
        .then(setState)
        .then(() => reload())
        .catch(() => setError("Anmeldung fehlgeschlagen. Bitte erneut versuchen."));

      return reg;
    },
    [state.myRegistration, findFirstFreeSeat, event, userId, reload],
  );

  const submitOrder = useCallback(
    (order: string) => {
      void api.submitOrder(userId, event, order).then(setState);
    },
    [userId, event],
  );

  const cancelRegistration = useCallback(() => {
    void api.cancelRsvp(userId, event).then(setState);
  }, [userId, event]);

  return {
    groups,
    myRegistration: state.myRegistration,
    register,
    submitOrder,
    cancelRegistration,
    hydrated,
    error,
  };
}

export function totalStats(event: DeusiEvent, groups: EventGroup[]) {
  if (!event.groups) {
    return {
      participants: 0,
      remaining: event.groupsCount * event.seatsPerGroup,
      total: event.groupsCount * event.seatsPerGroup,
      groups: event.groupsCount,
    };
  }
  const total = groups.reduce((s, g) => s + g.seats, 0);
  const participants = groups.reduce((s, g) => s + g.reservations.length, 0);
  return {
    participants,
    remaining: total - participants,
    total,
    groups: groups.length,
  };
}

export function allEventsForInstitute(instituteId: string) {
  return MOCK_EVENTS.filter((e) => e.instituteId === instituteId);
}
