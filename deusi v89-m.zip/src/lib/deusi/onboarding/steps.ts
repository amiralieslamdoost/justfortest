import type { CefrLevel, GoalKey } from "@/lib/deusi/planner/types";
import type { LearningPreference, OnboardingAnswers } from "./types";

/** Schritt-Kennungen des Onboardings. */
export type StepId =
  | "level"
  | "goals"
  | "exam"
  | "time"
  | "days"
  | "start"
  | "target"
  | "intensity"
  | "skills"
  | "preferences";

/**
 * Titel, persische Übersetzung und — neu — eine ausführliche persische
 * Erklärung. Das Onboarding ist der erste Kontakt mit DEUSI: Lernende, deren
 * Deutsch noch schwach ist, sollen jede Frage vollständig verstehen.
 */
export const STEP_TITLE: Record<
  StepId,
  { de: string; fa: string; hint?: string; hintFa?: string; accent: string }
> = {
  level: {
    de: "Wie gut ist dein Deutsch?",
    fa: "آلمانی‌ات در چه سطحی است؟",
    hint: "Nicht sicher? Wähle „Noch unbekannt“ — DEUSI plant vorsichtig und passt sich an.",
    hintFa:
      "اگر مطمئن نیستی، گزینه‌ی «هنوز نمی‌دانم» را انتخاب کن. DEUSI محتاطانه شروع می‌کند و با پیشرفت تو سطح را تنظیم می‌کند.",
    accent: "#6366f1",
  },
  goals: {
    de: "Warum lernst du Deutsch?",
    fa: "چرا آلمانی یاد می‌گیری؟",
    hint: "Mehrfachauswahl möglich — DEUSI mischt die Schwerpunkte.",
    hintFa:
      "می‌توانی چند هدف را با هم انتخاب کنی؛ برنامه‌ات ترکیبی از آن‌ها می‌شود. هدف تعیین می‌کند روی کدام مهارت‌ها بیشتر کار کنی.",
    accent: "#ec4899",
  },
  exam: {
    de: "Welches Prüfungsziel hast du?",
    fa: "هدف آزمونی‌ات چیست؟",
    hint: "Zielniveau und Termin steuern, wie früh DEUSI Prüfungstraining einplant.",
    hintFa:
      "سطح هدف و تاریخ آزمون مشخص می‌کند از چه زمانی تمرین‌های آزمون در برنامه‌ات قرار بگیرد. هر دو اختیاری هستند.",
    accent: "#f59e0b",
  },
  time: {
    de: "Wie viel Zeit hast du pro Lerntag?",
    fa: "هر روزِ یادگیری چقدر وقت داری؟",
    hint: "Lieber realistisch als ehrgeizig — Regelmäßigkeit schlägt Länge.",
    hintFa:
      "واقع‌بین باش؛ بیست دقیقه‌ی هر روز از دو ساعتِ هفته‌ای یک‌بار مؤثرتر است. هر وقت خواستی می‌توانی این عدد را تغییر بدهی.",
    accent: "#10b981",
  },
  days: {
    de: "An welchen Tagen kannst du lernen?",
    fa: "چه روزهایی می‌توانی یاد بگیری؟",
    hint: "Wähle nur die Tage, an denen du wirklich Zeit hast.",
    hintFa:
      "فقط روزهایی را انتخاب کن که واقعاً وقت داری. هفته در DEUSI از شنبه شروع می‌شود و می‌توانی یک روز استراحت هم داشته باشی.",
    accent: "#0ea5e9",
  },
  start: {
    de: "Zu welcher Uhrzeit lernst du am liebsten?",
    fa: "ترجیح می‌دهی چه ساعتی یاد بگیری؟",
    hint: "DEUSI legt deine Blöcke ab dieser Uhrzeit nacheinander in den Tag.",
    hintFa:
      "بلوک‌های یادگیری‌ات از این ساعت به‌ترتیب چیده می‌شوند؛ بین بلوک‌های طولانی هم استراحت کوتاه در نظر گرفته می‌شود.",
    accent: "#8b5cf6",
  },
  target: {
    de: "Hast du ein bestimmtes Ziel oder Datum?",
    fa: "تاریخ یا هدف مشخصی داری؟",
    hint: "Optional. Ohne Datum plant DEUSI einfach kontinuierlich weiter.",
    hintFa:
      "اختیاری است. اگر تاریخی وارد کنی، هرچه نزدیک‌تر شوی برنامه فشرده‌تر و هدفمندتر می‌شود.",
    accent: "#f43f5e",
  },
  intensity: {
    de: "Wie intensiv soll dein Lernen sein?",
    fa: "شدت یادگیری‌ات چقدر باشد؟",
    hint: "Du kannst die Intensität später jederzeit ändern.",
    hintFa:
      "این گزینه طول و تعداد بلوک‌های روزانه را کم یا زیاد می‌کند. هر زمان می‌توانی آن را عوض کنی.",
    accent: "#14b8a6",
  },
  skills: {
    de: "Wie sicher fühlst du dich in den Fertigkeiten?",
    fa: "در هر مهارت چقدر احساس توانایی می‌کنی؟",
    hint: "Bewerte jede Fertigkeit: schwach, in Ordnung oder stark.",
    hintFa:
      "برای هر مهارت بگو ضعیف هستی، متوسط، یا قوی. مهارت‌های ضعیف زمان بیشتری در برنامه می‌گیرند و مهارت‌های قوی کمتر تکرار می‌شوند. اگر مطمئن نیستی، روی «متوسط» بگذار.",
    accent: "#f97316",
  },
  preferences: {
    de: "Womit lernst du am liebsten?",
    fa: "با چه چیزی بیشتر لذت می‌بری؟",
    hint: "DEUSI empfiehlt dir passende Inhalte aus diesen Bereichen.",
    hintFa:
      "بر اساس این انتخاب‌ها، DEUSI محتوای پیشنهادی‌ات را انتخاب می‌کند؛ مثلاً پادکست، فیلم یا تمرین با مربی هوش مصنوعی.",
    accent: "#a855f7",
  },
};

export const LEVEL_OPTIONS: {
  value: CefrLevel;
  label: string;
  desc: string;
  descFa: string;
}[] = [
  {
    value: "unknown",
    label: "Noch unbekannt",
    desc: "Ich bin mir nicht sicher",
    descFa: "هنوز نمی‌دانم — DEUSI کمکم می‌کند",
  },
  {
    value: "A1",
    label: "A1",
    desc: "Erste Wörter und Sätze",
    descFa: "اولین کلمه‌ها و جمله‌های ساده",
  },
  {
    value: "A2",
    label: "A2",
    desc: "Alltag in einfachen Sätzen",
    descFa: "کارهای روزمره با جمله‌های ساده",
  },
  { value: "B1", label: "B1", desc: "Selbstständig im Alltag", descFa: "مستقل در زندگی روزمره" },
  {
    value: "B2",
    label: "B2",
    desc: "Sicher in Beruf und Studium",
    descFa: "مطمئن در کار و دانشگاه",
  },
  { value: "C1", label: "C1", desc: "Fließend und differenziert", descFa: "روان و دقیق" },
  { value: "C2", label: "C2", desc: "Nahezu muttersprachlich", descFa: "تقریباً در حد زبان مادری" },
];

export const GOAL_OPTIONS: { value: GoalKey; desc: string; descFa: string }[] = [
  {
    value: "general",
    desc: "Solide Grundlagen in allen Fertigkeiten",
    descFa: "پایه‌ی محکم در همه‌ی مهارت‌ها",
  },
  {
    value: "migration",
    desc: "Behörden, Arzt, Nachbarschaft, Alltag",
    descFa: "اداره‌ها، پزشک، همسایه‌ها و زندگی روزمره",
  },
  {
    value: "university",
    desc: "Lesen, Schreiben, akademischer Wortschatz",
    descFa: "خواندن، نوشتن و واژگان دانشگاهی",
  },
  {
    value: "work",
    desc: "Bewerbung, Meetings, Fachsprache",
    descFa: "رزومه، جلسه‌ها و زبان تخصصی",
  },
  {
    value: "goethe",
    desc: "Zielgerichtet auf das Goethe-Zertifikat",
    descFa: "آمادگی هدفمند برای مدرک گوته",
  },
  { value: "testdaf", desc: "Vorbereitung auf TestDaF", descFa: "آمادگی برای آزمون تست‌داف" },
  { value: "conversation", desc: "Frei sprechen und verstehen", descFa: "صحبت آزاد و درک گفتار" },
  { value: "travel", desc: "Unterwegs zurechtkommen", descFa: "برای سفر و موقعیت‌های کوتاه" },
];

export const MINUTE_OPTIONS = [20, 30, 45, 60, 90, 120];

export const MINUTE_HINT_FA: Record<number, string> = {
  20: "کوتاه ولی هر روز",
  30: "متعادل و قابل‌دوام",
  45: "پیشرفت محسوس",
  60: "یک ساعت کامل",
  90: "برای هدف‌های فشرده",
  120: "آماده‌سازی جدی آزمون",
};

export const PREFERENCE_LABEL: Record<LearningPreference, { de: string; fa: string }> = {
  vocabulary: { de: "Wortschatz", fa: "واژگان" },
  grammar: { de: "Grammatik", fa: "گرامر" },
  listening: { de: "Hören", fa: "شنیدن" },
  speaking: { de: "Sprechen", fa: "صحبت کردن" },
  reading: { de: "Lesen", fa: "خواندن" },
  podcasts: { de: "Podcasts", fa: "پادکست" },
  movies: { de: "Filme & Serien", fa: "فیلم و سریال" },
  "ai-coach": { de: "KI-Coach", fa: "مربی هوش مصنوعی" },
};

export const PREFERENCE_ORDER: LearningPreference[] = [
  "vocabulary",
  "grammar",
  "listening",
  "speaking",
  "reading",
  "podcasts",
  "movies",
  "ai-coach",
];

const EXAM_GOALS: GoalKey[] = ["goethe", "testdaf"];

/** Welche Schritte dieser Nutzer sieht — abhängig von seinen Antworten. */
export function stepsFor(answers: OnboardingAnswers): StepId[] {
  const exam = answers.goals.some((g) => EXAM_GOALS.includes(g));
  return [
    "level",
    "goals",
    ...(exam ? (["exam"] as StepId[]) : []),
    "time",
    "days",
    "start",
    ...(exam ? [] : (["target"] as StepId[])),
    "intensity",
    "skills",
    "preferences",
  ];
}

/** Ein Schritt darf übersprungen werden, wenn er nichts Pflichtiges abfragt. */
export function isStepOptional(step: StepId): boolean {
  return step === "target" || step === "exam" || step === "skills" || step === "preferences";
}

export function hasAnswer(step: StepId, a: OnboardingAnswers): boolean {
  switch (step) {
    case "goals":
      return a.goals.length > 0;
    case "days":
      return a.studyDays.length > 0;
    default:
      return true;
  }
}
