import type { ComponentType } from "react";
import {
  Award,
  BookOpen,
  Brain,
  Briefcase,
  Building2,
  CalendarDays,
  CalendarRange,
  Clock,
  Coffee,
  Compass,
  Ear,
  Film,
  Flame,
  GaugeCircle,
  GraduationCap,
  Headphones,
  Heart,
  Languages,
  Leaf,
  Mic,
  Moon,
  MessageCircle,
  Plane,
  PenLine,
  Rocket,
  Sprout,
  Sparkles,
  Spline,
  Sun,
  SunMedium,
  Sunrise,
  Sunset,
  Target,
  Timer,
  TrendingUp,
  Trophy,
  Users,
  Waves,
} from "lucide-react";
import type { CefrLevel, GoalKey, Intensity, SkillKey } from "@/lib/deusi/planner/types";
import type { LearningPreference } from "./types";
import type { StepId } from "./steps";

export type Icon = ComponentType<{ className?: string }>;

/** Icon je Onboarding-Schritt — gibt jeder Frage ein visuelles Thema. */
export const STEP_ICON: Record<StepId, Icon> = {
  level: Languages,
  goals: Target,
  exam: Award,
  time: Clock,
  days: CalendarDays,
  start: Sunrise,
  target: CalendarRange,
  intensity: GaugeCircle,
  skills: Spline,
  preferences: Sparkles,
};

export const LEVEL_ICON: Record<CefrLevel, Icon> = {
  unknown: Compass,
  A1: Sprout,
  A2: Leaf,
  B1: Waves,
  B2: TrendingUp,
  C1: Rocket,
  C2: Trophy,
};

export const GOAL_ICON: Record<GoalKey, Icon> = {
  general: BookOpen,
  migration: Building2,
  university: GraduationCap,
  work: Briefcase,
  goethe: Award,
  testdaf: Trophy,
  conversation: MessageCircle,
  travel: Plane,
  personal: Heart,
  other: Compass,
};

export const INTENSITY_ICON: Record<Intensity, Icon> = {
  light: Coffee,
  steady: Waves,
  intense: Flame,
};

export const SKILL_ICON: Record<SkillKey, Icon> = {
  vocabulary: Brain,
  grammar: Spline,
  listening: Ear,
  speaking: Mic,
  reading: BookOpen,
  writing: PenLine,
};

export const PREFERENCE_ICON: Record<LearningPreference, Icon> = {
  vocabulary: Brain,
  grammar: Spline,
  listening: Headphones,
  speaking: Mic,
  reading: BookOpen,
  podcasts: Headphones,
  movies: Film,
  "ai-coach": Sparkles,
};

/** Tageszeit-Icon für die Startzeit-Presets. */
export function startIcon(time: string): Icon {
  const hour = Number(time.slice(0, 2));
  if (hour < 8) return Sunrise;
  if (hour < 12) return SunMedium;
  if (hour < 15) return Sun;
  if (hour < 19) return Sunset;
  return Moon;
}

/** Icon für die Minuten-Auswahl — je länger, desto „intensiver“. */
export function minuteIcon(minutes: number): Icon {
  if (minutes <= 30) return Timer;
  if (minutes <= 60) return Clock;
  return Flame;
}

export { Users };
