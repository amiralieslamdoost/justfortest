import { useCallback, useEffect, useMemo, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { learnerProfileService, emptyState, profileFromAnswers } from "./service";
import type { LearnerProfile, OnboardingAnswers, OnboardingState } from "./types";

/**
 * Zugriff auf das Lernprofil (Onboarding-Status + Antworten).
 * Kennt keine Persistenz-Details — nur den Service-Vertrag.
 */
export function useLearnerProfile() {
  const { currentUser, hydrated } = useDeusi();
  const userId = currentUser?.id ?? "";
  const [state, setState] = useState<OnboardingState | null>(null);

  useEffect(() => {
    if (!hydrated) return;
    if (!userId) {
      setState(null);
      return;
    }
    let cancelled = false;
    void learnerProfileService.load(userId).then((loaded) => {
      if (!cancelled) setState(loaded);
    });
    return () => {
      cancelled = true;
    };
  }, [hydrated, userId]);

  const persist = useCallback(
    async (next: OnboardingState) => {
      setState(next);
      if (userId) await learnerProfileService.save(userId, next);
      return next;
    },
    [userId],
  );

  /** Zwischenstand sichern, damit ein Abbruch nicht von vorn beginnt. */
  const saveDraft = useCallback(
    (answers: Partial<OnboardingAnswers>, stepId?: string | null) => {
      const base = state ?? emptyState();
      return persist({
        ...base,
        status: base.status === "completed" ? "completed" : "draft",
        answers: { ...base.answers, ...answers },
        stepId: stepId ?? base.stepId,
        updatedAt: new Date().toISOString(),
      });
    },
    [persist, state],
  );

  const complete = useCallback(
    (answers: OnboardingAnswers) => {
      const base = state ?? emptyState();
      const profile: LearnerProfile = profileFromAnswers(answers);
      return persist({
        ...base,
        status: "completed",
        answers,
        stepId: null,
        profile,
        updatedAt: new Date().toISOString(),
      }).then(() => profile);
    },
    [persist, state],
  );

  const skip = useCallback(() => {
    const base = state ?? emptyState();
    return persist({ ...base, status: "skipped", updatedAt: new Date().toISOString() });
  }, [persist, state]);

  const reset = useCallback(() => persist(emptyState()), [persist]);

  const loading = !hydrated || (!!userId && state === null);

  return useMemo(
    () => ({
      loading,
      state,
      status: state?.status ?? "pending",
      answers: state?.answers ?? emptyState().answers,
      profile: state?.profile ?? null,
      hasProfile: state?.status === "completed" && !!state.profile,
      saveDraft,
      complete,
      skip,
      reset,
    }),
    [complete, loading, reset, saveDraft, skip, state],
  );
}
