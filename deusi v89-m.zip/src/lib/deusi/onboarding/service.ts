import type {
  LearnerProfile,
  OnboardingAnswers,
  OnboardingState,
  LearnerProfileService,
} from "./types";

/**
 * Lokale Implementierung des LearnerProfileService.
 *
 * Frontend-only: der Zustand liegt im localStorage, pro Nutzer getrennt.
 * Die UI spricht ausschließlich über das Interface — ein späterer Backend-
 * Adapter ersetzt nur diese Datei, nicht die Oberfläche.
 */

const KEY = (userId: string) => `deusi.onboarding.${userId}`;

export const EMPTY_ANSWERS: OnboardingAnswers = {
  level: "unknown",
  goals: [],
  targetLevel: null,
  dailyMinutes: 45,
  studyDays: [6, 0, 1, 2, 3, 4],
  restDays: "auto",
  preferredStartTime: "19:00",
  targetDate: null,
  intensity: "steady",
  weakSkills: [],
  strongSkills: [],
  preferences: [],
};

export function emptyState(): OnboardingState {
  return {
    version: 1,
    status: "pending",
    answers: { ...EMPTY_ANSWERS },
    stepId: null,
    profile: null,
    updatedAt: new Date().toISOString(),
  };
}

export function profileFromAnswers(answers: OnboardingAnswers): LearnerProfile {
  return {
    version: 1,
    ...answers,
    goals: answers.goals.length ? answers.goals : ["general"],
    completedAt: new Date().toISOString(),
  };
}

function parse(raw: string | null): OnboardingState {
  if (!raw) return emptyState();
  try {
    const parsed = JSON.parse(raw) as Partial<OnboardingState>;
    const base = emptyState();
    return {
      ...base,
      ...parsed,
      version: 1,
      answers: { ...base.answers, ...(parsed.answers ?? {}) },
      profile: parsed.profile ?? null,
    };
  } catch {
    return emptyState();
  }
}

export const localLearnerProfileService: LearnerProfileService = {
  async load(userId) {
    if (typeof window === "undefined" || !userId) return emptyState();
    return parse(localStorage.getItem(KEY(userId)));
  },
  async save(userId, state) {
    if (typeof window === "undefined" || !userId) return;
    try {
      localStorage.setItem(KEY(userId), JSON.stringify(state));
    } catch (err) {
      console.warn("[onboarding] localStorage write failed", err);
    }
  },
  async clear(userId) {
    if (typeof window === "undefined" || !userId) return;
    localStorage.removeItem(KEY(userId));
  },
};

/** Aktive Implementierung — später gegen den Backend-Adapter tauschbar. */
export const learnerProfileService: LearnerProfileService = localLearnerProfileService;
