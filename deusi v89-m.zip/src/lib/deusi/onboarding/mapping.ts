import type { PlannerPrefs } from "@/lib/deusi/planner/types";
import type { LearnerProfile, OnboardingAnswers } from "./types";

/**
 * Die EINZIGE Stelle, an der Onboarding-Antworten auf die Konfiguration des
 * bestehenden Smart Planners abgebildet werden.
 *
 * onboarding profile → planner prefs → bestehende Engine → bestehende Planer-UI
 */
export function plannerPrefsFromProfile(
  profile: LearnerProfile | OnboardingAnswers,
): Partial<PlannerPrefs> {
  return {
    level: profile.level,
    goals: profile.goals.length ? profile.goals : ["general"],
    dailyMinutes: profile.dailyMinutes,
    availableDays: profile.studyDays.length ? profile.studyDays : [6, 0, 1, 2, 3],
    startHour: profile.preferredStartTime,
    targetDate: profile.targetDate ?? null,
    intensity: profile.intensity,
    weakSkills: profile.weakSkills,
    strongSkills: profile.strongSkills,
    restDays: profile.restDays,
  };
}

/** Rückweg: bestehende Planer-Werte als Startpunkt fürs Onboarding. */
export function answersFromPlannerPrefs(prefs: PlannerPrefs): Partial<OnboardingAnswers> {
  return {
    level: prefs.level,
    goals: prefs.goals,
    dailyMinutes: prefs.dailyMinutes,
    studyDays: prefs.availableDays,
    preferredStartTime: prefs.startHour,
    targetDate: prefs.targetDate,
    intensity: prefs.intensity,
    weakSkills: prefs.weakSkills,
    strongSkills: prefs.strongSkills,
    restDays: prefs.restDays,
  };
}
