// ============ Wortfamilien (word roots & families) ============
// Self-contained model for the /verben section, which now teaches word roots
// and word families instead of verb conjugation (that lives in the dictionary).

export type WfPos = "verb" | "noun" | "adjective" | "adverb";
export type WfLevel = "A1" | "A2" | "B1" | "B2" | "C1";

/** One member of a word family, split into its morphemes. */
export interface FamilyMember {
  id: string;
  /** Full display word, e.g. "Beschreibung" */
  word: string;
  pos: WfPos;
  /** Prefix morpheme, e.g. "be" */
  prefix?: string;
  /** Shared root morpheme, e.g. "schreib" */
  root: string;
  /** Suffix / ending morpheme, e.g. "ung" */
  suffix?: string;
  /** Article for nouns */
  article?: "der" | "die" | "das";
  /** Whether the prefix is separable (trennbar) */
  separable?: boolean;
  meaningDe: string;
  meaningFa: string;
  example: string;
  cefr: WfLevel;
  /** Root id this member also opens as its own family, if any */
  familyId?: string;
}

export interface WordRoot {
  id: string;
  /** The bare root morpheme, e.g. "schreib" */
  root: string;
  /** Human label shown in lists, e.g. "schreiben" */
  label: string;
  meaningDe: string;
  meaningFa: string;
  cefr: WfLevel;
  /** Short didactic note about the root */
  noteDe: string;
  noteFa: string;
  members: FamilyMember[];
}

export interface PrefixInfo {
  prefix: string;
  separable: boolean;
  meaningDe: string;
  meaningFa: string;
  example: string;
  exampleMeaningFa: string;
}

export const POS_COLOR: Record<WfPos, string> = {
  verb: "#22d3ee",
  noun: "#a78bfa",
  adjective: "#fbbf24",
  adverb: "#4ade80",
};

export const POS_LABEL: Record<WfPos, { de: string; fa: string; short: string }> = {
  verb: { de: "Verb", fa: "فعل", short: "V" },
  noun: { de: "Nomen", fa: "اسم", short: "N" },
  adjective: { de: "Adjektiv", fa: "صفت", short: "Adj" },
  adverb: { de: "Adverb", fa: "قید", short: "Adv" },
};
