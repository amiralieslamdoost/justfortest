/**
 * Shared achievements data — used by the dashboard `AchievementsCard`
 * and the dedicated `/achievements` page.
 */

export type AchievementCategory =
  "Serie" | "Wortschatz" | "Grammatik" | "Hören" | "Lesen" | "Prüfung" | "Meilenstein";

export interface Achievement {
  id: string;
  emoji: string;
  labelDe: string;
  labelFa: string;
  sub: string;
  subFa?: string;
  color: string;
  category: AchievementCategory;
  unlocked: boolean;
  /** ISO date (YYYY-MM-DD) when it was unlocked. */
  unlockedAt?: string;
  /** For locked achievements — current progress towards target. */
  progress?: { current: number; target: number };
}

export const ACHIEVEMENTS: Achievement[] = [
  // Serie
  {
    id: "streak-14",
    emoji: "🔥",
    labelDe: "14-Tage-Serie",
    labelFa: "سری ۱۴ روزه",
    sub: "Konstantes Lernen",
    subFa: "یادگیری مداوم",
    color: "#F97316",
    category: "Serie",
    unlocked: true,
    unlockedAt: "2026-07-14",
  },
  {
    id: "streak-30",
    emoji: "⚡",
    labelDe: "30-Tage-Serie",
    labelFa: "سری ۳۰ روزه",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#F59E0B",
    category: "Serie",
    unlocked: false,
    progress: { current: 14, target: 30 },
  },
  {
    id: "streak-100",
    emoji: "🌟",
    labelDe: "100-Tage-Serie",
    labelFa: "سری ۱۰۰ روزه",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#EAB308",
    category: "Serie",
    unlocked: false,
    progress: { current: 14, target: 100 },
  },

  // Wortschatz
  {
    id: "words-100",
    emoji: "📚",
    labelDe: "100 Wörter",
    labelFa: "۱۰۰ واژه",
    sub: "Wortschatz-Meister",
    subFa: "استاد واژگان",
    color: "#8B5CF6",
    category: "Wortschatz",
    unlocked: true,
    unlockedAt: "2026-06-28",
  },
  {
    id: "words-500",
    emoji: "📖",
    labelDe: "500 Wörter",
    labelFa: "۵۰۰ واژه",
    sub: "Wortschatz-Profi",
    subFa: "حرفه‌ای واژگان",
    color: "#7C3AED",
    category: "Wortschatz",
    unlocked: true,
    unlockedAt: "2026-07-20",
  },
  {
    id: "words-1000",
    emoji: "🧠",
    labelDe: "1000 Wörter",
    labelFa: "۱۰۰۰ واژه",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#6D28D9",
    category: "Wortschatz",
    unlocked: false,
    progress: { current: 612, target: 1000 },
  },

  // Grammatik
  {
    id: "grammar-pro",
    emoji: "✍️",
    labelDe: "Grammatik-Profi",
    labelFa: "استاد گرامر",
    sub: "10 Lektionen",
    subFa: "۱۰ درس",
    color: "#22C55E",
    category: "Grammatik",
    unlocked: true,
    unlockedAt: "2026-07-05",
  },
  {
    id: "grammar-cases",
    emoji: "🎯",
    labelDe: "Alle 4 Fälle",
    labelFa: "چهار حالت اسم",
    sub: "Nom · Akk · Dat · Gen",
    subFa: "کامل",
    color: "#16A34A",
    category: "Grammatik",
    unlocked: true,
    unlockedAt: "2026-07-22",
  },
  {
    id: "grammar-master",
    emoji: "🧩",
    labelDe: "Grammatik-Meister",
    labelFa: "استاد کامل گرامر",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#15803D",
    category: "Grammatik",
    unlocked: false,
    progress: { current: 10, target: 25 },
  },

  // Hören
  {
    id: "listen-5",
    emoji: "🎧",
    labelDe: "Hör-Champion",
    labelFa: "قهرمان شنیدن",
    sub: "5 Podcasts",
    subFa: "۵ پادکست",
    color: "#EC4899",
    category: "Hören",
    unlocked: true,
    unlockedAt: "2026-07-18",
  },
  {
    id: "listen-song",
    emoji: "🎵",
    labelDe: "Karaoke-Star",
    labelFa: "ستاره کارائوکه",
    sub: "10 Lieder mitgesungen",
    subFa: "۱۰ آهنگ",
    color: "#DB2777",
    category: "Hören",
    unlocked: true,
    unlockedAt: "2026-07-25",
  },
  {
    id: "listen-25",
    emoji: "🎙️",
    labelDe: "25 Podcasts",
    labelFa: "۲۵ پادکست",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#BE185D",
    category: "Hören",
    unlocked: false,
    progress: { current: 8, target: 25 },
  },

  // Lesen
  {
    id: "read-first",
    emoji: "📰",
    labelDe: "Erster Artikel",
    labelFa: "اولین مقاله",
    sub: "Gelesen & verstanden",
    subFa: "مطالعه شد",
    color: "#0EA5E9",
    category: "Lesen",
    unlocked: true,
    unlockedAt: "2026-06-15",
  },
  {
    id: "read-book",
    emoji: "📕",
    labelDe: "Erstes Buch",
    labelFa: "اولین کتاب",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#0284C7",
    category: "Lesen",
    unlocked: false,
    progress: { current: 3, target: 12 },
  },

  // Prüfung
  {
    id: "exam-a2",
    emoji: "🎓",
    labelDe: "A2 bestanden",
    labelFa: "قبولی A2",
    sub: "Zertifikat erhalten",
    subFa: "مدرک دریافت شد",
    color: "#14B8A6",
    category: "Prüfung",
    unlocked: true,
    unlockedAt: "2026-05-30",
  },
  {
    id: "exam-b1",
    emoji: "🏆",
    labelDe: "B1-Meister",
    labelFa: "استاد B1",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#0D9488",
    category: "Prüfung",
    unlocked: false,
    progress: { current: 68, target: 100 },
  },

  // Meilenstein
  {
    id: "xp-1000",
    emoji: "💎",
    labelDe: "1000 XP",
    labelFa: "۱۰۰۰ امتیاز",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#0EA5E9",
    category: "Meilenstein",
    unlocked: false,
    progress: { current: 720, target: 1000 },
  },
  {
    id: "xp-5000",
    emoji: "👑",
    labelDe: "5000 XP",
    labelFa: "۵۰۰۰ امتیاز",
    sub: "gesperrt",
    subFa: "قفل",
    color: "#6366F1",
    category: "Meilenstein",
    unlocked: false,
    progress: { current: 720, target: 5000 },
  },
];

export const ACHIEVEMENT_CATEGORIES: AchievementCategory[] = [
  "Serie",
  "Wortschatz",
  "Grammatik",
  "Hören",
  "Lesen",
  "Prüfung",
  "Meilenstein",
];

export const unlockedCount = ACHIEVEMENTS.filter((a) => a.unlocked).length;
export const totalCount = ACHIEVEMENTS.length;
export const progressPct = Math.round((unlockedCount / totalCount) * 100);

export const latestUnlocked: Achievement | undefined = [...ACHIEVEMENTS]
  .filter((a) => a.unlocked && a.unlockedAt)
  .sort((a, b) => (a.unlockedAt! < b.unlockedAt! ? 1 : -1))[0];
