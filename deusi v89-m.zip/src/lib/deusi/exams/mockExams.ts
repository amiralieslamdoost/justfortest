export type ExamId = "testdaf" | "telc" | "oesd" | "goethe" | "dsh";

export interface ExamResource {
  id: string;
  title: string;
  description: string;
  type: "PDF" | "Buch" | "Video" | "Audio" | "Webseite" | "Wortschatz" | "Grammatik";
  category: "Bücher" | "PDFs" | "Wortschatz" | "Grammatik" | "Videos" | "Webseiten" | "Audio";
  level: string;
  uploadDate: string;
  size?: string;
  url?: string;
}

export interface PracticeFile {
  id: string;
  title: string;
  skill: "Modelltest" | "Schreiben" | "Lesen" | "Hören" | "Sprechen";
  fileType: "PDF" | "MP3" | "ZIP" | "MP4";
  size: string;
  uploadDate: string;
}

export interface Experience {
  id: string;
  username: string;
  level: string;
  examDate: string;
  difficulty: 1 | 2 | 3 | 4 | 5;
  writingTips: string;
  speakingTips: string;
  readingTips: string;
  listeningTips: string;
  notes: string;
  helpful: number;
  createdAt: string;
}

export interface ExamCenter {
  id: string;
  name: string;
  city: string;
  address: string;
  website: string;
  phone: string;
  examTypes: string[];
  upcomingSessions: { date: string; level: string; seatsLeft: number }[];
  badge?: "Offiziell" | "Partner";
}

export interface FAQItem {
  q: string;
  a: string;
}

export interface ExamBook {
  id: string;
  title: string;
  publisher: string;
  level: string;
  skill: "Komplett" | "Schreiben" | "Lesen" | "Hören" | "Sprechen" | "Wortschatz" | "Grammatik";
  pages: number;
  year: number;
  rating: number;
  size: string;
  cover: string; // css gradient
  description: string;
}

export interface ExamComparison {
  duration: string;
  cost: string;
  results: string;
  validity: string;
  format: string;
  bestFor: string;
}

export type ExamPurpose = "Studium" | "Beruf" | "Aufenthalt";

export interface PrepWeek {
  week: string;
  focus: string;
  tasks: string[];
}

export interface Exam {
  id: ExamId;
  name: string;
  shortName: string;
  tagline: string;
  description: string;
  longDescription: string;
  levels: string[];
  recommendedLevel: string;
  officialWebsite: string;
  accent: string; // css color
  gradient: string;
  logo: LogoKind;
  resources: ExamResource[];
  practice: PracticeFile[];
  experiences: Experience[];
  centers: ExamCenter[];
  faq: FAQItem[];
  highlights: { icon: string; title: string; text: string }[];
  structure: { skill: string; minutes: number; weight: number }[];
  books: ExamBook[];
  comparison: ExamComparison;
  prepPlan: PrepWeek[];
  purpose: ExamPurpose[];
}

export type LogoKind = "testdaf" | "telc" | "oesd" | "goethe" | "dsh";

const commonFaq: FAQItem[] = [
  {
    q: "Wie melde ich mich zur Prüfung an?",
    a: "Die Anmeldung erfolgt direkt über ein autorisiertes Prüfungszentrum. Wähle ein Institut aus der Liste und folge dem angegebenen Link oder rufe an.",
  },
  {
    q: "Welches Niveau sollte ich wählen?",
    a: "Nutze unseren Einstufungstest im DEUSI Dashboard. Für ein Studium in Deutschland wird meist B2 oder C1 empfohlen.",
  },
  {
    q: "Wie lange ist das Zertifikat gültig?",
    a: "Die meisten deutschen Sprachzertifikate sind unbegrenzt gültig. Universitäten akzeptieren sie jedoch oft nur, wenn sie nicht älter als 2 Jahre sind.",
  },
  {
    q: "Welche Punktzahl wird zum Bestehen benötigt?",
    a: "In der Regel musst du in jedem der vier Prüfungsteile mindestens 60% erreichen. Details findest du in der jeweiligen Prüfungsordnung.",
  },
  {
    q: "Wie kann ich mich am besten vorbereiten?",
    a: "Kombiniere DEUSI-Flashcards, Modelltests, das Grammatikmodul und einen wöchentlichen Sprech-Event. Plane 8–12 Wochen intensive Vorbereitung ein.",
  },
];

function makeResources(prefix: string): ExamResource[] {
  return [
    {
      id: `${prefix}-r1`,
      title: "Offizieller Wortschatz B2",
      description: "Ca. 2.400 prüfungsrelevante Wörter mit Beispielsätzen.",
      type: "Wortschatz",
      category: "Wortschatz",
      level: "B2",
      uploadDate: "2025-11-04",
      size: "1.8 MB",
    },
    {
      id: `${prefix}-r2`,
      title: "Grammatik-Kompendium",
      description: "Alle wichtigen Strukturen kompakt erklärt.",
      type: "Grammatik",
      category: "Grammatik",
      level: "B1–C1",
      uploadDate: "2025-10-22",
      size: "3.2 MB",
    },
    {
      id: `${prefix}-r3`,
      title: "Prüfungshandbuch",
      description: "Aufbau, Bewertungsraster und Beispielaufgaben.",
      type: "PDF",
      category: "PDFs",
      level: "Alle",
      uploadDate: "2025-09-14",
      size: "4.5 MB",
    },
    {
      id: `${prefix}-r4`,
      title: "Hörverstehen Trainer",
      description: "12 Audio-Übungen mit Transkripten.",
      type: "Audio",
      category: "Audio",
      level: "B2",
      uploadDate: "2025-08-30",
      size: "42 MB",
    },
    {
      id: `${prefix}-r5`,
      title: "Video-Tutorial Sprechen",
      description: "Strategien für den mündlichen Prüfungsteil.",
      type: "Video",
      category: "Videos",
      level: "B2–C1",
      uploadDate: "2025-11-11",
      size: "180 MB",
    },
    {
      id: `${prefix}-r6`,
      title: "Übungsbuch Schreiben",
      description: "20 Musteraufsätze mit Korrekturen.",
      type: "Buch",
      category: "Bücher",
      level: "B2",
      uploadDate: "2025-07-19",
      size: "6.1 MB",
    },
    {
      id: `${prefix}-r7`,
      title: "Offizielle Website Portal",
      description: "Aktuelle Termine und Anmeldung online.",
      type: "Webseite",
      category: "Webseiten",
      level: "Alle",
      uploadDate: "2025-12-01",
    },
  ];
}

function makePractice(prefix: string): PracticeFile[] {
  return [
    {
      id: `${prefix}-p1`,
      title: "Modelltest 1 – Komplett",
      skill: "Modelltest",
      fileType: "PDF",
      size: "4.2 MB",
      uploadDate: "2025-11-20",
    },
    {
      id: `${prefix}-p2`,
      title: "Modelltest 2 – Komplett",
      skill: "Modelltest",
      fileType: "PDF",
      size: "4.1 MB",
      uploadDate: "2025-10-15",
    },
    {
      id: `${prefix}-p3`,
      title: "Schreiben – 10 Aufgaben",
      skill: "Schreiben",
      fileType: "PDF",
      size: "1.6 MB",
      uploadDate: "2025-09-27",
    },
    {
      id: `${prefix}-p4`,
      title: "Lesen – Übungssatz A",
      skill: "Lesen",
      fileType: "PDF",
      size: "2.3 MB",
      uploadDate: "2025-08-11",
    },
    {
      id: `${prefix}-p5`,
      title: "Hören – Audio-Set 1",
      skill: "Hören",
      fileType: "MP3",
      size: "38 MB",
      uploadDate: "2025-07-05",
    },
    {
      id: `${prefix}-p6`,
      title: "Sprechen – Themenkatalog",
      skill: "Sprechen",
      fileType: "PDF",
      size: "0.9 MB",
      uploadDate: "2025-06-18",
    },
  ];
}

function makeExperiences(exam: string): Experience[] {
  return [
    {
      id: `${exam}-e1`,
      username: "Sarah M.",
      level: "B2",
      examDate: "2025-11-08",
      difficulty: 4,
      writingTips: "Strukturiere den Aufsatz klar: Einleitung, 2 Argumente, Fazit.",
      speakingTips: "Übe Redemittel für Meinungsäußerung auswendig.",
      readingTips: "Skim-Technik spart im Leseteil viel Zeit.",
      listeningTips: "Notizen in Stichworten machen, nicht in ganzen Sätzen.",
      notes: "Insgesamt fair, aber der Zeitdruck war real.",
      helpful: 42,
      createdAt: "2025-11-12",
    },
    {
      id: `${exam}-e2`,
      username: "Ali R.",
      level: "C1",
      examDate: "2025-10-19",
      difficulty: 5,
      writingTips: "Nutze komplexe Konnektoren – das gibt Punkte.",
      speakingTips: "Ruhig bleiben, langsamer sprechen als du denkst.",
      readingTips: "Achte auf Synonyme in den Fragen.",
      listeningTips: "Der zweite Höreingriff ist immer schneller.",
      notes: "Sehr anspruchsvoll, aber machbar mit guter Vorbereitung.",
      helpful: 78,
      createdAt: "2025-10-25",
    },
    {
      id: `${exam}-e3`,
      username: "Mina K.",
      level: "B1",
      examDate: "2025-09-14",
      difficulty: 3,
      writingTips: "Einfache, aber korrekte Sätze sind besser als komplizierte Fehler.",
      speakingTips: "Kartensystem im Dialogteil vorher üben.",
      readingTips: "Überschriften zuerst lesen.",
      listeningTips: "Zahlen und Namen immer sofort notieren.",
      notes: "Angenehme Atmosphäre im Prüfungszentrum.",
      helpful: 31,
      createdAt: "2025-09-20",
    },
    {
      id: `${exam}-e4`,
      username: "Reza A.",
      level: "B2",
      examDate: "2025-08-22",
      difficulty: 4,
      writingTips: "Zeitmanagement: max. 15 Min. für den ersten Aufsatzteil.",
      speakingTips: "Redemittel-Liste von DEUSI hat sehr geholfen.",
      readingTips: "Genau lesen: ein Wort kann die Antwort ändern.",
      listeningTips: "Vor dem Hören die Fragen markieren.",
      notes: "Ich habe mit den DEUSI-Modelltests bestanden – super!",
      helpful: 55,
      createdAt: "2025-08-28",
    },
  ];
}

function makeCenters(exam: string): ExamCenter[] {
  return [
    {
      id: `${exam}-c1`,
      name: "Goethe-Institut Iran",
      city: "Tehran, Isfahan, Shiraz",
      address: "Farmanieh, Tehran",
      website: "https://www.goethe.de/ir",
      phone: "+98 21 22293119",
      examTypes: ["A1", "A2", "B1", "B2", "C1", "C2"],
      upcomingSessions: [
        { date: "2026-02-14", level: "B2", seatsLeft: 8 },
        { date: "2026-03-21", level: "C1", seatsLeft: 3 },
      ],
      badge: "Offiziell",
    },
    {
      id: `${exam}-c2`,
      name: "ÖSD Prüfungszentrum Tehran",
      city: "Tehran",
      address: "Vanak, Tehran",
      website: "https://www.osd.at",
      phone: "+98 21 88770011",
      examTypes: ["A2", "B1", "B2", "C1"],
      upcomingSessions: [{ date: "2026-02-28", level: "B1", seatsLeft: 12 }],
      badge: "Offiziell",
    },
    {
      id: `${exam}-c3`,
      name: "Farhangsara Sprachinstitut",
      city: "Tehran, Tabriz",
      address: "Yousef Abad, Tehran",
      website: "https://farhangsara.ir",
      phone: "+98 21 88998877",
      examTypes: ["telc", "TestDaF"],
      upcomingSessions: [{ date: "2026-04-10", level: "B2", seatsLeft: 20 }],
      badge: "Partner",
    },
    {
      id: `${exam}-c4`,
      name: "Safir Language Academy",
      city: "Tehran, Mashhad",
      address: "Mirdamad, Tehran",
      website: "https://safirlanguage.com",
      phone: "+98 21 22884455",
      examTypes: ["telc", "ÖSD"],
      upcomingSessions: [{ date: "2026-05-02", level: "A2", seatsLeft: 15 }],
      badge: "Partner",
    },
    {
      id: `${exam}-c5`,
      name: "Iran-Deutsches Sprachzentrum",
      city: "Isfahan",
      address: "Chaharbagh, Isfahan",
      website: "https://ids.ir",
      phone: "+98 31 32234455",
      examTypes: ["Goethe", "telc"],
      upcomingSessions: [{ date: "2026-03-15", level: "B1", seatsLeft: 10 }],
    },
  ];
}

type BaseExam = Omit<Exam, "books" | "comparison" | "prepPlan" | "purpose">;

const BASE_EXAMS: BaseExam[] = [
  {
    id: "testdaf",
    name: "TestDaF",
    shortName: "TestDaF",
    tagline: "Test Deutsch als Fremdsprache",
    description: "Wissenschaftsorientierte Sprachprüfung für ein Studium in Deutschland.",
    longDescription:
      "Der TestDaF ist eine zentrale, standardisierte Prüfung für alle, die in Deutschland studieren möchten. Er wird weltweit an über 450 Testzentren angeboten und von allen deutschen Hochschulen anerkannt.",
    levels: ["B2", "C1"],
    recommendedLevel: "B2–C1",
    officialWebsite: "https://www.testdaf.de",
    accent: "#2563eb",
    gradient: "linear-gradient(135deg,#dbeafe,#eff6ff)",
    logo: "testdaf",
    resources: makeResources("testdaf"),
    practice: makePractice("testdaf"),
    experiences: makeExperiences("testdaf"),
    centers: makeCenters("testdaf"),
    faq: commonFaq,
    highlights: [
      { icon: "🎓", title: "Für das Studium", text: "Anerkannt an allen deutschen Hochschulen." },
      { icon: "🌍", title: "Weltweit", text: "Über 450 Testzentren in 90+ Ländern." },
      { icon: "📚", title: "4 Teilprüfungen", text: "Lesen, Hören, Schreiben, Sprechen." },
      { icon: "🧠", title: "Wissenschaftlich", text: "Themen aus dem akademischen Kontext." },
    ],
    structure: [
      { skill: "Lesen", minutes: 60, weight: 25 },
      { skill: "Hören", minutes: 40, weight: 25 },
      { skill: "Schreiben", minutes: 60, weight: 25 },
      { skill: "Sprechen", minutes: 35, weight: 25 },
    ],
  },
  {
    id: "telc",
    name: "telc Deutsch",
    shortName: "telc",
    tagline: "The European Language Certificates",
    description: "Standardisierte, flexible Sprachprüfungen von A1 bis C2.",
    longDescription:
      "telc bietet praxisnahe Prüfungen für alle GER-Niveaus. Die Zertifikate sind europaweit anerkannt und ideal für Beruf, Studium oder Einbürgerung.",
    levels: ["A1", "A2", "B1", "B2", "C1", "C2"],
    recommendedLevel: "B1–B2",
    officialWebsite: "https://www.telc.net",
    accent: "#0ea5e9",
    gradient: "linear-gradient(135deg,#e0f2fe,#f0f9ff)",
    logo: "telc",
    resources: makeResources("telc"),
    practice: makePractice("telc"),
    experiences: makeExperiences("telc"),
    centers: makeCenters("telc"),
    faq: commonFaq,
    highlights: [
      { icon: "🇪🇺", title: "Europaweit", text: "Anerkannt in Deutschland und der EU." },
      { icon: "⚡", title: "Schnelle Ergebnisse", text: "Zertifikat in 4–6 Wochen." },
      { icon: "🎯", title: "Flexibel", text: "Alle Niveaus von A1 bis C2." },
      { icon: "💼", title: "Beruf & Studium", text: "Auch Fachsprache Medizin verfügbar." },
    ],
    structure: [
      { skill: "Lesen", minutes: 90, weight: 25 },
      { skill: "Hören", minutes: 30, weight: 25 },
      { skill: "Schreiben", minutes: 30, weight: 25 },
      { skill: "Sprechen", minutes: 15, weight: 25 },
    ],
  },
  {
    id: "oesd",
    name: "ÖSD",
    shortName: "ÖSD",
    tagline: "Österreichisches Sprachdiplom Deutsch",
    description: "International anerkanntes Sprachzertifikat aus Österreich.",
    longDescription:
      "Das ÖSD ist ein staatlich anerkanntes Prüfungssystem für Deutsch als Fremd- und Zweitsprache. Es wird weltweit für Studium, Beruf und Einbürgerung anerkannt.",
    levels: ["A1", "A2", "B1", "B2", "C1", "C2"],
    recommendedLevel: "B1–C1",
    officialWebsite: "https://www.osd.at",
    accent: "#dc2626",
    gradient: "linear-gradient(135deg,#fee2e2,#fef2f2)",
    logo: "oesd",
    resources: makeResources("oesd"),
    practice: makePractice("oesd"),
    experiences: makeExperiences("oesd"),
    centers: makeCenters("oesd"),
    faq: commonFaq,
    highlights: [
      { icon: "🇦🇹", title: "Anerkannt", text: "In Österreich, Deutschland und weltweit." },
      { icon: "📝", title: "Digital & Papier", text: "Flexible Prüfungsformate." },
      { icon: "🏛️", title: "Alle Zwecke", text: "Studium, Beruf, Einbürgerung." },
      { icon: "📅", title: "Flexible Termine", text: "Mehrere Prüfungstermine im Jahr." },
    ],
    structure: [
      { skill: "Lesen", minutes: 60, weight: 25 },
      { skill: "Hören", minutes: 40, weight: 25 },
      { skill: "Schreiben", minutes: 60, weight: 25 },
      { skill: "Sprechen", minutes: 15, weight: 25 },
    ],
  },
  {
    id: "goethe",
    name: "Goethe-Zertifikat",
    shortName: "Goethe",
    tagline: "Prüfung des Goethe-Instituts",
    description: "Das weltweit bekannteste Deutsch-Zertifikat für alle GER-Niveaus.",
    longDescription:
      "Die Goethe-Zertifikate sind offizielle Prüfungen des Goethe-Instituts und werden international von Arbeitgebern, Universitäten und Behörden anerkannt.",
    levels: ["A1", "A2", "B1", "B2", "C1", "C2"],
    recommendedLevel: "B1–C1",
    officialWebsite: "https://www.goethe.de",
    accent: "#059669",
    gradient: "linear-gradient(135deg,#d1fae5,#ecfdf5)",
    logo: "goethe",
    resources: makeResources("goethe"),
    practice: makePractice("goethe"),
    experiences: makeExperiences("goethe"),
    centers: makeCenters("goethe"),
    faq: commonFaq,
    highlights: [
      { icon: "🌐", title: "Weltweit anerkannt", text: "In über 90 Ländern." },
      { icon: "🏆", title: "Reputation", text: "Der Klassiker unter den Deutschprüfungen." },
      { icon: "🎓", title: "Alle Niveaus", text: "Von A1 bis C2." },
      {
        icon: "👶",
        title: "Auch für Jugendliche",
        text: "Spezielle Jugendprüfungen A1 Fit, A2 Fit.",
      },
    ],
    structure: [
      { skill: "Lesen", minutes: 65, weight: 25 },
      { skill: "Hören", minutes: 40, weight: 25 },
      { skill: "Schreiben", minutes: 75, weight: 25 },
      { skill: "Sprechen", minutes: 15, weight: 25 },
    ],
  },
  {
    id: "dsh",
    name: "DSH",
    shortName: "DSH",
    tagline: "Deutsche Sprachprüfung für den Hochschulzugang",
    description: "Universitätsinterne Prüfung als Zulassungsvoraussetzung für ein Studium.",
    longDescription:
      "Die DSH wird direkt von deutschen Universitäten angeboten und dient dem Nachweis ausreichender Deutschkenntnisse für ein Studium. Bewertungen: DSH-1, DSH-2, DSH-3.",
    levels: ["B2", "C1", "C2"],
    recommendedLevel: "C1",
    officialWebsite: "https://www.fadaf.de/de/dsh/",
    accent: "#7c3aed",
    gradient: "linear-gradient(135deg,#ede9fe,#f5f3ff)",
    logo: "dsh",
    resources: makeResources("dsh"),
    practice: makePractice("dsh"),
    experiences: makeExperiences("dsh"),
    centers: makeCenters("dsh"),
    faq: commonFaq,
    highlights: [
      { icon: "🏫", title: "Uni-Zugang", text: "Direkter Nachweis für das Studium." },
      { icon: "📖", title: "Wissenschaftlich", text: "Fokus auf akademische Textsorten." },
      { icon: "⭐", title: "3 Stufen", text: "DSH-1, DSH-2, DSH-3." },
      { icon: "🎯", title: "Zielgerichtet", text: "Ideal nach dem Studienkolleg." },
    ],
    structure: [
      { skill: "Leseverstehen", minutes: 90, weight: 20 },
      { skill: "Hörverstehen", minutes: 60, weight: 20 },
      { skill: "Textproduktion", minutes: 70, weight: 30 },
      { skill: "Mündlich", minutes: 20, weight: 30 },
    ],
  },
];

const BOOK_COVERS = [
  "linear-gradient(140deg,#1e3a8a,#3b82f6)",
  "linear-gradient(140deg,#7c2d12,#f97316)",
  "linear-gradient(140deg,#134e4a,#14b8a6)",
  "linear-gradient(140deg,#4c1d95,#a855f7)",
  "linear-gradient(140deg,#7f1d1d,#ef4444)",
  "linear-gradient(140deg,#0f172a,#475569)",
];

function makeBooks(exam: BaseExam): ExamBook[] {
  const n = exam.shortName;
  const rows: Omit<ExamBook, "id" | "cover">[] = [
    {
      title: `Mit Erfolg zum ${n}`,
      publisher: "Klett",
      level: exam.recommendedLevel,
      skill: "Komplett",
      pages: 248,
      year: 2024,
      rating: 4.8,
      size: "18.4 MB",
      description: "Das Standardwerk: Übungsbuch, Testbuch und Lösungen in einem Band.",
    },
    {
      title: `${n} Vorbereitungskurs`,
      publisher: "Hueber",
      level: exam.recommendedLevel,
      skill: "Komplett",
      pages: 196,
      year: 2023,
      rating: 4.6,
      size: "15.1 MB",
      description: "Kompletter Kurs mit Strategietraining für alle vier Prüfungsteile.",
    },
    {
      title: `Prüfungstraining ${n}`,
      publisher: "Cornelsen",
      level: exam.levels[exam.levels.length - 1],
      skill: "Komplett",
      pages: 172,
      year: 2024,
      rating: 4.7,
      size: "12.9 MB",
      description: "Aufgabentypen Schritt für Schritt mit Tipps von Prüferinnen und Prüfern.",
    },
    {
      title: `Schreibtraining ${n}`,
      publisher: "Schubert",
      level: exam.recommendedLevel,
      skill: "Schreiben",
      pages: 128,
      year: 2023,
      rating: 4.5,
      size: "8.6 MB",
      description: "Musteraufsätze, Redemittel und Korrekturbeispiele für den schriftlichen Teil.",
    },
    {
      title: `Hörtraining ${n}`,
      publisher: "Klett",
      level: exam.recommendedLevel,
      skill: "Hören",
      pages: 96,
      year: 2022,
      rating: 4.4,
      size: "9.2 MB",
      description: "Hörstrategien plus Transkripte zu allen Audio-Dateien.",
    },
    {
      title: `Wortschatz für ${n}`,
      publisher: "Hueber",
      level: exam.levels.join("–"),
      skill: "Wortschatz",
      pages: 210,
      year: 2024,
      rating: 4.9,
      size: "11.7 MB",
      description: "Thematisch sortierter Prüfungswortschatz mit Beispielsätzen.",
    },
    {
      title: `Grammatik aktiv – ${n}`,
      publisher: "Cornelsen",
      level: exam.levels.join("–"),
      skill: "Grammatik",
      pages: 264,
      year: 2023,
      rating: 4.6,
      size: "14.3 MB",
      description: "Alle prüfungsrelevanten Strukturen erklärt und trainiert.",
    },
    {
      title: `Sprechen leicht gemacht – ${n}`,
      publisher: "Schubert",
      level: exam.recommendedLevel,
      skill: "Sprechen",
      pages: 112,
      year: 2024,
      rating: 4.3,
      size: "7.4 MB",
      description: "Dialogkarten, Redemittel und Bewertungskriterien für die mündliche Prüfung.",
    },
  ];
  return rows.map((b, i) => ({
    ...b,
    id: `${exam.id}-b${i + 1}`,
    cover: BOOK_COVERS[i % BOOK_COVERS.length],
  }));
}

const COMPARISON: Record<ExamId, ExamComparison> = {
  testdaf: {
    duration: "ca. 3 Std. 15 Min.",
    cost: "ca. 195 €",
    results: "4–6 Wochen",
    validity: "unbegrenzt",
    format: "Digital & Papier",
    bestFor: "Studium in Deutschland",
  },
  telc: {
    duration: "ca. 2 Std. 45 Min.",
    cost: "ca. 130–180 €",
    results: "4–6 Wochen",
    validity: "unbegrenzt",
    format: "Papier",
    bestFor: "Beruf, Einbürgerung, Studium",
  },
  oesd: {
    duration: "ca. 3 Std.",
    cost: "ca. 150–200 €",
    results: "3–5 Wochen",
    validity: "unbegrenzt",
    format: "Digital & Papier",
    bestFor: "Österreich, Beruf, Aufenthalt",
  },
  goethe: {
    duration: "ca. 3 Std. 15 Min.",
    cost: "ca. 180–250 €",
    results: "2–4 Wochen",
    validity: "unbegrenzt",
    format: "Digital & Papier",
    bestFor: "Weltweite Anerkennung",
  },
  dsh: {
    duration: "ca. 4 Std.",
    cost: "ca. 100–150 €",
    results: "1–2 Wochen",
    validity: "unbegrenzt",
    format: "Papier (an der Uni)",
    bestFor: "Direkter Hochschulzugang",
  },
};

const PURPOSE: Record<ExamId, ExamPurpose[]> = {
  testdaf: ["Studium"],
  telc: ["Beruf", "Aufenthalt", "Studium"],
  oesd: ["Aufenthalt", "Beruf", "Studium"],
  goethe: ["Studium", "Beruf", "Aufenthalt"],
  dsh: ["Studium"],
};

function makePrepPlan(exam: BaseExam): PrepWeek[] {
  const n = exam.shortName;
  return [
    {
      week: "Woche 1–2",
      focus: "Diagnose & Grundlagen",
      tasks: [
        "Einstufungstest im DEUSI Dashboard machen",
        `Prüfungsformat von ${n} genau anschauen`,
        "Lernplan mit festen Zeiten erstellen",
        "Erstes Wortschatzpaket starten (300 Wörter)",
      ],
    },
    {
      week: "Woche 3–4",
      focus: "Lesen & Wortschatz",
      tasks: [
        "Täglich 30 Min. Leseverstehen üben",
        "Skim- und Scan-Technik trainieren",
        "Grammatikmodul: Konnektoren & Nebensätze",
        "2 Leseübungssätze komplett lösen",
      ],
    },
    {
      week: "Woche 5–6",
      focus: "Hören & Notizen",
      tasks: [
        "Podcasts auf Niveau hören (DEUSI Podcasts)",
        "Notiztechnik mit Stichworten üben",
        "Audio-Set 1 komplett bearbeiten",
        "Transkripte nachlesen und Fehler markieren",
      ],
    },
    {
      week: "Woche 7–8",
      focus: "Schreiben",
      tasks: [
        "Wöchentlich 2 Aufsätze schreiben",
        "Redemittel-Liste auswendig lernen",
        "Musteraufsätze analysieren",
        "Korrektur mit dem KI-Coach machen",
      ],
    },
    {
      week: "Woche 9–10",
      focus: "Sprechen",
      tasks: [
        "Wöchentlich an einem Sprech-Event teilnehmen",
        "Themenkatalog durchgehen",
        "Antworten aufnehmen und anhören",
        "Mit Partner Prüfungsdialoge simulieren",
      ],
    },
    {
      week: "Woche 11–12",
      focus: "Simulation & Feinschliff",
      tasks: [
        `2 komplette ${n}-Modelltests unter Zeitdruck`,
        "Schwächste Fertigkeit gezielt wiederholen",
        "Prüfungsanmeldung & Unterlagen prüfen",
        "Erholung: am Tag vor der Prüfung nicht mehr lernen",
      ],
    },
  ];
}

export const EXAMS: Exam[] = BASE_EXAMS.map((e) => ({
  ...e,
  books: makeBooks(e),
  comparison: COMPARISON[e.id],
  prepPlan: makePrepPlan(e),
  purpose: PURPOSE[e.id],
}));

export function getExam(id: string): Exam | undefined {
  return EXAMS.find((e) => e.id === id);
}

export const EXAM_STATS = {
  totalExams: EXAMS.length,
  totalPractice: EXAMS.reduce((s, e) => s + e.practice.length, 0),
  totalExperiences: EXAMS.reduce((s, e) => s + e.experiences.length, 0),
  totalCenters: new Set(EXAMS.flatMap((e) => e.centers.map((c) => c.id))).size,
  totalBooks: EXAMS.reduce((s, e) => s + e.books.length, 0),
  totalResources: EXAMS.reduce((s, e) => s + e.resources.length, 0),
};
