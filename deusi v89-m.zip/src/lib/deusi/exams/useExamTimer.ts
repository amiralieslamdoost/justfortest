/**
 * تایمر آزمون، مقاوم به رفرش — سشن ۶.
 *
 * منبع حقیقت همیشه `deadlineAt` است (نه شمارندهٔ حافظه)، بنابراین بستن تب،
 * رفرش یا خواب سیستم زمان را خراب نمی‌کند.
 */
import { useEffect, useMemo, useRef, useState } from "react";

export interface ExamTimerState {
  secondsLeft: number;
  totalSeconds: number;
  expired: boolean;
  label: string;
  percent: number;
  warning: "none" | "five" | "one";
}

function secondsUntil(deadlineAt: string): number {
  const end = new Date(deadlineAt).getTime();
  if (Number.isNaN(end)) return 0;
  return Math.max(0, Math.round((end - Date.now()) / 1000));
}

export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(s / 60);
  const rest = s % 60;
  return `${String(m).padStart(2, "0")}:${String(rest).padStart(2, "0")}`;
}

/**
 * @param deadlineAt زمان پایان به ISO
 * @param startedAt  زمان شروع به ISO (برای درصد پیشرفت)
 * @param onExpire   یک‌بار در لحظهٔ اتمام زمان صدا زده می‌شود
 */
export function useExamTimer(
  deadlineAt: string | undefined,
  startedAt: string | undefined,
  onExpire?: () => void,
): ExamTimerState {
  const [secondsLeft, setSecondsLeft] = useState(() => (deadlineAt ? secondsUntil(deadlineAt) : 0));
  const firedRef = useRef(false);
  const expireRef = useRef(onExpire);
  expireRef.current = onExpire;

  const totalSeconds = useMemo(() => {
    if (!deadlineAt || !startedAt) return 0;
    const total = Math.round(
      (new Date(deadlineAt).getTime() - new Date(startedAt).getTime()) / 1000,
    );
    return Number.isFinite(total) && total > 0 ? total : 0;
  }, [deadlineAt, startedAt]);

  useEffect(() => {
    if (!deadlineAt) return;
    firedRef.current = false;
    const tick = () => {
      const left = secondsUntil(deadlineAt);
      setSecondsLeft(left);
      if (left <= 0 && !firedRef.current) {
        firedRef.current = true;
        expireRef.current?.();
      }
    };
    tick();
    const id = setInterval(tick, 1000);
    const onVisible = () => {
      if (document.visibilityState === "visible") tick();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [deadlineAt]);

  const warning: ExamTimerState["warning"] =
    secondsLeft <= 60 ? "one" : secondsLeft <= 300 ? "five" : "none";

  return {
    secondsLeft,
    totalSeconds,
    expired: Boolean(deadlineAt) && secondsLeft <= 0,
    label: formatClock(secondsLeft),
    percent: totalSeconds > 0 ? Math.round((secondsLeft / totalSeconds) * 100) : 0,
    warning,
  };
}
