/**
 * Modelltests (Mock) / آزمون‌های نمونه — سشن ۶.
 *
 * این فایل بانک سؤال آزمون‌های نمونه است. ساختار آن دقیقاً با
 * `exam_sections.questions` در `backend/pb_schema.json` هم‌خوان است تا
 * اسکریپت seed بتواند بدون تبدیل اضافه آن را به PocketBase منتقل کند.
 *
 * هیچ وابستگی به مرورگر یا داده تصادفی ندارد (قابل استفاده در seed سمت Node).
 */
import { EXAMS, type Exam, type ExamId } from "./mockExams";

/* -------------------------------------------------------------------------- */
/* تایپ‌ها                                                                      */
/* -------------------------------------------------------------------------- */

export type ExamSkill = "Lesen" | "Hoeren" | "Schreiben" | "Sprechen" | "Modelltest";

export type QuestionKind = "single" | "multi" | "truefalse" | "gap" | "matching" | "free";

export interface QuestionOption {
  id: string;
  text: string;
}

interface QuestionBase {
  id: string;
  kind: QuestionKind;
  prompt: string;
  /** متن/زمینهٔ سؤال (Lesetext یا Hörtext). */
  passage?: string;
  points: number;
  explanation?: string;
  hint?: string;
}

export interface SingleChoiceQuestion extends QuestionBase {
  kind: "single";
  options: QuestionOption[];
  correct: string;
}

export interface MultiChoiceQuestion extends QuestionBase {
  kind: "multi";
  options: QuestionOption[];
  correct: string[];
}

export interface TrueFalseQuestion extends QuestionBase {
  kind: "truefalse";
  correct: boolean;
}

export interface GapFillQuestion extends QuestionBase {
  kind: "gap";
  /** پاسخ‌های پذیرفته‌شده (بدون حساسیت به بزرگی/کوچکی حروف). */
  accepted: string[];
}

export interface MatchingQuestion extends QuestionBase {
  kind: "matching";
  left: QuestionOption[];
  right: QuestionOption[];
  /** نگاشت درست: کلید = شناسهٔ ستون چپ، مقدار = شناسهٔ ستون راست. */
  correct: Record<string, string>;
}

export interface FreeTextQuestion extends QuestionBase {
  kind: "free";
  minWords: number;
  sample?: string;
  /** پاسخ آزاد فقط با خودارزیابی نمره می‌گیرد. */
  manual: true;
}

export type ExamQuestion =
  | SingleChoiceQuestion
  | MultiChoiceQuestion
  | TrueFalseQuestion
  | GapFillQuestion
  | MatchingQuestion
  | FreeTextQuestion;

export interface ModelltestSection {
  id: string;
  examId: ExamId;
  skill: ExamSkill;
  title: string;
  intro: string;
  durationMin: number;
  maxPoints: number;
  order: number;
  questions: ExamQuestion[];
}

export interface Modelltest {
  examId: ExamId;
  title: string;
  level: string;
  totalMinutes: number;
  sections: ModelltestSection[];
}

/* -------------------------------------------------------------------------- */
/* بانک سؤال بر اساس سطح                                                        */
/* -------------------------------------------------------------------------- */

type Band = "B1" | "B2" | "C1";

/** حذف توزیعی `id` روی union سؤال‌ها (Omit ساده union را خراب می‌کند). */
type QuestionSeed = ExamQuestion extends infer T
  ? T extends ExamQuestion
    ? Omit<T, "id">
    : never
  : never;

interface SkillBank {
  intro: string;
  questions: QuestionSeed[];
}

type Bank = Record<Band, Record<"Lesen" | "Hoeren" | "Schreiben" | "Sprechen", SkillBank>>;

const BANK: Bank = {
  B1: {
    Lesen: {
      intro: "Lies die beiden kurzen Texte und beantworte die Fragen.",
      questions: [
        {
          kind: "single",
          prompt: "Warum schreibt Lena die E-Mail?",
          passage:
            "Hallo Tom,\nich muss unser Treffen am Donnerstag leider verschieben. Mein Chef hat mich für eine Fortbildung eingeteilt, die den ganzen Nachmittag dauert. Hättest du am Samstag Zeit? Dann könnten wir auch länger bleiben.\nViele Grüße, Lena",
          points: 2,
          options: [
            { id: "a", text: "Sie möchte einen neuen Termin vorschlagen." },
            { id: "b", text: "Sie sagt das Treffen endgültig ab." },
            { id: "c", text: "Sie sucht einen anderen Kursort." },
            { id: "d", text: "Sie bittet Tom um Hilfe bei der Arbeit." },
          ],
          correct: "a",
          explanation: "Lena verschiebt den Termin und schlägt den Samstag vor.",
        },
        {
          kind: "truefalse",
          prompt: "Lena hat am Donnerstag eine Fortbildung.",
          points: 1,
          correct: true,
        },
        {
          kind: "gap",
          prompt: "Ergänze: „Ich freue mich ___ das Wiedersehen.“",
          points: 1,
          accepted: ["auf"],
          explanation: "„sich freuen auf“ + Akkusativ.",
        },
        {
          kind: "multi",
          prompt: "Welche Angaben stehen im Text? (mehrere Antworten)",
          points: 2,
          options: [
            { id: "a", text: "Ein Wochentag" },
            { id: "b", text: "Ein Preis" },
            { id: "c", text: "Ein Alternativtermin" },
            { id: "d", text: "Eine Adresse" },
          ],
          correct: ["a", "c"],
        },
        {
          kind: "matching",
          prompt: "Ordne den Ausdrücken die passende Bedeutung zu.",
          points: 2,
          left: [
            { id: "l1", text: "verschieben" },
            { id: "l2", text: "einteilen" },
            { id: "l3", text: "Fortbildung" },
          ],
          right: [
            { id: "r1", text: "auf einen späteren Zeitpunkt legen" },
            { id: "r2", text: "jemandem eine Aufgabe zuweisen" },
            { id: "r3", text: "berufliche Weiterbildung" },
          ],
          correct: { l1: "r1", l2: "r2", l3: "r3" },
        },
      ],
    },
    Hoeren: {
      intro:
        "Lies das Transkript der Ansage (im Modelltest hörst du es zweimal) und beantworte die Fragen.",
      questions: [
        {
          kind: "single",
          prompt: "Was wird durchgesagt?",
          passage:
            "Transkript: „Sehr geehrte Fahrgäste, der Regionalexpress nach Leipzig hat heute etwa 20 Minuten Verspätung. Grund dafür ist eine Signalstörung. Bitte beachten Sie die Anzeigetafeln.“",
          points: 2,
          options: [
            { id: "a", text: "Der Zug fällt aus." },
            { id: "b", text: "Der Zug ist verspätet." },
            { id: "c", text: "Der Zug fährt von einem anderen Gleis." },
            { id: "d", text: "Der Bahnhof wird geschlossen." },
          ],
          correct: "b",
        },
        {
          kind: "gap",
          prompt: "Wie viele Minuten Verspätung hat der Zug? (nur die Zahl)",
          points: 1,
          accepted: ["20", "zwanzig"],
        },
        {
          kind: "truefalse",
          prompt: "Der Grund für die Verspätung ist das Wetter.",
          points: 1,
          correct: false,
          explanation: "Genannt wird eine Signalstörung.",
        },
        {
          kind: "single",
          prompt: "Worum werden die Fahrgäste gebeten?",
          points: 1,
          options: [
            { id: "a", text: "Die Anzeigetafeln zu beachten" },
            { id: "b", text: "Ein Taxi zu nehmen" },
            { id: "c", text: "Am Schalter zu warten" },
          ],
          correct: "a",
        },
      ],
    },
    Schreiben: {
      intro: "Schreibe eine kurze E-Mail. Achte auf Anrede, Struktur und Gruß.",
      questions: [
        {
          kind: "free",
          prompt:
            "Eine Freundin hat dich zum Geburtstag eingeladen, du kannst aber nicht kommen. Schreibe eine E-Mail (ca. 80 Wörter): bedanke dich, erkläre den Grund und schlage ein Treffen vor.",
          points: 10,
          minWords: 60,
          manual: true,
          sample:
            "Liebe Sara, vielen Dank für deine Einladung! Leider kann ich am Samstag nicht kommen, weil ich arbeiten muss. Ich würde dich aber gern nächste Woche treffen …",
        },
      ],
    },
    Sprechen: {
      intro: "Nimm dir zwei Minuten Vorbereitungszeit und notiere dein Sprechkonzept.",
      questions: [
        {
          kind: "free",
          prompt:
            "Stelle deinen Alltag vor: Was machst du an einem typischen Tag? Notiere Stichpunkte für ein Gespräch von zwei Minuten.",
          points: 10,
          minWords: 30,
          manual: true,
        },
      ],
    },
  },

  B2: {
    Lesen: {
      intro: "Lies den Zeitungsausschnitt und beantworte die Fragen.",
      questions: [
        {
          kind: "single",
          prompt: "Welche Aussage gibt den Text am besten wieder?",
          passage:
            "Immer mehr Unternehmen bieten ihren Beschäftigten hybride Arbeitsmodelle an. Studien zeigen: Wer zwei bis drei Tage pro Woche im Büro arbeitet, ist zufriedener als jemand, der ausschließlich zu Hause bleibt. Entscheidend sei jedoch nicht der Ort, sondern die Qualität der Absprachen im Team.",
          points: 2,
          options: [
            { id: "a", text: "Homeoffice macht grundsätzlich unzufrieden." },
            { id: "b", text: "Eine Mischung aus Büro und Homeoffice wirkt sich positiv aus." },
            { id: "c", text: "Unternehmen schaffen das Büro ab." },
            { id: "d", text: "Absprachen im Team spielen keine Rolle." },
          ],
          correct: "b",
        },
        {
          kind: "multi",
          prompt: "Welche Aussagen lassen sich aus dem Text belegen?",
          points: 2,
          options: [
            { id: "a", text: "Hybride Modelle verbreiten sich." },
            { id: "b", text: "Die Qualität der Absprachen ist wichtig." },
            { id: "c", text: "Alle Beschäftigten wollen fünf Tage ins Büro." },
            { id: "d", text: "Studien beschäftigen sich mit Zufriedenheit." },
          ],
          correct: ["a", "b", "d"],
        },
        {
          kind: "gap",
          prompt: "Ergänze das Nomen: „Die Absprachen im Team sind von großer ___.“",
          points: 1,
          accepted: ["Bedeutung", "Wichtigkeit"],
        },
        {
          kind: "truefalse",
          prompt: "Laut Text ist allein der Arbeitsort entscheidend.",
          points: 1,
          correct: false,
        },
        {
          kind: "matching",
          prompt: "Ordne die Konnektoren ihrer Funktion zu.",
          points: 3,
          left: [
            { id: "l1", text: "jedoch" },
            { id: "l2", text: "deshalb" },
            { id: "l3", text: "sofern" },
          ],
          right: [
            { id: "r1", text: "Gegensatz" },
            { id: "r2", text: "Folge" },
            { id: "r3", text: "Bedingung" },
          ],
          correct: { l1: "r1", l2: "r2", l3: "r3" },
        },
      ],
    },
    Hoeren: {
      intro: "Transkript eines Radiobeitrags. Beantworte danach die Fragen.",
      questions: [
        {
          kind: "single",
          prompt: "Welches Thema behandelt der Beitrag?",
          passage:
            "Transkript: „… in vielen Städten wächst das Angebot an Leihrädern schneller als die Zahl der Radwege. Verkehrsforscherin Dr. Wolf fordert deshalb, zuerst in die Infrastruktur zu investieren und erst danach die Flotten zu vergrößern.“",
          points: 2,
          options: [
            { id: "a", text: "Den Ausbau von Radwegen und Leihrädern" },
            { id: "b", text: "Neue Elektroautos" },
            { id: "c", text: "Die Preise im Nahverkehr" },
          ],
          correct: "a",
        },
        {
          kind: "gap",
          prompt: "Wie heißt die Verkehrsforscherin? (Nachname)",
          points: 1,
          accepted: ["Wolf", "Dr. Wolf"],
        },
        {
          kind: "truefalse",
          prompt: "Die Forscherin fordert, zuerst mehr Leihräder anzuschaffen.",
          points: 1,
          correct: false,
        },
        {
          kind: "multi",
          prompt: "Was wird im Beitrag genannt?",
          points: 2,
          options: [
            { id: "a", text: "Infrastruktur" },
            { id: "b", text: "Flottengröße" },
            { id: "c", text: "Ticketpreise" },
            { id: "d", text: "Städte" },
          ],
          correct: ["a", "b", "d"],
        },
      ],
    },
    Schreiben: {
      intro: "Verfasse einen strukturierten Text mit Einleitung, Argumenten und Schluss.",
      questions: [
        {
          kind: "free",
          prompt:
            "Nimm Stellung: „Sollten Unternehmen Homeoffice verpflichtend anbieten?“ Schreibe ca. 180 Wörter mit Argumenten für und gegen sowie deiner eigenen Meinung.",
          points: 15,
          minWords: 140,
          manual: true,
        },
      ],
    },
    Sprechen: {
      intro: "Bereite einen kurzen Vortrag vor (Stichpunkte genügen).",
      questions: [
        {
          kind: "free",
          prompt:
            "Präsentiere in drei Minuten Vor- und Nachteile des mobilen Arbeitens und beziehe am Ende klar Stellung.",
          points: 15,
          minWords: 40,
          manual: true,
        },
      ],
    },
  },

  C1: {
    Lesen: {
      intro: "Wissenschaftsjournalistischer Text mit anspruchsvollem Wortschatz.",
      questions: [
        {
          kind: "single",
          prompt: "Welche Schlussfolgerung zieht der Autor?",
          passage:
            "Die Digitalisierung der Hochschullehre hat die Zugänglichkeit von Wissen erheblich erweitert, zugleich aber die Anforderungen an die Selbstorganisation der Studierenden verschärft. Wer über ausgeprägte metakognitive Strategien verfügt, profitiert überproportional; alle anderen drohen abgehängt zu werden.",
          points: 3,
          options: [
            { id: "a", text: "Digitalisierung wirkt für alle Studierenden gleich." },
            { id: "b", text: "Digitalisierung verstärkt bestehende Unterschiede." },
            { id: "c", text: "Digitalisierung senkt die Anforderungen." },
            { id: "d", text: "Digitalisierung ist für Hochschulen bedeutungslos." },
          ],
          correct: "b",
        },
        {
          kind: "gap",
          prompt: "Ergänze das Fachwort aus dem Text: „___ Strategien“ (Denken über das Denken).",
          points: 2,
          accepted: ["metakognitive", "metakognitiv"],
        },
        {
          kind: "multi",
          prompt: "Welche Aspekte nennt der Text ausdrücklich?",
          points: 3,
          options: [
            { id: "a", text: "Zugänglichkeit von Wissen" },
            { id: "b", text: "Selbstorganisation" },
            { id: "c", text: "Studiengebühren" },
            { id: "d", text: "Ungleiche Ergebnisse" },
          ],
          correct: ["a", "b", "d"],
        },
        {
          kind: "matching",
          prompt: "Ordne den Wendungen die passende Umschreibung zu.",
          points: 3,
          left: [
            { id: "l1", text: "überproportional profitieren" },
            { id: "l2", text: "abgehängt werden" },
            { id: "l3", text: "Anforderungen verschärfen" },
          ],
          right: [
            { id: "r1", text: "deutlich mehr Nutzen ziehen als andere" },
            { id: "r2", text: "den Anschluss verlieren" },
            { id: "r3", text: "Ansprüche erhöhen" },
          ],
          correct: { l1: "r1", l2: "r2", l3: "r3" },
        },
        {
          kind: "truefalse",
          prompt: "Der Text bewertet die Entwicklung ausschließlich positiv.",
          points: 1,
          correct: false,
        },
      ],
    },
    Hoeren: {
      intro: "Transkript eines Vortragsausschnitts aus einem Universitätsseminar.",
      questions: [
        {
          kind: "single",
          prompt: "Welche Position vertritt der Referent?",
          passage:
            "Transkript: „… ich plädiere ausdrücklich dafür, Prüfungsleistungen stärker prozessorientiert zu bewerten. Eine einzige Abschlussklausur bildet weder Lernwege noch Kompetenzzuwachs angemessen ab.“",
          points: 3,
          options: [
            { id: "a", text: "Nur Abschlussklausuren sind aussagekräftig." },
            { id: "b", text: "Prüfungen sollten den Lernprozess stärker berücksichtigen." },
            { id: "c", text: "Prüfungen sollten abgeschafft werden." },
          ],
          correct: "b",
        },
        {
          kind: "gap",
          prompt: "Ergänze: Bewertung soll stärker ___ erfolgen (Adjektiv aus dem Text).",
          points: 2,
          accepted: ["prozessorientiert"],
        },
        {
          kind: "truefalse",
          prompt: "Der Referent hält eine einzelne Klausur für ausreichend.",
          points: 1,
          correct: false,
        },
        {
          kind: "multi",
          prompt: "Welche Begriffe fallen im Ausschnitt?",
          points: 2,
          options: [
            { id: "a", text: "Kompetenzzuwachs" },
            { id: "b", text: "Lernwege" },
            { id: "c", text: "Studienplatzvergabe" },
            { id: "d", text: "Abschlussklausur" },
          ],
          correct: ["a", "b", "d"],
        },
      ],
    },
    Schreiben: {
      intro: "Wissenschaftsnaher Text: Beschreibung einer Grafik plus Argumentation.",
      questions: [
        {
          kind: "free",
          prompt:
            "Beschreibe die Entwicklung der Studierendenzahlen (2015: 2,8 Mio.; 2020: 2,9 Mio.; 2024: 2,7 Mio.) und diskutiere anschließend mögliche Ursachen und Folgen. Ca. 250 Wörter.",
          points: 20,
          minWords: 180,
          manual: true,
        },
      ],
    },
    Sprechen: {
      intro: "Strukturierter Kurzvortrag mit anschließender Stellungnahme.",
      questions: [
        {
          kind: "free",
          prompt:
            "Halte einen Vortrag (4 Minuten): „Wie verändert künstliche Intelligenz das wissenschaftliche Arbeiten?“ Gliedere in Einleitung, zwei Argumente, Fazit.",
          points: 20,
          minWords: 50,
          manual: true,
        },
      ],
    },
  },
};

/* -------------------------------------------------------------------------- */
/* ساخت Modelltest برای هر آزمون                                                */
/* -------------------------------------------------------------------------- */

const EXAM_BAND: Record<ExamId, Band> = {
  telc: "B1",
  oesd: "B2",
  goethe: "B2",
  testdaf: "C1",
  dsh: "C1",
};

const SKILL_ORDER: ("Lesen" | "Hoeren" | "Schreiben" | "Sprechen")[] = [
  "Lesen",
  "Hoeren",
  "Schreiben",
  "Sprechen",
];

const SKILL_LABEL: Record<string, string> = {
  Lesen: "Lesen",
  Hoeren: "Hören",
  Schreiben: "Schreiben",
  Sprechen: "Sprechen",
};

/** مدت پیش‌فرض هر بخش، در صورت امکان از ساختار رسمی آزمون. */
function durationFor(exam: Exam, skill: string): number {
  const match = exam.structure.find((s) =>
    s.skill.toLowerCase().startsWith(skill.slice(0, 4).toLowerCase()),
  );
  const raw = match?.minutes ?? 30;
  // Modelltest کوتاه‌شده: حداکثر ۲۵ دقیقه در هر بخش، حداقل ۸ دقیقه.
  return Math.max(8, Math.min(25, Math.round(raw / 2)));
}

function buildSection(
  exam: Exam,
  skill: (typeof SKILL_ORDER)[number],
  order: number,
): ModelltestSection {
  const bank = BANK[EXAM_BAND[exam.id]][skill];
  const questions: ExamQuestion[] = bank.questions.map(
    (q, i) => ({ ...q, id: `${exam.id}-${skill.toLowerCase()}-q${i + 1}` }) as ExamQuestion,
  );
  return {
    id: `${exam.id}-${skill.toLowerCase()}`,
    examId: exam.id,
    skill,
    title: `${exam.shortName} · ${SKILL_LABEL[skill]}`,
    intro: bank.intro,
    durationMin: durationFor(exam, skill),
    maxPoints: questions.reduce((sum, q) => sum + q.points, 0),
    order,
    questions,
  };
}

function buildModelltest(exam: Exam): Modelltest {
  const sections = SKILL_ORDER.map((skill, i) => buildSection(exam, skill, i + 1));
  return {
    examId: exam.id,
    title: `${exam.shortName} Modelltest`,
    level: EXAM_BAND[exam.id],
    totalMinutes: sections.reduce((sum, s) => sum + s.durationMin, 0),
    sections,
  };
}

export const MODELLTESTS: Modelltest[] = EXAMS.map(buildModelltest);

export function getModelltest(examId: string): Modelltest | undefined {
  return MODELLTESTS.find((m) => m.examId === examId);
}

export function getModelltestSection(sectionId: string): ModelltestSection | undefined {
  for (const test of MODELLTESTS) {
    const found = test.sections.find((s) => s.id === sectionId);
    if (found) return found;
  }
  return undefined;
}

/** آیا سؤال نیاز به ارزیابی دستی دارد (پاسخ آزاد). */
export function isManualQuestion(q: ExamQuestion): q is FreeTextQuestion {
  return q.kind === "free";
}
