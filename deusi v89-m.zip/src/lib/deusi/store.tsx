import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { User, Word, DeckCard } from "./types";
import { SEED_WORDS } from "./seed";
import { newCard, schedule, type Rating } from "./fsrs";

import { authApi, onAuthChange, type AuthSession } from "@/lib/api/auth";
import { BACKEND } from "@/lib/api/config";
import { startOfflineQueue } from "@/lib/api/offline-queue";
import { migrateLocalVocabulary, upsertLeitnerItem } from "@/lib/api/vocabulary";
import { migrateLocalMediaProgress } from "@/lib/api/mediaProgress";
import { errorMessage } from "@/lib/api/errors";

const LS_USERS = "deusi.users";
const LS_WORDS = "deusi.masterWords";
const LS_SESSION = "deusi.session";

export type AuthResult = { ok: boolean; error?: string };

interface StoreCtx {
  users: User[];
  masterWords: Word[];
  currentUser: User | null;
  /** true once localStorage / the PocketBase session has been read on the client */
  hydrated: boolean;
  /** true when the backend (PocketBase) is configured */
  backend: boolean;
  allWords: Word[]; // master + user custom
  register: (username: string, email: string, password: string) => Promise<AuthResult>;
  login: (identifier: string, password: string) => Promise<AuthResult>;
  requestPasswordReset: (email: string) => Promise<AuthResult>;
  confirmPasswordReset: (token: string, password: string) => Promise<AuthResult>;
  logout: () => void;
  addCustomWord: (w: Word) => void;
  deleteCustomWord: (id: string) => void;
  rate: (wordId: string, rating: Rating) => void;
  dueCards: () => { card: DeckCard; word: Word }[];
  ensureDeckFor: (userId: string) => void;
}

const Ctx = createContext<StoreCtx | null>(null);

function load<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}
function save<T>(key: string, v: T) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

function nextStreak(user: Pick<User, "streak" | "lastStudy">) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const last = user.lastStudy ? new Date(user.lastStudy) : null;
  if (last) last.setHours(0, 0, 0, 0);
  if (!last) return 1;
  const diff = Math.round((today.getTime() - last.getTime()) / 86400000);
  if (diff === 0) return user.streak || 1;
  if (diff === 1) return user.streak + 1;
  return 1;
}

export function DeusiProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>([]);
  const [masterWords, setMasterWords] = useState<Word[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);

  /** نشست بازگشتی از بک‌اند را در state محلی جا می‌اندازد. */
  const absorb = useCallback((session: AuthSession | null) => {
    if (!session) {
      setSessionId(null);
      return;
    }
    setUsers((prev) => {
      const exists = prev.some((u) => u.id === session.user.id);
      return exists
        ? prev.map((u) =>
            u.id === session.user.id
              ? { ...u, ...session.user, deck: u.deck, customWords: u.customWords }
              : u,
          )
        : [...prev, session.user];
    });
    setSessionId(session.user.id);
    // صف آفلاین + مهاجرت یک‌بارهٔ دادهٔ محلی واژگان به سرور
    startOfflineQueue();
    void migrateLocalVocabulary(session.user.id);
    // مهاجرت یک‌بارهٔ پیشرفت مدیا (سشن ۵)
    void migrateLocalMediaProgress(session.user.id);
  }, []);

  useEffect(() => {
    const stored = load<Word[]>(LS_WORDS, []);
    setMasterWords(stored.length ? stored : SEED_WORDS);
    if (!stored.length) save(LS_WORDS, SEED_WORDS);

    setUsers(load<User[]>(LS_USERS, []));

    let cancelled = false;
    if (BACKEND) {
      // نشست واقعی: توکن ذخیره‌شده را تازه کن، بعد hydrate را باز کن.
      void authApi
        .refresh()
        .catch(() => null)
        .then((session) => {
          if (cancelled) return;
          absorb(session);
          setHydrated(true);
        });
    } else {
      setSessionId(load<string | null>(LS_SESSION, null));
      setHydrated(true);
    }
    return () => {
      cancelled = true;
    };
  }, [absorb]);

  // خروج در تب دیگر / انقضای توکن → پاک کردن نشست محلی.
  useEffect(() => {
    if (!BACKEND) return;
    return onAuthChange(() => {
      void authApi.restore().then((session) => {
        if (!session) setSessionId(null);
      });
    });
  }, []);

  // بازگشت به تب: توکن را تازه نگه دار.
  useEffect(() => {
    if (!BACKEND || typeof document === "undefined") return;
    const onVisible = () => {
      if (document.visibilityState === "visible") {
        void authApi
          .refresh()
          .then((session) => absorb(session))
          .catch(() => undefined);
      }
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [absorb]);

  useEffect(() => {
    if (hydrated) save(LS_USERS, users);
  }, [users, hydrated]);
  useEffect(() => {
    if (hydrated) save(LS_WORDS, masterWords);
  }, [masterWords, hydrated]);
  useEffect(() => {
    if (hydrated && !BACKEND) save(LS_SESSION, sessionId);
  }, [sessionId, hydrated]);

  const currentUser = useMemo(
    () => users.find((u) => u.id === sessionId) ?? null,
    [users, sessionId],
  );

  const allWords = useMemo(
    () => [...masterWords, ...(currentUser?.customWords ?? [])],
    [masterWords, currentUser],
  );

  const value: StoreCtx = {
    users,
    masterWords,
    currentUser,
    allWords,
    hydrated,
    backend: BACKEND,
    async register(username, email, password) {
      try {
        absorb(await authApi.register(username, email, password));
        return { ok: true };
      } catch (err) {
        return { ok: false, error: errorMessage(err) };
      }
    },
    async login(identifier, password) {
      try {
        absorb(await authApi.login(identifier, password));
        return { ok: true };
      } catch (err) {
        return { ok: false, error: errorMessage(err) };
      }
    },
    async requestPasswordReset(email) {
      try {
        await authApi.requestPasswordReset(email);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: errorMessage(err) };
      }
    },
    async confirmPasswordReset(token, password) {
      try {
        await authApi.confirmPasswordReset(token, password);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: errorMessage(err) };
      }
    },
    logout() {
      void authApi.logout().catch(() => undefined);
      setSessionId(null);
    },

    addCustomWord(w) {
      if (!currentUser) return;
      setUsers((prev) =>
        prev.map((u) =>
          u.id === currentUser.id
            ? { ...u, customWords: [...u.customWords, w], deck: [...u.deck, newCard(w.id)] }
            : u,
        ),
      );
    },
    deleteCustomWord(id) {
      if (!currentUser) return;
      setUsers((prev) =>
        prev.map((u) =>
          u.id === currentUser.id
            ? {
                ...u,
                customWords: u.customWords.filter((w) => w.id !== id),
                deck: u.deck.filter((c) => c.wordId !== id),
              }
            : u,
        ),
      );
    },
    rate(wordId, rating) {
      if (!currentUser) return;
      setUsers((prev) =>
        prev.map((u) => {
          if (u.id !== currentUser.id) return u;
          const deck = u.deck.map((c) => {
            if (c.wordId !== wordId) return c;
            const next = schedule(c, rating);
            // همگام‌سازی نتیجهٔ FSRS با سرور (در نبود شبکه: صف آفلاین)
            void upsertLeitnerItem(currentUser.id, {
              id: next.wordId,
              box: Math.min(5, Math.max(1, next.box)) as 1 | 2 | 3 | 4 | 5,
              reps: next.reps,
              lapses: next.lapses,
              ease: next.ease,
              interval: next.interval,
              dueAt: new Date(next.due).toISOString(),
            });
            return next;
          });
          return { ...u, deck, lastStudy: Date.now(), streak: nextStreak(u) };
        }),
      );
    },

    dueCards() {
      if (!currentUser) return [];
      const now = Date.now();
      return currentUser.deck
        .filter((c) => c.due <= now)
        .map((c) => ({ card: c, word: allWords.find((w) => w.id === c.wordId)! }))
        .filter((x) => x.word);
    },
    ensureDeckFor(userId) {
      setUsers((prev) =>
        prev.map((u) => {
          if (u.id !== userId) return u;
          const have = new Set(u.deck.map((c) => c.wordId));
          const missing = [...masterWords, ...u.customWords]
            .filter((w) => !have.has(w.id))
            .map((w) => newCard(w.id));
          return missing.length ? { ...u, deck: [...u.deck, ...missing] } : u;
        }),
      );
    },
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useDeusi() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useDeusi must be inside DeusiProvider");
  return v;
}
