// ---------------------------------------------------------------------------
// DEUSI — Profile mock data.
//
// Deterministic snapshot for the user's personal control center. All values
// are plain, JSON-serializable primitives so this file can be replaced by
// a `fetchProfile()` server function that returns the same shape.
// ---------------------------------------------------------------------------

export type CEFRLevel = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export interface ProfileHeader {
  fullName: string;
  username: string;
  email: string;
  level: CEFRLevel;
  memberSince: string; // "12. März 2024"
  streakDays: number;
  memoryHealth: number; // 0..100
  verified: boolean;
  avatarInitials: string;
  avatarGradient: [string, string];
}

export const PROFILE_HEADER: ProfileHeader = {
  fullName: "Max Mustermann",
  username: "@maxmustermann",
  email: "max.mustermann@example.com",
  level: "B1",
  memberSince: "12. März 2024",
  streakDays: 14,
  memoryHealth: 91,
  verified: true,
  avatarInitials: "MM",
  avatarGradient: ["#8B5CF6", "#DD2222"],
};

// ---------- Language roadmap ----------

export interface RoadmapNode {
  level: CEFRLevel;
  status: "done" | "current" | "locked";
  label: string;
}

export const ROADMAP: RoadmapNode[] = [
  { level: "A1", status: "done", label: "Anfänger" },
  { level: "A2", status: "done", label: "Grundlagen" },
  { level: "B1", status: "current", label: "Mittelstufe" },
  { level: "B2", status: "locked", label: "Fortgeschritten" },
  { level: "C1", status: "locked", label: "Kompetent" },
  { level: "C2", status: "locked", label: "Meisterhaft" },
];

export const ROADMAP_META = {
  currentLevel: "B1" as CEFRLevel,
  nextLevel: "B2" as CEFRLevel,
  daysUntilNext: 87,
  progressToNext: 35, // %
  overallProgress: 42, // %
};

// ---------- AI Coach insights ----------

export interface AiInsight {
  id: string;
  icon: "time" | "speed" | "vocab" | "lesson" | "weak" | "advice";
  title: string;
  detail: string;
  accent: string;
}

export const AI_INSIGHTS: AiInsight[] = [
  {
    id: "time",
    icon: "time",
    title: "Beste Lernzeit",
    detail: "Du lernst am besten zwischen 18:00 und 21:00 Uhr.",
    accent: "#8B5CF6",
  },
  {
    id: "speed",
    icon: "speed",
    title: "Lerntempo",
    detail: "12% schneller als letzte Woche.",
    accent: "#22C55E",
  },
  {
    id: "vocab",
    icon: "vocab",
    title: "Wortschatzwachstum",
    detail: "+42 neue Wörter in den letzten 7 Tagen.",
    accent: "#3B82F6",
  },
  {
    id: "lesson",
    icon: "lesson",
    title: "Nächste Empfehlung",
    detail: "Grammatik: Dativ mit Präpositionen.",
    accent: "#F59E0B",
  },
  {
    id: "weak",
    icon: "weak",
    title: "Schwaches Thema",
    detail: "Modalverben im Präteritum.",
    accent: "#DD2222",
  },
  {
    id: "advice",
    icon: "advice",
    title: "Persönlicher Tipp",
    detail: "Höre täglich 10 Minuten Podcast — es passt zu deinem Lernstil.",
    accent: "#EC4899",
  },
];

// ---------- Learning DNA ----------

export const LEARNING_DNA = {
  strongest: { label: "Lesen", value: 88 },
  weakest: { label: "Sprechen", value: 46 },
  favorite: "Podcasts",
  dailyAvg: "24 Min",
  preferredTime: "Abends (19:00 – 21:00)",
  consistency: 82, // %
};

// ---------- Statistics ----------

export interface StatCard {
  key: string;
  label: string;
  value: number;
  icon: string;
  tint: string;
  color: string;
}

export const STATS: StatCard[] = [
  {
    key: "words",
    label: "Wörter gelernt",
    value: 1250,
    icon: "book",
    tint: "#EAF7EE",
    color: "#22C55E",
  },
  {
    key: "flash",
    label: "Karten gemeistert",
    value: 320,
    icon: "cards",
    tint: "#FFF1E5",
    color: "#F59E0B",
  },
  {
    key: "leitner",
    label: "Leitner Reviews",
    value: 412,
    icon: "box",
    tint: "#F3ECFE",
    color: "#8B5CF6",
  },
  {
    key: "grammar",
    label: "Grammatik Lektionen",
    value: 24,
    icon: "grammar",
    tint: "#E7F0FE",
    color: "#3B82F6",
  },
  {
    key: "reading",
    label: "Artikel gelesen",
    value: 34,
    icon: "read",
    tint: "#FEE9E7",
    color: "#DD2222",
  },
  {
    key: "listening",
    label: "Hörübungen",
    value: 21,
    icon: "ear",
    tint: "#E7FBF4",
    color: "#10B981",
  },
  {
    key: "podcasts",
    label: "Podcasts gehört",
    value: 18,
    icon: "headphone",
    tint: "#F3ECFE",
    color: "#8B5CF6",
  },
  {
    key: "writing",
    label: "Schreibübungen",
    value: 12,
    icon: "pencil",
    tint: "#FFF4D6",
    color: "#F7C948",
  },
  { key: "ai", label: "KI Chats", value: 56, icon: "sparkle", tint: "#EAF7EE", color: "#22C55E" },
  {
    key: "events",
    label: "Events besucht",
    value: 7,
    icon: "calendar",
    tint: "#FEE9E7",
    color: "#DD2222",
  },
];

// ---------- Recent activity ----------

export interface ActivityItem {
  id: string;
  icon: "leitner" | "podcast" | "event" | "grammar" | "cards" | "read" | "ai";
  title: string;
  detail: string;
  time: string;
  day: "Heute" | "Gestern";
}

export const ACTIVITY: ActivityItem[] = [
  {
    id: "1",
    icon: "leitner",
    title: "Leitner Box Session beendet",
    detail: "12 Karten wiederholt",
    time: "10:24",
    day: "Heute",
  },
  {
    id: "2",
    icon: "podcast",
    title: "Podcast abgeschlossen",
    detail: '„Künstliche Intelligenz"',
    time: "09:15",
    day: "Heute",
  },
  {
    id: "3",
    icon: "event",
    title: "Event registriert",
    detail: "Sprachpraxis im Café",
    time: "08:40",
    day: "Heute",
  },
  {
    id: "4",
    icon: "grammar",
    title: "Grammatik Lektion abgeschlossen",
    detail: "Nominativ · Lektion 4",
    time: "20:30",
    day: "Gestern",
  },
  {
    id: "5",
    icon: "cards",
    title: "Flashcards Session abgeschlossen",
    detail: "15 neue Wörter gelernt",
    time: "18:15",
    day: "Gestern",
  },
  {
    id: "6",
    icon: "ai",
    title: "KI Coach Gespräch gestartet",
    detail: "Thema: Dativ",
    time: "16:02",
    day: "Gestern",
  },
];

// ---------- Badges / achievements ----------

export interface Badge {
  id: string;
  title: string;
  subtitle: string;
  gradient: [string, string];
  earned: boolean;
  icon: "fire" | "words" | "grammar" | "read" | "podcast" | "event";
}

export const BADGES: Badge[] = [
  {
    id: "streak7",
    title: "7 Tage",
    subtitle: "Serie",
    gradient: ["#F59E0B", "#DD2222"],
    earned: true,
    icon: "fire",
  },
  {
    id: "words100",
    title: "100",
    subtitle: "Wörter",
    gradient: ["#F7C948", "#F59E0B"],
    earned: true,
    icon: "words",
  },
  {
    id: "grammar",
    title: "Grammatik",
    subtitle: "Meister",
    gradient: ["#8B5CF6", "#3B82F6"],
    earned: true,
    icon: "grammar",
  },
  {
    id: "read",
    title: "Lesen",
    subtitle: "Experte",
    gradient: ["#F59E0B", "#DD2222"],
    earned: true,
    icon: "read",
  },
  {
    id: "podcast",
    title: "Podcast",
    subtitle: "Explorer",
    gradient: ["#3B82F6", "#8B5CF6"],
    earned: true,
    icon: "podcast",
  },
  {
    id: "event",
    title: "Event",
    subtitle: "Teilnehmer",
    gradient: ["#22C55E", "#10B981"],
    earned: true,
    icon: "event",
  },
];

// ---------- Certificates ----------

export interface Certificate {
  id: string;
  level: string;
  title: string;
  issuedOn: string;
  kind: "cefr" | "event" | "topic";
}

export const CERTIFICATES: Certificate[] = [
  { id: "cert-a1", level: "A1", title: "Zertifikat", issuedOn: "01.04.2024", kind: "cefr" },
  { id: "cert-a2", level: "A2", title: "Zertifikat", issuedOn: "20.06.2024", kind: "cefr" },
  {
    id: "cert-gr",
    level: "Grammatik",
    title: "Modul-Zertifikat",
    issuedOn: "12.07.2024",
    kind: "topic",
  },
  { id: "cert-ev", level: "Event", title: "Teilnahme", issuedOn: "25.05.2024", kind: "event" },
];

// ---------- Registered events ----------

export interface RegisteredEvent {
  id: string;
  title: string;
  institute: string;
  dateShort: string;
  dayNumber: string;
  month: string;
  time: string;
  group: string;
  table: number;
  seat: number;
  status: "confirmed" | "pending" | "waitlist";
}

export const REGISTERED_EVENTS: RegisteredEvent[] = [
  {
    id: "sprachpraxis-cafe",
    title: "Sprachpraxis im Café",
    institute: "Deutsch Mashhad",
    dateShort: "25.05.2024",
    dayNumber: "25",
    month: "Mai",
    time: "16:00 – 18:00 Uhr",
    group: "Gruppe D",
    table: 4,
    seat: 7,
    status: "confirmed",
  },
];

// ---------- Yearly heatmap (52 weeks × 7 days, 0..4) ----------

function buildHeatmap(): number[][] {
  const weeks: number[][] = [];
  let seed = 42;
  const rnd = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  for (let w = 0; w < 52; w++) {
    const week: number[] = [];
    for (let d = 0; d < 7; d++) {
      const r = rnd();
      // recent weeks denser
      const boost = w > 40 ? 0.35 : w > 30 ? 0.2 : 0;
      const v = r + boost;
      const lvl = v < 0.35 ? 0 : v < 0.55 ? 1 : v < 0.75 ? 2 : v < 0.9 ? 3 : 4;
      week.push(lvl);
    }
    weeks.push(week);
  }
  return weeks;
}

export const HEATMAP = buildHeatmap();
export const HEATMAP_MONTHS = [
  "Jan",
  "Feb",
  "Mär",
  "Apr",
  "Mai",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Okt",
  "Nov",
  "Dez",
];
export const HEATMAP_WEEKDAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];

// ---------- Settings defaults ----------

export const DEFAULT_SETTINGS = {
  profile: {
    fullName: "Max Mustermann",
    username: "maxmustermann",
    email: "max.mustermann@example.com",
    birthday: "1995-05-15",
    country: "Deutschland",
    timezone: "(UTC+02:00) Berlin",
  },
  learning: {
    dailyGoalMinutes: 30,
    preferredTime: "19:00",
    cefrGoal: "B2 — Fortgeschritten",
    dictionaryLanguage: "Deutsch",
    autoPronunciation: true,
    autoTranslation: true,
    flashcardShowIPA: true,
    flashcardAutoFlip: false,
    leitnerReviewLimit: 25,
  },
  notifications: {
    dailyReminder: true,
    leitnerReminder: true,
    eventReminder: true,
    podcastReminder: false,
    grammarReminder: true,
    email: true,
    push: true,
  },
};

export const SETTINGS_LANGUAGES = ["Deutsch", "English", "Persian"];
export const CEFR_GOALS = [
  "A2 — Grundlagen",
  "B1 — Mittelstufe",
  "B2 — Fortgeschritten",
  "C1 — Kompetent",
  "C2 — Meisterhaft",
];
export const TIMEZONES = [
  "(UTC+02:00) Berlin",
  "(UTC+01:00) London",
  "(UTC+03:30) Tehran",
  "(UTC+00:00) UTC",
];
