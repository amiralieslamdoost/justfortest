// Mock data for the DEUSI Grammar module.
// Structured so it can later be replaced by a real backend without touching UI.

export type CEFR = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type GrammarCategoryKey =
  | "cases"
  | "articles"
  | "tenses"
  | "modal-verbs"
  | "sentence-structure"
  | "adjective-endings"
  | "prepositions"
  | "passive"
  | "konjunktiv"
  | "relative-clauses"
  | "word-order"
  | "common-mistakes";

export interface GrammarCategory {
  key: GrammarCategoryKey;
  name: string;
  emoji: string;
  color: string; // token
  description: string;
}

export const grammarCategories: GrammarCategory[] = [
  {
    key: "cases",
    name: "Fälle",
    emoji: "📐",
    color: "#7c5cff",
    description: "Nominativ, Akkusativ, Dativ, Genitiv",
  },
  {
    key: "articles",
    name: "Artikel",
    emoji: "🔖",
    color: "#f59e0b",
    description: "der, die, das & Deklination",
  },
  {
    key: "tenses",
    name: "Zeitformen",
    emoji: "⏳",
    color: "#0ea5e9",
    description: "Präsens, Perfekt, Präteritum & mehr",
  },
  {
    key: "modal-verbs",
    name: "Modalverben",
    emoji: "🔑",
    color: "#ec4899",
    description: "können, müssen, dürfen, sollen …",
  },
  {
    key: "sentence-structure",
    name: "Satzbau",
    emoji: "🧱",
    color: "#22c55e",
    description: "Haupt- und Nebensätze",
  },
  {
    key: "adjective-endings",
    name: "Adjektivendungen",
    emoji: "🎨",
    color: "#eab308",
    description: "Endungen nach Artikel & Fall",
  },
  {
    key: "prepositions",
    name: "Präpositionen",
    emoji: "🧭",
    color: "#06b6d4",
    description: "mit, nach, für, durch …",
  },
  {
    key: "passive",
    name: "Passiv",
    emoji: "🌀",
    color: "#8b5cf6",
    description: "Vorgangs- und Zustandspassiv",
  },
  {
    key: "konjunktiv",
    name: "Konjunktiv",
    emoji: "💭",
    color: "#f43f5e",
    description: "Konjunktiv I & II",
  },
  {
    key: "relative-clauses",
    name: "Relativsätze",
    emoji: "🔗",
    color: "#14b8a6",
    description: "der, die, das als Relativpronomen",
  },
  {
    key: "word-order",
    name: "Wortstellung",
    emoji: "🎯",
    color: "#f97316",
    description: "TeKaMoLo, Verbposition",
  },
  {
    key: "common-mistakes",
    name: "Häufige Fehler",
    emoji: "⚠️",
    color: "#ef4444",
    description: "Typische Stolperfallen vermeiden",
  },
];

export type NodeKind =
  | "intro"
  | "explanation"
  | "visual"
  | "exercise"
  | "mistakes"
  | "practice"
  | "challenge"
  | "quiz"
  | "final"
  | "certificate";

export const nodeKindMeta: Record<NodeKind, { label: string; emoji: string; hue: string }> = {
  intro: { label: "Einführung", emoji: "🚀", hue: "#7c5cff" },
  explanation: { label: "Erklärung", emoji: "📖", hue: "#0ea5e9" },
  visual: { label: "Visuelles Beispiel", emoji: "🎨", hue: "#f59e0b" },
  exercise: { label: "Interaktive Übung", emoji: "🎮", hue: "#22c55e" },
  mistakes: { label: "Häufige Fehler", emoji: "⚠️", hue: "#ef4444" },
  practice: { label: "Praxis", emoji: "🏋️", hue: "#8b5cf6" },
  challenge: { label: "Challenge", emoji: "🔥", hue: "#ec4899" },
  quiz: { label: "Quiz", emoji: "🧠", hue: "#06b6d4" },
  final: { label: "Abschlusstest", emoji: "🏁", hue: "#14b8a6" },
  certificate: { label: "Zertifikat", emoji: "🏆", hue: "#eab308" },
};

export interface RoadmapNode {
  id: string;
  kind: NodeKind;
  title: string;
  description: string;
  duration: number; // minutes
  difficulty: CEFR;
  status: "done" | "current" | "locked" | "available";
}

export type ExerciseType =
  | "multiple-choice"
  | "fill-blank"
  | "drag-drop"
  | "build-sentence"
  | "match"
  | "rearrange"
  | "error-correction"
  | "select";

export interface Exercise {
  id: string;
  type: ExerciseType;
  prompt: string;
  data: {
    // multiple-choice / select
    options?: string[];
    answer?: string | string[];
    // fill-blank: prompt has "___", options fill it
    // drag-drop / rearrange / build-sentence: `tokens` + `answer` (ordered)
    tokens?: string[];
    // match: pairs of {left,right}
    pairs?: { left: string; right: string }[];
    // error-correction
    wrong?: string;
    correct?: string;
    explanation?: string;
  };
}

export interface Word {
  text: string;
  translation: string;
  role?: string; // e.g. "Nominativ (Wer?)"
  ipa?: string;
  related?: string; // lesson id
}

export interface Sentence {
  id: string;
  text: string;
  translation: string;
  words: Word[]; // highlighted words
}

export interface LessonSection {
  id: string;
  kind:
    | "hero"
    | "what-is"
    | "visual"
    | "examples"
    | "real-life"
    | "exercise"
    | "mistakes"
    | "tips"
    | "summary"
    | "quiz"
    | "next";
  title: string;
  body?: string;
  sentences?: Sentence[];
  exercise?: Exercise;
  bullets?: string[];
  compare?: { wrong: string; right: string; why: string }[];
}

export interface Lesson {
  id: string;
  nodeId: string; // matches roadmap node
  topicId: string;
  title: string;
  subtitle: string;
  emoji: string;
  duration: number;
  difficulty: CEFR;
  sections: LessonSection[];
}

export interface GrammarTopic {
  id: string;
  category: GrammarCategoryKey;
  name: string;
  subtitle: string;
  description: string;
  emoji: string;
  difficulty: CEFR;
  duration: number; // total minutes
  completion: number; // 0-100
  streak?: number;
  accent: string;
  nodes: RoadmapNode[];
  lessons: Lesson[];
}

// -------- Helpers to generate consistent demo data --------

function ex(id: string, e: Omit<Exercise, "id">): Exercise {
  return { id, ...e };
}

function makeNodes(topicId: string, completion: number): RoadmapNode[] {
  const spec: { kind: NodeKind; title: string; d: string; min: number; lvl: CEFR }[] = [
    { kind: "intro", title: "Einführung", d: "Warum ist dieses Thema wichtig?", min: 4, lvl: "A2" },
    {
      kind: "explanation",
      title: "Erklärung & Regeln",
      d: "Die wichtigsten Regeln verstehen.",
      min: 8,
      lvl: "A2",
    },
    {
      kind: "visual",
      title: "Visuelles Beispiel",
      d: "Sieh die Struktur in Farben & Formen.",
      min: 5,
      lvl: "A2",
    },
    {
      kind: "exercise",
      title: "Interaktive Übung",
      d: "Wende das Gelernte sofort an.",
      min: 6,
      lvl: "A2",
    },
    {
      kind: "mistakes",
      title: "Typische Fehler",
      d: "Vermeide die häufigsten Stolperfallen.",
      min: 5,
      lvl: "B1",
    },
    {
      kind: "practice",
      title: "Praxis im Satz",
      d: "Trainiere mit realen Sätzen.",
      min: 7,
      lvl: "B1",
    },
    {
      kind: "challenge",
      title: "Challenge",
      d: "Etwas anspruchsvollere Übungen.",
      min: 8,
      lvl: "B1",
    },
    { kind: "quiz", title: "Mini-Quiz", d: "Teste dein Wissen in 5 Fragen.", min: 5, lvl: "B1" },
    {
      kind: "final",
      title: "Abschlusstest",
      d: "Zeig, dass du es beherrschst.",
      min: 10,
      lvl: "B2",
    },
    {
      kind: "certificate",
      title: "Zertifikat",
      d: "Dein Fortschritt sichtbar gemacht.",
      min: 2,
      lvl: "B2",
    },
  ];
  const doneCount = Math.round((completion / 100) * spec.length);
  return spec.map((s, i) => {
    let status: RoadmapNode["status"] = "locked";
    if (i < doneCount) status = "done";
    else if (i === doneCount) status = "current";
    else if (i === doneCount + 1) status = "available";
    return {
      id: `${topicId}-n${i + 1}`,
      kind: s.kind,
      title: s.title,
      description: s.d,
      duration: s.min,
      difficulty: s.lvl,
      status,
    };
  });
}

function baseLesson(
  topicId: string,
  nodeId: string,
  title: string,
  subtitle: string,
  emoji: string,
): Lesson {
  return {
    id: `${nodeId}-l`,
    nodeId,
    topicId,
    title,
    subtitle,
    emoji,
    duration: 8,
    difficulty: "A2",
    sections: [
      {
        id: "hero",
        kind: "hero",
        title,
        body: subtitle,
      },
      {
        id: "what",
        kind: "what-is",
        title: `Was ist ${title}?`,
        body: "Kurz erklärt: Was steckt hinter dieser Grammatikregel und wozu brauchst du sie im Alltag?",
        bullets: [
          "Wozu dient diese Struktur?",
          "Wo begegnet sie dir im Deutschen?",
          "Wie erkennst du sie im Satz?",
        ],
      },
      {
        id: "visual",
        kind: "visual",
        title: "Visuelle Erklärung",
        body: "Farben zeigen dir die Rollen im Satz. Klicke auf einzelne Wörter, um mehr zu erfahren.",
        sentences: [
          {
            id: "s1",
            text: "Der Mann liest ein Buch.",
            translation: "The man is reading a book.",
            words: [
              {
                text: "Der Mann",
                translation: "the man",
                role: "Nominativ (Wer?)",
                ipa: "deːɐ̯ man",
              },
              { text: "liest", translation: "reads", role: "Verb (Präsens)" },
              { text: "ein Buch", translation: "a book", role: "Akkusativ (Wen/Was?)" },
            ],
          },
          {
            id: "s2",
            text: "Die Katze schläft auf dem Sofa.",
            translation: "The cat sleeps on the sofa.",
            words: [
              { text: "Die Katze", translation: "the cat", role: "Nominativ (Wer?)" },
              { text: "schläft", translation: "sleeps", role: "Verb (Präsens)" },
              { text: "auf dem Sofa", translation: "on the sofa", role: "Dativ (Wo?)" },
            ],
          },
        ],
      },
      {
        id: "real",
        kind: "real-life",
        title: "Beispiele aus dem Alltag",
        body: "So klingt es im echten Leben:",
        sentences: [
          {
            id: "r1",
            text: "Anna spielt Klavier.",
            translation: "Anna plays piano.",
            words: [
              { text: "Anna", translation: "Anna", role: "Nominativ" },
              { text: "spielt", translation: "plays", role: "Verb" },
              { text: "Klavier", translation: "piano", role: "Akkusativ" },
            ],
          },
          {
            id: "r2",
            text: "Die Sonne scheint heute hell.",
            translation: "The sun shines brightly today.",
            words: [
              { text: "Die Sonne", translation: "the sun", role: "Nominativ" },
              { text: "scheint", translation: "shines", role: "Verb" },
            ],
          },
          {
            id: "r3",
            text: "Mein Bruder fährt nach Berlin.",
            translation: "My brother is going to Berlin.",
            words: [
              { text: "Mein Bruder", translation: "my brother", role: "Nominativ" },
              { text: "fährt", translation: "drives / goes", role: "Verb" },
              { text: "nach Berlin", translation: "to Berlin", role: "Dativ" },
            ],
          },
        ],
      },
      {
        id: "ex1",
        kind: "exercise",
        title: "Interaktive Übung",
        exercise: ex("ex-mc-1", {
          type: "multiple-choice",
          prompt: "Welches Wort ist im Nominativ?",
          data: {
            options: ["Der Lehrer", "den Mann", "dem Kind", "des Buches"],
            answer: "Der Lehrer",
          },
        }),
      },
      {
        id: "mistakes",
        kind: "mistakes",
        title: "Typische Fehler",
        compare: [
          {
            wrong: "Den Mann liest ein Buch.",
            right: "Der Mann liest ein Buch.",
            why: "Das Subjekt steht im Nominativ.",
          },
          {
            wrong: "Ein Buch ist interessant.",
            right: "Ein Buch ist interessant.",
            why: "Hier stimmt alles – Achtung nur bei Artikel + Fall!",
          },
        ],
      },
      {
        id: "tips",
        kind: "tips",
        title: "Merke dir",
        bullets: [
          "Frage: Wer oder was macht etwas? → Nominativ",
          "Das Subjekt steht meist am Satzanfang.",
          "Verb steht in Position 2 im Hauptsatz.",
        ],
      },
      {
        id: "ex2",
        kind: "exercise",
        title: "Baue den Satz",
        exercise: ex("ex-build-1", {
          type: "build-sentence",
          prompt: "Ordne die Wörter zu einem Satz.",
          data: {
            tokens: ["liest", "Der Lehrer", "ein Buch"],
            answer: ["Der Lehrer", "liest", "ein Buch"],
          },
        }),
      },
      {
        id: "sum",
        kind: "summary",
        title: "Zusammenfassung",
        bullets: [
          "Nominativ = Subjekt des Satzes",
          "Frage: Wer? / Was?",
          "Steht meist am Anfang",
          "Bestimmt die Verbendung",
        ],
      },
      {
        id: "quiz",
        kind: "quiz",
        title: "Mini-Quiz",
        exercise: ex("ex-quiz-1", {
          type: "select",
          prompt: "Was fragt der Nominativ?",
          data: {
            options: ["Wen? / Was?", "Wem?", "Wer? / Was?", "Wessen?"],
            answer: "Wer? / Was?",
          },
        }),
      },
      {
        id: "next",
        kind: "next",
        title: "Nächste Lektion",
        body: "Bereit für den nächsten Schritt? Weiter geht's mit dem Akkusativ.",
      },
    ],
  };
}

function makeLessons(topicId: string, nodes: RoadmapNode[], topicName: string): Lesson[] {
  return nodes.map((n) =>
    baseLesson(
      topicId,
      n.id,
      `${topicName} – ${n.title}`,
      `${nodeKindMeta[n.kind].label} in diesem Thema.`,
      nodeKindMeta[n.kind].emoji,
    ),
  );
}

// -------- Topics per category (5 topics per common category → 60+) --------

interface TopicSpec {
  id: string;
  name: string;
  subtitle: string;
  emoji: string;
  difficulty: CEFR;
  completion: number;
  accent: string;
  category: GrammarCategoryKey;
}

const topicSpecs: TopicSpec[] = [
  // Cases
  {
    id: "nominativ",
    category: "cases",
    name: "Nominativ",
    subtitle: "Der Wer? Was? Fall",
    emoji: "🧑",
    difficulty: "A1",
    completion: 100,
    accent: "#7c5cff",
  },
  {
    id: "akkusativ",
    category: "cases",
    name: "Akkusativ",
    subtitle: "Der Wen? Was? Fall",
    emoji: "🎯",
    difficulty: "A2",
    completion: 75,
    accent: "#0ea5e9",
  },
  {
    id: "dativ",
    category: "cases",
    name: "Dativ",
    subtitle: "Der Wem? Fall",
    emoji: "🎁",
    difficulty: "A2",
    completion: 60,
    accent: "#22c55e",
  },
  {
    id: "genitiv",
    category: "cases",
    name: "Genitiv",
    subtitle: "Der Wessen? Fall",
    emoji: "📜",
    difficulty: "B1",
    completion: 20,
    accent: "#f97316",
  },
  {
    id: "faelle-uebersicht",
    category: "cases",
    name: "Alle Fälle im Überblick",
    subtitle: "Nom · Akk · Dat · Gen",
    emoji: "🗺️",
    difficulty: "B1",
    completion: 40,
    accent: "#ec4899",
  },
  // Articles
  {
    id: "artikel-basics",
    category: "articles",
    name: "der, die, das",
    subtitle: "Bestimmte Artikel",
    emoji: "🔖",
    difficulty: "A1",
    completion: 100,
    accent: "#f59e0b",
  },
  {
    id: "ein-eine",
    category: "articles",
    name: "ein / eine / ein",
    subtitle: "Unbestimmte Artikel",
    emoji: "🎴",
    difficulty: "A1",
    completion: 90,
    accent: "#eab308",
  },
  {
    id: "kein-nullartikel",
    category: "articles",
    name: "kein & Nullartikel",
    subtitle: "Verneinung mit Artikel",
    emoji: "🚫",
    difficulty: "A2",
    completion: 55,
    accent: "#ef4444",
  },
  {
    id: "artikel-deklination",
    category: "articles",
    name: "Artikeldeklination",
    subtitle: "Alle Formen tabellarisch",
    emoji: "📊",
    difficulty: "B1",
    completion: 30,
    accent: "#8b5cf6",
  },
  // Tenses
  {
    id: "praesens",
    category: "tenses",
    name: "Präsens",
    subtitle: "Gegenwart im Deutschen",
    emoji: "⏰",
    difficulty: "A1",
    completion: 100,
    accent: "#22c55e",
  },
  {
    id: "perfekt",
    category: "tenses",
    name: "Perfekt",
    subtitle: "Gesprochene Vergangenheit",
    emoji: "📼",
    difficulty: "A2",
    completion: 80,
    accent: "#0ea5e9",
  },
  {
    id: "praeteritum",
    category: "tenses",
    name: "Präteritum",
    subtitle: "Erzählte Vergangenheit",
    emoji: "📚",
    difficulty: "B1",
    completion: 45,
    accent: "#f59e0b",
  },
  {
    id: "plusquamperfekt",
    category: "tenses",
    name: "Plusquamperfekt",
    subtitle: "Vorvergangenheit",
    emoji: "🕰️",
    difficulty: "B2",
    completion: 10,
    accent: "#8b5cf6",
  },
  {
    id: "futur-i",
    category: "tenses",
    name: "Futur I",
    subtitle: "Zukunft & Vermutung",
    emoji: "🚀",
    difficulty: "B1",
    completion: 25,
    accent: "#ec4899",
  },
  {
    id: "futur-ii",
    category: "tenses",
    name: "Futur II",
    subtitle: "Vollendete Zukunft",
    emoji: "🛰️",
    difficulty: "B2",
    completion: 5,
    accent: "#7c5cff",
  },
  // Modal verbs
  {
    id: "koennen",
    category: "modal-verbs",
    name: "können",
    subtitle: "Fähigkeit & Möglichkeit",
    emoji: "💪",
    difficulty: "A1",
    completion: 100,
    accent: "#ec4899",
  },
  {
    id: "muessen",
    category: "modal-verbs",
    name: "müssen",
    subtitle: "Notwendigkeit",
    emoji: "❗",
    difficulty: "A1",
    completion: 90,
    accent: "#f43f5e",
  },
  {
    id: "duerfen",
    category: "modal-verbs",
    name: "dürfen",
    subtitle: "Erlaubnis",
    emoji: "✅",
    difficulty: "A2",
    completion: 65,
    accent: "#22c55e",
  },
  {
    id: "sollen",
    category: "modal-verbs",
    name: "sollen",
    subtitle: "Aufforderung & Rat",
    emoji: "📣",
    difficulty: "A2",
    completion: 55,
    accent: "#f59e0b",
  },
  {
    id: "moechten-wollen",
    category: "modal-verbs",
    name: "möchten / wollen",
    subtitle: "Wunsch & Wille",
    emoji: "💭",
    difficulty: "A2",
    completion: 50,
    accent: "#0ea5e9",
  },
  // Sentence structure
  {
    id: "hauptsatz",
    category: "sentence-structure",
    name: "Hauptsatz",
    subtitle: "Verb an Position 2",
    emoji: "🧱",
    difficulty: "A1",
    completion: 100,
    accent: "#22c55e",
  },
  {
    id: "nebensatz",
    category: "sentence-structure",
    name: "Nebensatz",
    subtitle: "Verb am Ende",
    emoji: "🧩",
    difficulty: "A2",
    completion: 70,
    accent: "#0ea5e9",
  },
  {
    id: "fragesatz",
    category: "sentence-structure",
    name: "Fragesatz",
    subtitle: "W-Fragen & Ja/Nein",
    emoji: "❓",
    difficulty: "A1",
    completion: 95,
    accent: "#f59e0b",
  },
  {
    id: "imperativ",
    category: "sentence-structure",
    name: "Imperativ",
    subtitle: "Aufforderungen",
    emoji: "🗣️",
    difficulty: "A2",
    completion: 60,
    accent: "#ec4899",
  },
  // Adjective endings
  {
    id: "adj-nach-der",
    category: "adjective-endings",
    name: "nach der/die/das",
    subtitle: "Schwache Deklination",
    emoji: "🎨",
    difficulty: "A2",
    completion: 55,
    accent: "#eab308",
  },
  {
    id: "adj-nach-ein",
    category: "adjective-endings",
    name: "nach ein/eine",
    subtitle: "Gemischte Deklination",
    emoji: "🖌️",
    difficulty: "B1",
    completion: 35,
    accent: "#f59e0b",
  },
  {
    id: "adj-null",
    category: "adjective-endings",
    name: "ohne Artikel",
    subtitle: "Starke Deklination",
    emoji: "🎭",
    difficulty: "B1",
    completion: 20,
    accent: "#ec4899",
  },
  {
    id: "komparativ",
    category: "adjective-endings",
    name: "Komparativ & Superlativ",
    subtitle: "Steigerung",
    emoji: "📈",
    difficulty: "A2",
    completion: 70,
    accent: "#22c55e",
  },
  // Prepositions
  {
    id: "wechselprep",
    category: "prepositions",
    name: "Wechselpräpositionen",
    subtitle: "Akkusativ oder Dativ?",
    emoji: "🔄",
    difficulty: "A2",
    completion: 50,
    accent: "#06b6d4",
  },
  {
    id: "akk-prep",
    category: "prepositions",
    name: "mit Akkusativ",
    subtitle: "für, ohne, gegen …",
    emoji: "➡️",
    difficulty: "A2",
    completion: 65,
    accent: "#0ea5e9",
  },
  {
    id: "dat-prep",
    category: "prepositions",
    name: "mit Dativ",
    subtitle: "mit, nach, bei, seit …",
    emoji: "⬅️",
    difficulty: "A2",
    completion: 60,
    accent: "#22c55e",
  },
  {
    id: "gen-prep",
    category: "prepositions",
    name: "mit Genitiv",
    subtitle: "wegen, trotz, während …",
    emoji: "🎓",
    difficulty: "B2",
    completion: 15,
    accent: "#8b5cf6",
  },
  // Passive
  {
    id: "vorgangspassiv",
    category: "passive",
    name: "Vorgangspassiv",
    subtitle: "werden + Partizip II",
    emoji: "🌀",
    difficulty: "B1",
    completion: 30,
    accent: "#8b5cf6",
  },
  {
    id: "zustandspassiv",
    category: "passive",
    name: "Zustandspassiv",
    subtitle: "sein + Partizip II",
    emoji: "🧊",
    difficulty: "B2",
    completion: 15,
    accent: "#0ea5e9",
  },
  {
    id: "passiv-modal",
    category: "passive",
    name: "Passiv mit Modalverb",
    subtitle: "muss gemacht werden",
    emoji: "⚙️",
    difficulty: "B2",
    completion: 8,
    accent: "#ec4899",
  },
  // Konjunktiv
  {
    id: "konjunktiv-ii",
    category: "konjunktiv",
    name: "Konjunktiv II",
    subtitle: "Wünsche & Höflichkeit",
    emoji: "💭",
    difficulty: "B1",
    completion: 25,
    accent: "#f43f5e",
  },
  {
    id: "konjunktiv-i",
    category: "konjunktiv",
    name: "Konjunktiv I",
    subtitle: "Indirekte Rede",
    emoji: "📰",
    difficulty: "B2",
    completion: 10,
    accent: "#ec4899",
  },
  {
    id: "irreal",
    category: "konjunktiv",
    name: "Irreale Bedingungen",
    subtitle: "Wenn ich … wäre",
    emoji: "🌙",
    difficulty: "B2",
    completion: 12,
    accent: "#7c5cff",
  },
  // Relative clauses
  {
    id: "relativ-basics",
    category: "relative-clauses",
    name: "Relativpronomen",
    subtitle: "der, die, das im Nebensatz",
    emoji: "🔗",
    difficulty: "B1",
    completion: 40,
    accent: "#14b8a6",
  },
  {
    id: "relativ-prep",
    category: "relative-clauses",
    name: "mit Präposition",
    subtitle: "mit dem, in der …",
    emoji: "🪝",
    difficulty: "B2",
    completion: 18,
    accent: "#0ea5e9",
  },
  // Word order
  {
    id: "tekamolo",
    category: "word-order",
    name: "TeKaMoLo",
    subtitle: "Temporal · Kausal · Modal · Lokal",
    emoji: "🎯",
    difficulty: "B1",
    completion: 45,
    accent: "#f97316",
  },
  {
    id: "verbklammer",
    category: "word-order",
    name: "Verbklammer",
    subtitle: "Trennbare Verben & Perfekt",
    emoji: "🧲",
    difficulty: "A2",
    completion: 70,
    accent: "#ec4899",
  },
  // Common mistakes
  {
    id: "false-friends",
    category: "common-mistakes",
    name: "False Friends",
    subtitle: "Wörter, die täuschen",
    emoji: "🎭",
    difficulty: "A2",
    completion: 55,
    accent: "#ef4444",
  },
  {
    id: "fall-fehler",
    category: "common-mistakes",
    name: "Fallfehler",
    subtitle: "Nominativ statt Akkusativ",
    emoji: "⚠️",
    difficulty: "B1",
    completion: 30,
    accent: "#f43f5e",
  },
];

export const grammarTopics: GrammarTopic[] = topicSpecs.map((spec) => {
  const nodes = makeNodes(spec.id, spec.completion);
  return {
    id: spec.id,
    category: spec.category,
    name: spec.name,
    subtitle: spec.subtitle,
    description: spec.subtitle,
    emoji: spec.emoji,
    difficulty: spec.difficulty,
    duration: nodes.reduce((s, n) => s + n.duration, 0),
    completion: spec.completion,
    accent: spec.accent,
    nodes,
    lessons: makeLessons(spec.id, nodes, spec.name),
  };
});

export function findTopic(id: string) {
  return grammarTopics.find((t) => t.id === id);
}
export function findLesson(topicId: string, lessonId: string) {
  const t = findTopic(topicId);
  return t?.lessons.find((l) => l.id === lessonId);
}
export function findNode(topicId: string, nodeId: string) {
  const t = findTopic(topicId);
  return t?.nodes.find((n) => n.id === nodeId);
}
export function lessonForNode(topicId: string, nodeId: string) {
  const t = findTopic(topicId);
  return t?.lessons.find((l) => l.nodeId === nodeId);
}

export function grammarStats() {
  const total = grammarTopics.length;
  const done = grammarTopics.filter((t) => t.completion === 100).length;
  const avg = Math.round(grammarTopics.reduce((s, t) => s + t.completion, 0) / total);
  const totalLessons = grammarTopics.reduce((s, t) => s + t.lessons.length, 0);
  const doneLessons = grammarTopics.reduce(
    (s, t) => s + t.nodes.filter((n) => n.status === "done").length,
    0,
  );
  return {
    totalTopics: total,
    doneTopics: done,
    avgCompletion: avg,
    totalLessons,
    doneLessons,
    xp: 2450,
    level: 12,
    streak: 14,
    accuracy: 78,
    timeSpent: "6h 32m",
    weekProgress: 12,
  };
}

export function continueLearning() {
  return grammarTopics.find((t) => t.completion > 0 && t.completion < 100) ?? grammarTopics[1];
}

export function recommendedTopics() {
  return grammarTopics.filter((t) => t.completion < 60).slice(0, 4);
}

export function recentlyStudied() {
  return grammarTopics.filter((t) => t.completion > 0).slice(0, 3);
}

export function aiSuggestions(): string[] {
  return [
    "Wiederhole den Akkusativ – deine Genauigkeit ist bei 62 %.",
    "Neu für dich: Konjunktiv II wirkt oft in Alltagsdialogen.",
    "Kurze Übung: TeKaMoLo in 5 Minuten festigen.",
    "Basierend auf deinen Fehlern: Fokus auf Wechselpräpositionen.",
  ];
}
