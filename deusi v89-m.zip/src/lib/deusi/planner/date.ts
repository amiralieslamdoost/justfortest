import { WEEKDAY_LABEL, WEEK_START_DAY } from "./config";

/** yyyy-mm-dd für ein Date (lokale Zeit, kein UTC-Versatz). */
export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function fromISODate(iso: string): Date {
  const [y, m, d] = iso.split("-").map((n) => Number(n));
  return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
}

export function todayISO(): string {
  return toISODate(new Date());
}

export function addDays(iso: string, days: number): string {
  const d = fromISODate(iso);
  d.setDate(d.getDate() + days);
  return toISODate(d);
}

/** Wochenanfang (Samstag) für ein Datum. */
export function weekStartOf(iso: string): string {
  const d = fromISODate(iso);
  const diff = (d.getDay() - WEEK_START_DAY + 7) % 7;
  d.setDate(d.getDate() - diff);
  return toISODate(d);
}

export function weekDates(weekStart: string): string[] {
  return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
}

export function weekdayOf(iso: string): number {
  return fromISODate(iso).getDay();
}

export function weekdayLabel(iso: string) {
  return WEEKDAY_LABEL[weekdayOf(iso)]!;
}

/** "12. Aug." */
export function formatDayShort(iso: string): string {
  const d = fromISODate(iso);
  return d.toLocaleDateString("de-DE", { day: "numeric", month: "short" });
}

/** "12. August 2026" */
export function formatDayLong(iso: string): string {
  return fromISODate(iso).toLocaleDateString("de-DE", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function formatWeekRange(weekStart: string): string {
  const end = addDays(weekStart, 6);
  return `${formatDayShort(weekStart)} – ${formatDayShort(end)}`;
}

/** "19:00" -> 1140 */
export function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(":").map((n) => Number(n));
  return (h ?? 0) * 60 + (m ?? 0);
}

/** 1140 -> "19:00" (bleibt innerhalb eines Tages) */
export function toClock(minutes: number): string {
  const clamped = Math.max(0, Math.min(24 * 60 - 1, Math.round(minutes)));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${`${h}`.padStart(2, "0")}:${`${m}`.padStart(2, "0")}`;
}

export function addClock(hhmm: string, minutes: number): string {
  return toClock(toMinutes(hhmm) + minutes);
}

/** "1 h 45 min" / "45 min" */
export function formatMinutes(total: number): string {
  const m = Math.max(0, Math.round(total));
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  const rest = m % 60;
  return rest ? `${h} h ${rest} min` : `${h} h`;
}

/** Tage bis zu einem Zieldatum (negativ = vorbei). */
export function daysUntil(iso: string): number {
  const target = fromISODate(iso).getTime();
  const now = fromISODate(todayISO()).getTime();
  return Math.round((target - now) / 86_400_000);
}

/** Überschneiden sich zwei Zeitfenster? */
export function overlaps(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
  return toMinutes(aStart) < toMinutes(bEnd) && toMinutes(bStart) < toMinutes(aEnd);
}
