import { DEFAULT_PREFS } from "./config";
import { toMinutes } from "./date";
import type { PlannerPrefs, PlannerSession } from "./types";

/**
 * Persistenz-Adapter des Planers.
 *
 * Seit Session 7 liegt die eigentliche Persistenz in `@/lib/api/planner`
 * (PocketBase + Offline-Spiegel im localStorage). Dieses Modul enthält nur
 * noch die reinen Helfer, die UI und Engine gemeinsam nutzen.
 */

export {
  loadPrefs,
  savePrefs,
  loadWeek,
  saveWeek,
  putSession,
  deleteSession,
  logSession,
  sortSessions,
} from "@/lib/api/planner";

export function normalizePrefs(input: Partial<PlannerPrefs> | null): PlannerPrefs {
  const merged = { ...DEFAULT_PREFS, ...(input ?? {}) } as PlannerPrefs;
  return {
    ...merged,
    dailyMinutes: Math.max(10, Math.min(240, Math.round(merged.dailyMinutes || 45))),
    availableDays: (merged.availableDays?.length
      ? merged.availableDays
      : DEFAULT_PREFS.availableDays
    )
      .filter((d) => d >= 0 && d <= 6)
      .sort((a, b) => a - b),
    goals: merged.goals?.length ? merged.goals : DEFAULT_PREFS.goals,
    weakSkills: merged.weakSkills ?? [],
    strongSkills: merged.strongSkills ?? [],
    updatedAt: merged.updatedAt ?? new Date().toISOString(),
  };
}

/** Sortierung ohne Backend-Abhängigkeit (Engine-intern nutzbar). */
export function sortByClock(sessions: PlannerSession[]): PlannerSession[] {
  return [...sessions].sort(
    (a, b) => a.date.localeCompare(b.date) || toMinutes(a.start) - toMinutes(b.start),
  );
}
