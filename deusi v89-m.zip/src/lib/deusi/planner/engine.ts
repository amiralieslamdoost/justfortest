import {
  DEADLINE_RULES,
  GOAL_SKILL_MULTIPLIER,
  INTENSITY,
  LEVEL_SKILL_WEIGHTS,
  REST_RULES,
  REVIEW_RULES,
  SESSION_RULES,
  SKILL_ORDER,
} from "./config";
import { ACTIVITIES, ACTIVITY_BY_ID, activitiesForSkill } from "./activities";
import { addClock, daysUntil, toMinutes, weekDates, weekdayOf } from "./date";
import type {
  ActivityDef,
  PlannerPrefs,
  PlannerSession,
  PlannerWeek,
  SessionPriority,
  SkillKey,
} from "./types";

/**
 * Deterministische Planungs-Engine (Version 1).
 *
 * Bewusst ohne externe KI: gleiche Eingaben → gleicher Plan. Die Didaktik
 * steckt vollständig in config.ts, hier wird nur verteilt und terminiert.
 * Eine späte KI-Stufe kann `generateWeek` ersetzen, ohne die UI zu ändern.
 */

type Bucket = SkillKey | "exam";

const round = (n: number, step = SESSION_RULES.stepMinutes) => Math.round(n / step) * step;

/** Kleiner deterministischer Zähler aus einem String (Wochen-Seed). */
function seedOf(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

/** Gewichtung pro Fertigkeit aus Stufe, Zielen und Stärken/Schwächen. */
export function skillWeights(prefs: PlannerPrefs): Record<SkillKey, number> {
  const base = LEVEL_SKILL_WEIGHTS[prefs.level] ?? LEVEL_SKILL_WEIGHTS.unknown;
  const weights = {} as Record<SkillKey, number>;

  SKILL_ORDER.forEach((skill) => {
    let w = base[skill];
    const goals = prefs.goals.length ? prefs.goals : ["general" as const];
    const multipliers = goals.map((g) => GOAL_SKILL_MULTIPLIER[g]?.[skill] ?? 1);
    w *= multipliers.reduce((a, b) => a + b, 0) / multipliers.length;
    if (prefs.weakSkills.includes(skill)) w *= 1.6;
    if (prefs.strongSkills.includes(skill)) w *= 0.7;
    weights[skill] = w;
  });

  const sum = SKILL_ORDER.reduce((a, s) => a + weights[s], 0) || 1;
  SKILL_ORDER.forEach((s) => {
    weights[s] = weights[s] / sum;
  });
  return weights;
}

/** Anteil der Wochenzeit, der in Prüfungstraining fließt (0 wenn kein Ziel nah). */
export function examShare(prefs: PlannerPrefs): number {
  if (!prefs.targetDate) return 0;
  const left = daysUntil(prefs.targetDate);
  if (left < 0 || left > DEADLINE_RULES.examFocusDays) return 0;
  const closeness = 1 - left / DEADLINE_RULES.examFocusDays;
  return DEADLINE_RULES.examShare * Math.max(0.35, closeness);
}

/** Tagesbudget nach Intensität, auf 5 Minuten gerundet. */
export function dailyBudget(prefs: PlannerPrefs): number {
  const factor = INTENSITY[prefs.intensity]?.factor ?? 1;
  return Math.max(SESSION_RULES.minMinutes, round(prefs.dailyMinutes * factor));
}

/** Lerntage der Woche — Verfügbarkeit plus optionaler Ruhetag. */
export function activeDaysOf(prefs: PlannerPrefs, weekStart: string): string[] {
  const days = weekDates(weekStart).filter((d) => prefs.availableDays.includes(weekdayOf(d)));
  if (prefs.restDays !== "auto" || days.length < REST_RULES.minDaysForRest) return days;
  const preferred = days.find((d) => weekdayOf(d) === REST_RULES.preferredRestDay);
  const rest = preferred ?? days[days.length - 1];
  return days.filter((d) => d !== rest);
}

/** Anzahl Blöcke für ein Tagesbudget. */
function blockCount(minutes: number): number {
  const rule = SESSION_RULES.blocks.find((b) => minutes <= b.upTo);
  return rule?.count ?? 3;
}

function pickActivity(bucket: Bucket, prefs: PlannerPrefs, counter: number): ActivityDef | null {
  const pool = (
    bucket === "exam" ? ACTIVITIES.filter((a) => a.category === "exam") : activitiesForSkill(bucket)
  ).filter((a) => {
    if (a.levels && prefs.level !== "unknown" && !a.levels.includes(prefs.level)) return false;
    if (a.goals && !a.goals.some((g) => prefs.goals.includes(g))) return false;
    return true;
  });
  if (!pool.length) return null;
  return pool[counter % pool.length] ?? null;
}

function priorityOf(bucket: Bucket, prefs: PlannerPrefs): SessionPriority {
  if (bucket === "exam") return "high";
  if (prefs.weakSkills.includes(bucket)) return "high";
  if (prefs.strongSkills.includes(bucket)) return "low";
  return "normal";
}

/** Teilt ein Tagesbudget in realistische Blöcke (nie unter minMinutes). */
function splitDay(minutes: number, count: number): number[] {
  const n = Math.max(1, count);
  const share = round(minutes / n);
  const blocks: number[] = [];
  let left = minutes;
  for (let i = 0; i < n; i += 1) {
    const isLast = i === n - 1;
    let value = isLast ? left : Math.min(share, SESSION_RULES.maxMinutes);
    value = Math.max(SESSION_RULES.minMinutes, round(value));
    if (!isLast && left - value < SESSION_RULES.minMinutes * (n - i - 1)) {
      value = Math.max(SESSION_RULES.minMinutes, left - SESSION_RULES.minMinutes * (n - i - 1));
    }
    value = Math.min(value, SESSION_RULES.maxMinutes, left);
    if (value < SESSION_RULES.minMinutes) break;
    blocks.push(value);
    left -= value;
  }
  if (left >= SESSION_RULES.stepMinutes && blocks.length) {
    // Restminuten auf den ersten Block legen, aber Maximum respektieren.
    for (let i = 0; i < blocks.length && left > 0; i += 1) {
      const room = SESSION_RULES.maxMinutes - blocks[i]!;
      const give = Math.min(room, left);
      blocks[i] = blocks[i]! + give;
      left -= give;
    }
  }
  return blocks;
}

export type GenerateOptions = {
  /** Sessions, die erhalten bleiben (manuell bearbeitet oder selbst angelegt). */
  keep?: PlannerSession[];
};

let idCounter = 0;
export function newSessionId(): string {
  idCounter += 1;
  const rand = Math.random().toString(36).slice(2, 8);
  return `ps_${Date.now().toString(36)}_${idCounter.toString(36)}_${rand}`;
}

export function sessionFromActivity(
  activity: ActivityDef,
  input: {
    date: string;
    start: string;
    minutes: number;
    level: PlannerPrefs["level"];
    priority?: SessionPriority;
    generated?: boolean;
    resourceId?: string;
  },
): PlannerSession {
  const now = new Date().toISOString();
  return {
    id: newSessionId(),
    date: input.date,
    start: input.start,
    end: addClock(input.start, input.minutes),
    minutes: input.minutes,
    activityId: activity.id,
    module: activity.module,
    skill: activity.skill,
    title: activity.titleDe,
    description: activity.descDe,
    level: input.level,
    priority: input.priority ?? "normal",
    status: "planned",
    href: activity.href,
    cta: activity.cta,
    ...(input.resourceId ? { resourceId: input.resourceId } : {}),
    generated: input.generated ?? true,
    edited: false,
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Erzeugt den Wochenplan.
 * `opts.keep` bleibt unangetastet und wird nur bei der Zeitplanung berücksichtigt.
 */
export function generateWeek(
  prefs: PlannerPrefs,
  weekStart: string,
  opts: GenerateOptions = {},
): PlannerWeek {
  const keep = opts.keep ?? [];
  const days = activeDaysOf(prefs, weekStart);
  const budget = dailyBudget(prefs);
  const weekly = days.length * budget;
  const weights = skillWeights(prefs);
  const exam = examShare(prefs);

  // Wochen-Budget pro Bucket (Prüfung zieht anteilig von allen Fertigkeiten ab).
  const remaining = {} as Record<Bucket, number>;
  SKILL_ORDER.forEach((s) => {
    remaining[s] = weights[s] * weekly * (1 - exam);
  });
  remaining.exam = weekly * exam;

  const leitnerMinutes = REVIEW_RULES.leitnerMinutes[prefs.intensity] ?? 15;
  const sessions: PlannerSession[] = [];
  let counter = seedOf(weekStart) % 7;

  days.forEach((date, dayIndex) => {
    const keptToday = keep
      .filter((s) => s.date === date)
      .sort((a, b) => toMinutes(a.start) - toMinutes(b.start));
    const keptMinutes = keptToday.reduce((a, s) => a + s.minutes, 0);
    let dayMinutes = Math.max(0, budget - keptMinutes);
    if (dayMinutes < SESSION_RULES.minMinutes) return;

    // Startzeit: nach der letzten beibehaltenen Session, sonst Wunschzeit.
    const lastKeptEnd = keptToday.length ? keptToday[keptToday.length - 1]!.end : null;
    let cursor =
      lastKeptEnd && toMinutes(lastKeptEnd) > toMinutes(prefs.startHour)
        ? lastKeptEnd
        : prefs.startHour;

    const plan: { bucket: Bucket; minutes: number; fixedActivity?: string }[] = [];

    // 1) Leitner zuerst — die tägliche Wortschatz-Konstante.
    if (REVIEW_RULES.leitnerEveryDay && dayMinutes >= leitnerMinutes + SESSION_RULES.minMinutes) {
      plan.push({ bucket: "vocabulary", minutes: leitnerMinutes, fixedActivity: "leitner-review" });
      remaining.vocabulary = Math.max(0, remaining.vocabulary - leitnerMinutes);
      dayMinutes -= leitnerMinutes;
    }

    // 2) Wochenrückblick am letzten Lerntag.
    const isLastDay = dayIndex === days.length - 1;
    if (
      REVIEW_RULES.weeklyReview &&
      isLastDay &&
      dayMinutes >= REVIEW_RULES.weeklyReviewMinutes + SESSION_RULES.minMinutes
    ) {
      dayMinutes -= REVIEW_RULES.weeklyReviewMinutes;
    }

    // 3) Restzeit auf Blöcke verteilen, Bucket nach größtem Restbudget.
    const blocks = splitDay(dayMinutes, Math.max(1, blockCount(budget) - plan.length));
    const usedToday = new Set<Bucket>();
    blocks.forEach((minutes) => {
      const order = (Object.keys(remaining) as Bucket[])
        .filter((b) => remaining[b] > 0)
        .sort((a, b) => remaining[b] - remaining[a]);
      const bucket = order.find((b) => !usedToday.has(b)) ?? order[0] ?? "vocabulary";
      usedToday.add(bucket);
      remaining[bucket] = Math.max(0, remaining[bucket] - minutes);
      plan.push({ bucket, minutes });
    });

    if (
      REVIEW_RULES.weeklyReview &&
      isLastDay &&
      budget - keptMinutes >= REVIEW_RULES.weeklyReviewMinutes + SESSION_RULES.minMinutes
    ) {
      plan.push({
        bucket: "vocabulary",
        minutes: REVIEW_RULES.weeklyReviewMinutes,
        fixedActivity: "weekly-review",
      });
    }

    // 4) Terminieren.
    plan.forEach((block, i) => {
      const activity = block.fixedActivity
        ? ACTIVITY_BY_ID[block.fixedActivity]
        : pickActivity(block.bucket, prefs, counter + dayIndex + i);
      if (!activity) return;
      counter += 1;
      const clampedMinutes = Math.max(
        SESSION_RULES.minMinutes,
        Math.min(block.minutes, activity.maxMinutes),
      );
      sessions.push(
        sessionFromActivity(activity, {
          date,
          start: cursor,
          minutes: clampedMinutes,
          level: prefs.level,
          priority: priorityOf(block.bucket, prefs),
        }),
      );
      cursor = addClock(cursor, clampedMinutes);
      if (budget >= SESSION_RULES.breakAfter && i < plan.length - 1) {
        cursor = addClock(cursor, SESSION_RULES.breakMinutes);
      }
    });
  });

  const all = [...keep, ...sessions].sort(
    (a, b) => a.date.localeCompare(b.date) || toMinutes(a.start) - toMinutes(b.start),
  );

  return {
    weekStart,
    targetMinutes: weekly,
    generatedAt: new Date().toISOString(),
    sessions: all,
  };
}

/** Verteilung der geplanten Zeit auf Fertigkeiten. */
export function skillDistribution(
  sessions: PlannerSession[],
): { skill: SkillKey; minutes: number }[] {
  const map = {} as Record<SkillKey, number>;
  SKILL_ORDER.forEach((s) => {
    map[s] = 0;
  });
  sessions.forEach((s) => {
    map[s.skill] = (map[s.skill] ?? 0) + s.minutes;
  });
  return SKILL_ORDER.map((skill) => ({ skill, minutes: map[skill] })).filter((r) => r.minutes > 0);
}
