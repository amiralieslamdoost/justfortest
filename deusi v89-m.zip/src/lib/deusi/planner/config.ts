import type { CefrLevel, GoalKey, Intensity, SkillKey } from "./types";

/**
 * Strategie-Schicht des Planers.
 *
 * Alle Zahlen hier sind bewusst als Konfiguration ausgelagert: Der Planer
 * (engine.ts) liest nur, rechnet und verteilt. Wer die Didaktik ändern will,
 * ändert diese Datei — nicht die Engine.
 */

export const SKILL_LABEL: Record<SkillKey, { de: string; fa: string }> = {
  vocabulary: { de: "Wortschatz", fa: "واژگان" },
  grammar: { de: "Grammatik", fa: "گرامر" },
  listening: { de: "Hören", fa: "شنیدن" },
  speaking: { de: "Sprechen", fa: "صحبت کردن" },
  reading: { de: "Lesen", fa: "خواندن" },
  writing: { de: "Schreiben", fa: "نوشتن" },
};

export const SKILL_ORDER: SkillKey[] = [
  "vocabulary",
  "grammar",
  "listening",
  "speaking",
  "reading",
  "writing",
];

export const GOAL_LABEL: Record<GoalKey, { de: string; fa: string }> = {
  general: { de: "Allgemeines Deutsch", fa: "آلمانی عمومی" },
  migration: { de: "Migration & Alltag", fa: "مهاجرت و زندگی روزمره" },
  university: { de: "Studium", fa: "تحصیل" },
  work: { de: "Beruf", fa: "کار" },
  goethe: { de: "Goethe-Prüfung", fa: "آزمون گوته" },
  testdaf: { de: "TestDaF", fa: "تست‌داف" },
  conversation: { de: "Konversation", fa: "مکالمه" },
  travel: { de: "Reisen", fa: "سفر" },
  personal: { de: "Persönliche Entwicklung", fa: "رشد شخصی" },
  other: { de: "Anderes Ziel", fa: "هدف دیگر" },
};

export const LEVEL_LABEL: Record<CefrLevel, string> = {
  A1: "A1",
  A2: "A2",
  B1: "B1",
  B2: "B2",
  C1: "C1",
  C2: "C2",
  unknown: "Noch unbekannt",
};

/** Basis-Gewichtung pro Stufe (Summe je Zeile ≈ 1). */
export const LEVEL_SKILL_WEIGHTS: Record<CefrLevel, Record<SkillKey, number>> = {
  A1: {
    vocabulary: 0.34,
    grammar: 0.24,
    listening: 0.16,
    speaking: 0.12,
    reading: 0.1,
    writing: 0.04,
  },
  A2: {
    vocabulary: 0.3,
    grammar: 0.24,
    listening: 0.18,
    speaking: 0.13,
    reading: 0.11,
    writing: 0.04,
  },
  B1: {
    vocabulary: 0.24,
    grammar: 0.2,
    listening: 0.2,
    speaking: 0.16,
    reading: 0.14,
    writing: 0.06,
  },
  B2: {
    vocabulary: 0.2,
    grammar: 0.17,
    listening: 0.21,
    speaking: 0.18,
    reading: 0.16,
    writing: 0.08,
  },
  C1: {
    vocabulary: 0.17,
    grammar: 0.13,
    listening: 0.22,
    speaking: 0.2,
    reading: 0.18,
    writing: 0.1,
  },
  C2: {
    vocabulary: 0.15,
    grammar: 0.1,
    listening: 0.23,
    speaking: 0.22,
    reading: 0.2,
    writing: 0.1,
  },
  unknown: {
    vocabulary: 0.3,
    grammar: 0.22,
    listening: 0.18,
    speaking: 0.14,
    reading: 0.12,
    writing: 0.04,
  },
};

/** Ziel-Multiplikatoren: verschiebt die Basis-Gewichtung Richtung Ziel. */
export const GOAL_SKILL_MULTIPLIER: Record<GoalKey, Partial<Record<SkillKey, number>>> = {
  general: {},
  migration: { listening: 1.35, speaking: 1.4, vocabulary: 1.1, writing: 0.8 },
  university: { reading: 1.4, writing: 1.35, grammar: 1.15, speaking: 0.9 },
  work: { speaking: 1.3, writing: 1.2, vocabulary: 1.15, reading: 0.95 },
  goethe: { grammar: 1.3, writing: 1.3, reading: 1.2, listening: 1.15 },
  testdaf: { reading: 1.35, writing: 1.35, listening: 1.25, grammar: 1.1 },
  conversation: { speaking: 1.6, listening: 1.35, grammar: 0.75, writing: 0.6 },
  travel: { speaking: 1.4, listening: 1.25, vocabulary: 1.2, writing: 0.5 },
  personal: { reading: 1.15, listening: 1.15 },
  other: {},
};

/** Verstärkung schwacher bzw. Dämpfung starker Fertigkeiten. */
export const SKILL_FOCUS = {
  weak: 1.6,
  strong: 0.7,
};

/** Intensität: skaliert das Tagesbudget und die Anzahl der Blöcke. */
export const INTENSITY: Record<Intensity, { factor: number; label: string; fa: string }> = {
  light: { factor: 0.8, label: "Entspannt", fa: "آرام" },
  steady: { factor: 1, label: "Konstant", fa: "پیوسته" },
  intense: { factor: 1.2, label: "Intensiv", fa: "فشرده" },
};

/** Session-Design: realistische Blocklängen. */
export const SESSION_RULES = {
  minMinutes: 10,
  maxMinutes: 45,
  /** Auf dieses Raster runden. */
  stepMinutes: 5,
  /** Pause zwischen Blöcken, sobald der Tag mindestens `breakAfter` Minuten hat. */
  breakMinutes: 5,
  breakAfter: 60,
  /** Anzahl Blöcke pro Tag nach Tagesbudget. */
  blocks: [
    { upTo: 20, count: 1 },
    { upTo: 35, count: 2 },
    { upTo: 60, count: 3 },
    { upTo: 90, count: 4 },
    { upTo: Infinity, count: 5 },
  ],
} as const;

/** Wortschatz-Wiederholung (Leitner) — die tägliche Konstante. */
export const REVIEW_RULES = {
  /** Leitner an jedem Lerntag zuerst. */
  leitnerEveryDay: true,
  leitnerMinutes: { light: 10, steady: 15, intense: 20 } as Record<Intensity, number>,
  /** Wochenrückblick am letzten Lerntag der Woche. */
  weeklyReview: true,
  weeklyReviewMinutes: 15,
};

/** Ruhetag-Verhalten. */
export const REST_RULES = {
  /** Wenn alle 7 Tage verfügbar sind, wird dieser Wochentag zum Ruhetag (5 = Freitag). */
  preferredRestDay: 5,
  /** Erst ab so vielen verfügbaren Tagen wird ein Ruhetag vorgeschlagen. */
  minDaysForRest: 6,
};

/** Deadline-Druck: je näher das Ziel, desto stärker Prüfungs-Aktivitäten. */
export const DEADLINE_RULES = {
  /** Innerhalb dieser Tage vor dem Ziel wird Prüfungstraining eingeplant. */
  examFocusDays: 45,
  /** Anteil der Wochenzeit für Prüfungstraining in der Endphase. */
  examShare: 0.2,
};

/** Standard-Profil für neue Lernende. */
export const DEFAULT_PREFS = {
  level: "unknown" as CefrLevel,
  goals: ["general"] as GoalKey[],
  weakSkills: [] as SkillKey[],
  strongSkills: [] as SkillKey[],
  dailyMinutes: 45,
  availableDays: [6, 0, 1, 2, 3, 4],
  startHour: "19:00",
  targetDate: null as string | null,
  intensity: "steady" as Intensity,
  restDays: "auto" as "auto" | "none",
};

export const WEEKDAY_LABEL: { de: string; short: string; fa: string }[] = [
  { de: "Sonntag", short: "So", fa: "یک‌شنبه" },
  { de: "Montag", short: "Mo", fa: "دوشنبه" },
  { de: "Dienstag", short: "Di", fa: "سه‌شنبه" },
  { de: "Mittwoch", short: "Mi", fa: "چهارشنبه" },
  { de: "Donnerstag", short: "Do", fa: "پنج‌شنبه" },
  { de: "Freitag", short: "Fr", fa: "جمعه" },
  { de: "Samstag", short: "Sa", fa: "شنبه" },
];

/** Woche beginnt am Samstag (0 = So … 6 = Sa) — passt zum DEUSI-Publikum. */
export const WEEK_START_DAY = 6;
