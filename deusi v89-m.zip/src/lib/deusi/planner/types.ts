import type { SectionKey } from "@/lib/deusi/sectionTheme";

/** CEFR-Stufe des Lernenden ("unknown" = noch kein Einstufungstest). */
export type CefrLevel = "A1" | "A2" | "B1" | "B2" | "C1" | "C2" | "unknown";

/** Die sechs Fertigkeiten, über die der Planer Zeit verteilt. */
export type SkillKey = "vocabulary" | "grammar" | "listening" | "speaking" | "reading" | "writing";

/** Lernziel des Nutzers — steuert die Gewichtung der Fertigkeiten. */
export type GoalKey =
  | "general"
  | "migration"
  | "university"
  | "work"
  | "goethe"
  | "testdaf"
  | "conversation"
  | "travel"
  | "personal"
  | "other";

export type Intensity = "light" | "steady" | "intense";

export type SessionStatus = "planned" | "done" | "skipped";
export type SessionPriority = "low" | "normal" | "high";

/**
 * Routen, auf die eine Planer-Aktivität zeigen darf.
 * Bewusst als Literal-Union, damit `<Link to={…}>` typsicher bleibt.
 */
export type ActivityHref =
  | "/dashboard"
  | "/leitner"
  | "/learn"
  | "/dictionary"
  | "/verben"
  | "/grammatik"
  | "/schreiben"
  | "/lesen"
  | "/books"
  | "/podcasts"
  | "/musik"
  | "/kino"
  | "/ki-coach"
  | "/pruefungen"
  | "/statistiken"
  | "/community"
  | "/achievements";

/** Katalog-Eintrag: eine echte DEUSI-Aktivität. */
export type ActivityDef = {
  id: string;
  skill: SkillKey;
  /** Quell-Modul in DEUSI (nutzt das bestehende Section-Theme). */
  module: SectionKey;
  category: "practice" | "input" | "review" | "exam" | "speaking";
  titleDe: string;
  titleFa: string;
  descDe: string;
  href: ActivityHref;
  /** Aktions-Label auf der Karte. */
  cta: "Starten" | "Öffnen" | "Fortsetzen" | "Wiederholen";
  minMinutes: number;
  maxMinutes: number;
  /** Nur für diese Stufen anbieten (leer = alle). */
  levels?: CefrLevel[];
  /** Ziel-Bonus: Aktivität passt besonders gut zu diesen Zielen. */
  goals?: GoalKey[];
};

/** Eine geplante Lern-Session im Kalender. */
export type PlannerSession = {
  id: string;
  /** yyyy-mm-dd */
  date: string;
  /** HH:MM */
  start: string;
  /** HH:MM */
  end: string;
  minutes: number;
  activityId: string;
  module: SectionKey;
  skill: SkillKey;
  title: string;
  description: string;
  level: CefrLevel;
  priority: SessionPriority;
  status: SessionStatus;
  href: ActivityHref;
  cta: ActivityDef["cta"];
  /** Optionale Verknüpfung zu konkretem Inhalt (Artikel, Episode …). */
  resourceId?: string;
  /** Von DEUSI generiert (false = vom Nutzer selbst angelegt). */
  generated: boolean;
  /** Vom Nutzer manuell verändert — wird beim Regenerieren geschützt. */
  edited: boolean;
  createdAt: string;
  updatedAt: string;
};

/** Metadaten einer Woche. */
export type PlannerWeekMeta = {
  weekStart: string;
  targetMinutes: number;
  generatedAt: string | null;
};

export type PlannerWeek = PlannerWeekMeta & { sessions: PlannerSession[] };

/** Planungs-Profil des Lernenden. */
export type PlannerPrefs = {
  level: CefrLevel;
  goals: GoalKey[];
  weakSkills: SkillKey[];
  strongSkills: SkillKey[];
  /** Minuten pro Lerntag. */
  dailyMinutes: number;
  /** Wochentage 0 = Sonntag … 6 = Samstag. */
  availableDays: number[];
  /** Bevorzugter Startzeitpunkt, HH:MM. */
  startHour: string;
  /** ISO-Datum der Prüfung / des Ziels. */
  targetDate: string | null;
  intensity: Intensity;
  /** "auto" = DEUSI darf einen Ruhetag einplanen. */
  restDays: "auto" | "none";
  updatedAt: string;
};
