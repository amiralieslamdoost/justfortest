import { useCallback, useMemo, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import {
  usePlannerMutations,
  usePlannerPlanQuery,
  usePlannerWeekQuery,
  usePlannerLogsQuery,
  usePlannerRealtimeSync,
  useDueVocabCount,
} from "@/lib/api/usePlanner";
import { ACTIVITY_BY_ID, FALLBACK_ACTIVITY } from "./activities";
import { addClock, todayISO, weekStartOf } from "./date";
import { generateWeek, newSessionId, sessionFromActivity, skillDistribution } from "./engine";
import { normalizePrefs, sortSessions } from "./storage";
import type {
  ActivityDef,
  PlannerPrefs,
  PlannerSession,
  PlannerWeek,
  SessionStatus,
  SkillKey,
} from "./types";

/**
 * Zentraler Planer-Hook.
 *
 * Lädt Profil und Woche über die Datenschicht (`@/lib/api/planner`:
 * PocketBase, sonst Offline-Spiegel), erzeugt bei Bedarf einen Plan und
 * stellt alle Bearbeitungs-Aktionen bereit. Die UI kennt weder Persistenz
 * noch Engine.
 */

export type PlannerStatus = "loading" | "onboarding" | "ready" | "anonymous";

export function usePlanner(initialWeek?: string) {
  const { currentUser, hydrated } = useDeusi();
  const userId = currentUser?.id ?? "";

  const [weekStart, setWeekStart] = useState(() => weekStartOf(initialWeek ?? todayISO()));
  const [localError, setLocalError] = useState<string | null>(null);

  usePlannerRealtimeSync(userId);

  const planQuery = usePlannerPlanQuery(userId, hydrated);
  const weekQuery = usePlannerWeekQuery(userId, weekStart, hydrated);
  const mutations = usePlannerMutations(userId, weekStart);
  const { dueCount: dueVocabCount } = useDueVocabCount(userId);
  const { logs, summary: logSummary } = usePlannerLogsQuery(userId, weekStart, hydrated);

  const prefs = planQuery.data ?? null;
  const week = weekQuery.data ?? null;
  const loading = !hydrated || (Boolean(userId) && (planQuery.isLoading || weekQuery.isLoading));

  const status: PlannerStatus =
    !hydrated || loading ? "loading" : !userId ? "anonymous" : !prefs ? "onboarding" : "ready";

  const error =
    localError ??
    (planQuery.error || weekQuery.error
      ? "Der Plan konnte nicht geladen werden."
      : mutations.error
        ? "Änderungen konnten nicht gespeichert werden."
        : null);

  /* ---------------------------------------------------------- Speichern */

  const persistWeek = useCallback(
    async (next: PlannerWeek) => {
      mutations.setWeekCache(next);
      try {
        await mutations.saveWeek(next);
        setLocalError(null);
      } catch (err) {
        console.error("[planner] save week failed", err);
        setLocalError("Änderungen konnten nicht gespeichert werden.");
      }
    },
    [mutations],
  );

  const persistSession = useCallback(
    async (session: PlannerSession) => {
      try {
        await mutations.putSession(session);
      } catch (err) {
        console.error("[planner] save session failed", err);
        setLocalError("Die Session konnte nicht gespeichert werden.");
      }
    },
    [mutations],
  );

  /* ------------------------------------------------------------ Aktionen */

  /** Profil speichern und Woche neu planen. */
  const savePrefs = useCallback(
    async (input: Partial<PlannerPrefs>) => {
      const next = normalizePrefs({
        ...(prefs ?? {}),
        ...input,
        updatedAt: new Date().toISOString(),
      });
      await mutations.savePrefs(next);
      const keep = (week?.sessions ?? []).filter((s) => !s.generated || s.status === "done");
      await persistWeek(generateWeek(next, weekStart, { keep }));
      return next;
    },
    [mutations, persistWeek, prefs, week, weekStart],
  );

  /**
   * Woche neu erzeugen.
   * `mode: "keep-edits"` schützt manuell veränderte, eigene und erledigte Sessions.
   */
  const regenerate = useCallback(
    async (mode: "keep-edits" | "fresh" = "keep-edits") => {
      if (!prefs) return;
      const keep =
        mode === "fresh"
          ? []
          : (week?.sessions ?? []).filter((s) => s.edited || !s.generated || s.status === "done");
      await persistWeek(generateWeek(prefs, weekStart, { keep }));
    },
    [persistWeek, prefs, week, weekStart],
  );

  const updateSession = useCallback(
    async (
      id: string,
      patch: Partial<PlannerSession>,
      /** Zusatzdaten fürs Session-Log (z. B. Anzahl wiederholter Karten). */
      result?: { itemsDone?: number; accuracy?: number; minutes?: number },
    ) => {
      if (!week) return;
      let updated: PlannerSession | null = null;
      const sessions = week.sessions.map((s) => {
        if (s.id !== id) return s;
        const minutes = patch.minutes ?? s.minutes;
        const start = patch.start ?? s.start;
        updated = {
          ...s,
          ...patch,
          minutes,
          start,
          end: patch.end ?? addClock(start, minutes),
          edited: true,
          updatedAt: new Date().toISOString(),
        };
        return updated;
      });
      await persistWeek({ ...week, sessions: sortSessions(sessions) });
      if (updated) {
        const saved: PlannerSession = updated;
        await persistSession(saved);
        // Erledigte Blöcke landen als Log auf dem Server (Basis für die Statistik).
        if (patch.status === "done") {
          try {
            await mutations.logSession({
              sessionId: saved.id,
              skill: saved.skill,
              minutes: result?.minutes ?? saved.minutes,
              itemsDone: result?.itemsDone,
              accuracy: result?.accuracy,
              startedAt: `${saved.date}T${saved.start}:00`,
              endedAt: new Date().toISOString(),
              meta: { activityId: saved.activityId, module: saved.module },
            });
          } catch (err) {
            console.warn("[planner] session log deferred", err);
          }
        }
      }
    },
    [mutations, persistSession, persistWeek, week],
  );

  const setSessionStatus = useCallback(
    (id: string, status: SessionStatus) => updateSession(id, { status }),
    [updateSession],
  );

  /**
   * Wortschatz-Block abschließen: Der Block gilt als erledigt und die Anzahl
   * der wiederholten FSRS-/Leitner-Karten landet im Session-Log.
   */
  const completeVocabSession = useCallback(
    (id: string, itemsDone: number) => updateSession(id, { status: "done" }, { itemsDone }),
    [updateSession],
  );

  /** Session auf einen anderen Tag / eine andere Zeit legen. */
  const moveSession = useCallback(
    (id: string, date: string, start?: string) =>
      updateSession(id, { date, ...(start ? { start } : {}) }),
    [updateSession],
  );

  const removeSession = useCallback(
    async (id: string) => {
      if (!week) return;
      await persistWeek({ ...week, sessions: week.sessions.filter((s) => s.id !== id) });
      try {
        await mutations.deleteSession(id);
      } catch (err) {
        console.error("[planner] delete session failed", err);
        setLocalError("Die Session konnte nicht gelöscht werden.");
      }
    },
    [mutations, persistWeek, week],
  );

  /** Komplett freie, selbst formulierte Lerneinheit (nicht aus dem Katalog). */
  const addCustomSession = useCallback(
    async (input: {
      title: string;
      description?: string;
      skill: SkillKey;
      date: string;
      start: string;
      minutes: number;
    }) => {
      const now = new Date().toISOString();
      const session: PlannerSession = {
        id: newSessionId(),
        date: input.date,
        start: input.start,
        end: addClock(input.start, input.minutes),
        minutes: input.minutes,
        activityId: "custom",
        module: "planner",
        skill: input.skill,
        title: input.title.trim() || "Eigene Lerneinheit",
        description: (input.description ?? "").trim(),
        level: prefs?.level ?? "unknown",
        priority: "normal",
        status: "planned",
        href: "/dashboard",
        cta: "Öffnen",
        generated: false,
        edited: true,
        createdAt: now,
        updatedAt: now,
      };
      const base: PlannerWeek = week ?? {
        weekStart,
        targetMinutes: 0,
        generatedAt: null,
        sessions: [],
      };
      await persistWeek({
        ...base,
        sessions: sortSessions([...base.sessions, session]),
      });
      await persistSession(session);
      return session;
    },
    [persistSession, persistWeek, prefs, week, weekStart],
  );

  const addSession = useCallback(
    async (input: { activityId: string; date: string; start: string; minutes: number }) => {
      const activity: ActivityDef = ACTIVITY_BY_ID[input.activityId] ?? FALLBACK_ACTIVITY;
      const session = {
        ...sessionFromActivity(activity, {
          date: input.date,
          start: input.start,
          minutes: input.minutes,
          level: prefs?.level ?? "unknown",
          generated: false,
        }),
        generated: false,
      };
      const base: PlannerWeek = week ?? {
        weekStart,
        targetMinutes: 0,
        generatedAt: null,
        sessions: [],
      };
      await persistWeek({
        ...base,
        sessions: sortSessions([...base.sessions, session]),
      });
      await persistSession(session);
      return session;
    },
    [persistSession, persistWeek, prefs, week, weekStart],
  );

  const goToWeek = useCallback((next: string) => setWeekStart(weekStartOf(next)), []);

  /* ------------------------------------------------------------ Ableitungen */

  const sessions = useMemo(() => week?.sessions ?? [], [week]);

  const stats = useMemo(() => {
    const planned = sessions.reduce((a, s) => a + s.minutes, 0);
    const done = sessions.filter((s) => s.status === "done");
    const doneMinutes = done.reduce((a, s) => a + s.minutes, 0);
    return {
      plannedMinutes: planned,
      doneMinutes,
      doneCount: done.length,
      totalCount: sessions.length,
      skippedCount: sessions.filter((s) => s.status === "skipped").length,
      progress: planned ? Math.round((doneMinutes / planned) * 100) : 0,
      distribution: skillDistribution(sessions),
    };
  }, [sessions]);

  const today = todayISO();
  const todaySessions = useMemo(() => sessions.filter((s) => s.date === today), [sessions, today]);
  const nextSession = useMemo(
    () => todaySessions.find((s) => s.status === "planned") ?? null,
    [todaySessions],
  );

  return {
    status,
    loading,
    busy: mutations.busy,
    error,
    prefs,
    week,
    weekStart,
    sessions,
    stats,
    today,
    todaySessions,
    nextSession,
    /** Fällige FSRS-/Leitner-Karten für Wortschatz-Blöcke. */
    dueVocabCount,
    /** Protokoll der erledigten Blöcke dieser Woche (geräteübergreifend). */
    logs,
    logSummary,
    goToWeek,
    savePrefs,
    regenerate,
    updateSession,
    setSessionStatus,
    completeVocabSession,
    moveSession,
    removeSession,
    addSession,
    addCustomSession,
  };
}

export type PlannerApi = ReturnType<typeof usePlanner>;
