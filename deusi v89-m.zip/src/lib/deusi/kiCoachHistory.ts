export type CoachRole = "user" | "ai";
export type CoachMsg = { id: string; role: CoachRole; text: string; time: string };
export type CoachThread = {
  id: string;
  title: string;
  updatedAt: number;
  messages: CoachMsg[];
};

const KEY = "deusi.kiCoach.threads.v1";

export function nowTime() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export function newId() {
  return Math.random().toString(36).slice(2, 10);
}

export function loadThreads(): CoachThread[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as CoachThread[];
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((t) => t && typeof t.id === "string" && Array.isArray(t.messages))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  } catch {
    return [];
  }
}

export function saveThreads(threads: CoachThread[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(threads.slice(0, 50)));
  } catch {
    /* storage full or blocked */
  }
}

export function makeThread(greeting: string): CoachThread {
  return {
    id: newId(),
    title: "Neuer Chat",
    updatedAt: Date.now(),
    messages: [{ id: "m" + newId(), role: "ai", text: greeting, time: nowTime() }],
  };
}

export function titleFrom(text: string) {
  const t = text.trim().replace(/\s+/g, " ");
  return t.length > 38 ? t.slice(0, 38) + "…" : t || "Neuer Chat";
}

export function relativeDay(ts: number) {
  const d = new Date(ts);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  if (sameDay) return "Heute";
  const yest = new Date(today.getTime() - 86400000);
  if (d.toDateString() === yest.toDateString()) return "Gestern";
  return d.toLocaleDateString("de-DE", { day: "2-digit", month: "short" });
}
