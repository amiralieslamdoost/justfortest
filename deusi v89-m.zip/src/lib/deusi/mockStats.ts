// ---------------------------------------------------------------------------
// DEUSI — Mock statistics data.
//
// A realistic snapshot for a learner who has been studying German for
// ~5 months, currently around A2 and progressing toward B1. All data
// generated deterministically so charts stay stable across renders.
//
// Every export is a plain, serializable value so the file can later be
// replaced by a `fetchStats()` server function that returns the same
// shape from Supabase / Firebase / any REST API.
// ---------------------------------------------------------------------------

export type CEFRLevel = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type SkillKey = "wortschatz" | "grammatik" | "hoeren" | "lesen" | "sprechen" | "schreiben";

export interface DailySession {
  date: string; // ISO yyyy-mm-dd
  minutes: number; // total study minutes on that day
  xp: number;
  wordsLearned: number;
  reviews: number; // Leitner / FSRS reviews completed
  lessons: number;
}

export interface WeeklyPoint {
  label: string; // Mo, Di, ...
  minutes: number;
}

export interface MonthPoint {
  label: string; // Dez, Jan, ...
  minutes: number;
  xp: number;
  words: number;
}

export interface GrammarTopic {
  name: string;
  mastery: number; // 0-100
  color: string;
}

export interface CEFRPoint {
  date: string; // ISO
  level: CEFRLevel;
  score: number; // 0-100 within level
}

export interface LeitnerBucket {
  box: number; // 1..5
  label: string;
  cards: number;
  color: string;
}

export interface PronunciationScore {
  phoneme: string;
  score: number; // 0-100
}

export interface AIInsight {
  id: string;
  icon: string;
  title: string;
  body: string;
  tone: "success" | "info" | "warning";
}

export interface Prediction {
  level: CEFRLevel;
  weeks: number;
  eta: string; // "23. Aug. 2026"
  progress: number; // 0-100 progress toward that level
}

// ---------------------------------------------------------------------------
// Deterministic pseudo-random helpers
// ---------------------------------------------------------------------------

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(20260711);

function isoDay(d: Date) {
  return d.toISOString().slice(0, 10);
}

// ---------------------------------------------------------------------------
// Learner profile
// ---------------------------------------------------------------------------

export const learnerProfile = {
  name: "Max Mustermann",
  currentLevel: "A2" as CEFRLevel,
  levelName: "Grundlagen",
  levelProgress: 72, // % toward next level
  totalXP: 12480,
  streak: 27, // current daily streak
  longestStreak: 41,
  dailyGoalMinutes: 45,
  dailyDoneMinutes: 38,
  weeklyMinutes: 765, // 12h 45m
  weeklyMinutesDelta: 135, // +2h 15m vs. last week
  wordsLearned: 1245,
  wordsLearnedDelta: 38,
  lessonsCompleted: 87,
  lessonsCompletedDelta: 4,
  xpThisWeek: 3240,
  xpThisWeekDelta: 680,
  totalStudyHours: 148,
  reviewsThisWeek: 412,
  activeDays: 152,
};

// ---------------------------------------------------------------------------
// Time series — 180 days of daily sessions (approx. 6 months)
// ---------------------------------------------------------------------------

export const dailySessions: DailySession[] = (() => {
  const out: DailySession[] = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (let i = 179; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const weekday = d.getDay(); // 0 Sun … 6 Sat

    // Weekend dip, mid-week peak, growing trend.
    const base = 25 + (180 - i) * 0.18;
    const weekendPenalty = weekday === 0 || weekday === 6 ? -10 : 0;
    const midWeekBoost = weekday === 3 || weekday === 4 ? 12 : 0;
    const noise = (rand() - 0.5) * 22;
    const skipDay = rand() < 0.08 ? true : false; // ~8% missed days
    const minutes = skipDay
      ? 0
      : Math.max(5, Math.round(base + weekendPenalty + midWeekBoost + noise));

    const xp = Math.round(minutes * (2.4 + rand() * 0.6));
    const wordsLearned = minutes === 0 ? 0 : Math.max(1, Math.round(minutes * 0.28 + rand() * 3));
    const reviews = minutes === 0 ? 0 : Math.round(minutes * 1.4 + rand() * 6);
    const lessons = minutes === 0 ? 0 : Math.random() < 0.55 ? 1 : 0;

    out.push({
      date: isoDay(d),
      minutes,
      xp,
      wordsLearned,
      reviews,
      lessons,
    });
  }
  return out;
})();

// ---------------------------------------------------------------------------
// Weekly view — last 7 days
// ---------------------------------------------------------------------------

const WEEKDAYS_DE = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];

export const weeklyActivity: WeeklyPoint[] = (() => {
  const last7 = dailySessions.slice(-7);
  return last7.map((s) => {
    const day = new Date(s.date).getDay();
    return { label: WEEKDAYS_DE[day], minutes: s.minutes };
  });
})();

// ---------------------------------------------------------------------------
// Monthly aggregates — last 6 months
// ---------------------------------------------------------------------------

const MONTHS_DE = [
  "Jan",
  "Feb",
  "Mär",
  "Apr",
  "Mai",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Okt",
  "Nov",
  "Dez",
];

export const monthlyActivity: MonthPoint[] = (() => {
  const buckets = new Map<string, MonthPoint>();
  for (const s of dailySessions) {
    const d = new Date(s.date);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    const label = MONTHS_DE[d.getMonth()];
    const cur = buckets.get(key) ?? { label, minutes: 0, xp: 0, words: 0 };
    cur.minutes += s.minutes;
    cur.xp += s.xp;
    cur.words += s.wordsLearned;
    buckets.set(key, cur);
  }
  return Array.from(buckets.values());
})();

// ---------------------------------------------------------------------------
// Vocabulary growth — cumulative words over the last 6 months
// ---------------------------------------------------------------------------

export const vocabularyGrowth = (() => {
  let total = learnerProfile.wordsLearned - dailySessions.reduce((s, x) => s + x.wordsLearned, 0);
  if (total < 0) total = 0;
  return dailySessions.map((s) => {
    total += s.wordsLearned;
    return { date: s.date, total };
  });
})();

// ---------------------------------------------------------------------------
// Skill distribution — the ring/donut on the top right
// ---------------------------------------------------------------------------

export const skillDistribution: { key: SkillKey; label: string; value: number; color: string }[] = [
  { key: "wortschatz", label: "Wörter", value: 72, color: "#EF4444" },
  { key: "grammatik", label: "Grammatik", value: 65, color: "#60A5FA" },
  { key: "hoeren", label: "Hören", value: 60, color: "#3B82F6" },
  { key: "lesen", label: "Lesen", value: 70, color: "#F59E0B" },
  { key: "sprechen", label: "Sprechen", value: 55, color: "#F97316" },
  { key: "schreiben", label: "Schreiben", value: 50, color: "#FBBF24" },
];

export const overallProgress = Math.round(
  skillDistribution.reduce((s, x) => s + x.value, 0) / skillDistribution.length,
);

// ---------------------------------------------------------------------------
// Grammar topics
// ---------------------------------------------------------------------------

export const grammarTopics: GrammarTopic[] = [
  { name: "Präsens", mastery: 92, color: "#22C55E" },
  { name: "Präteritum", mastery: 78, color: "#84CC16" },
  { name: "Perfekt", mastery: 66, color: "#F7C948" },
  { name: "Konjunktiv II", mastery: 45, color: "#F59E0B" },
  { name: "Passiv", mastery: 37, color: "#F97316" },
  { name: "Relativsätze", mastery: 31, color: "#EF4444" },
  { name: "Präpositionen", mastery: 58, color: "#8B5CF6" },
];

// ---------------------------------------------------------------------------
// CEFR progression
// ---------------------------------------------------------------------------

export const cefrHistory: CEFRPoint[] = [
  { date: "2026-02-10", level: "A1", score: 20 },
  { date: "2026-02-28", level: "A1", score: 55 },
  { date: "2026-03-20", level: "A1", score: 88 },
  { date: "2026-04-05", level: "A2", score: 18 },
  { date: "2026-04-25", level: "A2", score: 42 },
  { date: "2026-05-18", level: "A2", score: 58 },
  { date: "2026-06-08", level: "A2", score: 65 },
  { date: "2026-07-11", level: "A2", score: 72 },
];

export const predictions: Prediction[] = [
  { level: "B1", weeks: 14, eta: "23. Aug. 2026", progress: 72 },
  { level: "B2", weeks: 34, eta: "20. Dez. 2026", progress: 28 },
];

// ---------------------------------------------------------------------------
// Leitner box distribution
// ---------------------------------------------------------------------------

export const leitnerBoxes: LeitnerBucket[] = [
  { box: 1, label: "Neu", cards: 128, color: "#EF4444" },
  { box: 2, label: "Lernend", cards: 214, color: "#F97316" },
  { box: 3, label: "Vertraut", cards: 352, color: "#F7C948" },
  { box: 4, label: "Gefestigt", cards: 386, color: "#84CC16" },
  { box: 5, label: "Beherrscht", cards: 165, color: "#22C55E" },
];

// ---------------------------------------------------------------------------
// Pronunciation
// ---------------------------------------------------------------------------

export const pronunciationScores: PronunciationScore[] = [
  { phoneme: "ä", score: 82 },
  { phoneme: "ö", score: 74 },
  { phoneme: "ü", score: 68 },
  { phoneme: "ch", score: 55 },
  { phoneme: "r", score: 61 },
  { phoneme: "sch", score: 88 },
  { phoneme: "z", score: 79 },
  { phoneme: "st", score: 84 },
];

export const pronunciationOverall = Math.round(
  pronunciationScores.reduce((s, p) => s + p.score, 0) / pronunciationScores.length,
);

// ---------------------------------------------------------------------------
// Streak history (last 12 weeks) — 0..7 active days
// ---------------------------------------------------------------------------

export const streakHistory: { week: string; activeDays: number }[] = (() => {
  const out: { week: string; activeDays: number }[] = [];
  const chunks: DailySession[][] = [];
  for (let i = dailySessions.length - 84; i < dailySessions.length; i += 7) {
    chunks.push(dailySessions.slice(Math.max(0, i), i + 7));
  }
  chunks.forEach((week, idx) => {
    const active = week.filter((d) => d.minutes > 0).length;
    out.push({ week: `KW ${idx + 1}`, activeDays: active });
  });
  return out;
})();

// ---------------------------------------------------------------------------
// Heatmap — vocabulary practice intensity, last 6 months by weekday
// ---------------------------------------------------------------------------

export const vocabularyHeatmap: number[][] = (() => {
  // 7 rows (Mo..So) × 26 cols (weeks).
  const rows: number[][] = Array.from({ length: 7 }, () => []);
  const weeks = 26;
  for (let w = 0; w < weeks; w++) {
    for (let day = 0; day < 7; day++) {
      const trend = w / weeks; // grow over time
      const dayBias = day < 5 ? 1 : 0.55; // weekend dip
      const raw = trend * 0.85 * dayBias + rand() * 0.35;
      rows[day].push(Math.min(1, Math.max(0, raw)));
    }
  }
  return rows;
})();

// ---------------------------------------------------------------------------
// Strengths & weaknesses
// ---------------------------------------------------------------------------

export const strengths = [
  { label: "Wortschatz", value: 72, tone: "good" as const },
  { label: "Lesen", value: 70, tone: "good" as const },
];

export const weaknesses = [
  { label: "Sprechen", value: 55, tone: "bad" as const },
  { label: "Schreiben", value: 50, tone: "bad" as const },
];

// ---------------------------------------------------------------------------
// AI insights
// ---------------------------------------------------------------------------

export const aiInsights: AIInsight[] = [
  {
    id: "consistency",
    icon: "⚡",
    title: "Super konstant!",
    body: "Du bist 20 % aktiver als letzte Woche. Halte dieses Tempo, um dein B1-Ziel zu erreichen.",
    tone: "success",
  },
  {
    id: "vocab",
    icon: "⭐",
    title: "Wiederhole schwierige Wörter",
    body: "12 Karten aus Box 2 sind fällig. Kurze Wiederholungssessions helfen dir, sie langfristig zu behalten.",
    tone: "info",
  },
  {
    id: "listening",
    icon: "🎧",
    title: "Hörübungen empfohlen",
    body: "Dein Hörverstehen liegt bei 60 %. Zwei kurze Podcasts pro Woche könnten es auf 70 % heben.",
    tone: "warning",
  },
];

// ---------------------------------------------------------------------------
// Date-range presets shown in the header
// ---------------------------------------------------------------------------

export const dateRanges = [
  { key: "7d", label: "Letzte 7 Tage" },
  { key: "4w", label: "Letzte 4 Wochen" },
  { key: "6m", label: "Letzte 6 Monate" },
  { key: "1y", label: "Letztes Jahr" },
] as const;

export type DateRangeKey = (typeof dateRanges)[number]["key"];
