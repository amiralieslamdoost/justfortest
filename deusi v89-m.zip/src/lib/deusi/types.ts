export type POS = "noun" | "verb" | "adjective" | "preposition";

export interface BaseWord {
  id: string;
  pos: POS;
  translation: string; // Persian
  example?: string;
  createdBy?: string; // user id or "system"
}

export interface NounWord extends BaseWord {
  pos: "noun";
  article: "der" | "die" | "das";
  singular: string;
  plural: string;
  pluralSuffix?: string;
}

export interface VerbWord extends BaseWord {
  pos: "verb";
  infinitive: string;
  praeteritum: string;
  perfekt: string; // e.g. "hat gemacht" / "ist gegangen"
  aux: "haben" | "sein";
  /** Fixed preposition governed by this verb, with the required case (e.g. warten + auf + Akk) */
  governedPreposition?: { text: string; case: "Akk" | "Dat" | "Gen" };
  praesens: { ich: string; du: string; er: string; wir: string; ihr: string; sie: string };
  praeteritumConj: { ich: string; du: string; er: string; wir: string; ihr: string; sie: string };
  perfektConj: { ich: string; du: string; er: string; wir: string; ihr: string; sie: string };
}

export interface AdjectiveWord extends BaseWord {
  pos: "adjective";
  positive: string;
  comparative: string;
  superlative: string;
  antonym?: string;
  antonymComparative?: string;
  antonymSuperlative?: string;
  antonymTranslation?: string;
}

export interface PrepositionWord extends BaseWord {
  pos: "preposition";
  preposition: string;
  cases: Array<"Akk" | "Dat">; // one or both
}

export type Word = NounWord | VerbWord | AdjectiveWord | PrepositionWord;

export interface DeckCard {
  wordId: string;
  box: 1 | 2 | 3 | 4 | 5;
  due: number; // timestamp
  reps: number;
  lapses: number;
  ease: number;
  interval: number; // days
}

export interface User {
  id: string;
  username: string;
  email: string;
  password: string; // mock only
  createdAt: number;
  streak: number;
  lastStudy: number | null;
  deck: DeckCard[];
  customWords: Word[];
}
