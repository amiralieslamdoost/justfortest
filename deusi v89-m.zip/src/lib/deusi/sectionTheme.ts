import type { ComponentType, SVGProps } from "react";
import { FlashcardsIcon } from "@/components/deusi/icons/SectionIcons";
import {
  HomeIcon,
  BookIcon,
  SparkleIcon,
  GrammarNavIcon,
  BoxIcon,
  ReadIcon,
  HeadphoneIcon,
  MusicNoteIcon,
  FilmIcon,
  ChartIcon,
  ExamIcon,
  UserIcon,
  CalendarIcon,
  PencilIcon,
  WordFamilyIcon,
  ChatIcon,
  TrophyIcon,
} from "@/components/deusi/icons/NavIcons";

export type SectionKey =
  | "dashboard"
  | "planner"
  | "dictionary"
  | "ai-coach"
  | "grammar"
  | "flashcards"
  | "leitner"
  | "reading"
  | "podcasts"
  | "music"
  | "movies"
  | "statistics"
  | "exams"
  | "profile"
  | "events"
  | "writing"
  | "verbs"
  | "community"
  | "achievements";

export type SectionTheme = {
  key: SectionKey;
  label: string;
  labelFa: string;
  /** German H1 default */
  titleDe: string;
  /** Farsi hint under H1 */
  titleFa: string;
  /** German paragraph default */
  descDe: string;
  descFa: string;
  /** Portion of the H1 that gets the light gradient span */
  highlight?: string;
  /** Deep base color used for the header's dark corner */
  base: string;
  /** Middle/brand color */
  primary: string;
  /** Bright accent for the second gradient stop and blurred blob */
  accent: string;
  Icon: ComponentType<SVGProps<SVGSVGElement> & { size?: number }>;
};

export const SECTION_THEME: Record<SectionKey, SectionTheme> = {
  dashboard: {
    key: "dashboard",
    label: "Dashboard",
    labelFa: "داشبورد",
    titleDe: "Willkommen zurück",
    titleFa: "بازگشتت خوش",
    descDe: "Dein Lernüberblick, alle wichtigen Aktionen an einem Ort.",
    descFa: "نمای کلی یادگیری‌ات، همه‌ی اکشن‌های مهم در یک صفحه.",
    highlight: "zurück",
    base: "#4c1d95",
    primary: "#7c3aed",
    accent: "#a5b4fc",

    Icon: HomeIcon,
  },
  planner: {
    key: "planner",
    label: "Planer",
    labelFa: "برنامه‌ریز",
    titleDe: "Dein Smart Planner",
    titleFa: "برنامه‌ریز هوشمند تو",
    descDe:
      "Ein Wochenplan, der zu deinem Niveau, deinen Zielen und deiner Zeit passt — Tag für Tag.",
    descFa: "برنامه‌ی هفتگی متناسب با سطح، هدف و زمان تو — روز به روز.",
    highlight: "Smart Planner",
    base: "#0b1f3a",
    primary: "#1d4ed8",
    accent: "#7dd3fc",
    Icon: CalendarIcon,
  },
  dictionary: {
    key: "dictionary",
    label: "Wörterbuch",
    labelFa: "دیکشنری",
    titleDe: "Baue deinen Wortschatz",
    titleFa: "دایره‌ی واژگانت را بساز",
    descDe: "Neue Wörter entdecken, speichern und im Kontext verstehen.",
    descFa: "کلمه‌های تازه را کشف کن، ذخیره کن و در بستر واقعی یاد بگیر.",
    highlight: "Wortschatz",
    base: "#160530",
    primary: "#3a1080",
    accent: "#7c3bff",
    Icon: BookIcon,
  },
  "ai-coach": {
    key: "ai-coach",
    label: "AI Coach",
    labelFa: "مربی هوش مصنوعی",
    titleDe: "Dein persönlicher Sprachcoach",
    titleFa: "مربی زبان شخصی تو",
    descDe: "Frag alles rund um Deutsch — Grammatik, Wortschatz, Aussprache.",
    descFa: "هرچی درباره‌ی آلمانی می‌خواستی بپرس — گرامر، واژه، تلفظ.",
    highlight: "Sprachcoach",
    base: "#02332f",
    primary: "#0a746b",
    accent: "#2adfd2",
    Icon: SparkleIcon,
  },
  grammar: {
    key: "grammar",
    label: "Grammatik",
    labelFa: "گرامر",
    titleDe: "Verstehe die Regeln",
    titleFa: "قواعد را بفهم و درست بنویس",
    descDe: "Klare Erklärungen, saubere Beispiele, Schritt für Schritt zum Ziel.",
    descFa: "توضیح‌های شفاف، مثال‌های تمیز، گام‌به‌گام تا هدف.",
    highlight: "Regeln",
    base: "#0a1547",
    primary: "#1b3fbf",
    accent: "#4d8cff",
    Icon: GrammarNavIcon,
  },
  flashcards: {
    key: "flashcards",
    label: "Flashcards",
    labelFa: "فلش‌کارت‌ها",
    titleDe: "Wörter, die wirklich bleiben",
    titleFa: "کلمه‌هایی که واقعاً می‌مانند",
    descDe: "Aktives Erinnern in kurzen Runden — genau richtig für jeden Tag.",
    descFa: "یادآوری فعال در نوبت‌های کوتاه — دقیقاً اندازه‌ی هر روز.",
    highlight: "bleiben",
    base: "#3d0a2a",
    primary: "#b21f66",
    accent: "#ff5aa1",
    Icon: FlashcardsIcon,
  },
  leitner: {
    key: "leitner",
    label: "Leitner",
    labelFa: "لایتنر",
    titleDe: "Intelligentes Wiederholen",
    titleFa: "مرور هوشمند برای ماندگاری بلندمدت",
    descDe: "Das richtige Wort zur richtigen Zeit — dein Gedächtnis wird es dir danken.",
    descFa: "کلمه‌ی درست در زمان درست — حافظه‌ات ازت تشکر می‌کند.",
    highlight: "Wiederholen",
    base: "#04321a",
    primary: "#128a3c",
    accent: "#4be27a",
    Icon: BoxIcon,
  },
  reading: {
    key: "reading",
    label: "Lesen",
    labelFa: "خواندن",
    titleDe: "Lies. Verstehe. Wachse.",
    titleFa: "بخوان، بفهم، رشد کن.",
    descDe: "Kurze Texte, echte Themen, spürbarer Fortschritt.",
    descFa: "متن‌های کوتاه، موضوع‌های واقعی، پیشرفت محسوس.",
    highlight: "Wachse",
    base: "#1e2a05",
    primary: "#5c7a1c",
    accent: "#b3d34a",
    Icon: ReadIcon,
  },
  podcasts: {
    key: "podcasts",
    label: "Podcasts",
    labelFa: "پادکست",
    titleDe: "Deutsch im echten Kontext",
    titleFa: "پادکست — آلمانی در بستر واقعی",
    descDe:
      "Höre echte Gespräche, verbessere dein Hörverständnis und tauche in die deutsche Kultur ein.",
    descFa: "به گفتگوهای واقعی گوش بده، درک شنیداری‌ات را قوی کن و در فرهنگ آلمانی غرق شو.",
    highlight: "echten Kontext",
    base: "#2a0714",
    primary: "#9e1b3a",
    accent: "#ff6b8a",
    Icon: HeadphoneIcon,
  },
  music: {
    key: "music",
    label: "Musik",
    labelFa: "موزیک",
    titleDe: "Deutsch lernen mit Musik",
    titleFa: "با موزیک آلمانی یاد بگیر",
    descDe:
      "Songtexte mitlesen, Wörter speichern und dein Hörverständnis Zeile für Zeile trainieren.",
    descFa: "متن آهنگ را همراه بخوان، واژه‌ها را ذخیره کن و درک شنیداری‌ات را خط‌به‌خط تقویت کن.",
    highlight: "Musik",
    base: "#04162f",
    primary: "#1552c8",
    accent: "#38bdf8",
    Icon: MusicNoteIcon,
  },
  movies: {
    key: "movies",
    label: "Kino",
    labelFa: "فیلم",
    titleDe: "Deutsch lernen mit echten Filmen",
    titleFa: "با فیلم‌های واقعی آلمانی یاد بگیر",
    descDe: "Szenen, Dialoge und Kultur — Lernen wie ein Kinoabend.",
    descFa: "صحنه، دیالوگ و فرهنگ — یادگیری مثل یک شب سینما.",
    highlight: "echten Filmen",
    base: "#3d0f05",
    primary: "#c73a1c",
    accent: "#ff8560",
    Icon: FilmIcon,
  },
  statistics: {
    key: "statistics",
    label: "Statistiken",
    labelFa: "آمار",
    titleDe: "Dein Fortschritt auf einen Blick",
    titleFa: "پیشرفتت در یک نگاه",
    descDe: "Sichtbare Erfolge, klare Muster, motivierende Ziele.",
    descFa: "موفقیت‌های محسوس، الگوهای شفاف، اهداف انگیزه‌بخش.",
    highlight: "Fortschritt",
    base: "#3a2500",
    primary: "#c48412",
    accent: "#ffcf4a",
    Icon: ChartIcon,
  },
  exams: {
    key: "exams",
    label: "Prüfungen",
    labelFa: "آزمون‌ها",
    titleDe: "Bereit für die Prüfung",
    titleFa: "آماده برای آزمون",
    descDe: "Zielgerichtet üben, mit echten Prüfungsformaten trainieren.",
    descFa: "تمرین هدف‌مند با فرمت‌های واقعی امتحان.",
    highlight: "Prüfung",
    base: "#0a1547",
    primary: "#1b3fbf",
    accent: "#4d8cff",
    Icon: ExamIcon,
  },
  profile: {
    key: "profile",
    label: "Profil",
    labelFa: "پروفایل",
    titleDe: "Dein Lernprofil",
    titleFa: "پروفایل یادگیری‌ات",
    descDe: "Einstellungen, Ziele und alles, was zu deinem Lernstil passt.",
    descFa: "تنظیمات، اهداف و همه‌ی چیزهایی که با سبک یادگیری‌ات جور می‌آید.",
    highlight: "Lernprofil",
    base: "#1a1d24",
    primary: "#3a3f4d",
    accent: "#8b93a6",
    Icon: UserIcon,
  },
  events: {
    key: "events",
    label: "Events",
    labelFa: "رویدادها",
    titleDe: "Triff deine Community",
    titleFa: "با جامعه‌ات آشنا شو",
    descDe: "Sprachtreffs, Meetups und echte Gespräche — Deutsch leben, nicht nur lernen.",
    descFa: "دورهمی‌های زبان، میت‌آپ‌ها و گفتگوی واقعی — آلمانی را زندگی کن.",
    highlight: "Community",
    base: "#0a2a1c",
    primary: "#0e7c5a",
    accent: "#4ade80",
    Icon: CalendarIcon,
  },
  writing: {
    key: "writing",
    label: "Schreiben",
    labelFa: "نوشتن",
    titleDe: "Schreib. Sende. Verbessere.",
    titleFa: "تمرین نوشتن با بازخورد هوش مصنوعی",
    descDe:
      "Wähle ein Thema, schreibe deinen Text und erhalte sofort detailliertes Feedback zu Grammatik, Stil und Wortschatz.",
    descFa: "یک موضوع انتخاب کن، متنت را بنویس و بلافاصله بازخورد دقیق بگیر.",
    highlight: "Verbessere.",
    base: "#1b0630",
    primary: "#5b21b6",
    accent: "#c084fc",
    Icon: PencilIcon,
  },
  verbs: {
    key: "verbs",
    label: "Wortfamilien",
    labelFa: "خانواده واژه‌ها",
    titleDe: "Wörter über ihre Wurzel verstehen",
    titleFa: "واژه‌ها را از راه ریشه‌شان بفهم",
    descDe:
      "Ein Wortstamm in der Mitte, seine ganze Familie darum herum — mit Präfixen, Suffixen und Wortbau.",
    descFa: "یک ریشه در مرکز و همه‌ی هم‌خانواده‌هایش دور آن — با پیشوند، پسوند و ساخت واژه.",
    highlight: "Wurzel",
    base: "#032b33",
    primary: "#0e7490",
    accent: "#22d3ee",
    Icon: WordFamilyIcon,
  },
  community: {
    key: "community",
    label: "Community",
    labelFa: "جامعه",
    titleDe: "Lernt gemeinsam Deutsch",
    titleFa: "باهم آلمانی یاد بگیرید",
    descDe: "Talare, eigene Gruppen und private Chats — plus Sprechpartner für dein Deutsch.",
    descFa: "تالار عمومی، گروه دوستانه و چت خصوصی — به‌همراه پارتنر مکالمه.",
    highlight: "gemeinsam",
    base: "#4a1206",
    primary: "#c2410c",
    accent: "#fdba74",
    Icon: ChatIcon,
  },
  achievements: {
    key: "achievements",
    label: "Erfolge",
    labelFa: "دستاوردها",
    titleDe: "Deine Erfolge",
    titleFa: "دستاوردهای تو",
    descDe: "Abzeichen, Serien und Missionen — sieh, wie weit du gekommen bist.",
    descFa: "نشان‌ها، رکوردها و ماموریت‌ها — ببین تا کجا رسیده‌ای.",
    highlight: "Erfolge",
    base: "#3a2400",
    primary: "#b4790a",
    accent: "#fbbf24",
    Icon: TrophyIcon,
  },
};
