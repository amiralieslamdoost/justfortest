// Mock data for "Deutsches Kino" — German cinema section.
// Films with dual-language subtitles (DE/FA) synced by timestamp.
// Each German cue can carry a "words" map for smart click-to-translate.

export interface SubtitleWord {
  de: string;
  fa: string;
  pos?: string;
  note?: string;
}

export interface SubtitleCue {
  id: string;
  start: number; // seconds
  end: number;
  de: string;
  fa: string;
  words?: SubtitleWord[];
}

export interface Film {
  id: string;
  title: string;
  titleFa: string;
  year: number;
  duration: string;
  level: "A1" | "A2" | "B1" | "B2" | "C1";
  genre: string[];
  director: string;
  synopsis: string;
  synopsisFa: string;
  poster: string; // gradient tokens for poster
  videoUrl: string;
  cues: SubtitleCue[];
}

// Sample videos: public domain / Creative Commons clips
const SAMPLE_1 = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
const SAMPLE_2 = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/friday.mp4";
const SAMPLE_3 = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
const SAMPLE_4 = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/friday.mp4";

export const films: Film[] = [
  {
    id: "berlin-tage",
    title: "Good Bye, Lenin!",
    titleFa: "خداحافظ، لنین!",
    year: 2003,
    duration: "2h 1m",
    level: "B1",
    genre: ["Drama", "Komödie"],
    director: "Wolfgang Becker",
    synopsis:
      "Nach dem Mauerfall versucht ein junger Ostberliner, für seine kranke Mutter die DDR in einer kleinen Wohnung am Leben zu halten.",
    synopsisFa:
      "پس از فروپاشی دیوار برلین، جوانی برلینی تلاش می‌کند برای مادر بیمارش، آلمان شرقی را در آپارتمانی کوچک زنده نگه دارد.",
    poster:
      "center/cover no-repeat url('https://upload.wikimedia.org/wikipedia/en/6/63/Good_Bye_Lenin.jpg'), #0a0a0c",
    videoUrl: SAMPLE_1,
    cues: [
      {
        id: "c1",
        start: 2,
        end: 6,
        de: "Willkommen in Berlin! Das ist meine neue Wohnung.",
        fa: "به برلین خوش آمدی! این آپارتمان جدید من است.",
        words: [
          { de: "Willkommen", fa: "خوش‌آمدی", pos: "Interjektion" },
          { de: "Berlin", fa: "برلین (پایتخت آلمان)", pos: "Nomen" },
          { de: "neue", fa: "جدید", pos: "Adjektiv" },
          { de: "Wohnung", fa: "آپارتمان (die)", pos: "Nomen", note: "die Wohnung, -en" },
        ],
      },
      {
        id: "c2",
        start: 6.5,
        end: 10,
        de: "Wie heißt du? Ich heiße Amir und komme aus dem Iran.",
        fa: "اسمت چیست؟ من امیر هستم و اهل ایران‌ام.",
        words: [
          { de: "heißt", fa: "نامیده می‌شوی", pos: "Verb", note: "heißen — نام داشتن" },
          { de: "komme", fa: "می‌آیم", pos: "Verb" },
          { de: "Iran", fa: "ایران", pos: "Nomen" },
        ],
      },
      {
        id: "c3",
        start: 10.5,
        end: 15,
        de: "Freut mich sehr! Trinken wir zusammen einen Kaffee?",
        fa: "خیلی خوشحالم! باهم یک قهوه بخوریم؟",
        words: [
          { de: "Freut", fa: "خوشحال می‌کند", pos: "Verb", note: "sich freuen" },
          { de: "zusammen", fa: "باهم", pos: "Adverb" },
          { de: "Kaffee", fa: "قهوه (der)", pos: "Nomen" },
        ],
      },
      {
        id: "c4",
        start: 16,
        end: 21,
        de: "Die Straßen sind voll, aber die Menschen sind freundlich.",
        fa: "خیابان‌ها شلوغ‌اند، اما مردم مهربان‌اند.",
        words: [
          { de: "Straßen", fa: "خیابان‌ها", pos: "Nomen", note: "die Straße, -n" },
          { de: "voll", fa: "پر / شلوغ", pos: "Adjektiv" },
          { de: "Menschen", fa: "مردم / انسان‌ها", pos: "Nomen" },
          { de: "freundlich", fa: "مهربان", pos: "Adjektiv" },
        ],
      },
      {
        id: "c5",
        start: 22,
        end: 27,
        de: "Morgen gehe ich zur Universität. Ich studiere Informatik.",
        fa: "فردا به دانشگاه می‌روم. من علوم کامپیوتر می‌خوانم.",
        words: [
          { de: "Morgen", fa: "فردا", pos: "Adverb" },
          { de: "Universität", fa: "دانشگاه (die)", pos: "Nomen" },
          { de: "studiere", fa: "تحصیل می‌کنم", pos: "Verb" },
          { de: "Informatik", fa: "علوم کامپیوتر (die)", pos: "Nomen" },
        ],
      },
      {
        id: "c6",
        start: 28,
        end: 34,
        de: "Am Wochenende möchte ich das Brandenburger Tor besuchen.",
        fa: "آخر هفته می‌خواهم دروازه براندنبورگ را ببینم.",
        words: [
          { de: "Wochenende", fa: "آخر هفته (das)", pos: "Nomen" },
          { de: "möchte", fa: "دوست دارم / می‌خواهم", pos: "Verb" },
          { de: "besuchen", fa: "بازدید کردن", pos: "Verb" },
        ],
      },
    ],
  },
  {
    id: "muenchen-liebe",
    title: "Lola rennt",
    titleFa: "لولا می‌دود",
    year: 1998,
    duration: "1h 21m",
    level: "B2",
    genre: ["Thriller", "Drama"],
    director: "Tom Tykwer",
    synopsis:
      "Lola hat zwanzig Minuten Zeit, um 100.000 Mark zu beschaffen und das Leben ihres Freundes zu retten — drei rasante Varianten desselben Laufs.",
    synopsisFa:
      "لولا فقط بیست دقیقه فرصت دارد تا صدهزار مارک پیدا کند و جان دوست‌پسرش را نجات دهد؛ سه روایت پرشتاب از یک دویدن.",
    poster:
      "center/cover no-repeat url('https://upload.wikimedia.org/wikipedia/en/f/f5/Lola_Rennt_poster.jpg'), #0a0a0c",
    videoUrl: SAMPLE_3,
    cues: [
      {
        id: "m1",
        start: 1,
        end: 5,
        de: "Grüß Gott! Was darf es sein?",
        fa: "سلام! چه میل دارید؟",
        words: [
          { de: "Grüß Gott", fa: "سلام (بایرنی)", note: "Bayerischer Gruß" },
          { de: "darf", fa: "اجازه دارد", pos: "Verb", note: "dürfen" },
        ],
      },
      {
        id: "m2",
        start: 5.5,
        end: 10,
        de: "Zwei Brezeln bitte, und ein Stück Apfelstrudel.",
        fa: "لطفاً دو تا برتزل و یک تکه اشترودل سیب.",
        words: [
          { de: "Brezeln", fa: "برتزل‌ها (شیرینی نمکی)", pos: "Nomen" },
          { de: "Stück", fa: "تکه (das)", pos: "Nomen" },
          { de: "Apfelstrudel", fa: "اشترودل سیب (der)", pos: "Nomen" },
        ],
      },
      {
        id: "m3",
        start: 11,
        end: 16,
        de: "Woher kommst du? Dein Deutsch ist wirklich gut.",
        fa: "اهل کجایی؟ آلمانی‌ات واقعاً خوب است.",
        words: [
          { de: "Woher", fa: "از کجا", pos: "Adverb" },
          { de: "wirklich", fa: "واقعاً", pos: "Adverb" },
          { de: "gut", fa: "خوب", pos: "Adjektiv" },
        ],
      },
      {
        id: "m4",
        start: 17,
        end: 22,
        de: "Danke! Ich lerne seit einem Jahr in der Sprachschule.",
        fa: "ممنون! یک سال است در آموزشگاه زبان درس می‌خوانم.",
        words: [
          { de: "seit", fa: "از (زمان)", pos: "Präposition", note: "seit + Dat" },
          { de: "Jahr", fa: "سال (das)", pos: "Nomen" },
          { de: "Sprachschule", fa: "آموزشگاه زبان (die)", pos: "Nomen" },
        ],
      },
      {
        id: "m5",
        start: 23,
        end: 29,
        de: "Möchtest du mit mir zum Englischen Garten spazieren gehen?",
        fa: "دوست داری با من به باغ انگلیسی برای پیاده‌روی برویم؟",
        words: [
          { de: "Möchtest", fa: "دوست داری", pos: "Verb" },
          { de: "spazieren", fa: "پیاده‌روی کردن", pos: "Verb" },
          { de: "Garten", fa: "باغ (der)", pos: "Nomen" },
        ],
      },
    ],
  },
  {
    id: "hamburg-hafen",
    title: "Das Leben der Anderen",
    titleFa: "زندگی دیگران",
    year: 2006,
    duration: "2h 17m",
    level: "C1",
    genre: ["Drama", "Thriller"],
    director: "Florian Henckel von Donnersmarck",
    synopsis:
      "Ein Stasi-Offizier im Ost-Berlin der 80er belauscht einen Dramatiker — und beginnt langsam, an seinem eigenen System zu zweifeln.",
    synopsisFa:
      "افسر اشتازی در برلین شرقی دهه هشتاد، از یک نمایشنامه‌نویس شنود می‌گیرد و کم‌کم به نظام خودش شک می‌کند.",
    poster:
      "center/cover no-repeat url('https://upload.wikimedia.org/wikipedia/en/9/9f/Leben_der_anderen.jpg'), #0a0a0c",
    videoUrl: SAMPLE_2,
    cues: [
      {
        id: "h1",
        start: 2,
        end: 7,
        de: "Der Nebel war dicht, als wir die Leiche fanden.",
        fa: "وقتی جسد را پیدا کردیم، مه غلیظ بود.",
        words: [
          { de: "Nebel", fa: "مه (der)", pos: "Nomen" },
          { de: "dicht", fa: "غلیظ", pos: "Adjektiv" },
          { de: "Leiche", fa: "جسد (die)", pos: "Nomen" },
          { de: "fanden", fa: "پیدا کردیم", pos: "Verb", note: "finden — Präteritum" },
        ],
      },
      {
        id: "h2",
        start: 8,
        end: 14,
        de: "Wir müssen den Fall so schnell wie möglich aufklären.",
        fa: "باید هرچه سریع‌تر پرونده را حل کنیم.",
        words: [
          { de: "Fall", fa: "پرونده (der)", pos: "Nomen" },
          { de: "schnell", fa: "سریع", pos: "Adjektiv" },
          { de: "aufklären", fa: "روشن کردن / حل کردن", pos: "Verb" },
        ],
      },
      {
        id: "h3",
        start: 15,
        end: 21,
        de: "Der Verdächtige wurde gestern Abend am Hafen gesehen.",
        fa: "مظنون دیشب در بندر دیده شده است.",
        words: [
          { de: "Verdächtige", fa: "مظنون (der)", pos: "Nomen" },
          { de: "gestern", fa: "دیروز", pos: "Adverb" },
          { de: "Hafen", fa: "بندر (der)", pos: "Nomen" },
        ],
      },
      {
        id: "h4",
        start: 22,
        end: 28,
        de: "Ich glaube, hier stimmt etwas ganz und gar nicht.",
        fa: "فکر می‌کنم اینجا اصلاً اوضاع درست نیست.",
        words: [
          { de: "glaube", fa: "فکر می‌کنم", pos: "Verb", note: "glauben" },
          { de: "stimmt", fa: "درست است", pos: "Verb", note: "stimmen" },
        ],
      },
    ],
  },
];

export function findFilm(id: string) {
  return films.find((f) => f.id === id);
}
