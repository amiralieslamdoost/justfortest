// ============ Leitner Dashboard Mock Data ============
// Self-contained mock layer for the Leitner Dashboard.
// Reuses vocabulary from the Dictionary module for a consistent demo.

import { ALL_WORDS } from "@/lib/deusi/dictionary/mockWords";
import type { DictWord, CEFR, DictPos } from "@/lib/deusi/dictionary/types";

export type LeitnerBoxNumber = 1 | 2 | 3 | 4 | 5;

export interface LeitnerBoxInfo {
  box: LeitnerBoxNumber;
  label: string; // Neu / Lernend / Fortgeschritten / Reifend / Meister
  intervalDays: number;
  cards: number;
  progress: number; // 0..100 completion for today
  nextReviewIn: string; // human string e.g. "in 2 Stunden"
  color: string; // accent hex
  tint: string; // soft background hex
}

export interface QueueItem {
  id: string;
  headword: string;
  pos: DictPos;
  cefr: CEFR;
  box: LeitnerBoxNumber;
  category: string;
  dueLabel: string; // "jetzt" | "in 2 Std."
  difficult?: boolean;
  favorite?: boolean;
}

export interface WeeklyPoint {
  day: string;
  count: number;
}
export interface MonthlyPoint {
  week: string;
  count: number;
}
export interface HeatCell {
  date: string;
  value: number;
}

export interface AIInsight {
  id: string;
  icon: string;
  tone: "success" | "warning" | "info";
  title: string;
  body: string;
}

// ============ Boxes ============

export const LEITNER_BOXES: LeitnerBoxInfo[] = [
  {
    box: 1,
    label: "Neu",
    intervalDays: 1,
    cards: 32,
    progress: 20,
    nextReviewIn: "täglich",
    color: "#8B5CF6",
    tint: "#F3ECFF",
  },
  {
    box: 2,
    label: "Lernend",
    intervalDays: 3,
    cards: 78,
    progress: 45,
    nextReviewIn: "in 2 Stunden",
    color: "#3B82F6",
    tint: "#E7F0FF",
  },
  {
    box: 3,
    label: "Fortgeschritten",
    intervalDays: 7,
    cards: 96,
    progress: 62,
    nextReviewIn: "in 5 Stunden",
    color: "#22C55E",
    tint: "#E7F8EE",
  },
  {
    box: 4,
    label: "Reifend",
    intervalDays: 15,
    cards: 54,
    progress: 80,
    nextReviewIn: "in 7 Stunden",
    color: "#F59E0B",
    tint: "#FFF4D6",
  },
  {
    box: 5,
    label: "Meister",
    intervalDays: 30,
    cards: 12,
    progress: 95,
    nextReviewIn: "in 1 Tag",
    color: "#EF4444",
    tint: "#FEE9E7",
  },
];

export const DEFAULT_INTERVALS: Record<LeitnerBoxNumber, number> = {
  1: 1,
  2: 3,
  3: 7,
  4: 15,
  5: 30,
};

// ============ Aggregate stats ============

export const LEITNER_STATS = {
  memoryHealth: 84, // 0..100
  memoryHealthAfter: 91,
  dueToday: 48,
  streak: 14,
  totalCards: 2450,
  mastered: 1278,
  learning: 856,
  retentionRate: 92,
  successRate: 88,
  weeklyReviews: 342,
  monthlyReviews: 1287,
  totalReviews: 8_942,
  correctAnswers: 7_870,
  wrongAnswers: 1_072,
  avgResponseSec: 2.4,
  learningVelocity: 12, // words / day
};

// ============ Charts ============

export const WEEKLY_ACTIVITY: WeeklyPoint[] = [
  { day: "Mo", count: 32 },
  { day: "Di", count: 45 },
  { day: "Mi", count: 38 },
  { day: "Do", count: 56 },
  { day: "Fr", count: 48 },
  { day: "Sa", count: 62 },
  { day: "So", count: 71 },
];

export const MONTHLY_ACTIVITY: MonthlyPoint[] = [
  { week: "W1", count: 210 },
  { week: "W2", count: 268 },
  { week: "W3", count: 305 },
  { week: "W4", count: 342 },
];

export const REVIEW_HEATMAP: HeatCell[] = Array.from({ length: 12 * 7 }, (_, i) => {
  // deterministic pseudo-random 0..4
  const v = Math.round((Math.sin(i * 1.7) + 1) * 2);
  return { date: `d${i}`, value: v };
});

// ============ Queue (reuse dictionary words) ============

const QUEUE_SEEDS: Array<{
  id: string;
  box: LeitnerBoxNumber;
  dueLabel: string;
  difficult?: boolean;
  favorite?: boolean;
}> = [
  { id: "wunderbar", box: 2, dueLabel: "in 2 Std.", favorite: true },
  { id: "entwickeln", box: 3, dueLabel: "in 5 Std.", difficult: true },
  { id: "traumhaft", box: 2, dueLabel: "in 7 Std." },
  { id: "geniessen", box: 4, dueLabel: "in 1 Tag", favorite: true },
  { id: "abenteuer", box: 2, dueLabel: "in 1 Tag" },
  { id: "morgen", box: 3, dueLabel: "jetzt" },
  { id: "freund", box: 4, dueLabel: "in 2 Std." },
  { id: "zeit", box: 5, dueLabel: "in 3 Std." },
  { id: "lernen", box: 3, dueLabel: "jetzt", difficult: true },
];

export const TODAY_QUEUE: QueueItem[] = QUEUE_SEEDS.map((seed) => {
  const w = ALL_WORDS.find((x) => x.id === seed.id) as DictWord | undefined;
  if (!w) return null;
  return {
    id: w.id,
    headword: w.headword,
    pos: w.pos,
    cefr: w.cefr,
    category: w.category,
    box: seed.box,
    dueLabel: seed.dueLabel,
    difficult: seed.difficult,
    favorite: seed.favorite,
  } as QueueItem;
}).filter(Boolean) as QueueItem[];

// ============ AI Insights ============

export const AI_INSIGHTS: AIInsight[] = [
  {
    id: "forgotten",
    icon: "🧠",
    tone: "warning",
    title: "Häufig vergessene Wörter",
    body: "Du vergisst „entwickeln“, „genießen“ und „traumhaft“ oft. Wiederhole sie heute gezielt.",
  },
  {
    id: "best-time",
    icon: "🌅",
    tone: "info",
    title: "Deine beste Lernzeit",
    body: "Zwischen 08:00 und 10:00 Uhr behältst du 23% mehr Wörter als am Abend.",
  },
  {
    id: "prediction",
    icon: "🎯",
    tone: "success",
    title: "Speicher-Vorhersage",
    body: "Nach dieser Sitzung liegt deine Behaltensrate bei etwa 91% (heute: 84%).",
  },
  {
    id: "duration",
    icon: "⏱️",
    tone: "info",
    title: "Empfohlene Dauer",
    body: "18–22 Minuten reichen heute – längere Sitzungen bringen kaum mehr Ertrag.",
  },
  {
    id: "weak-grammar",
    icon: "📚",
    tone: "warning",
    title: "Grammatik-Schwächen",
    body: "Trennbare Verben und Akkusativ-Präpositionen brauchen mehr Übung.",
  },
  {
    id: "categories",
    icon: "🗂️",
    tone: "info",
    title: "Kategorien mit Nachholbedarf",
    body: "„Technik & Medien“ und „Abstrakte Begriffe“ sind unter deinem Schnitt.",
  },
];

// ============ Session settings ============

export type ReviewOrder = "due-first" | "hardest-first" | "random" | "by-box";

export interface SessionSettings {
  dailyNewLimit: number;
  dailyReviewLimit: number;
  reviewOrder: ReviewOrder;
  shuffle: boolean;
  autoPlayPronunciation: boolean;
  showTranslation: boolean;
  showExample: boolean;
  showGrammar: boolean;
  showHints: boolean;
  revealDelaySec: number;
  onlyDueToday: boolean;
  includeDifficult: boolean;
  includeFavorites: boolean;
  cefrLevels: CEFR[];
  wordTypes: DictPos[];
  intervals: Record<LeitnerBoxNumber, number>;
}

export const DEFAULT_SETTINGS: SessionSettings = {
  dailyNewLimit: 12,
  dailyReviewLimit: 40,
  reviewOrder: "due-first",
  shuffle: true,
  autoPlayPronunciation: true,
  showTranslation: true,
  showExample: true,
  showGrammar: true,
  showHints: false,
  revealDelaySec: 3,
  onlyDueToday: false,
  includeDifficult: true,
  includeFavorites: true,
  cefrLevels: ["A1", "A2", "B1", "B2"],
  wordTypes: ["noun", "verb", "adjective", "adverb"],
  intervals: { ...DEFAULT_INTERVALS },
};

// ============ Presets ============

export type PresetId = "quick" | "balanced" | "intensive";

export interface Preset {
  id: PresetId;
  title: string;
  duration: string;
  tagline: string;
  bullets: string[];
  recommended?: boolean;
  color: string;
  tint: string;
  apply: (base: SessionSettings) => SessionSettings;
}

export const PRESETS: Preset[] = [
  {
    id: "quick",
    title: "Schnelle Wiederholung",
    duration: "5–10 Min",
    tagline: "Nur die heute fälligen Karten.",
    bullets: ["Nur fällige Karten", "Keine neuen Wörter", "Kurze Sitzung"],
    color: "#3B82F6",
    tint: "#E7F0FF",
    apply: (s) => ({
      ...s,
      onlyDueToday: true,
      dailyNewLimit: 0,
      dailyReviewLimit: 20,
      includeDifficult: false,
    }),
  },
  {
    id: "balanced",
    title: "Ausgewogene Sitzung",
    duration: "15–20 Min",
    tagline: "Wiederholungen und neue Wörter.",
    bullets: ["Fällige Karten", "12 neue Wörter", "Empfohlen"],
    recommended: true,
    color: "#8B5CF6",
    tint: "#F3ECFF",
    apply: (s) => ({
      ...s,
      onlyDueToday: false,
      dailyNewLimit: 12,
      dailyReviewLimit: 40,
      includeDifficult: true,
      includeFavorites: true,
    }),
  },
  {
    id: "intensive",
    title: "Intensive Sitzung",
    duration: "30–45 Min",
    tagline: "Alles: Wiederholungen, schwierige & Lieblingswörter.",
    bullets: ["Alle Wiederholungen", "Schwierige Wörter", "Lieblingswörter"],
    color: "#EF4444",
    tint: "#FEE9E7",
    apply: (s) => ({
      ...s,
      onlyDueToday: false,
      dailyNewLimit: 20,
      dailyReviewLimit: 80,
      includeDifficult: true,
      includeFavorites: true,
    }),
  },
];

// ============ Session preview computation ============

export interface SessionPreview {
  totalCards: number;
  newCards: number;
  reviewCards: number;
  difficultCards: number;
  favoriteCards: number;
  estimatedMinutes: number;
  estimatedXp: number;
  successPrediction: number; // %
  retentionAfter: number; // %
  memoryHealthBefore: number; // %
  memoryHealthAfter: number; // %
  cefrLevels: CEFR[];
  wordTypes: DictPos[];
}

export function computePreview(s: SessionSettings): SessionPreview {
  const reviewCards = Math.min(
    s.dailyReviewLimit,
    s.onlyDueToday ? LEITNER_STATS.dueToday : LEITNER_STATS.dueToday + 8,
  );
  const newCards = s.dailyNewLimit;
  const difficult = s.includeDifficult ? Math.round(reviewCards * 0.18) : 0;
  const favorites = s.includeFavorites ? Math.round(reviewCards * 0.22) : 0;
  const total = reviewCards + newCards;
  const minutes = Math.max(3, Math.round(total * 0.38));
  const xp = total * 2 + newCards * 3;
  const success = Math.min(
    98,
    78 +
      (s.showHints ? 4 : 0) +
      (s.showExample ? 3 : 0) +
      (s.showTranslation ? 3 : 0) +
      (s.reviewOrder === "due-first" ? 4 : 0),
  );
  const retention = Math.min(98, LEITNER_STATS.memoryHealth + Math.round(total / 12));
  return {
    totalCards: total,
    newCards,
    reviewCards,
    difficultCards: difficult,
    favoriteCards: favorites,
    estimatedMinutes: minutes,
    estimatedXp: xp,
    successPrediction: success,
    retentionAfter: retention,
    memoryHealthBefore: LEITNER_STATS.memoryHealth,
    memoryHealthAfter: Math.min(99, LEITNER_STATS.memoryHealth + Math.round(total / 8)),
    cefrLevels: s.cefrLevels,
    wordTypes: s.wordTypes,
  };
}
