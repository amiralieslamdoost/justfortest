// ---------------------------------------------------------------------------
// DEUSI — Mock reading library
//
// Realistic, deterministic mock data for the Lesen (Reading) module. All
// exports are plain serializable values so they can be swapped for a
// `fetchArticles()` / `fetchArticle(id)` server call later.
// ---------------------------------------------------------------------------

export type CEFR = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type ReadingCategory =
  | "nachrichten"
  | "kultur"
  | "wissenschaft"
  | "geschichten"
  | "reisen"
  | "alltag"
  | "technologie"
  | "natur"
  | "bildung"
  | "sport";

export interface VocabItem {
  word: string;
  article?: "der" | "die" | "das";
  pos: "Substantiv" | "Verb" | "Adjektiv" | "Adverb" | "Präposition" | "Ausdruck";
  translation: string;
  pronunciation: string;
  level: CEFR;
  example: string;
}

export type QuestionType = "mcq" | "truefalse" | "fill" | "match" | "vocab";

export interface Question {
  id: string;
  type: QuestionType;
  prompt: string;
  options?: string[]; // mcq / vocab
  answer: string | string[]; // single index string, "true"/"false", string, or matched pairs
  pairs?: { left: string; right: string }[]; // match
  explanation?: string;
}

export interface Paragraph {
  text: string; // uses [[word]] markers for interactive vocab words
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  description: string;
  category: ReadingCategory;
  level: CEFR;
  minutes: number;
  words: number;
  cover: string;
  author: string;
  publishedAt: string;
  progress: number; // 0..100
  bookmarked: boolean;
  favorite: boolean;
  content: Paragraph[];
  vocab: VocabItem[];
  questions: Question[];
  aiSummary: string;
  grammarNotes: { title: string; body: string }[];
}

// ---------------------------------------------------------------------------
// Categories
// ---------------------------------------------------------------------------

export const readingCategories: { key: ReadingCategory | "alle" | "fuerdich"; label: string }[] = [
  { key: "fuerdich", label: "Für dich" },
  { key: "alle", label: "Alle Texte" },
  { key: "nachrichten", label: "Nachrichten" },
  { key: "kultur", label: "Kultur" },
  { key: "wissenschaft", label: "Wissenschaft" },
  { key: "geschichten", label: "Geschichten" },
  { key: "reisen", label: "Reisen" },
  { key: "alltag", label: "Alltag" },
  { key: "technologie", label: "Technologie" },
  { key: "natur", label: "Natur" },
  { key: "bildung", label: "Bildung" },
  { key: "sport", label: "Sport" },
];

export const cefrLevels: CEFR[] = ["A1", "A2", "B1", "B2", "C1", "C2"];

// ---------------------------------------------------------------------------
// Shared vocab bank (reused across articles)
// ---------------------------------------------------------------------------

const V = {
  Herausforderung: {
    word: "Herausforderung",
    article: "die",
    pos: "Substantiv",
    translation: "challenge",
    pronunciation: "/hɛˈʁaʊ̯sˌfɔʁdəʁʊŋ/",
    level: "B1",
    example: "Die Prüfung war eine große Herausforderung.",
  },
  Stadtbild: {
    word: "Stadtbild",
    article: "das",
    pos: "Substantiv",
    translation: "cityscape",
    pronunciation: "/ˈʃtatˌbɪlt/",
    level: "B1",
    example: "Das Stadtbild von Berlin verändert sich schnell.",
  },
  Viertel: {
    word: "Viertel",
    article: "das",
    pos: "Substantiv",
    translation: "district, quarter",
    pronunciation: "/ˈfɪʁtl̩/",
    level: "A2",
    example: "Ich wohne in einem ruhigen Viertel.",
  },
  Nachhaltigkeit: {
    word: "Nachhaltigkeit",
    article: "die",
    pos: "Substantiv",
    translation: "sustainability",
    pronunciation: "/ˈnaːxˌhaltɪçkaɪ̯t/",
    level: "B2",
    example: "Nachhaltigkeit ist ein wichtiges Thema.",
  },
  wandeln: {
    word: "wandeln",
    pos: "Verb",
    translation: "to transform, to change",
    pronunciation: "/ˈvandl̩n/",
    level: "B1",
    example: "Die Stadt wandelt sich jedes Jahr.",
  },
  Umwelt: {
    word: "Umwelt",
    article: "die",
    pos: "Substantiv",
    translation: "environment",
    pronunciation: "/ˈʊmvɛlt/",
    level: "A2",
    example: "Wir müssen die Umwelt schützen.",
  },
  Bildung: {
    word: "Bildung",
    article: "die",
    pos: "Substantiv",
    translation: "education",
    pronunciation: "/ˈbɪldʊŋ/",
    level: "A2",
    example: "Bildung öffnet viele Türen.",
  },
  gestalten: {
    word: "gestalten",
    pos: "Verb",
    translation: "to shape, to design",
    pronunciation: "/ɡəˈʃtaltn̩/",
    level: "B1",
    example: "Wir gestalten unsere Zukunft selbst.",
  },
  erneuerbar: {
    word: "erneuerbar",
    pos: "Adjektiv",
    translation: "renewable",
    pronunciation: "/ɛɐ̯ˈnɔɪ̯ɐbaːɐ̯/",
    level: "B1",
    example: "Erneuerbare Energien sind wichtig.",
  },
  Zukunft: {
    word: "Zukunft",
    article: "die",
    pos: "Substantiv",
    translation: "future",
    pronunciation: "/ˈtsuːkʊnft/",
    level: "A2",
    example: "Die Zukunft beginnt jetzt.",
  },
  Alltag: {
    word: "Alltag",
    article: "der",
    pos: "Substantiv",
    translation: "everyday life",
    pronunciation: "/ˈaltaːk/",
    level: "A2",
    example: "Der Alltag eines Studenten ist voll.",
  },
} as const satisfies Record<string, VocabItem>;

// ---------------------------------------------------------------------------
// Article templates — kept as data so a single source drives everything
// ---------------------------------------------------------------------------

type Template = {
  title: string;
  description: string;
  category: ReadingCategory;
  level: CEFR;
  minutes: number;
  cover: string;
  content: Paragraph[];
  vocab: VocabItem[];
  aiSummary: string;
  grammarNotes?: { title: string; body: string }[];
};

// A generic filler paragraph builder so all 40+ articles feel “complete”.
function filler(topic: string): Paragraph[] {
  return [
    {
      text: `${topic} ist ein spannendes Thema in Deutschland. Viele Menschen interessieren sich für die aktuellen [[Herausforderung]]en und die Möglichkeiten, die es bietet.`,
    },
    {
      text: `In den letzten Jahren hat sich viel [[wandeln|gewandelt]]. Neue Ideen, neue Technologien und ein neues Denken haben das [[Stadtbild]] geprägt und den [[Alltag]] verändert.`,
    },
    {
      text: `Für die [[Zukunft]] wünschen sich viele mehr [[Nachhaltigkeit]] und mehr Verantwortung für die [[Umwelt]]. [[Bildung]] spielt dabei eine zentrale Rolle.`,
    },
    {
      text: `Am Ende zählt vor allem eines: Wir müssen unsere Welt gemeinsam [[gestalten|gestalten]] – Schritt für Schritt, Tag für Tag.`,
    },
  ];
}

const genericVocab: VocabItem[] = [
  V.Herausforderung,
  V.Stadtbild,
  V.Viertel,
  V.Nachhaltigkeit,
  V.wandeln,
  V.Umwelt,
  V.Bildung,
  V.gestalten,
  V.erneuerbar,
  V.Zukunft,
  V.Alltag,
];

const COVERS = [
  "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1509316785289-025f5b846b35?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1470813740244-df37b8c1edcb?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=1200&q=60",
  "https://images.unsplash.com/photo-1449034446853-66c86144b0ad?auto=format&fit=crop&w=1200&q=60",
];

const TEMPLATES: Template[] = [
  // 1 — Featured Berlin article (matches reference)
  {
    title: "Berlin: Eine Stadt im Wandel",
    description: "Berlin ist die Hauptstadt von Deutschland und eine der größten Städte Europas.",
    category: "kultur",
    level: "A2",
    minutes: 5,
    cover:
      "https://images.unsplash.com/photo-1587330979470-3595ac045ab0?auto=format&fit=crop&w=1200&q=60",
    content: [
      {
        text: `Berlin ist eine Stadt, die sich ständig verändert. Jedes Jahr ziehen Tausende von Menschen hierher, um zu arbeiten, zu studieren oder ein neues Leben zu beginnen. Die Stadt bietet viele Möglichkeiten, aber sie stellt auch große [[Herausforderung]]en.`,
      },
      {
        text: `In den letzten Jahren hat sich besonders das [[Stadtbild]] stark [[wandeln|gewandelt]]. Alte Gebäude werden renoviert, neue Wohnungen gebaut und viele [[Viertel]] werden moderner. Gleichzeitig versuchen die Menschen, die Geschichte und den besonderen Charakter der Stadt zu bewahren.`,
      },
      {
        text: `Ein wichtiges Thema in Berlin ist auch die [[Umwelt]]. Die Stadt möchte klimafreundlicher werden. Deshalb gibt es mehr Fahrradwege, Elektrobusse und Grünflächen. Viele Berlinerinnen und Berliner engagieren sich für [[Nachhaltigkeit]] und ein besseres Leben in ihrer Stadt.`,
      },
      {
        text: `Berlin ist eine Stadt voller Gegensätze — laut und leise, alt und neu, traditionell und modern. Vielleicht ist genau das der Grund, warum so viele Menschen diese Stadt lieben.`,
      },
    ],
    vocab: [V.Herausforderung, V.Stadtbild, V.Viertel, V.Nachhaltigkeit, V.wandeln, V.Umwelt],
    aiSummary:
      "Der Text beschreibt Berlin als eine Stadt im ständigen Wandel. Er zeigt, wie sich das Stadtbild verändert, welche Rolle Umwelt und Nachhaltigkeit spielen und warum Berlin trotz aller Gegensätze so faszinierend bleibt.",
    grammarNotes: [
      {
        title: "Passiv im Präsens",
        body: "„Alte Gebäude werden renoviert.“ — Passivform mit werden + Partizip II.",
      },
      {
        title: "Reflexive Verben",
        body: "„Die Stadt verändert sich ständig.“ — sich als Reflexivpronomen bei Verben wie verändern, wandeln.",
      },
    ],
  },
  // 2
  {
    title: "Erneuerbare Energien in Deutschland",
    description:
      "Deutschland setzt zunehmend auf erneuerbare Energien, um die Umwelt zu schützen und die Zukunft nachhaltig zu gestalten.",
    category: "wissenschaft",
    level: "B1",
    minutes: 8,
    cover:
      "https://images.unsplash.com/photo-1466611653911-95081537e5b7?auto=format&fit=crop&w=1200&q=60",
    content: filler("Erneuerbare Energien"),
    vocab: genericVocab,
    aiSummary:
      "Ein Überblick über Wind-, Solar- und Wasserenergie in Deutschland und ihre Bedeutung für die Zukunft.",
  },
  // 3
  {
    title: "Ein typischer Tag im Leben eines Studenten",
    description: "Wie sieht der Alltag eines Studenten in Deutschland aus?",
    category: "alltag",
    level: "A2",
    minutes: 4,
    cover:
      "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1200&q=60",
    content: filler("Der Studentenalltag"),
    vocab: genericVocab,
    aiSummary:
      "Ein Blick auf den ganz normalen Tag eines Studenten — von der Vorlesung bis zum Feierabend.",
  },
];

// Fill up to 40+ articles with generated variants across categories & levels.
const EXTRA_TITLES: Array<[string, string, ReadingCategory, CEFR, number]> = [
  [
    "Die Alpen — Ein Naturparadies",
    "Berge, Seen und Wanderwege im Herzen Europas.",
    "natur",
    "B1",
    6,
  ],
  [
    "Züge in Deutschland: Pünktlich ans Ziel",
    "Ein Blick auf das deutsche Bahnnetz.",
    "technologie",
    "A2",
    5,
  ],
  [
    "Warum Lesen so wichtig ist",
    "Bücher öffnen Welten — auch beim Sprachenlernen.",
    "bildung",
    "A2",
    4,
  ],
  [
    "Das Oktoberfest — Tradition und Moderne",
    "Ein Fest zwischen Brauchtum und Party.",
    "kultur",
    "B1",
    7,
  ],
  [
    "Fußball: Deutschlands Lieblingssport",
    "Wie Fußball die Menschen in Deutschland verbindet.",
    "sport",
    "A2",
    5,
  ],
  ["Klimawandel und Politik", "Was tut die Politik gegen den Klimawandel?", "nachrichten", "B2", 9],
  [
    "Kaffee oder Tee? Deutsche Trinkgewohnheiten",
    "Kleine Rituale mit großer Bedeutung.",
    "alltag",
    "A1",
    3,
  ],
  [
    "Künstliche Intelligenz im Alltag",
    "Von Sprachassistenten bis zu Empfehlungen.",
    "technologie",
    "B2",
    8,
  ],
  [
    "Der Schwarzwald: Mythen und Wälder",
    "Ein Ausflug in eine der schönsten Regionen.",
    "reisen",
    "B1",
    6,
  ],
  ["Weihnachten in Deutschland", "Bräuche, Märkte und leckere Rezepte.", "kultur", "A2", 5],
  ["Ostern: Frühlingsbräuche", "Wie feiern deutsche Familien Ostern?", "kultur", "A1", 3],
  [
    "Universitäten in Deutschland",
    "Warum viele Studenten aus dem Ausland kommen.",
    "bildung",
    "B1",
    6,
  ],
  ["Die deutsche Wirtschaft heute", "Herausforderungen und Chancen.", "nachrichten", "B2", 8],
  ["Berliner Streetfood-Szene", "Von Currywurst bis Vietnamesisch.", "alltag", "B1", 6],
  ["Reisen mit dem 49-Euro-Ticket", "Wie eine Fahrkarte das Reisen verändert.", "reisen", "A2", 5],
  ["Digitale Bildung an Schulen", "Tablets, Apps und neue Lernwege.", "bildung", "B1", 6],
  [
    "Die deutsche Sprache lernen",
    "Warum Deutsch nicht so schwer ist, wie man denkt.",
    "bildung",
    "A1",
    3,
  ],
  [
    "Berliner Mauer: Damals und heute",
    "Eine kurze Geschichte der geteilten Stadt.",
    "geschichten",
    "B1",
    7,
  ],
  ["Beethoven: Ein deutscher Komponist", "Sein Leben und sein Einfluss.", "kultur", "B2", 8],
  ["Berufe der Zukunft", "Welche Berufe werden gebraucht?", "nachrichten", "B1", 6],
  ["Elektroautos in Deutschland", "Der Weg zur Elektromobilität.", "technologie", "B1", 6],
  ["Wandern in Bayern", "Die schönsten Wanderungen der Region.", "reisen", "A2", 5],
  ["Kunstmuseen in München", "Ein Kulturführer durch die Stadt.", "kultur", "B1", 6],
  ["Vegane Küche in Berlin", "Wo isst man am besten pflanzlich?", "alltag", "A2", 4],
  ["Recycling im Haushalt", "Wie trennt man richtig?", "alltag", "A2", 4],
  ["Die Grimm-Märchen", "Klassische Geschichten für alle Altersgruppen.", "geschichten", "A2", 5],
  ["Berliner Nachtleben", "Clubs, Bars und mehr.", "kultur", "B1", 6],
  ["Der deutsche Wald", "Warum der Wald so wichtig ist.", "natur", "B1", 6],
  ["Handball in Deutschland", "Ein oft unterschätzter Sport.", "sport", "A2", 4],
  ["Wintersport in den Alpen", "Skifahren, Rodeln, Snowboarden.", "sport", "A2", 5],
  ["Digitale Nomaden in Berlin", "Arbeiten von überall — auch in Berlin.", "alltag", "B1", 6],
  ["Klassische Musik in Wien und Berlin", "Zwei Städte, eine große Tradition.", "kultur", "C1", 9],
  [
    "Roboter im Krankenhaus",
    "Wie Technik Ärztinnen und Ärzte unterstützt.",
    "technologie",
    "B2",
    8,
  ],
  [
    "Fahrradstädte in Deutschland",
    "Wo das Fahrradfahren am besten funktioniert.",
    "reisen",
    "A2",
    4,
  ],
  ["Studieren im Ausland", "Ein Erasmus-Erfahrungsbericht.", "bildung", "B1", 6],
  [
    "Die Zeitumstellung — Sinnvoll oder nicht?",
    "Zwei Perspektiven zu einem alten Thema.",
    "nachrichten",
    "B2",
    7,
  ],
  ["Nordsee vs. Ostsee", "Zwei Meere, zwei Charaktere.", "reisen", "A2", 5],
  [
    "Deutschland und die Europäische Union",
    "Wirtschaft, Politik und Alltag.",
    "nachrichten",
    "C1",
    10,
  ],
  ["Astronomie für Anfänger", "Der Sternenhimmel über Deutschland.", "wissenschaft", "B1", 6],
  ["Yoga und Meditation im Alltag", "Kleine Übungen, große Wirkung.", "alltag", "A2", 5],
];

TEMPLATES.push(
  ...EXTRA_TITLES.map(([title, description, category, level, minutes], idx): Template => ({
    title,
    description,
    category,
    level,
    minutes,
    cover: COVERS[idx % COVERS.length],
    content: filler(title),
    vocab: genericVocab,
    aiSummary: `Kurze Zusammenfassung: ${description}`,
  })),
);

// ---------------------------------------------------------------------------
// Questions
// ---------------------------------------------------------------------------

function questionsFor(a: Template, id: string): Question[] {
  return [
    {
      id: `${id}-q1`,
      type: "mcq",
      prompt: `Worum geht es in „${a.title}“?`,
      options: [
        a.description,
        "Es geht um die Geschichte der römischen Kaiser.",
        "Der Text erklärt Kochrezepte aus Frankreich.",
        "Es ist ein Interview mit einem Sportler.",
      ],
      answer: "0",
      explanation: "Die richtige Antwort spiegelt die Kernaussage des Textes wider.",
    },
    {
      id: `${id}-q2`,
      type: "truefalse",
      prompt: `Das Thema des Textes ist ${a.category}.`,
      answer: "true",
    },
    {
      id: `${id}-q3`,
      type: "fill",
      prompt: "Ergänze den Satz: „Wir müssen die ___ schützen.“",
      answer: "Umwelt",
      explanation: "Ein häufiger Kollokations­partner: die Umwelt schützen.",
    },
    {
      id: `${id}-q4`,
      type: "vocab",
      prompt: "Was bedeutet „nachhaltig“?",
      options: ["umweltfreundlich", "teuer", "schnell", "schwierig"],
      answer: "0",
    },
    {
      id: `${id}-q5`,
      type: "match",
      prompt: "Ordne die Wörter ihren Übersetzungen zu.",
      pairs: [
        { left: "Herausforderung", right: "challenge" },
        { left: "Zukunft", right: "future" },
        { left: "Umwelt", right: "environment" },
        { left: "Bildung", right: "education" },
      ],
      answer: ["challenge", "future", "environment", "education"],
    },
    {
      id: `${id}-q6`,
      type: "mcq",
      prompt: `Welches Niveau hat dieser Text ungefähr?`,
      options: ["A1", "A2", "B1", "B2"],
      answer: String(
        ["A1", "A2", "B1", "B2"].indexOf(a.level.replace("C1", "B2").replace("C2", "B2")),
      ),
    },
    {
      id: `${id}-q7`,
      type: "truefalse",
      prompt: "Nachhaltigkeit spielt im Text eine Rolle.",
      answer: "true",
    },
    {
      id: `${id}-q8`,
      type: "fill",
      prompt: "Ergänze: „Bildung öffnet viele ___.“",
      answer: "Türen",
    },
    {
      id: `${id}-q9`,
      type: "vocab",
      prompt: "Was bedeutet „gestalten“?",
      options: ["formen / designen", "kaufen", "verlieren", "vergessen"],
      answer: "0",
    },
    {
      id: `${id}-q10`,
      type: "mcq",
      prompt: "Welche Aussage passt am besten zum Text?",
      options: [
        "Der Text ist optimistisch und blickt in die Zukunft.",
        "Der Text kritisiert eine berühmte Person.",
        "Der Text ist ein Kochrezept.",
        "Der Text handelt nur von Vergangenheit.",
      ],
      answer: "0",
    },
  ];
}

function slugify(t: string) {
  return t
    .toLowerCase()
    .replace(/ä/g, "ae")
    .replace(/ö/g, "oe")
    .replace(/ü/g, "ue")
    .replace(/ß/g, "ss")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

// ---------------------------------------------------------------------------
// Final articles
// ---------------------------------------------------------------------------

export const articles: Article[] = TEMPLATES.map((t, i) => {
  const id = `article-${(i + 1).toString().padStart(3, "0")}`;
  const words = t.content.reduce((s, p) => s + p.text.split(/\s+/).length, 0);
  const progress = [80, 65, 0, 0, 100, 45, 20, 0, 30, 0][i % 10];
  return {
    id,
    title: t.title,
    slug: slugify(t.title),
    description: t.description,
    category: t.category,
    level: t.level,
    minutes: t.minutes,
    words,
    cover: t.cover,
    author: "DEUSI Redaktion",
    publishedAt: new Date(2026, 5 + (i % 3), 1 + (i % 27)).toISOString(),
    progress,
    bookmarked: i % 5 === 0,
    favorite: i % 7 === 0,
    content: t.content,
    vocab: t.vocab,
    questions: questionsFor(t, id),
    aiSummary: t.aiSummary,
    grammarNotes: t.grammarNotes ?? [
      {
        title: "Nomen mit Artikel",
        body: "Merke dir Substantive immer mit dem Artikel (der/die/das).",
      },
      {
        title: "Trennbare Verben",
        body: "Bei trennbaren Verben rückt das Präfix im Hauptsatz ans Ende.",
      },
    ],
  };
});

// ---------------------------------------------------------------------------
// Reading dashboard stats
// ---------------------------------------------------------------------------

export const readingStats = {
  level: "A2" as CEFR,
  nextLevel: "B1" as CEFR,
  levelProgress: 60,
  textsRead: 48,
  textsReadDelta: 12,
  wordsLearned: 286,
  wordsLearnedDelta: 35,
  readingMinutes: 452, // 7h 32m
  readingMinutesDelta: 80,
  comprehension: 78,
  comprehensionDelta: 8,
  streakDays: 14,
  weeklyTexts: 12,
  weeklyComprehension: 78,
  weeklyWords: 86,
  dailyChallenge: {
    title: "Tages-Challenge",
    description: "Lies heute einen Text mit mindestens 80 % Verständnis.",
    progress: 60,
  },
  weeklyProgress: [
    { label: "Mo", value: 22 },
    { label: "Di", value: 34 },
    { label: "Mi", value: 41 },
    { label: "Do", value: 55 },
    { label: "Fr", value: 62 },
    { label: "Sa", value: 74 },
    { label: "So", value: 82 },
  ],
  vocabularyOfTheDay: [
    { word: "nachhaltig", pos: "Adjektiv" as const },
    { word: "Wandel", pos: "Substantiv" as const },
    { word: "Zukunft", pos: "Substantiv" as const },
    { word: "gestalten", pos: "Verb" as const },
    { word: "Umwelt", pos: "Substantiv" as const },
  ],
  exerciseOfTheDay: {
    prompt: "Was bedeutet das Wort „nachhaltig“?",
    options: [
      { key: "A", label: "schnell" },
      { key: "B", label: "umweltfreundlich" },
      { key: "C", label: "teuer" },
      { key: "D", label: "schwierig" },
    ],
    correctKey: "B",
  },
};

// ---------------------------------------------------------------------------
// Lookup helper
// ---------------------------------------------------------------------------

export function getArticle(id: string): Article | undefined {
  return articles.find((a) => a.id === id);
}

export function continueReading(): Article | undefined {
  return articles.find((a) => a.progress > 0 && a.progress < 100);
}

export function recentlyRead(limit = 3): Article[] {
  return articles.filter((a) => a.progress > 0).slice(0, limit);
}

export function recommendedForYou(limit = 5): Article[] {
  return articles.slice(0, limit);
}
