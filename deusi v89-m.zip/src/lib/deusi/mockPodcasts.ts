// ---------------------------------------------------------------------------
// DEUSI — Mock podcast / listening data.
// Every export is a plain, serializable value so it can be replaced by
// a real API call (Supabase / Firebase / REST) without touching the UI.
// ---------------------------------------------------------------------------

export type CEFR = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type PodcastCategoryKey =
  | "fuer-dich"
  | "alle"
  | "nachrichten"
  | "kultur"
  | "alltag"
  | "wissenschaft"
  | "business"
  | "geschichten";

export interface PodcastCategory {
  key: PodcastCategoryKey;
  label: string;
}

export const podcastCategories: PodcastCategory[] = [
  { key: "fuer-dich", label: "Für dich" },
  { key: "alle", label: "Alle" },
  { key: "nachrichten", label: "Nachrichten" },
  { key: "kultur", label: "Kultur" },
  { key: "alltag", label: "Alltag" },
  { key: "wissenschaft", label: "Wissenschaft" },
  { key: "business", label: "Business" },
  { key: "geschichten", label: "Geschichten" },
];

export interface PodcastShow {
  id: string;
  title: string;
  publisher: string;
  tagline: string;
  cover: string; // CSS gradient string, so no external assets needed
  accent: string; // hex, main brand color of the show
  level: CEFR | `${CEFR}-${CEFR}`;
  category: Exclude<PodcastCategoryKey, "fuer-dich" | "alle">;
  episodes: number;
}

export interface TranscriptWord {
  w: string;
  wordId?: string; // linked vocabulary entry
}

export interface TranscriptLine {
  id: string;
  start: number; // seconds
  end: number; // seconds
  speaker?: string;
  words: TranscriptWord[];
  translation: string;
}

export interface PodcastVocab {
  id: string;
  word: string;
  article?: "der" | "die" | "das";
  ipa: string;
  pos: "Nomen" | "Verb" | "Adjektiv" | "Adverb" | "Präposition" | "Ausdruck";
  meaning: string;
  example: string;
  level: CEFR;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface PodcastEpisode {
  id: string;
  showId: string;
  number: number;
  title: string;
  description: string;
  summary: string; // AI summary shown after listening
  cover: string; // CSS gradient (placeholder cover)
  accent: string;
  category: Exclude<PodcastCategoryKey, "fuer-dich" | "alle">;
  level: CEFR | `${CEFR}-${CEFR}`;
  publishedAt: string; // ISO
  durationSec: number;
  waveform: number[]; // 64 samples 0..1
  transcript: TranscriptLine[];
  vocab: PodcastVocab[];
  quiz: QuizQuestion[];
  featured?: boolean;
}

// ---------------------------------------------------------------------------
// Deterministic rng
// ---------------------------------------------------------------------------

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(19700711);

function waveform(seed: number, len = 64): number[] {
  const r = mulberry32(seed);
  const out: number[] = [];
  for (let i = 0; i < len; i++) {
    const env = Math.sin((i / len) * Math.PI) * 0.85 + 0.15;
    out.push(Math.max(0.08, Math.min(1, env * (0.4 + r() * 0.7))));
  }
  return out;
}

function gradient(a: string, b: string, c?: string): string {
  return c
    ? `linear-gradient(135deg, ${a} 0%, ${b} 55%, ${c} 100%)`
    : `linear-gradient(135deg, ${a} 0%, ${b} 100%)`;
}

// ---------------------------------------------------------------------------
// Shows
// ---------------------------------------------------------------------------

export const podcastShows: PodcastShow[] = [
  {
    id: "welt-nachrichten",
    title: "WELT Nachrichten",
    publisher: "WELT",
    tagline: "Tägliche News",
    cover: gradient("#0F1E3A", "#1B2C55"),
    accent: "#1B2C55",
    level: "A2-B1",
    category: "nachrichten",
    episodes: 128,
  },
  {
    id: "easy-german",
    title: "Easy German",
    publisher: "Easy German",
    tagline: "Learn German from the Streets",
    cover: gradient("#F4823B", "#E86A20"),
    accent: "#E86A20",
    level: "A2-B1",
    category: "alltag",
    episodes: 412,
  },
  {
    id: "deutschlandlabor",
    title: "Deutschlandlabor",
    publisher: "Goethe-Institut",
    tagline: "Der Podcast über Deutschland",
    cover: gradient("#1F6FB2", "#2E86C4"),
    accent: "#2E86C4",
    level: "B1-B2",
    category: "kultur",
    episodes: 74,
  },
  {
    id: "slow-german",
    title: "Slow German",
    publisher: "Annik Rubens",
    tagline: "Für besseres Hörverstehen",
    cover: gradient("#4E7A4A", "#6E9E67"),
    accent: "#4E7A4A",
    level: "A2-B1",
    category: "kultur",
    episodes: 268,
  },
  {
    id: "wissen-woche",
    title: "Wissen Woche",
    publisher: "Deutschlandfunk",
    tagline: "Wissenschaft einfach erklärt",
    cover: gradient("#3A2E7A", "#5A45B0"),
    accent: "#3A2E7A",
    level: "B1-B2",
    category: "wissenschaft",
    episodes: 96,
  },
  {
    id: "business-daily",
    title: "Business Daily DE",
    publisher: "Handelsblatt",
    tagline: "Wirtschaft auf den Punkt",
    cover: gradient("#0B3D2E", "#0F5C48"),
    accent: "#0F5C48",
    level: "B2-C1",
    category: "business",
    episodes: 210,
  },
];

// ---------------------------------------------------------------------------
// Episode helpers
// ---------------------------------------------------------------------------

const covers = [
  gradient("#F4823B", "#DC5A16"),
  gradient("#1F4CBF", "#3B82F6"),
  gradient("#0F1E3A", "#3B4A8A"),
  gradient("#4E7A4A", "#82B27C"),
  gradient("#B02A5B", "#E85D8A"),
  gradient("#2E86C4", "#5DADE2"),
  gradient("#8B5CF6", "#B794F4"),
  gradient("#0F5C48", "#22A78F"),
  gradient("#E9A426", "#F7C948"),
  gradient("#D64545", "#F97070"),
];

// A shared vocab pool. Each episode picks a subset.
const vocabPool: PodcastVocab[] = [
  {
    id: "v-nachricht",
    word: "Nachricht",
    article: "die",
    ipa: "ˈnaːxrɪçt",
    pos: "Nomen",
    meaning: "message / news item",
    example: "Die Nachricht kam heute Morgen.",
    level: "A2",
  },
  {
    id: "v-berlin",
    word: "Berlin",
    ipa: "bɛʁˈliːn",
    pos: "Nomen",
    meaning: "capital of Germany",
    example: "Berlin ist die Hauptstadt Deutschlands.",
    level: "A1",
  },
  {
    id: "v-verstehen",
    word: "verstehen",
    ipa: "fɛɐ̯ˈʃteːən",
    pos: "Verb",
    meaning: "to understand",
    example: "Ich verstehe dich sehr gut.",
    level: "A2",
  },
  {
    id: "v-erneuerbar",
    word: "erneuerbar",
    ipa: "ɛɐ̯ˈnɔʏ̯ɐbaːɐ̯",
    pos: "Adjektiv",
    meaning: "renewable",
    example: "Wir nutzen erneuerbare Energien.",
    level: "B1",
  },
  {
    id: "v-energie",
    word: "Energie",
    article: "die",
    ipa: "enɛʁˈɡiː",
    pos: "Nomen",
    meaning: "energy",
    example: "Die Energie ist begrenzt.",
    level: "B1",
  },
  {
    id: "v-wirtschaft",
    word: "Wirtschaft",
    article: "die",
    ipa: "ˈvɪʁtʃaft",
    pos: "Nomen",
    meaning: "economy",
    example: "Die deutsche Wirtschaft wächst.",
    level: "B1",
  },
  {
    id: "v-forschung",
    word: "Forschung",
    article: "die",
    ipa: "ˈfɔʁʃʊŋ",
    pos: "Nomen",
    meaning: "research",
    example: "Die Forschung braucht Zeit.",
    level: "B1",
  },
  {
    id: "v-entwickeln",
    word: "entwickeln",
    ipa: "ɛntˈvɪkəln",
    pos: "Verb",
    meaning: "to develop",
    example: "Wir entwickeln neue Ideen.",
    level: "B1",
  },
  {
    id: "v-alltag",
    word: "Alltag",
    article: "der",
    ipa: "ˈaltaːk",
    pos: "Nomen",
    meaning: "everyday life",
    example: "Im Alltag spricht man anders.",
    level: "A2",
  },
  {
    id: "v-tradition",
    word: "Tradition",
    article: "die",
    ipa: "tʁadiˈtsi̯oːn",
    pos: "Nomen",
    meaning: "tradition",
    example: "Weihnachten ist eine schöne Tradition.",
    level: "A2",
  },
  {
    id: "v-modern",
    word: "modern",
    ipa: "moˈdɛʁn",
    pos: "Adjektiv",
    meaning: "modern",
    example: "Das ist ein moderner Beruf.",
    level: "A2",
  },
  {
    id: "v-veraendern",
    word: "verändern",
    ipa: "fɛɐ̯ˈʔɛndɐn",
    pos: "Verb",
    meaning: "to change",
    example: "Die Welt verändert sich schnell.",
    level: "B1",
  },
  {
    id: "v-gesundheit",
    word: "Gesundheit",
    article: "die",
    ipa: "ɡəˈzʊnthaɪ̯t",
    pos: "Nomen",
    meaning: "health",
    example: "Gesundheit ist das Wichtigste.",
    level: "A2",
  },
  {
    id: "v-umwelt",
    word: "Umwelt",
    article: "die",
    ipa: "ˈʊmvɛlt",
    pos: "Nomen",
    meaning: "environment",
    example: "Wir schützen die Umwelt.",
    level: "A2",
  },
  {
    id: "v-schuetzen",
    word: "schützen",
    ipa: "ˈʃʏtsn̩",
    pos: "Verb",
    meaning: "to protect",
    example: "Wir müssen den Wald schützen.",
    level: "B1",
  },
  {
    id: "v-erklaeren",
    word: "erklären",
    ipa: "ɛɐ̯ˈklɛːʁən",
    pos: "Verb",
    meaning: "to explain",
    example: "Kannst du das erklären?",
    level: "A2",
  },
  {
    id: "v-zukunft",
    word: "Zukunft",
    article: "die",
    ipa: "ˈtsuːkʊnft",
    pos: "Nomen",
    meaning: "future",
    example: "Die Zukunft beginnt jetzt.",
    level: "A2",
  },
  {
    id: "v-arbeit",
    word: "Arbeit",
    article: "die",
    ipa: "ˈaʁbaɪ̯t",
    pos: "Nomen",
    meaning: "work",
    example: "Ich gehe zur Arbeit.",
    level: "A1",
  },
];

function pickVocab(seed: number, n = 6): PodcastVocab[] {
  const r = mulberry32(seed);
  const copy = [...vocabPool].sort(() => r() - 0.5);
  return copy.slice(0, n);
}

function buildTranscript(
  seed: number,
  lines: { s: string; t: string; secLen: number; speaker?: string }[],
): TranscriptLine[] {
  const r = mulberry32(seed);
  const wordMap = new Map(vocabPool.map((v) => [v.word.toLowerCase(), v.id]));
  let cur = 0;
  return lines.map((l, idx) => {
    const tokens = l.s.split(/(\s+)/);
    const words: TranscriptWord[] = tokens
      .filter((t) => t.trim().length > 0)
      .map((t) => {
        const clean = t.replace(/[.,!?"„“„»«]/g, "").toLowerCase();
        return { w: t, wordId: wordMap.get(clean) };
      });
    const start = cur;
    const end = cur + l.secLen + r() * 0.4;
    cur = end + 0.15;
    return {
      id: `l-${idx}`,
      start,
      end,
      speaker: l.speaker,
      words,
      translation: l.t,
    };
  });
}

// A curated pool of episode templates. We extend with generated ones to reach 20+.
const seedEpisodes: Array<
  Omit<PodcastEpisode, "id" | "waveform" | "transcript" | "vocab" | "quiz" | "cover" | "accent"> & {
    transcriptLines: { s: string; t: string; secLen: number; speaker?: string }[];
    coverIdx: number;
  }
> = [
  {
    showId: "welt-nachrichten",
    number: 348,
    title: "Nachrichten aus Deutschland",
    description:
      "Aktuelle Nachrichten einfach erklärt. Perfekt, um dein Hörverständnis mit echten Inhalten zu verbessern.",
    summary:
      "In dieser Folge geht es um die politische Lage in Berlin, neue Umweltgesetze und einen kurzen Ausblick auf das Wetter der Woche. Die Sprecher betonen die Bedeutung erneuerbarer Energien.",
    category: "nachrichten",
    level: "A2-B1",
    publishedAt: "2026-07-11",
    durationSec: 18 * 60 + 45,
    featured: true,
    coverIdx: 2,
    transcriptLines: [
      {
        s: "Guten Morgen und willkommen zu den Nachrichten aus Deutschland.",
        t: "Good morning and welcome to the news from Germany.",
        secLen: 4.2,
        speaker: "Sprecherin",
      },
      {
        s: "Heute sprechen wir über die neue Wirtschaftspolitik in Berlin.",
        t: "Today we're talking about the new economic policy in Berlin.",
        secLen: 3.8,
      },
      {
        s: "Die Regierung will erneuerbare Energien stärker fördern.",
        t: "The government wants to promote renewable energy more strongly.",
        secLen: 3.6,
      },
      {
        s: "Viele Menschen unterstützen diese Entscheidung.",
        t: "Many people support this decision.",
        secLen: 2.9,
      },
      {
        s: "Auch die Umwelt profitiert davon.",
        t: "The environment also benefits from it.",
        secLen: 2.2,
      },
      {
        s: "Bleiben Sie dran für weitere Nachrichten.",
        t: "Stay tuned for more news.",
        secLen: 2.5,
      },
    ],
  },
  {
    showId: "easy-german",
    number: 512,
    title: "Leben in Berlin: Zwischen Tradition und Moderne",
    description:
      "Wir sprechen über das Leben in der Hauptstadt: Wohnen, Arbeiten, Freizeit und Kultur.",
    summary:
      "Zwei Freunde diskutieren, wie sich Berlin verändert hat. Sie sprechen über Mieten, neue Cafés und alte Traditionen, die trotz der Moderne erhalten bleiben.",
    category: "alltag",
    level: "A2-B1",
    publishedAt: "2026-07-10",
    durationSec: 22 * 60,
    coverIdx: 0,
    transcriptLines: [
      {
        s: "Berlin verändert sich sehr schnell.",
        t: "Berlin is changing very quickly.",
        secLen: 2.6,
        speaker: "Anna",
      },
      {
        s: "Ja, das stimmt. Die Mieten sind hoch.",
        t: "Yes, that's right. Rents are high.",
        secLen: 3.0,
        speaker: "Max",
      },
      {
        s: "Aber der Alltag hat auch schöne Seiten.",
        t: "But everyday life also has beautiful sides.",
        secLen: 3.1,
      },
      {
        s: "Ich liebe die kleinen Cafés im Kiez.",
        t: "I love the small cafés in the neighbourhood.",
        secLen: 2.9,
      },
      {
        s: "Tradition und Moderne existieren nebeneinander.",
        t: "Tradition and modernity exist side by side.",
        secLen: 3.4,
      },
    ],
  },
  {
    showId: "wissen-woche",
    number: 45,
    title: "Erneuerbare Energien in Deutschland",
    description: "Wie Deutschland die Energiewende schafft und welche Herausforderungen es gibt.",
    summary:
      "Ein Forscher erklärt den aktuellen Stand der Energiewende. Wind- und Solarkraft wachsen, aber das Netz muss noch verbessert werden.",
    category: "wissenschaft",
    level: "B1-B2",
    publishedAt: "2026-07-09",
    durationSec: 19 * 60,
    coverIdx: 6,
    transcriptLines: [
      {
        s: "Erneuerbare Energien sind die Zukunft.",
        t: "Renewable energy is the future.",
        secLen: 2.8,
        speaker: "Forscher",
      },
      {
        s: "Wind und Sonne sind unsere wichtigsten Quellen.",
        t: "Wind and sun are our most important sources.",
        secLen: 3.3,
      },
      {
        s: "Die Forschung entwickelt bessere Speicher.",
        t: "Research is developing better storage.",
        secLen: 3.1,
      },
      {
        s: "So können wir die Umwelt schützen.",
        t: "That way we can protect the environment.",
        secLen: 2.7,
      },
    ],
  },
  {
    showId: "deutschlandlabor",
    number: 62,
    title: "Kaffee und Kultur",
    description: "Warum ist Kaffee in Deutschland so beliebt und welche Rituale gibt es?",
    summary: "Ein Rundgang durch deutsche Cafékultur, vom Sonntagskuchen bis zum Coffee-to-go.",
    category: "kultur",
    level: "B1-B2",
    publishedAt: "2026-07-08",
    durationSec: 14 * 60,
    coverIdx: 3,
    transcriptLines: [
      {
        s: "Der Kaffee gehört zum deutschen Alltag.",
        t: "Coffee is part of everyday German life.",
        secLen: 3.0,
      },
      {
        s: "Viele treffen sich am Nachmittag im Café.",
        t: "Many meet in the afternoon at the café.",
        secLen: 3.2,
      },
      {
        s: "Kaffee und Kuchen ist eine schöne Tradition.",
        t: "Coffee and cake is a beautiful tradition.",
        secLen: 3.0,
      },
    ],
  },
];

// Extra generated episodes to reach 20+
const extraTitles: Array<{
  showId: string;
  title: string;
  description: string;
  summary: string;
  category: PodcastEpisode["category"];
  level: PodcastEpisode["level"];
  duration: number;
}> = [
  {
    showId: "slow-german",
    title: "Weihnachten in Deutschland",
    description: "Wie Deutsche Weihnachten feiern.",
    summary: "Traditionen rund um Weihnachtsmärkte, Plätzchen und den 24. Dezember.",
    category: "kultur",
    level: "A2",
    duration: 720,
  },
  {
    showId: "slow-german",
    title: "Ein Tag in München",
    description: "Sightseeing durch die bayerische Hauptstadt.",
    summary: "Vom Marienplatz zum Englischen Garten – ein Spaziergang mit Vokabeltipps.",
    category: "kultur",
    level: "A2",
    duration: 900,
  },
  {
    showId: "easy-german",
    title: "Öffentliche Verkehrsmittel verstehen",
    description: "So funktionieren Bus, Tram und U-Bahn.",
    summary: "Wie man Tickets kauft, Fahrpläne liest und Zonen unterscheidet.",
    category: "alltag",
    level: "A1",
    duration: 660,
  },
  {
    showId: "easy-german",
    title: "Beim Arzt: was sage ich?",
    description: "Wichtige Sätze für den Arztbesuch.",
    summary: "Symptome beschreiben, Fragen beantworten und Rezepte verstehen.",
    category: "alltag",
    level: "A2",
    duration: 840,
  },
  {
    showId: "welt-nachrichten",
    title: "Bundestag: Neue Gesetze für 2027",
    description: "Ein Überblick über kommende Reformen.",
    summary: "Kurze Zusammenfassung der wichtigsten Beschlüsse der letzten Sitzung.",
    category: "nachrichten",
    level: "B1",
    duration: 720,
  },
  {
    showId: "welt-nachrichten",
    title: "Wetter der Woche",
    description: "Meteorologin erklärt die Wetterlage.",
    summary: "Tiefdruckgebiete, Temperaturen und Regenwahrscheinlichkeit im Detail.",
    category: "nachrichten",
    level: "A2",
    duration: 480,
  },
  {
    showId: "wissen-woche",
    title: "Wie funktioniert das Gehirn?",
    description: "Ein Neurowissenschaftler erklärt.",
    summary: "Wie Erinnerungen entstehen und warum Schlaf wichtig für das Lernen ist.",
    category: "wissenschaft",
    level: "B2",
    duration: 1140,
  },
  {
    showId: "wissen-woche",
    title: "Klimawandel und Nordsee",
    description: "Was verändert sich an der Küste?",
    summary: "Meeresspiegel steigt, Ökosysteme verschieben sich, Fischer berichten.",
    category: "wissenschaft",
    level: "B1",
    duration: 960,
  },
  {
    showId: "business-daily",
    title: "Startups in Berlin",
    description: "Warum die Hauptstadt Gründer anzieht.",
    summary: "Von der Idee bis zur Series-A – Interviews mit drei Berliner Startups.",
    category: "business",
    level: "B2",
    duration: 1080,
  },
  {
    showId: "business-daily",
    title: "Der DAX unter der Lupe",
    description: "Aktuelle Trends an der Frankfurter Börse.",
    summary: "Welche Branchen wachsen und wo Anleger vorsichtig sein sollten.",
    category: "business",
    level: "C1",
    duration: 900,
  },
  {
    showId: "deutschlandlabor",
    title: "Feste und Feiertage",
    description: "Ein Kalender durchs Jahr.",
    summary: "Karneval, Ostern, Oktoberfest – regionale Unterschiede erklärt.",
    category: "kultur",
    level: "B1",
    duration: 780,
  },
  {
    showId: "deutschlandlabor",
    title: "Deutsche Musikszene heute",
    description: "Von Rammstein bis Berlin-Techno.",
    summary: "Wie sich die deutsche Popmusik in den letzten 20 Jahren verändert hat.",
    category: "kultur",
    level: "B2",
    duration: 1020,
  },
  {
    showId: "slow-german",
    title: "Reisen mit der Deutschen Bahn",
    description: "Tipps für stressfreies Zugfahren.",
    summary: "Reservierung, Sparpreise, Umsteigen und was tun bei Verspätung.",
    category: "alltag",
    level: "A2",
    duration: 720,
  },
  {
    showId: "easy-german",
    title: "Wortschatz: Freundschaft",
    description: "Vokabeln rund um Freunde und Beziehungen.",
    summary: "Redewendungen und typische Sätze für den Freundeskreis.",
    category: "alltag",
    level: "A2",
    duration: 540,
  },
  {
    showId: "welt-nachrichten",
    title: "EU-Gipfel: die Ergebnisse",
    description: "Beschlüsse der europäischen Regierungschefs.",
    summary: "Migration, Verteidigung und Wirtschaft standen im Mittelpunkt.",
    category: "nachrichten",
    level: "B2",
    duration: 660,
  },
  {
    showId: "wissen-woche",
    title: "Künstliche Intelligenz im Alltag",
    description: "Wo KI heute schon hilft.",
    summary: "Sprachmodelle, Bilderkennung und Assistenten – Chancen und Grenzen.",
    category: "wissenschaft",
    level: "B2",
    duration: 1200,
  },
];

// ---------------------------------------------------------------------------
// Assemble episodes
// ---------------------------------------------------------------------------

export const podcastEpisodes: PodcastEpisode[] = [
  ...seedEpisodes.map((e, i) => {
    const cover = covers[e.coverIdx % covers.length];
    return {
      id: `ep-${i + 1}`,
      showId: e.showId,
      number: e.number,
      title: e.title,
      description: e.description,
      summary: e.summary,
      cover,
      accent: podcastShows.find((s) => s.id === e.showId)?.accent ?? "#DD2222",
      category: e.category,
      level: e.level,
      publishedAt: e.publishedAt,
      durationSec: e.durationSec,
      waveform: waveform(1000 + i * 17, 96),
      transcript: buildTranscript(2000 + i * 11, e.transcriptLines),
      vocab: pickVocab(3000 + i * 7, 8),
      quiz: buildQuiz(i, e.title),
      featured: e.featured,
    } as PodcastEpisode;
  }),
  ...extraTitles.map((e, i) => {
    const idx = i + 100;
    const show = podcastShows.find((s) => s.id === e.showId)!;
    return {
      id: `ep-${idx}`,
      showId: e.showId,
      number: 300 - i,
      title: e.title,
      description: e.description,
      summary: e.summary,
      cover: covers[(idx + Math.floor(rand() * 5)) % covers.length],
      accent: show.accent,
      category: e.category,
      level: e.level,
      publishedAt: `2026-07-${String(8 - (i % 8)).padStart(2, "0")}`,
      durationSec: e.duration,
      waveform: waveform(4000 + idx * 13, 96),
      transcript: buildTranscript(5000 + idx * 9, [
        {
          s: `Willkommen zur Folge über ${e.title}.`,
          t: `Welcome to the episode about ${e.title}.`,
          secLen: 3.2,
          speaker: "Host",
        },
        { s: e.description, t: "Description read as intro.", secLen: 4.5 },
        {
          s: "Wir sprechen heute über die wichtigsten Punkte.",
          t: "Today we talk about the most important points.",
          secLen: 3.4,
        },
        {
          s: "Bleib dran und viel Spaß beim Zuhören.",
          t: "Stay tuned and enjoy listening.",
          secLen: 2.6,
        },
      ]),
      vocab: pickVocab(6000 + idx * 5, 6),
      quiz: buildQuiz(idx, e.title),
    } as PodcastEpisode;
  }),
];

function buildQuiz(seed: number, title: string): QuizQuestion[] {
  return [
    {
      id: `q-${seed}-1`,
      question: `Worum geht es hauptsächlich in "${title}"?`,
      options: [
        "Um Sport in Deutschland",
        "Um das Thema der Episode",
        "Um Kochrezepte",
        "Um Reisen nach Asien",
      ],
      answerIndex: 1,
      explanation: "Der Titel gibt bereits einen klaren Hinweis auf das Hauptthema.",
    },
    {
      id: `q-${seed}-2`,
      question: "Welche Aussage passt zum Inhalt?",
      options: [
        "Es wird nur eine Person interviewt.",
        "Der Sprecher gibt Beispiele aus dem Alltag.",
        "Es geht ausschließlich um Zahlen.",
        "Nichts davon.",
      ],
      answerIndex: 1,
      explanation: "In den meisten DEUSI-Folgen werden Alltagssituationen als Beispiele genutzt.",
    },
    {
      id: `q-${seed}-3`,
      question: "Wie lang ist eine typische Folge?",
      options: ["Weniger als 2 Minuten", "5 bis 25 Minuten", "Über 2 Stunden", "Genau 60 Minuten"],
      answerIndex: 1,
      explanation: "DEUSI-Folgen dauern in der Regel zwischen 5 und 25 Minuten.",
    },
  ];
}

// ---------------------------------------------------------------------------
// Continue Listening — currently in progress
// ---------------------------------------------------------------------------

export interface ProgressEntry {
  episodeId: string;
  positionSec: number;
  updatedAt: string;
}

export const continueListening: ProgressEntry[] = [
  { episodeId: "ep-2", positionSec: 10 * 60, updatedAt: "2026-07-11" },
  { episodeId: "ep-4", positionSec: 7 * 60, updatedAt: "2026-07-11" },
  { episodeId: "ep-3", positionSec: 16 * 60, updatedAt: "2026-07-10" },
];

// ---------------------------------------------------------------------------
// Listening statistics for the right-hand card
// ---------------------------------------------------------------------------

export const listeningStats = {
  weekly: {
    totalMinutes: 272, // 4h 32m
    deltaMinutes: 72, // +1h 12m
    episodes: 12,
    deltaEpisodes: 3,
    newWords: 86,
    deltaWords: 24,
    comprehension: 78, // %
    deltaComprehension: 8,
  },
  perDay: [
    { day: "Mo", minutes: 22 },
    { day: "Di", minutes: 34 },
    { day: "Mi", minutes: 28 },
    { day: "Do", minutes: 43 },
    { day: "Fr", minutes: 30 },
    { day: "Sa", minutes: 55 },
    { day: "So", minutes: 60 },
  ],
};

// ---------------------------------------------------------------------------
// AI recommended topics
// ---------------------------------------------------------------------------

export const recommendedTopics: string[] = [
  "Umwelt",
  "Technologie",
  "Kultur",
  "Gesellschaft",
  "Reisen",
  "Bildung",
  "Geschichte",
];

// ---------------------------------------------------------------------------
// Utility selectors
// ---------------------------------------------------------------------------

export function findEpisode(id: string): PodcastEpisode | undefined {
  return podcastEpisodes.find((e) => e.id === id);
}

export function findShow(id: string): PodcastShow | undefined {
  return podcastShows.find((s) => s.id === id);
}

export function featuredEpisode(): PodcastEpisode {
  return podcastEpisodes.find((e) => e.featured) ?? podcastEpisodes[0];
}

export function popularShows(): PodcastShow[] {
  return podcastShows.slice(0, 6);
}
