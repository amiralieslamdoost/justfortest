import type { SongVocab } from "@/lib/deusi/mockMusic";
import type { Word } from "@/lib/deusi/types";

/**
 * Converts a song vocabulary entry into a DEUSI `Word` so it can be pushed
 * into the user's Leitner deck via `addCustomWord`.
 */
export function songVocabToWord(v: SongVocab, songTitle: string): Word {
  const id = `musik-${v.id}`;
  const example = `${v.example} — „${songTitle}“`;

  if (v.pos === "noun") {
    return {
      id,
      pos: "noun",
      article: v.article ?? "die",
      singular: v.term,
      plural: v.plural ?? v.term,
      translation: v.translation,
      example,
      createdBy: "musik",
    };
  }

  if (v.pos === "verb") {
    const stem = v.term.replace(/en$/, "");
    return {
      id,
      pos: "verb",
      infinitive: v.term,
      praeteritum: v.praeteritum ?? `${stem}te`,
      perfekt: v.perfekt ?? `hat ge${stem}t`,
      aux: (v.perfekt ?? "").startsWith("ist") ? "sein" : "haben",
      praesens: {
        ich: `${stem}e`,
        du: `${stem}st`,
        er: `${stem}t`,
        wir: v.term,
        ihr: `${stem}t`,
        sie: v.term,
      },
      praeteritumConj: {
        ich: `${stem}te`,
        du: `${stem}test`,
        er: `${stem}te`,
        wir: `${stem}ten`,
        ihr: `${stem}tet`,
        sie: `${stem}ten`,
      },
      perfektConj: {
        ich: v.perfekt ?? "",
        du: v.perfekt ?? "",
        er: v.perfekt ?? "",
        wir: v.perfekt ?? "",
        ihr: v.perfekt ?? "",
        sie: v.perfekt ?? "",
      },
      translation: v.translation,
      example,
      createdBy: "musik",
    };
  }

  return {
    id,
    pos: "adjective",
    positive: v.term,
    comparative: v.comparative ?? `${v.term}er`,
    superlative: v.superlative ?? `am ${v.term}sten`,
    translation: v.translation,
    example,
    createdBy: "musik",
  };
}
