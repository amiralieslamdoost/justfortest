export type CommunityLevel = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type CommunityUser = {
  id: string;
  name: string;
  /** Public @id used for search / invites */
  handle: string;
  /** Two-letter initials used for the avatar */
  initials: string;
  level: CommunityLevel;
  /** Hex accent for the avatar tint */
  color: string;
  online?: boolean;
};

/** room = öffentlicher Talar, group = eigene Gruppe, dm = privater Chat */
export type ChatKind = "room" | "group" | "dm";

export type Message = {
  id: string;
  /** "me" or a user id from COMMUNITY_USERS */
  authorId: string;
  body: string;
  time: string;
  /** Optional day separator shown above this message */
  day?: string;
  /** Data-URL of an attached image */
  imageUrl?: string;
  /** Id of the message this one replies to */
  replyToId?: string;
  /** Soft-deleted message (shows a placeholder) */
  deleted?: boolean;
};

export type Chat = {
  id: string;
  kind: ChatKind;
  title: string;
  titleFa?: string;
  description?: string;
  /** Hex accent driving avatar / cover tint */
  color: string;
  /** Short emoji used as the room / group avatar */
  emoji?: string;
  /** Member ids (without me) */
  members: string[];
  joined: boolean;
  private?: boolean;
  unread: number;
  lastTime: string;
  messages: Message[];
  /** Only for kind === "dm" */
  partnerId?: string;
  /** Owner / admin of a room or group ("me" = ich darf Einstellungen ändern) */
  ownerId?: string;
};

/** Kleinanzeige für Sprechpartner */
export type TandemProfile = {
  id: string;
  userId: string;
  /** Überschrift der Anzeige */
  headline: string;
  nativeLanguage: string;
  level: CommunityLevel;
  goal: string;
  availability: string;
  /** Freitext des Inserenten */
  description: string;
  /** Anzeige wurde von "me" erstellt */
  mine?: boolean;
};
