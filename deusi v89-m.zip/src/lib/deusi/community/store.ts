import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import { COMMUNITY_USERS, getUser, registerUsers } from "./mockCommunity";
import type { Chat, CommunityUser, TandemProfile } from "./types";
import * as api from "@/lib/api/community";
import type { CommunitySnapshot, Draft, ReportReason, ReportTarget } from "@/lib/api/community";
import { useDeusi } from "@/lib/deusi/store";

export type { Draft } from "@/lib/api/community";
export { REPORT_REASONS } from "@/lib/api/community";
export type { ReportReason, ReportTarget } from "@/lib/api/community";

/**
 * Chat-Store.
 *
 * Der Store hält einen gemeinsamen Snapshot (Chats, Tandem-Anzeigen,
 * blockierte Nutzer) und delegiert Lesen/Schreiben an die Datenschicht
 * (`@/lib/api/community`: PocketBase, sonst lokaler Spiegel).
 */

let snapshot: CommunitySnapshot = { chats: [], ads: [], blocked: [] };
let activeUserId = "";
let loading = false;
const listeners = new Set<() => void>();

function emit(next: CommunitySnapshot) {
  snapshot = { chats: [...next.chats], ads: [...next.ads], blocked: [...next.blocked] };
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

const getSnapshot = () => snapshot;

async function refresh(userId: string) {
  if (loading) return;
  loading = true;
  try {
    emit(await api.loadCommunity(userId));
  } finally {
    loading = false;
  }
}

/** Users searchable by @handle or name (without me). */
export function searchUsers(query: string): CommunityUser[] {
  const q = query.trim().toLowerCase().replace(/^@/, "");
  if (!q) return [];
  return Object.values(COMMUNITY_USERS).filter(
    (u) =>
      u.id !== "me" && (u.handle.toLowerCase().includes(q) || u.name.toLowerCase().includes(q)),
  );
}

/** Suche über lokales Verzeichnis + Backend-Profile (debounced). */
export function useUserSearch(query: string): CommunityUser[] {
  const [results, setResults] = useState<CommunityUser[]>(() => searchUsers(query));

  useEffect(() => {
    setResults(searchUsers(query));
    if (!query.trim()) return;
    let cancelled = false;
    const timer = setTimeout(async () => {
      const remote = await api.searchProfiles(query);
      if (cancelled || !remote.length) return;
      registerUsers(remote);
      setResults(searchUsers(query));
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  return results;
}

export function useCommunity() {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const state = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);

  // Erstes Laden + Wechsel des angemeldeten Nutzers.
  useEffect(() => {
    if (activeUserId === userId && (state.chats.length > 0 || loading)) return;
    activeUserId = userId;
    void refresh(userId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  // Live-Updates aus dem Backend (neue Nachrichten, Anzeigen, Chats).
  useEffect(() => {
    if (!userId) return;
    return api.subscribeCommunity(userId, () => {
      void refresh(userId);
    });
  }, [userId]);

  const run = useCallback(
    (fn: (uid: string) => Promise<CommunitySnapshot>) => {
      void fn(userId).then(emit);
    },
    [userId],
  );

  const sendMessage = useCallback(
    (chatId: string, draft: Draft) => run((uid) => api.sendMessage(uid, chatId, draft)),
    [run],
  );

  const deleteMessage = useCallback(
    (chatId: string, messageId: string) => run((uid) => api.deleteMessage(uid, chatId, messageId)),
    [run],
  );

  const markRead = useCallback(
    (chatId: string) => {
      const chat = snapshot.chats.find((c) => c.id === chatId);
      if (!chat || chat.unread === 0) return;
      run((uid) => api.markRead(uid, chatId));
    },
    [run],
  );

  const toggleJoined = useCallback(
    (chatId: string) => {
      const chat = snapshot.chats.find((c) => c.id === chatId);
      if (!chat) return;
      run((uid) => api.setChatMembership(uid, chatId, !chat.joined));
    },
    [run],
  );

  const addMember = useCallback(
    (chatId: string, memberId: string) => run((uid) => api.addMember(uid, chatId, memberId)),
    [run],
  );

  const removeMember = useCallback(
    (chatId: string, memberId: string) => run((uid) => api.removeMember(uid, chatId, memberId)),
    [run],
  );

  const updateChat = useCallback(
    (chatId: string, input: api.ChatPatch) => run((uid) => api.updateChat(uid, chatId, input)),
    [run],
  );

  const createGroup = useCallback(
    (input: { name: string; description: string; private: boolean }) => {
      const id = api.newLocalId("local-group");
      void api
        .createGroup(userId, input, id)
        .then(({ snapshot: snap }) => emit(snap))
        .catch((err) => console.warn("[community] createGroup failed", err));
      // Der Store vergibt die Id synchron, damit die UI sofort navigieren kann.
      return id;
    },
    [userId],
  );

  const openDirectChat = useCallback(
    (partnerId: string) => {
      const existing = snapshot.chats.find((c) => c.kind === "dm" && c.partnerId === partnerId);
      if (existing) return existing.id;
      const partner = getUser(partnerId);
      const id = `local-dm-${partnerId}`;
      void api.openDirectChat(userId, partner, id).then(({ snapshot: snap }) => emit(snap));
      return id;
    },
    [userId],
  );

  const createAd = useCallback(
    (input: Omit<TandemProfile, "id" | "userId" | "mine">) => {
      void api.createTandemAd(userId, input).then(emit);
    },
    [userId],
  );

  const deleteAd = useCallback((id: string) => run((uid) => api.deleteTandemAd(uid, id)), [run]);

  const reportContent = useCallback(
    (input: {
      targetType: ReportTarget;
      targetId: string;
      reason: ReportReason;
      details?: string;
    }) => api.reportContent(userId, input),
    [userId],
  );

  const blockUser = useCallback(
    (targetUserId: string) => run((uid) => api.setBlocked(uid, targetUserId, true)),
    [run],
  );

  const unblockUser = useCallback(
    (targetUserId: string) => run((uid) => api.setBlocked(uid, targetUserId, false)),
    [run],
  );

  const isBlocked = useCallback(
    (targetUserId: string) => state.blocked.includes(targetUserId),
    [state.blocked],
  );

  // Nachrichten blockierter Mitglieder werden ausgeblendet.
  const chats: Chat[] = state.blocked.length
    ? state.chats
        .filter((c) => !(c.kind === "dm" && c.partnerId && state.blocked.includes(c.partnerId)))
        .map((c) => ({
          ...c,
          messages: c.messages.filter((m) => !state.blocked.includes(m.authorId)),
        }))
    : state.chats;

  const tandemAds = state.blocked.length
    ? state.ads.filter((a) => !state.blocked.includes(a.userId))
    : state.ads;

  return {
    chats,
    tandemAds,
    blocked: state.blocked,
    sendMessage,
    deleteMessage,
    markRead,
    toggleJoined,
    addMember,
    updateChat,
    removeMember,
    createGroup,
    openDirectChat,
    createAd,
    deleteAd,
    reportContent,
    blockUser,
    unblockUser,
    isBlocked,
  };
}
