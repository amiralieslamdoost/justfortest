import type { SectionKey } from "@/lib/deusi/sectionTheme";

/**
 * Maps a URL pathname to the owning top-level section, so the whole page
 * (not just its header) can inherit that section's color identity.
 * Order matters: longest / most specific prefixes first.
 */
const ROUTE_SECTIONS: Array<[string, SectionKey]> = [
  ["/dashboard", "dashboard"],
  ["/planer", "planner"],
  ["/onboarding", "planner"],
  ["/dictionary", "dictionary"],
  ["/ki-coach", "ai-coach"],
  ["/grammatik", "grammar"],
  ["/schreiben", "writing"],
  ["/verben", "verbs"],
  ["/learn", "flashcards"],
  ["/leitner", "leitner"],
  ["/lesen", "reading"],
  ["/books", "reading"],
  ["/podcasts", "podcasts"],
  ["/musik", "music"],
  ["/kino", "movies"],
  ["/events", "events"],
  ["/community", "community"],
  ["/statistiken", "statistics"],
  ["/pruefungen", "exams"],
  ["/profil", "profile"],
];

export function sectionForPath(pathname: string): SectionKey | null {
  for (const [prefix, key] of ROUTE_SECTIONS) {
    if (
      pathname === prefix ||
      pathname.startsWith(`${prefix}/`) ||
      pathname.startsWith(`${prefix}_`)
    ) {
      return key;
    }
  }
  return null;
}
