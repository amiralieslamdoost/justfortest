/**
 * پاسخ‌های نمونهٔ KI-Coach برای حالت MOCK (بدون بک‌اند/پروکسی).
 * این منطق قبلاً داخل `src/routes/ki-coach.tsx` بود و در سشن ۱۰ به اینجا
 * منتقل شد تا روت فقط با لایهٔ داده کار کند.
 */
export function generateReply(input: string): string {
  const q = input.toLowerCase();
  if (q.includes("seit") && q.includes("vor"))
    return "**seit** → ein Zeitpunkt in der Vergangenheit, der bis jetzt andauert.\n_Ich lerne **seit** zwei Monaten Deutsch._\n\n**vor** → ein abgeschlossener Zeitpunkt.\n_Ich bin **vor** zwei Monaten gekommen._";
  if (q.includes("konjunktiv"))
    return "Konjunktiv II drückt **Wünsche, Höflichkeit oder Irreales** aus.\n\n- _Ich **hätte** gern einen Kaffee._\n- _Wenn ich Zeit **hätte**, **würde** ich reisen._";
  if (q.includes("korrigier") || q.includes("gefahrt"))
    return "❌ _Ich bin gestern in Berlin **gefahrt**._\n✅ _Ich bin gestern **nach** Berlin **gefahren**._\n\n**Warum?** Partizip II von _fahren_ ist _gefahren_, und Richtung mit _nach_ + Stadt.";
  if (q.includes("vokabel") || q.includes("arbeit"))
    return "5 Wörter zum Thema **Arbeit**:\n\n1. **die Bewerbung**\n2. **der Lebenslauf**\n3. **die Kollegin / der Kollege**\n4. **der Termin**\n5. **die Besprechung**";
  if (q.includes("sprechen") || q.includes("hobby") || q.includes("hobbys"))
    return "Gerne! 🎤 Erzähl mir: **Welche Hobbys hast du, und wie oft machst du sie?**\n\nTipp: Nutze Konnektoren wie _außerdem, obwohl, weil_.";
  if (q.includes("brief") || q.includes("formell"))
    return "Aufbau eines formellen Briefs:\n\n1. **Anrede** – _Sehr geehrte Damen und Herren,_\n2. **Einleitung**\n3. **Hauptteil**\n4. **Schluss**\n5. _Mit freundlichen Grüßen_";
  return "Ich kann dir bei **Grammatik, Wortschatz, Schreiben, Sprechen und Prüfungen** helfen. Stell mir einfach deine Frage — oder wähle unten einen Vorschlag.";
}
