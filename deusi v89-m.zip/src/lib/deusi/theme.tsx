import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

type Theme = "light" | "dark";
const Ctx = createContext<{
  theme: Theme;
  toggle: () => void;
  setTheme: (t: Theme | "system") => void;
} | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>("light");

  useEffect(() => {
    try {
      const stored = localStorage.getItem("deusi.theme") as Theme | null;
      // Default to light mode — only follow stored preference if the user
      // explicitly chose one before.
      const initial: Theme = stored ?? "light";
      setTheme(initial);
    } catch {
      /* noop */
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    try {
      localStorage.setItem("deusi.theme", theme);
    } catch {
      /* noop */
    }
  }, [theme]);

  const applyTheme = (t: Theme | "system") => {
    if (t === "system") {
      const sys: Theme =
        typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light";
      setTheme(sys);
    } else {
      setTheme(t);
    }
  };
  return (
    <Ctx.Provider
      value={{
        theme,
        toggle: () => setTheme((t) => (t === "dark" ? "light" : "dark")),
        setTheme: applyTheme,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useTheme() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useTheme must be inside ThemeProvider");
  return v;
}
