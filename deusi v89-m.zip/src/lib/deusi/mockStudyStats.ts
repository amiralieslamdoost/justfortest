// ---------------------------------------------------------------------------
// DEUSI — Study-time statistics (demo data).
//
// Everything here is modelled on features that actually exist in DEUSI:
// dictionary, Leitner, flashcards, grammar, verbs, writing, reading,
// podcasts, music, movies, AI coach and exams.
//
// The shape mirrors what a `study_sessions` table would return, so this file
// can later be swapped for a real `fetchStudyStats()` call without touching
// the UI.
// ---------------------------------------------------------------------------

import type { SectionKey } from "@/lib/deusi/sectionTheme";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";

export type StudyModuleKey = Extract<
  SectionKey,
  | "dictionary"
  | "leitner"
  | "flashcards"
  | "grammar"
  | "verbs"
  | "writing"
  | "reading"
  | "podcasts"
  | "music"
  | "movies"
  | "ai-coach"
  | "exams"
>;

export interface StudyDay {
  date: string; // ISO yyyy-mm-dd
  minutes: number;
  sessions: number;
  cardsReviewed: number;
  wordsSaved: number;
  byModule: Record<StudyModuleKey, number>;
}

export interface ModuleTimeSlice {
  key: StudyModuleKey;
  label: string;
  labelFa: string;
  href: string;
  color: string;
  minutes: number;
  share: number; // 0-100
}

export interface HourBucket {
  hour: number; // 0..23
  minutes: number;
}

export interface MonthPoint {
  label: string;
  minutes: number;
  words: number;
}

// --------------------------------------------------------------- module meta

type ModuleMeta = { key: StudyModuleKey; href: string; weight: number };

const MODULES: ModuleMeta[] = [
  { key: "dictionary", href: "/dictionary", weight: 1.0 },
  { key: "leitner", href: "/leitner", weight: 1.15 },
  { key: "flashcards", href: "/learn", weight: 0.75 },
  { key: "grammar", href: "/grammatik", weight: 0.95 },
  { key: "verbs", href: "/verben", weight: 0.4 },
  { key: "writing", href: "/schreiben", weight: 0.45 },
  { key: "reading", href: "/lesen", weight: 0.8 },
  { key: "podcasts", href: "/podcasts", weight: 0.7 },
  { key: "music", href: "/musik", weight: 0.5 },
  { key: "movies", href: "/kino", weight: 0.35 },
  { key: "ai-coach", href: "/ki-coach", weight: 0.55 },
  { key: "exams", href: "/pruefungen", weight: 0.3 },
];

export const MODULE_KEYS = MODULES.map((m) => m.key);

const emptyByModule = (): Record<StudyModuleKey, number> =>
  MODULES.reduce(
    (acc, m) => {
      acc[m.key] = 0;
      return acc;
    },
    {} as Record<StudyModuleKey, number>,
  );

// -------------------------------------------------- deterministic randomness

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(20260807);

function isoDay(d: Date) {
  const y = d.getFullYear();
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// ------------------------------------------------------------------- profile

export const studyProfile = {
  dailyGoalMinutes: 45,
  /** consecutive days with at least one session */
  streakDays: 0, // filled below
  longestStreak: 0, // filled below
  totalMinutes: 0, // filled below
  totalSessions: 0, // filled below
  firstDay: "", // filled below
};

// --------------------------------------------------------- 365 days of study

export const studyDays: StudyDay[] = (() => {
  const out: StudyDay[] = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (let i = 364; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const weekday = d.getDay(); // 0 Sun … 6 Sat

    const growth = (365 - i) / 365; // learner ramps up over the year
    const base = 14 + growth * 34;
    const weekend = weekday === 0 || weekday === 6 ? -9 : 0;
    const midWeek = weekday === 2 || weekday === 3 ? 9 : 0;
    const noise = (rand() - 0.5) * 20;
    const off = i === 0 ? false : rand() < 0.11; // today always has a session

    const minutes = off ? 0 : Math.max(5, Math.round(base + weekend + midWeek + noise));

    const byModule = emptyByModule();
    let sessions = 0;

    if (minutes > 0) {
      // pick 2–4 modules for the day, weighted
      const picks: ModuleMeta[] = [];
      const pool = [...MODULES];
      const count = 2 + Math.floor(rand() * 3);
      for (let n = 0; n < count && pool.length; n++) {
        const total = pool.reduce((s, m) => s + m.weight, 0);
        let r = rand() * total;
        let idx = 0;
        for (let k = 0; k < pool.length; k++) {
          r -= pool[k].weight;
          if (r <= 0) {
            idx = k;
            break;
          }
        }
        picks.push(pool.splice(idx, 1)[0]);
      }

      const shares = picks.map(() => 0.4 + rand());
      const sum = shares.reduce((s, x) => s + x, 0);
      let assigned = 0;
      picks.forEach((m, k) => {
        const part =
          k === picks.length - 1 ? minutes - assigned : Math.round((shares[k] / sum) * minutes);
        byModule[m.key] = Math.max(0, part);
        assigned += part;
      });
      sessions = picks.length;
    }

    const cardsReviewed =
      minutes === 0 ? 0 : Math.round((byModule.leitner + byModule.flashcards) * 2.1 + rand() * 5);
    const wordsSaved =
      minutes === 0 ? 0 : Math.round((byModule.dictionary + byModule.reading) * 0.35 + rand() * 2);

    out.push({ date: isoDay(d), minutes, sessions, cardsReviewed, wordsSaved, byModule });
  }
  return out;
})();

// ------------------------------------------------------------ profile totals

(() => {
  studyProfile.totalMinutes = studyDays.reduce((s, d) => s + d.minutes, 0);
  studyProfile.totalSessions = studyDays.reduce((s, d) => s + d.sessions, 0);
  studyProfile.firstDay = studyDays[0]?.date ?? "";

  let cur = 0;
  for (let i = studyDays.length - 1; i >= 0; i--) {
    if (studyDays[i].minutes > 0) cur++;
    else break;
  }
  studyProfile.streakDays = cur;

  let best = 0;
  let run = 0;
  for (const d of studyDays) {
    run = d.minutes > 0 ? run + 1 : 0;
    if (run > best) best = run;
  }
  studyProfile.longestStreak = best;
})();

/** Today's minutes (last entry). */
export const todayMinutes = studyDays[studyDays.length - 1]?.minutes ?? 0;

/** Last 7 days, oldest → newest. */
export const last7Days = studyDays.slice(-7);

// ------------------------------------------------------------------ helpers

export function sliceDays(days: number): StudyDay[] {
  return studyDays.slice(-Math.min(days, studyDays.length));
}

export function moduleBreakdown(days: StudyDay[]): ModuleTimeSlice[] {
  const totals = emptyByModule();
  for (const d of days) {
    for (const m of MODULES) totals[m.key] += d.byModule[m.key];
  }
  const grand = Object.values(totals).reduce((s, x) => s + x, 0) || 1;
  return MODULES.map((m) => {
    const theme = SECTION_THEME[m.key];
    return {
      key: m.key,
      label: theme.label,
      labelFa: theme.labelFa,
      href: m.href,
      color: theme.primary,
      minutes: totals[m.key],
      share: Math.round((totals[m.key] / grand) * 100),
    };
  })
    .filter((m) => m.minutes > 0)
    .sort((a, b) => b.minutes - a.minutes);
}

/** 7 rows (Mo..So) × N weeks, normalised 0..1 by study minutes. */
export function studyHeatmap(days: StudyDay[]): { grid: number[][]; months: string[] } {
  const weeks = Math.max(1, Math.ceil(days.length / 7));
  const grid: number[][] = Array.from({ length: 7 }, () => Array(weeks).fill(0));
  const max = Math.max(...days.map((d) => d.minutes), 1);
  const months: string[] = [];

  days.forEach((d, i) => {
    const date = new Date(d.date);
    const jsDay = date.getDay();
    const row = (jsDay + 6) % 7; // Mo = 0
    const col = Math.floor(i / 7);
    if (col < weeks) grid[row][col] = d.minutes / max;
  });

  const step = Math.max(1, Math.floor(days.length / 6));
  for (let i = 0; i < days.length; i += step) {
    const label = MONTHS_DE[new Date(days[i].date).getMonth()];
    if (months[months.length - 1] !== label) months.push(label);
  }

  return { grid, months: months.length ? months : ["—"] };
}

export const MONTHS_DE = [
  "Jan",
  "Feb",
  "Mär",
  "Apr",
  "Mai",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Okt",
  "Nov",
  "Dez",
];

export function monthlyTotals(days: StudyDay[]): MonthPoint[] {
  const buckets = new Map<string, MonthPoint>();
  for (const d of days) {
    const date = new Date(d.date);
    const key = `${date.getFullYear()}-${date.getMonth()}`;
    const cur = buckets.get(key) ?? { label: MONTHS_DE[date.getMonth()], minutes: 0, words: 0 };
    cur.minutes += d.minutes;
    cur.words += d.wordsSaved;
    buckets.set(key, cur);
  }
  return Array.from(buckets.values());
}

/** Format minutes as "12h 45m" / "45m". */
export function formatMinutes(total: number): string {
  const h = Math.floor(total / 60);
  const m = Math.round(total % 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

// ---------------------------------------------------- time of day (24 hours)

export const hourBuckets: HourBucket[] = (() => {
  // Typical learner: short morning burst, lunch dip, strong evening block.
  const shape = [
    0, 0, 0, 0, 0, 0.05, 0.2, 0.5, 0.65, 0.4, 0.25, 0.2, 0.3, 0.25, 0.2, 0.25, 0.35, 0.5, 0.75,
    0.95, 0.9, 0.6, 0.3, 0.1,
  ];
  const totalWeek = last7Days.reduce((s, d) => s + d.minutes, 0);
  const sum = shape.reduce((s, x) => s + x, 0) || 1;
  return shape.map((v, hour) => ({
    hour,
    minutes: Math.round((v / sum) * totalWeek),
  }));
})();

// -------------------------------------------------------------- Leitner view

export interface LeitnerBucket {
  box: number;
  label: string;
  cards: number;
  color: string;
}

export const leitnerBoxes: LeitnerBucket[] = [
  { box: 1, label: "Neu", cards: 128, color: "#EF4444" },
  { box: 2, label: "Lernend", cards: 214, color: "#F97316" },
  { box: 3, label: "Vertraut", cards: 352, color: "#F7C948" },
  { box: 4, label: "Gefestigt", cards: 386, color: "#84CC16" },
  { box: 5, label: "Beherrscht", cards: 165, color: "#22C55E" },
];

export const leitnerDueToday = 42;

// -------------------------------------------------------------- Grammar view

export const grammarTopics = [
  { name: "Präsens", mastery: 92, color: "#22C55E" },
  { name: "Perfekt", mastery: 78, color: "#84CC16" },
  { name: "Präteritum", mastery: 66, color: "#F7C948" },
  { name: "Präpositionen", mastery: 58, color: "#8B5CF6" },
  { name: "Konjunktiv II", mastery: 45, color: "#F59E0B" },
  { name: "Passiv", mastery: 37, color: "#F97316" },
  { name: "Relativsätze", mastery: 31, color: "#EF4444" },
];

// ------------------------------------------------------------- range presets

export const dateRanges = [
  { key: "7d", label: "Letzte 7 Tage", days: 7 },
  { key: "4w", label: "Letzte 4 Wochen", days: 28 },
  { key: "6m", label: "Letzte 6 Monate", days: 182 },
  { key: "1y", label: "Letztes Jahr", days: 365 },
] as const;

export type DateRangeKey = (typeof dateRanges)[number]["key"];
