/**
 * موتور نمره‌دهی آزمون‌ها (خالص، بدون وابستگی به مرورگر) — سشن ۶.
 */
import type { ExamQuestion, ModelltestSection } from "./exams/mockModelltests";
import { isManualQuestion } from "./exams/mockModelltests";

export type Cefr = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export interface GradedAnswer {
  correct: boolean;
  points: number;
  /** پاسخ آزاد: نمره بعداً با خودارزیابی تعیین می‌شود. */
  manual: boolean;
}

function normalize(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[.,;:!?"']/g, "");
}

function sameSet(a: string[], b: string[]): boolean {
  if (a.length !== b.length) return false;
  const sortedA = [...a].sort();
  const sortedB = [...b].sort();
  return sortedA.every((v, i) => v === sortedB[i]);
}

/** نمره‌دهی یک پاسخ. برای پاسخ آزاد نمره صفر و `manual: true` برمی‌گردد. */
export function gradeAnswer(question: ExamQuestion, value: unknown): GradedAnswer {
  if (isManualQuestion(question)) {
    return { correct: false, points: 0, manual: true };
  }
  if (value === undefined || value === null || value === "") {
    return { correct: false, points: 0, manual: false };
  }

  switch (question.kind) {
    case "single": {
      const ok = String(value) === question.correct;
      return { correct: ok, points: ok ? question.points : 0, manual: false };
    }
    case "truefalse": {
      const ok = Boolean(value) === question.correct;
      return { correct: ok, points: ok ? question.points : 0, manual: false };
    }
    case "gap": {
      const given = normalize(String(value));
      const ok = question.accepted.some((a) => normalize(a) === given);
      return { correct: ok, points: ok ? question.points : 0, manual: false };
    }
    case "multi": {
      const given = Array.isArray(value) ? value.map(String) : [];
      const ok = sameSet(given, question.correct);
      if (ok) return { correct: true, points: question.points, manual: false };
      // نمرهٔ جزئی: هر گزینهٔ درست مثبت، هر گزینهٔ نادرست منفی (حداقل صفر).
      const hits = given.filter((g) => question.correct.includes(g)).length;
      const misses = given.length - hits;
      const ratio = Math.max(0, (hits - misses) / question.correct.length);
      return {
        correct: false,
        points: Math.round(question.points * ratio * 100) / 100,
        manual: false,
      };
    }
    case "matching": {
      const given = (value ?? {}) as Record<string, string>;
      const entries = Object.entries(question.correct);
      const hits = entries.filter(([k, v]) => given[k] === v).length;
      const ok = hits === entries.length;
      return {
        correct: ok,
        points: Math.round(((question.points * hits) / entries.length) * 100) / 100,
        manual: false,
      };
    }
    default:
      return { correct: false, points: 0, manual: false };
  }
}

/** بیشینهٔ نمرهٔ خودکار یک بخش (بدون سؤال‌های پاسخ آزاد). */
export function autoMaxPoints(section: ModelltestSection): number {
  return section.questions.filter((q) => !isManualQuestion(q)).reduce((s, q) => s + q.points, 0);
}

/** بیشینهٔ نمرهٔ کل یک بخش (شامل پاسخ آزاد). */
export function totalMaxPoints(section: ModelltestSection): number {
  return section.questions.reduce((s, q) => s + q.points, 0);
}

/** درصد بر پایهٔ نمره و سقف نمره. */
export function percentOf(score: number, max: number): number {
  if (max <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round((score / max) * 100)));
}

const LEVELS: Cefr[] = ["A1", "A2", "B1", "B2", "C1", "C2"];

/**
 * نگاشت درصد → سطح CEFR.
 * `targetLevel` سطح هدف آزمون است: با درصد بالا همان سطح (یا یک پله بالاتر)،
 * با درصد پایین یک تا دو پله پایین‌تر پیشنهاد می‌شود.
 */
export function levelFromPercent(percent: number, targetLevel: string): Cefr {
  const idx = Math.max(0, LEVELS.indexOf((targetLevel as Cefr) ?? "B1"));
  let offset: number;
  if (percent >= 90) offset = 1;
  else if (percent >= 70) offset = 0;
  else if (percent >= 50) offset = -1;
  else offset = -2;
  const next = Math.max(0, Math.min(LEVELS.length - 1, idx + offset));
  return LEVELS[next] as Cefr;
}

/** برچسب فارسی/آلمانی وضعیت نمره. */
export function verdictOf(percent: number): { label: string; tone: "good" | "ok" | "weak" } {
  if (percent >= 75) return { label: "Bestanden – sehr gut", tone: "good" };
  if (percent >= 55) return { label: "Bestanden – ausbaufähig", tone: "ok" };
  return { label: "Noch nicht bestanden", tone: "weak" };
}
