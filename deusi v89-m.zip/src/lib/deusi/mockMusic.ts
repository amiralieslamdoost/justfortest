// ---------------------------------------------------------------------------
// DEUSI — Mock music / karaoke data.
// Plain serializable values so a real API (Supabase / REST) can replace them
// later without touching any UI component.
// ---------------------------------------------------------------------------

export type CEFR = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type MusicGenreKey =
  "fuer-dich" | "alle" | "pop" | "rap" | "rock" | "schlager" | "indie" | "klassiker";

export interface MusicGenre {
  key: MusicGenreKey;
  label: string;
  labelFa: string;
}

export const musicGenres: MusicGenre[] = [
  { key: "fuer-dich", label: "Für dich", labelFa: "برای تو" },
  { key: "alle", label: "Alle", labelFa: "همه" },
  { key: "pop", label: "Pop", labelFa: "پاپ" },
  { key: "rap", label: "Rap & HipHop", labelFa: "رپ و هیپ‌هاپ" },
  { key: "rock", label: "Rock", labelFa: "راک" },
  { key: "schlager", label: "Schlager", labelFa: "شلاگر" },
  { key: "indie", label: "Indie", labelFa: "ایندی" },
  { key: "klassiker", label: "Klassiker", labelFa: "کلاسیک‌ها" },
];

export const musicLevels: CEFR[] = ["A1", "A2", "B1", "B2", "C1"];

export interface Artist {
  id: string;
  name: string;
  country: string;
  genre: Exclude<MusicGenreKey, "fuer-dich" | "alle">;
  tagline: string;
  cover: string; // CSS gradient fallback — no external assets needed
  coverUrl?: string; // optional square artwork (1:1)
  accent: string; // hex
  songs: number;
  listeners: string;
}

export interface LyricWord {
  w: string;
  vocabId?: string;
}

export interface LyricLine {
  id: string;
  start: number; // seconds
  end: number; // seconds
  words: LyricWord[];
  translation: string; // Persian
  translationEn?: string;
}

export type SongVocabPos = "noun" | "verb" | "adjective";

export interface SongVocab {
  id: string;
  term: string;
  pos: SongVocabPos;
  /** nouns */
  article?: "der" | "die" | "das";
  plural?: string;
  /** verbs */
  praeteritum?: string;
  perfekt?: string;
  /** adjectives */
  comparative?: string;
  superlative?: string;
  translation: string; // Persian
  example: string; // line from the song
}

export interface Song {
  id: string;
  title: string;
  artistId: string;
  album: string;
  year: number;
  durationSec: number;
  level: CEFR;
  genre: Exclude<MusicGenreKey, "fuer-dich" | "alle">;
  cover: string;
  coverUrl?: string;
  accent: string;
  plays: string;
  /** Would be a real MP3 URL once a backend exists. */
  audioUrl: string;
  waveform: number[];
  lyrics: LyricLine[];
  vocab: SongVocab[];
  /** short Persian note about the song's theme */
  noteFa: string;
}

export interface Playlist {
  id: string;
  title: string;
  titleFa: string;
  description: string;
  level: CEFR | `${CEFR}-${CEFR}`;
  cover: string;
  coverUrl?: string;
  accent: string;
  songIds: string[];
}

export interface MusicProgress {
  songId: string;
  positionSec: number;
  lastPlayed: string;
}

// --- helpers ---------------------------------------------------------------

function wave(seed: number, n = 56): number[] {
  const out: number[] = [];
  let x = seed;
  for (let i = 0; i < n; i++) {
    x = (x * 9301 + 49297) % 233280;
    const r = x / 233280;
    out.push(0.25 + r * 0.75);
  }
  return out;
}

function line(
  id: string,
  start: number,
  end: number,
  text: string,
  translation: string,
  links: Record<string, string> = {},
): LyricLine {
  return {
    id,
    start,
    end,
    translation,
    words: text.split(" ").map((w) => {
      const clean = w.replace(/[.,!?;:„“"»«()]/g, "");
      const vocabId = links[clean];
      return vocabId ? { w, vocabId } : { w };
    }),
  };
}

// --- artists ---------------------------------------------------------------

export const artists: Artist[] = [
  {
    id: "a-nebel",
    name: "Nebelkind",
    country: "Berlin, DE",
    genre: "indie",
    tagline: "Melancholischer Indie-Pop aus Kreuzberg",
    cover: "linear-gradient(135deg,#f97316,#ef4444)",
    accent: "#f97316",
    songs: 24,
    listeners: "1.2 Mio",
  },
  {
    id: "a-lena",
    name: "Lena Sommer",
    country: "Hamburg, DE",
    genre: "pop",
    tagline: "Klarer Pop mit Texten zum Mitsingen",
    cover: "linear-gradient(135deg,#4c1d95,#a21caf)",
    accent: "#a855f7",
    songs: 41,
    listeners: "3.8 Mio",
  },
  {
    id: "a-kiez",
    name: "Kiezpoet",
    country: "Köln, DE",
    genre: "rap",
    tagline: "Straßenpoesie mit deutlicher Aussprache",
    cover: "linear-gradient(135deg,#064e3b,#10b981)",
    accent: "#10b981",
    songs: 33,
    listeners: "2.1 Mio",
  },
  {
    id: "a-alpen",
    name: "Alpenglühen",
    country: "München, DE",
    genre: "rock",
    tagline: "Deutschrock mit Gitarren und Herz",
    cover: "linear-gradient(135deg,#111827,#dc2626)",
    accent: "#ef4444",
    songs: 18,
    listeners: "900 Tsd",
  },
  {
    id: "a-marlene",
    name: "Marlene Feld",
    country: "Wien, AT",
    genre: "klassiker",
    tagline: "Zeitlose Lieder, langsam und deutlich",
    cover: "linear-gradient(135deg,#0f172a,#0ea5e9)",
    accent: "#0ea5e9",
    songs: 27,
    listeners: "640 Tsd",
  },
  {
    id: "a-freund",
    name: "Die Freundlichen",
    country: "Leipzig, DE",
    genre: "schlager",
    tagline: "Gute Laune, einfache Wörter",
    cover: "linear-gradient(135deg,#be185d,#f472b6)",
    accent: "#ec4899",
    songs: 52,
    listeners: "1.7 Mio",
  },
];

// --- songs -----------------------------------------------------------------

const sonneVocab: SongVocab[] = [
  {
    id: "v-sonne",
    term: "Sonne",
    pos: "noun",
    article: "die",
    plural: "Sonnen",
    translation: "خورشید",
    example: "Die Sonne geht über der Stadt auf",
  },
  {
    id: "v-aufgehen",
    term: "aufgehen",
    pos: "verb",
    praeteritum: "ging auf",
    perfekt: "ist aufgegangen",
    translation: "طلوع کردن",
    example: "Die Sonne geht über der Stadt auf",
  },
  {
    id: "v-strasse",
    term: "Straße",
    pos: "noun",
    article: "die",
    plural: "Straßen",
    translation: "خیابان",
    example: "Die Straßen sind noch leer und still",
  },
  {
    id: "v-leer",
    term: "leer",
    pos: "adjective",
    comparative: "leerer",
    superlative: "am leersten",
    translation: "خالی",
    example: "Die Straßen sind noch leer und still",
  },
  {
    id: "v-warten",
    term: "warten",
    pos: "verb",
    praeteritum: "wartete",
    perfekt: "hat gewartet",
    translation: "منتظر ماندن",
    example: "Ich warte auf den ersten Zug",
  },
  {
    id: "v-morgen",
    term: "Morgen",
    pos: "noun",
    article: "der",
    plural: "Morgen",
    translation: "صبح",
    example: "Der Morgen schmeckt nach Kaffee",
  },
];

const sonneLyrics: LyricLine[] = [
  line("l1", 0, 7, "Die Sonne geht über der Stadt auf", "خورشید بالای شهر طلوع می‌کند", {
    Sonne: "v-sonne",
    auf: "v-aufgehen",
  }),
  line("l2", 7, 14, "Die Straßen sind noch leer und still", "خیابان‌ها هنوز خالی و ساکت‌اند", {
    Straßen: "v-strasse",
    leer: "v-leer",
  }),
  line("l3", 14, 21, "Ich warte auf den ersten Zug", "منتظر اولین قطار هستم", {
    warte: "v-warten",
  }),
  line(
    "l4",
    21,
    28,
    "und denke, was der Tag mir bringen will",
    "و فکر می‌کنم امروز چه چیزی برایم دارد",
  ),
  line(
    "l5",
    28,
    36,
    "Der Morgen schmeckt nach Kaffee und nach Zeit",
    "صبح طعم قهوه و زمان می‌دهد",
    { Morgen: "v-morgen" },
  ),
  line("l6", 36, 44, "Ich bin bereit, ich bin bereit", "من آماده‌ام، من آماده‌ام"),
  line("l7", 44, 52, "Und wenn die Sonne über allem steht", "و وقتی خورشید بالای همه‌چیز بایستد", {
    Sonne: "v-sonne",
  }),
  line("l8", 52, 60, "dann weiß ich, dass es weitergeht", "آن‌وقت می‌دانم که راه ادامه دارد"),
  line("l9", 60, 68, "Die Stadt wacht auf, ich atme ein", "شهر بیدار می‌شود، من نفس می‌کشم"),
  line("l10", 68, 78, "und heute will ich mutig sein", "و امروز می‌خواهم شجاع باشم"),
  line(
    "l11",
    78,
    88,
    "Die Sonne, die Sonne, sie ruft meinen Namen",
    "خورشید، خورشید، اسم مرا صدا می‌زند",
    { Sonne: "v-sonne" },
  ),
  line("l12", 88, 98, "Ich gehe los und sage einfach: Ja", "راه می‌افتم و فقط می‌گویم: بله"),
];

const kiezVocab: SongVocab[] = [
  {
    id: "v-viertel",
    term: "Viertel",
    pos: "noun",
    article: "das",
    plural: "Viertel",
    translation: "محله",
    example: "Mein Viertel schläft nie richtig ein",
  },
  {
    id: "v-traum",
    term: "Traum",
    pos: "noun",
    article: "der",
    plural: "Träume",
    translation: "رؤیا",
    example: "Jeder trägt hier seinen Traum",
  },
  {
    id: "v-tragen",
    term: "tragen",
    pos: "verb",
    praeteritum: "trug",
    perfekt: "hat getragen",
    translation: "حمل کردن",
    example: "Jeder trägt hier seinen Traum",
  },
  {
    id: "v-laut",
    term: "laut",
    pos: "adjective",
    comparative: "lauter",
    superlative: "am lautesten",
    translation: "بلند، پرصدا",
    example: "Die Nacht ist laut, mein Kopf ist voll",
  },
  {
    id: "v-kaempfen",
    term: "kämpfen",
    pos: "verb",
    praeteritum: "kämpfte",
    perfekt: "hat gekämpft",
    translation: "جنگیدن، تلاش کردن",
    example: "Wir kämpfen leise, jeden Tag",
  },
];

const kiezLyrics: LyricLine[] = [
  line("k1", 0, 6, "Mein Viertel schläft nie richtig ein", "محله‌ی من هیچ‌وقت درست نمی‌خوابد", {
    Viertel: "v-viertel",
  }),
  line("k2", 6, 12, "Zwischen Beton wächst trotzdem was", "بین بتن‌ها باز هم چیزی رشد می‌کند"),
  line("k3", 12, 19, "Jeder trägt hier seinen Traum", "اینجا هرکسی رؤیایش را با خود دارد", {
    trägt: "v-tragen",
    Traum: "v-traum",
  }),
  line("k4", 19, 26, "in einer Tasche ohne Maß", "توی کیفی بی‌اندازه"),
  line("k5", 26, 33, "Die Nacht ist laut, mein Kopf ist voll", "شب پرصداست، سرم پر است", {
    laut: "v-laut",
  }),
  line("k6", 33, 40, "Ich schreibe auf, was bleiben soll", "چیزی را می‌نویسم که باید بماند"),
  line("k7", 40, 48, "Wir kämpfen leise, jeden Tag", "ما آرام می‌جنگیم، هر روز", {
    kämpfen: "v-kaempfen",
  }),
  line("k8", 48, 56, "bis keiner mehr uns fragen mag", "تا وقتی دیگر کسی از ما نپرسد"),
  line("k9", 56, 64, "Mein Viertel, meine Melodie", "محله‌ی من، ملودی من", {
    Viertel: "v-viertel",
  }),
  line("k10", 64, 74, "vergessen tu ich sie wohl nie", "هیچ‌وقت فراموشش نمی‌کنم"),
];

const regenVocab: SongVocab[] = [
  {
    id: "v-regen",
    term: "Regen",
    pos: "noun",
    article: "der",
    translation: "باران",
    example: "Der Regen fällt auf unser Dach",
  },
  {
    id: "v-dach",
    term: "Dach",
    pos: "noun",
    article: "das",
    plural: "Dächer",
    translation: "سقف",
    example: "Der Regen fällt auf unser Dach",
  },
  {
    id: "v-bleiben",
    term: "bleiben",
    pos: "verb",
    praeteritum: "blieb",
    perfekt: "ist geblieben",
    translation: "ماندن",
    example: "Bleib noch ein bisschen hier bei mir",
  },
  {
    id: "v-warm",
    term: "warm",
    pos: "adjective",
    comparative: "wärmer",
    superlative: "am wärmsten",
    translation: "گرم",
    example: "Drinnen ist es warm und hell",
  },
];

const regenLyrics: LyricLine[] = [
  line("r1", 0, 8, "Der Regen fällt auf unser Dach", "باران روی سقف ما می‌بارد", {
    Regen: "v-regen",
    Dach: "v-dach",
  }),
  line("r2", 8, 16, "Drinnen ist es warm und hell", "داخل، گرم و روشن است", { warm: "v-warm" }),
  line("r3", 16, 24, "Bleib noch ein bisschen hier bei mir", "کمی دیگر اینجا پیش من بمان", {
    Bleib: "v-bleiben",
  }),
  line("r4", 24, 32, "die Zeit vergeht sonst viel zu schnell", "وگرنه زمان خیلی زود می‌گذرد"),
  line("r5", 32, 40, "Wir zählen Tropfen an der Scheibe", "قطره‌ها را روی شیشه می‌شماریم"),
  line("r6", 40, 48, "und keiner sagt ein lautes Wort", "و هیچ‌کس حرف بلندی نمی‌زند"),
  line("r7", 48, 58, "Ich hoffe, dass ich hier noch bleibe", "امیدوارم هنوز اینجا بمانم", {
    bleibe: "v-bleiben",
  }),
  line("r8", 58, 68, "an diesem kleinen, stillen Ort", "در این جای کوچک و ساکت"),
];

const heimatVocab: SongVocab[] = [
  {
    id: "v-heimat",
    term: "Heimat",
    pos: "noun",
    article: "die",
    translation: "وطن، زادگاه",
    example: "Heimat ist kein Ort allein",
  },
  {
    id: "v-weg",
    term: "Weg",
    pos: "noun",
    article: "der",
    plural: "Wege",
    translation: "راه",
    example: "Der Weg zurück ist niemals grad",
  },
  {
    id: "v-finden",
    term: "finden",
    pos: "verb",
    praeteritum: "fand",
    perfekt: "hat gefunden",
    translation: "پیدا کردن",
    example: "Ich finde dich in jedem Lied",
  },
];

const heimatLyrics: LyricLine[] = [
  line("h1", 0, 8, "Heimat ist kein Ort allein", "وطن فقط یک مکان نیست", { Heimat: "v-heimat" }),
  line("h2", 8, 16, "Heimat kann ein Mensch auch sein", "وطن می‌تواند یک آدم هم باشد", {
    Heimat: "v-heimat",
  }),
  line("h3", 16, 25, "Der Weg zurück ist niemals grad", "راه بازگشت هیچ‌وقت صاف نیست", {
    Weg: "v-weg",
  }),
  line("h4", 25, 34, "doch jeder Schritt war eine Tat", "اما هر قدم یک کار بود"),
  line("h5", 34, 44, "Ich finde dich in jedem Lied", "تو را در هر ترانه پیدا می‌کنم", {
    finde: "v-finden",
  }),
  line("h6", 44, 54, "das leise durch die Jahre zieht", "که آرام از میان سال‌ها می‌گذرد"),
];

type SongSeed = {
  id: string;
  title: string;
  artistId: string;
  album: string;
  year: number;
  durationSec: number;
  level: CEFR;
  genre: Song["genre"];
  cover: string;
  accent: string;
  plays: string;
  noteFa: string;
  lyrics?: LyricLine[];
  vocab?: SongVocab[];
};

const seeds: SongSeed[] = [
  {
    id: "s-sonne",
    title: "Die Sonne über uns",
    artistId: "a-lena",
    album: "Morgenlicht",
    year: 2023,
    durationSec: 98,
    level: "A2",
    genre: "pop",
    cover: "linear-gradient(135deg,#f59e0b,#ef4444)",
    accent: "#f97316",
    plays: "8.4 Mio",
    noteFa: "ترانه‌ای روشن درباره شروع دوباره — واژگان ساده و تلفظ شمرده.",
    lyrics: sonneLyrics,
    vocab: sonneVocab,
  },
  {
    id: "s-kiez",
    title: "Mein Viertel",
    artistId: "a-kiez",
    album: "Beton & Poesie",
    year: 2024,
    durationSec: 74,
    level: "B1",
    genre: "rap",
    cover: "linear-gradient(135deg,#1e1b4b,#7c3aed)",
    accent: "#8b5cf6",
    plays: "5.1 Mio",
    noteFa: "رپ آرام با تلفظ واضح؛ عالی برای تمرین ریتم جمله.",
    lyrics: kiezLyrics,
    vocab: kiezVocab,
  },
  {
    id: "s-regen",
    title: "Regen auf dem Dach",
    artistId: "a-nebel",
    album: "Nachtspaziergang",
    year: 2022,
    durationSec: 68,
    level: "A1",
    genre: "indie",
    cover: "linear-gradient(135deg,#0b1e3f,#2563eb)",
    accent: "#3b82f6",
    plays: "3.3 Mio",
    noteFa: "کند و ملایم؛ بهترین انتخاب برای شروع تمرین شنیداری.",
    lyrics: regenLyrics,
    vocab: regenVocab,
  },
  {
    id: "s-heimat",
    title: "Heimat",
    artistId: "a-marlene",
    album: "Zeitlos",
    year: 2019,
    durationSec: 54,
    level: "B1",
    genre: "klassiker",
    cover: "linear-gradient(135deg,#064e3b,#10b981)",
    accent: "#10b981",
    plays: "2.7 Mio",
    noteFa: "کلاسیکی درباره مفهوم «وطن» با جمله‌های کوتاه و شاعرانه.",
    lyrics: heimatLyrics,
    vocab: heimatVocab,
  },
  {
    id: "s-tanz",
    title: "Tanz mit mir",
    artistId: "a-freund",
    album: "Gute Laune",
    year: 2021,
    durationSec: 92,
    level: "A1",
    genre: "schlager",
    cover: "linear-gradient(135deg,#be185d,#f472b6)",
    accent: "#ec4899",
    plays: "6.9 Mio",
    noteFa: "ریتم شاد و تکرارشونده — واژه‌های روزمره.",
  },
  {
    id: "s-sturm",
    title: "Sturm im Kopf",
    artistId: "a-alpen",
    album: "Gegenwind",
    year: 2023,
    durationSec: 110,
    level: "B2",
    genre: "rock",
    cover: "linear-gradient(135deg,#111827,#dc2626)",
    accent: "#ef4444",
    plays: "1.9 Mio",
    noteFa: "راک پرانرژی با اصطلاح‌های محاوره‌ای.",
  },
  {
    id: "s-stadt",
    title: "Stadt aus Glas",
    artistId: "a-nebel",
    album: "Nachtspaziergang",
    year: 2022,
    durationSec: 88,
    level: "B1",
    genre: "indie",
    cover: "linear-gradient(135deg,#0f172a,#0ea5e9)",
    accent: "#0ea5e9",
    plays: "1.4 Mio",
    noteFa: "تصویرسازی شهری با واژگان انتزاعی سطح B1.",
  },
  {
    id: "s-brief",
    title: "Ein Brief an dich",
    artistId: "a-lena",
    album: "Morgenlicht",
    year: 2023,
    durationSec: 84,
    level: "A2",
    genre: "pop",
    cover: "linear-gradient(135deg,#7c2d12,#f59e0b)",
    accent: "#f59e0b",
    plays: "4.6 Mio",
    noteFa: "ساختار نامه‌ای؛ تمرین خوب برای زمان گذشته.",
  },
  {
    id: "s-zug",
    title: "Letzter Zug",
    artistId: "a-kiez",
    album: "Beton & Poesie",
    year: 2024,
    durationSec: 96,
    level: "B2",
    genre: "rap",
    cover: "linear-gradient(135deg,#312e81,#4f46e5)",
    accent: "#6366f1",
    plays: "2.2 Mio",
    noteFa: "سرعت بالاتر — برای وقتی که گوشت آماده‌تر شد.",
  },
  {
    id: "s-wind",
    title: "Wind im Haar",
    artistId: "a-alpen",
    album: "Gegenwind",
    year: 2020,
    durationSec: 102,
    level: "B1",
    genre: "rock",
    cover: "linear-gradient(135deg,#134e4a,#14b8a6)",
    accent: "#14b8a6",
    plays: "1.1 Mio",
    noteFa: "کر تکرارشونده و ساده برای هم‌خوانی.",
  },
  {
    id: "s-nacht",
    title: "Gute Nacht, Berlin",
    artistId: "a-marlene",
    album: "Zeitlos",
    year: 2018,
    durationSec: 76,
    level: "A2",
    genre: "klassiker",
    cover: "linear-gradient(135deg,#1e293b,#64748b)",
    accent: "#94a3b8",
    plays: "980 Tsd",
    noteFa: "آرام و شمرده؛ مناسب قبل از خواب.",
  },
  {
    id: "s-sommer",
    title: "Sommer bleibt",
    artistId: "a-freund",
    album: "Gute Laune",
    year: 2022,
    durationSec: 90,
    level: "A1",
    genre: "schlager",
    cover: "linear-gradient(135deg,#ca8a04,#facc15)",
    accent: "#eab308",
    plays: "5.5 Mio",
    noteFa: "واژگان فصل‌ها و تعطیلات.",
  },
  {
    id: "s-frage",
    title: "Frag mich nicht",
    artistId: "a-nebel",
    album: "Zwischenräume",
    year: 2024,
    durationSec: 106,
    level: "C1",
    genre: "indie",
    cover: "linear-gradient(135deg,#4c1d95,#a21caf)",
    accent: "#a855f7",
    plays: "740 Tsd",
    noteFa: "متن پیچیده‌تر با استعاره — چالش سطح C1.",
  },
];

export const songs: Song[] = seeds.map((s, i) => ({
  ...s,
  coverUrl: `https://picsum.photos/seed/deusi-song-${s.id}/500/500`,
  audioUrl: `/audio/musik/${s.id}.mp3`,
  waveform: wave(i * 37 + 11),
  lyrics: s.lyrics ?? [],
  vocab: s.vocab ?? [],
}));

// --- playlists -------------------------------------------------------------

export const playlists: Playlist[] = [
  {
    id: "p-anfang",
    title: "Sanfter Start",
    titleFa: "شروع ملایم",
    description: "Langsame Lieder mit klarer Aussprache — perfekt für A1/A2.",
    level: "A1-A2",
    cover: "linear-gradient(135deg,#111827,#dc2626)",
    coverUrl: "https://picsum.photos/seed/deusi-pl-anfang/500/500",
    accent: "#ef4444",
    songIds: ["s-regen", "s-tanz", "s-sommer", "s-sonne", "s-nacht"],
  },
  {
    id: "p-alltag",
    title: "Alltagsdeutsch",
    titleFa: "آلمانی روزمره",
    description: "Wörter, die du jeden Tag hörst — B1-Niveau.",
    level: "B1",
    cover: "linear-gradient(135deg,#0f172a,#0ea5e9)",
    coverUrl: "https://picsum.photos/seed/deusi-pl-alltag/500/500",
    accent: "#0ea5e9",
    songIds: ["s-kiez", "s-heimat", "s-stadt", "s-wind"],
  },
  {
    id: "p-rap",
    title: "Rap-Training",
    titleFa: "تمرین رپ",
    description: "Schnelles Sprechtempo für fortgeschrittene Ohren.",
    level: "B2-C1",
    cover: "linear-gradient(135deg,#be185d,#f472b6)",
    coverUrl: "https://picsum.photos/seed/deusi-pl-rap/500/500",
    accent: "#ec4899",
    songIds: ["s-zug", "s-kiez", "s-frage"],
  },
  {
    id: "p-abend",
    title: "Ruhiger Abend",
    titleFa: "شب آرام",
    description: "Zum Zuhören, Mitlesen und Entspannen.",
    level: "A2-B1",
    cover: "linear-gradient(135deg,#03203f,#38bdf8)",
    coverUrl: "https://picsum.photos/seed/deusi-pl-abend/500/500",
    accent: "#4f8ff7",
    songIds: ["s-nacht", "s-regen", "s-brief", "s-heimat"],
  },
];

export const continueListeningMusic: MusicProgress[] = [
  { songId: "s-sonne", positionSec: 42, lastPlayed: "vor 2 Stunden" },
  { songId: "s-kiez", positionSec: 19, lastPlayed: "gestern" },
  { songId: "s-regen", positionSec: 8, lastPlayed: "vor 3 Tagen" },
];

export const musicStats = {
  minutesThisWeek: 84,
  songsFinished: 12,
  wordsSaved: 37,
  streakDays: 6,
  weekly: [12, 8, 20, 4, 15, 10, 15],
};

export const recommendedTopicsMusic = [
  "Liebeslieder",
  "Alltag & Stadt",
  "Langsam gesungen",
  "Zum Mitsingen",
  "Deutschrap",
  "80er Klassiker",
];

// --- lookups ---------------------------------------------------------------

export function findSong(id: string): Song | undefined {
  return songs.find((s) => s.id === id);
}
export function findArtist(id: string): Artist | undefined {
  return artists.find((a) => a.id === id);
}
export function findPlaylist(id: string): Playlist | undefined {
  return playlists.find((p) => p.id === id);
}
export function featuredSong(): Song {
  return findSong("s-sonne") ?? songs[0];
}
export function songsWithLyrics(): Song[] {
  return songs.filter((s) => s.lyrics.length > 0);
}
export function artistName(id: string): string {
  return findArtist(id)?.name ?? "Unbekannt";
}
