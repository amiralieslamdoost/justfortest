import type { DeckCard } from "./types";

export type Rating = "again" | "hard" | "good" | "easy";
const DAY = 24 * 60 * 60 * 1000;

export function newCard(wordId: string): DeckCard {
  return { wordId, box: 1, due: Date.now(), reps: 0, lapses: 0, ease: 2.5, interval: 0 };
}

// Simplified FSRS-inspired scheduler with 5 Leitner boxes.
export function schedule(card: DeckCard, rating: Rating): DeckCard {
  let { box, ease, interval, reps, lapses } = card;
  reps += 1;
  if (rating === "again") {
    lapses += 1;
    box = 1;
    ease = Math.max(1.3, ease - 0.2);
    interval = 0;
  } else if (rating === "hard") {
    ease = Math.max(1.3, ease - 0.05);
    interval = Math.max(1, Math.round(interval * 1.2 || 1));
    box = Math.min(5, box + (box < 3 ? 1 : 0)) as DeckCard["box"];
  } else if (rating === "good") {
    interval = Math.max(1, Math.round((interval || 1) * ease));
    box = Math.min(5, box + 1) as DeckCard["box"];
  } else {
    ease += 0.1;
    interval = Math.max(2, Math.round((interval || 1) * ease * 1.3));
    box = Math.min(5, box + 1) as DeckCard["box"];
  }
  return { ...card, box, ease, interval, reps, lapses, due: Date.now() + interval * DAY };
}
