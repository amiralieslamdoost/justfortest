/**
 * Service-Worker-Registrierung mit Sicherheitsnetz.
 * ثبت سرویس‌ورکر فقط در نسخهٔ منتشرشده؛ در حالت توسعه، داخل iframe،
 * در پیش‌نمایش‌های Lovable و با پارامتر ?sw=off ثبت نمی‌شود و
 * ثبت‌های قدیمی نیز پاک می‌شوند.
 */

const SW_URL = "/sw.js";

function isPreviewHost(hostname: string) {
  return (
    hostname.startsWith("id-preview--") ||
    hostname.startsWith("preview--") ||
    hostname === "lovableproject.com" ||
    hostname.endsWith(".lovableproject.com") ||
    hostname === "lovableproject-dev.com" ||
    hostname.endsWith(".lovableproject-dev.com") ||
    hostname === "beta.lovable.dev" ||
    hostname.endsWith(".beta.lovable.dev")
  );
}

function shouldRegister(): boolean {
  if (typeof window === "undefined") return false;
  if (!("serviceWorker" in navigator)) return false;
  if (!import.meta.env.PROD) return false;
  if (window.self !== window.top) return false;
  if (isPreviewHost(window.location.hostname)) return false;
  if (new URLSearchParams(window.location.search).get("sw") === "off") return false;
  return true;
}

async function unregisterExisting() {
  if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return;
  try {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.allSettled(
      registrations
        .filter((r) => {
          const url = r.active?.scriptURL ?? r.installing?.scriptURL ?? r.waiting?.scriptURL ?? "";
          return url.endsWith(SW_URL);
        })
        .map((r) => r.unregister()),
    );
  } catch {
    /* ignore */
  }
}

/** In main.tsx aufgerufen. از src/main.tsx صدا زده می‌شود. */
export function registerServiceWorker(): void {
  if (!shouldRegister()) {
    void unregisterExisting();
    return;
  }

  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register(SW_URL, { scope: "/" })
      .then((registration) => {
        registration.addEventListener("updatefound", () => {
          const next = registration.installing;
          if (!next) return;
          next.addEventListener("statechange", () => {
            if (next.state === "installed" && navigator.serviceWorker.controller) {
              void import("sonner").then(({ toast }) => {
                toast("نسخهٔ جدید DEUSI آماده است", {
                  description: "Neue Version verfügbar",
                  action: { label: "بارگذاری مجدد", onClick: () => window.location.reload() },
                  duration: 10000,
                });
              });
            }
          });
        });
      })
      .catch(() => {
        /* Offline-Support ist optional. */
      });
  });
}
