/**
 * هوک‌های TanStack Query برای دامنهٔ خواندن (lesen).
 */
import { useCallback, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import {
  getArticleBySlug,
  listReadingProgress,
  saveReadingProgress,
  searchArticlesPaged,
  type ArticleQuery,
  type ArticleState,
  type ArticleStateMap,
} from "./reading";
import { articles as MOCK_ARTICLES, type Article } from "@/lib/deusi/mockReading";
import { useDeusi } from "@/lib/deusi/store";

/** فهرست صفحه‌بندی‌شدهٔ مقاله‌ها. */
export function useArticles(query: ArticleQuery = {}) {
  const q = useQuery({
    queryKey: queryKeys.reading.articlesPaged(query),
    queryFn: () => searchArticlesPaged(query),
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });
  return {
    articles: q.data?.items ?? [],
    total: q.data?.totalItems ?? 0,
    totalPages: q.data?.totalPages ?? 1,
    isLoading: q.isLoading,
    error: q.error,
  };
}

/** یک مقاله (با fallback به دیتای محلی). */
export function useArticle(idOrSlug: string) {
  const fallback = useMemo(
    () => MOCK_ARTICLES.find((a) => a.id === idOrSlug || a.slug === idOrSlug) ?? null,
    [idOrSlug],
  );
  const q = useQuery({
    queryKey: queryKeys.reading.article(idOrSlug),
    queryFn: () => getArticleBySlug(idOrSlug),
    enabled: Boolean(idOrSlug),
    staleTime: 5 * 60_000,
    initialData: fallback,
  });
  return {
    article: (q.data ?? fallback) as Article | null,
    isLoading: q.isLoading,
    error: q.error,
  };
}

/** پیشرفت خواندن همهٔ مقاله‌ها. */
export function useReadingProgressMap() {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const q = useQuery({
    queryKey: queryKeys.reading.readingProgress(userId),
    queryFn: () => listReadingProgress(userId),
    staleTime: 60_000,
    initialData: {} as ArticleStateMap,
  });
  return { progress: q.data ?? {}, isLoading: q.isLoading };
}

/** خواندن و نوشتن وضعیت یک مقاله (جایگزین سرورمحور `useArticleState`). */
export function useArticleProgress(articleId: string) {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const qc = useQueryClient();
  const { progress } = useReadingProgressMap();

  const state: ArticleState = progress[articleId] ?? {
    progress: 0,
    bookmarked: false,
    savedWords: [],
  };

  const mutation = useMutation({
    mutationFn: (patch: Partial<ArticleState>) => saveReadingProgress(userId, articleId, patch),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.reading.readingProgress(userId) });
    },
  });

  const patch = useCallback((p: Partial<ArticleState>) => mutation.mutate(p), [mutation]);

  return [state, patch] as const;
}
