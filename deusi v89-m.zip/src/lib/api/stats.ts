/**
 * آمار یادگیری (سشن ۹) — خواندن `daily_stats` و تبدیل آن به شکل `StudyDay`
 * که صفحهٔ /statistiken و داشبورد از قبل با آن کار می‌کنند.
 *
 * نوشتن در `daily_stats` فقط از سمت سرور (pb_hooks) انجام می‌شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import type { DailyStatRecord } from "./types";
import {
  MODULE_KEYS,
  sliceDays,
  studyDays as MOCK_DAYS,
  type StudyDay,
  type StudyModuleKey,
} from "@/lib/deusi/mockStudyStats";

export interface StudyTotals {
  totalMinutes: number;
  totalSessions: number;
  totalXp: number;
  todayMinutes: number;
  avgAccuracy: number;
  firstDay: string;
}

function emptyByModule(): Record<StudyModuleKey, number> {
  const out = {} as Record<StudyModuleKey, number>;
  for (const k of MODULE_KEYS) out[k] = 0;
  return out;
}

function isoDay(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** ساخت یک بازهٔ کامل روزانه (بدون حفره) از رکوردهای بک‌اند. */
function fillRange(records: DailyStatRecord[], days: number): StudyDay[] {
  const byDay = new Map(records.map((r) => [r.day, r]));
  const out: StudyDay[] = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const key = isoDay(d);
    const rec = byDay.get(key);
    const byModule = emptyByModule();
    const skills = (rec?.skill_minutes ?? {}) as Record<string, number>;
    for (const k of MODULE_KEYS) byModule[k] = Number(skills[k] ?? 0);
    out.push({
      date: key,
      minutes: rec?.minutes ?? 0,
      sessions: rec
        ? (rec.lessons_done ?? 0) + (rec.articles_read ?? 0) || (rec.minutes ? 1 : 0)
        : 0,
      cardsReviewed: rec?.words_reviewed ?? 0,
      wordsSaved: rec?.words_learned ?? 0,
      byModule,
    });
  }
  return out;
}

/**
 * آمار روزانهٔ کاربر برای `days` روز گذشته.
 * در حالت MOCK همان `sliceDays` قبلی برگردانده می‌شود.
 */
export async function loadStudyDays(userId: string, days = 365): Promise<StudyDay[]> {
  if (!BACKEND || !userId) return sliceDays(days);
  try {
    const from = new Date();
    from.setDate(from.getDate() - (days - 1));
    const list = await pbRequest((signal) =>
      getPb()
        .collection("daily_stats")
        .getFullList<DailyStatRecord>({
          filter: `user = "${userId}" && day >= "${isoDay(from)}"`,
          sort: "day",
          signal,
        }),
    );
    return fillRange(list, days);
  } catch (err) {
    console.warn("loadStudyDays fallback to mock", err);
    return sliceDays(days);
  }
}

/** جمع‌بندی کلی از یک بازهٔ روزانه. */
export function totalsOf(days: StudyDay[]): StudyTotals {
  const totalMinutes = days.reduce((a, d) => a + d.minutes, 0);
  const totalSessions = days.reduce((a, d) => a + d.sessions, 0);
  const active = days.filter((d) => d.minutes > 0);
  return {
    totalMinutes,
    totalSessions,
    totalXp: 0,
    todayMinutes: days[days.length - 1]?.minutes ?? 0,
    avgAccuracy: 0,
    firstDay: active[0]?.date ?? days[0]?.date ?? "",
  };
}

/** آمار محلی (برای placeholder اولیهٔ کوئری‌ها). */
export const mockStudyDays = MOCK_DAYS;

/**
 * XP هر روز هفتهٔ جاری (دوشنبه → یکشنبه) برای کارت استریک.
 * در حالت MOCK آرایهٔ خالی برمی‌گردد تا کارت از مقدار پیش‌فرض استفاده کند.
 */
export async function loadWeekXp(userId: string): Promise<number[]> {
  if (!BACKEND || !userId) return [];
  try {
    const monday = new Date();
    monday.setHours(0, 0, 0, 0);
    monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
    const list = await pbRequest((signal) =>
      getPb()
        .collection("daily_stats")
        .getFullList<DailyStatRecord>({
          filter: `user = "${userId}" && day >= "${isoDay(monday)}"`,
          sort: "day",
          signal,
        }),
    );
    const out = [0, 0, 0, 0, 0, 0, 0];
    for (const rec of list) {
      const d = new Date(`${rec.day}T00:00:00`);
      const idx = (d.getDay() + 6) % 7;
      out[idx] = rec.xp ?? 0;
    }
    return out;
  } catch (err) {
    console.warn("loadWeekXp failed", err);
    return [];
  }
}
