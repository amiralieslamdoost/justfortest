/**
 * پیشرفت مدیا (media_progress) / Medien-Fortschritt — سشن ۵.
 *
 * - در MOCK فقط localStorage
 * - با بک‌اند: نوشتن خوش‌بینانه در localStorage + صف آفلاین (IndexedDB)
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import { resolveMediaRecordId } from "./media";
import type { MediaProgressRecord, MediaType } from "./types";

export const LS_MEDIA_PROGRESS = "deusi.media.progress.v1";
const LS_MEDIA_MIGRATED = "deusi.media.migrated.v1";

export interface MediaProgressState {
  positionSec: number;
  progress: number; // 0..100
  finished: boolean;
  plays: number;
  quizAnswers?: Record<string, unknown>;
  quizScore?: number;
  lastPlayedAt?: string;
}

export type MediaProgressMap = Record<string, MediaProgressState>;

export const EMPTY_MEDIA_PROGRESS: MediaProgressState = {
  positionSec: 0,
  progress: 0,
  finished: false,
  plays: 0,
};

/** کلید یکتای هر آیتم مدیا در نقشهٔ پیشرفت. */
export function mediaKey(type: MediaType, mediaId: string) {
  return `${type}:${mediaId}`;
}

const COLLECTION: Record<MediaType, "films" | "songs" | "episodes" | "books"> = {
  film: "films",
  song: "songs",
  episode: "episodes",
  book: "books",
};

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

export function readLocalMediaProgress(): MediaProgressMap {
  return readLocal<MediaProgressMap>(LS_MEDIA_PROGRESS, {});
}

function writeLocalMediaProgress(map: MediaProgressMap) {
  writeLocal(LS_MEDIA_PROGRESS, map);
}

/** همهٔ پیشرفت‌های کاربر (سرور + محلی). */
export async function listMediaProgress(userId: string): Promise<MediaProgressMap> {
  if (!BACKEND || !userId) return readLocalMediaProgress();
  const pb = getPb();
  try {
    const rows = await pbRequest((signal) =>
      pb.collection("media_progress").getFullList<MediaProgressRecord>({
        filter: `user = "${escapeFilter(userId)}"`,
        signal,
      }),
    );
    const map: MediaProgressMap = { ...readLocalMediaProgress() };
    for (const r of rows) {
      map[mediaKey(r.media_type, r.media_id)] = {
        positionSec: r.position_sec ?? 0,
        progress: r.progress ?? 0,
        finished: r.finished ?? false,
        plays: r.plays ?? 0,
        quizAnswers: (r.quiz_answers ?? {}) as Record<string, unknown>,
        quizScore: r.quiz_score ?? 0,
        lastPlayedAt: r.last_played_at || undefined,
      };
    }
    writeLocalMediaProgress(map);
    return map;
  } catch {
    return readLocalMediaProgress();
  }
}

/** ذخیرهٔ خوش‌بینانهٔ پیشرفت یک آیتم مدیا. */
export async function saveMediaProgress(
  userId: string,
  type: MediaType,
  mediaId: string,
  patch: Partial<MediaProgressState>,
): Promise<MediaProgressState> {
  const key = mediaKey(type, mediaId);
  const map = readLocalMediaProgress();
  const prev = map[key] ?? EMPTY_MEDIA_PROGRESS;
  const next: MediaProgressState = {
    ...prev,
    ...patch,
    quizAnswers: { ...(prev.quizAnswers ?? {}), ...(patch.quizAnswers ?? {}) },
    lastPlayedAt: new Date().toISOString(),
  };
  writeLocalMediaProgress({ ...map, [key]: next });

  if (BACKEND && userId) {
    await enqueue(
      "media.progress.upsert",
      { userId, type, mediaId, state: next },
      `media.progress:${userId}:${key}`,
    );
  }
  return next;
}

/* -------------------------------------------------------------------------- */
/* هندلر صف آفلاین                                                             */
/* -------------------------------------------------------------------------- */

async function findMediaProgress(userId: string, type: MediaType, mediaId: string) {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("media_progress")
        .getFirstListItem<MediaProgressRecord>(
          `user = "${escapeFilter(userId)}" && media_type = "${type}" && media_id = "${escapeFilter(mediaId)}"`,
          { signal },
        ),
    );
  } catch (err) {
    if (toApiError(err).kind === "notFound") return null;
    throw err;
  }
}

registerHandler("media.progress.upsert", async (payload) => {
  const { userId, type, mediaId, state } = payload as {
    userId: string;
    type: MediaType;
    mediaId: string;
    state: MediaProgressState;
  };
  if (!BACKEND || !userId) return;
  // شناسهٔ رکورد سرور را ترجیح می‌دهیم تا فیلتر پایدار بماند؛ اگر seed اجرا نشده، خود slug.
  const recordId = (await resolveMediaRecordId(COLLECTION[type], mediaId)) ?? mediaId;
  const pb = getPb();
  const existing = await findMediaProgress(userId, type, recordId);
  const data = {
    user: userId,
    media_type: type,
    media_id: recordId,
    position_sec: Math.round(state.positionSec ?? 0),
    progress: Math.round(state.progress ?? 0),
    finished: state.finished ?? (state.progress ?? 0) >= 98,
    plays: state.plays ?? 0,
    quiz_answers: state.quizAnswers ?? {},
    quiz_score: state.quizScore ?? 0,
    last_played_at: state.lastPlayedAt ?? new Date().toISOString(),
  };
  if (existing) {
    await pbRequest((signal) =>
      pb.collection("media_progress").update(existing.id, data, { signal }),
    );
  } else {
    await pbRequest((signal) => pb.collection("media_progress").create(data, { signal }));
  }
});

/** انتقال یک‌بارهٔ پیشرفت محلی مدیا به سرور. */
export async function migrateLocalMediaProgress(userId: string): Promise<void> {
  if (!BACKEND || !userId) return;
  const flags = readLocal<Record<string, boolean>>(LS_MEDIA_MIGRATED, {});
  if (flags[userId]) return;
  writeLocal(LS_MEDIA_MIGRATED, { ...flags, [userId]: true });
  for (const [key, state] of Object.entries(readLocalMediaProgress())) {
    const [type, ...rest] = key.split(":");
    const mediaId = rest.join(":");
    if (!type || !mediaId) continue;
    await enqueue(
      "media.progress.upsert",
      { userId, type: type as MediaType, mediaId, state },
      `media.progress:${userId}:${key}`,
    );
  }
}
