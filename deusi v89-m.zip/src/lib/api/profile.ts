/**
 * پروفایل کاربر و نتیجهٔ تعیین سطح.
 * در حالت MOCK روی localStorage کار می‌کند تا رفتار فعلی حفظ شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import type { Cefr, PlacementResultRecord, ProfileRecord, SkillKey } from "./types";

const LS_PROFILE = (userId: string) => `deusi.profile.${userId}`;
const LS_PLACEMENT = (userId: string) => `deusi.placement.${userId}`;

export type ProfilePatch = Partial<Omit<ProfileRecord, keyof ProfileRecord & never>> &
  Record<string, unknown>;

export interface PlacementInput {
  level: Cefr;
  score: number;
  max_score: number;
  skill_scores?: Partial<Record<SkillKey, number>>;
  answers?: Record<string, unknown>;
}

function readLocal<T>(key: string): T | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function writeLocal(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

/** پروفایل کاربر جاری. */
export async function getProfile(userId: string): Promise<Partial<ProfileRecord> | null> {
  if (!userId) return null;
  if (!BACKEND) return readLocal<Partial<ProfileRecord>>(LS_PROFILE(userId));
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb.collection("profiles").getFirstListItem<ProfileRecord>(`user="${userId}"`, { signal }),
    );
  } catch (err) {
    const api = toApiError(err);
    if (api.kind === "notFound") return null;
    throw api;
  }
}

/** به‌روزرسانی (یا ساخت) پروفایل. */
export async function updateProfile(
  userId: string,
  patch: ProfilePatch,
): Promise<Partial<ProfileRecord>> {
  if (!BACKEND) {
    const current = readLocal<Partial<ProfileRecord>>(LS_PROFILE(userId)) ?? {};
    const next = { ...current, ...patch, user: userId };
    writeLocal(LS_PROFILE(userId), next);
    return next;
  }
  const pb = getPb();
  const existing = await getProfile(userId);
  if (existing?.id) {
    return pbRequest((signal) =>
      pb.collection("profiles").update<ProfileRecord>(existing.id as string, patch, { signal }),
    );
  }
  return pbRequest((signal) =>
    pb.collection("profiles").create<ProfileRecord>({ user: userId, ...patch }, { signal }),
  );
}

/** ذخیرهٔ نتیجهٔ آزمون تعیین سطح + به‌روزرسانی سطح در پروفایل. */
export async function savePlacementResult(
  userId: string,
  input: PlacementInput,
): Promise<Partial<PlacementResultRecord>> {
  const payload = {
    user: userId,
    level: input.level,
    score: input.score,
    max_score: input.max_score,
    skill_scores: input.skill_scores ?? {},
    answers: input.answers ?? {},
    taken_at: new Date().toISOString(),
  };

  if (!BACKEND) {
    writeLocal(LS_PLACEMENT(userId), payload);
    await updateProfile(userId, { level: input.level });
    return payload;
  }

  const pb = getPb();
  const created = await pbRequest((signal) =>
    pb.collection("placement_results").create<PlacementResultRecord>(payload, { signal }),
  );
  await updateProfile(userId, { level: input.level }).catch(() => null);
  return created;
}

/** آخرین نتیجهٔ تعیین سطح. */
export async function getLatestPlacement(
  userId: string,
): Promise<Partial<PlacementResultRecord> | null> {
  if (!userId) return null;
  if (!BACKEND) return readLocal<Partial<PlacementResultRecord>>(LS_PLACEMENT(userId));
  const pb = getPb();
  const list = await pbRequest((signal) =>
    pb.collection("placement_results").getList<PlacementResultRecord>(1, 1, {
      filter: `user="${userId}"`,
      sort: "-created",
      signal,
    }),
  );
  return list.items[0] ?? null;
}
