/**
 * هوک‌های تنظیمات و اشتراک (سشن ۹).
 */
import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import { useCurrentUserId } from "./useExams";
import { BACKEND } from "./config";
import {
  DEFAULT_SETTINGS,
  getSettings,
  migrateSettings,
  saveSettings,
  type UserSettings,
} from "./settings";
import { FREE_SUBSCRIPTION, getSubscription, requestPlanChange, type PlanId } from "./subscription";

/** تنظیمات کاربر جاری + ذخیرهٔ خوش‌بینانه. */
export function useSettings() {
  const userId = useCurrentUserId();
  const qc = useQueryClient();
  const key = queryKeys.profile.settings();

  useEffect(() => {
    if (BACKEND && userId) void migrateSettings(userId);
  }, [userId]);

  const q = useQuery({
    queryKey: [...key, userId],
    queryFn: () => getSettings(userId),
    staleTime: 60_000,
    initialData: DEFAULT_SETTINGS,
  });

  const save = useMutation({
    mutationFn: (patch: Partial<UserSettings>) => saveSettings(userId, patch),
    onMutate: (patch: Partial<UserSettings>) => {
      qc.setQueryData<UserSettings>([...key, userId], (prev) => ({
        ...(prev ?? DEFAULT_SETTINGS),
        ...patch,
      }));
    },
  });

  return {
    settings: (q.data ?? DEFAULT_SETTINGS) as UserSettings,
    isLoading: q.isLoading,
    save: (patch: Partial<UserSettings>) => save.mutate(patch),
    isSaving: save.isPending,
  };
}

/** اشتراک کاربر جاری + ثبت درخواست تغییر پلن. */
export function useSubscription() {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: [...queryKeys.profile.subscription(), userId],
    queryFn: () => getSubscription(userId),
    staleTime: 5 * 60_000,
    initialData: FREE_SUBSCRIPTION,
  });

  const request = useMutation({
    mutationFn: (plan: PlanId) => requestPlanChange(userId, plan),
  });

  return {
    subscription: q.data ?? FREE_SUBSCRIPTION,
    isLoading: q.isLoading,
    requestPlan: (plan: PlanId) => request.mutateAsync(plan),
    isRequesting: request.isPending,
  };
}
