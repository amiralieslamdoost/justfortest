/**
 * هوک پروفایل کاربر (سشن ۹).
 * `src/lib/api/profile.ts` را به لایهٔ TanStack Query وصل می‌کند تا صفحهٔ
 * profil مستقیم PocketBase را صدا نزند. در MOCK_MODE روی localStorage کار
 * می‌کند و همان رفتار قبلی حفظ می‌شود.
 */
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import { useCurrentUserId } from "./useExams";
import { getLatestPlacement, getProfile, updateProfile, type ProfilePatch } from "./profile";
import type { ProfileRecord } from "./types";

export type UserProfile = Partial<ProfileRecord>;

/** پروفایل کاربر جاری + ذخیرهٔ خوش‌بینانه. */
export function useProfile() {
  const userId = useCurrentUserId();
  const qc = useQueryClient();
  const key = [...queryKeys.profile.me(), userId];

  const q = useQuery({
    queryKey: key,
    queryFn: () => getProfile(userId),
    enabled: Boolean(userId),
    staleTime: 60_000,
  });

  const save = useMutation({
    mutationFn: (patch: ProfilePatch) => updateProfile(userId, patch),
    onMutate: (patch: ProfilePatch) => {
      qc.setQueryData<UserProfile | null>(key, (prev) => ({ ...(prev ?? {}), ...patch }));
    },
    onSuccess: (next) => {
      qc.setQueryData<UserProfile | null>(key, next);
    },
  });

  return {
    profile: (q.data ?? null) as UserProfile | null,
    isLoading: q.isLoading,
    save: (patch: ProfilePatch) => save.mutate(patch),
    saveAsync: (patch: ProfilePatch) => save.mutateAsync(patch),
    isSaving: save.isPending,
    userId,
  };
}

/** آخرین نتیجهٔ تعیین سطح کاربر جاری. */
export function usePlacement() {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: [...queryKeys.profile.placement(), userId],
    queryFn: () => getLatestPlacement(userId),
    enabled: Boolean(userId),
    staleTime: 5 * 60_000,
  });
  return { placement: q.data ?? null, isLoading: q.isLoading };
}
