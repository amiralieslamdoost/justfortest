/**
 * هوک‌های TanStack Query برای دامنهٔ نوشتن (schreiben).
 */
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import {
  listWritingSubmissions,
  saveWriting,
  submitWriting,
  type WritingEntry,
  type WritingMap,
} from "./writing";
import { useDeusi } from "@/lib/deusi/store";

export function useWritingSubmissions() {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const qc = useQueryClient();

  const q = useQuery({
    queryKey: queryKeys.reading.writingList(userId),
    queryFn: () => listWritingSubmissions(userId),
    staleTime: 60_000,
    initialData: {} as WritingMap,
  });

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: queryKeys.reading.writingList(userId) });
  };

  const save = useMutation({
    mutationFn: (entry: Omit<WritingEntry, "updatedAt">) => saveWriting(userId, entry),
    onSuccess: invalidate,
  });

  const submit = useMutation({
    mutationFn: (entry: Omit<WritingEntry, "updatedAt" | "status" | "submittedAt">) =>
      submitWriting(userId, entry),
    onSuccess: invalidate,
  });

  return {
    submissions: q.data ?? {},
    isLoading: q.isLoading,
    saveDraft: (entry: Omit<WritingEntry, "updatedAt">) => save.mutate(entry),
    submit: (entry: Omit<WritingEntry, "updatedAt" | "status" | "submittedAt">) =>
      submit.mutate(entry),
    isSaving: save.isPending,
    isSubmitting: submit.isPending,
  };
}
