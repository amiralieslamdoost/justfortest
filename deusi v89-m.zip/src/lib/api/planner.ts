/**
 * دامنهٔ برنامه‌ریز (Planner) — سشن ۷.
 *
 * - پروفایل برنامه‌ریزی: کالکشن `study_plans`
 * - بلوک‌های هفتگی: کالکشن `plan_sessions`
 * - لاگ سشن‌های انجام‌شده: کالکشن `session_logs`
 *
 * الگو مثل بقیهٔ دامنه‌ها: «اول محلی، بعد سرور».
 * هر نوشتن بلافاصله در localStorage (همان کلید قبلی `deusi.planner.<userId>`)
 * ذخیره می‌شود تا رفرش/قطع شبکه چیزی از بین نبرد، و در حالت BACKEND از طریق
 * صف آفلاین با PocketBase همگام می‌شود.
 * در `MOCK_MODE` دقیقاً رفتار قبلی حفظ می‌شود (فقط localStorage).
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import type { PlanSessionRecord, SessionLogRecord, StudyPlanRecord } from "./types";
import { toMinutes, weekStartOf } from "@/lib/deusi/planner/date";
import type {
  PlannerPrefs,
  PlannerSession,
  PlannerWeek,
  PlannerWeekMeta,
  SkillKey,
} from "@/lib/deusi/planner/types";

/* -------------------------------------------------------------------------- */
/* آینهٔ محلی                                                                   */
/* -------------------------------------------------------------------------- */

const KEY = (userId: string) => `deusi.planner.${userId}`;
const REMOTE_KEY = (userId: string) => `deusi.planner.remote.${userId}`;
const MIGRATED_KEY = "deusi.planner.migrated.v1";

type LocalShape = {
  prefs: PlannerPrefs | null;
  weeks: Record<string, PlannerWeekMeta>;
  sessions: PlannerSession[];
};

const EMPTY: LocalShape = { prefs: null, weeks: {}, sessions: [] };

function readMirror(userId: string): LocalShape {
  const raw = readLocal<Partial<LocalShape> | null>(KEY(userId), null);
  if (!raw) return { prefs: null, weeks: {}, sessions: [] };
  return {
    prefs: raw.prefs ?? null,
    weeks: raw.weeks ?? {},
    sessions: Array.isArray(raw.sessions) ? raw.sessions : [],
  };
}

function writeMirror(userId: string, data: LocalShape) {
  writeLocal(KEY(userId), data);
}

/** نگاشت شناسهٔ محلی سشن به شناسهٔ رکورد PocketBase. */
type RemoteMap = { plan?: string; sessions: Record<string, string> };

function readRemoteMap(userId: string): RemoteMap {
  const raw = readLocal<Partial<RemoteMap> | null>(REMOTE_KEY(userId), null);
  return { plan: raw?.plan, sessions: raw?.sessions ?? {} };
}

function writeRemoteMap(userId: string, map: RemoteMap) {
  writeLocal(REMOTE_KEY(userId), map);
}

function rememberSessionId(userId: string, localId: string, remoteId: string) {
  const map = readRemoteMap(userId);
  map.sessions[localId] = remoteId;
  writeRemoteMap(userId, map);
}

function remoteSessionId(userId: string, localId: string): string | undefined {
  return readRemoteMap(userId).sessions[localId];
}

function forgetSessionId(userId: string, localId: string) {
  const map = readRemoteMap(userId);
  delete map.sessions[localId];
  writeRemoteMap(userId, map);
}

export function sortSessions(sessions: PlannerSession[]): PlannerSession[] {
  return [...sessions].sort(
    (a, b) => a.date.localeCompare(b.date) || toMinutes(a.start) - toMinutes(b.start),
  );
}

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

function weekEndOf(weekStart: string): string {
  const d = new Date(`${weekStart}T00:00:00`);
  d.setDate(d.getDate() + 6);
  return d.toISOString().slice(0, 10);
}

/* -------------------------------------------------------------------------- */
/* نگاشت رکورد ↔ تایپ UI                                                        */
/* -------------------------------------------------------------------------- */

function prefsFromRecord(rec: StudyPlanRecord): PlannerPrefs {
  const extra = (rec.prefs ?? {}) as Partial<PlannerPrefs>;
  return {
    level: rec.level,
    goals: rec.goals ?? [],
    weakSkills: rec.weak_skills ?? [],
    strongSkills: rec.strong_skills ?? [],
    dailyMinutes: rec.daily_minutes || 45,
    availableDays: rec.available_days ?? [],
    startHour: rec.preferred_start || "18:00",
    targetDate: extra.targetDate ?? null,
    intensity: rec.intensity,
    restDays: extra.restDays ?? "auto",
    updatedAt: rec.updated ?? new Date().toISOString(),
  };
}

function prefsToRecord(userId: string, prefs: PlannerPrefs, meta?: PlannerWeekMeta) {
  return {
    user: userId,
    level: prefs.level,
    goals: prefs.goals,
    weak_skills: prefs.weakSkills,
    strong_skills: prefs.strongSkills,
    daily_minutes: prefs.dailyMinutes,
    available_days: prefs.availableDays,
    preferred_start: prefs.startHour,
    intensity: prefs.intensity,
    week_start: meta?.weekStart ?? weekStartOf(new Date().toISOString().slice(0, 10)),
    target_minutes: meta?.targetMinutes ?? 0,
    active: true,
    generated_at: meta?.generatedAt ?? "",
    prefs: { targetDate: prefs.targetDate, restDays: prefs.restDays },
  };
}

function sessionFromRecord(rec: PlanSessionRecord): PlannerSession {
  return {
    id: rec.id,
    date: rec.date,
    start: rec.start,
    end: rec.end,
    minutes: rec.minutes,
    activityId: rec.activity_id,
    module: rec.module as PlannerSession["module"],
    skill: rec.skill,
    title: rec.title,
    description: rec.description ?? "",
    level: rec.level,
    priority: rec.priority,
    status: rec.status,
    href: rec.href as PlannerSession["href"],
    cta: rec.cta as PlannerSession["cta"],
    resourceId: rec.resource_id || undefined,
    generated: Boolean(rec.generated),
    edited: Boolean(rec.edited),
    createdAt: rec.created ?? new Date().toISOString(),
    updatedAt: rec.updated ?? new Date().toISOString(),
  };
}

function sessionToRecord(userId: string, planId: string | undefined, s: PlannerSession) {
  return {
    user: userId,
    plan: planId ?? "",
    date: s.date,
    start: s.start,
    end: s.end,
    minutes: s.minutes,
    activity_id: s.activityId,
    module: s.module,
    skill: s.skill,
    title: s.title,
    description: s.description ?? "",
    level: s.level,
    priority: s.priority,
    status: s.status,
    href: s.href,
    cta: s.cta,
    resource_id: s.resourceId ?? "",
    generated: s.generated,
    edited: s.edited,
  };
}

/* -------------------------------------------------------------------------- */
/* رکورد برنامه (study_plans)                                                   */
/* -------------------------------------------------------------------------- */

async function findPlanRecord(userId: string): Promise<StudyPlanRecord | null> {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("study_plans")
        .getFirstListItem<StudyPlanRecord>(`user = "${escapeFilter(userId)}" && active = true`, {
          signal,
        }),
    );
  } catch {
    return null;
  }
}

/** شناسهٔ رکورد برنامه (در صورت نبود، ساخته می‌شود). */
async function ensurePlanRecord(
  userId: string,
  prefs: PlannerPrefs,
  meta?: PlannerWeekMeta,
): Promise<string | undefined> {
  if (!BACKEND || !userId) return undefined;
  const pb = getPb();
  const cached = readRemoteMap(userId).plan;
  const data = prefsToRecord(userId, prefs, meta);
  try {
    if (cached) {
      await pbRequest((signal) => pb.collection("study_plans").update(cached, data, { signal }));
      return cached;
    }
    const existing = await findPlanRecord(userId);
    if (existing) {
      await pbRequest((signal) =>
        pb.collection("study_plans").update(existing.id, data, { signal }),
      );
      const map = readRemoteMap(userId);
      writeRemoteMap(userId, { ...map, plan: existing.id });
      return existing.id;
    }
    const created = await pbRequest((signal) =>
      pb.collection("study_plans").create<StudyPlanRecord>(data, { signal }),
    );
    const map = readRemoteMap(userId);
    writeRemoteMap(userId, { ...map, plan: created.id });
    return created.id;
  } catch (err) {
    console.warn("[planner] plan record sync failed", err);
    return cached;
  }
}

/* -------------------------------------------------------------------------- */
/* خواندن                                                                       */
/* -------------------------------------------------------------------------- */

/** پروفایل برنامه‌ریزی کاربر (سرور یا آینهٔ محلی). */
export async function loadPrefs(userId: string): Promise<PlannerPrefs | null> {
  const local = readMirror(userId).prefs;
  if (!BACKEND || !userId) return local;
  try {
    const rec = await findPlanRecord(userId);
    if (!rec) return local;
    const prefs = prefsFromRecord(rec);
    const map = readRemoteMap(userId);
    writeRemoteMap(userId, { ...map, plan: rec.id });
    const mirror = readMirror(userId);
    writeMirror(userId, { ...mirror, prefs });
    return prefs;
  } catch (err) {
    console.warn("[planner] load prefs offline", err);
    return local;
  }
}

function localWeek(userId: string, weekStart: string): PlannerWeek | null {
  const mirror = readMirror(userId);
  const sessions = mirror.sessions.filter((s) => weekStartOf(s.date) === weekStart);
  const meta = mirror.weeks[weekStart];
  if (!meta && !sessions.length) return null;
  return {
    weekStart,
    targetMinutes: meta?.targetMinutes ?? 0,
    generatedAt: meta?.generatedAt ?? null,
    sessions: sortSessions(sessions),
  };
}

/** بلوک‌های یک هفته. */
export async function loadWeek(userId: string, weekStart: string): Promise<PlannerWeek | null> {
  const local = localWeek(userId, weekStart);
  if (!BACKEND || !userId) return local;
  const pb = getPb();
  try {
    const rows = await pbRequest((signal) =>
      pb.collection("plan_sessions").getFullList<PlanSessionRecord>({
        filter: `user = "${escapeFilter(userId)}" && date >= "${weekStart}" && date <= "${weekEndOf(
          weekStart,
        )}"`,
        sort: "date,start",
        signal,
      }),
    );
    const sessions = sortSessions(rows.map(sessionFromRecord));
    const map = readRemoteMap(userId);
    for (const s of sessions) map.sessions[s.id] = s.id;
    writeRemoteMap(userId, map);

    const week: PlannerWeek = {
      weekStart,
      targetMinutes: local?.targetMinutes ?? 0,
      generatedAt: local?.generatedAt ?? null,
      sessions,
    };
    // آینهٔ محلی را با وضعیت سرور یکی می‌کنیم (همگام‌سازی چنددستگاهی).
    const mirror = readMirror(userId);
    writeMirror(userId, {
      ...mirror,
      weeks: {
        ...mirror.weeks,
        [weekStart]: {
          weekStart,
          targetMinutes: week.targetMinutes,
          generatedAt: week.generatedAt,
        },
      },
      sessions: [...mirror.sessions.filter((s) => weekStartOf(s.date) !== weekStart), ...sessions],
    });
    if (!sessions.length && local?.sessions.length) return local;
    return week;
  } catch (err) {
    console.warn("[planner] load week offline", err);
    return local;
  }
}

/* -------------------------------------------------------------------------- */
/* نوشتن                                                                        */
/* -------------------------------------------------------------------------- */

/** ذخیرهٔ پروفایل برنامه‌ریزی. */
export async function savePrefs(userId: string, prefs: PlannerPrefs): Promise<void> {
  const mirror = readMirror(userId);
  writeMirror(userId, { ...mirror, prefs });
  if (!BACKEND || !userId) return;
  await enqueue("planner.plan.save", { userId, prefs }, `planner.plan:${userId}`);
}

/** جایگزینی کامل یک هفته (بازتولید برنامه). */
export async function saveWeek(userId: string, week: PlannerWeek): Promise<void> {
  const mirror = readMirror(userId);
  writeMirror(userId, {
    ...mirror,
    weeks: {
      ...mirror.weeks,
      [week.weekStart]: {
        weekStart: week.weekStart,
        targetMinutes: week.targetMinutes,
        generatedAt: week.generatedAt,
      },
    },
    sessions: [
      ...mirror.sessions.filter((s) => weekStartOf(s.date) !== week.weekStart),
      ...week.sessions,
    ],
  });
  if (!BACKEND || !userId) return;
  await enqueue(
    "planner.week.replace",
    { userId, weekStart: week.weekStart, sessions: week.sessions },
    `planner.week:${userId}:${week.weekStart}`,
  );
}

/** ذخیرهٔ یک بلوک (ساخت یا ویرایش). */
export async function putSession(userId: string, session: PlannerSession): Promise<void> {
  const mirror = readMirror(userId);
  writeMirror(userId, {
    ...mirror,
    sessions: [...mirror.sessions.filter((s) => s.id !== session.id), session],
  });
  if (!BACKEND || !userId) return;
  await enqueue(
    "planner.session.upsert",
    { userId, session },
    `planner.session:${userId}:${session.id}`,
  );
}

/** حذف یک بلوک. */
export async function deleteSession(userId: string, sessionId: string): Promise<void> {
  const mirror = readMirror(userId);
  writeMirror(userId, { ...mirror, sessions: mirror.sessions.filter((s) => s.id !== sessionId) });
  if (!BACKEND || !userId) return;
  await enqueue(
    "planner.session.delete",
    { userId, sessionId },
    `planner.sessionDel:${userId}:${sessionId}`,
  );
}

export interface SessionLogInput {
  sessionId: string;
  skill: SkillKey;
  minutes: number;
  itemsDone?: number;
  accuracy?: number;
  startedAt?: string;
  endedAt?: string;
  meta?: Record<string, unknown>;
}

export const LS_SESSION_LOGS = "deusi.planner.logs.v1";

export interface SessionLogEntry extends SessionLogInput {
  id: string;
  userId: string;
  createdAt: string;
}

/** لاگ یک بلوک انجام‌شده (پایهٔ آمار سشن ۹). */
export async function logSession(userId: string, input: SessionLogInput): Promise<void> {
  const entry: SessionLogEntry = {
    ...input,
    id: `log_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    userId,
    createdAt: new Date().toISOString(),
  };
  const logs = readLocal<SessionLogEntry[]>(LS_SESSION_LOGS, []);
  writeLocal(LS_SESSION_LOGS, [entry, ...logs].slice(0, 500));
  if (!BACKEND || !userId) return;
  await enqueue("planner.log.create", { userId, entry }, `planner.log:${entry.id}`);
}

/** لاگ‌های محلی (برای نمایش سریع تا سشن ۹). */
export function listLocalLogs(userId: string): SessionLogEntry[] {
  return readLocal<SessionLogEntry[]>(LS_SESSION_LOGS, []).filter((l) => l.userId === userId);
}

/* -------------------------------------------------------------------------- */
/* مهاجرت یک‌بارهٔ دادهٔ محلی به سرور                                            */
/* -------------------------------------------------------------------------- */

export async function migrateLocalPlanner(userId: string): Promise<void> {
  if (!BACKEND || !userId) return;
  const done = readLocal<Record<string, boolean>>(MIGRATED_KEY, {});
  if (done[userId]) return;
  const mirror = readMirror(userId);
  try {
    if (mirror.prefs) {
      const planId = await ensurePlanRecord(userId, mirror.prefs);
      const pb = getPb();
      const existing = await pbRequest((signal) =>
        pb.collection("plan_sessions").getFullList<PlanSessionRecord>({
          filter: `user = "${escapeFilter(userId)}"`,
          signal,
        }),
      );
      const known = new Set(existing.map((r) => `${r.date}|${r.start}|${r.activity_id}`));
      for (const s of mirror.sessions) {
        if (known.has(`${s.date}|${s.start}|${s.activityId}`)) continue;
        const created = await pbRequest((signal) =>
          pb
            .collection("plan_sessions")
            .create<PlanSessionRecord>(sessionToRecord(userId, planId, s), { signal }),
        );
        rememberSessionId(userId, s.id, created.id);
      }
    }
    writeLocal(MIGRATED_KEY, { ...done, [userId]: true });
  } catch (err) {
    console.warn("[planner] migration deferred", err);
  }
}

/* -------------------------------------------------------------------------- */
/* هندلرهای صف آفلاین                                                           */
/* -------------------------------------------------------------------------- */

async function upsertRemoteSession(userId: string, session: PlannerSession) {
  const pb = getPb();
  const mirror = readMirror(userId);
  const planId = mirror.prefs
    ? await ensurePlanRecord(userId, mirror.prefs, mirror.weeks[weekStartOf(session.date)])
    : readRemoteMap(userId).plan;
  const data = sessionToRecord(userId, planId, session);
  const remoteId = remoteSessionId(userId, session.id);
  if (remoteId) {
    try {
      await pbRequest((signal) =>
        pb.collection("plan_sessions").update(remoteId, data, { signal }),
      );
      return;
    } catch {
      forgetSessionId(userId, session.id);
    }
  }
  const created = await pbRequest((signal) =>
    pb.collection("plan_sessions").create<PlanSessionRecord>(data, { signal }),
  );
  rememberSessionId(userId, session.id, created.id);
}

registerHandler("planner.plan.save", async (payload) => {
  const { userId, prefs } = payload as { userId: string; prefs: PlannerPrefs };
  if (!BACKEND || !userId) return;
  const mirror = readMirror(userId);
  const weeks = Object.values(mirror.weeks);
  await ensurePlanRecord(userId, prefs, weeks[weeks.length - 1]);
});

registerHandler("planner.session.upsert", async (payload) => {
  const { userId, session } = payload as { userId: string; session: PlannerSession };
  if (!BACKEND || !userId) return;
  await upsertRemoteSession(userId, session);
});

registerHandler("planner.session.delete", async (payload) => {
  const { userId, sessionId } = payload as { userId: string; sessionId: string };
  if (!BACKEND || !userId) return;
  const remoteId = remoteSessionId(userId, sessionId) ?? sessionId;
  const pb = getPb();
  try {
    await pbRequest((signal) => pb.collection("plan_sessions").delete(remoteId, { signal }));
  } catch (err) {
    console.warn("[planner] delete session skipped", err);
  }
  forgetSessionId(userId, sessionId);
});

registerHandler("planner.week.replace", async (payload) => {
  const { userId, weekStart, sessions } = payload as {
    userId: string;
    weekStart: string;
    sessions: PlannerSession[];
  };
  if (!BACKEND || !userId) return;
  const pb = getPb();
  const keep = new Set(
    sessions.map((s) => remoteSessionId(userId, s.id)).filter(Boolean) as string[],
  );
  const existing = await pbRequest((signal) =>
    pb.collection("plan_sessions").getFullList<PlanSessionRecord>({
      filter: `user = "${escapeFilter(userId)}" && date >= "${weekStart}" && date <= "${weekEndOf(
        weekStart,
      )}"`,
      signal,
    }),
  );
  for (const rec of existing) {
    if (keep.has(rec.id)) continue;
    await pbRequest((signal) => pb.collection("plan_sessions").delete(rec.id, { signal }));
  }
  for (const session of sessions) {
    await upsertRemoteSession(userId, session);
  }
});

registerHandler("planner.log.create", async (payload) => {
  const { userId, entry } = payload as { userId: string; entry: SessionLogEntry };
  if (!BACKEND || !userId) return;
  const pb = getPb();
  await pbRequest((signal) =>
    pb.collection("session_logs").create(
      {
        user: userId,
        session: remoteSessionId(userId, entry.sessionId) ?? "",
        skill: entry.skill,
        minutes: entry.minutes,
        items_done: entry.itemsDone ?? 0,
        accuracy: entry.accuracy ?? 0,
        xp_earned: 0,
        started_at: entry.startedAt ?? entry.createdAt,
        ended_at: entry.endedAt ?? entry.createdAt,
        meta: entry.meta ?? {},
      },
      { signal },
    ),
  );
});

/* -------------------------------------------------------------------------- */
/* خواندن لاگ سشن‌ها (تاریخچه و خلاصهٔ هفتگی)                                    */
/* -------------------------------------------------------------------------- */

function logFromRecord(userId: string, rec: SessionLogRecord): SessionLogEntry {
  return {
    id: rec.id,
    userId,
    sessionId: rec.session || "",
    skill: rec.skill,
    minutes: rec.minutes ?? 0,
    itemsDone: rec.items_done ?? 0,
    accuracy: rec.accuracy ?? 0,
    startedAt: rec.started_at || rec.created,
    endedAt: rec.ended_at || rec.created,
    meta: rec.meta ?? {},
    createdAt: rec.created ?? new Date().toISOString(),
  };
}

function logDay(entry: SessionLogEntry): string {
  return (entry.startedAt ?? entry.createdAt).slice(0, 10);
}

function mergeLogs(a: SessionLogEntry[], b: SessionLogEntry[]): SessionLogEntry[] {
  const seen = new Map<string, SessionLogEntry>();
  for (const entry of [...a, ...b]) {
    // کلید ادغام: لاگ سرور و لاگ محلیِ همان بلوک نباید دوبار شمرده شوند.
    const key = `${entry.sessionId}|${logDay(entry)}|${entry.minutes}|${entry.skill}`;
    if (!seen.has(key)) seen.set(key, entry);
  }
  return [...seen.values()].sort((x, y) =>
    (logDay(y) + y.createdAt).localeCompare(logDay(x) + x.createdAt),
  );
}

/** لاگ سشن‌ها در یک بازهٔ تاریخ (پیش‌فرض: همهٔ لاگ‌های محلی). */
export async function listLogs(
  userId: string,
  range?: { from?: string; to?: string },
): Promise<SessionLogEntry[]> {
  const inRange = (e: SessionLogEntry) => {
    const day = logDay(e);
    if (range?.from && day < range.from) return false;
    if (range?.to && day > range.to) return false;
    return true;
  };
  const local = listLocalLogs(userId).filter(inRange);
  if (!BACKEND || !userId) return mergeLogs(local, []);

  const pb = getPb();
  const parts = [`user = "${escapeFilter(userId)}"`];
  if (range?.from) parts.push(`started_at >= "${range.from} 00:00:00"`);
  if (range?.to) parts.push(`started_at <= "${range.to} 23:59:59"`);
  try {
    const rows = await pbRequest((signal) =>
      pb.collection("session_logs").getFullList<SessionLogRecord>({
        filter: parts.join(" && "),
        sort: "-started_at",
        signal,
      }),
    );
    return mergeLogs(
      rows.map((r) => logFromRecord(userId, r)),
      local,
    );
  } catch (err) {
    console.warn("[planner] load logs offline", err);
    return mergeLogs(local, []);
  }
}

/** لاگ‌های یک هفته. */
export function weekLogRange(weekStart: string): { from: string; to: string } {
  return { from: weekStart, to: weekEndOf(weekStart) };
}

export interface LogSummary {
  totalMinutes: number;
  sessionCount: number;
  itemsDone: number;
  activeDays: number;
  bySkill: Partial<Record<SkillKey, number>>;
  /** طولانی‌ترین زنجیرهٔ روزهای پشت‌سرهم تا امروز. */
  streak: number;
}

/** خلاصهٔ آماری مجموعه‌ای از لاگ‌ها. */
export function summarizeLogs(logs: SessionLogEntry[]): LogSummary {
  const bySkill: Partial<Record<SkillKey, number>> = {};
  const days = new Set<string>();
  let totalMinutes = 0;
  let itemsDone = 0;
  for (const l of logs) {
    totalMinutes += l.minutes ?? 0;
    itemsDone += l.itemsDone ?? 0;
    bySkill[l.skill] = (bySkill[l.skill] ?? 0) + (l.minutes ?? 0);
    days.add(logDay(l));
  }

  let streak = 0;
  const cursor = new Date();
  // اگر امروز چیزی ثبت نشده، از دیروز شروع می‌کنیم تا استریک بی‌دلیل صفر نشود.
  if (!days.has(cursor.toISOString().slice(0, 10))) cursor.setDate(cursor.getDate() - 1);
  while (days.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }

  return {
    totalMinutes,
    sessionCount: logs.length,
    itemsDone,
    activeDays: days.size,
    bySkill,
    streak,
  };
}

/* -------------------------------------------------------------------------- */
/* همگام‌سازی چنددستگاهی (realtime)                                             */
/* -------------------------------------------------------------------------- */

export type PlannerChange = "plan" | "sessions" | "logs";

/**
 * اشتراک realtime روی کالکشن‌های برنامه‌ریز.
 * در `MOCK_MODE` یا بدون کاربر، هیچ اتصالی باز نمی‌شود.
 */
export function subscribePlanner(
  userId: string,
  onChange: (what: PlannerChange) => void,
): () => void {
  if (!BACKEND || !userId) return () => {};
  let disposed = false;
  const unsubs: Array<() => void> = [];
  const filter = `user = "${escapeFilter(userId)}"`;

  const bind = async (collection: string, what: PlannerChange) => {
    try {
      const pb = getPb();
      const unsub = await pb
        .collection(collection)
        .subscribe("*", () => onChange(what), { filter });
      if (disposed) void unsub();
      else unsubs.push(() => void unsub());
    } catch (err) {
      console.warn(`[planner] realtime ${collection} unavailable`, err);
    }
  };

  void bind("study_plans", "plan");
  void bind("plan_sessions", "sessions");
  void bind("session_logs", "logs");

  return () => {
    disposed = true;
    for (const u of unsubs) u();
    unsubs.length = 0;
  };
}
