/**
 * هوک‌های TanStack Query برای دامنهٔ گرامر.
 * کامپوننت‌ها فقط از این هوک‌ها استفاده می‌کنند.
 */
import { useCallback, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import {
  applyProgress,
  grammarStatsFrom,
  listGrammarTopics,
  listLessonProgress,
  saveExerciseAnswer,
  saveLessonProgress,
  type LessonProgress,
  type LessonProgressMap,
} from "./grammar";
import { grammarTopics as MOCK_TOPICS, type GrammarTopic } from "@/lib/deusi/mockGrammar";
import { useDeusi } from "@/lib/deusi/store";

/** موضوع‌های گرامر با وضعیت واقعی پیشرفت کاربر. */
export function useGrammarTopics() {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";

  const topicsQuery = useQuery({
    queryKey: queryKeys.grammar.topics(),
    queryFn: listGrammarTopics,
    staleTime: 5 * 60_000,
    initialData: MOCK_TOPICS,
  });

  const progressQuery = useQuery({
    queryKey: queryKeys.grammar.lessonProgress(userId),
    queryFn: () => listLessonProgress(userId),
    staleTime: 60_000,
    initialData: {} as LessonProgressMap,
  });

  const topics: GrammarTopic[] = useMemo(
    () => applyProgress(topicsQuery.data ?? MOCK_TOPICS, progressQuery.data ?? {}),
    [topicsQuery.data, progressQuery.data],
  );

  return {
    topics,
    progress: progressQuery.data ?? {},
    stats: useMemo(() => grammarStatsFrom(topics), [topics]),
    isLoading: topicsQuery.isLoading,
    error: topicsQuery.error,
  };
}

/** یک موضوع مشخص. */
export function useGrammarTopic(topicId: string) {
  const { topics, progress, isLoading, error } = useGrammarTopics();
  const topic = useMemo(() => topics.find((t) => t.id === topicId), [topics, topicId]);
  return { topic, topics, progress, isLoading, error };
}

/** یک درس مشخص از یک موضوع. */
export function useGrammarLesson(topicId: string, lessonId: string) {
  const { topic, progress, isLoading, error } = useGrammarTopic(topicId);
  const lesson = useMemo(() => topic?.lessons.find((l) => l.id === lessonId), [topic, lessonId]);
  return { topic, lesson, progress: progress[lessonId], isLoading, error };
}

/** ذخیرهٔ پیشرفت درس و پاسخ تمرین‌ها. */
export function useLessonProgressMutations(topicId: string, lessonId: string) {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const qc = useQueryClient();

  const invalidate = useCallback(() => {
    void qc.invalidateQueries({ queryKey: queryKeys.grammar.lessonProgress(userId) });
  }, [qc, userId]);

  const save = useMutation({
    mutationFn: (patch: Partial<LessonProgress>) =>
      saveLessonProgress(userId, { ...patch, topicId, lessonId }),
    onSuccess: invalidate,
  });

  const answer = useMutation({
    mutationFn: (args: { exerciseId: string; value: unknown; correct?: boolean }) =>
      saveExerciseAnswer(userId, { ...args, topicId, lessonId }),
    onSuccess: invalidate,
  });

  return {
    saveProgress: (patch: Partial<LessonProgress>) => save.mutate(patch),
    markDone: (score = 100) => save.mutate({ progress: 100, status: "done", score }),
    saveAnswer: (exerciseId: string, value: unknown, correct?: boolean) =>
      answer.mutate({ exerciseId, value, correct }),
    isSaving: save.isPending || answer.isPending,
  };
}
