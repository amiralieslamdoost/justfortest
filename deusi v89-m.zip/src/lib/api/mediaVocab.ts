/**
 * واژه‌های ذخیره‌شده از داخل مدیا (media_vocab) — سشن ۵.
 *
 * هر ذخیره دو کار می‌کند:
 * 1) رکورد `media_vocab` (منبع، زمان، جملهٔ نمونه)
 * 2) افزودن واژه به `user_words` از مسیر موجود لایهٔ واژگان (createCustomWord)
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import { createCustomWord } from "./vocabulary";
import { resolveMediaRecordId } from "./media";
import type { MediaType, MediaVocabRecord } from "./types";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import type { Word } from "@/lib/deusi/types";

/** متن سادهٔ واژه (مثل کلیک روی زیرنویس فیلم). */
export interface PlainMediaWord {
  text: string;
  translation?: string;
}

/** واژهٔ ورودی: `DictWord`، `Word` فروشگاه یا متن ساده. */
export type MediaWordInput = DictWord | Word | PlainMediaWord;

function isDictWord(w: MediaWordInput): w is DictWord {
  return typeof (w as DictWord).headword === "string";
}

function isPlain(w: MediaWordInput): w is PlainMediaWord {
  return typeof (w as PlainMediaWord).text === "string";
}

/** متن آلمانی واژه برای ذخیره در `media_vocab`. */
export function mediaWordText(w: MediaWordInput): string {
  if (isPlain(w)) return w.text;
  if (isDictWord(w)) return w.headword;
  if (w.pos === "noun") return w.singular;
  if (w.pos === "verb") return w.infinitive;
  return (w as { base?: string; id: string }).base ?? w.id;
}

export const LS_MEDIA_VOCAB = "deusi.media.vocab.v1";

export interface MediaVocabEntry {
  id: string; // `${type}:${mediaId}:${wordText}`
  type: MediaType;
  mediaId: string;
  wordText: string;
  context: string;
  timestampSec: number;
  createdAt: string;
}

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

export function readLocalMediaVocab(): MediaVocabEntry[] {
  return readLocal<MediaVocabEntry[]>(LS_MEDIA_VOCAB, []);
}

/** فهرست واژه‌های ذخیره‌شده از مدیا (اختیاری فیلتر بر اساس یک آیتم). */
export async function listMediaVocab(
  userId: string,
  filter: { type?: MediaType; mediaId?: string } = {},
): Promise<MediaVocabEntry[]> {
  const local = readLocalMediaVocab().filter(
    (e) =>
      (!filter.type || e.type === filter.type) && (!filter.mediaId || e.mediaId === filter.mediaId),
  );
  if (!BACKEND || !userId) return local;
  const pb = getPb();
  try {
    const parts = [`user = "${escapeFilter(userId)}"`];
    if (filter.type) parts.push(`media_type = "${filter.type}"`);
    const rows = await pbRequest((signal) =>
      pb.collection("media_vocab").getFullList<MediaVocabRecord>({
        filter: parts.join(" && "),
        sort: "-created",
        signal,
      }),
    );
    const items = rows.map<MediaVocabEntry>((r) => ({
      id: `${r.media_type}:${r.media_id}:${r.word_text}`,
      type: r.media_type,
      mediaId: r.media_id,
      wordText: r.word_text,
      context: r.context ?? "",
      timestampSec: r.timestamp_sec ?? 0,
      createdAt: r.created,
    }));
    return items.length ? items : local;
  } catch {
    return local;
  }
}

/**
 * ذخیرهٔ یک واژه از داخل مدیا.
 * `word` همان `DictWord` است تا در دیکشنری/لایتنر کاربر هم دیده شود.
 */
export async function saveMediaWord(
  userId: string,
  input: {
    type: MediaType;
    mediaId: string;
    word: MediaWordInput;
    context?: string;
    timestampSec?: number;
  },
): Promise<void> {
  const wordText = mediaWordText(input.word);
  const entry: MediaVocabEntry = {
    id: `${input.type}:${input.mediaId}:${wordText}`,
    type: input.type,
    mediaId: input.mediaId,
    wordText,
    context: input.context ?? "",
    timestampSec: Math.round(input.timestampSec ?? 0),
    createdAt: new Date().toISOString(),
  };
  const local = readLocalMediaVocab();
  writeLocal(LS_MEDIA_VOCAB, [entry, ...local.filter((e) => e.id !== entry.id)]);

  // واژه‌های دیکشنری به مسیر واژگان شخصی (سشن ۳) هم می‌روند؛
  // واژه‌های سبکِ فروشگاه از قبل با `addCustomWord` در store ذخیره شده‌اند.
  if (isDictWord(input.word)) await createCustomWord(userId, input.word);

  if (BACKEND && userId) {
    await enqueue("media.vocab.create", { userId, entry }, `media.vocab:${userId}:${entry.id}`);
  }
}

const COLLECTION: Record<MediaType, "films" | "songs" | "episodes" | "books"> = {
  film: "films",
  song: "songs",
  episode: "episodes",
  book: "books",
};

registerHandler("media.vocab.create", async (payload) => {
  const { userId, entry } = payload as { userId: string; entry: MediaVocabEntry };
  if (!BACKEND || !userId) return;
  const pb = getPb();
  const mediaRecordId =
    (await resolveMediaRecordId(COLLECTION[entry.type], entry.mediaId)) ?? entry.mediaId;
  let existing: MediaVocabRecord | null = null;
  try {
    existing = await pbRequest((signal) =>
      pb
        .collection("media_vocab")
        .getFirstListItem<MediaVocabRecord>(
          `user = "${escapeFilter(userId)}" && media_type = "${entry.type}" && media_id = "${escapeFilter(mediaRecordId)}" && word_text = "${escapeFilter(entry.wordText)}"`,
          { signal },
        ),
    );
  } catch (err) {
    if (toApiError(err).kind !== "notFound") throw err;
  }
  const data = {
    user: userId,
    media_type: entry.type,
    media_id: mediaRecordId,
    word_text: entry.wordText,
    context: entry.context,
    timestamp_sec: entry.timestampSec,
    added_to_srs: true,
  };
  if (existing) {
    await pbRequest((signal) =>
      pb.collection("media_vocab").update(existing!.id, data, { signal }),
    );
  } else {
    await pbRequest((signal) => pb.collection("media_vocab").create(data, { signal }));
  }
});
