/**
 * خطای یکسان لایهٔ داده.
 * همهٔ خطاهای PocketBase / شبکه / timeout به این شکل تبدیل می‌شوند تا UI
 * فقط با یک نوع خطا کار کند.
 */

export type ApiErrorKind =
  | "network" // قطعی اینترنت یا سرور در دسترس نیست
  | "timeout" // درخواست بیش از حد طول کشید
  | "auth" // 401/403
  | "notFound" // 404
  | "validation" // 400 با خطای فیلد
  | "rateLimit" // 429
  | "server" // 5xx
  | "unknown";

export interface FieldErrors {
  [field: string]: string;
}

export class ApiError extends Error {
  readonly kind: ApiErrorKind;
  readonly status: number;
  readonly fieldErrors: FieldErrors;

  constructor(kind: ApiErrorKind, message: string, status = 0, fieldErrors: FieldErrors = {}) {
    super(message);
    this.name = "ApiError";
    this.kind = kind;
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

const FA: Record<ApiErrorKind, string> = {
  network: "اتصال به سرور برقرار نشد. اینترنت را بررسی کنید.",
  timeout: "پاسخ سرور بیش از حد طول کشید. دوباره تلاش کنید.",
  auth: "دسترسی مجاز نیست. دوباره وارد شوید.",
  notFound: "موردی پیدا نشد.",
  validation: "اطلاعات واردشده معتبر نیست.",
  rateLimit: "تعداد درخواست‌ها زیاد است. کمی بعد دوباره تلاش کنید.",
  server: "خطای سرور. کمی بعد دوباره تلاش کنید.",
  unknown: "خطای ناشناخته رخ داد.",
};

function kindFromStatus(status: number): ApiErrorKind {
  if (status === 0) return "network";
  if (status === 400) return "validation";
  if (status === 401 || status === 403) return "auth";
  if (status === 404) return "notFound";
  if (status === 429) return "rateLimit";
  if (status >= 500) return "server";
  return "unknown";
}

interface PbLikeError {
  status?: number;
  isAbort?: boolean;
  name?: string;
  message?: string;
  response?: { message?: string; data?: Record<string, { message?: string }> };
  data?: { message?: string; data?: Record<string, { message?: string }> };
}

/** هر خطایی را به `ApiError` تبدیل می‌کند. */
export function toApiError(err: unknown): ApiError {
  if (err instanceof ApiError) return err;

  const e = (err ?? {}) as PbLikeError;

  if (e.isAbort || e.name === "AbortError") {
    return new ApiError("timeout", FA.timeout, 0);
  }

  const status = typeof e.status === "number" ? e.status : 0;
  const payload = e.response ?? e.data ?? {};
  const rawFields = (payload.data ?? {}) as Record<string, { message?: string }>;

  const fieldErrors: FieldErrors = {};
  for (const [key, value] of Object.entries(rawFields)) {
    if (value?.message) fieldErrors[key] = value.message;
  }

  const kind = kindFromStatus(status);
  const message =
    (Object.values(fieldErrors)[0] as string | undefined) ??
    (kind === "validation" ? payload.message : undefined) ??
    FA[kind];

  return new ApiError(kind, message || FA.unknown, status, fieldErrors);
}

/** پیام کوتاه فارسی برای نمایش در فرم‌ها. */
export function errorMessage(err: unknown): string {
  return toApiError(err).message;
}
