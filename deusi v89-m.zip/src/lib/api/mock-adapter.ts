/**
 * MOCK-Adapter / آداپتور حالت بدون بک‌اند.
 *
 * وقتی `VITE_PB_URL` تنظیم نشده باشد، همین پیاده‌سازی روی localStorage
 * اجرا می‌شود تا رفتار فعلی اپ دقیقاً حفظ شود (همان کلیدهای قبلی).
 */
import type { AuthApi, AuthSession } from "./auth-types";
import { ApiError } from "./errors";
import type { DeckCard, User } from "@/lib/deusi/types";
import { SEED_WORDS } from "@/lib/deusi/seed";
import { newCard } from "@/lib/deusi/fsrs";

export const LS_USERS = "deusi.users";
export const LS_SESSION = "deusi.session";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

export function readMockUsers(): User[] {
  return read<User[]>(LS_USERS, []);
}

export function readMockSessionId(): string | null {
  return read<string | null>(LS_SESSION, null);
}

function session(user: User): AuthSession {
  return { user, recordId: user.id };
}

export const mockAuthApi: AuthApi = {
  async restore() {
    const id = readMockSessionId();
    if (!id) return null;
    const user = readMockUsers().find((u) => u.id === id);
    return user ? session(user) : null;
  },

  async register(username, email, password) {
    if (!username || !email || !password) {
      throw new ApiError("validation", "همه فیلدها لازم است");
    }
    const users = readMockUsers();
    if (users.some((u) => u.email === email)) {
      throw new ApiError("validation", "این ایمیل قبلا ثبت شده", 400, {
        email: "این ایمیل قبلا ثبت شده",
      });
    }
    const deck: DeckCard[] = SEED_WORDS.map((w) => newCard(w.id));
    const user: User = {
      id: "u" + Date.now(),
      username,
      email,
      password,
      createdAt: Date.now(),
      streak: 0,
      lastStudy: null,
      deck,
      customWords: [],
    };
    write(LS_USERS, [...users, user]);
    write(LS_SESSION, user.id);
    return session(user);
  },

  async login(identifier, password) {
    const user = readMockUsers().find(
      (u) => (u.email === identifier || u.username === identifier) && u.password === password,
    );
    if (!user) throw new ApiError("auth", "اطلاعات ورود نادرست است", 401);
    write(LS_SESSION, user.id);
    return session(user);
  },

  async requestPasswordReset(email) {
    if (!email)
      throw new ApiError("validation", "ایمیل لازم است", 400, { email: "ایمیل لازم است" });
  },

  async confirmPasswordReset(token, password) {
    if (!token) throw new ApiError("validation", "لینک بازیابی نامعتبر است");
    if (password.length < 8) {
      throw new ApiError("validation", "رمز عبور باید حداقل ۸ کاراکتر باشد", 400, {
        password: "رمز عبور باید حداقل ۸ کاراکتر باشد",
      });
    }
  },

  async refresh() {
    return mockAuthApi.restore();
  },

  async logout() {
    write(LS_SESSION, null);
  },
};
