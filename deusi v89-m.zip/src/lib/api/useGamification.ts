/**
 * هوک‌های گیمیفیکیشن (سشن ۹): XP، سطح، استریک، دستاوردها و مأموریت‌ها.
 * همه فقط خواندنی هستند؛ نوشتن XP در سرور انجام می‌شود.
 */
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import { useCurrentUserId } from "./useExams";
import {
  loadAchievements,
  loadGamification,
  loadMissions,
  loadXpHistory,
  type GamificationSummary,
} from "./gamification";
import { ACHIEVEMENTS, type Achievement } from "@/lib/deusi/achievements";
import { DAILY_MISSIONS, WEEKLY_MISSIONS } from "@/lib/deusi/gamification";

/** خلاصهٔ XP/سطح/استریک کاربر جاری. */
export function useGamification() {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: queryKeys.gamification.summary(userId),
    queryFn: () => loadGamification(userId),
    staleTime: 30_000,
  });
  return {
    summary: q.data as GamificationSummary | undefined,
    isLoading: q.isLoading,
    error: q.error,
    userId,
  };
}

/** فهرست دستاوردها (کاتالوگ + وضعیت کاربر). */
export function useAchievements() {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: queryKeys.gamification.achievementsByUser(userId),
    queryFn: () => loadAchievements(userId),
    staleTime: 60_000,
    initialData: ACHIEVEMENTS,
  });
  return {
    achievements: (q.data ?? ACHIEVEMENTS) as Achievement[],
    isLoading: q.isLoading,
  };
}

/** مأموریت‌های روزانه و هفتگی. */
export function useMissions() {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: queryKeys.gamification.missions(userId),
    queryFn: () => loadMissions(userId),
    staleTime: 60_000,
    initialData: { daily: DAILY_MISSIONS, weekly: WEEKLY_MISSIONS },
  });
  return {
    daily: q.data?.daily ?? DAILY_MISSIONS,
    weekly: q.data?.weekly ?? WEEKLY_MISSIONS,
    isLoading: q.isLoading,
  };
}

/** تاریخچهٔ XP. */
export function useXpHistory(limit = 30) {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: queryKeys.gamification.xpHistory(userId),
    queryFn: () => loadXpHistory(userId, limit),
    staleTime: 60_000,
  });
  return { entries: q.data ?? [], isLoading: q.isLoading };
}
