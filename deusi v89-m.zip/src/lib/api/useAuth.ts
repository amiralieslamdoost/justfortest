import { useCallback, useMemo } from "react";
import { useDeusi } from "@/lib/deusi/store";
import type { AuthResult } from "@/lib/deusi/store";
import type { AuthSession } from "./auth-types";

/**
 * نمای یکنواخت نشست برای UI.
 *
 * نشست در `DeusiProvider` مدیریت می‌شود تا هم PocketBase و هم MOCK_MODE
 * دقیقاً از یک منبع حقیقت استفاده کنند. این هوک قرارداد صریح سشن ۲ را
 * برای کامپوننت‌ها فراهم می‌کند؛ بدون اینکه اتصال مستقیم به PocketBase
 * در UI ایجاد شود.
 */
export function useSession() {
  const { currentUser, hydrated, backend } = useDeusi();

  const session = useMemo<AuthSession | null>(
    () => (currentUser ? { user: currentUser, recordId: currentUser.id } : null),
    [currentUser],
  );

  return {
    session,
    user: currentUser,
    hydrated,
    isAuthenticated: Boolean(currentUser),
    isLoading: !hydrated,
    backend,
  };
}

/**
 * رابط کامل عملیات احراز هویت برای صفحات و کامپوننت‌ها.
 * همهٔ عملیات به Provider مرکزی واگذار می‌شوند تا refresh توکن، صف آفلاین
 * و حالت Mock به‌صورت سازگار حفظ شوند.
 */
export function useAuth() {
  const store = useDeusi();
  const session = useSession();

  const logout = useCallback(() => store.logout(), [store]);

  return {
    ...session,
    login: (identifier: string, password: string): Promise<AuthResult> =>
      store.login(identifier, password),
    register: (username: string, email: string, password: string): Promise<AuthResult> =>
      store.register(username, email, password),
    requestPasswordReset: (email: string): Promise<AuthResult> => store.requestPasswordReset(email),
    confirmPasswordReset: (token: string, password: string): Promise<AuthResult> =>
      store.confirmPasswordReset(token, password),
    logout,
  };
}
