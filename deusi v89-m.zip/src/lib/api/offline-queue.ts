/**
 * صف آفلاین عمومی (IndexedDB) / Offline-Queue.
 *
 * همهٔ نوشتن‌های دامنه‌ها می‌توانند در این صف قرار بگیرند تا وقتی شبکه قطع است
 * از دست نروند و هنگام آنلاین شدن ارسال شوند.
 *
 * - ذخیره در IndexedDB (بدون کتابخانهٔ اضافه)
 * - ادغام بر اساس `key` (مثلاً چند به‌روزرسانی یک کارت SRS = یک آیتم)
 * - عقب‌نشینی نمایی برای خطاهای شبکه، حذف آیتم بعد از موفقیت
 * - در حالت MOCK هرگز استفاده نمی‌شود (نوشتن مستقیم روی localStorage)
 */
import { useEffect, useState } from "react";
import { toApiError } from "./errors";

const DB_NAME = "deusi-offline";
const DB_VERSION = 1;
const STORE = "ops";
const MAX_ATTEMPTS = 8;

export interface QueuedOp<T = unknown> {
  /** شناسهٔ یکتای آیتم (برابر با key برای ادغام). */
  id: string;
  /** نوع عملیات؛ handler بر اساس آن پیدا می‌شود. */
  type: string;
  payload: T;
  createdAt: number;
  attempts: number;
  nextAttemptAt: number;
}

type Handler = (payload: unknown) => Promise<void>;

const handlers = new Map<string, Handler>();
const listeners = new Set<(count: number) => void>();

let dbPromise: Promise<IDBDatabase> | null = null;
let flushing = false;
let timer: ReturnType<typeof setTimeout> | null = null;

function hasIdb(): boolean {
  return typeof window !== "undefined" && "indexedDB" in window;
}

function openDb(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: "id" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
}

async function tx<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>) {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const req = run(t.objectStore(STORE));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function allOps(): Promise<QueuedOp[]> {
  if (!hasIdb()) return [];
  try {
    return (await tx<QueuedOp[]>("readonly", (s) => s.getAll() as IDBRequest<QueuedOp[]>)) ?? [];
  } catch {
    return [];
  }
}

async function putOp(op: QueuedOp) {
  await tx("readwrite", (s) => s.put(op) as IDBRequest<IDBValidKey>);
}

async function deleteOp(id: string) {
  await tx("readwrite", (s) => s.delete(id) as IDBRequest<undefined>);
}

async function notify() {
  const ops = await allOps();
  listeners.forEach((fn) => fn(ops.length));
}

/** ثبت هندلر برای یک نوع عملیات. */
export function registerHandler(type: string, handler: Handler) {
  handlers.set(type, handler);
}

/**
 * افزودن عملیات به صف.
 * اگر `key` تکراری باشد، payload جایگزین می‌شود (ادغام).
 */
export async function enqueue<T>(type: string, payload: T, key?: string): Promise<void> {
  if (!hasIdb()) return;
  const id = key ?? `${type}:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
  const op: QueuedOp<T> = {
    id,
    type,
    payload,
    createdAt: Date.now(),
    attempts: 0,
    nextAttemptAt: Date.now(),
  };
  try {
    await putOp(op as QueuedOp);
    await notify();
  } catch (err) {
    console.warn("offline-queue: enqueue failed", err);
    return;
  }
  void flush();
}

/** تلاش برای ارسال همهٔ آیتم‌های صف. */
export async function flush(): Promise<void> {
  if (flushing || !hasIdb()) return;
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    scheduleRetry(15_000);
    return;
  }
  flushing = true;
  try {
    const ops = (await allOps()).sort((a, b) => a.createdAt - b.createdAt);
    const now = Date.now();
    let earliestRetry = Infinity;

    for (const op of ops) {
      if (op.nextAttemptAt > now) {
        earliestRetry = Math.min(earliestRetry, op.nextAttemptAt - now);
        continue;
      }
      const handler = handlers.get(op.type);
      if (!handler) continue; // هندلر هنوز ثبت نشده — دفعهٔ بعد
      try {
        await handler(op.payload);
        await deleteOp(op.id);
      } catch (err) {
        const api = toApiError(err);
        const retryable = api.kind === "network" || api.kind === "timeout" || api.kind === "server";
        const attempts = op.attempts + 1;
        if (!retryable || attempts >= MAX_ATTEMPTS) {
          console.warn("offline-queue: dropping op", op.type, api.message);
          await deleteOp(op.id);
        } else {
          const delay = Math.min(5 * 60_000, 1000 * 2 ** attempts);
          await putOp({ ...op, attempts, nextAttemptAt: Date.now() + delay });
          earliestRetry = Math.min(earliestRetry, delay);
        }
      }
    }
    if (earliestRetry !== Infinity) scheduleRetry(earliestRetry);
  } finally {
    flushing = false;
    await notify();
  }
}

function scheduleRetry(ms: number) {
  if (timer) clearTimeout(timer);
  timer = setTimeout(
    () => {
      timer = null;
      void flush();
    },
    Math.max(1000, ms),
  );
}

/** تعداد آیتم‌های در انتظار. */
export async function pendingCount(): Promise<number> {
  return (await allOps()).length;
}

let started = false;
/** راه‌اندازی شنونده‌های online/visibility (یک‌بار). */
export function startOfflineQueue() {
  if (started || typeof window === "undefined") return;
  started = true;
  window.addEventListener("online", () => void flush());
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") void flush();
  });
  void flush();
}

/** هوک وضعیت صف برای نمایش نشانگر «در انتظار همگام‌سازی». */
export function useOfflineQueueStatus() {
  const [count, setCount] = useState(0);
  const [online, setOnline] = useState(
    typeof navigator === "undefined" ? true : navigator.onLine !== false,
  );

  useEffect(() => {
    startOfflineQueue();
    listeners.add(setCount);
    void pendingCount().then(setCount);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      listeners.delete(setCount);
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  return { pending: count, online, flush };
}
