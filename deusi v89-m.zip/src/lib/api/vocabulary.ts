/**
 * لایهٔ دادهٔ واژگان / Vocabulary-Datenschicht.
 *
 * دامنه‌ها: dictionary، meine-woerter، sprichwoerter، leitner، verben، wordfamilies.
 *
 * قانون: کامپوننت‌ها هرگز مستقیم PocketBase صدا نمی‌زنند؛ همه چیز از اینجا می‌آید.
 * در حالت MOCK (نبود VITE_PB_URL) دقیقاً همان دیتای `src/lib/deusi/*` و localStorage
 * استفاده می‌شود تا اپ بدون بک‌اند هم کامل کار کند.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import { enqueue, registerHandler } from "./offline-queue";
import type {
  ProverbRecord,
  SrsCardRecord,
  UserWordRecord,
  VerbRecord,
  WordFamilyRecord,
  WordRecord,
} from "./types";
import type { CEFR, DictPos, DictWord } from "@/lib/deusi/dictionary/types";
import { ALL_WORDS, findById as findMockWord } from "@/lib/deusi/dictionary/mockWords";
import { PROVERBS } from "@/lib/deusi/dictionary/proverbs";
import { WORD_ROOTS } from "@/lib/deusi/wordfamilies/mockFamilies";

/* -------------------------------------------------------------------------- */
/* کلیدهای محلی (حالت MOCK و کش آفلاین)                                        */
/* -------------------------------------------------------------------------- */

export const LS_CUSTOM_WORDS = "deusi.customDictWords.v1";
export const LS_LEITNER_QUEUE = "deusi.leitner.dictQueue.v2";
export const LS_LEITNER_LEGACY = "deusi.leitner.dictQueue.v1";
export const LS_MIGRATED = "deusi.vocab.migrated.v1";

export function readLocal<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function writeLocal(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

/* -------------------------------------------------------------------------- */
/* نگاشت رکورد سرور ↔ مدل UI                                                   */
/* -------------------------------------------------------------------------- */

export function wordRecordToDictWord(r: Partial<WordRecord>): DictWord {
  return {
    id: (r.slug || r.id || "") as string,
    headword: r.headword ?? "",
    lemma: r.lemma ?? (r.headword ?? "").toLowerCase(),
    pos: (r.pos ?? "noun") as DictPos,
    cefr: (r.cefr ?? "A1") as CEFR,
    category: r.category ?? "",
    frequency: r.frequency ?? 50,
    ipa: r.ipa ?? "",
    shortMeaning: r.short_meaning ?? "",
    meanings: (r.meanings ?? []) as DictWord["meanings"],
    usage: r.usage ?? "",
    difficulty: (r.difficulty ?? 3) as DictWord["difficulty"],
    examples: (r.examples ?? []) as DictWord["examples"],
    family: (r.family ?? {
      synonyms: [],
      antonyms: [],
      similar: [],
      compounds: [],
      relatedVerbs: [],
      relatedNouns: [],
      relatedAdjectives: [],
    }) as DictWord["family"],
    memoryTip: r.memory_tip ?? "",
    imagePrompt: r.image_prompt ?? "",
    nounGrammar: (r.noun_grammar ?? undefined) as DictWord["nounGrammar"],
    verbGrammar: (r.verb_grammar ?? undefined) as DictWord["verbGrammar"],
    adjectiveGrammar: (r.adjective_grammar ?? undefined) as DictWord["adjectiveGrammar"],
    adverbGrammar: (r.adverb_grammar ?? undefined) as DictWord["adverbGrammar"],
    prepositionGrammar: (r.preposition_grammar ?? undefined) as DictWord["prepositionGrammar"],
  };
}

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

/* -------------------------------------------------------------------------- */
/* جست‌وجوی دیکشنری با صفحه‌بندی سمت سرور                                       */
/* -------------------------------------------------------------------------- */

export interface WordQuery {
  q?: string;
  pos?: DictPos | "all";
  cefr?: CEFR | "all";
  category?: string | "all";
  page?: number;
  perPage?: number;
}

export interface Paged<T> {
  items: T[];
  page: number;
  perPage: number;
  totalItems: number;
  totalPages: number;
}

function filterLocally(words: DictWord[], query: WordQuery): DictWord[] {
  const q = (query.q ?? "").trim().toLowerCase();
  return words.filter((w) => {
    if (query.pos && query.pos !== "all" && w.pos !== query.pos) return false;
    if (query.cefr && query.cefr !== "all" && w.cefr !== query.cefr) return false;
    if (query.category && query.category !== "all" && w.category !== query.category) return false;
    if (!q) return true;
    return (
      w.headword.toLowerCase().includes(q) ||
      w.lemma.includes(q) ||
      w.shortMeaning.toLowerCase().includes(q)
    );
  });
}

/** جست‌وجوی واژه‌ها؛ روی سرور با فیلتر و صفحه‌بندی، در MOCK روی دیتای محلی. */
export async function searchWordsPaged(query: WordQuery = {}): Promise<Paged<DictWord>> {
  const page = Math.max(1, query.page ?? 1);
  const perPage = Math.min(200, Math.max(1, query.perPage ?? 24));

  if (!BACKEND) {
    const all = filterLocally(ALL_WORDS, query);
    const start = (page - 1) * perPage;
    return {
      items: all.slice(start, start + perPage),
      page,
      perPage,
      totalItems: all.length,
      totalPages: Math.max(1, Math.ceil(all.length / perPage)),
    };
  }

  const filters: string[] = ["published = true"];
  const q = escapeFilter((query.q ?? "").trim());
  if (q) filters.push(`(headword ~ "${q}" || lemma ~ "${q}" || short_meaning ~ "${q}")`);
  if (query.pos && query.pos !== "all") filters.push(`pos = "${escapeFilter(query.pos)}"`);
  if (query.cefr && query.cefr !== "all") filters.push(`cefr = "${escapeFilter(query.cefr)}"`);
  if (query.category && query.category !== "all")
    filters.push(`category = "${escapeFilter(query.category)}"`);

  const pb = getPb();
  const res = await pbRequest((signal) =>
    pb.collection("words").getList<WordRecord>(page, perPage, {
      filter: filters.join(" && "),
      sort: "-frequency,headword",
      signal,
    }),
  );

  return {
    items: res.items.map(wordRecordToDictWord),
    page: res.page,
    perPage: res.perPage,
    totalItems: res.totalItems,
    totalPages: res.totalPages,
  };
}

/** یک واژه بر اساس شناسه/slug. */
export async function getWord(id: string): Promise<DictWord | null> {
  if (!id) return null;
  if (!BACKEND) return findMockWord(id) ?? null;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("words")
        .getFirstListItem<WordRecord>(
          `slug = "${escapeFilter(id)}" || id = "${escapeFilter(id)}"`,
          {
            signal,
          },
        ),
    );
    return wordRecordToDictWord(rec);
  } catch (err) {
    if (toApiError(err).kind === "notFound") return findMockWord(id) ?? null;
    throw err;
  }
}

/** شناسهٔ رکورد سرور برای یک slug محلی (برای رابطه‌ها). null یعنی محتوا هنوز منتقل نشده. */
async function resolveWordRecordId(slug: string): Promise<string | null> {
  if (!BACKEND || !slug) return null;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("words")
        .getFirstListItem<WordRecord>(
          `slug = "${escapeFilter(slug)}" || id = "${escapeFilter(slug)}"`,
          {
            signal,
          },
        ),
    );
    return rec.id;
  } catch {
    return null;
  }
}

/* -------------------------------------------------------------------------- */
/* واژه‌های شخصی کاربر (user_words)                                            */
/* -------------------------------------------------------------------------- */

export async function listCustomWords(userId: string): Promise<DictWord[]> {
  if (!BACKEND || !userId) return readLocal<DictWord[]>(LS_CUSTOM_WORDS, []);
  const pb = getPb();
  const res = await pbRequest((signal) =>
    pb.collection("user_words").getFullList<UserWordRecord>({
      filter: `user = "${escapeFilter(userId)}" && source = "custom"`,
      sort: "-created",
      signal,
    }),
  );
  return res
    .map((r) => (r.custom_data as DictWord | null) ?? null)
    .filter((w): w is DictWord => Boolean(w));
}

export async function createCustomWord(userId: string, word: DictWord): Promise<void> {
  const local = readLocal<DictWord[]>(LS_CUSTOM_WORDS, []);
  writeLocal(LS_CUSTOM_WORDS, [word, ...local.filter((w) => w.id !== word.id)]);
  if (!BACKEND || !userId) return;
  await enqueue(
    "vocab.customWord.upsert",
    { userId, word },
    `vocab.customWord:${userId}:${word.id}`,
  );
}

export async function updateCustomWord(
  userId: string,
  id: string,
  patch: Partial<DictWord>,
): Promise<void> {
  const local = readLocal<DictWord[]>(LS_CUSTOM_WORDS, []);
  const next = local.map((w) => (w.id === id ? { ...w, ...patch } : w));
  writeLocal(LS_CUSTOM_WORDS, next);
  const word = next.find((w) => w.id === id);
  if (!BACKEND || !userId || !word) return;
  await enqueue("vocab.customWord.upsert", { userId, word }, `vocab.customWord:${userId}:${id}`);
}

export async function deleteCustomWord(userId: string, id: string): Promise<void> {
  const local = readLocal<DictWord[]>(LS_CUSTOM_WORDS, []);
  writeLocal(
    LS_CUSTOM_WORDS,
    local.filter((w) => w.id !== id),
  );
  if (!BACKEND || !userId) return;
  await enqueue("vocab.customWord.delete", { userId, id }, `vocab.customWordDel:${userId}:${id}`);
}

async function findUserWord(userId: string, sourceId: string): Promise<UserWordRecord | null> {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("user_words")
        .getFirstListItem<UserWordRecord>(
          `user = "${escapeFilter(userId)}" && source_id = "${escapeFilter(sourceId)}"`,
          { signal },
        ),
    );
  } catch (err) {
    if (toApiError(err).kind === "notFound") return null;
    throw err;
  }
}

/* -------------------------------------------------------------------------- */
/* کارت‌های Leitner / FSRS (srs_cards)                                          */
/* -------------------------------------------------------------------------- */

export type LeitnerBoxNum = 1 | 2 | 3 | 4 | 5;

export interface LeitnerItem {
  id: string; // شناسهٔ واژه (slug محلی)
  box: LeitnerBoxNum;
  reps?: number;
  lapses?: number;
  ease?: number;
  interval?: number;
  dueAt?: string;
}

function loadLocalQueue(): LeitnerItem[] {
  const items = readLocal<LeitnerItem[] | null>(LS_LEITNER_QUEUE, null);
  if (items) return items;
  const legacy = readLocal<string[]>(LS_LEITNER_LEGACY, []);
  return legacy.map((id) => ({ id, box: 1 as LeitnerBoxNum }));
}

export async function listLeitnerItems(userId: string): Promise<LeitnerItem[]> {
  if (!BACKEND || !userId) return loadLocalQueue();
  const pb = getPb();
  const res = await pbRequest((signal) =>
    pb.collection("srs_cards").getFullList<SrsCardRecord & { expand?: { word?: WordRecord } }>({
      filter: `user = "${escapeFilter(userId)}"`,
      expand: "word",
      sort: "due_at",
      signal,
    }),
  );
  const items = res.map((r) => ({
    id: r.expand?.word?.slug ?? (r.word as string),
    box: r.box,
    reps: r.reps,
    lapses: r.lapses,
    ease: r.ease,
    interval: r.interval,
    dueAt: r.due_at,
  }));
  // کش محلی تا UI آفلاین هم داده داشته باشد
  writeLocal(LS_LEITNER_QUEUE, items);
  return items;
}

/** ثبت/به‌روزرسانی کارت (خوش‌بینانه + صف آفلاین). */
export async function upsertLeitnerItem(userId: string, item: LeitnerItem): Promise<void> {
  const local = loadLocalQueue();
  const exists = local.some((i) => i.id === item.id);
  writeLocal(
    LS_LEITNER_QUEUE,
    exists ? local.map((i) => (i.id === item.id ? { ...i, ...item } : i)) : [item, ...local],
  );
  if (!BACKEND || !userId) return;
  await enqueue("vocab.srs.upsert", { userId, item }, `vocab.srs:${userId}:${item.id}`);
}

export async function removeLeitnerItem(userId: string, wordId: string): Promise<void> {
  const local = loadLocalQueue();
  writeLocal(
    LS_LEITNER_QUEUE,
    local.filter((i) => i.id !== wordId),
  );
  if (!BACKEND || !userId) return;
  await enqueue("vocab.srs.delete", { userId, wordId }, `vocab.srsDel:${userId}:${wordId}`);
}

async function findSrsCard(userId: string, wordRecordId: string): Promise<SrsCardRecord | null> {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("srs_cards")
        .getFirstListItem<SrsCardRecord>(
          `user = "${escapeFilter(userId)}" && word = "${escapeFilter(wordRecordId)}"`,
          { signal },
        ),
    );
  } catch (err) {
    if (toApiError(err).kind === "notFound") return null;
    throw err;
  }
}

/* -------------------------------------------------------------------------- */
/* محتوای ثابت: ضرب‌المثل، افعال، خانوادهٔ واژگان                                */
/* -------------------------------------------------------------------------- */

export async function listProverbs(): Promise<typeof PROVERBS> {
  if (!BACKEND) return PROVERBS;
  const pb = getPb();
  try {
    const res = await pbRequest((signal) =>
      pb.collection("proverbs").getFullList<ProverbRecord>({ sort: "de", signal }),
    );
    if (!res.length) return PROVERBS;
    return res as unknown as typeof PROVERBS;
  } catch {
    return PROVERBS; // fallback تا زمان مهاجرت محتوا
  }
}

export async function listVerbs(): Promise<VerbRecord[]> {
  if (!BACKEND) return [];
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb.collection("verbs").getFullList<VerbRecord>({ sort: "infinitive", signal }),
    );
  } catch {
    return [];
  }
}

export async function listWordFamilies(): Promise<typeof WORD_ROOTS> {
  if (!BACKEND) return WORD_ROOTS;
  const pb = getPb();
  try {
    const res = await pbRequest((signal) =>
      pb.collection("word_families").getFullList<WordFamilyRecord>({ sort: "root", signal }),
    );
    if (!res.length) return WORD_ROOTS;
    return res as unknown as typeof WORD_ROOTS;
  } catch {
    return WORD_ROOTS;
  }
}

/* -------------------------------------------------------------------------- */
/* هندلرهای صف آفلاین                                                          */
/* -------------------------------------------------------------------------- */

registerHandler("vocab.customWord.upsert", async (payload) => {
  const { userId, word } = payload as { userId: string; word: DictWord };
  if (!BACKEND || !userId) return;
  const pb = getPb();
  const existing = await findUserWord(userId, word.id);
  const data = {
    user: userId,
    custom_headword: word.headword,
    custom_data: word,
    status: "learning",
    source: "custom",
    source_id: word.id,
  };
  if (existing) {
    await pbRequest((signal) => pb.collection("user_words").update(existing.id, data, { signal }));
  } else {
    await pbRequest((signal) => pb.collection("user_words").create(data, { signal }));
  }
});

registerHandler("vocab.customWord.delete", async (payload) => {
  const { userId, id } = payload as { userId: string; id: string };
  if (!BACKEND || !userId) return;
  const pb = getPb();
  const existing = await findUserWord(userId, id);
  if (existing) {
    await pbRequest((signal) => pb.collection("user_words").delete(existing.id, { signal }));
  }
});

registerHandler("vocab.srs.upsert", async (payload) => {
  const { userId, item } = payload as { userId: string; item: LeitnerItem };
  if (!BACKEND || !userId) return;
  const wordRecordId = await resolveWordRecordId(item.id);
  if (!wordRecordId) return; // محتوای واژه هنوز روی سرور نیست (سشن ۴/۵)
  const pb = getPb();
  const existing = await findSrsCard(userId, wordRecordId);
  const data = {
    user: userId,
    word: wordRecordId,
    box: item.box,
    reps: item.reps ?? existing?.reps ?? 0,
    lapses: item.lapses ?? existing?.lapses ?? 0,
    ease: item.ease ?? existing?.ease ?? 2.5,
    interval: item.interval ?? existing?.interval ?? 0,
    due_at: item.dueAt ?? existing?.due_at ?? new Date().toISOString(),
    last_review_at: new Date().toISOString(),
  };
  if (existing) {
    await pbRequest((signal) => pb.collection("srs_cards").update(existing.id, data, { signal }));
  } else {
    await pbRequest((signal) => pb.collection("srs_cards").create(data, { signal }));
  }
});

registerHandler("vocab.srs.delete", async (payload) => {
  const { userId, wordId } = payload as { userId: string; wordId: string };
  if (!BACKEND || !userId) return;
  const wordRecordId = await resolveWordRecordId(wordId);
  if (!wordRecordId) return;
  const existing = await findSrsCard(userId, wordRecordId);
  if (existing) {
    const pb = getPb();
    await pbRequest((signal) => pb.collection("srs_cards").delete(existing.id, { signal }));
  }
});

/* -------------------------------------------------------------------------- */
/* مهاجرت یک‌بارهٔ دادهٔ محلی به سرور                                            */
/* -------------------------------------------------------------------------- */

/** پس از اولین ورود، دادهٔ localStorage را به صف ارسال می‌فرستد. */
export async function migrateLocalVocabulary(userId: string): Promise<void> {
  if (!BACKEND || !userId) return;
  const flags = readLocal<Record<string, boolean>>(LS_MIGRATED, {});
  if (flags[userId]) return;
  writeLocal(LS_MIGRATED, { ...flags, [userId]: true });

  for (const word of readLocal<DictWord[]>(LS_CUSTOM_WORDS, [])) {
    await enqueue(
      "vocab.customWord.upsert",
      { userId, word },
      `vocab.customWord:${userId}:${word.id}`,
    );
  }
  for (const item of loadLocalQueue()) {
    await enqueue("vocab.srs.upsert", { userId, item }, `vocab.srs:${userId}:${item.id}`);
  }
}
