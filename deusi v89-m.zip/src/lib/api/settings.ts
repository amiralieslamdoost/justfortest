/**
 * تنظیمات کاربر (سشن ۹) — کالکشن `settings`.
 * در حالت MOCK یا بدون ورود، همان localStorage قبلی استفاده می‌شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import type { SettingsRecord } from "./types";

export interface UserSettings {
  ui_language: "de" | "fa";
  theme: "light" | "dark" | "system";
  rtl: boolean;
  sound: boolean;
  email_digest: boolean;
  push_enabled: boolean;
  daily_goal_minutes: number;
  notification_prefs: Record<string, boolean>;
}

export const DEFAULT_SETTINGS: UserSettings = {
  ui_language: "de",
  theme: "system",
  rtl: true,
  sound: true,
  email_digest: true,
  push_enabled: false,
  daily_goal_minutes: 45,
  notification_prefs: {
    srs: true,
    planner: true,
    community: true,
    event: true,
    achievement: true,
    exam: true,
    system: true,
  },
};

const LS_KEY = (userId: string) => `deusi.settings.${userId || "guest"}`;

function readLocal(userId: string): UserSettings | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(LS_KEY(userId));
    return raw ? ({ ...DEFAULT_SETTINGS, ...JSON.parse(raw) } as UserSettings) : null;
  } catch {
    return null;
  }
}

function writeLocal(userId: string, value: UserSettings) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(LS_KEY(userId), JSON.stringify(value));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

function fromRecord(rec: Partial<SettingsRecord>): UserSettings {
  return {
    ui_language: rec.ui_language ?? DEFAULT_SETTINGS.ui_language,
    theme: rec.theme ?? DEFAULT_SETTINGS.theme,
    rtl: rec.rtl ?? DEFAULT_SETTINGS.rtl,
    sound: rec.sound ?? DEFAULT_SETTINGS.sound,
    email_digest: rec.email_digest ?? DEFAULT_SETTINGS.email_digest,
    push_enabled: rec.push_enabled ?? DEFAULT_SETTINGS.push_enabled,
    daily_goal_minutes: rec.daily_goal_minutes ?? DEFAULT_SETTINGS.daily_goal_minutes,
    notification_prefs: {
      ...DEFAULT_SETTINGS.notification_prefs,
      ...(rec.notification_prefs ?? {}),
    },
  };
}

/** خواندن تنظیمات (با fallback به localStorage و مقادیر پیش‌فرض). */
export async function getSettings(userId: string): Promise<UserSettings> {
  if (!BACKEND || !userId) return readLocal(userId) ?? DEFAULT_SETTINGS;
  try {
    const rec = await pbRequest((signal) =>
      getPb()
        .collection("settings")
        .getFirstListItem<SettingsRecord>(`user = "${userId}"`, { signal }),
    );
    const value = fromRecord(rec);
    writeLocal(userId, value);
    return value;
  } catch {
    return readLocal(userId) ?? DEFAULT_SETTINGS;
  }
}

/** ذخیرهٔ بخشی از تنظیمات (offline-safe). */
export async function saveSettings(
  userId: string,
  patch: Partial<UserSettings>,
): Promise<UserSettings> {
  const current = readLocal(userId) ?? DEFAULT_SETTINGS;
  const next = { ...current, ...patch };
  writeLocal(userId, next);
  if (BACKEND && userId) {
    await enqueue("settings.save", { userId, patch: next }, `settings.save:${userId}`);
  }
  return next;
}

/** انتقال یک‌بارهٔ تنظیمات محلی به بک‌اند (اولین ورود). */
export async function migrateSettings(userId: string): Promise<void> {
  if (!BACKEND || !userId) return;
  const local = readLocal(userId) ?? readLocal("");
  if (!local) return;
  try {
    await getPb().collection("settings").getFirstListItem<SettingsRecord>(`user = "${userId}"`);
  } catch {
    await enqueue("settings.save", { userId, patch: local }, `settings.save:${userId}`);
  }
}

registerHandler("settings.save", async (payload) => {
  const { userId, patch } = payload as { userId: string; patch: Partial<UserSettings> };
  const pb = getPb();
  try {
    const rec = await pb
      .collection("settings")
      .getFirstListItem<SettingsRecord>(`user = "${userId}"`);
    await pb.collection("settings").update(rec.id, patch);
  } catch {
    await pb.collection("settings").create({ user: userId, ...DEFAULT_SETTINGS, ...patch });
  }
});
