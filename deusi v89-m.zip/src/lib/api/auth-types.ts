/**
 * قرارداد مشترک احراز هویت برای هر دو حالت (mock و PocketBase).
 */
import type { User } from "@/lib/deusi/types";

export interface AuthSession {
  user: User;
  /** شناسهٔ رکورد کاربر در بک‌اند (در حالت mock همان id محلی است). */
  recordId: string;
}

export interface AuthApi {
  /** خواندن نشست فعلی (بدون throw). */
  restore(): Promise<AuthSession | null>;
  register(username: string, email: string, password: string): Promise<AuthSession>;
  login(identifier: string, password: string): Promise<AuthSession>;
  requestPasswordReset(email: string): Promise<void>;
  confirmPasswordReset(token: string, password: string): Promise<void>;
  /** تازه‌سازی توکن؛ اگر نشست نامعتبر شد null برمی‌گرداند. */
  refresh(): Promise<AuthSession | null>;
  logout(): Promise<void>;
}
