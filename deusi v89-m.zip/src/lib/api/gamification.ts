/**
 * Gamification (سشن ۹) — XP، سطح، استریک، دستاوردها و مأموریت‌ها.
 *
 * قاعدهٔ امنیتی: کلاینت هرگز XP نمی‌نویسد. کالکشن‌های `xp_ledger`،
 * `user_achievements`، `streaks` و `daily_stats` قواعد create/update ندارند و
 * فقط hooks سرور (`backend/pb_hooks/gamification.pb.js`) در آن‌ها می‌نویسند.
 * این ماژول صرفاً می‌خواند.
 *
 * در حالت MOCK (بدون VITE_PB_URL) همان دیتای `src/lib/deusi/gamification.ts`
 * و `src/lib/deusi/achievements.ts` برگردانده می‌شود تا رفتار فعلی حفظ شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import type {
  AchievementRecord,
  DailyStatRecord,
  MissionRecord,
  StreakRecord,
  UserAchievementRecord,
  UserMissionRecord,
  XpLedgerRecord,
} from "./types";
import { ACHIEVEMENTS, type Achievement, type AchievementCategory } from "@/lib/deusi/achievements";
import {
  DAILY_MISSIONS,
  LEVEL_TITLES,
  TOTAL_XP,
  WEEKLY_MISSIONS,
  levelFromXp,
  xpForLevel,
  type Mission,
} from "@/lib/deusi/gamification";

/* ------------------------------- انواع ---------------------------------- */

export interface StreakInfo {
  current: number;
  longest: number;
  lastActiveDay: string | null;
  freezesLeft: number;
  weekMap: boolean[];
}

export interface GamificationSummary {
  xp: number;
  level: number;
  levelTitle: { de: string; fa: string };
  nextLevelTitle: { de: string; fa: string };
  xpInLevel: number;
  xpNeeded: number;
  levelPct: number;
  streak: StreakInfo;
  unlocked: number;
  total: number;
  progressPct: number;
  todayXp: number;
  source: "backend" | "mock";
}

export interface XpEntry {
  id: string;
  amount: number;
  source: XpLedgerRecord["source"];
  note: string;
  earnedAt: string;
}

/* ----------------------------- کمک‌کننده‌ها ------------------------------ */

const CATEGORY_MAP: Record<AchievementRecord["category"], AchievementCategory> = {
  vocabulary: "Wortschatz",
  grammar: "Grammatik",
  reading: "Lesen",
  listening: "Hören",
  streak: "Serie",
  community: "Meilenstein",
  exam: "Prüfung",
  special: "Meilenstein",
};

/** ساخت خلاصهٔ سطح از مقدار XP (همان فرمول موتور فعلی). */
export function levelInfo(xp: number) {
  const level = levelFromXp(xp);
  const floor = xpForLevel(level);
  const ceil = xpForLevel(level + 1);
  const xpInLevel = xp - floor;
  const xpNeeded = Math.max(1, ceil - floor);
  return {
    level,
    xpInLevel,
    xpNeeded,
    levelPct: Math.round((xpInLevel / xpNeeded) * 100),
    levelTitle: LEVEL_TITLES[Math.min(level, 8)],
    nextLevelTitle: LEVEL_TITLES[Math.min(level + 1, 8)],
  };
}

function mockStreak(): StreakInfo {
  return {
    current: 14,
    longest: 21,
    lastActiveDay: new Date().toISOString().slice(0, 10),
    freezesLeft: 2,
    weekMap: [true, true, true, true, true, false, false],
  };
}

function mockSummary(): GamificationSummary {
  const info = levelInfo(TOTAL_XP);
  const unlocked = ACHIEVEMENTS.filter((a) => a.unlocked).length;
  return {
    xp: TOTAL_XP,
    ...info,
    streak: mockStreak(),
    unlocked,
    total: ACHIEVEMENTS.length,
    progressPct: Math.round((unlocked / Math.max(1, ACHIEVEMENTS.length)) * 100),
    todayXp: 120,
    source: "mock",
  };
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

/* ------------------------------ خواندن‌ها -------------------------------- */

/** خلاصهٔ XP/سطح/استریک/دستاورد برای داشبورد، پروفایل و صفحهٔ دستاوردها. */
export async function loadGamification(userId: string): Promise<GamificationSummary> {
  if (!BACKEND || !userId) return mockSummary();
  try {
    const pb = getPb();
    const [ledger, streakList, achList, userAch, todayStat] = await Promise.all([
      pbRequest((signal) =>
        pb.collection("xp_ledger").getList<XpLedgerRecord>(1, 500, {
          filter: `user = "${userId}"`,
          sort: "-earned_at",
          signal,
        }),
      ),
      pbRequest((signal) =>
        pb.collection("streaks").getList<StreakRecord>(1, 1, {
          filter: `user = "${userId}"`,
          signal,
        }),
      ),
      pbRequest((signal) =>
        pb.collection("achievements").getFullList<AchievementRecord>({ signal }),
      ),
      pbRequest((signal) =>
        pb.collection("user_achievements").getFullList<UserAchievementRecord>({
          filter: `user = "${userId}"`,
          signal,
        }),
      ),
      pbRequest((signal) =>
        pb.collection("daily_stats").getList<DailyStatRecord>(1, 1, {
          filter: `user = "${userId}" && day = "${today()}"`,
          signal,
        }),
      ),
    ]);

    const xp = ledger.items.reduce((sum, row) => sum + (row.amount ?? 0), 0);
    const streakRec = streakList.items[0];
    const unlocked = userAch.filter((r) => r.unlocked).length;
    const total = achList.length || ACHIEVEMENTS.length;

    return {
      xp,
      ...levelInfo(xp),
      streak: {
        current: streakRec?.current ?? 0,
        longest: streakRec?.longest ?? 0,
        lastActiveDay: streakRec?.last_active_day ?? null,
        freezesLeft: streakRec?.freezes_left ?? 0,
        weekMap: Array.isArray(streakRec?.week_map)
          ? (streakRec?.week_map as boolean[])
          : [false, false, false, false, false, false, false],
      },
      unlocked,
      total,
      progressPct: Math.round((unlocked / Math.max(1, total)) * 100),
      todayXp: todayStat.items[0]?.xp ?? 0,
      source: "backend",
    };
  } catch (err) {
    console.warn("loadGamification fallback to mock", err);
    return mockSummary();
  }
}

/** کاتالوگ دستاوردها + وضعیت کاربر، در قالب `Achievement` فعلی UI. */
export async function loadAchievements(userId: string): Promise<Achievement[]> {
  if (!BACKEND || !userId) return ACHIEVEMENTS;
  try {
    const pb = getPb();
    const [catalog, mine] = await Promise.all([
      pbRequest((signal) =>
        pb.collection("achievements").getFullList<AchievementRecord>({
          filter: "hidden = false",
          sort: "category,slug",
          signal,
        }),
      ),
      pbRequest((signal) =>
        pb.collection("user_achievements").getFullList<UserAchievementRecord>({
          filter: `user = "${userId}"`,
          signal,
        }),
      ),
    ]);
    if (!catalog.length) return ACHIEVEMENTS;

    const byAchievement = new Map(mine.map((r) => [r.achievement, r]));
    return catalog.map((rec) => {
      const fallback = ACHIEVEMENTS.find((a) => a.id === rec.slug);
      const state = byAchievement.get(rec.id);
      const criteria = (rec.criteria ?? {}) as { target?: number };
      const target = criteria.target ?? fallback?.progress?.target ?? 0;
      const current = state?.progress ?? 0;
      return {
        id: rec.slug,
        emoji: rec.icon || fallback?.emoji || "🏅",
        labelDe: rec.title || fallback?.labelDe || rec.slug,
        labelFa: rec.title_fa || fallback?.labelFa || rec.title,
        sub: rec.description || fallback?.sub || "",
        subFa: fallback?.subFa,
        color: fallback?.color ?? "#DD2222",
        category: CATEGORY_MAP[rec.category] ?? "Meilenstein",
        unlocked: Boolean(state?.unlocked),
        unlockedAt: state?.unlocked_at ? state.unlocked_at.slice(0, 10) : undefined,
        progress: state?.unlocked || !target ? undefined : { current, target },
      } satisfies Achievement;
    });
  } catch (err) {
    console.warn("loadAchievements fallback to mock", err);
    return ACHIEVEMENTS;
  }
}

function periodKey(period: MissionRecord["period"]): string {
  const now = new Date();
  if (period === "daily") return now.toISOString().slice(0, 10);
  if (period === "weekly") {
    const d = new Date(now);
    const day = (d.getDay() + 6) % 7;
    d.setDate(d.getDate() - day);
    return `w${d.toISOString().slice(0, 10)}`;
  }
  return `s${now.getFullYear()}`;
}

/** مأموریت‌های روزانه/هفتگی با پیشرفت کاربر. */
export async function loadMissions(
  userId: string,
): Promise<{ daily: Mission[]; weekly: Mission[] }> {
  if (!BACKEND || !userId) return { daily: DAILY_MISSIONS, weekly: WEEKLY_MISSIONS };
  try {
    const pb = getPb();
    const [catalog, mine] = await Promise.all([
      pbRequest((signal) =>
        pb.collection("missions").getFullList<MissionRecord>({
          filter: "active = true",
          sort: "period,slug",
          signal,
        }),
      ),
      pbRequest((signal) =>
        pb.collection("user_missions").getFullList<UserMissionRecord>({
          filter: `user = "${userId}"`,
          signal,
        }),
      ),
    ]);
    if (!catalog.length) return { daily: DAILY_MISSIONS, weekly: WEEKLY_MISSIONS };

    const fallbackAll = [...DAILY_MISSIONS, ...WEEKLY_MISSIONS];
    const toMission = (rec: MissionRecord): Mission => {
      const fallback = fallbackAll.find((m) => m.id === rec.slug);
      const state = mine.find(
        (r) => r.mission === rec.id && r.period_key === periodKey(rec.period),
      );
      const criteria = (rec.criteria ?? {}) as { href?: string; emoji?: string; color?: string };
      return {
        id: rec.slug,
        titleDe: rec.title || fallback?.titleDe || rec.slug,
        titleFa: fallback?.titleFa ?? rec.description ?? "",
        emoji: criteria.emoji ?? fallback?.emoji ?? "🎯",
        xp: rec.xp_reward ?? fallback?.xp ?? 0,
        current: state?.progress ?? 0,
        target: Math.max(1, rec.target ?? fallback?.target ?? 1),
        href: criteria.href ?? fallback?.href ?? "/dashboard",
        color: criteria.color ?? fallback?.color ?? "#DD2222",
      };
    };

    return {
      daily: catalog.filter((m) => m.period === "daily").map(toMission),
      weekly: catalog.filter((m) => m.period !== "daily").map(toMission),
    };
  } catch (err) {
    console.warn("loadMissions fallback to mock", err);
    return { daily: DAILY_MISSIONS, weekly: WEEKLY_MISSIONS };
  }
}

/** تاریخچهٔ XP (فقط خواندنی). */
export async function loadXpHistory(userId: string, limit = 50): Promise<XpEntry[]> {
  if (!BACKEND || !userId) return [];
  try {
    const list = await pbRequest((signal) =>
      getPb()
        .collection("xp_ledger")
        .getList<XpLedgerRecord>(1, limit, {
          filter: `user = "${userId}"`,
          sort: "-earned_at",
          signal,
        }),
    );
    return list.items.map((r) => ({
      id: r.id,
      amount: r.amount ?? 0,
      source: r.source,
      note: r.note ?? "",
      earnedAt: r.earned_at ?? r.created,
    }));
  } catch (err) {
    console.warn("loadXpHistory failed", err);
    return [];
  }
}
