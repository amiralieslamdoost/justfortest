/**
 * دامنهٔ اجتماعی (Community) — سشن ۸.
 *
 * کالکشن‌ها: `chats`, `messages`, `chat_reads`, `tandem_profiles`,
 * `reports`, `blocks` (+ `profiles` برای دایرکتوری کاربران).
 *
 * الگو مثل بقیهٔ دامنه‌ها: «اول محلی، بعد سرور».
 * هر نوشتن بلافاصله در آینهٔ localStorage ثبت می‌شود و در حالت BACKEND از طریق
 * صف آفلاین با PocketBase همگام می‌شود. در `MOCK_MODE` همان دیتای mock فعلی
 * (`src/lib/deusi/community/mockCommunity.ts`) با ذخیرهٔ محلی کار می‌کند.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import { INITIAL_CHATS, MOCK_TANDEM, registerUsers } from "@/lib/deusi/community/mockCommunity";
import type {
  Chat,
  CommunityLevel,
  CommunityUser,
  Message,
  TandemProfile,
} from "@/lib/deusi/community/types";
import type {
  BlockRecord,
  ChatReadRecord,
  ChatRecord,
  MessageRecord,
  ProfileRecord,
  TandemProfileRecord,
} from "./types";

/* -------------------------------------------------------------------------- */
/* آینهٔ محلی                                                                   */
/* -------------------------------------------------------------------------- */

const KEY = (userId: string) => `deusi.community.${userId}`;
const REMOTE_KEY = (userId: string) => `deusi.community.remote.${userId}`;

export type CommunitySnapshot = {
  chats: Chat[];
  ads: TandemProfile[];
  blocked: string[];
};

const EMPTY: CommunitySnapshot = { chats: [], ads: [], blocked: [] };

/** نگاشت شناسه‌های محلی (local-…) به شناسهٔ واقعی رکورد PocketBase. */
type RemoteMap = { chats: Record<string, string>; messages: Record<string, string> };

function readRemoteMap(userId: string): RemoteMap {
  const raw = readLocal<Partial<RemoteMap> | null>(REMOTE_KEY(userId), null);
  return { chats: raw?.chats ?? {}, messages: raw?.messages ?? {} };
}

function writeRemoteMap(userId: string, map: RemoteMap) {
  writeLocal(REMOTE_KEY(userId), map);
}

function mapChatId(userId: string, localId: string): string {
  return readRemoteMap(userId).chats[localId] ?? localId;
}

function mapMessageId(userId: string, localId: string): string {
  return readRemoteMap(userId).messages[localId] ?? localId;
}

function rememberChat(userId: string, localId: string, remoteId: string) {
  const map = readRemoteMap(userId);
  map.chats[localId] = remoteId;
  writeRemoteMap(userId, map);
}

function rememberMessage(userId: string, localId: string, remoteId: string) {
  const map = readRemoteMap(userId);
  map.messages[localId] = remoteId;
  writeRemoteMap(userId, map);
}

export function readCommunityMirror(userId: string): CommunitySnapshot {
  if (!userId) return { ...EMPTY, chats: INITIAL_CHATS, ads: MOCK_TANDEM };
  const raw = readLocal<Partial<CommunitySnapshot> | null>(KEY(userId), null);
  if (!raw) {
    // اولین بار: در حالت MOCK با دیتای نمونه شروع می‌کنیم تا UI خالی نباشد.
    return {
      chats: BACKEND ? [] : INITIAL_CHATS,
      ads: BACKEND ? [] : MOCK_TANDEM,
      blocked: [],
    };
  }
  return {
    chats: Array.isArray(raw.chats) ? raw.chats : [],
    ads: Array.isArray(raw.ads) ? raw.ads : [],
    blocked: Array.isArray(raw.blocked) ? raw.blocked : [],
  };
}

export function writeCommunityMirror(userId: string, snap: CommunitySnapshot) {
  if (!userId) return;
  writeLocal(KEY(userId), snap);
}

function patchMirror(
  userId: string,
  fn: (snap: CommunitySnapshot) => CommunitySnapshot,
): CommunitySnapshot {
  const next = fn(readCommunityMirror(userId));
  writeCommunityMirror(userId, next);
  return next;
}

let seq = 0;
export const newLocalId = (prefix = "local") => `${prefix}-${Date.now()}-${seq++}`;

function nowClock(): string {
  return new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
}

function escapeFilter(value: string): string {
  return value.replace(/"/g, '\\"');
}

/* -------------------------------------------------------------------------- */
/* نگاشت رکوردهای سرور به مدل UI                                                */
/* -------------------------------------------------------------------------- */

const LEVELS: CommunityLevel[] = ["A1", "A2", "B1", "B2", "C1", "C2"];
const asLevel = (value: unknown): CommunityLevel =>
  LEVELS.includes(value as CommunityLevel) ? (value as CommunityLevel) : "B1";

function initialsOf(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "??";
  return (parts[0]![0]! + (parts[1]?.[0] ?? "")).toUpperCase();
}

/** رکورد پروفایل → کاربر جامعه (برای آواتار و نام). */
export function userFromProfile(rec: ProfileRecord): CommunityUser {
  const name = rec.display_name || rec.handle || "Mitglied";
  return {
    id: rec.user || rec.id,
    name,
    handle: rec.handle ? `@${rec.handle.replace(/^@/, "")}` : `@${rec.id}`,
    initials: rec.initials || initialsOf(name),
    level: asLevel(rec.level),
    color: rec.accent_color || "#94a3b8",
  };
}

function messageFromRecord(userId: string, rec: MessageRecord): Message {
  const created = rec.created ? new Date(rec.created) : new Date();
  return {
    id: rec.id,
    authorId: rec.author === userId ? "me" : rec.author,
    body: rec.deleted ? "" : rec.body,
    time: created.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }),
    imageUrl: rec.image ? fileUrl("messages", rec.id, rec.image) : undefined,
    replyToId: rec.reply_to || undefined,
    deleted: rec.deleted || undefined,
  };
}

function fileUrl(collection: string, recordId: string, filename: string): string {
  if (!BACKEND) return filename;
  try {
    return getPb().files.getURL({ id: recordId, collectionName: collection }, filename);
  } catch {
    return filename;
  }
}

function chatFromRecord(
  userId: string,
  rec: ChatRecord,
  messages: Message[],
  unread: number,
): Chat {
  const members = (rec.members ?? []).filter((m) => m !== userId);
  const last = messages[messages.length - 1];
  return {
    id: rec.id,
    kind: rec.kind,
    title: rec.title,
    titleFa: rec.title_fa || undefined,
    description: rec.description || undefined,
    color: rec.color || "#6366f1",
    emoji: rec.emoji || undefined,
    members,
    joined: rec.kind === "room" ? (rec.members ?? []).includes(userId) : true,
    private: rec.private || undefined,
    unread,
    lastTime: last?.time ?? "",
    messages,
    partnerId: rec.kind === "dm" ? members[0] : undefined,
    ownerId: rec.owner ? (rec.owner === userId ? "me" : rec.owner) : undefined,
  };
}

function adFromRecord(userId: string, rec: TandemProfileRecord): TandemProfile {
  return {
    id: rec.id,
    userId: rec.user === userId ? "me" : rec.user,
    headline: rec.headline,
    nativeLanguage: rec.native_language,
    level: asLevel(rec.level),
    goal: rec.goal,
    availability: rec.availability,
    description: rec.description,
    mine: rec.user === userId || undefined,
  };
}

/* -------------------------------------------------------------------------- */
/* خواندن                                                                       */
/* -------------------------------------------------------------------------- */

const MESSAGE_PAGE = 100;

/** بارگذاری کامل وضعیت جامعه (چت‌ها، آگهی‌ها، بلاک‌ها). */
export async function loadCommunity(userId: string): Promise<CommunitySnapshot> {
  if (!userId) return { chats: INITIAL_CHATS, ads: MOCK_TANDEM, blocked: [] };
  const mirror = readCommunityMirror(userId);
  if (!BACKEND) return mirror;

  try {
    const pb = getPb();

    const chatRecords = await pbRequest(() =>
      pb.collection("chats").getFullList<ChatRecord>({
        filter: `kind = "room" || members ~ "${escapeFilter(userId)}"`,
        sort: "-last_message_at",
      }),
    );

    const [messageRecords, readRecords, adRecords, blockRecords] = await Promise.all([
      chatRecords.length
        ? pbRequest(() =>
            pb.collection("messages").getFullList<MessageRecord>({
              filter: chatRecords.map((c) => `chat = "${c.id}"`).join(" || "),
              sort: "created",
              perPage: MESSAGE_PAGE * Math.max(1, chatRecords.length),
            }),
          )
        : Promise.resolve<MessageRecord[]>([]),
      pbRequest(() =>
        pb
          .collection("chat_reads")
          .getFullList<ChatReadRecord>({ filter: `user = "${escapeFilter(userId)}"` }),
      ),
      pbRequest(() =>
        pb
          .collection("tandem_profiles")
          .getFullList<TandemProfileRecord>({ filter: "active = true", sort: "-created" }),
      ),
      pbRequest(() =>
        pb
          .collection("blocks")
          .getFullList<BlockRecord>({ filter: `user = "${escapeFilter(userId)}"` }),
      ),
    ]);

    await hydrateUserDirectory(userId, chatRecords, messageRecords, adRecords);

    const unreadByChat = new Map(readRecords.map((r) => [r.chat, r.unread ?? 0]));
    const chats = chatRecords.map((rec) => {
      const msgs = messageRecords
        .filter((m) => m.chat === rec.id)
        .slice(-MESSAGE_PAGE)
        .map((m) => messageFromRecord(userId, m));
      return chatFromRecord(userId, rec, msgs, unreadByChat.get(rec.id) ?? 0);
    });

    const snap: CommunitySnapshot = {
      chats: mergePending(mirror.chats, chats),
      ads: adRecords.map((r) => adFromRecord(userId, r)),
      blocked: blockRecords.map((b) => b.blocked_user),
    };
    writeCommunityMirror(userId, snap);
    return snap;
  } catch (err) {
    console.warn("[community] load failed, using local mirror", err);
    return mirror;
  }
}

/** چت‌ها/پیام‌هایی که هنوز روی سرور نیستند از بین نروند. */
function mergePending(local: Chat[], remote: Chat[]): Chat[] {
  const remoteIds = new Set(remote.map((c) => c.id));
  const pendingChats = local.filter((c) => c.id.startsWith("local-") && !remoteIds.has(c.id));
  const merged = remote.map((chat) => {
    const mine = local.find((c) => c.id === chat.id);
    if (!mine) return chat;
    const known = new Set(chat.messages.map((m) => m.id));
    const pendingMsgs = mine.messages.filter((m) => m.id.startsWith("local-") && !known.has(m.id));
    if (!pendingMsgs.length) return chat;
    return { ...chat, messages: [...chat.messages, ...pendingMsgs] };
  });
  return [...pendingChats, ...merged];
}

/** پروفایل کاربران دخیل را در دایرکتوری محلی ثبت می‌کند (نام/آواتار). */
async function hydrateUserDirectory(
  userId: string,
  chats: ChatRecord[],
  messages: MessageRecord[],
  ads: TandemProfileRecord[],
) {
  const ids = new Set<string>();
  for (const c of chats) for (const m of c.members ?? []) ids.add(m);
  for (const m of messages) ids.add(m.author);
  for (const a of ads) ids.add(a.user);
  ids.delete(userId);
  if (!ids.size) return;

  try {
    const filter = [...ids].map((id) => `user = "${escapeFilter(id)}"`).join(" || ");
    const profiles = await pbRequest(() =>
      getPb().collection("profiles").getFullList<ProfileRecord>({ filter }),
    );
    registerUsers(profiles.map(userFromProfile));
  } catch (err) {
    console.warn("[community] profile directory unavailable", err);
  }
}

/** جست‌وجوی کاربر با نام یا @handle (سمت سرور در حالت BACKEND). */
export async function searchProfiles(query: string): Promise<CommunityUser[]> {
  const q = query.trim().replace(/^@/, "");
  if (!q || !BACKEND) return [];
  try {
    const res = await pbRequest(() =>
      getPb()
        .collection("profiles")
        .getList<ProfileRecord>(1, 20, {
          filter: `public_profile = true && (display_name ~ "${escapeFilter(q)}" || handle ~ "${escapeFilter(q)}")`,
        }),
    );
    const users = res.items.map(userFromProfile);
    registerUsers(users);
    return users;
  } catch (err) {
    console.warn("[community] profile search failed", err);
    return [];
  }
}

/* -------------------------------------------------------------------------- */
/* نوشتن — همیشه اول محلی                                                       */
/* -------------------------------------------------------------------------- */

export type Draft = { body: string; imageUrl?: string; replyToId?: string };

function patchChat(userId: string, chatId: string, fn: (chat: Chat) => Chat): CommunitySnapshot {
  return patchMirror(userId, (snap) => ({
    ...snap,
    chats: snap.chats.map((c) => (c.id === chatId ? fn(c) : c)),
  }));
}

export async function sendMessage(
  userId: string,
  chatId: string,
  draft: Draft,
): Promise<CommunitySnapshot> {
  const text = draft.body.trim();
  if (!text && !draft.imageUrl) return readCommunityMirror(userId);

  const message: Message = {
    id: newLocalId("local-msg"),
    authorId: "me",
    body: text,
    time: nowClock(),
    imageUrl: draft.imageUrl,
    replyToId: draft.replyToId,
  };

  const snap = patchChat(userId, chatId, (c) => ({
    ...c,
    unread: 0,
    lastTime: message.time,
    messages: [...c.messages, message],
  }));

  if (BACKEND) {
    await enqueue("community.message.create", {
      userId,
      chatId,
      localId: message.id,
      body: text,
      imageUrl: draft.imageUrl ?? "",
      replyToId: draft.replyToId ?? "",
    });
  }
  return snap;
}

export async function deleteMessage(
  userId: string,
  chatId: string,
  messageId: string,
): Promise<CommunitySnapshot> {
  const snap = patchChat(userId, chatId, (c) => ({
    ...c,
    messages: c.messages.map((m) =>
      m.id === messageId ? { ...m, body: "", imageUrl: undefined, deleted: true } : m,
    ),
  }));
  if (BACKEND) await enqueue("community.message.delete", { userId, messageId });
  return snap;
}

export async function markRead(userId: string, chatId: string): Promise<CommunitySnapshot> {
  const snap = patchChat(userId, chatId, (c) => ({ ...c, unread: 0 }));
  if (BACKEND) {
    await enqueue("community.read", { userId, chatId }, `community.read:${userId}:${chatId}`);
  }
  return snap;
}

export async function setChatMembership(
  userId: string,
  chatId: string,
  joined: boolean,
): Promise<CommunitySnapshot> {
  const snap = patchChat(userId, chatId, (c) => ({ ...c, joined }));
  if (BACKEND) {
    await enqueue("community.membership", { userId, chatId, joined, memberId: userId });
  }
  return snap;
}

export async function addMember(
  userId: string,
  chatId: string,
  memberId: string,
): Promise<CommunitySnapshot> {
  const snap = patchChat(userId, chatId, (c) =>
    c.members.includes(memberId) ? c : { ...c, members: [...c.members, memberId] },
  );
  if (BACKEND) {
    await enqueue("community.membership", { userId, chatId, joined: true, memberId });
  }
  return snap;
}

export async function removeMember(
  userId: string,
  chatId: string,
  memberId: string,
): Promise<CommunitySnapshot> {
  const snap = patchChat(userId, chatId, (c) => ({
    ...c,
    members: c.members.filter((m) => m !== memberId),
  }));
  if (BACKEND) {
    await enqueue("community.membership", { userId, chatId, joined: false, memberId });
  }
  return snap;
}

export type ChatPatch = Partial<
  Pick<Chat, "title" | "description" | "emoji" | "private" | "color">
>;

export async function updateChat(
  userId: string,
  chatId: string,
  input: ChatPatch,
): Promise<CommunitySnapshot> {
  const snap = patchChat(userId, chatId, (c) => ({ ...c, ...input }));
  if (BACKEND) {
    await enqueue(
      "community.chat.update",
      { userId, chatId, input },
      `community.chat.update:${chatId}`,
    );
  }
  return snap;
}

export async function createGroup(
  userId: string,
  input: { name: string; description: string; private: boolean },
  localId?: string,
): Promise<{ id: string; snapshot: CommunitySnapshot }> {
  const id = localId ?? newLocalId("local-group");
  const chat: Chat = {
    id,
    kind: "group",
    title: input.name.trim(),
    description: input.description.trim() || undefined,
    color: "#6366f1",
    emoji: "✨",
    ownerId: "me",
    members: [],
    joined: true,
    private: input.private,
    unread: 0,
    lastTime: nowClock(),
    messages: [],
  };
  const snapshot = patchMirror(userId, (snap) => ({ ...snap, chats: [chat, ...snap.chats] }));
  if (BACKEND) {
    await enqueue("community.chat.create", {
      userId,
      localId: id,
      kind: "group",
      title: chat.title,
      description: chat.description ?? "",
      private: input.private,
      partnerId: "",
    });
  }
  return { id, snapshot };
}

export async function openDirectChat(
  userId: string,
  partner: CommunityUser,
  localId?: string,
): Promise<{ id: string; snapshot: CommunitySnapshot }> {
  const mirror = readCommunityMirror(userId);
  const existing = mirror.chats.find((c) => c.kind === "dm" && c.partnerId === partner.id);
  if (existing) return { id: existing.id, snapshot: mirror };

  const id = localId ?? newLocalId("local-dm");
  const chat: Chat = {
    id,
    kind: "dm",
    title: partner.name,
    color: partner.color,
    members: [partner.id],
    partnerId: partner.id,
    joined: true,
    unread: 0,
    lastTime: nowClock(),
    messages: [],
  };
  const snapshot = patchMirror(userId, (snap) => ({ ...snap, chats: [chat, ...snap.chats] }));
  if (BACKEND) {
    await enqueue("community.chat.create", {
      userId,
      localId: id,
      kind: "dm",
      title: partner.name,
      description: "",
      private: true,
      partnerId: partner.id,
    });
  }
  return { id, snapshot };
}

export type TandemInput = Omit<TandemProfile, "id" | "userId" | "mine">;

export async function createTandemAd(
  userId: string,
  input: TandemInput,
): Promise<CommunitySnapshot> {
  const ad: TandemProfile = { ...input, id: newLocalId("local-ad"), userId: "me", mine: true };
  const snap = patchMirror(userId, (s) => ({ ...s, ads: [ad, ...s.ads] }));
  if (BACKEND) await enqueue("community.tandem.create", { userId, localId: ad.id, input });
  return snap;
}

export async function deleteTandemAd(userId: string, adId: string): Promise<CommunitySnapshot> {
  const snap = patchMirror(userId, (s) => ({ ...s, ads: s.ads.filter((a) => a.id !== adId) }));
  if (BACKEND) await enqueue("community.tandem.delete", { userId, adId });
  return snap;
}

/* -------------------------------------------------------------------------- */
/* مدیریت تخلف: گزارش و بلاک                                                    */
/* -------------------------------------------------------------------------- */

export type ReportTarget = "post" | "comment" | "message" | "tandem_profile" | "user";
export type ReportReason = "spam" | "harassment" | "hate" | "sexual" | "other";

export const REPORT_REASONS: Array<{ value: ReportReason; de: string; fa: string }> = [
  { value: "spam", de: "Spam oder Werbung", fa: "هرزنامه یا تبلیغ" },
  { value: "harassment", de: "Belästigung", fa: "آزار و اذیت" },
  { value: "hate", de: "Hass oder Beleidigung", fa: "نفرت‌پراکنی یا توهین" },
  { value: "sexual", de: "Sexueller Inhalt", fa: "محتوای جنسی" },
  { value: "other", de: "Etwas anderes", fa: "موارد دیگر" },
];

export async function reportContent(
  userId: string,
  input: {
    targetType: ReportTarget;
    targetId: string;
    reason: ReportReason;
    details?: string;
  },
): Promise<void> {
  if (!BACKEND || !userId) return;
  await enqueue("community.report", {
    userId,
    targetType: input.targetType,
    targetId: input.targetId,
    reason: input.reason,
    details: input.details ?? "",
  });
}

export async function setBlocked(
  userId: string,
  targetUserId: string,
  blocked: boolean,
): Promise<CommunitySnapshot> {
  const snap = patchMirror(userId, (s) => ({
    ...s,
    blocked: blocked
      ? [...new Set([...s.blocked, targetUserId])]
      : s.blocked.filter((id) => id !== targetUserId),
  }));
  if (BACKEND) {
    await enqueue(
      "community.block",
      { userId, targetUserId, blocked },
      `community.block:${userId}:${targetUserId}`,
    );
  }
  return snap;
}

/* -------------------------------------------------------------------------- */
/* همگام‌سازی زنده (realtime)                                                   */
/* -------------------------------------------------------------------------- */

export type CommunityChange = "chats" | "messages" | "tandem" | "notifications";

export function subscribeCommunity(
  userId: string,
  onChange: (what: CommunityChange) => void,
): () => void {
  if (!BACKEND || !userId) return () => {};
  let disposed = false;
  const unsubs: Array<() => void> = [];

  const bind = async (collection: string, what: CommunityChange, filter?: string) => {
    try {
      const pb = getPb();
      const unsub = await pb
        .collection(collection)
        .subscribe("*", () => onChange(what), filter ? { filter } : undefined);
      if (disposed) void unsub();
      else unsubs.push(() => void unsub());
    } catch (err) {
      console.warn(`[community] realtime ${collection} unavailable`, err);
    }
  };

  void bind("messages", "messages");
  void bind("chats", "chats");
  void bind("tandem_profiles", "tandem");
  void bind("notifications", "notifications", `user = "${escapeFilter(userId)}"`);

  return () => {
    disposed = true;
    for (const u of unsubs) u();
    unsubs.length = 0;
  };
}

/* -------------------------------------------------------------------------- */
/* هندلرهای صف آفلاین                                                           */
/* -------------------------------------------------------------------------- */

async function dataUrlToFile(dataUrl: string, name: string): Promise<File | null> {
  try {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([blob], name, { type: blob.type || "image/jpeg" });
  } catch {
    return null;
  }
}

if (BACKEND) {
  registerHandler("community.chat.create", async (raw) => {
    const p = raw as {
      userId: string;
      localId: string;
      kind: "group" | "dm";
      title: string;
      description: string;
      private: boolean;
      partnerId: string;
    };
    const members = p.partnerId ? [p.userId, p.partnerId] : [p.userId];
    const rec = await pbRequest(() =>
      getPb().collection("chats").create<ChatRecord>({
        kind: p.kind,
        title: p.title,
        description: p.description,
        color: "#6366f1",
        emoji: "✨",
        owner: p.userId,
        members,
        private: p.private,
        last_message_at: new Date().toISOString(),
      }),
    );
    rememberChat(p.userId, p.localId, rec.id);
    patchMirror(p.userId, (snap) => ({
      ...snap,
      chats: snap.chats.map((c) => (c.id === p.localId ? { ...c, id: rec.id } : c)),
    }));
  });

  registerHandler("community.chat.update", async (raw) => {
    const p = raw as { userId: string; chatId: string; input: ChatPatch };
    const id = mapChatId(p.userId, p.chatId);
    if (id.startsWith("local-")) throw new Error("chat not synced yet");
    await pbRequest(() =>
      getPb()
        .collection("chats")
        .update(id, {
          ...(p.input.title !== undefined ? { title: p.input.title } : {}),
          ...(p.input.description !== undefined ? { description: p.input.description } : {}),
          ...(p.input.emoji !== undefined ? { emoji: p.input.emoji } : {}),
          ...(p.input.color !== undefined ? { color: p.input.color } : {}),
          ...(p.input.private !== undefined ? { private: p.input.private } : {}),
        }),
    );
  });

  registerHandler("community.membership", async (raw) => {
    const p = raw as { userId: string; chatId: string; joined: boolean; memberId: string };
    const id = mapChatId(p.userId, p.chatId);
    if (id.startsWith("local-")) throw new Error("chat not synced yet");
    await pbRequest(() =>
      getPb()
        .collection("chats")
        .update(id, { [p.joined ? "members+" : "members-"]: p.memberId }),
    );
  });

  registerHandler("community.message.create", async (raw) => {
    const p = raw as {
      userId: string;
      chatId: string;
      localId: string;
      body: string;
      imageUrl: string;
      replyToId: string;
    };
    const chatId = mapChatId(p.userId, p.chatId);
    if (chatId.startsWith("local-")) throw new Error("chat not synced yet");

    const payload: Record<string, unknown> = {
      chat: chatId,
      author: p.userId,
      body: p.body,
      reply_to: p.replyToId ? mapMessageId(p.userId, p.replyToId) : "",
      deleted: false,
    };

    let rec: MessageRecord;
    if (p.imageUrl && p.imageUrl.startsWith("data:")) {
      const file = await dataUrlToFile(p.imageUrl, `chat-${Date.now()}.jpg`);
      const form = new FormData();
      for (const [k, v] of Object.entries(payload)) form.append(k, String(v));
      if (file) form.append("image", file);
      rec = await pbRequest(() => getPb().collection("messages").create<MessageRecord>(form));
    } else {
      rec = await pbRequest(() => getPb().collection("messages").create<MessageRecord>(payload));
    }

    rememberMessage(p.userId, p.localId, rec.id);
    patchMirror(p.userId, (snap) => ({
      ...snap,
      chats: snap.chats.map((c) =>
        c.id === p.chatId || c.id === chatId
          ? {
              ...c,
              messages: c.messages.map((m) => (m.id === p.localId ? { ...m, id: rec.id } : m)),
            }
          : c,
      ),
    }));

    await pbRequest(() =>
      getPb().collection("chats").update(chatId, { last_message_at: new Date().toISOString() }),
    ).catch(() => undefined);
  });

  registerHandler("community.message.delete", async (raw) => {
    const p = raw as { userId: string; messageId: string };
    const id = mapMessageId(p.userId, p.messageId);
    if (id.startsWith("local-")) throw new Error("message not synced yet");
    await pbRequest(() =>
      getPb().collection("messages").update(id, { body: "", image: null, deleted: true }),
    );
  });

  registerHandler("community.read", async (raw) => {
    const p = raw as { userId: string; chatId: string };
    const chatId = mapChatId(p.userId, p.chatId);
    if (chatId.startsWith("local-")) return;
    const pb = getPb();
    const existing = await pbRequest(() =>
      pb
        .collection("chat_reads")
        .getFirstListItem<ChatReadRecord>(
          `user = "${escapeFilter(p.userId)}" && chat = "${escapeFilter(chatId)}"`,
        )
        .catch(() => null),
    );
    const data = {
      user: p.userId,
      chat: chatId,
      last_read_at: new Date().toISOString(),
      unread: 0,
    };
    if (existing) await pbRequest(() => pb.collection("chat_reads").update(existing.id, data));
    else await pbRequest(() => pb.collection("chat_reads").create(data));
  });

  registerHandler("community.tandem.create", async (raw) => {
    const p = raw as { userId: string; localId: string; input: TandemInput };
    const rec = await pbRequest(() =>
      getPb().collection("tandem_profiles").create<TandemProfileRecord>({
        user: p.userId,
        headline: p.input.headline,
        native_language: p.input.nativeLanguage,
        level: p.input.level,
        goal: p.input.goal,
        availability: p.input.availability,
        description: p.input.description,
        active: true,
      }),
    );
    patchMirror(p.userId, (snap) => ({
      ...snap,
      ads: snap.ads.map((a) => (a.id === p.localId ? { ...a, id: rec.id } : a)),
    }));
  });

  registerHandler("community.tandem.delete", async (raw) => {
    const p = raw as { userId: string; adId: string };
    if (p.adId.startsWith("local-")) return;
    await pbRequest(() => getPb().collection("tandem_profiles").delete(p.adId));
  });

  registerHandler("community.report", async (raw) => {
    const p = raw as {
      userId: string;
      targetType: ReportTarget;
      targetId: string;
      reason: ReportReason;
      details: string;
    };
    const targetId = p.targetType === "message" ? mapMessageId(p.userId, p.targetId) : p.targetId;
    await pbRequest(() =>
      getPb().collection("reports").create({
        reporter: p.userId,
        target_type: p.targetType,
        target_id: targetId,
        reason: p.reason,
        details: p.details,
        status: "open",
      }),
    );
  });

  registerHandler("community.block", async (raw) => {
    const p = raw as { userId: string; targetUserId: string; blocked: boolean };
    const pb = getPb();
    const existing = await pbRequest(() =>
      pb
        .collection("blocks")
        .getFirstListItem<BlockRecord>(
          `user = "${escapeFilter(p.userId)}" && blocked_user = "${escapeFilter(p.targetUserId)}"`,
        )
        .catch(() => null),
    );
    if (p.blocked && !existing) {
      await pbRequest(() =>
        pb
          .collection("blocks")
          .create({ user: p.userId, blocked_user: p.targetUserId, reason: "" }),
      );
    } else if (!p.blocked && existing) {
      await pbRequest(() => pb.collection("blocks").delete(existing.id));
    }
  });
}
