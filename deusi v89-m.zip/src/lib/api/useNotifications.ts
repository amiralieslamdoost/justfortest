/**
 * هوک اعلان‌ها (سشن ۹) — خواندن، خوانده‌شده‌کردن، حذف و real-time.
 */
import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import { useCurrentUserId } from "./useExams";
import {
  clearNotifications,
  listNotifications,
  markAllRead,
  markRead,
  removeNotification,
  restoreNotification,
  subscribeNotifications,
  type AppNotification,
} from "./notifications";

/** فهرست اعلان‌ها با اشتراک real-time. */
export function useNotifications(seed: AppNotification[] = []) {
  const userId = useCurrentUserId();
  const qc = useQueryClient();
  const key = queryKeys.notifications.list(userId);

  const q = useQuery({
    queryKey: key,
    queryFn: () => listNotifications(userId, seed),
    staleTime: 15_000,
  });

  useEffect(() => {
    if (!userId) return;
    return subscribeNotifications(userId, () => {
      void qc.invalidateQueries({ queryKey: key });
      void qc.invalidateQueries({ queryKey: queryKeys.notifications.unread(userId) });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const list = (q.data ?? []) as AppNotification[];

  const patch = (fn: (list: AppNotification[]) => AppNotification[]) =>
    qc.setQueryData<AppNotification[]>(key, (prev) => fn(prev ?? []));

  const toggleRead = useMutation({
    mutationFn: ({ id, read }: { id: string; read: boolean }) => markRead(userId, id, read),
    onMutate: ({ id, read }: { id: string; read: boolean }) =>
      patch((l) => l.map((n) => (n.id === id ? { ...n, read } : n))),
  });

  const readAll = useMutation({
    mutationFn: () => markAllRead(userId),
    onMutate: () => patch((l) => l.map((n) => ({ ...n, read: true }))),
  });

  const remove = useMutation({
    mutationFn: (id: string) => removeNotification(userId, id),
    onMutate: (id: string) => patch((l) => l.filter((n) => n.id !== id)),
  });

  const restore = useMutation({
    mutationFn: (n: AppNotification) => restoreNotification(userId, n),
    onMutate: (n: AppNotification) => patch((l) => [n, ...l.filter((x) => x.id !== n.id)]),
  });

  const clearAll = useMutation({
    mutationFn: () => clearNotifications(userId),
    onMutate: () => patch(() => []),
  });

  return {
    notifications: list,
    unread: list.filter((n) => !n.read).length,
    isLoading: q.isLoading,
    setRead: (id: string, read = true) => toggleRead.mutate({ id, read }),
    markAllRead: () => readAll.mutate(),
    remove: (id: string) => remove.mutate(id),
    restore: (n: AppNotification) => restore.mutate(n),
    clearAll: () => clearAll.mutate(),
  };
}
