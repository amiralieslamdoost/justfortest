/**
 * فرم پشتیبانی → کالکشن `contact_messages`.
 * در MOCK_MODE پیام فقط محلی نگه داشته می‌شود (بدون شکست UI).
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { readLocal, writeLocal } from "./storage";
import type { ContactMessageRecord } from "./types";

const LS_MESSAGES = "deusi.support.messages.v1";

export type ContactTopic = "frage" | "fehler" | "vorschlag" | "abrechnung";

export interface ContactInput {
  name: string;
  email: string;
  subject: string;
  message: string;
  topic: ContactTopic;
  userId?: string;
}

/** ارسال پیام پشتیبانی. */
export async function sendContactMessage(input: ContactInput): Promise<void> {
  const payload = {
    name: input.name.trim(),
    email: input.email.trim(),
    subject: input.subject.trim(),
    message: input.message.trim(),
    topic: input.topic,
    ...(input.userId ? { user: input.userId } : {}),
    status: "new",
  };

  if (!BACKEND) {
    const list = readLocal<unknown[]>(LS_MESSAGES, []);
    writeLocal(LS_MESSAGES, [{ ...payload, created: new Date().toISOString() }, ...list]);
    return;
  }

  const pb = getPb();
  await pbRequest((signal) =>
    pb.collection("contact_messages").create<ContactMessageRecord>(payload, { signal }),
  );
}
