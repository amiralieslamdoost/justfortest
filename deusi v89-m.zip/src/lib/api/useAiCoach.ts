/**
 * KI-Coach — هوک‌های TanStack Query (سشن ۱۰).
 *
 * یک API یکسان برای صفحهٔ `ki-coach` فراهم می‌کند که در دو حالت کار می‌کند:
 *  - BACKEND + AI_PROXY: تاریخچه در PocketBase، پاسخ استریمی از پروکسی.
 *  - MOCK: همان رفتار قبلی (localStorage + پاسخ‌های نمونه).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AI_ENABLED, AI_PROXY_URL } from "./config";
import { getPb } from "./client";
import { queryKeys } from "./queryKeys";
import { useCurrentUserId } from "./useExams";
import {
  createThread,
  deleteThread as apiDeleteThread,
  listMessages,
  listThreads,
  renameThread,
  streamChat,
  type AiThread,
} from "./ai";
import { ApiError } from "./errors";
import {
  loadThreads,
  makeThread,
  nowTime,
  saveThreads,
  titleFrom,
  type CoachThread,
} from "@/lib/deusi/kiCoachHistory";
import { generateReply } from "@/lib/deusi/kiCoachMock";

export interface CoachUiMessage {
  id: string;
  role: "user" | "ai";
  text: string;
  time: string;
}

export interface CoachUiThread {
  id: string;
  title: string;
  updatedAt: number;
  messageCount: number;
}

export interface CoachApi {
  threads: CoachUiThread[];
  messages: CoachUiMessage[];
  activeId: string;
  typing: boolean;
  /** true تا پایان پاسخ (شامل زمان استریم شدن متن). */
  busy: boolean;
  /** خطای قابل‌نمایش به کاربر (فارسی). */
  error: string | null;
  ready: boolean;
  send: (text: string) => void;
  stop: () => void;
  retry: () => void;
  newChat: () => void;
  openChat: (id: string) => void;
  deleteChat: (id: string) => void;
}

const MIGRATION_KEY = "deusi.kiCoach.migrated.v1";

/* -------------------------------------------------------------------------- */
/* حالت MOCK                                                                   */
/* -------------------------------------------------------------------------- */

function useMockCoach(
  greeting: string,
  routeThreadId: string | undefined,
  onOpen: (id: string) => void,
): CoachApi {
  const [threads, setThreads] = useState<CoachThread[]>(() => {
    // در حالت بک‌اند این هوک فقط برای هم‌ترازی تعداد هوک‌ها اجرا می‌شود؛
    // پس نباید چیزی در localStorage بنویسد.
    if (AI_ENABLED) return [];
    const stored = loadThreads();
    if (stored.length) return stored;
    const first = makeThread(greeting);
    saveThreads([first]);
    return [first];
  });
  const [typing, setTyping] = useState(false);
  const lastInput = useRef("");

  const activeId = useMemo(() => {
    if (routeThreadId && threads.some((t) => t.id === routeThreadId)) return routeThreadId;
    return threads[0]?.id ?? "";
  }, [routeThreadId, threads]);

  const active = threads.find((t) => t.id === activeId) ?? threads[0];

  const update = useCallback((updater: (prev: CoachThread[]) => CoachThread[]) => {
    setThreads((prev) => {
      const next = updater(prev).sort((a, b) => b.updatedAt - a.updatedAt);
      saveThreads(next);
      return next;
    });
  }, []);

  const send = useCallback(
    (text: string) => {
      if (!text.trim() || typing || !active) return;
      lastInput.current = text;
      const id = active.id;
      update((prev) =>
        prev.map((t) =>
          t.id === id
            ? {
                ...t,
                title: t.messages.some((m) => m.role === "user") ? t.title : titleFrom(text),
                updatedAt: Date.now(),
                messages: [
                  ...t.messages,
                  { id: "u" + Date.now(), role: "user" as const, text, time: nowTime() },
                ],
              }
            : t,
        ),
      );
      setTyping(true);
      setTimeout(() => {
        update((prev) =>
          prev.map((t) =>
            t.id === id
              ? {
                  ...t,
                  updatedAt: Date.now(),
                  messages: [
                    ...t.messages,
                    {
                      id: "a" + Date.now(),
                      role: "ai" as const,
                      text: generateReply(text),
                      time: nowTime(),
                    },
                  ],
                }
              : t,
          ),
        );
        setTyping(false);
      }, 800);
    },
    [active, typing, update],
  );

  const newChat = useCallback(() => {
    const t = makeThread(greeting);
    update((prev) => [t, ...prev]);
    onOpen(t.id);
  }, [greeting, onOpen, update]);

  const deleteChat = useCallback(
    (id: string) => {
      setThreads((prev) => {
        const rest = prev.filter((t) => t.id !== id);
        const next = rest.length ? rest : [makeThread(greeting)];
        saveThreads(next);
        if (id === activeId) onOpen(next[0].id);
        return next;
      });
    },
    [activeId, greeting, onOpen],
  );

  return {
    threads: threads.map((t) => ({
      id: t.id,
      title: t.title,
      updatedAt: t.updatedAt,
      messageCount: t.messages.length,
    })),
    messages: (active?.messages ?? []) as CoachUiMessage[],
    activeId,
    typing,
    busy: typing,
    error: null,
    ready: Boolean(active),
    send,
    stop: () => setTyping(false),
    retry: () => send(lastInput.current),
    newChat,
    openChat: onOpen,
    deleteChat,
  };
}

/* -------------------------------------------------------------------------- */
/* حالت بک‌اند                                                                 */
/* -------------------------------------------------------------------------- */

function useBackendCoach(
  greeting: string,
  level: string,
  routeThreadId: string | undefined,
  onOpen: (id: string) => void,
): CoachApi {
  const userId = useCurrentUserId();
  const qc = useQueryClient();
  const [streamText, setStreamText] = useState("");
  const [typing, setTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<CoachUiMessage | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const lastInput = useRef("");

  const threadsQuery = useQuery({
    queryKey: [...queryKeys.ai.threads(), userId],
    queryFn: () => listThreads(userId),
    enabled: Boolean(userId),
    staleTime: 30_000,
  });

  const threads = useMemo(() => threadsQuery.data ?? [], [threadsQuery.data]);

  const activeId = useMemo(() => {
    if (routeThreadId && threads.some((t) => t.id === routeThreadId)) return routeThreadId;
    return threads[0]?.id ?? "";
  }, [routeThreadId, threads]);

  const messagesQuery = useQuery({
    queryKey: queryKeys.ai.thread(activeId),
    queryFn: () => listMessages(activeId),
    enabled: Boolean(activeId),
    staleTime: 10_000,
  });

  /* انتقال یک‌بارهٔ تاریخچهٔ محلی به سرور */
  useEffect(() => {
    if (!userId || threadsQuery.isLoading) return;
    if (typeof window === "undefined") return;
    if (window.localStorage.getItem(MIGRATION_KEY)) return;
    const local = loadThreads().filter((t) => t.messages.some((m) => m.role === "user"));
    window.localStorage.setItem(MIGRATION_KEY, "1");
    if (!local.length) return;
    const token = getPb().authStore.token;
    if (!token) return;
    void fetch(`${AI_PROXY_URL}/import`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ level, threads: local }),
    })
      .then(() => qc.invalidateQueries({ queryKey: queryKeys.ai.all }))
      .catch(() => null);
  }, [userId, threadsQuery.isLoading, level, qc]);

  const create = useMutation({
    mutationFn: () => createThread(userId, { level }),
    onSuccess: (t: AiThread) => {
      qc.setQueryData<AiThread[]>([...queryKeys.ai.threads(), userId], (prev) => [
        t,
        ...(prev ?? []),
      ]);
      onOpen(t.id);
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => apiDeleteThread(id),
    onSuccess: (_res, id) => {
      const rest = threads.filter((t) => t.id !== id);
      qc.setQueryData<AiThread[]>([...queryKeys.ai.threads(), userId], rest);
      if (id === activeId && rest[0]) onOpen(rest[0].id);
      if (!rest.length) create.mutate();
    },
  });

  /* اگر هیچ گفتگویی وجود ندارد، یکی بساز */
  useEffect(() => {
    if (!userId || threadsQuery.isLoading || threads.length || create.isPending) return;
    create.mutate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, threadsQuery.isLoading, threads.length]);

  const stop = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setTyping(false);
  }, []);

  const runSend = useCallback(
    async (text: string) => {
      const threadId = activeId;
      if (!threadId || !text.trim() || typing) return;
      lastInput.current = text;
      setError(null);

      const history = (messagesQuery.data ?? []).map((m) => ({
        role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
        content: m.text,
      }));

      setPending({ id: "local-" + Date.now(), role: "user", text, time: nowTime() });
      setStreamText("");
      setTyping(true);

      const controller = new AbortController();
      abortRef.current = controller;

      const isFirst = history.filter((h) => h.role === "user").length === 0;

      try {
        await streamChat({
          threadId,
          message: text,
          level,
          history,
          signal: controller.signal,
          onDelta: (chunk) => setStreamText((prev) => prev + chunk),
        });
        if (isFirst) await renameThread(threadId, titleFrom(text)).catch(() => null);
      } catch (err) {
        if ((err as Error)?.name !== "AbortError") {
          setError(err instanceof ApiError ? err.message : "پاسخ KI-Coach دریافت نشد.");
        }
      } finally {
        abortRef.current = null;
        setTyping(false);
        setStreamText("");
        setPending(null);
        await qc.invalidateQueries({ queryKey: queryKeys.ai.thread(threadId) });
        await qc.invalidateQueries({ queryKey: [...queryKeys.ai.threads(), userId] });
      }
    },
    [activeId, level, messagesQuery.data, qc, typing, userId],
  );

  const send = useCallback((text: string) => void runSend(text), [runSend]);

  const messages: CoachUiMessage[] = useMemo(() => {
    const base: CoachUiMessage[] = (messagesQuery.data ?? []).map((m) => ({
      id: m.id,
      role: m.role === "assistant" ? "ai" : "user",
      text: m.text,
      time: m.time,
    }));
    const list = base.length
      ? base
      : [{ id: "greeting", role: "ai" as const, text: greeting, time: nowTime() }];
    const out = [...list];
    if (pending) out.push(pending);
    if (streamText) out.push({ id: "stream", role: "ai", text: streamText, time: nowTime() });
    return out;
  }, [messagesQuery.data, greeting, pending, streamText]);

  return {
    threads: threads.map((t) => ({
      id: t.id,
      title: t.title,
      updatedAt: t.updatedAt,
      messageCount: t.messageCount,
    })),
    messages,
    activeId,
    typing: typing && !streamText,
    busy: typing,
    error,
    ready: Boolean(activeId),
    send,
    stop,
    retry: () => send(lastInput.current),
    newChat: () => create.mutate(),
    openChat: onOpen,
    deleteChat: (id: string) => remove.mutate(id),
  };
}

/* -------------------------------------------------------------------------- */

/** هوک اصلی صفحهٔ KI-Coach. حالت مناسب را خودش انتخاب می‌کند. */
export function useAiCoach(params: {
  greeting: string;
  level?: string;
  threadId?: string;
  onOpen: (id: string) => void;
}): CoachApi {
  const { greeting, level = "unknown", threadId, onOpen } = params;
  const mock = useMockCoach(greeting, threadId, onOpen);
  const backend = useBackendCoach(greeting, level, threadId, onOpen);
  return AI_ENABLED ? backend : mock;
}
