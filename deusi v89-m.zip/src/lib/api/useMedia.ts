/**
 * هوک‌های TanStack Query برای دامنهٔ مدیا (kino / musik / podcasts / books) — سشن ۵.
 */
import { useCallback, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import {
  getBook,
  getEpisode,
  getFilm,
  getSong,
  listArtists,
  listBooks,
  listEpisodes,
  listFilms,
  listShows,
  listSongs,
  type MediaQuery,
} from "./media";
import {
  EMPTY_MEDIA_PROGRESS,
  listMediaProgress,
  mediaKey,
  saveMediaProgress,
  type MediaProgressMap,
  type MediaProgressState,
} from "./mediaProgress";
import { listMediaVocab, saveMediaWord, type MediaWordInput } from "./mediaVocab";
import type { MediaType } from "./types";
import { films as MOCK_FILMS, type Film } from "@/lib/deusi/mockKino";
import {
  artists as MOCK_ARTISTS,
  songs as MOCK_SONGS,
  type Artist,
  type Song,
} from "@/lib/deusi/mockMusic";
import {
  podcastEpisodes as MOCK_EPISODES,
  podcastShows as MOCK_SHOWS,
  type PodcastEpisode,
  type PodcastShow,
} from "@/lib/deusi/mockPodcasts";
import { LEARNING_BOOKS as MOCK_BOOKS, type LearningBook } from "@/lib/deusi/dictionary/books";
import { useDeusi } from "@/lib/deusi/store";

const LIST_STALE = 60_000;
const ITEM_STALE = 5 * 60_000;

/* ------------------------------- فیلم‌ها -------------------------------- */

export function useFilms(query: MediaQuery = {}) {
  const q = useQuery({
    queryKey: queryKeys.media.films(query),
    queryFn: () => listFilms(query),
    staleTime: LIST_STALE,
    placeholderData: (prev) => prev,
  });
  return {
    films: q.data?.items ?? [],
    total: q.data?.totalItems ?? 0,
    totalPages: q.data?.totalPages ?? 1,
    isLoading: q.isLoading,
    error: q.error,
  };
}

export function useFilm(idOrSlug: string) {
  const fallback = useMemo(() => MOCK_FILMS.find((f) => f.id === idOrSlug) ?? null, [idOrSlug]);
  const q = useQuery({
    queryKey: queryKeys.media.film(idOrSlug),
    queryFn: () => getFilm(idOrSlug),
    enabled: Boolean(idOrSlug),
    staleTime: ITEM_STALE,
    initialData: fallback,
  });
  return { film: (q.data ?? fallback) as Film | null, isLoading: q.isLoading, error: q.error };
}

/* ------------------------------- موسیقی -------------------------------- */

export function useSongs(query: MediaQuery = {}) {
  const q = useQuery({
    queryKey: queryKeys.media.songs(query),
    queryFn: () => listSongs(query),
    staleTime: LIST_STALE,
    placeholderData: (prev) => prev,
  });
  return {
    songs: q.data?.items ?? [],
    total: q.data?.totalItems ?? 0,
    totalPages: q.data?.totalPages ?? 1,
    isLoading: q.isLoading,
    error: q.error,
  };
}

export function useSong(idOrSlug: string) {
  const fallback = useMemo(() => MOCK_SONGS.find((s) => s.id === idOrSlug) ?? null, [idOrSlug]);
  const q = useQuery({
    queryKey: queryKeys.media.song(idOrSlug),
    queryFn: () => getSong(idOrSlug),
    enabled: Boolean(idOrSlug),
    staleTime: ITEM_STALE,
    initialData: fallback,
  });
  return { song: (q.data ?? fallback) as Song | null, isLoading: q.isLoading, error: q.error };
}

export function useArtists() {
  const q = useQuery({
    queryKey: queryKeys.media.artists(),
    queryFn: () => listArtists(),
    staleTime: ITEM_STALE,
    initialData: MOCK_ARTISTS,
  });
  return { artists: (q.data ?? MOCK_ARTISTS) as Artist[], isLoading: q.isLoading };
}

/* ------------------------------ پادکست‌ها ------------------------------ */

export function useEpisodes(query: MediaQuery = {}) {
  const q = useQuery({
    queryKey: queryKeys.media.episodes(query),
    queryFn: () => listEpisodes(query),
    staleTime: LIST_STALE,
    placeholderData: (prev) => prev,
  });
  return {
    episodes: q.data?.items ?? [],
    total: q.data?.totalItems ?? 0,
    totalPages: q.data?.totalPages ?? 1,
    isLoading: q.isLoading,
    error: q.error,
  };
}

export function useEpisode(idOrSlug: string) {
  const fallback = useMemo(() => MOCK_EPISODES.find((e) => e.id === idOrSlug) ?? null, [idOrSlug]);
  const q = useQuery({
    queryKey: queryKeys.media.episode(idOrSlug),
    queryFn: () => getEpisode(idOrSlug),
    enabled: Boolean(idOrSlug),
    staleTime: ITEM_STALE,
    initialData: fallback,
  });
  return {
    episode: (q.data ?? fallback) as PodcastEpisode | null,
    isLoading: q.isLoading,
    error: q.error,
  };
}

export function usePodcastShows() {
  const q = useQuery({
    queryKey: queryKeys.media.shows(),
    queryFn: () => listShows(),
    staleTime: ITEM_STALE,
    initialData: MOCK_SHOWS,
  });
  return { shows: (q.data ?? MOCK_SHOWS) as PodcastShow[], isLoading: q.isLoading };
}

/* ------------------------------- کتاب‌ها ------------------------------- */

export function useBooks(query: MediaQuery = {}) {
  const q = useQuery({
    queryKey: queryKeys.media.books(query),
    queryFn: () => listBooks(query),
    staleTime: LIST_STALE,
    placeholderData: (prev) => prev,
  });
  return {
    books: q.data?.items ?? [],
    total: q.data?.totalItems ?? 0,
    totalPages: q.data?.totalPages ?? 1,
    isLoading: q.isLoading,
    error: q.error,
  };
}

export function useBook(idOrSlug: string) {
  const fallback = useMemo(() => MOCK_BOOKS.find((b) => b.id === idOrSlug) ?? null, [idOrSlug]);
  const q = useQuery({
    queryKey: queryKeys.media.book(idOrSlug),
    queryFn: () => getBook(idOrSlug),
    enabled: Boolean(idOrSlug),
    staleTime: ITEM_STALE,
    initialData: fallback,
  });
  return {
    book: (q.data ?? fallback) as LearningBook | null,
    isLoading: q.isLoading,
  };
}

/* ------------------------------- پیشرفت ------------------------------- */

/** نقشهٔ پیشرفت همهٔ آیتم‌های مدیا. */
export function useMediaProgressMap() {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const q = useQuery({
    queryKey: queryKeys.media.progressByUser(userId),
    queryFn: () => listMediaProgress(userId),
    staleTime: LIST_STALE,
    initialData: {} as MediaProgressMap,
  });
  return { progress: q.data ?? {}, isLoading: q.isLoading, userId };
}

/** خواندن/نوشتن پیشرفت یک آیتم مدیا. */
export function useMediaProgress(type: MediaType, mediaId: string) {
  const qc = useQueryClient();
  const { progress, userId } = useMediaProgressMap();
  const state = progress[mediaKey(type, mediaId)] ?? EMPTY_MEDIA_PROGRESS;

  const mutation = useMutation({
    mutationFn: (patch: Partial<MediaProgressState>) =>
      saveMediaProgress(userId, type, mediaId, patch),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.media.progressByUser(userId) });
    },
  });

  const patch = useCallback(
    (p: Partial<MediaProgressState>) => {
      if (!mediaId) return;
      mutation.mutate(p);
    },
    [mutation, mediaId],
  );

  return { state, patch, isSaving: mutation.isPending };
}

/* -------------------------- واژه‌های مدیا --------------------------- */

/** واژه‌های ذخیره‌شده از مدیا + ذخیرهٔ واژهٔ جدید. */
export function useMediaVocab(filter: { type?: MediaType; mediaId?: string } = {}) {
  const { currentUser } = useDeusi();
  const userId = currentUser?.id ?? "";
  const qc = useQueryClient();

  const q = useQuery({
    queryKey: queryKeys.media.vocab(userId, filter),
    queryFn: () => listMediaVocab(userId, filter),
    staleTime: LIST_STALE,
  });

  const mutation = useMutation({
    mutationFn: (input: {
      type: MediaType;
      mediaId: string;
      word: MediaWordInput;
      context?: string;
      timestampSec?: number;
    }) => saveMediaWord(userId, input),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["media", "vocab", userId] });
      void qc.invalidateQueries({ queryKey: queryKeys.vocabulary.all });
    },
  });

  const saveWord = useCallback(
    (input: {
      type: MediaType;
      mediaId: string;
      word: MediaWordInput;
      context?: string;
      timestampSec?: number;
    }) => mutation.mutate(input),
    [mutation],
  );

  return { words: q.data ?? [], isLoading: q.isLoading, saveWord, isSaving: mutation.isPending };
}
