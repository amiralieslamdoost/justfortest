/**
 * دامنهٔ رویدادها (Events) — سشن ۸.
 *
 * کاتالوگ رویدادها در حالت BACKEND از کالکشن `events` خوانده می‌شود (با fallback
 * به `mockEvents` وقتی بک‌اند نیست یا خطا داد). ثبت‌نام (RSVP) روی کالکشن
 * `event_rsvps` ذخیره می‌شود و از طریق realtime بین دستگاه‌ها همگام می‌ماند.
 * الگو مثل بقیه: اول محلی، بعد صف آفلاین.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import { MOCK_EVENTS, getEvent } from "@/lib/deusi/events/mockEvents";
import type { DeusiEvent, SeatReservation } from "@/lib/deusi/events/mockEvents";
import type { EventRecord, EventRsvpRecord } from "./types";

/** شناسهٔ رابطه در PocketBase (رکورد) یا همان slug در حالت MOCK. */
const eventRef = (event: DeusiEvent): string => event.recordId ?? event.id;

function coverUrl(rec: EventRecord): string {
  if (rec.cover_image) {
    try {
      return (
        getPb().files.getURL({ ...rec, collectionName: "events" }, rec.cover_image) || rec.cover
      );
    } catch {
      return rec.cover;
    }
  }
  return rec.cover;
}

function eventFromRecord(rec: EventRecord): DeusiEvent {
  const fallback = getEvent(rec.slug);
  return {
    id: rec.slug,
    recordId: rec.id,
    instituteId: rec.institute_id || "deusi",
    title: rec.title,
    shortDescription: rec.short_description,
    description: rec.description,
    cover: coverUrl(rec) || fallback?.cover || "",
    organizer: {
      id: rec.organizer?.id ?? "",
      name: rec.organizer?.name ?? "",
      tagline: rec.organizer?.tagline ?? "",
      rating: rec.organizer?.rating ?? 0,
      reviews: rec.organizer?.reviews ?? 0,
      events: fallback?.organizer.events ?? 0,
      participants: fallback?.organizer.participants ?? "",
      satisfaction: fallback?.organizer.satisfaction ?? "",
      verified: rec.organizer?.verified ?? false,
    },
    date: rec.date_label,
    dateShort: rec.date_label,
    weekday: rec.weekday,
    time: rec.time_label,
    duration: rec.duration_label,
    locationName: rec.location_name,
    locationAddress: rec.location_address,
    levels: rec.levels ?? [],
    levelSummary: rec.level_summary,
    bands: rec.bands ?? [],
    themesCount: rec.themes_count ?? 0,
    groupsCount: rec.groups_count ?? 0,
    seatsPerGroup: rec.seats_per_group ?? 0,
    notes: rec.notes ?? [],
    hasRegistration: (rec.groups?.length ?? 0) > 0,
    groups: rec.groups?.length
      ? rec.groups.map((g) => {
          const seeded = g as typeof g & { reservations?: SeatReservation[] };
          return { ...g, reservations: seeded.reservations ?? [] };
        })
      : undefined,
    weekly: rec.weekly_topics ?? undefined,
  };
}

/** کاتالوگ رویدادها. BACKEND: کالکشن `events`؛ وگرنه دیتای mock. */
export async function loadEvents(): Promise<DeusiEvent[]> {
  if (!BACKEND) return MOCK_EVENTS;
  try {
    const records = await pbRequest(() =>
      getPb().collection("events").getFullList<EventRecord>({
        filter: "published = true",
        sort: "starts_at,slug",
      }),
    );
    if (!records.length) return MOCK_EVENTS;
    return records.map(eventFromRecord);
  } catch (err) {
    console.warn("[events] catalog load failed, using mock data", err);
    return MOCK_EVENTS;
  }
}

/** یک رویداد بر اساس slug. */
export async function loadEvent(slug: string): Promise<DeusiEvent | undefined> {
  if (!BACKEND) return getEvent(slug);
  try {
    const rec = await pbRequest(() =>
      getPb()
        .collection("events")
        .getFirstListItem<EventRecord>(`slug = "${slug.replace(/"/g, '\\"')}"`),
    );
    return eventFromRecord(rec);
  } catch (err) {
    console.warn("[events] event load failed, using mock data", err);
    return getEvent(slug);
  }
}

export interface Registration {
  eventId: string;
  instituteId: string;
  groupId: string;
  tableNumber: number;
  seat: number;
  level: string;
  leaderName: string;
  registeredAt: number;
}

export interface EventState {
  /** groupId -> رزروهای اضافه بر دیتای پایه */
  reservations: Record<string, SeatReservation[]>;
  myRegistration: Registration | null;
}

const EMPTY: EventState = { reservations: {}, myRegistration: null };

const KEY = (instituteId: string, eventId: string) => `deusi.events::${instituteId}::${eventId}`;
const REMOTE_KEY = (eventId: string) => `deusi.events.remote::${eventId}`;

export function readEventMirror(instituteId: string, eventId: string): EventState {
  const raw = readLocal<Partial<EventState> | null>(KEY(instituteId, eventId), null);
  if (!raw) return EMPTY;
  return {
    reservations: raw.reservations ?? {},
    myRegistration: raw.myRegistration ?? null,
  };
}

export function writeEventMirror(instituteId: string, eventId: string, state: EventState) {
  writeLocal(KEY(instituteId, eventId), state);
}

function escapeFilter(value: string): string {
  return value.replace(/"/g, '\\"');
}

function rememberRsvp(eventId: string, recordId: string) {
  writeLocal(REMOTE_KEY(eventId), recordId);
}

function readRsvpId(eventId: string): string {
  return readLocal<string>(REMOTE_KEY(eventId), "");
}

/* -------------------------------------------------------------------------- */
/* خواندن                                                                       */
/* -------------------------------------------------------------------------- */

function stateFromRecords(
  userId: string,
  event: DeusiEvent,
  records: EventRsvpRecord[],
): EventState {
  const reservations: Record<string, SeatReservation[]> = {};
  let mine: Registration | null = null;

  for (const rec of records) {
    if (rec.status === "canceled") continue;
    const list = (reservations[rec.group_id] ??= []);
    list.push({
      seat: rec.seat,
      participantName: rec.participant_name,
      order: rec.order_note || undefined,
    });
    if (rec.user === userId) {
      const group = event.groups?.find((g) => g.id === rec.group_id);
      rememberRsvp(event.id, rec.id);
      mine = {
        eventId: event.id,
        instituteId: event.instituteId,
        groupId: rec.group_id,
        tableNumber: group?.tableNumber ?? 0,
        seat: rec.seat,
        level: group?.level ?? "",
        leaderName: group?.leader.name ?? "",
        registeredAt: rec.reserved_at ? new Date(rec.reserved_at).getTime() : Date.now(),
      };
    }
  }

  return { reservations, myRegistration: mine };
}

/** وضعیت صندلی‌های یک رویداد (سرور در حالت BACKEND، وگرنه آینهٔ محلی). */
export async function loadEventState(userId: string, event: DeusiEvent): Promise<EventState> {
  const mirror = readEventMirror(event.instituteId, event.id);
  if (!BACKEND || !userId) return mirror;

  try {
    const records = await pbRequest(() =>
      getPb()
        .collection("event_rsvps")
        .getFullList<EventRsvpRecord>({
          filter: `event = "${escapeFilter(eventRef(event))}"`,
          sort: "seat",
        }),
    );
    const state = stateFromRecords(userId, event, records);
    writeEventMirror(event.instituteId, event.id, state);
    return state;
  } catch (err) {
    console.warn("[events] load failed, using local mirror", err);
    return mirror;
  }
}

/* -------------------------------------------------------------------------- */
/* نوشتن                                                                        */
/* -------------------------------------------------------------------------- */

export async function reserveSeat(
  userId: string,
  event: DeusiEvent,
  reg: Registration,
  participantName: string,
): Promise<EventState> {
  const prev = readEventMirror(event.instituteId, event.id);
  const extra = prev.reservations[reg.groupId] ?? [];
  const next: EventState = {
    myRegistration: reg,
    reservations: {
      ...prev.reservations,
      [reg.groupId]: [...extra, { seat: reg.seat, participantName }],
    },
  };
  writeEventMirror(event.instituteId, event.id, next);

  if (BACKEND && userId) {
    await enqueue("events.rsvp.create", {
      userId,
      eventId: event.id,
      recordId: eventRef(event),
      groupId: reg.groupId,
      seat: reg.seat,
      participantName,
    });
  }
  return next;
}

export async function submitOrder(
  userId: string,
  event: DeusiEvent,
  order: string,
): Promise<EventState> {
  const prev = readEventMirror(event.instituteId, event.id);
  const reg = prev.myRegistration;
  const note = order.trim();
  if (!reg || !note) return prev;

  const extra = prev.reservations[reg.groupId] ?? [];
  const next: EventState = {
    ...prev,
    reservations: {
      ...prev.reservations,
      [reg.groupId]: extra.map((r) => (r.seat === reg.seat ? { ...r, order: note } : r)),
    },
  };
  writeEventMirror(event.instituteId, event.id, next);

  if (BACKEND && userId) {
    await enqueue(
      "events.rsvp.order",
      { userId, eventId: event.id, order: note },
      `events.rsvp.order:${event.id}`,
    );
  }
  return next;
}

export async function cancelRsvp(userId: string, event: DeusiEvent): Promise<EventState> {
  const prev = readEventMirror(event.instituteId, event.id);
  const reg = prev.myRegistration;
  if (!reg) return prev;

  const extra = prev.reservations[reg.groupId] ?? [];
  const next: EventState = {
    myRegistration: null,
    reservations: {
      ...prev.reservations,
      [reg.groupId]: extra.filter((r) => r.seat !== reg.seat),
    },
  };
  writeEventMirror(event.instituteId, event.id, next);

  if (BACKEND && userId) {
    await enqueue("events.rsvp.cancel", { userId, eventId: event.id });
  }
  return next;
}

/* -------------------------------------------------------------------------- */
/* همگام‌سازی زنده                                                              */
/* -------------------------------------------------------------------------- */

export function subscribeEvent(eventId: string, onChange: () => void): () => void {
  if (!BACKEND || !eventId) return () => {};
  let disposed = false;
  let cleanup: (() => void) | null = null;

  void (async () => {
    try {
      const unsub = await getPb()
        .collection("event_rsvps")
        .subscribe("*", () => onChange(), { filter: `event = "${escapeFilter(eventId)}"` });
      if (disposed) void unsub();
      else cleanup = () => void unsub();
    } catch (err) {
      console.warn("[events] realtime unavailable", err);
    }
  })();

  return () => {
    disposed = true;
    cleanup?.();
  };
}

/* -------------------------------------------------------------------------- */
/* هندلرهای صف آفلاین                                                           */
/* -------------------------------------------------------------------------- */

if (BACKEND) {
  registerHandler("events.rsvp.create", async (raw) => {
    const p = raw as {
      userId: string;
      eventId: string;
      recordId?: string;
      groupId: string;
      seat: number;
      participantName: string;
    };
    const rec = await pbRequest(() =>
      getPb()
        .collection("event_rsvps")
        .create<EventRsvpRecord>({
          user: p.userId,
          event: p.recordId ?? p.eventId,
          group_id: p.groupId,
          seat: p.seat,
          participant_name: p.participantName,
          order_note: "",
          status: "reserved",
          reserved_at: new Date().toISOString(),
        }),
    );
    rememberRsvp(p.eventId, rec.id);
  });

  registerHandler("events.rsvp.order", async (raw) => {
    const p = raw as { userId: string; eventId: string; order: string };
    const id = readRsvpId(p.eventId);
    if (!id) throw new Error("rsvp not synced yet");
    await pbRequest(() => getPb().collection("event_rsvps").update(id, { order_note: p.order }));
  });

  registerHandler("events.rsvp.cancel", async (raw) => {
    const p = raw as { userId: string; eventId: string };
    const id = readRsvpId(p.eventId);
    if (!id) return;
    await pbRequest(() => getPb().collection("event_rsvps").update(id, { status: "canceled" }));
    rememberRsvp(p.eventId, "");
  });
}
