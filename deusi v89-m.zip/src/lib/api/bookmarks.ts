/**
 * نشان‌ها و علاقه‌مندی‌ها (سشن ۹).
 * دادهٔ محلی (`deusi.bookmarks.v2` / `deusi.favorites.v2`) در اولین ورود
 * به بک‌اند منتقل می‌شود و از آن پس localStorage فقط نقش cache دارد.
 * همهٔ نوشتن‌ها از صف آفلاین می‌گذرند.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import type { BookmarkRecord, BookmarkTarget } from "./types";

export type BookmarkKind = "bookmark" | "favorite";

/** انواع کلاینتی (همان `InteractionType`). */
export type ItemType =
  "word" | "grammar" | "article" | "podcast" | "exam" | "music" | "film" | "book";

export interface RemoteBookmark {
  recordId: string;
  kind: BookmarkKind;
  type: ItemType;
  id: string;
  at: string;
  title?: string;
  sub?: string;
  level?: string;
  to?: string;
}

const TO_TARGET: Record<ItemType, BookmarkTarget> = {
  word: "word",
  grammar: "lesson",
  article: "article",
  podcast: "episode",
  exam: "exam",
  music: "song",
  film: "film",
  book: "book",
};

const FROM_TARGET: Partial<Record<BookmarkTarget, ItemType>> = {
  word: "word",
  lesson: "grammar",
  article: "article",
  episode: "podcast",
  exam: "exam",
  song: "music",
  film: "film",
  book: "book",
};

function toRemote(rec: BookmarkRecord): RemoteBookmark | null {
  const type = FROM_TARGET[rec.target_type];
  if (!type) return null;
  const meta = (rec.meta ?? {}) as { sub?: string; level?: string; to?: string };
  return {
    recordId: rec.id,
    kind: rec.kind === "favorite" ? "favorite" : "bookmark",
    type,
    id: rec.target_id,
    at: rec.created,
    title: rec.label || undefined,
    sub: meta.sub,
    level: meta.level,
    to: meta.to,
  };
}

/** همهٔ نشان‌ها و علاقه‌مندی‌های کاربر. */
export async function listBookmarks(userId: string): Promise<RemoteBookmark[]> {
  if (!BACKEND || !userId) return [];
  const list = await pbRequest((signal) =>
    getPb()
      .collection("bookmarks")
      .getFullList<BookmarkRecord>({
        filter: `user = "${userId}"`,
        sort: "-created",
        signal,
      }),
  );
  return list.map(toRemote).filter((x): x is RemoteBookmark => x !== null);
}

export interface BookmarkInput {
  kind: BookmarkKind;
  type: ItemType;
  id: string;
  title?: string;
  sub?: string;
  level?: string;
  to?: string;
}

/** افزودن (idempotent) — کلید صف از نوع/شناسه ساخته می‌شود. */
export async function addBookmark(userId: string, input: BookmarkInput): Promise<void> {
  if (!BACKEND || !userId) return;
  await enqueue(
    "bookmark.add",
    { userId, input },
    `bookmark.add:${userId}:${input.kind}:${input.type}:${input.id}`,
  );
}

/** حذف بر اساس نوع/شناسه (نه recordId) تا آفلاین هم درست کار کند. */
export async function removeBookmark(
  userId: string,
  kind: BookmarkKind,
  type: ItemType,
  id: string,
): Promise<void> {
  if (!BACKEND || !userId) return;
  await enqueue(
    "bookmark.remove",
    { userId, kind, type, id },
    `bookmark.remove:${userId}:${kind}:${type}:${id}`,
  );
}

/** انتقال یک‌بارهٔ دادهٔ محلی به بک‌اند. */
export async function migrateBookmarks(userId: string, items: BookmarkInput[]): Promise<void> {
  if (!BACKEND || !userId || !items.length) return;
  const existing = await listBookmarks(userId).catch(() => [] as RemoteBookmark[]);
  const has = new Set(existing.map((e) => `${e.kind}:${e.type}:${e.id}`));
  for (const item of items) {
    if (has.has(`${item.kind}:${item.type}:${item.id}`)) continue;
    await addBookmark(userId, item);
  }
}

/* ------------------------- هندلرهای صف آفلاین -------------------------- */

async function findRecord(
  userId: string,
  kind: BookmarkKind,
  type: ItemType,
  id: string,
): Promise<BookmarkRecord | null> {
  try {
    return await getPb()
      .collection("bookmarks")
      .getFirstListItem<BookmarkRecord>(
        `user = "${userId}" && kind = "${kind}" && target_type = "${TO_TARGET[type]}" && target_id = "${id}"`,
      );
  } catch {
    return null;
  }
}

registerHandler("bookmark.add", async (payload) => {
  const { userId, input } = payload as { userId: string; input: BookmarkInput };
  const found = await findRecord(userId, input.kind, input.type, input.id);
  if (found) return;
  await getPb()
    .collection("bookmarks")
    .create({
      user: userId,
      kind: input.kind,
      target_type: TO_TARGET[input.type],
      target_id: input.id,
      label: input.title ?? "",
      meta: { sub: input.sub, level: input.level, to: input.to },
    });
});

registerHandler("bookmark.remove", async (payload) => {
  const { userId, kind, type, id } = payload as {
    userId: string;
    kind: BookmarkKind;
    type: ItemType;
    id: string;
  };
  const found = await findRecord(userId, kind, type, id);
  if (found) await getPb().collection("bookmarks").delete(found.id);
});
