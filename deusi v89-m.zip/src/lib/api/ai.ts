/**
 * KI-Coach — لایهٔ داده (سشن ۱۰).
 *
 * - تاریخچه: کالکشن‌های `ai_threads` / `ai_messages` در PocketBase.
 * - پاسخ مدل: فقط از طریق `backend/ai-proxy` (کلید API هرگز در مرورگر نیست).
 * - در MOCK_MODE (نبود `VITE_PB_URL` یا `VITE_AI_PROXY_URL`) هیچ‌کدام از این
 *   توابع صدا زده نمی‌شوند و صفحه از `kiCoachHistory` محلی استفاده می‌کند.
 */
import { AI_ENABLED, AI_PROXY_URL, BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { ApiError, toApiError } from "./errors";
import type { AiMessageRecord, AiThreadRecord } from "./types";

export type CoachMode = AiThreadRecord["mode"];

export interface AiThread {
  id: string;
  title: string;
  mode: CoachMode;
  updatedAt: number;
  messageCount: number;
}

export interface AiMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  time: string;
}

function hhmm(iso: string): string {
  const d = iso ? new Date(iso) : new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function toThread(r: AiThreadRecord & { messageCount?: number }): AiThread {
  return {
    id: r.id,
    title: r.title || "Neuer Chat",
    mode: r.mode || "coach",
    updatedAt: new Date(r.last_message_at || r.updated || r.created || Date.now()).getTime(),
    messageCount: r.messageCount ?? 0,
  };
}

/* -------------------------------------------------------------------------- */
/* Threads                                                                     */
/* -------------------------------------------------------------------------- */

/** فهرست گفتگوهای کاربر (جدیدترین اول). */
export async function listThreads(userId: string): Promise<AiThread[]> {
  if (!BACKEND || !userId) return [];
  const pb = getPb();
  const items = await pbRequest((signal) =>
    pb.collection("ai_threads").getFullList<AiThreadRecord>({
      filter: `user = "${userId}" && archived = false`,
      sort: "-last_message_at,-created",
      signal,
    }),
  );
  return items.map((r) => toThread(r));
}

/** ساخت گفتگوی تازه. */
export async function createThread(
  userId: string,
  input: { title?: string; mode?: CoachMode; level?: string } = {},
): Promise<AiThread> {
  const pb = getPb();
  const rec = await pbRequest((signal) =>
    pb.collection("ai_threads").create<AiThreadRecord>(
      {
        user: userId,
        title: input.title || "Neuer Chat",
        mode: input.mode || "coach",
        level: input.level || "unknown",
        last_message_at: new Date().toISOString(),
        archived: false,
      },
      { signal },
    ),
  );
  return toThread(rec);
}

/** تغییر عنوان گفتگو. */
export async function renameThread(threadId: string, title: string): Promise<void> {
  const pb = getPb();
  await pbRequest((signal) =>
    pb.collection("ai_threads").update(threadId, { title: title.slice(0, 80) }, { signal }),
  );
}

/** حذف گفتگو (پیام‌ها با cascade حذف می‌شوند). */
export async function deleteThread(threadId: string): Promise<void> {
  const pb = getPb();
  await pbRequest((signal) => pb.collection("ai_threads").delete(threadId, { signal }));
}

/** پیام‌های یک گفتگو به ترتیب زمانی. */
export async function listMessages(threadId: string): Promise<AiMessage[]> {
  if (!BACKEND || !threadId) return [];
  const pb = getPb();
  const items = await pbRequest((signal) =>
    pb.collection("ai_messages").getFullList<AiMessageRecord>({
      filter: `thread = "${threadId}"`,
      sort: "created",
      signal,
    }),
  );
  return items
    .filter((m) => m.role !== "system")
    .map((m) => ({
      id: m.id,
      role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
      text: m.content,
      time: hhmm(m.created),
    }));
}

/* -------------------------------------------------------------------------- */
/* Streaming از پروکسی                                                         */
/* -------------------------------------------------------------------------- */

export interface StreamOptions {
  threadId: string;
  message: string;
  mode?: CoachMode;
  level?: string;
  history?: { role: "user" | "assistant"; content: string }[];
  signal?: AbortSignal;
  onDelta: (chunk: string) => void;
}

const ERROR_FA: Record<string, string> = {
  rate_limited: "سقف استفادهٔ شما از KI-Coach پر شده است. کمی بعد دوباره تلاش کنید.",
  message_too_long: "پیام خیلی بلند است. کوتاه‌ترش کنید.",
  unauthorized: "نشست شما منقضی شده است. دوباره وارد شوید.",
  upstream_unavailable: "سرویس هوش مصنوعی در دسترس نیست. کمی بعد دوباره تلاش کنید.",
  upstream_error: "سرویس هوش مصنوعی پاسخ معتبری نداد.",
  stream_failed: "ارتباط در میانهٔ پاسخ قطع شد.",
};

function proxyError(status: number, code?: string): ApiError {
  const kind =
    status === 401 || status === 403
      ? "auth"
      : status === 429
        ? "rateLimit"
        : status >= 500
          ? "server"
          : status === 400
            ? "validation"
            : "unknown";
  return new ApiError(kind, ERROR_FA[code ?? ""] ?? "پاسخ KI-Coach دریافت نشد.", status);
}

/**
 * ارسال پیام و خواندن پاسخ به‌صورت SSE.
 * متن کامل برگردانده می‌شود؛ قطعه‌ها از طریق `onDelta` می‌رسند.
 */
export async function streamChat(opts: StreamOptions): Promise<string> {
  if (!AI_ENABLED) throw new ApiError("unknown", "KI-Coach پیکربندی نشده است.", 0);

  const pb = getPb();
  const token = pb.authStore.token;
  if (!token) throw new ApiError("auth", ERROR_FA.unauthorized, 401);

  let res: Response;
  try {
    res = await fetch(`${AI_PROXY_URL}/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      signal: opts.signal,
      body: JSON.stringify({
        threadId: opts.threadId,
        message: opts.message,
        mode: opts.mode ?? "coach",
        level: opts.level ?? "unknown",
        history: (opts.history ?? []).slice(-12),
      }),
    });
  } catch (err) {
    if ((err as Error)?.name === "AbortError") throw err;
    throw toApiError(err);
  }

  if (!res.ok || !res.body) {
    const data = (await res.json().catch(() => null)) as { error?: string } | null;
    throw proxyError(res.status, data?.error);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let full = "";
  let streamError: string | null = null;

  const handleEvent = (block: string) => {
    let event = "message";
    const dataLines: string[] = [];
    for (const line of block.split("\n")) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
    }
    if (!dataLines.length) return;
    let payload: { text?: string; error?: string };
    try {
      payload = JSON.parse(dataLines.join("\n")) as { text?: string; error?: string };
    } catch {
      return;
    }
    if (event === "delta" && payload.text) {
      full += payload.text;
      opts.onDelta(payload.text);
    } else if (event === "error") {
      streamError = payload.error ?? "stream_failed";
    }
  };

  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const blocks = buffer.split("\n\n");
    buffer = blocks.pop() ?? "";
    blocks.forEach(handleEvent);
  }
  if (buffer.trim()) handleEvent(buffer);

  if (streamError && !full) throw proxyError(502, streamError);
  return full;
}
