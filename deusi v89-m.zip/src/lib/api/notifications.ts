/**
 * اعلان‌ها (سشن ۹).
 * ساخت اعلان از سمت سرور انجام می‌شود؛ کلاینت فقط می‌خواند، خوانده‌شده می‌کند
 * یا حذف می‌کند. تغییرهای آفلاین در صف `offline-queue` می‌روند.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest, tryPb } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import type { NotificationRecord } from "./types";

export type NotificationKind = NotificationRecord["kind"];

export interface AppNotification {
  id: string;
  kind: NotificationKind;
  title: string;
  body: string;
  href: string;
  read: boolean;
  createdAt: string;
}

const LS_KEY = (userId: string) => `deusi.notifications.${userId || "guest"}`;

function readLocal(userId: string): AppNotification[] | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(LS_KEY(userId));
    return raw ? (JSON.parse(raw) as AppNotification[]) : null;
  } catch {
    return null;
  }
}

function writeLocal(userId: string, list: AppNotification[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(LS_KEY(userId), JSON.stringify(list));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

function toNotification(r: NotificationRecord): AppNotification {
  return {
    id: r.id,
    kind: r.kind,
    title: r.title ?? "",
    body: r.body ?? "",
    href: r.href ?? "",
    read: Boolean(r.read),
    createdAt: r.created,
  };
}

/**
 * فهرست اعلان‌ها.
 * @param seed در حالت MOCK اگر چیزی ذخیره نشده باشد، این فهرست پایه می‌شود.
 */
export async function listNotifications(
  userId: string,
  seed: AppNotification[] = [],
): Promise<AppNotification[]> {
  if (!BACKEND || !userId) {
    const local = readLocal(userId);
    if (local) return local;
    writeLocal(userId, seed);
    return seed;
  }
  try {
    const list = await pbRequest((signal) =>
      getPb()
        .collection("notifications")
        .getList<NotificationRecord>(1, 200, {
          filter: `user = "${userId}"`,
          sort: "-created",
          signal,
        }),
    );
    return list.items.map(toNotification);
  } catch (err) {
    console.warn("listNotifications fallback", err);
    return readLocal(userId) ?? seed;
  }
}

/** تعداد نخوانده‌ها. */
export async function unreadCount(userId: string): Promise<number> {
  if (!BACKEND || !userId) return (readLocal(userId) ?? []).filter((n) => !n.read).length;
  try {
    const list = await pbRequest((signal) =>
      getPb()
        .collection("notifications")
        .getList<NotificationRecord>(1, 1, {
          filter: `user = "${userId}" && read = false`,
          signal,
        }),
    );
    return list.totalItems;
  } catch {
    return 0;
  }
}

function patchLocal(userId: string, fn: (list: AppNotification[]) => AppNotification[]) {
  const list = readLocal(userId) ?? [];
  writeLocal(userId, fn(list));
}

/** یک اعلان را خوانده‌شده می‌کند. */
export async function markRead(userId: string, id: string, read = true): Promise<void> {
  patchLocal(userId, (list) => list.map((n) => (n.id === id ? { ...n, read } : n)));
  if (!BACKEND || !userId) return;
  await enqueue("notif.read", { id, read }, `notif.read:${id}`);
}

/** همهٔ اعلان‌ها را خوانده‌شده می‌کند. */
export async function markAllRead(userId: string): Promise<void> {
  patchLocal(userId, (list) => list.map((n) => ({ ...n, read: true })));
  if (!BACKEND || !userId) return;
  await enqueue("notif.readAll", { userId }, `notif.readAll:${userId}`);
}

/** حذف یک اعلان. */
export async function removeNotification(userId: string, id: string): Promise<void> {
  patchLocal(userId, (list) => list.filter((n) => n.id !== id));
  if (!BACKEND || !userId) return;
  await enqueue("notif.delete", { id }, `notif.delete:${id}`);
}

/**
 * بازگردانی اعلان حذف‌شده (دکمهٔ Undo). در بک‌اند رکورد تازه ساخته می‌شود.
 */
export async function restoreNotification(userId: string, n: AppNotification): Promise<void> {
  patchLocal(userId, (list) => [n, ...list.filter((x) => x.id !== n.id)]);
  if (!BACKEND || !userId) return;
  await enqueue(
    "notif.create",
    { user: userId, kind: n.kind, title: n.title, body: n.body, href: n.href, read: n.read },
    `notif.create:${n.id}`,
  );
}

/** حذف همهٔ اعلان‌ها. */
export async function clearNotifications(userId: string): Promise<void> {
  const list = readLocal(userId) ?? [];
  writeLocal(userId, []);
  if (!BACKEND || !userId) return;
  for (const n of list) await enqueue("notif.delete", { id: n.id }, `notif.delete:${n.id}`);
}

/** اشتراک real-time روی اعلان‌های کاربر. */
export function subscribeNotifications(
  userId: string,
  onChange: (n: AppNotification, action: string) => void,
): () => void {
  const pb = tryPb();
  if (!pb || !userId) return () => {};
  let unsub: (() => void) | undefined;
  void pb
    .collection("notifications")
    .subscribe<NotificationRecord>(
      "*",
      (e) => {
        if (e.record.user !== userId) return;
        onChange(toNotification(e.record), e.action);
      },
      { filter: `user = "${userId}"` },
    )
    .then((fn) => {
      unsub = fn;
    })
    .catch((err) => console.warn("notifications subscribe failed", err));
  return () => unsub?.();
}

/* ------------------------- هندلرهای صف آفلاین -------------------------- */

registerHandler("notif.read", async (payload) => {
  const { id, read } = payload as { id: string; read: boolean };
  await getPb()
    .collection("notifications")
    .update(id, { read, read_at: read ? new Date().toISOString() : null });
});

registerHandler("notif.readAll", async (payload) => {
  const { userId } = payload as { userId: string };
  const pb = getPb();
  const list = await pb.collection("notifications").getFullList<NotificationRecord>({
    filter: `user = "${userId}" && read = false`,
  });
  for (const rec of list) {
    await pb
      .collection("notifications")
      .update(rec.id, { read: true, read_at: new Date().toISOString() });
  }
});

registerHandler("notif.delete", async (payload) => {
  const { id } = payload as { id: string };
  await getPb().collection("notifications").delete(id);
});

registerHandler("notif.create", async (payload) => {
  await getPb()
    .collection("notifications")
    .create(payload as Record<string, unknown>);
});
