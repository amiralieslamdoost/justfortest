/**
 * هوک‌های TanStack Query برای دامنهٔ واژگان.
 * کامپوننت‌ها فقط از این هوک‌ها استفاده می‌کنند (نه مستقیم از PocketBase).
 */
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import { BACKEND } from "./config";
import {
  listProverbs,
  listVerbs,
  listWordFamilies,
  searchWordsPaged,
  type WordQuery,
} from "./vocabulary";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import { ALL_WORDS } from "@/lib/deusi/dictionary/mockWords";
import { PROVERBS } from "@/lib/deusi/dictionary/proverbs";
import { WORD_ROOTS } from "@/lib/deusi/wordfamilies/mockFamilies";

/** جست‌وجوی صفحه‌بندی‌شدهٔ دیکشنری (سرور یا mock). */
export function useDictionarySearch(query: WordQuery) {
  return useQuery({
    queryKey: queryKeys.vocabulary.words(query),
    queryFn: () => searchWordsPaged(query),
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });
}

/**
 * فهرست واژه‌هایی که صفحهٔ دیکشنری روی آن فیلتر می‌کند.
 * در حالت MOCK همان `ALL_WORDS` است (بدون درخواست شبکه).
 */
export function useWordCatalog(query: WordQuery = {}) {
  const enabled = BACKEND;
  const q = useQuery({
    queryKey: queryKeys.vocabulary.words({ ...query, catalog: true }),
    queryFn: () => searchWordsPaged({ ...query, perPage: 200 }),
    enabled,
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });

  const words: DictWord[] = enabled ? (q.data?.items ?? []) : ALL_WORDS;
  return {
    words,
    total: enabled ? (q.data?.totalItems ?? 0) : ALL_WORDS.length,
    isLoading: enabled ? q.isLoading : false,
    error: enabled ? q.error : null,
  };
}

export function useProverbs() {
  const q = useQuery({
    queryKey: queryKeys.vocabulary.proverbs(),
    queryFn: listProverbs,
    enabled: BACKEND,
    staleTime: 5 * 60_000,
  });
  return {
    proverbs: BACKEND ? (q.data ?? PROVERBS) : PROVERBS,
    isLoading: BACKEND ? q.isLoading : false,
  };
}

export function useVerbs() {
  return useQuery({
    queryKey: queryKeys.vocabulary.verbs(),
    queryFn: listVerbs,
    enabled: BACKEND,
    staleTime: 5 * 60_000,
  });
}

export function useWordFamilies() {
  const q = useQuery({
    queryKey: queryKeys.vocabulary.families(),
    queryFn: listWordFamilies,
    enabled: BACKEND,
    staleTime: 5 * 60_000,
  });
  return {
    families: BACKEND ? (q.data ?? WORD_ROOTS) : WORD_ROOTS,
    isLoading: BACKEND ? q.isLoading : false,
  };
}
