/**
 * دامنهٔ آزمون‌ها (Exams) — سشن ۶.
 *
 * - محتوای آزمون (بخش‌ها و سؤال‌ها): در MOCK از `mockModelltests.ts`،
 *   با بک‌اند از کالکشن `exam_sections` (با fallback به mock اگر seed اجرا نشده).
 * - تلاش‌ها و پاسخ‌ها: همیشه ابتدا محلی (localStorage) نوشته می‌شوند تا
 *   رفرش/قطع شبکه چیزی از بین نبرد؛ با بک‌اند از صف آفلاین برای همگام‌سازی
 *   استفاده می‌شود.
 * - کامپوننت‌ها هرگز مستقیم PocketBase صدا نمی‌زنند؛ فقط این ماژول.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import type { AnswerRecord, ExamAttemptRecord, ExamRecord, ExamSectionRecord } from "./types";
import {
  getModelltest,
  getModelltestSection,
  type ExamQuestion,
  type ModelltestSection,
} from "@/lib/deusi/exams/mockModelltests";
import { EXAMS, getExam, type Exam } from "@/lib/deusi/exams/mockExams";
import {
  gradeAnswer,
  levelFromPercent,
  percentOf,
  totalMaxPoints,
  type Cefr,
} from "@/lib/deusi/examScoring";

export const LS_ATTEMPTS = "deusi.exams.attempts.v1";
export const LS_ANSWERS = "deusi.exams.answers.v1";

export type AttemptStatus = "in-progress" | "submitted" | "scored" | "abandoned";

export interface ExamAttempt {
  id: string;
  /** شناسهٔ رکورد سرور، اگر روی PocketBase ساخته شده باشد. */
  remoteId?: string;
  userId: string;
  examId: string;
  sectionId: string;
  skill: string;
  status: AttemptStatus;
  startedAt: string;
  deadlineAt: string;
  submittedAt?: string;
  score: number;
  maxScore: number;
  resultLevel: Cefr | "";
  sectionScores: Record<string, number>;
}

export interface ExamAnswer {
  questionId: string;
  value: unknown;
  correct: boolean;
  points: number;
  manual: boolean;
  answeredAt: string;
}

type AnswerMap = Record<string, Record<string, ExamAnswer>>;

/* -------------------------------------------------------------------------- */
/* ذخیرهٔ محلی                                                                  */
/* -------------------------------------------------------------------------- */

function readAttempts(): ExamAttempt[] {
  return readLocal<ExamAttempt[]>(LS_ATTEMPTS, []);
}

function writeAttempts(list: ExamAttempt[]) {
  writeLocal(LS_ATTEMPTS, list);
}

function readAnswerMap(): AnswerMap {
  return readLocal<AnswerMap>(LS_ANSWERS, {});
}

function writeAnswerMap(map: AnswerMap) {
  writeLocal(LS_ANSWERS, map);
}

function upsertAttemptLocal(attempt: ExamAttempt): ExamAttempt {
  const list = readAttempts();
  const idx = list.findIndex((a) => a.id === attempt.id);
  if (idx >= 0) list[idx] = attempt;
  else list.unshift(attempt);
  writeAttempts(list);
  return attempt;
}

function newId(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

/* -------------------------------------------------------------------------- */
/* محتوای آزمون                                                                 */
/* -------------------------------------------------------------------------- */

function sectionFromRecord(rec: ExamSectionRecord, examId: string): ModelltestSection {
  return {
    id: rec.id,
    examId: examId as ModelltestSection["examId"],
    skill: rec.skill,
    title: rec.title,
    intro: "",
    durationMin: rec.duration_min || 15,
    maxPoints: rec.max_points || 0,
    order: rec.order ?? 0,
    questions: (rec.questions ?? []) as ExamQuestion[],
  };
}

/** بخش‌های Modelltest یک آزمون. */
export async function listSections(examId: string): Promise<ModelltestSection[]> {
  const fallback = getModelltest(examId)?.sections ?? [];
  if (!BACKEND) return fallback;
  const pb = getPb();
  try {
    const rows = await pbRequest((signal) =>
      pb.collection("exam_sections").getFullList<ExamSectionRecord>({
        filter: `exam.slug = "${escapeFilter(examId)}"`,
        sort: "order",
        signal,
      }),
    );
    if (!rows.length) return fallback;
    return rows.map((r) => sectionFromRecord(r, examId));
  } catch {
    return fallback;
  }
}

/** یک بخش مشخص (سرور یا mock). */
export async function getSection(
  examId: string,
  sectionId: string,
): Promise<ModelltestSection | null> {
  const sections = await listSections(examId);
  return sections.find((s) => s.id === sectionId) ?? getModelltestSection(sectionId) ?? null;
}

/* -------------------------------------------------------------------------- */
/* تلاش‌ها                                                                      */
/* -------------------------------------------------------------------------- */

/** شروع یک تلاش جدید روی یک بخش. */
export async function startAttempt(input: {
  userId: string;
  examId: string;
  section: ModelltestSection;
}): Promise<ExamAttempt> {
  const { userId, examId, section } = input;
  const startedAt = new Date();
  const deadline = new Date(startedAt.getTime() + section.durationMin * 60_000);

  const attempt: ExamAttempt = {
    id: newId("att"),
    userId,
    examId,
    sectionId: section.id,
    skill: section.skill,
    status: "in-progress",
    startedAt: startedAt.toISOString(),
    deadlineAt: deadline.toISOString(),
    score: 0,
    maxScore: totalMaxPoints(section),
    resultLevel: "",
    sectionScores: {},
  };

  if (BACKEND && userId) {
    try {
      const pb = getPb();
      const created = await pbRequest((signal) =>
        pb.collection("exam_attempts").create<ExamAttemptRecord>(
          {
            user: userId,
            status: "in-progress",
            started_at: attempt.startedAt,
            deadline_at: attempt.deadlineAt,
            seconds_remaining: section.durationMin * 60,
            max_score: attempt.maxScore,
            section_scores: {},
          },
          { signal },
        ),
      );
      attempt.remoteId = created.id;
    } catch (err) {
      console.warn("exam attempt: offline start", err);
    }
  }

  return upsertAttemptLocal(attempt);
}

/** یک تلاش بر اساس شناسهٔ محلی. */
export function getAttempt(attemptId: string): ExamAttempt | null {
  return readAttempts().find((a) => a.id === attemptId) ?? null;
}

/** آخرین تلاش «در حال انجام» روی یک بخش (برای ادامه بعد از رفرش). */
export function findOpenAttempt(userId: string, sectionId: string): ExamAttempt | null {
  return (
    readAttempts().find(
      (a) => a.sectionId === sectionId && a.userId === userId && a.status === "in-progress",
    ) ?? null
  );
}

/** فهرست تلاش‌های کاربر (اختیاری: فقط یک آزمون). */
export async function listAttempts(userId: string, examId?: string): Promise<ExamAttempt[]> {
  const local = readAttempts()
    .filter((a) => (!userId || a.userId === userId) && (!examId || a.examId === examId))
    .sort((a, b) => (a.startedAt < b.startedAt ? 1 : -1));
  return local;
}

/** پاسخ‌های ثبت‌شدهٔ یک تلاش. */
export function listAnswers(attemptId: string): Record<string, ExamAnswer> {
  return readAnswerMap()[attemptId] ?? {};
}

/** ذخیرهٔ تدریجی یک پاسخ (نمره‌دهی خودکار در همان لحظه). */
export async function saveAnswer(
  attempt: ExamAttempt,
  question: ExamQuestion,
  value: unknown,
): Promise<ExamAnswer> {
  const graded = gradeAnswer(question, value);
  const answer: ExamAnswer = {
    questionId: question.id,
    value,
    correct: graded.correct,
    points: graded.points,
    manual: graded.manual,
    answeredAt: new Date().toISOString(),
  };

  const map = readAnswerMap();
  map[attempt.id] = { ...(map[attempt.id] ?? {}), [question.id]: answer };
  writeAnswerMap(map);

  if (BACKEND && attempt.remoteId && attempt.userId) {
    await enqueue(
      "exam.answer.upsert",
      { userId: attempt.userId, attemptId: attempt.remoteId, answer },
      `exam.answer:${attempt.remoteId}:${question.id}`,
    );
  }
  return answer;
}

/** به‌روزرسانی زمان باقی‌مانده روی سرور (heartbeat سبک). */
export async function heartbeat(attempt: ExamAttempt, secondsRemaining: number): Promise<void> {
  if (!BACKEND || !attempt.remoteId) return;
  await enqueue(
    "exam.attempt.heartbeat",
    { attemptId: attempt.remoteId, secondsRemaining: Math.max(0, Math.round(secondsRemaining)) },
    `exam.attempt.heartbeat:${attempt.remoteId}`,
  );
}

/** جمع نمرهٔ بخش‌های دیگر همان آزمون (آخرین تلاش هر بخش). */
function collectSectionScores(userId: string, examId: string, current: ExamAttempt) {
  const scores: Record<string, number> = {};
  const finished = readAttempts().filter(
    (a) =>
      a.userId === userId &&
      a.examId === examId &&
      a.id !== current.id &&
      (a.status === "submitted" || a.status === "scored"),
  );
  for (const a of finished) {
    if (scores[a.skill] === undefined) scores[a.skill] = percentOf(a.score, a.maxScore);
  }
  scores[current.skill] = percentOf(current.score, current.maxScore);
  return scores;
}

/** تحویل آزمون: نمره‌دهی، ذخیره و محاسبهٔ سطح پیشنهادی. */
export async function submitAttempt(
  attemptId: string,
  section: ModelltestSection,
): Promise<ExamAttempt> {
  const attempt = getAttempt(attemptId);
  if (!attempt) throw new Error("Versuch nicht gefunden");

  const answers = listAnswers(attemptId);
  // نمره‌دهی مجدد همهٔ پاسخ‌ها تا مطمئن شویم چیزی جا نمانده.
  const map = readAnswerMap();
  const forAttempt: Record<string, ExamAnswer> = { ...answers };
  for (const q of section.questions) {
    const existing = forAttempt[q.id];
    if (!existing) continue;
    if (existing.manual) continue; // نمرهٔ دستی دست‌نخورده می‌ماند
    const graded = gradeAnswer(q, existing.value);
    forAttempt[q.id] = { ...existing, correct: graded.correct, points: graded.points };
  }
  map[attemptId] = forAttempt;
  writeAnswerMap(map);

  const score = Object.values(forAttempt).reduce((s, a) => s + (a.points || 0), 0);
  const maxScore = totalMaxPoints(section);
  const exam = getExam(section.examId);
  const target = getModelltest(section.examId)?.level ?? exam?.recommendedLevel ?? "B1";

  const next: ExamAttempt = {
    ...attempt,
    status: "scored",
    submittedAt: new Date().toISOString(),
    score: Math.round(score * 100) / 100,
    maxScore,
    resultLevel: levelFromPercent(percentOf(score, maxScore), target),
    sectionScores: {},
  };
  next.sectionScores = collectSectionScores(attempt.userId, attempt.examId, next);
  upsertAttemptLocal(next);

  if (BACKEND && next.remoteId) {
    await enqueue(
      "exam.attempt.submit",
      { attempt: next, answers: Object.values(forAttempt) },
      `exam.attempt.submit:${next.remoteId}`,
    );
  }
  return next;
}

/** خودارزیابی پاسخ‌های آزاد؛ نمرهٔ تلاش دوباره محاسبه می‌شود. */
export async function rateManualAnswer(
  attemptId: string,
  section: ModelltestSection,
  questionId: string,
  points: number,
): Promise<ExamAttempt> {
  const map = readAnswerMap();
  const forAttempt = { ...(map[attemptId] ?? {}) };
  const question = section.questions.find((q) => q.id === questionId);
  if (!question) throw new Error("Frage nicht gefunden");
  const clamped = Math.max(0, Math.min(question.points, points));
  const prev = forAttempt[questionId];
  forAttempt[questionId] = {
    questionId,
    value: prev?.value ?? "",
    manual: true,
    correct: clamped >= question.points,
    points: clamped,
    answeredAt: prev?.answeredAt ?? new Date().toISOString(),
  };
  map[attemptId] = forAttempt;
  writeAnswerMap(map);

  const attempt = getAttempt(attemptId);
  if (!attempt) throw new Error("Versuch nicht gefunden");
  const score = Object.values(forAttempt).reduce((s, a) => s + (a.points || 0), 0);
  const maxScore = totalMaxPoints(section);
  const target = getModelltest(section.examId)?.level ?? "B1";
  const next: ExamAttempt = {
    ...attempt,
    score: Math.round(score * 100) / 100,
    maxScore,
    resultLevel: levelFromPercent(percentOf(score, maxScore), target),
  };
  next.sectionScores = collectSectionScores(attempt.userId, attempt.examId, next);
  upsertAttemptLocal(next);

  if (BACKEND && next.remoteId) {
    await enqueue(
      "exam.attempt.submit",
      { attempt: next, answers: Object.values(forAttempt) },
      `exam.attempt.submit:${next.remoteId}`,
    );
  }
  return next;
}

/* -------------------------------------------------------------------------- */
/* هندلرهای صف آفلاین                                                           */
/* -------------------------------------------------------------------------- */

async function findAnswerRecord(attemptId: string, questionId: string) {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("answers")
        .getFirstListItem<AnswerRecord>(
          `attempt = "${escapeFilter(attemptId)}" && question_id = "${escapeFilter(questionId)}"`,
          { signal },
        ),
    );
  } catch {
    return null;
  }
}

registerHandler("exam.answer.upsert", async (payload) => {
  const { userId, attemptId, answer } = payload as {
    userId: string;
    attemptId: string;
    answer: ExamAnswer;
  };
  if (!BACKEND || !attemptId) return;
  const pb = getPb();
  const data = {
    user: userId,
    attempt: attemptId,
    question_id: answer.questionId,
    value: answer.value ?? null,
    correct: answer.correct,
    points: answer.points,
    answered_at: answer.answeredAt,
  };
  const existing = await findAnswerRecord(attemptId, answer.questionId);
  if (existing) {
    await pbRequest((signal) => pb.collection("answers").update(existing.id, data, { signal }));
  } else {
    await pbRequest((signal) => pb.collection("answers").create(data, { signal }));
  }
});

registerHandler("exam.attempt.heartbeat", async (payload) => {
  const { attemptId, secondsRemaining } = payload as {
    attemptId: string;
    secondsRemaining: number;
  };
  if (!BACKEND || !attemptId) return;
  const pb = getPb();
  await pbRequest((signal) =>
    pb
      .collection("exam_attempts")
      .update(attemptId, { seconds_remaining: secondsRemaining }, { signal }),
  );
});

registerHandler("exam.attempt.submit", async (payload) => {
  const { attempt, answers } = payload as { attempt: ExamAttempt; answers: ExamAnswer[] };
  if (!BACKEND || !attempt.remoteId) return;
  const pb = getPb();
  for (const answer of answers) {
    const data = {
      user: attempt.userId,
      attempt: attempt.remoteId,
      question_id: answer.questionId,
      value: answer.value ?? null,
      correct: answer.correct,
      points: answer.points,
      answered_at: answer.answeredAt,
    };
    const existing = await findAnswerRecord(attempt.remoteId, answer.questionId);
    if (existing) {
      await pbRequest((signal) => pb.collection("answers").update(existing.id, data, { signal }));
    } else {
      await pbRequest((signal) => pb.collection("answers").create(data, { signal }));
    }
  }
  await pbRequest((signal) =>
    pb.collection("exam_attempts").update(
      attempt.remoteId as string,
      {
        status: "scored",
        submitted_at: attempt.submittedAt ?? new Date().toISOString(),
        seconds_remaining: 0,
        score: attempt.score,
        max_score: attempt.maxScore,
        result_level: attempt.resultLevel || undefined,
        section_scores: attempt.sectionScores,
      },
      { signal },
    ),
  );
});

/* -------------------------------------------------------------------------- */
/* کاتالوگ آزمون‌ها (سشن ۶ — تکمیل)                                             */
/* -------------------------------------------------------------------------- */

/**
 * کاتالوگ آزمون‌ها.
 *
 * محتوای قابل‌ویرایش (نام، توضیح، منابع، کتاب‌ها، مراکز، FAQ، برنامه) از
 * کالکشن `exams` می‌آید و روی دادهٔ mock (که فیلدهای صرفاً بصری مثل لوگو و
 * گرادیان را دارد) سوار می‌شود. اگر بک‌اند/seed در دسترس نباشد، همان mock.
 */
function mergeExam(base: Exam, rec: Partial<ExamRecord>): Exam {
  const arr = <T>(v: unknown, fallback: T[]): T[] =>
    Array.isArray(v) && v.length ? (v as T[]) : fallback;
  return {
    ...base,
    name: rec.name || base.name,
    shortName: rec.short_name || base.shortName,
    description: rec.description || base.description,
    accent: rec.accent || base.accent,
    levels: arr(rec.levels, base.levels),
    purpose: arr(rec.purposes, base.purpose) as Exam["purpose"],
    resources: arr(rec.resources, base.resources) as Exam["resources"],
    practice: arr(rec.practice_files, base.practice) as Exam["practice"],
    books: arr(rec.books, base.books) as Exam["books"],
    centers: arr(rec.centers, base.centers) as Exam["centers"],
    faq: arr(rec.faq, base.faq) as Exam["faq"],
    prepPlan: arr(rec.prep_plan, base.prepPlan) as Exam["prepPlan"],
    comparison: (rec.comparison as unknown as Exam["comparison"]) ?? base.comparison,
  };
}

/** همهٔ آزمون‌های منتشرشده. */
export async function listExamCatalog(): Promise<Exam[]> {
  if (!BACKEND) return EXAMS;
  try {
    const pb = getPb();
    const rows = await pbRequest((signal) =>
      pb.collection("exams").getFullList<ExamRecord>({
        filter: "published = true",
        sort: "slug",
        signal,
      }),
    );
    if (!rows.length) return EXAMS;
    const bySlug = new Map(rows.map((r) => [r.slug, r]));
    const merged = EXAMS.filter((e) => bySlug.has(e.id)).map((e) =>
      mergeExam(e, bySlug.get(e.id) as ExamRecord),
    );
    return merged.length ? merged : EXAMS;
  } catch {
    return EXAMS;
  }
}

/** یک آزمون بر اساس slug. */
export async function getExamCatalogEntry(slug: string): Promise<Exam | null> {
  const list = await listExamCatalog();
  return list.find((e) => e.id === slug) ?? getExam(slug) ?? null;
}

/** آمار خلاصهٔ صفحهٔ فهرست، از روی دادهٔ واقعی. */
export function examStatsOf(list: Exam[]) {
  return {
    totalExams: list.length,
    totalPractice: list.reduce((s, e) => s + e.practice.length, 0),
    totalBooks: list.reduce((s, e) => s + e.books.length, 0),
    totalCenters: new Set(list.flatMap((e) => e.centers.map((c) => c.id))).size,
    totalResources: list.reduce((s, e) => s + e.resources.length, 0),
    totalExperiences: list.reduce((s, e) => s + e.experiences.length, 0),
  };
}
