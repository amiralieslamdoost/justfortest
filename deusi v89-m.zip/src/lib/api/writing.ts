/**
 * لایهٔ دادهٔ نوشتن / Schreiben-Datenschicht (writing_submissions).
 * در حالت MOCK همان کلید پیش‌نویس قبلی (`deusi:schreiben:drafts`) استفاده می‌شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import type { WritingSubmissionRecord } from "./types";

/** کلید قدیمی: نگاشت promptId → متن. */
export const LS_DRAFTS = "deusi:schreiben:drafts";
const LS_SUBMISSIONS = "deusi.writing.submissions.v1";
const LS_WRITING_MIGRATED = "deusi.writing.migrated.v1";

export type WritingStatus = "draft" | "submitted" | "reviewed";

export interface WritingEntry {
  promptId: string;
  title: string;
  body: string;
  level: string;
  taskType: "email" | "essay" | "letter" | "description" | "free";
  wordCount: number;
  status: WritingStatus;
  score: number;
  feedback: Record<string, unknown> | null;
  updatedAt: string;
  submittedAt?: string;
}

export type WritingMap = Record<string, WritingEntry>;

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

export function readLocalDrafts(): Record<string, string> {
  return readLocal<Record<string, string>>(LS_DRAFTS, {});
}

function writeLocalDrafts(map: Record<string, string>) {
  writeLocal(LS_DRAFTS, map);
}

function readLocalEntries(): WritingMap {
  return readLocal<WritingMap>(LS_SUBMISSIONS, {});
}

function writeLocalEntries(map: WritingMap) {
  writeLocal(LS_SUBMISSIONS, map);
}

function recordToEntry(r: WritingSubmissionRecord): WritingEntry {
  return {
    promptId: r.prompt_id,
    title: r.title,
    body: r.body,
    level: r.level,
    taskType: r.task_type,
    wordCount: r.word_count ?? 0,
    status: r.status ?? "draft",
    score: r.score ?? 0,
    feedback: (r.ai_feedback ?? null) as Record<string, unknown> | null,
    updatedAt: r.updated,
    submittedAt: r.submitted_at || undefined,
  };
}

/** همهٔ نوشته‌های کاربر (کلید = promptId). */
export async function listWritingSubmissions(userId: string): Promise<WritingMap> {
  const local = readLocalEntries();
  if (!BACKEND || !userId) return local;
  const pb = getPb();
  try {
    const rows = await pbRequest((signal) =>
      pb.collection("writing_submissions").getFullList<WritingSubmissionRecord>({
        filter: `user = "${escapeFilter(userId)}"`,
        sort: "-updated",
        signal,
      }),
    );
    const map: WritingMap = { ...local };
    for (const r of rows) map[r.prompt_id] = recordToEntry(r);
    writeLocalEntries(map);
    // کلید قدیمی هم به‌روز بماند تا رفتار فعلی صفحه حفظ شود
    const drafts = readLocalDrafts();
    for (const [promptId, entry] of Object.entries(map)) drafts[promptId] = entry.body;
    writeLocalDrafts(drafts);
    return map;
  } catch (err) {
    if (toApiError(err).kind === "auth") return local;
    return local;
  }
}

/** ذخیرهٔ پیش‌نویس (خوش‌بینانه + صف آفلاین). */
export async function saveWriting(
  userId: string,
  entry: Omit<WritingEntry, "updatedAt"> & { updatedAt?: string },
): Promise<WritingEntry> {
  const next: WritingEntry = { ...entry, updatedAt: new Date().toISOString() };
  const map = readLocalEntries();
  writeLocalEntries({ ...map, [next.promptId]: next });
  const drafts = readLocalDrafts();
  drafts[next.promptId] = next.body;
  writeLocalDrafts(drafts);

  if (BACKEND && userId) {
    await enqueue(
      "writing.submission.upsert",
      { userId, entry: next },
      `writing.submission:${userId}:${next.promptId}`,
    );
  }
  return next;
}

/** ثبت نهایی نوشته. */
export async function submitWriting(
  userId: string,
  entry: Omit<WritingEntry, "updatedAt" | "status" | "submittedAt">,
): Promise<WritingEntry> {
  return saveWriting(userId, {
    ...entry,
    status: "submitted",
    submittedAt: new Date().toISOString(),
  });
}

async function findSubmission(userId: string, promptId: string) {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("writing_submissions")
        .getFirstListItem<WritingSubmissionRecord>(
          `user = "${escapeFilter(userId)}" && prompt_id = "${escapeFilter(promptId)}"`,
          { signal },
        ),
    );
  } catch (err) {
    if (toApiError(err).kind === "notFound") return null;
    throw err;
  }
}

registerHandler("writing.submission.upsert", async (payload) => {
  const { userId, entry } = payload as { userId: string; entry: WritingEntry };
  if (!BACKEND || !userId) return;
  const pb = getPb();
  const existing = await findSubmission(userId, entry.promptId);
  const data = {
    user: userId,
    prompt_id: entry.promptId,
    title: entry.title,
    body: entry.body,
    level: entry.level,
    task_type: entry.taskType,
    word_count: entry.wordCount,
    status: entry.status,
    ai_feedback: entry.feedback ?? null,
    score: entry.score,
    submitted_at: entry.submittedAt ?? "",
  };
  if (existing) {
    await pbRequest((signal) =>
      pb.collection("writing_submissions").update(existing.id, data, { signal }),
    );
  } else {
    await pbRequest((signal) => pb.collection("writing_submissions").create(data, { signal }));
  }
});

/** انتقال یک‌بارهٔ پیش‌نویس‌های localStorage به سرور. */
export async function migrateLocalWriting(userId: string): Promise<void> {
  if (!BACKEND || !userId) return;
  const flags = readLocal<Record<string, boolean>>(LS_WRITING_MIGRATED, {});
  if (flags[userId]) return;
  writeLocal(LS_WRITING_MIGRATED, { ...flags, [userId]: true });
  const entries = readLocalEntries();
  for (const [promptId, body] of Object.entries(readLocalDrafts())) {
    if (!body?.trim()) continue;
    const entry: WritingEntry =
      entries[promptId] ??
      ({
        promptId,
        title: promptId,
        body,
        level: "B1",
        taskType: "free",
        wordCount: body.trim().split(/\s+/).length,
        status: "draft",
        score: 0,
        feedback: null,
        updatedAt: new Date().toISOString(),
      } satisfies WritingEntry);
    await enqueue(
      "writing.submission.upsert",
      { userId, entry: { ...entry, body } },
      `writing.submission:${userId}:${promptId}`,
    );
  }
}
