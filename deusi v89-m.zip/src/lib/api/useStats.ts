/**
 * هوک آمار یادگیری (سشن ۹).
 * `days` را از بک‌اند می‌خواند و همان توابع کمکی mock (moduleBreakdown،
 * studyHeatmap، monthlyTotals) روی آن کار می‌کنند.
 */
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import { useCurrentUserId } from "./useExams";
import { loadStudyDays, loadWeekXp, totalsOf } from "./stats";
import { sliceDays, type StudyDay } from "@/lib/deusi/mockStudyStats";

/** آمار روزانهٔ کاربر جاری (۳۶۵ روز) + برش‌گیری محلی. */
export function useStudyStats(days = 365) {
  const userId = useCurrentUserId();
  const fallback = useMemo(() => sliceDays(days), [days]);
  const q = useQuery({
    queryKey: queryKeys.stats.days(userId, days),
    queryFn: () => loadStudyDays(userId, days),
    staleTime: 60_000,
    initialData: fallback,
  });

  const allDays = (q.data ?? fallback) as StudyDay[];
  const slice = (n: number) => allDays.slice(-Math.min(n, allDays.length));
  const totals = useMemo(() => totalsOf(allDays), [allDays]);

  return { days: allDays, slice, totals, isLoading: q.isLoading, userId };
}

/** XP روزهای هفتهٔ جاری (خالی = استفاده از مقدار پیش‌فرض کارت). */
export function useWeekXp() {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: [...queryKeys.stats.all, "weekXp", userId],
    queryFn: () => loadWeekXp(userId),
    staleTime: 60_000,
  });
  return { weekXp: q.data ?? [], isLoading: q.isLoading };
}
