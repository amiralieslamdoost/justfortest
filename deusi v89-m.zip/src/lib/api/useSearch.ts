/**
 * هوک جست‌وجوی سراسری (سشن ۹).
 * از فیلتر دامنه و صفحه‌بندی سمت سرور پشتیبانی می‌کند.
 * اگر بک‌اند فعال نباشد `hits === null` می‌ماند و صفحه از دیتای محلی
 * استفاده می‌کند.
 */
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import { globalSearch, type SearchHit, type SearchKind } from "./search";
import { BACKEND } from "./config";

export function useGlobalSearch(query: string, kind: SearchKind | "alle" = "alle", page = 1) {
  const q = query.trim();
  const res = useQuery({
    queryKey: [...queryKeys.search.global(q), kind, page],
    queryFn: () => globalSearch(q, { kind, page }),
    enabled: BACKEND && q.length >= 2,
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });
  return {
    hits: (res.data?.items ?? null) as SearchHit[] | null,
    totalByKind: res.data?.totalByKind ?? null,
    hasMore: res.data?.hasMore ?? false,
    isLoading: res.isFetching,
  };
}
