/**
 * لایهٔ دادهٔ خواندن / Lesen-Datenschicht.
 *
 * دامنه‌ها: lesen و lesen_.$articleId.
 * در حالت MOCK دقیقاً `mockReading.ts` + همان کلید localStorage قبلی.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import type { ArticleRecord, ReadingProgressRecord } from "./types";
import {
  articles as MOCK_ARTICLES,
  type Article,
  type CEFR,
  type ReadingCategory,
} from "@/lib/deusi/mockReading";

/** همان کلید صفحهٔ فعلی تا رفتار MOCK تغییر نکند. */
export const LS_ARTICLE_STATE = "deusi:lesen:state:v1";
const LS_ARTICLES_CACHE = "deusi.reading.articles.cache.v1";
const LS_READING_MIGRATED = "deusi.reading.migrated.v1";

export interface ArticleState {
  progress: number; // 0..100
  bookmarked: boolean;
  savedWords: string[];
  lastReadAt?: string;
  timeSpent?: number;
  scrollPosition?: number;
  finished?: boolean;
  questionAnswers?: Record<string, unknown>;
  quizScore?: number;
}

export type ArticleStateMap = Record<string, ArticleState>;

export interface ArticleQuery {
  q?: string;
  category?: ReadingCategory | "alle" | "fuerdich";
  level?: CEFR | "alle";
  page?: number;
  perPage?: number;
}

export interface Paged<T> {
  items: T[];
  page: number;
  perPage: number;
  totalItems: number;
  totalPages: number;
}

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

/* -------------------------------------------------------------------------- */
/* نگاشت رکورد ↔ مدل UI                                                        */
/* -------------------------------------------------------------------------- */

export function articleRecordToArticle(r: ArticleRecord): Article {
  return {
    id: r.slug || r.id,
    title: r.title,
    slug: r.slug || r.id,
    description: r.description,
    category: r.category as Article["category"],
    level: r.level as CEFR,
    minutes: r.minutes,
    words: r.words,
    cover: r.cover,
    author: r.author,
    publishedAt: r.published_at || r.created,
    progress: 0,
    bookmarked: false,
    favorite: false,
    content: (r.content ?? []) as Article["content"],
    vocab: (r.vocab ?? []) as unknown as Article["vocab"],
    questions: (r.questions ?? []) as unknown as Article["questions"],
    aiSummary: r.ai_summary ?? "",
    grammarNotes: (r.grammar_notes ?? []) as Article["grammarNotes"],
  };
}

function matchesLocally(a: Article, query: ArticleQuery): boolean {
  const q = (query.q ?? "").trim().toLowerCase();
  if (query.category && query.category !== "alle" && query.category !== "fuerdich") {
    if (a.category !== query.category) return false;
  }
  if (query.level && query.level !== "alle" && a.level !== query.level) return false;
  if (!q) return true;
  return (
    a.title.toLowerCase().includes(q) ||
    a.description.toLowerCase().includes(q) ||
    a.category.toLowerCase().includes(q)
  );
}

/* -------------------------------------------------------------------------- */
/* مقاله‌ها                                                                    */
/* -------------------------------------------------------------------------- */

/** فهرست مقاله‌ها با فیلتر و صفحه‌بندی سمت سرور (در MOCK محلی). */
export async function searchArticlesPaged(query: ArticleQuery = {}): Promise<Paged<Article>> {
  const page = Math.max(1, query.page ?? 1);
  const perPage = Math.min(100, Math.max(1, query.perPage ?? 24));

  if (!BACKEND) {
    const all = MOCK_ARTICLES.filter((a) => matchesLocally(a, query));
    const start = (page - 1) * perPage;
    return {
      items: all.slice(start, start + perPage),
      page,
      perPage,
      totalItems: all.length,
      totalPages: Math.max(1, Math.ceil(all.length / perPage)),
    };
  }

  const filters: string[] = ["published = true"];
  const q = escapeFilter((query.q ?? "").trim());
  if (q) filters.push(`(title ~ "${q}" || description ~ "${q}")`);
  if (query.category && query.category !== "alle" && query.category !== "fuerdich") {
    filters.push(`category = "${escapeFilter(query.category)}"`);
  }
  if (query.level && query.level !== "alle") filters.push(`level = "${escapeFilter(query.level)}"`);

  const pb = getPb();
  try {
    const res = await pbRequest((signal) =>
      pb.collection("articles").getList<ArticleRecord>(page, perPage, {
        filter: filters.join(" && "),
        sort: "-published_at",
        signal,
      }),
    );
    const items = res.items.map(articleRecordToArticle);
    if (page === 1) writeLocal(LS_ARTICLES_CACHE, items);
    return {
      items,
      page: res.page,
      perPage: res.perPage,
      totalItems: res.totalItems,
      totalPages: res.totalPages,
    };
  } catch (err) {
    const cached = readLocal<Article[] | null>(LS_ARTICLES_CACHE, null);
    const source = cached?.length ? cached : MOCK_ARTICLES;
    if (toApiError(err).kind === "auth") throw err;
    const all = source.filter((a) => matchesLocally(a, query));
    const start = (page - 1) * perPage;
    return {
      items: all.slice(start, start + perPage),
      page,
      perPage,
      totalItems: all.length,
      totalPages: Math.max(1, Math.ceil(all.length / perPage)),
    };
  }
}

/** یک مقاله بر اساس slug یا شناسه. */
export async function getArticleBySlug(idOrSlug: string): Promise<Article | null> {
  if (!idOrSlug) return null;
  const local = MOCK_ARTICLES.find((a) => a.id === idOrSlug || a.slug === idOrSlug) ?? null;
  if (!BACKEND) return local;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("articles")
        .getFirstListItem<ArticleRecord>(
          `slug = "${escapeFilter(idOrSlug)}" || id = "${escapeFilter(idOrSlug)}"`,
          { signal },
        ),
    );
    return articleRecordToArticle(rec);
  } catch {
    return local;
  }
}

/* -------------------------------------------------------------------------- */
/* پیشرفت خواندن (reading_progress)                                            */
/* -------------------------------------------------------------------------- */

export function readLocalArticleStates(): ArticleStateMap {
  return readLocal<ArticleStateMap>(LS_ARTICLE_STATE, {});
}

function writeLocalArticleStates(map: ArticleStateMap) {
  writeLocal(LS_ARTICLE_STATE, map);
}

export async function listReadingProgress(userId: string): Promise<ArticleStateMap> {
  if (!BACKEND || !userId) return readLocalArticleStates();
  const pb = getPb();
  try {
    const rows = await pbRequest((signal) =>
      pb
        .collection("reading_progress")
        .getFullList<ReadingProgressRecord & { expand?: { article?: ArticleRecord } }>({
          filter: `user = "${escapeFilter(userId)}"`,
          expand: "article",
          signal,
        }),
    );
    const local = readLocalArticleStates();
    const map: ArticleStateMap = { ...local };
    for (const r of rows) {
      const key = r.expand?.article?.slug ?? (r.article as string);
      map[key] = {
        ...(local[key] ?? { bookmarked: false, savedWords: [] }),
        progress: r.progress ?? 0,
        scrollPosition: r.scroll_position ?? 0,
        finished: r.finished ?? false,
        questionAnswers: (r.question_answers ?? {}) as Record<string, unknown>,
        quizScore: r.quiz_score ?? 0,
        lastReadAt: r.last_read_at || undefined,
        bookmarked: local[key]?.bookmarked ?? false,
        savedWords: local[key]?.savedWords ?? [],
      };
    }
    writeLocalArticleStates(map);
    return map;
  } catch {
    return readLocalArticleStates();
  }
}

/** ذخیرهٔ خوش‌بینانهٔ پیشرفت یک مقاله + صف آفلاین. */
export async function saveReadingProgress(
  userId: string,
  articleId: string,
  patch: Partial<ArticleState>,
): Promise<ArticleState> {
  const map = readLocalArticleStates();
  const prev = map[articleId] ?? { progress: 0, bookmarked: false, savedWords: [] };
  const next: ArticleState = {
    ...prev,
    ...patch,
    questionAnswers: { ...(prev.questionAnswers ?? {}), ...(patch.questionAnswers ?? {}) },
    lastReadAt: new Date().toISOString(),
  };
  writeLocalArticleStates({ ...map, [articleId]: next });

  if (BACKEND && userId) {
    await enqueue(
      "reading.progress.upsert",
      { userId, articleId, state: next },
      `reading.progress:${userId}:${articleId}`,
    );
  }
  return next;
}

/* -------------------------------------------------------------------------- */
/* هندلر صف آفلاین                                                             */
/* -------------------------------------------------------------------------- */

async function resolveArticleRecordId(slug: string): Promise<string | null> {
  if (!BACKEND || !slug) return null;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("articles")
        .getFirstListItem<ArticleRecord>(
          `slug = "${escapeFilter(slug)}" || id = "${escapeFilter(slug)}"`,
          { signal },
        ),
    );
    return rec.id;
  } catch {
    return null;
  }
}

async function findReadingProgress(userId: string, articleRecordId: string) {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("reading_progress")
        .getFirstListItem<ReadingProgressRecord>(
          `user = "${escapeFilter(userId)}" && article = "${escapeFilter(articleRecordId)}"`,
          { signal },
        ),
    );
  } catch (err) {
    if (toApiError(err).kind === "notFound") return null;
    throw err;
  }
}

registerHandler("reading.progress.upsert", async (payload) => {
  const { userId, articleId, state } = payload as {
    userId: string;
    articleId: string;
    state: ArticleState;
  };
  if (!BACKEND || !userId) return;
  const articleRecordId = await resolveArticleRecordId(articleId);
  if (!articleRecordId) return; // seed هنوز اجرا نشده
  const pb = getPb();
  const existing = await findReadingProgress(userId, articleRecordId);
  const data = {
    user: userId,
    article: articleRecordId,
    progress: Math.round(state.progress ?? 0),
    scroll_position: Math.round(state.scrollPosition ?? 0),
    finished: state.finished ?? (state.progress ?? 0) >= 100,
    question_answers: state.questionAnswers ?? {},
    quiz_score: state.quizScore ?? 0,
    last_read_at: state.lastReadAt ?? new Date().toISOString(),
  };
  if (existing) {
    await pbRequest((signal) =>
      pb.collection("reading_progress").update(existing.id, data, { signal }),
    );
  } else {
    await pbRequest((signal) => pb.collection("reading_progress").create(data, { signal }));
  }
});

/** انتقال یک‌بارهٔ وضعیت محلی مقاله‌ها به سرور. */
export async function migrateLocalReadingProgress(userId: string): Promise<void> {
  if (!BACKEND || !userId) return;
  const flags = readLocal<Record<string, boolean>>(LS_READING_MIGRATED, {});
  if (flags[userId]) return;
  writeLocal(LS_READING_MIGRATED, { ...flags, [userId]: true });
  for (const [articleId, state] of Object.entries(readLocalArticleStates())) {
    await enqueue(
      "reading.progress.upsert",
      { userId, articleId, state },
      `reading.progress:${userId}:${articleId}`,
    );
  }
}
