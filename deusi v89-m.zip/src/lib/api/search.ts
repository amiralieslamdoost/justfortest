/**
 * جست‌وجوی سراسری (سشن ۹).
 * روی کالکشن‌های واژه، گرامر، مقاله، پادکست، موسیقی و فیلم جست‌وجو می‌کند
 * و نتیجه را در همان شکل `Hit` صفحهٔ /suche برمی‌گرداند.
 * در حالت MOCK مقدار `null` برمی‌گردد تا صفحه از دیتای محلی استفاده کند.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";

export type SearchKind = "wort" | "grammatik" | "artikel" | "podcast" | "musik" | "film";

export interface SearchHit {
  id: string;
  kind: SearchKind;
  title: string;
  sub: string;
  excerpt?: string;
  level?: string;
  to: string;
}

function esc(q: string): string {
  return q.replace(/["\\]/g, " ").trim();
}

interface Source {
  kind: SearchKind;
  collection: string;
  fields: string[];
  map: (r: Record<string, unknown>) => SearchHit;
}

const str = (v: unknown) => (typeof v === "string" ? v : "");

const SOURCES: Source[] = [
  {
    kind: "wort",
    collection: "words",
    fields: ["lemma", "translation_fa"],
    map: (r) => ({
      id: str(r.id),
      kind: "wort",
      title: str(r.lemma),
      sub: [str(r.pos), str(r.translation_fa)].filter(Boolean).join(" · "),
      excerpt: str(r.example),
      level: str(r.level),
      to: `/dictionary?w=${str(r.slug) || str(r.id)}`,
    }),
  },
  {
    kind: "grammatik",
    collection: "grammar_lessons",
    fields: ["title", "title_fa", "summary"],
    map: (r) => ({
      id: str(r.id),
      kind: "grammatik",
      title: str(r.title),
      sub: str(r.title_fa) || str(r.summary),
      excerpt: str(r.summary),
      level: str(r.level),
      to: `/grammatik/${str(r.slug) || str(r.id)}`,
    }),
  },
  {
    kind: "artikel",
    collection: "articles",
    fields: ["title", "title_fa", "summary"],
    map: (r) => ({
      id: str(r.id),
      kind: "artikel",
      title: str(r.title),
      sub: [str(r.category), str(r.level)].filter(Boolean).join(" · "),
      excerpt: str(r.summary),
      level: str(r.level),
      to: `/lesen/${str(r.slug) || str(r.id)}`,
    }),
  },
  {
    kind: "podcast",
    collection: "episodes",
    fields: ["title", "description"],
    map: (r) => ({
      id: str(r.id),
      kind: "podcast",
      title: str(r.title),
      sub: str(r.level),
      excerpt: str(r.description),
      level: str(r.level),
      to: `/podcasts/${str(r.slug) || str(r.id)}`,
    }),
  },
  {
    kind: "musik",
    collection: "songs",
    fields: ["title", "artist_name"],
    map: (r) => ({
      id: str(r.id),
      kind: "musik",
      title: str(r.title),
      sub: str(r.genre) || str(r.artist_name),
      excerpt: str(r.summary),
      level: str(r.level),
      to: `/musik/${str(r.slug) || str(r.id)}`,
    }),
  },
  {
    kind: "film",
    collection: "films",
    fields: ["title", "title_fa", "synopsis"],
    map: (r) => ({
      id: str(r.id),
      kind: "film",
      title: str(r.title),
      sub: [str(r.genre), str(r.year)].filter(Boolean).join(" · "),
      excerpt: str(r.synopsis),
      level: str(r.level),
      to: `/kino/${str(r.slug) || str(r.id)}`,
    }),
  },
];

export interface SearchResult {
  items: SearchHit[];
  page: number;
  hasMore: boolean;
  /** تعداد کل نتیجه‌ها به تفکیک دامنه (برای چیپ‌های فیلتر). */
  totalByKind: Record<string, number>;
}

export interface SearchOptions {
  /** فیلتر دامنه؛ `alle` یعنی همه. */
  kind?: SearchKind | "alle";
  /** شمارهٔ صفحه (از ۱). فقط وقتی `kind` مشخص است معنا دارد. */
  page?: number;
  /** تعداد نتیجه در هر صفحه (حالت فیلترشده). */
  perPage?: number;
  /** تعداد نتیجه از هر دامنه در حالت «همه». */
  perKind?: number;
}

/**
 * جست‌وجو در همهٔ دامنه‌ها یا یک دامنهٔ مشخص، با صفحه‌بندی سمت سرور.
 * `null` یعنی بک‌اند در دسترس نیست و باید از دیتای محلی استفاده شود.
 */
export async function globalSearch(
  query: string,
  opts: SearchOptions = {},
): Promise<SearchResult | null> {
  const q = esc(query);
  if (!BACKEND || q.length < 2) return null;

  const kind = opts.kind ?? "alle";
  const page = Math.max(1, opts.page ?? 1);
  const perPage = Math.min(100, Math.max(1, opts.perPage ?? 20));
  const perKind = Math.min(50, Math.max(1, opts.perKind ?? 8));
  const pb = getPb();

  const run = async (src: Source, p: number, size: number) => {
    const filter = src.fields.map((f) => `${f} ~ "${q}"`).join(" || ");
    try {
      const list = await pbRequest((signal) =>
        pb.collection(src.collection).getList(p, size, { filter, signal }),
      );
      return {
        kind: src.kind,
        total: list.totalItems,
        items: list.items.map((item) => src.map(item as unknown as Record<string, unknown>)),
      };
    } catch (err) {
      console.warn(`search failed for ${src.collection}`, err);
      return { kind: src.kind, total: 0, items: [] as SearchHit[] };
    }
  };

  if (kind !== "alle") {
    const src = SOURCES.find((s) => s.kind === kind);
    if (!src) return { items: [], page, hasMore: false, totalByKind: {} };
    const res = await run(src, page, perPage);
    return {
      items: res.items,
      page,
      hasMore: page * perPage < res.total,
      totalByKind: { [res.kind]: res.total, alle: res.total },
    };
  }

  const results = await Promise.all(SOURCES.map((src) => run(src, 1, perKind)));
  const totalByKind: Record<string, number> = { alle: 0 };
  for (const r of results) {
    totalByKind[r.kind] = r.total;
    totalByKind.alle += r.total;
  }
  return {
    items: results.flatMap((r) => r.items),
    page: 1,
    hasMore: results.some((r) => r.total > r.items.length),
    totalByKind,
  };
}
