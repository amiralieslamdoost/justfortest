/**
 * اشتراک (سشن ۹) — کالکشن `subscriptions` فقط خواندنی است؛
 * تغییر پلن به‌صورت درخواست در `contact_messages` (topic = billing) ثبت می‌شود
 * و تیم پشتیبانی/سرور آن را اعمال می‌کند. هیچ پرداختی در کلاینت انجام نمی‌شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { enqueue, registerHandler } from "./offline-queue";
import type { SubscriptionRecord } from "./types";

export type PlanId = SubscriptionRecord["plan"];
export type PlanStatus = SubscriptionRecord["status"];

export interface Subscription {
  plan: PlanId;
  status: PlanStatus;
  startedAt: string;
  expiresAt: string;
  source: "backend" | "mock";
}

export const FREE_SUBSCRIPTION: Subscription = {
  plan: "free",
  status: "active",
  startedAt: "",
  expiresAt: "",
  source: "mock",
};

/** اشتراک فعال کاربر. */
export async function getSubscription(userId: string): Promise<Subscription> {
  if (!BACKEND || !userId) return FREE_SUBSCRIPTION;
  try {
    const rec = await pbRequest((signal) =>
      getPb()
        .collection("subscriptions")
        .getFirstListItem<SubscriptionRecord>(`user = "${userId}"`, {
          sort: "-created",
          signal,
        }),
    );
    return {
      plan: rec.plan ?? "free",
      status: rec.status ?? "active",
      startedAt: rec.started_at ?? "",
      expiresAt: rec.expires_at ?? "",
      source: "backend",
    };
  } catch {
    return FREE_SUBSCRIPTION;
  }
}

/** ثبت درخواست تغییر پلن (offline-safe). */
export async function requestPlanChange(
  userId: string,
  plan: PlanId,
  opts: { email?: string; name?: string; note?: string } = {},
): Promise<void> {
  if (!BACKEND || !userId) return;
  await enqueue(
    "subscription.request",
    { userId, plan, ...opts },
    `subscription.request:${userId}:${plan}`,
  );
}

registerHandler("subscription.request", async (payload) => {
  const { userId, plan, email, name, note } = payload as {
    userId: string;
    plan: PlanId;
    email?: string;
    name?: string;
    note?: string;
  };
  await getPb()
    .collection("contact_messages")
    .create({
      user: userId,
      name: name ?? "",
      email: email ?? "",
      topic: "billing",
      subject: `Plan-Wechsel: ${plan}`,
      message: note ?? `Der Nutzer möchte auf den Plan "${plan}" wechseln.`,
      status: "new",
    });
});
