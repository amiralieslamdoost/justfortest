/**
 * هوک‌های TanStack Query برای دامنهٔ برنامه‌ریز — سشن ۷.
 *
 * کامپوننت‌ها این ماژول را مستقیم صدا نمی‌زنند؛ `@/lib/deusi/planner/usePlanner`
 * روی همین هوک‌ها سوار است و همان API قبلی را به UI می‌دهد.
 */
import { useEffect, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import {
  deleteSession as apiDeleteSession,
  listLogs,
  loadPrefs,
  loadWeek,
  logSession,
  migrateLocalPlanner,
  putSession,
  savePrefs as apiSavePrefs,
  saveWeek,
  subscribePlanner,
  summarizeLogs,
  weekLogRange,
  type SessionLogEntry,
  type SessionLogInput,
} from "./planner";
import { listLeitnerItems } from "./vocabulary";
import { BACKEND } from "./config";
import type { PlannerPrefs, PlannerSession, PlannerWeek } from "@/lib/deusi/planner/types";

const PLAN_STALE = 30_000;
const WEEK_STALE = 15_000;

/** پروفایل برنامه‌ریزی کاربر. */
export function usePlannerPlanQuery(userId: string, enabled: boolean) {
  useEffect(() => {
    if (BACKEND && userId) void migrateLocalPlanner(userId);
  }, [userId]);

  return useQuery({
    queryKey: queryKeys.planner.planByUser(userId),
    queryFn: () => loadPrefs(userId),
    enabled: enabled && Boolean(userId),
    staleTime: PLAN_STALE,
    refetchOnWindowFocus: true,
  });
}

/** بلوک‌های یک هفته. */
export function usePlannerWeekQuery(userId: string, weekStart: string, enabled: boolean) {
  return useQuery({
    queryKey: queryKeys.planner.week(userId, weekStart),
    queryFn: () => loadWeek(userId, weekStart),
    enabled: enabled && Boolean(userId),
    staleTime: WEEK_STALE,
    refetchOnWindowFocus: true,
  });
}

/** ابزارهای نوشتن + به‌روزرسانی خوش‌بینانهٔ کش. */
export function usePlannerMutations(userId: string, weekStart: string) {
  const qc = useQueryClient();

  const weekKey = useMemo(() => queryKeys.planner.week(userId, weekStart), [userId, weekStart]);

  const setWeekCache = (week: PlannerWeek | null) => qc.setQueryData(weekKey, week);

  const savePrefsMutation = useMutation({
    mutationFn: async (prefs: PlannerPrefs) => {
      if (userId) await apiSavePrefs(userId, prefs);
      return prefs;
    },
    onSuccess: (prefs) => {
      qc.setQueryData(queryKeys.planner.planByUser(userId), prefs);
    },
  });

  const saveWeekMutation = useMutation({
    mutationFn: async (week: PlannerWeek) => {
      if (userId) await saveWeek(userId, week);
      return week;
    },
    onMutate: (week: PlannerWeek) => {
      setWeekCache(week);
    },
  });

  const putSessionMutation = useMutation({
    mutationFn: async (session: PlannerSession) => {
      if (userId) await putSession(userId, session);
      return session;
    },
  });

  const deleteSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      if (userId) await apiDeleteSession(userId, sessionId);
      return sessionId;
    },
  });

  const logSessionMutation = useMutation({
    mutationFn: async (input: SessionLogInput) => {
      if (userId) await logSession(userId, input);
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["planner", "logs", userId] });
      void qc.invalidateQueries({ queryKey: queryKeys.planner.dueVocab(userId) });
    },
  });

  return {
    savePrefs: savePrefsMutation.mutateAsync,
    saveWeek: saveWeekMutation.mutateAsync,
    putSession: putSessionMutation.mutateAsync,
    deleteSession: deleteSessionMutation.mutateAsync,
    logSession: logSessionMutation.mutateAsync,
    setWeekCache,
    busy:
      savePrefsMutation.isPending ||
      saveWeekMutation.isPending ||
      putSessionMutation.isPending ||
      deleteSessionMutation.isPending,
    error:
      savePrefsMutation.error ??
      saveWeekMutation.error ??
      putSessionMutation.error ??
      deleteSessionMutation.error ??
      null,
  };
}

/** تعداد کارت‌های سررسیدشدهٔ FSRS/Leitner برای بلوک‌های واژگان. */
export function useDueVocabCount(userId: string) {
  const q = useQuery({
    queryKey: queryKeys.planner.dueVocab(userId),
    queryFn: () => listLeitnerItems(userId),
    enabled: Boolean(userId),
    staleTime: 60_000,
  });
  const now = Date.now();
  const due = (q.data ?? []).filter((item) => !item.dueAt || Date.parse(item.dueAt) <= now);
  return { dueCount: due.length, totalCount: (q.data ?? []).length, isLoading: q.isLoading };
}

/** تاریخچهٔ لاگ سشن‌های یک هفته + خلاصهٔ آماری. */
export function usePlannerLogsQuery(userId: string, weekStart: string, enabled: boolean) {
  const range = useMemo(() => weekLogRange(weekStart), [weekStart]);

  const q = useQuery({
    queryKey: queryKeys.planner.logs(userId, range.from, range.to),
    queryFn: () => listLogs(userId, range),
    enabled: enabled && Boolean(userId),
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });

  const logs: SessionLogEntry[] = useMemo(() => q.data ?? [], [q.data]);
  const summary = useMemo(() => summarizeLogs(logs), [logs]);

  return { logs, summary, isLoading: q.isLoading, error: q.error };
}

/**
 * همگام‌سازی چنددستگاهی: تغییرات سرور، کش محلی را بی‌اعتبار می‌کند.
 * در حالت MOCK هیچ اتصالی باز نمی‌شود.
 */
export function usePlannerRealtimeSync(userId: string) {
  const qc = useQueryClient();

  useEffect(() => {
    if (!BACKEND || !userId) return;
    const unsubscribe = subscribePlanner(userId, (what) => {
      if (what === "plan") {
        void qc.invalidateQueries({ queryKey: queryKeys.planner.planByUser(userId) });
        return;
      }
      if (what === "sessions") {
        void qc.invalidateQueries({ queryKey: ["planner", "week", userId] });
        return;
      }
      void qc.invalidateQueries({ queryKey: ["planner", "logs", userId] });
    });
    return unsubscribe;
  }, [qc, userId]);
}
