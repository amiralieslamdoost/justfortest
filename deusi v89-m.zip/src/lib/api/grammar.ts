/**
 * لایهٔ دادهٔ گرامر / Grammatik-Datenschicht.
 *
 * دامنه‌ها: grammatik (index/$topicId/$lessonId) و docs.
 *
 * قانون: کامپوننت‌ها هرگز مستقیم PocketBase صدا نمی‌زنند.
 * در حالت MOCK (نبود `VITE_PB_URL`) دقیقاً همان دیتای `mockGrammar.ts`
 * و localStorage فعلی استفاده می‌شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { toApiError } from "./errors";
import { enqueue, registerHandler } from "./offline-queue";
import { readLocal, writeLocal } from "./storage";
import type {
  ExerciseRecord,
  GrammarLessonRecord,
  GrammarTopicRecord,
  LessonProgressRecord,
} from "./types";
import {
  grammarTopics as MOCK_TOPICS,
  type GrammarTopic,
  type Lesson,
  type RoadmapNode,
} from "@/lib/deusi/mockGrammar";

export const LS_LESSON_PROGRESS = "deusi.grammar.progress.v1";
const LS_TOPICS_CACHE = "deusi.grammar.topics.cache.v1";
const LS_PROGRESS_MIGRATED = "deusi.grammar.migrated.v1";

export type LessonStatus = "not-started" | "in-progress" | "done";

export interface LessonProgress {
  /** شناسهٔ محلی درس (slug) */
  lessonId: string;
  topicId: string;
  progress: number; // 0..100
  status: LessonStatus;
  score: number;
  secondsSpent: number;
  answers: Record<string, unknown>;
  completedAt?: string;
}

export type LessonProgressMap = Record<string, LessonProgress>;

function escapeFilter(value: string) {
  return value.replace(/["\\]/g, "");
}

/* -------------------------------------------------------------------------- */
/* نگاشت رکورد سرور ↔ مدل UI                                                   */
/* -------------------------------------------------------------------------- */

export function lessonRecordToLesson(r: GrammarLessonRecord, topicSlug: string): Lesson {
  return {
    id: r.slug || r.id,
    nodeId: r.node_id,
    topicId: topicSlug,
    title: r.title,
    subtitle: r.subtitle,
    emoji: r.emoji,
    duration: r.duration,
    difficulty: r.difficulty as Lesson["difficulty"],
    sections: (r.sections ?? []) as Lesson["sections"],
  };
}

export function topicRecordToTopic(
  r: GrammarTopicRecord,
  lessons: GrammarLessonRecord[],
): GrammarTopic {
  const slug = r.slug || r.id;
  const nodes = (r.nodes ?? []) as RoadmapNode[];
  return {
    id: slug,
    category: r.category as GrammarTopic["category"],
    name: r.name,
    subtitle: r.subtitle,
    description: r.description || r.subtitle,
    emoji: r.emoji,
    difficulty: r.difficulty as GrammarTopic["difficulty"],
    duration: r.duration || nodes.reduce((s, n) => s + (n.duration ?? 0), 0),
    completion: 0,
    accent: r.accent,
    nodes,
    lessons: lessons
      .slice()
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
      .map((l) => lessonRecordToLesson(l, slug)),
  };
}

/* -------------------------------------------------------------------------- */
/* محتوای گرامر                                                                */
/* -------------------------------------------------------------------------- */

/** همهٔ موضوع‌های گرامر همراه درس‌ها. در MOCK یا خطای سرور، دیتای محلی. */
export async function listGrammarTopics(): Promise<GrammarTopic[]> {
  if (!BACKEND) return MOCK_TOPICS;
  const pb = getPb();
  try {
    const topics = await pbRequest((signal) =>
      pb.collection("grammar_topics").getFullList<GrammarTopicRecord>({
        filter: "published = true",
        sort: "order,name",
        signal,
      }),
    );
    if (!topics.length) return MOCK_TOPICS;

    const lessons = await pbRequest((signal) =>
      pb.collection("grammar_lessons").getFullList<GrammarLessonRecord>({
        filter: "published = true",
        sort: "order",
        signal,
      }),
    );

    const byTopic = new Map<string, GrammarLessonRecord[]>();
    for (const l of lessons) {
      const key = typeof l.topic === "string" ? l.topic : "";
      const arr = byTopic.get(key) ?? [];
      arr.push(l);
      byTopic.set(key, arr);
    }

    const mapped = topics.map((t) => topicRecordToTopic(t, byTopic.get(t.id) ?? []));
    writeLocal(LS_TOPICS_CACHE, mapped);
    return mapped;
  } catch (err) {
    const cached = readLocal<GrammarTopic[] | null>(LS_TOPICS_CACHE, null);
    if (cached?.length) return cached;
    if (toApiError(err).kind === "notFound") return MOCK_TOPICS;
    return MOCK_TOPICS;
  }
}

/** تمرین‌های مستقل یک درس (اگر جدا از sections ذخیره شده باشند). */
export async function listLessonExercises(lessonRecordId: string): Promise<ExerciseRecord[]> {
  if (!BACKEND || !lessonRecordId) return [];
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb.collection("exercises").getFullList<ExerciseRecord>({
        filter: `lesson = "${escapeFilter(lessonRecordId)}"`,
        sort: "order",
        signal,
      }),
    );
  } catch {
    return [];
  }
}

/* -------------------------------------------------------------------------- */
/* پیشرفت درس (lesson_progress)                                                */
/* -------------------------------------------------------------------------- */

function readLocalProgress(): LessonProgressMap {
  return readLocal<LessonProgressMap>(LS_LESSON_PROGRESS, {});
}

function writeLocalProgress(map: LessonProgressMap) {
  writeLocal(LS_LESSON_PROGRESS, map);
}

/** پیشرفت همهٔ درس‌های کاربر (کلید = شناسهٔ محلی درس). */
export async function listLessonProgress(userId: string): Promise<LessonProgressMap> {
  if (!BACKEND || !userId) return readLocalProgress();
  const pb = getPb();
  try {
    const rows = await pbRequest((signal) =>
      pb
        .collection("lesson_progress")
        .getFullList<LessonProgressRecord & { expand?: { lesson?: GrammarLessonRecord } }>({
          filter: `user = "${escapeFilter(userId)}"`,
          expand: "lesson",
          signal,
        }),
    );
    const map: LessonProgressMap = {};
    for (const r of rows) {
      const lesson = r.expand?.lesson;
      const lessonId = lesson?.slug ?? (r.lesson as string);
      map[lessonId] = {
        lessonId,
        topicId: "",
        progress: r.progress ?? 0,
        status: r.status ?? "not-started",
        score: r.score ?? 0,
        secondsSpent: r.seconds_spent ?? 0,
        answers: (r.answers ?? {}) as Record<string, unknown>,
        completedAt: r.completed_at || undefined,
      };
    }
    writeLocalProgress({ ...readLocalProgress(), ...map });
    return map;
  } catch {
    return readLocalProgress();
  }
}

/** ذخیرهٔ خوش‌بینانهٔ پیشرفت یک درس + صف آفلاین. */
export async function saveLessonProgress(
  userId: string,
  patch: Partial<LessonProgress> & { lessonId: string; topicId: string },
): Promise<LessonProgress> {
  const map = readLocalProgress();
  const prev = map[patch.lessonId];
  const next: LessonProgress = {
    lessonId: patch.lessonId,
    topicId: patch.topicId,
    progress: patch.progress ?? prev?.progress ?? 0,
    status: patch.status ?? prev?.status ?? "in-progress",
    score: patch.score ?? prev?.score ?? 0,
    secondsSpent: patch.secondsSpent ?? prev?.secondsSpent ?? 0,
    answers: { ...(prev?.answers ?? {}), ...(patch.answers ?? {}) },
    completedAt:
      patch.completedAt ?? (patch.status === "done" ? new Date().toISOString() : prev?.completedAt),
  };
  writeLocalProgress({ ...map, [patch.lessonId]: next });

  if (BACKEND && userId) {
    await enqueue(
      "grammar.lessonProgress.upsert",
      { userId, progress: next },
      `grammar.lessonProgress:${userId}:${next.lessonId}`,
    );
  }
  return next;
}

/** ذخیرهٔ پاسخ یک تمرین در همان درس. */
export async function saveExerciseAnswer(
  userId: string,
  args: {
    topicId: string;
    lessonId: string;
    exerciseId: string;
    value: unknown;
    correct?: boolean;
  },
): Promise<LessonProgress> {
  return saveLessonProgress(userId, {
    lessonId: args.lessonId,
    topicId: args.topicId,
    answers: {
      [args.exerciseId]: {
        value: args.value,
        correct: args.correct ?? null,
        at: new Date().toISOString(),
      },
    },
  });
}

/* -------------------------------------------------------------------------- */
/* ترکیب پیشرفت با محتوا (وضعیت گره‌های نقشهٔ راه)                               */
/* -------------------------------------------------------------------------- */

/** وضعیت گره‌ها و درصد تکمیل موضوع را از روی پیشرفت واقعی کاربر می‌سازد. */
export function applyProgress(topics: GrammarTopic[], map: LessonProgressMap): GrammarTopic[] {
  if (!Object.keys(map).length) return topics;
  return topics.map((topic) => {
    const lessonByNode = new Map(topic.lessons.map((l) => [l.nodeId, l]));
    let doneCount = 0;
    let firstOpen = true;
    const nodes = topic.nodes.map((node) => {
      const lesson = lessonByNode.get(node.id);
      const p = lesson ? map[lesson.id] : undefined;
      let status: RoadmapNode["status"];
      if (p?.status === "done") {
        status = "done";
        doneCount++;
      } else if (p && p.progress > 0) {
        status = "current";
        firstOpen = false;
      } else if (firstOpen) {
        status = "available";
        firstOpen = false;
      } else {
        status = "locked";
      }
      return { ...node, status };
    });
    const completion = nodes.length ? Math.round((doneCount / nodes.length) * 100) : 0;
    return { ...topic, nodes, completion };
  });
}

/** آمار کلی گرامر بر اساس دادهٔ واقعی. */
export function grammarStatsFrom(topics: GrammarTopic[]) {
  const total = topics.length || 1;
  const done = topics.filter((t) => t.completion === 100).length;
  const avg = Math.round(topics.reduce((s, t) => s + t.completion, 0) / total);
  const totalLessons = topics.reduce((s, t) => s + t.lessons.length, 0);
  const doneLessons = topics.reduce(
    (s, t) => s + t.nodes.filter((n) => n.status === "done").length,
    0,
  );
  return {
    totalTopics: topics.length,
    doneTopics: done,
    avgCompletion: avg,
    totalLessons,
    doneLessons,
  };
}

/* -------------------------------------------------------------------------- */
/* هندلر صف آفلاین                                                             */
/* -------------------------------------------------------------------------- */

async function resolveLessonRecordId(slug: string): Promise<string | null> {
  if (!BACKEND || !slug) return null;
  const pb = getPb();
  try {
    const rec = await pbRequest((signal) =>
      pb
        .collection("grammar_lessons")
        .getFirstListItem<GrammarLessonRecord>(
          `slug = "${escapeFilter(slug)}" || id = "${escapeFilter(slug)}"`,
          { signal },
        ),
    );
    return rec.id;
  } catch {
    return null;
  }
}

async function findLessonProgress(userId: string, lessonRecordId: string) {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb
        .collection("lesson_progress")
        .getFirstListItem<LessonProgressRecord>(
          `user = "${escapeFilter(userId)}" && lesson = "${escapeFilter(lessonRecordId)}"`,
          { signal },
        ),
    );
  } catch (err) {
    if (toApiError(err).kind === "notFound") return null;
    throw err;
  }
}

registerHandler("grammar.lessonProgress.upsert", async (payload) => {
  const { userId, progress } = payload as { userId: string; progress: LessonProgress };
  if (!BACKEND || !userId) return;
  const lessonRecordId = await resolveLessonRecordId(progress.lessonId);
  if (!lessonRecordId) return; // محتوا هنوز روی سرور نیست (seed اجرا نشده)
  const pb = getPb();
  const existing = await findLessonProgress(userId, lessonRecordId);
  const data = {
    user: userId,
    lesson: lessonRecordId,
    progress: progress.progress,
    status: progress.status,
    score: progress.score,
    seconds_spent: progress.secondsSpent,
    answers: { ...((existing?.answers ?? {}) as object), ...progress.answers },
    completed_at: progress.completedAt ?? "",
  };
  if (existing) {
    await pbRequest((signal) =>
      pb.collection("lesson_progress").update(existing.id, data, { signal }),
    );
  } else {
    await pbRequest((signal) => pb.collection("lesson_progress").create(data, { signal }));
  }
});

/** انتقال یک‌بارهٔ پیشرفت محلی به سرور بعد از اولین ورود. */
export async function migrateLocalGrammarProgress(userId: string): Promise<void> {
  if (!BACKEND || !userId) return;
  const flags = readLocal<Record<string, boolean>>(LS_PROGRESS_MIGRATED, {});
  if (flags[userId]) return;
  writeLocal(LS_PROGRESS_MIGRATED, { ...flags, [userId]: true });
  for (const progress of Object.values(readLocalProgress())) {
    await enqueue(
      "grammar.lessonProgress.upsert",
      { userId, progress },
      `grammar.lessonProgress:${userId}:${progress.lessonId}`,
    );
  }
}
