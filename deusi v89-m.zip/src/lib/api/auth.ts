/**
 * لایهٔ احراز هویت / Authentifizierung.
 *
 * کامپوننت‌ها هرگز مستقیم PocketBase را صدا نمی‌زنند؛ فقط از `authApi`
 * استفاده می‌کنند. انتخاب پیاده‌سازی بر اساس `MOCK_MODE` انجام می‌شود.
 */
import { BACKEND } from "./config";
import { getPb, pbRequest } from "./client";
import { ApiError, toApiError } from "./errors";
import { mockAuthApi, readMockUsers, LS_USERS } from "./mock-adapter";
import type { AuthApi, AuthSession } from "./auth-types";
import type { DeckCard, User } from "@/lib/deusi/types";
import { SEED_WORDS } from "@/lib/deusi/seed";
import { newCard } from "@/lib/deusi/fsrs";
import type { ProfileRecord } from "./types";

export type { AuthApi, AuthSession } from "./auth-types";

interface PbAuthRecord {
  id: string;
  email?: string;
  name?: string;
  created?: string;
}

/** فقط داده‌های محلی (کارت‌ها/واژه‌های شخصی) — همگام‌سازی واقعی در سشن ۳. */
function localShell(recordId: string): Pick<User, "deck" | "customWords" | "streak" | "lastStudy"> {
  const existing = readMockUsers().find((u) => u.id === recordId);
  if (existing) {
    return {
      deck: existing.deck ?? [],
      customWords: existing.customWords ?? [],
      streak: existing.streak ?? 0,
      lastStudy: existing.lastStudy ?? null,
    };
  }
  const deck: DeckCard[] = SEED_WORDS.map((w) => newCard(w.id));
  return { deck, customWords: [], streak: 0, lastStudy: null };
}

function persistShell(user: User) {
  if (typeof window === "undefined") return;
  try {
    const users = readMockUsers();
    const next = users.some((u) => u.id === user.id)
      ? users.map((u) =>
          u.id === user.id ? { ...u, ...user, deck: u.deck, customWords: u.customWords } : u,
        )
      : [...users, user];
    localStorage.setItem(LS_USERS, JSON.stringify(next));
  } catch (err) {
    console.warn("localStorage write failed", err);
  }
}

function toUser(record: PbAuthRecord, profile?: Partial<ProfileRecord> | null): User {
  const shell = localShell(record.id);
  const user: User = {
    id: record.id,
    username: profile?.display_name || record.name || record.email?.split("@")[0] || "user",
    email: record.email ?? "",
    password: "", // رمز هرگز در کلاینت نگه داشته نمی‌شود
    createdAt: record.created ? Date.parse(record.created) : Date.now(),
    streak: typeof profile?.streak_days === "number" ? profile.streak_days : shell.streak,
    lastStudy: shell.lastStudy,
    deck: shell.deck,
    customWords: shell.customWords,
  };
  persistShell(user);
  return user;
}

async function loadProfile(userId: string): Promise<Partial<ProfileRecord> | null> {
  const pb = getPb();
  try {
    return await pbRequest((signal) =>
      pb.collection("profiles").getFirstListItem<ProfileRecord>(`user="${userId}"`, { signal }),
    );
  } catch (err) {
    const api = toApiError(err);
    if (api.kind === "notFound") return null;
    if (api.kind === "auth") return null;
    throw api;
  }
}

async function ensureProfile(userId: string, displayName: string) {
  const pb = getPb();
  const existing = await loadProfile(userId);
  if (existing) return existing;
  return pbRequest((signal) =>
    pb.collection("profiles").create<ProfileRecord>(
      {
        user: userId,
        display_name: displayName,
        handle: displayName
          .toLowerCase()
          .replace(/[^a-z0-9_]/g, "")
          .slice(0, 20),
        initials: displayName.slice(0, 2).toUpperCase(),
        level: "unknown",
        onboarding_done: false,
        public_profile: true,
      },
      { signal },
    ),
  );
}

async function sessionFromStore(): Promise<AuthSession | null> {
  const pb = getPb();
  const record = pb.authStore.record as PbAuthRecord | null;
  if (!pb.authStore.isValid || !record) return null;
  const profile = await loadProfile(record.id).catch(() => null);
  return { user: toUser(record, profile), recordId: record.id };
}

const pbAuthApi: AuthApi = {
  async restore() {
    const pb = getPb();
    if (!pb.authStore.isValid) return null;
    return sessionFromStore();
  },

  async register(username, email, password) {
    if (!username || !email || !password) {
      throw new ApiError("validation", "همه فیلدها لازم است");
    }
    if (password.length < 8) {
      throw new ApiError("validation", "رمز عبور باید حداقل ۸ کاراکتر باشد", 400, {
        password: "رمز عبور باید حداقل ۸ کاراکتر باشد",
      });
    }
    const pb = getPb();
    await pbRequest(
      (signal) =>
        pb
          .collection("users")
          .create(
            { email, password, passwordConfirm: password, name: username, emailVisibility: false },
            { signal },
          ),
      { retries: 0 },
    );
    await pbRequest(
      (signal) => pb.collection("users").authWithPassword(email, password, { signal }),
      {
        retries: 0,
      },
    );
    const record = pb.authStore.record as PbAuthRecord;
    const profile = await ensureProfile(record.id, username).catch(() => null);
    return { user: toUser(record, profile), recordId: record.id };
  },

  async login(identifier, password) {
    const pb = getPb();
    await pbRequest(
      (signal) => pb.collection("users").authWithPassword(identifier, password, { signal }),
      { retries: 0 },
    );
    const record = pb.authStore.record as PbAuthRecord;
    const profile = await loadProfile(record.id).catch(() => null);
    return { user: toUser(record, profile), recordId: record.id };
  },

  async requestPasswordReset(email) {
    if (!email) {
      throw new ApiError("validation", "ایمیل لازم است", 400, { email: "ایمیل لازم است" });
    }
    const pb = getPb();
    await pbRequest((signal) => pb.collection("users").requestPasswordReset(email, { signal }), {
      retries: 0,
    });
  },

  async confirmPasswordReset(token, password) {
    if (!token) throw new ApiError("validation", "لینک بازیابی نامعتبر است");
    if (password.length < 8) {
      throw new ApiError("validation", "رمز عبور باید حداقل ۸ کاراکتر باشد", 400, {
        password: "رمز عبور باید حداقل ۸ کاراکتر باشد",
      });
    }
    const pb = getPb();
    await pbRequest(
      (signal) =>
        pb.collection("users").confirmPasswordReset(token, password, password, { signal }),
      { retries: 0 },
    );
  },

  async refresh() {
    const pb = getPb();
    if (!pb.authStore.isValid) return null;
    try {
      await pbRequest((signal) => pb.collection("users").authRefresh({ signal }), { retries: 0 });
    } catch (err) {
      const api = toApiError(err);
      if (api.kind === "auth") {
        pb.authStore.clear();
        return null;
      }
      // خطای شبکه نباید کاربر را بیرون بیندازد؛ نشست فعلی حفظ می‌شود.
      return sessionFromStore();
    }
    return sessionFromStore();
  },

  async logout() {
    getPb().authStore.clear();
  },
};

/** پیاده‌سازی فعال بر اساس تنظیمات محیط. */
export const authApi: AuthApi = BACKEND ? pbAuthApi : mockAuthApi;

/** اشتراک در تغییرات نشست (فقط در حالت بک‌اند فعال است). */
export function onAuthChange(cb: () => void): () => void {
  if (!BACKEND) return () => {};
  return getPb().authStore.onChange(() => cb(), false);
}
