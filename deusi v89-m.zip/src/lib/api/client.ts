/**
 * PocketBase-Client / کلاینت PocketBase.
 *
 * - آدرس از `VITE_PB_URL` خوانده می‌شود (فقط متغیرهای VITE_*، هیچ کلید سری).
 * - در حالت MOCK هیچ نمونه‌ای ساخته نمی‌شود و `getPb()` خطا می‌دهد؛
 *   سرویس‌ها قبل از فراخوانی باید `BACKEND` را چک کنند.
 * - همهٔ درخواست‌ها timeout دارند و خطاها به `ApiError` تبدیل می‌شوند.
 */
import PocketBase from "pocketbase";
import { BACKEND, PB_URL, REQUEST_TIMEOUT_MS } from "./config";
import { toApiError } from "./errors";

let instance: PocketBase | null = null;

/** نمونهٔ singleton؛ فقط وقتی بک‌اند تنظیم شده باشد. */
export function getPb(): PocketBase {
  if (!BACKEND) {
    throw new Error("PocketBase ist nicht konfiguriert (VITE_PB_URL fehlt).");
  }
  if (!instance) {
    instance = new PocketBase(PB_URL);
    instance.autoCancellation(false);
  }
  return instance;
}

/** نمونه یا null — برای جاهایی که نباید throw شود. */
export function tryPb(): PocketBase | null {
  return BACKEND ? getPb() : null;
}

/**
 * اجرای یک فراخوانی PocketBase با timeout، تبدیل خطا و تلاش مجدد سبک
 * برای خطاهای شبکه‌ای (نه برای خطاهای ۴xx).
 */
export async function pbRequest<T>(
  run: (signal: AbortSignal) => Promise<T>,
  opts: { retries?: number; timeoutMs?: number } = {},
): Promise<T> {
  const retries = opts.retries ?? 1;
  const timeoutMs = opts.timeoutMs ?? REQUEST_TIMEOUT_MS;

  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await run(controller.signal);
    } catch (err) {
      lastError = err;
      const api = toApiError(err);
      const retryable = api.kind === "network" || api.kind === "server";
      if (!retryable || attempt === retries) throw api;
      await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
    } finally {
      clearTimeout(timer);
    }
  }
  throw toApiError(lastError);
}

/** کاربر واردشده (رکورد auth) یا null. */
export function currentAuthRecord() {
  const pb = tryPb();
  return pb?.authStore.record ?? null;
}

/** آیا نشست معتبری وجود دارد. */
export function hasValidSession(): boolean {
  const pb = tryPb();
  return Boolean(pb?.authStore.isValid);
}
