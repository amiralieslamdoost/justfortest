/**
 * هوک‌های TanStack Query برای دامنهٔ آزمون‌ها — سشن ۶.
 */
import { useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "./queryKeys";
import {
  findOpenAttempt,
  getAttempt,
  heartbeat,
  listAnswers,
  listAttempts,
  listSections,
  rateManualAnswer,
  saveAnswer,
  startAttempt,
  submitAttempt,
  type ExamAnswer,
  type ExamAttempt,
  listExamCatalog,
  getExamCatalogEntry,
  examStatsOf,
} from "./exams";
import { EXAMS, type Exam } from "@/lib/deusi/exams/mockExams";
import { updateProfile } from "./profile";
import type { ExamQuestion, ModelltestSection } from "@/lib/deusi/exams/mockModelltests";
import { getModelltest } from "@/lib/deusi/exams/mockModelltests";
import type { Cefr } from "@/lib/deusi/examScoring";
import { useDeusi } from "@/lib/deusi/store";

const CONTENT_STALE = 5 * 60_000;

/** شناسهٔ کاربر جاری (در MOCK هم همان کاربر localStorage). */
export function useCurrentUserId(): string {
  const { currentUser } = useDeusi();
  return currentUser?.id ?? "";
}

/** بخش‌های Modelltest یک آزمون. */
export function useExamSections(examId: string) {
  const fallback = getModelltest(examId)?.sections ?? [];
  const q = useQuery({
    queryKey: queryKeys.exams.sections(examId),
    queryFn: () => listSections(examId),
    enabled: Boolean(examId),
    staleTime: CONTENT_STALE,
    initialData: fallback,
  });
  return {
    sections: (q.data ?? fallback) as ModelltestSection[],
    isLoading: q.isLoading,
    error: q.error,
  };
}

/** تاریخچهٔ تلاش‌های کاربر روی یک آزمون (یا همهٔ آزمون‌ها). */
export function useExamAttempts(examId?: string) {
  const userId = useCurrentUserId();
  const q = useQuery({
    queryKey: queryKeys.exams.attemptsByUser(userId, examId ?? null),
    queryFn: () => listAttempts(userId, examId),
    staleTime: 10_000,
  });
  return { attempts: (q.data ?? []) as ExamAttempt[], isLoading: q.isLoading, userId };
}

/** یک تلاش + پاسخ‌هایش (از ذخیرهٔ محلی، پس رفرش‌پذیر است). */
export function useAttempt(attemptId: string) {
  const q = useQuery({
    queryKey: queryKeys.exams.attempt(attemptId),
    queryFn: async () => ({
      attempt: getAttempt(attemptId),
      answers: listAnswers(attemptId),
    }),
    enabled: Boolean(attemptId),
    staleTime: 0,
  });
  return {
    attempt: (q.data?.attempt ?? null) as ExamAttempt | null,
    answers: (q.data?.answers ?? {}) as Record<string, ExamAnswer>,
    isLoading: q.isLoading,
    refetch: q.refetch,
  };
}

/** مدیریت اجرای یک بخش آزمون: شروع/ادامه، ذخیرهٔ پاسخ، تحویل. */
export function useExamRunner(examId: string, section: ModelltestSection | null) {
  const qc = useQueryClient();
  const userId = useCurrentUserId();

  const invalidate = useCallback(
    (attemptId?: string) => {
      void qc.invalidateQueries({ queryKey: queryKeys.exams.all });
      if (attemptId) void qc.invalidateQueries({ queryKey: queryKeys.exams.attempt(attemptId) });
    },
    [qc],
  );

  // به‌جای mutation از query استفاده می‌کنیم تا با remount/رفرش، همان تلاش
  // باز دوباره پیدا شود و state داخلی کامپوننت گم نشود.
  const session = useQuery({
    queryKey: ["exams", "session", userId, section?.id ?? ""],
    queryFn: async () => {
      if (!section) return null;
      const open = findOpenAttempt(userId, section.id);
      if (open && new Date(open.deadlineAt).getTime() > Date.now()) return open;
      return startAttempt({ userId, examId, section });
    },
    enabled: Boolean(section),
    staleTime: Infinity,
    gcTime: Infinity,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });

  const answer = useMutation({
    mutationFn: async (input: { attempt: ExamAttempt; question: ExamQuestion; value: unknown }) =>
      saveAnswer(input.attempt, input.question, input.value),
    onSuccess: (_res, vars) => invalidate(vars.attempt.id),
  });

  const submit = useMutation({
    mutationFn: async (attemptId: string) => {
      if (!section) throw new Error("Kein Prüfungsteil ausgewählt");
      return submitAttempt(attemptId, section);
    },
    onSuccess: (attempt) => invalidate(attempt.id),
  });

  const ping = useCallback((attempt: ExamAttempt, secondsLeft: number) => {
    void heartbeat(attempt, secondsLeft);
  }, []);

  return {
    userId,
    attempt: (session.data ?? null) as ExamAttempt | null,
    isStarting: session.isLoading,
    answer,
    submit,
    ping,
  };
}

/** خودارزیابی پاسخ آزاد در صفحهٔ نتیجه. */
export function useManualRating(section: ModelltestSection | null) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { attemptId: string; questionId: string; points: number }) => {
      if (!section) throw new Error("Kein Prüfungsteil gefunden");
      return rateManualAnswer(input.attemptId, section, input.questionId, input.points);
    },
    onSuccess: (attempt) => {
      void qc.invalidateQueries({ queryKey: queryKeys.exams.all });
      void qc.invalidateQueries({ queryKey: queryKeys.exams.attempt(attempt.id) });
    },
  });
}

/** اعمال سطح پیشنهادی روی پروفایل — فقط با تأیید کاربر. */
export function useApplyExamLevel() {
  const qc = useQueryClient();
  const userId = useCurrentUserId();
  return useMutation({
    mutationFn: async (level: Cefr) => {
      if (!userId) throw new Error("Nicht angemeldet");
      return updateProfile(userId, { level });
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.profile.all });
    },
  });
}

/* -------------------------------------------------------------------------- */
/* کاتالوگ آزمون‌ها                                                             */
/* -------------------------------------------------------------------------- */

/** فهرست آزمون‌ها (سرور با fallback به mock) + آمار خلاصه. */
export function useExamCatalog() {
  const q = useQuery({
    queryKey: queryKeys.exams.list(),
    queryFn: listExamCatalog,
    initialData: EXAMS,
    staleTime: CONTENT_STALE,
  });
  const exams = q.data ?? EXAMS;
  return { exams, stats: examStatsOf(exams), isLoading: q.isLoading, error: q.error };
}

/** یک آزمون مشخص. */
export function useExamDetail(slug: string, fallback?: Exam) {
  const q = useQuery({
    queryKey: queryKeys.exams.detail(slug),
    queryFn: () => getExamCatalogEntry(slug),
    initialData: fallback ?? null,
    enabled: Boolean(slug),
    staleTime: CONTENT_STALE,
  });
  return { exam: q.data ?? fallback ?? null, isLoading: q.isLoading };
}
