import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useDeusi } from "@/lib/deusi/store";
import { useInteractions } from "@/lib/deusi/interactions";
import {
  FEATURED_WORDS,
  RECENTLY_VIEWED_IDS,
  POPULAR_IDS,
  VOCAB_STATS,
  findById,
  searchWords,
  categoryCount,
} from "@/lib/deusi/dictionary/mockWords";
import { CATEGORIES, CEFR_LEVELS, POS_LABEL } from "@/lib/deusi/dictionary/categories";
import { LEARNING_BOOKS } from "@/lib/deusi/dictionary/books";
import { PROVERBS } from "@/lib/deusi/dictionary/proverbs";
import { useWordCatalog } from "@/lib/api/useVocabulary";
import { ProverbCard } from "@/components/deusi/dictionary/ProverbCard";
import type { CEFR, DictPos, DictWord } from "@/lib/deusi/dictionary/types";
import { WordCard } from "@/components/deusi/dictionary/WordCard";
import { WordDetailPanel } from "@/components/deusi/dictionary/WordDetailPanel";
import { MyWordsSection } from "@/components/deusi/dictionary/MyWordsSection";
import { CefrBadge } from "@/components/deusi/dictionary/Badges";
import { SectionShell } from "@/components/deusi/dictionary/SectionShell";
import { Fa } from "@/components/deusi/Fa";
import { SectionHero } from "@/components/deusi/SectionHero";
import { SECTION_THEME } from "@/lib/deusi/sectionTheme";

import { useCustomWords } from "@/lib/deusi/dictionary/customWords";
import { useLeitnerQueue } from "@/lib/deusi/dictionary/leitnerQueue";
import {
  CategorySection,
  Chip,
  ClockIcon,
  DictionaryDetailPanel,
  ProverbsSection,
  SearchIcon,
  TextbookVocabulary,
  WortschatzHero,
} from "@/components/deusi/dictionary/DictionaryRouteHelpers";

// Section identity — one source of truth so SectionNav and each
// SectionShell agree on order, icon, label, and accent color.
const SECTIONS = [
  { id: "sec-recent", label: "Kürzlich", icon: "🕐", accent: "#64748B" },
  { id: "sec-wortschatz", label: "Wortschatz", icon: "📊", accent: "#7C3AED" },
  { id: "sec-mine", label: "Meine Wörter", icon: "✨", accent: "#EC4899" },
  { id: "sec-popular", label: "Beliebt", icon: "🔥", accent: "#F97316" },
  { id: "sec-proverbs", label: "Sprichwörter", icon: "💬", accent: "#14B8A6" },
  { id: "sec-books", label: "Lehrbücher", icon: "📚", accent: "#6366F1" },
  { id: "sec-categories", label: "Kategorien", icon: "🗂️", accent: "#0EA5E9" },
  { id: "sec-all", label: "Alle Wörter", icon: "📖", accent: "#A855F7" },
] as const;
const ACCENT = Object.fromEntries(SECTIONS.map((s) => [s.id, s])) as Record<
  (typeof SECTIONS)[number]["id"],
  (typeof SECTIONS)[number]
>;

export const Route = createFileRoute("/dictionary")({
  /** لینک عمیق از جست‌وجوی سراسری: /dictionary?w=<slug|id> */
  validateSearch: (search: Record<string, unknown>) => ({
    w: typeof search.w === "string" && search.w ? search.w : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Wörterbuch — DEUSI" },
      {
        name: "description",
        content: "Deutsches Wörterbuch mit Aussprache, Beispielen und persischer Übersetzung.",
      },
      { property: "og:title", content: "Wörterbuch — DEUSI" },
      {
        property: "og:description",
        content: "Deutsches Wörterbuch mit Aussprache, Beispielen und persischer Übersetzung.",
      },
    ],
  }),
  component: Dictionary,
});

function Dictionary() {
  const { w: deepLinkWord } = Route.useSearch();
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  const {
    isBookmarked,
    isFavorited,
    toggleBookmark,
    toggleFavorite,
    countBookmarks,
    countFavorites,
  } = useInteractions();
  const { words: customWords } = useCustomWords();
  const leitner = useLeitnerQueue();

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  // ---- state ----
  const [query, setQuery] = useState("");
  const [cefr, setCefr] = useState<CEFR | "all">("all");
  const [pos, setPos] = useState<DictPos | "all">("all");
  const [category, setCategory] = useState<string | "all">("all");
  const [showSuggest, setShowSuggest] = useState(false);
  const [recent, setRecent] = useState<string[]>(RECENTLY_VIEWED_IDS);
  const bookmarks = { has: (id: string) => isBookmarked("word", id) };
  const favorites = { has: (id: string) => isFavorited("word", id) };
  const [progress] = useState<Record<string, number>>({
    lernen: 85,
    wunderbar: 65,
    zeit: 90,
    freund: 72,
    entwickeln: 45,
    morgen: 85,
    abenteuer: 65,
    geniessen: 90,
    traumhaft: 40,
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>(["Zeit", "lernen", "Freund"]);
  const PAGE_SIZE = 10;
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [allLayout, setAllLayout] = useState<"grid" | "list">("grid");
  const resultsRef = useRef<HTMLDivElement | null>(null);

  // Reset pagination when filters/query change
  useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [cefr, pos, category, query]);

  // Mobile detail sheet: lock background scroll + close on Escape
  useEffect(() => {
    if (!selectedId || typeof window === "undefined") return;
    if (window.matchMedia("(min-width: 1024px)").matches) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSelectedId(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [selectedId]);

  const scrollToResults = () => {
    setTimeout(
      () => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
      60,
    );
  };
  const pickCategory = (id: string) => {
    setCategory((prev) => (prev === id ? "all" : id));
    scrollToResults();
  };

  // ---- derived ----
  const { words: catalog } = useWordCatalog();
  const suggestions = useMemo(() => searchWords(query, 6), [query]);
  const filtered = useMemo(
    () =>
      catalog.filter((w) => {
        if (cefr !== "all" && w.cefr !== cefr) return false;
        if (pos !== "all" && w.pos !== pos) return false;
        if (category !== "all" && w.category !== category) return false;
        if (query) {
          const q = query.toLowerCase();
          if (!w.headword.toLowerCase().includes(q) && !w.shortMeaning.toLowerCase().includes(q))
            return false;
        }
        return true;
      }),
    [catalog, cefr, pos, category, query],
  );

  const resolveWord = (id: string): DictWord | undefined =>
    findById(id) ?? catalog.find((w) => w.id === id) ?? customWords.find((w) => w.id === id);

  const selectedWord: DictWord | null = selectedId ? (resolveWord(selectedId) ?? null) : null;

  // ---- actions ----
  const openWord = (
    id: string,
    event?: React.MouseEvent<HTMLElement> | React.KeyboardEvent<HTMLElement>,
  ) => {
    void event;
    setSelectedId(id);
    setRecent((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, 8));
  };
  const wordMeta = (id: string) => {
    const w = resolveWord(id);
    return {
      title: w?.headword ?? id,
      sub: [w?.pos, w?.meanings?.[0]?.fa ?? w?.meanings?.[0]?.de].filter(Boolean).join(" · "),
      level: w?.cefr,
      to: "/dictionary",
    };
  };
  const toggleBm = (id: string) => toggleBookmark("word", id, wordMeta(id));
  const toggleFv = (id: string) => toggleFavorite("word", id, wordMeta(id));
  const toggleLeitner = (id: string, label?: string) => {
    const w = resolveWord(id);
    leitner.toggle(id, label ?? w?.headword);
  };

  /* باز کردن خودکار واژه هنگام ورود از جست‌وجوی سراسری (?w=…) */
  useEffect(() => {
    if (!deepLinkWord) return;
    const target =
      resolveWord(deepLinkWord) ??
      catalog.find((w) => w.headword.toLowerCase() === deepLinkWord.toLowerCase());
    if (target) {
      setSelectedId(target.id);
      setRecent((prev) => [target.id, ...prev.filter((x) => x !== target.id)].slice(0, 8));
    } else {
      setQuery(deepLinkWord);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deepLinkWord, catalog]);

  const submitSearch = () => {
    if (query.trim() && !recentSearches.includes(query)) {
      setRecentSearches((prev) => [query, ...prev].slice(0, 5));
    }
    setShowSuggest(false);
  };

  const mobileDetailPopover =
    typeof document === "undefined"
      ? null
      : createPortal(
          <AnimatePresence>
            {selectedWord && (
              <div key="mobile-dictionary-detail" className="lg:hidden">
                {/* Backdrop */}
                <motion.div
                  className="fixed inset-0 z-40 bg-black/45 backdrop-blur-[2px]"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.18, ease: "easeOut" }}
                  onClick={() => setSelectedId(null)}
                />

                {/* Slide-in sheet from the right, swipe right to dismiss */}
                <motion.div
                  role="dialog"
                  aria-modal="true"
                  drag="x"
                  dragDirectionLock
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={{ left: 0, right: 0.6 }}
                  onDragEnd={(_, info) => {
                    if (info.offset.x > 110 || info.velocity.x > 600) setSelectedId(null);
                  }}
                  initial={{ x: "100%" }}
                  animate={{ x: 0 }}
                  exit={{ x: "100%" }}
                  transition={{ type: "spring", stiffness: 460, damping: 42, mass: 0.7 }}
                  className="fixed inset-y-0 right-0 z-50 flex w-full max-w-[520px] flex-col overflow-hidden bg-card shadow-2xl ring-1 ring-border/70 [&>aside]:!rounded-none [&>aside]:!bg-card [&>aside]:!backdrop-blur-none [&>aside]:!border-border [&>aside]:!shadow-none"
                  style={{ touchAction: "pan-y" }}
                >
                  {/* Grab handle hinting the swipe-to-close gesture */}
                  <div
                    aria-hidden
                    className="pointer-events-none absolute left-1.5 top-1/2 z-20 h-14 w-1 -translate-y-1/2 rounded-full bg-foreground/15"
                  />
                  <WordDetailPanel
                    word={selectedWord}
                    favorite={favorites.has(selectedWord.id)}
                    inLeitner={leitner.has(selectedWord.id)}
                    bookmarked={bookmarks.has(selectedWord.id)}
                    onClose={() => setSelectedId(null)}
                    onToggleFavorite={() => toggleFv(selectedWord.id)}
                    onToggleLeitner={() => toggleLeitner(selectedWord.id)}
                    onToggleBookmark={() => toggleBm(selectedWord.id)}
                    onOpenWord={openWord}
                  />
                </motion.div>
              </div>
            )}
          </AnimatePresence>,
          document.body,
        );

  if (!currentUser) return null;

  return (
    <div className="grid gap-4 sm:gap-5 lg:grid-cols-[minmax(0,1fr)_420px] animate-fade">
      {/* ============ LEFT: Home ============ */}
      <div className="isolate min-w-0 space-y-6 sm:space-y-7">
        <SectionHero sectionKey="dictionary" allowOverflow>
          {/* Suche direkt im Header — ein einziges, kompaktes Steuerelement */}
          <div className="relative z-40">
            <div className="group relative flex w-full flex-col gap-2 rounded-2xl border border-white/25 bg-white/12 p-1.5 shadow-[0_18px_40px_-24px_rgba(0,0,0,.7)] backdrop-blur-md transition-all focus-within:border-white/50 focus-within:bg-white/18 focus-within:ring-2 focus-within:ring-white/25 sm:flex-row sm:items-center sm:gap-1">
              <div className="flex min-w-0 flex-1 items-center gap-2 pl-3 text-white">
                <SearchIcon />
                <input
                  value={query}
                  onChange={(e) => {
                    setQuery(e.target.value);
                    setShowSuggest(true);
                  }}
                  onFocus={() => setShowSuggest(true)}
                  onBlur={() => setTimeout(() => setShowSuggest(false), 150)}
                  onKeyDown={(e) => e.key === "Enter" && submitSearch()}
                  placeholder="Wörter suchen…"
                  aria-label="Wörter suchen"
                  className="min-w-0 flex-1 bg-transparent py-2.5 text-sm text-white outline-none placeholder:text-white/60"
                />
                {query && (
                  <button
                    onClick={() => setQuery("")}
                    className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-white/70 transition hover:bg-white/20 hover:text-white"
                    aria-label="Löschen"
                  >
                    ✕
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  setCefr("all");
                  setPos("all");
                  setCategory("all");
                  setQuery("");
                  scrollToResults();
                }}
                className="flex w-full shrink-0 items-center justify-center gap-1.5 rounded-xl bg-white px-3 py-2.5 text-xs font-bold shadow-sm transition hover:shadow-md sm:w-auto sm:text-sm"
                style={{ color: SECTION_THEME.dictionary.base }}
                title="Alle Wörter anzeigen"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="hidden sm:block"
                >
                  <rect x="3" y="4" width="18" height="4" rx="1" />
                  <rect x="3" y="11" width="18" height="4" rx="1" />
                  <rect x="3" y="18" width="18" height="3" rx="1" />
                </svg>
                <span className="whitespace-nowrap">Alle Wörter</span>
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M9 6l6 6-6 6" />
                </svg>
              </button>

              {/* Suggestions dropdown */}
              <AnimatePresence>
                {showSuggest && (query || recentSearches.length > 0) && (
                  <motion.div
                    initial={{ opacity: 0, y: -6, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -6, scale: 0.98 }}
                    transition={{ duration: 0.15 }}
                    className="absolute left-0 right-0 top-full z-[100] mt-2 max-h-80 overflow-y-auto rounded-2xl border border-border/70 bg-card p-2 text-foreground shadow-2xl ring-1 ring-black/5"
                  >
                    {query && suggestions.length > 0 && (
                      <div>
                        <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                          Vorschläge
                        </div>
                        {suggestions.map((s) => (
                          <button
                            key={s.id}
                            onMouseDown={(event) => {
                              event.preventDefault();
                              openWord(s.id, event);
                              setQuery("");
                              setShowSuggest(false);
                            }}
                            className="flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left transition hover:bg-muted"
                          >
                            <div className="flex items-baseline gap-2">
                              <span className="font-semibold">{s.headword}</span>
                              <span className="text-xs text-muted-foreground">
                                {POS_LABEL[s.pos]}
                              </span>
                            </div>
                            <CefrBadge level={s.cefr} />
                          </button>
                        ))}
                      </div>
                    )}
                    {query && suggestions.length === 0 && (
                      <div className="px-3 py-6 text-center text-sm text-muted-foreground">
                        Keine Ergebnisse für „{query}"
                      </div>
                    )}
                    {!query && recentSearches.length > 0 && (
                      <div>
                        <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                          Letzte Suchen
                        </div>
                        {recentSearches.map((r) => (
                          <button
                            key={r}
                            onMouseDown={(event) => {
                              event.preventDefault();
                              setQuery(r);
                              setShowSuggest(true);
                            }}
                            className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm transition hover:bg-muted"
                          >
                            <ClockIcon /> {r}
                          </button>
                        ))}
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </SectionHero>

        {/* 01 · Recently viewed */}
        <SectionShell
          anchorId="sec-recent"
          index={1}
          icon={ACCENT["sec-recent"].icon}
          accent={ACCENT["sec-recent"].accent}
          title="Kürzlich angesehen"
          subtitle="Deine zuletzt geöffneten Wörter"
        >
          {recent.length === 0 ? (
            <p className="rounded-xl border border-dashed border-border/60 bg-muted/30 px-4 py-6 text-center text-xs text-muted-foreground">
              Noch keine Wörter geöffnet — tippe unten auf ein Wort, um zu starten.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {recent.slice(0, 6).map((id) => {
                const w = findById(id);
                if (!w) return null;
                return (
                  <WordCard
                    key={w.id}
                    word={w}
                    variant="compact"
                    bookmarked={bookmarks.has(w.id)}
                    onOpen={(event) => openWord(w.id, event)}
                    onToggleBookmark={() => toggleBm(w.id)}
                  />
                );
              })}
            </div>
          )}
        </SectionShell>

        {/* 02 · Dein Wortschatz — stats hero (keeps its own vivid design) */}
        <div id="sec-wortschatz" className="scroll-mt-24">
          <WortschatzHero
            bookmarksCount={countBookmarks("word")}
            customCount={customWords.length}
            leitnerCount={leitner.count}
          />
        </div>

        {/* 03 · Meine Wörter — personal collection (has its own gradient header) */}
        <div id="sec-mine" className="scroll-mt-24">
          <MyWordsSection
            masterWords={catalog}
            findById={findById}
            onOpen={openWord}
            onToggleBookmark={toggleBm}
            bookmarks={(id) => bookmarks.has(id)}
            progress={progress}
            inLeitner={(id) => leitner.has(id)}
            onToggleLeitner={toggleLeitner}
            previewLimit={4}
            moreTo="/dictionary/meine-woerter"
          />
        </div>

        {/* 04 · Popular words */}
        <SectionShell
          anchorId="sec-popular"
          index={4}
          icon={ACCENT["sec-popular"].icon}
          accent={ACCENT["sec-popular"].accent}
          title="Beliebte Wörter"
          subtitle="Meistgesucht diese Woche"
          action={
            <span
              className="rounded-full px-2.5 py-1 text-[10px] font-bold"
              style={{
                background: `${ACCENT["sec-popular"].accent}18`,
                color: ACCENT["sec-popular"].accent,
              }}
            >
              Trending
            </span>
          }
        >
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {POPULAR_IDS.map((id) => {
              const w = findById(id);
              if (!w) return null;
              return (
                <WordCard
                  key={w.id}
                  word={w}
                  progress={progress[w.id] ?? 40}
                  bookmarked={bookmarks.has(w.id)}
                  inLeitner={leitner.has(w.id)}
                  onOpen={(event) => openWord(w.id, event)}
                  onToggleBookmark={() => toggleBm(w.id)}
                  onToggleLeitner={() => toggleLeitner(w.id, w.headword)}
                />
              );
            })}
          </div>
        </SectionShell>

        {/* 05 · Proverbs & idioms */}
        <ProverbsSection accent={ACCENT["sec-proverbs"].accent} anchorId="sec-proverbs" />

        <TextbookVocabulary icon={ACCENT["sec-books"].icon} accent={ACCENT["sec-books"].accent} />

        <CategorySection
          category={category}
          onCategoryChange={(value) => setCategory(value)}
          onPickCategory={pickCategory}
          getCategoryCount={categoryCount}
          icon={ACCENT["sec-categories"].icon}
          accent={ACCENT["sec-categories"].accent}
        />

        {/* 08 · All words (master results list) */}
        {(() => {
          const activeCat = category !== "all" ? CATEGORIES.find((c) => c.id === category) : null;
          const activeFilters: { label: string; onClear: () => void; color?: string }[] = [];
          if (activeCat)
            activeFilters.push({
              label: `${activeCat.icon} ${activeCat.label}`,
              onClear: () => setCategory("all"),
              color: activeCat.color,
            });
          if (cefr !== "all")
            activeFilters.push({ label: `Niveau ${cefr}`, onClear: () => setCefr("all") });
          if (pos !== "all")
            activeFilters.push({ label: POS_LABEL[pos], onClear: () => setPos("all") });
          if (query) activeFilters.push({ label: `"${query}"`, onClear: () => setQuery("") });
          return (
            <section
              id="sec-all"
              ref={resultsRef}
              className="relative scroll-mt-24 overflow-hidden rounded-3xl border-2 border-purple-200/70 bg-[linear-gradient(160deg,#F5F3FF_0%,#FDF2F8_55%,#EFF6FF_100%)] p-4 shadow-lg ring-1 ring-purple-100/50 dark:border-purple-800/50 dark:bg-[linear-gradient(160deg,rgba(76,29,149,0.18)_0%,rgba(131,24,67,0.18)_55%,rgba(30,58,138,0.18)_100%)] dark:ring-purple-900/30 sm:p-5"
            >
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 opacity-60 dark:opacity-30"
                style={{
                  background:
                    "radial-gradient(circle at 15% 0%, rgba(168,85,247,0.10), transparent 45%), radial-gradient(circle at 100% 100%, rgba(236,72,153,0.10), transparent 50%)",
                }}
              />
              <div className="relative">
                <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white text-lg shadow-md ring-1 ring-purple-200 dark:bg-slate-900 dark:ring-purple-800">
                      📖
                    </span>
                    <div>
                      <div className="mb-0.5 flex items-center gap-1.5">
                        <span className="rounded-full bg-purple-600/15 px-1.5 py-px text-[9px] font-black tracking-widest text-purple-700 dark:text-purple-300">
                          08
                        </span>
                        <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                          Abschnitt
                        </span>
                      </div>
                      <h2 className="text-base font-black tracking-tight sm:text-lg">
                        Alle Wörter · Ergebnisse ({filtered.length})
                      </h2>
                      <div className="text-[11px] text-muted-foreground sm:text-xs">
                        Vollständige Datenbank aller Vokabeln
                      </div>
                      <Fa className="fa-hint-xs">همهٔ واژه‌ها · نتایج</Fa>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-0.5 rounded-full bg-white/80 p-0.5 shadow-sm ring-1 ring-purple-200 dark:bg-slate-900/60 dark:ring-purple-800">
                      <button
                        onClick={() => setAllLayout("grid")}
                        aria-pressed={allLayout === "grid"}
                        title="Kartenansicht"
                        className={`grid h-7 w-7 place-items-center rounded-full transition ${
                          allLayout === "grid"
                            ? "bg-purple-600 text-white shadow-sm"
                            : "text-purple-700 hover:bg-purple-50 dark:text-purple-300"
                        }`}
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                          <rect x="3" y="3" width="8" height="8" rx="2" />
                          <rect x="13" y="3" width="8" height="8" rx="2" />
                          <rect x="3" y="13" width="8" height="8" rx="2" />
                          <rect x="13" y="13" width="8" height="8" rx="2" />
                        </svg>
                      </button>
                      <button
                        onClick={() => setAllLayout("list")}
                        aria-pressed={allLayout === "list"}
                        title="Listenansicht"
                        className={`grid h-7 w-7 place-items-center rounded-full transition ${
                          allLayout === "list"
                            ? "bg-purple-600 text-white shadow-sm"
                            : "text-purple-700 hover:bg-purple-50 dark:text-purple-300"
                        }`}
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                          <rect x="3" y="4" width="18" height="4" rx="2" />
                          <rect x="3" y="10" width="18" height="4" rx="2" />
                          <rect x="3" y="16" width="18" height="4" rx="2" />
                        </svg>
                      </button>
                    </div>
                    <button
                      onClick={() => {
                        setCefr("all");
                        setPos("all");
                        setCategory("all");
                        setQuery("");
                      }}
                      className="rounded-full bg-white/80 px-3 py-1.5 text-xs font-semibold text-purple-700 shadow-sm ring-1 ring-purple-200 transition hover:bg-white dark:bg-slate-900/60 dark:text-purple-300 dark:ring-purple-800"
                    >
                      Filter zurücksetzen
                    </button>
                  </div>
                </div>

                {activeFilters.length > 0 && (
                  <div className="mb-3 flex flex-wrap items-center gap-2 rounded-2xl border border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50 px-3 py-2.5 dark:border-purple-900/50 dark:from-purple-950/40 dark:to-pink-950/40">
                    <span className="text-[11px] font-bold uppercase tracking-widest text-purple-700 dark:text-purple-300">
                      Aktive Filter:
                    </span>
                    {activeFilters.map((f, i) => (
                      <span
                        key={i}
                        className="flex items-center gap-1 rounded-full bg-white px-2.5 py-1 text-xs font-semibold shadow-sm dark:bg-slate-900"
                        style={
                          f.color ? { color: f.color, boxShadow: `0 0 0 1px ${f.color}40` } : {}
                        }
                      >
                        {f.label}
                        <button
                          onClick={f.onClear}
                          className="grid h-4 w-4 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
                          aria-label="Entfernen"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                )}

                {/* Filters */}
                <div className="mb-4 flex flex-wrap items-center gap-2 rounded-2xl border border-border/60 bg-secondary/40 p-3">
                  <Chip active={cefr === "all"} onClick={() => setCefr("all")} accent>
                    Alle
                  </Chip>
                  {CEFR_LEVELS.map((l) => (
                    <Chip key={l} active={cefr === l} onClick={() => setCefr(l)}>
                      {l}
                    </Chip>
                  ))}
                  <div className="ml-2 hidden text-xs text-muted-foreground sm:block">·</div>
                  <select
                    value={pos}
                    onChange={(e) => setPos(e.target.value as DictPos | "all")}
                    className="rounded-full border border-border/60 bg-card px-3 py-1.5 text-xs font-medium outline-none hover:bg-muted"
                  >
                    <option value="all">Alle Wortarten</option>
                    {Object.entries(POS_LABEL).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </select>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="rounded-full border border-border/60 bg-card px-3 py-1.5 text-xs font-medium outline-none hover:bg-muted"
                  >
                    <option value="all">Alle Kategorien</option>
                    {CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div
                  className={
                    allLayout === "grid"
                      ? "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                      : "flex flex-col gap-2"
                  }
                >
                  {filtered.slice(0, visibleCount).map((w) => (
                    <WordCard
                      key={w.id}
                      word={w}
                      variant={allLayout === "list" ? "row" : "grid"}
                      progress={progress[w.id] ?? Math.min(90, w.frequency)}
                      bookmarked={bookmarks.has(w.id)}
                      inLeitner={leitner.has(w.id)}
                      onOpen={(event) => openWord(w.id, event)}
                      onToggleBookmark={() => toggleBm(w.id)}
                      onToggleLeitner={() => toggleLeitner(w.id, w.headword)}
                    />
                  ))}
                </div>
                {visibleCount < filtered.length && (
                  <div className="mt-5 flex flex-col items-center gap-2">
                    <div className="text-xs text-muted-foreground">
                      {Math.min(visibleCount, filtered.length)} von {filtered.length}
                    </div>
                    <button
                      onClick={() => setVisibleCount((v) => v + PAGE_SIZE)}
                      className="rounded-2xl bg-purple-600 px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:bg-purple-700 hover:shadow-lg active:scale-[0.98]"
                    >
                      {PAGE_SIZE} weitere Wörter laden
                    </button>
                  </div>
                )}
              </div>
            </section>
          );
        })()}
      </div>

      <DictionaryDetailPanel
        word={selectedWord}
        isFavorite={favorites.has}
        inLeitner={leitner.has}
        isBookmarked={bookmarks.has}
        onClose={() => setSelectedId(null)}
        onToggleFavorite={() => selectedWord && toggleFv(selectedWord.id)}
        onToggleLeitner={() => selectedWord && toggleLeitner(selectedWord.id)}
        onToggleBookmark={() => selectedWord && toggleBm(selectedWord.id)}
        onOpenWord={openWord}
      />

      {/* Mobile anchored detail popover */}
      {mobileDetailPopover}
    </div>
  );
}
