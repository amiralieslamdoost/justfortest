import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { HeroSearch } from "@/components/deusi/HeroSearch";
import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { CategoryChips } from "@/components/deusi/podcasts/CategoryChips";
import { PodcastCover } from "@/components/deusi/podcasts/PodcastCover";
import { Fa } from "@/components/deusi/Fa";
import { SectionHero } from "@/components/deusi/SectionHero";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";
import {
  featuredEpisode,
  listeningStats,
  podcastCategories,
  recommendedTopics,
  type PodcastCategoryKey,
  type PodcastEpisode,
} from "@/lib/deusi/mockPodcasts";
import { useEpisodes, useMediaProgressMap, usePodcastShows } from "@/lib/api/useMedia";
import { mediaKey } from "@/lib/api/mediaProgress";

export const Route = createFileRoute("/podcasts/")({
  head: () => ({
    meta: [
      { title: "Podcasts — Deutsch hören & verstehen | DEUSI" },
      {
        name: "description",
        content:
          "Deutsche Podcast-Folgen mit interaktivem Transkript, Vokabeln und Verständnis-Quiz — von A1 bis C1.",
      },
      { property: "og:title", content: "Podcasts — Deutsch hören & verstehen | DEUSI" },
      {
        property: "og:description",
        content: "Echte Gespräche hören, mitlesen und Wörter speichern.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PodcastsIndex,
});

function PodcastsIndex() {
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  const [category, setCategory] = useState<PodcastCategoryKey>("fuer-dich");
  const [search, setSearch] = useState("");

  // اپیزودها/شوها و پیشرفت شنیدن از لایهٔ API — سشن ۵.
  const { episodes: podcastEpisodes } = useEpisodes({ perPage: 200 });
  const { shows } = usePodcastShows();
  const { progress: mediaProgress } = useMediaProgressMap();
  const findShow = (id: string) => shows.find((s) => s.id === id);

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);
  const featured =
    podcastEpisodes.find((e) => e.featured) ?? podcastEpisodes[0] ?? featuredEpisode();
  const featuredShow = findShow(featured.showId);

  const filtered = useMemo(() => {
    return podcastEpisodes.filter((e) => {
      if (category !== "fuer-dich" && category !== "alle" && e.category !== category) return false;
      if (search && !`${e.title} ${e.description}`.toLowerCase().includes(search.toLowerCase()))
        return false;
      return true;
    });
  }, [category, search, podcastEpisodes]);

  const suggestions = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [];
    return podcastEpisodes
      .filter((e) => `${e.title} ${e.description}`.toLowerCase().includes(q))
      .slice(0, 6);
  }, [search, podcastEpisodes]);

  const latest = useMemo(
    () => [...filtered].sort((a, b) => (a.publishedAt < b.publishedAt ? 1 : -1)),
    [filtered],
  );

  const inProgress = podcastEpisodes
    .map((episode) => {
      const st = mediaProgress[mediaKey("episode", episode.id)];
      if (!st || st.progress <= 0 || st.finished) return null;
      return { progress: st, episode };
    })
    .filter((x): x is { progress: NonNullable<typeof x>["progress"]; episode: PodcastEpisode } =>
      Boolean(x),
    )
    .slice(0, 6);

  if (!currentUser) return null;

  return (
    <div className="space-y-6 animate-fade">
      <SectionHero
        sectionKey="podcasts"
        allowOverflow
        right={
          <HeroSearch
            value={search}
            onValueChange={setSearch}
            placeholder="Podcasts durchsuchen…"
            ariaLabel="Podcasts durchsuchen"
            emptyText="Keine Episoden"
            className="flex-1"
            items={suggestions.map((e) => ({
              id: e.id,
              title: e.title,
              sub: findShow(e.showId)?.title,
              badge: e.level,
              glyph: "🎧",
              color: "#6366F1",
            }))}
            totalCount={filtered.length}
            onSelect={(id) =>
              router.navigate({ to: "/podcasts/$episodeId", params: { episodeId: id } })
            }
          />
        }
      />

      <div className="grid gap-5 grid-cols-[minmax(0,1fr)] xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-5">
          <FeaturedCard episode={featured} publisher={featuredShow?.publisher ?? "DEUSI"} />

          {/* Popular shows */}
          <section className="neu-card p-4 sm:p-5">
            <div className="mb-4">
              <h2 className="text-sm font-black uppercase tracking-widest text-muted-foreground">
                Beliebte Podcasts
              </h2>
              <div className="mt-0.5 text-lg font-black">Trendige Shows</div>
              <Fa className="fa-hint-xs">پادکست‌های محبوب</Fa>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {shows.slice(0, 10).map((show) => {
                const ep = podcastEpisodes.find((e) => e.showId === show.id);
                if (!ep) return null;
                return (
                  <Link
                    key={show.id}
                    to="/podcasts/$episodeId"
                    params={{ episodeId: ep.id }}
                    className="group min-w-0 text-left"
                  >
                    <div className="relative overflow-hidden rounded-2xl shadow-md transition-shadow group-hover:shadow-2xl">
                      <PodcastCover
                        title={show.title}
                        publisher={show.publisher}
                        background={show.cover}
                        className="aspect-square"
                        size="md"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                      <div className="pointer-events-none absolute inset-0 grid place-items-center opacity-0 transition-opacity group-hover:opacity-100">
                        <span className="grid h-12 w-12 place-items-center rounded-full bg-white text-[color:var(--flag-red)] shadow-xl">
                          <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </span>
                      </div>
                      <span className="absolute right-2 top-2 rounded-md bg-black/60 px-1.5 py-0.5 text-[9px] font-black text-white backdrop-blur">
                        {show.level}
                      </span>
                    </div>
                    <div className="mt-2.5 truncate text-sm font-black">{show.publisher}</div>
                    <div className="truncate text-[11px] text-muted-foreground">{show.tagline}</div>
                  </Link>
                );
              })}
            </div>
          </section>

          {/* Episodes list */}
          <section className="neu-card p-4 sm:p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-black uppercase tracking-widest text-muted-foreground">
                  Alle Folgen
                </h2>
                <div className="mt-0.5 text-lg font-black">Frisch veröffentlicht</div>
                <Fa className="fa-hint-xs">تازه‌ترین قسمت‌ها</Fa>
              </div>
              <span className="rounded-full bg-secondary px-3 py-1 text-xs font-bold text-muted-foreground">
                {latest.length} Folgen
              </span>
            </div>
            <div className="mb-4">
              <CategoryChips
                categories={podcastCategories}
                active={category}
                onChange={setCategory}
              />
            </div>
            {latest.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                Keine Folgen gefunden.
              </div>
            ) : (
              <ul className="space-y-3">
                {latest.map((ep) => (
                  <EpisodeRow key={ep.id} episode={ep} />
                ))}
              </ul>
            )}
          </section>
        </div>

        <aside className="space-y-5">
          <ContinueListeningPanel entries={inProgress} />
          <ListeningStatsPanel />
          <RecommendedTopics />
        </aside>
      </div>
    </div>
  );
}

function FeaturedCard({ episode, publisher }: { episode: PodcastEpisode; publisher: string }) {
  return (
    <section className="neu-card relative overflow-hidden p-4 sm:p-6">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-30 blur-3xl"
        style={{ background: `radial-gradient(circle, ${episode.accent}55, transparent 60%)` }}
      />
      <div className="relative grid gap-5 grid-cols-[minmax(0,1fr)] md:grid-cols-[200px_minmax(0,1fr)] md:items-start">
        <PodcastCover
          title={episode.title}
          publisher={publisher}
          background={episode.cover}
          size="lg"
          className="mx-auto aspect-square w-40 sm:w-48 md:mx-0 md:w-full"
        />
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-[color:var(--flag-red)]">
            <span>Empfohlen für dich</span>
            <span className="rounded-md bg-secondary px-1.5 py-0.5 text-muted-foreground">
              {episode.level}
            </span>
          </div>
          <h2 className="mt-2 text-2xl font-black md:text-3xl">{episode.title}</h2>
          <p className="mt-2 text-sm text-muted-foreground">{episode.description}</p>
          <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
            <MetaChip icon="⏱" label={`${Math.round(episode.durationSec / 60)} Min`} />
            <MetaChip
              icon="📅"
              label={new Date(episode.publishedAt).toLocaleDateString("de-DE", {
                day: "2-digit",
                month: "short",
              })}
            />
            <MetaChip icon="📻" label={publisher} />
          </div>
          <Link
            to="/podcasts/$episodeId"
            params={{ episodeId: episode.id }}
            className="mt-5 inline-flex items-center gap-2 rounded-2xl bg-[color:var(--flag-red)] px-5 py-3 text-sm font-bold text-white shadow-lg transition hover:-translate-y-0.5"
          >
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <path d="M8 5v14l11-7z" />
            </svg>
            Folge anhören
          </Link>
        </div>
      </div>
    </section>
  );
}

function MetaChip({ icon, label }: { icon: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-secondary/70 px-2.5 py-1 text-[11px] font-semibold text-foreground">
      <span>{icon}</span>
      {label}
    </span>
  );
}

function EpisodeRow({ episode }: { episode: PodcastEpisode }) {
  return (
    <motion.li whileHover={{ y: -2 }} transition={{ type: "spring", stiffness: 260, damping: 22 }}>
      <Link
        to="/podcasts/$episodeId"
        params={{ episodeId: episode.id }}
        className="group relative flex items-center gap-3 overflow-hidden rounded-2xl bg-card p-3 ring-1 ring-border transition hover:shadow-lg sm:gap-4"
      >
        <div
          className="absolute inset-y-3 left-0 w-1 rounded-r-full opacity-0 transition-all group-hover:opacity-100"
          style={{ background: episode.accent }}
          aria-hidden
        />
        <div className="relative shrink-0">
          <PodcastCover
            title={episode.title}
            background={episode.cover}
            className="h-16 w-16 sm:h-[72px] sm:w-[72px]"
            size="sm"
          />
          <div className="pointer-events-none absolute inset-0 grid place-items-center rounded-2xl bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
            <span
              className="grid h-8 w-8 place-items-center rounded-full bg-white shadow-lg"
              style={{ color: episode.accent }}
            >
              <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor">
                <path d="M8 5v14l11-7z" />
              </svg>
            </span>
          </div>
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex min-w-0 items-center gap-2">
            <div className="min-w-0 flex-1 truncate text-sm font-black sm:text-base">
              {episode.title}
            </div>
            <span
              className="shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-black"
              style={{ background: `${episode.accent}20`, color: episode.accent }}
            >
              {episode.level}
            </span>
            <BookmarkButton
              type="podcast"
              id={episode.id}
              title={episode.title}
              sub={episode.description}
              level={episode.level}
              to={`/podcasts/${episode.id}`}
              size={16}
              className="h-7 w-7 shrink-0"
            />
          </div>
          <div className="line-clamp-1 text-xs text-muted-foreground">{episode.description}</div>
          <div className="mt-1.5 flex items-center gap-2 text-[10px] font-semibold text-muted-foreground">
            <span className="inline-flex items-center gap-1 rounded-full bg-secondary/70 px-2 py-0.5">
              ⏱ {Math.round(episode.durationSec / 60)} Min
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-secondary/70 px-2 py-0.5">
              📅{" "}
              {new Date(episode.publishedAt).toLocaleDateString("de-DE", {
                day: "2-digit",
                month: "short",
              })}
            </span>
          </div>
        </div>
      </Link>
    </motion.li>
  );
}

function ContinueListeningPanel({
  entries,
}: {
  entries: { progress: { positionSec: number }; episode: PodcastEpisode }[];
}) {
  return (
    <section className="neu-card p-5">
      <h3 className="text-sm font-bold">Fortsetzen</h3>
      <Fa className="fa-hint-xs mb-2 block">ادامهٔ گوش دادن</Fa>
      <ul className="space-y-3">
        {entries.map(({ episode, progress }) => {
          const pct = Math.round((progress.positionSec / episode.durationSec) * 100);
          const remaining = Math.max(
            1,
            Math.round((episode.durationSec - progress.positionSec) / 60),
          );
          return (
            <li key={episode.id}>
              <Link
                to="/podcasts/$episodeId"
                params={{ episodeId: episode.id }}
                className="flex items-center gap-3 rounded-2xl bg-background p-2.5 hover:bg-secondary/70"
              >
                <div className="relative">
                  <PodcastCover
                    title={episode.title}
                    background={episode.cover}
                    className="h-14 w-14 shrink-0"
                    size="sm"
                  />
                  <div className="absolute inset-0 m-auto grid h-7 w-7 place-items-center rounded-full bg-white/85 text-black shadow">
                    <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold">{episode.title}</div>
                  <div className="truncate text-[11px] text-muted-foreground">
                    Folge {episode.number}
                  </div>
                  <div className="mt-1 h-1 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full"
                      style={{
                        width: `${pct}%`,
                        background: "linear-gradient(90deg,var(--flag-gold),var(--flag-red))",
                      }}
                    />
                  </div>
                </div>
                <div className="shrink-0 text-[10px] text-muted-foreground">
                  {remaining} Min übrig
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function ListeningStatsPanel() {
  const s = listeningStats.weekly;
  const hours = `${Math.floor(s.totalMinutes / 60)}h ${s.totalMinutes % 60}m`;
  const maxBar = Math.max(...listeningStats.perDay.map((d) => d.minutes));
  return (
    <section className="neu-card p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-bold">Deine Hör-Statistiken</h3>
        <span className="rounded-full bg-secondary px-2 py-1 text-[11px] font-semibold text-muted-foreground">
          Diese Woche
        </span>
      </div>
      <Fa className="fa-hint-xs -mt-2 mb-3 block">آمار شنیداری این هفتهٔ شما</Fa>
      <div className="grid grid-cols-2 gap-2">
        <StatMini
          icon="🎧"
          label="Gesamtzeit"
          value={hours}
          delta={`+${Math.floor(s.deltaMinutes / 60)}h ${s.deltaMinutes % 60}m`}
          tint="#FDECEC"
        />
        <StatMini
          icon="🎙"
          label="Podcasts gehört"
          value={s.episodes}
          delta={`+${s.deltaEpisodes}`}
          tint="#FEE9E7"
        />
        <StatMini
          icon="Aa"
          label="Neue Wörter"
          value={s.newWords}
          delta={`+${s.deltaWords}`}
          tint="#E7F8EE"
        />
        <StatMini
          icon="📈"
          label="Verständnis"
          value={`${s.comprehension}%`}
          delta={`+${s.deltaComprehension}%`}
          tint="#F3ECFF"
        />
      </div>
      <div className="mt-4 flex items-end justify-between gap-2">
        {listeningStats.perDay.map((d) => {
          const h = Math.round((d.minutes / maxBar) * 60) + 6;
          return (
            <div key={d.day} className="flex flex-1 flex-col items-center gap-1">
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: h }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                className="w-full rounded-full"
                style={{ background: "linear-gradient(180deg,#FFD1CC,var(--flag-red))" }}
                title={`${d.minutes} Min`}
              />
              <span className="text-[10px] text-muted-foreground">{d.day}</span>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function StatMini({
  icon,
  label,
  value,
  delta,
  tint,
}: {
  icon: string;
  label: string;
  value: string | number;
  delta: string;
  tint: string;
}) {
  return (
    <div className="rounded-xl bg-background p-2.5">
      <div className="flex items-center gap-2">
        <div
          className="grid h-7 w-7 place-items-center rounded-lg text-xs"
          style={{ background: tint }}
        >
          {icon}
        </div>
        <div className="text-[10px] text-muted-foreground">{label}</div>
      </div>
      <div className="mt-1 text-lg font-black leading-none">{value}</div>
      <div className="mt-0.5 text-[10px] font-semibold text-[color:var(--easy)]">{delta}</div>
    </div>
  );
}

function RecommendedTopics() {
  return (
    <section className="neu-card p-5">
      <h3 className="mb-3 text-sm font-bold">Empfohlene Themen für dich</h3>
      <div className="flex flex-wrap gap-2">
        {recommendedTopics.map((t) => (
          <span key={t} className="rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold">
            {t}
          </span>
        ))}
      </div>
    </section>
  );
}
