import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AtSign, Loader2, Mail, ArrowLeft, CheckCircle2 } from "lucide-react";
import { AuthShell, AuthField } from "@/components/deusi/AuthShell";
import { useDeusi } from "@/lib/deusi/store";

export const Route = createFileRoute("/passwort-vergessen")({
  head: () => ({
    meta: [
      { title: "Passwort vergessen · DEUSI" },
      { name: "description", content: "Setze dein DEUSI-Passwort per E-Mail zurück." },
    ],
  }),
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  const { requestPasswordReset } = useDeusi();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    const res = await requestPasswordReset(email);
    setLoading(false);
    if (!res.ok) return setErr(res.error ?? "Senden fehlgeschlagen");
    setSent(true);
  };

  return (
    <AuthShell
      side="login"
      title="Passwort vergessen?"
      subtitle="Kein Problem — wir senden dir einen Link zum Zurücksetzen."
      footer={
        <>
          Wieder eingefallen?{" "}
          <Link
            to="/login"
            className="font-semibold hover:underline"
            style={{ color: "var(--flag-red)" }}
          >
            Zurück zur Anmeldung
          </Link>
        </>
      }
    >
      <AnimatePresence mode="wait">
        {sent ? (
          <motion.div
            key="sent"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4 text-center"
          >
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-500/15 text-emerald-600">
              <CheckCircle2 className="h-8 w-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold">E-Mail versendet</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Wir haben einen Link an <b className="text-foreground">{email}</b> geschickt. Prüfe
                auch deinen Spam-Ordner.
              </p>
              <p className="mt-1 text-xs text-muted-foreground" dir="rtl">
                یک لینک بازیابی به ایمیلت فرستادیم — پوشه‌ی اسپم را هم چک کن.
              </p>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:justify-center">
              <button
                onClick={() => {
                  setSent(false);
                  setEmail("");
                }}
                className="rounded-2xl border border-border bg-card/70 px-4 py-2 text-sm font-semibold hover:bg-secondary"
              >
                Andere E-Mail verwenden
              </button>
              <Link
                to="/login"
                className="inline-flex items-center justify-center gap-1.5 rounded-2xl bg-foreground px-4 py-2 text-sm font-bold text-background hover:opacity-90"
              >
                <ArrowLeft className="h-4 w-4" /> Zur Anmeldung
              </Link>
            </div>
          </motion.div>
        ) : (
          <motion.form
            key="form"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            onSubmit={submit}
            className="space-y-4"
          >
            <AuthField label="E-Mail-Adresse">
              <div className="group relative">
                <AtSign className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="max@deusi.app"
                  autoComplete="email"
                  className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-3 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
                />
              </div>
            </AuthField>

            {err && (
              <p className="rounded-2xl border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs font-semibold text-red-600">
                {err}
              </p>
            )}

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.98 }}
              className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl px-4 py-3 text-sm font-bold text-white shadow-lg transition disabled:opacity-60"
              style={{
                background: "linear-gradient(135deg, #1a1a1a 0%, #DD2222 60%, #F7C948 130%)",
                boxShadow: "0 20px 40px -18px rgba(221,34,34,0.65)",
              }}
            >
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Mail className="h-4 w-4" />
              )}
              <span className="relative">{loading ? "Sende…" : "Zurücksetz-Link senden"}</span>
            </motion.button>

            <p className="text-center text-xs text-muted-foreground" dir="rtl">
              لینک بازیابی رمز عبور به ایمیلت فرستاده می‌شود.
            </p>
          </motion.form>
        )}
      </AnimatePresence>
    </AuthShell>
  );
}
