import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bookmark,
  Search,
  BookOpen,
  Headphones,
  Music2,
  Film,
  Type,
  GraduationCap,
  Sparkles,
  Grid2x2,
  List as ListIcon,
  X,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { SearchField } from "@/components/deusi/SearchField";
import { useInteractions, INTERACTION_TYPES, type InteractionType } from "@/lib/deusi/interactions";

export const Route = createFileRoute("/lesezeichen")({
  head: () => ({
    meta: [
      { title: "Lesezeichen · DEUSI" },
      {
        name: "description",
        content: "Deine gespeicherten Wörter, Artikel, Podcasts, Songs und Filme.",
      },
    ],
  }),
  component: BookmarksPage,
});

type Kind = InteractionType;

const KIND_META: Record<
  Kind,
  { label: string; fa: string; Icon: typeof Bookmark; color: string; bg: string; fallback: string }
> = {
  word: {
    label: "Wörter",
    fa: "کلمات",
    Icon: Type,
    color: "#3a1080",
    bg: "#eee0ff",
    fallback: "/dictionary",
  },
  article: {
    label: "Artikel",
    fa: "مقاله‌ها",
    Icon: BookOpen,
    color: "#5c7a1c",
    bg: "#eaf5c9",
    fallback: "/lesen",
  },
  podcast: {
    label: "Podcasts",
    fa: "پادکست‌ها",
    Icon: Headphones,
    color: "#2a1a55",
    bg: "#e0daff",
    fallback: "/podcasts",
  },
  music: {
    label: "Musik",
    fa: "موسیقی",
    Icon: Music2,
    color: "#1552c8",
    bg: "#d9e6ff",
    fallback: "/musik",
  },
  film: {
    label: "Filme",
    fa: "فیلم‌ها",
    Icon: Film,
    color: "#c73a1c",
    bg: "#ffdccd",
    fallback: "/kino",
  },
  grammar: {
    label: "Grammatik",
    fa: "گرامر",
    Icon: GraduationCap,
    color: "#1b3fbf",
    bg: "#dee6ff",
    fallback: "/grammatik",
  },
  exam: {
    label: "Prüfungen",
    fa: "آزمون‌ها",
    Icon: GraduationCap,
    color: "#7a1c5c",
    bg: "#ffd9f0",
    fallback: "/pruefungen",
  },
  book: {
    label: "Bücher",
    fa: "کتاب‌ها",
    Icon: BookOpen,
    color: "#8a5a12",
    bg: "#ffeccc",
    fallback: "/dictionary",
  },
};

const KINDS: (Kind | "alle")[] = ["alle", ...INTERACTION_TYPES];

function BookmarksPage() {
  const { bookmarkList, removeBookmark } = useInteractions();
  const [filter, setFilter] = useState<Kind | "alle">("alle");
  const [q, setQ] = useState("");
  const [view, setView] = useState<"grid" | "list">("grid");

  const visible = useMemo(
    () =>
      bookmarkList.filter(
        (i) =>
          (filter === "alle" || i.type === filter) &&
          (q ? `${i.title ?? ""} ${i.sub ?? ""}`.toLowerCase().includes(q.toLowerCase()) : true),
      ),
    [bookmarkList, filter, q],
  );

  const counts = useMemo(() => {
    const map: Record<string, number> = { alle: bookmarkList.length };
    bookmarkList.forEach((i) => {
      map[i.type] = (map[i.type] ?? 0) + 1;
    });
    return map;
  }, [bookmarkList]);

  return (
    <div className="space-y-6 pb-10 animate-fade">
      <MiniHero
        Icon={Bookmark}
        label="Lesezeichen"
        title="Deine Sammlung an einem Ort"
        highlight="Sammlung"
        fa="مجموعه‌ی تو در یک نگاه"
        desc="Alle gespeicherten Wörter, Artikel, Podcasts, Songs und Filme."
        descFa="همه‌ی کلمات، مقاله‌ها، پادکست‌ها، آهنگ‌ها و فیلم‌های ذخیره‌شده."
        base="#04321a"
        primary="#128a3c"
        accent="#4be27a"
        right={
          <SearchField
            value={q}
            onValueChange={setQ}
            tone="hero"
            placeholder="In Lesezeichen suchen…"
            className="w-full sm:w-72"
          />
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-1 flex-wrap items-center gap-2">
          {KINDS.map((k) => {
            const active = filter === k;
            const meta = k === "alle" ? null : KIND_META[k];
            return (
              <button
                key={k}
                onClick={() => setFilter(k)}
                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                  active
                    ? "bg-foreground text-background shadow"
                    : "border border-border bg-background/50 text-foreground/70 hover:border-foreground/30"
                }`}
              >
                {meta ? (
                  <meta.Icon className="h-3.5 w-3.5" />
                ) : (
                  <Sparkles className="h-3.5 w-3.5" />
                )}
                {meta ? meta.label : "Alle"}
                <span
                  className={`ml-1 rounded-full px-1.5 text-[10px] ${active ? "bg-background/20" : "bg-foreground/10"}`}
                >
                  {counts[k] ?? 0}
                </span>
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-1 rounded-full border border-border bg-background/50 p-1">
          <button
            type="button"
            aria-label="Rasteransicht"
            aria-pressed={view === "grid"}
            onClick={() => setView("grid")}
            className={`grid h-9 w-9 place-items-center rounded-full ${view === "grid" ? "bg-foreground text-background" : "text-foreground/60"}`}
          >
            <Grid2x2 className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            aria-label="Listenansicht"
            aria-pressed={view === "list"}
            onClick={() => setView("list")}
            className={`grid h-9 w-9 place-items-center rounded-full ${view === "list" ? "bg-foreground text-background" : "text-foreground/60"}`}
          >
            <ListIcon className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="glass-strong grid place-items-center gap-2 rounded-[28px] py-20 text-center">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-foreground/5">
            <Bookmark className="h-6 w-6 text-foreground/60" />
          </div>
          <div className="text-sm font-semibold">Keine Lesezeichen in dieser Ansicht.</div>
          <FaHint>هیچ موردی پیدا نشد</FaHint>
        </div>
      ) : (
        <div
          className={
            view === "grid" ? "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3" : "space-y-2"
          }
        >
          <AnimatePresence initial={false}>
            {visible.map((it) => {
              const meta = KIND_META[it.type];
              return (
                <motion.div
                  key={`${it.type}:${it.id}`}
                  layout
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Link
                    to={(it.to ?? meta.fallback) as never}
                    className={`group grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-2xl border border-border bg-background/60 transition hover:border-foreground/25 hover:shadow-md ${
                      view === "grid"
                        ? "h-full items-start p-4 hover:-translate-y-0.5"
                        : "p-3 sm:gap-4"
                    }`}
                  >
                    <span
                      className={`grid shrink-0 place-items-center rounded-xl ${
                        view === "grid" ? "h-10 w-10" : "h-10 w-10 sm:h-11 sm:w-11"
                      }`}
                      style={{ backgroundColor: meta.bg, color: meta.color }}
                    >
                      <meta.Icon className="h-5 w-5" />
                    </span>

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="rounded-full bg-foreground/5 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-foreground/70">
                          {meta.label}
                        </span>
                        {it.level && (
                          <span
                            className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                            style={{ backgroundColor: meta.bg, color: meta.color }}
                          >
                            {it.level}
                          </span>
                        )}
                      </div>
                      <h3 className="mt-1 truncate text-sm font-bold leading-snug">
                        {it.title ?? meta.label}
                      </h3>
                      {it.sub && (
                        <p
                          className={`mt-0.5 text-xs text-muted-foreground ${
                            view === "grid" ? "line-clamp-2" : "truncate"
                          }`}
                        >
                          {it.sub}
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        removeBookmark(it.type, it.id);
                      }}
                      aria-label="Entfernen"
                      className="grid h-8 w-8 shrink-0 place-items-center rounded-full opacity-70 transition hover:bg-foreground/5 hover:opacity-100"
                      title="Aus Lesezeichen entfernen"
                    >
                      <X className="h-4 w-4 text-foreground/60" />
                    </button>
                  </Link>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

function MiniHero(props: {
  Icon: typeof Bookmark;
  label: string;
  title: string;
  highlight?: string;
  fa: string;
  desc: string;
  descFa: string;
  base: string;
  primary: string;
  accent: string;
  right?: React.ReactNode;
}) {
  const { Icon, label, title, highlight, fa, desc, descFa, base, primary, accent, right } = props;
  const idx = highlight ? title.indexOf(highlight) : -1;
  const before = idx >= 0 ? title.slice(0, idx) : title;
  const mid = idx >= 0 ? title.slice(idx, idx + (highlight?.length ?? 0)) : "";
  const after = idx >= 0 ? title.slice(idx + (highlight?.length ?? 0)) : "";
  return (
    <header
      className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
      style={{
        backgroundImage: `linear-gradient(135deg, ${base} 0%, ${primary} 55%, ${accent} 130%)`,
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div
          className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
          style={{ backgroundColor: accent, opacity: 0.4 }}
        />
      </div>
      <div className="relative grid gap-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
        <div className="flex min-w-0 items-center gap-3 sm:gap-4">
          <div
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16"
            style={{ color: primary }}
          >
            <Icon className="h-8 w-8" />
          </div>
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
              {label}
            </div>
            <h1 className="mt-2 text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
              {before}
              {mid && (
                <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
                  {mid}
                </span>
              )}
              {after}
            </h1>
            <FaHint className="!text-white/85">{fa}</FaHint>
            <p className="mt-2 max-w-2xl text-sm text-white/80">{desc}</p>
            <FaHint className="!text-white/70">{descFa}</FaHint>
          </div>
        </div>
        {right && <div className="flex w-full items-center gap-2 sm:w-auto">{right}</div>}
      </div>
    </header>
  );
}
