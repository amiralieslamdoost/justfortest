import { createFileRoute } from "@tanstack/react-router";
import { SearchField } from "@/components/deusi/SearchField";
import { useMemo, useRef, useState } from "react";
import { CircleDot, ListTree, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { SectionHero } from "@/components/deusi/SectionHero";
import { FamilyGraph } from "@/components/deusi/wortfamilien/FamilyGraph";
import { FamilyTree } from "@/components/deusi/wortfamilien/FamilyTree";
import { NodeDetailPanel } from "@/components/deusi/wortfamilien/NodeDetailPanel";
import { PrefixTable } from "@/components/deusi/wortfamilien/PrefixTable";
import { RootPicker } from "@/components/deusi/wortfamilien/RootPicker";
import { useLeitnerQueue } from "@/lib/deusi/dictionary/leitnerQueue";
import { TOTAL_MEMBERS, searchRoots } from "@/lib/deusi/wordfamilies/mockFamilies";
import { useWordFamilies } from "@/lib/api/useVocabulary";
import {
  POS_LABEL,
  type FamilyMember,
  type WfLevel,
  type WfPos,
} from "@/lib/deusi/wordfamilies/types";

export const Route = createFileRoute("/verben")({
  component: WortfamilienPage,
  head: () => ({
    meta: [
      { title: "Wortfamilien & Wortstämme — DEUSI" },
      {
        name: "description",
        content:
          "Deutsche Wörter über ihre Wurzel verstehen: interaktive Wortfamilien-Karte mit Präfixen, Suffixen und Wortbau.",
      },
      { property: "og:title", content: "DEUSI — Wortfamilien entdecken" },
      {
        property: "og:description",
        content:
          "Ein Wortstamm in der Mitte, seine ganze Wortfamilie darum herum — visuell, interaktiv, verständlich.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type ViewMode = "radial" | "tree";
const LEVELS: Array<WfLevel | "all"> = ["all", "A1", "A2", "B1", "B2", "C1"];
const POS_FILTERS: Array<WfPos | "all"> = ["all", "verb", "noun", "adjective", "adverb"];

function WortfamilienPage() {
  const [query, setQuery] = useState("");
  const { families: WORD_ROOTS } = useWordFamilies();
  const [rootId, setRootId] = useState(WORD_ROOTS[0].id);
  const [view, setView] = useState<ViewMode>("radial");
  const [posFilter, setPosFilter] = useState<WfPos | "all">("all");
  const [prefixFilter, setPrefixFilter] = useState<string | null>(null);
  const [levelFilter, setLevelFilter] = useState<WfLevel | "all">("all");
  const [memberQuery, setMemberQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const leitner = useLeitnerQueue();
  const detailRef = useRef<HTMLDivElement>(null);

  const roots = useMemo(() => searchRoots(query), [query]);
  const root = useMemo(
    () => WORD_ROOTS.find((r) => r.id === rootId) ?? WORD_ROOTS[0],
    [WORD_ROOTS, rootId],
  );

  const members = useMemo(() => {
    return root.members.filter((m) => {
      if (posFilter !== "all" && m.pos !== posFilter) return false;
      if (prefixFilter && m.prefix !== prefixFilter) return false;
      if (levelFilter !== "all" && m.cefr !== levelFilter) return false;
      const q = memberQuery.trim().toLowerCase();
      if (
        q &&
        !(
          m.word.toLowerCase().includes(q) ||
          m.meaningDe.toLowerCase().includes(q) ||
          m.meaningFa.includes(q)
        )
      )
        return false;
      return true;
    });
  }, [root, posFilter, prefixFilter, levelFilter, memberQuery]);

  const selected = useMemo(
    () => root.members.find((m) => m.id === selectedId) ?? null,
    [root, selectedId],
  );

  const openRoot = (id: string) => {
    setRootId(id);
    setSelectedId(null);
    setPrefixFilter(null);
    setMemberQuery("");
  };

  const selectMember = (m: FamilyMember) => {
    setSelectedId(m.id);
    // Bring the detail panel into view — otherwise the selection is invisible
    // below a long tree/graph and feels like "nothing happened".
    requestAnimationFrame(() => {
      detailRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  };

  const familyIds = root.members.map((m) => `wf:${m.id}`);
  const familyInLeitner = familyIds.every((id) => leitner.has(id));

  const activeFilters =
    (posFilter !== "all" ? 1 : 0) +
    (levelFilter !== "all" ? 1 : 0) +
    (prefixFilter ? 1 : 0) +
    (memberQuery.trim() ? 1 : 0);

  const resetFilters = () => {
    setPosFilter("all");
    setLevelFilter("all");
    setPrefixFilter(null);
    setMemberQuery("");
  };

  return (
    <div className="space-y-6">
      <SectionHero
        sectionKey="verbs"
        right={
          <div className="grid w-full grid-cols-3 gap-2 text-center sm:w-auto">
            <HeroStat value={String(WORD_ROOTS.length)} label="Wortstämme" />
            <HeroStat value={String(TOTAL_MEMBERS)} label="Wörter" />
            <HeroStat value="20+" label="Präfixe" />
          </div>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[300px_minmax(0,1fr)]">
        {/* Step 1 — choose a root */}
        <aside className="space-y-2 lg:sticky lg:top-4 lg:self-start">
          <StepLabel n={1} de="Wortstamm wählen" fa="ریشه را انتخاب کن" />
          <RootPicker
            roots={roots}
            activeId={root.id}
            query={query}
            onQuery={setQuery}
            onPick={openRoot}
          />
        </aside>

        <section className="min-w-0 space-y-4">
          {/* Step 2 — the root itself */}
          <StepLabel n={2} de="Wortfamilie ansehen" fa="خانوادهٔ واژه را ببین" />

          <div className="overflow-hidden rounded-3xl border border-border/60 bg-card">
            <div className="flex flex-wrap items-start justify-between gap-3 p-4 sm:p-5">
              <div className="min-w-0">
                <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                  Wortstamm
                </div>
                <h2 className="mt-0.5 flex flex-wrap items-baseline gap-2 text-3xl font-black">
                  <span className="font-mono">{root.root}-</span>
                  <span className="text-base font-bold text-muted-foreground">{root.label}</span>
                </h2>
                <div className="text-sm text-muted-foreground">{root.noteDe}</div>
                <FaHint className="mt-0.5">{root.noteFa}</FaHint>
              </div>
              <button
                type="button"
                onClick={() => leitner.addMany(familyIds, `${root.label} — Wortfamilie`)}
                disabled={familyInLeitner}
                className="inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold text-white transition disabled:opacity-60"
                style={{ background: "var(--section-primary)" }}
              >
                <Sparkles className="h-3.5 w-3.5" />
                {familyInLeitner ? "Familie gespeichert" : "Ganze Familie lernen"}
              </button>
            </div>

            {/* Prominent view switcher */}
            <div className="flex flex-wrap items-center gap-3 border-t border-border/60 bg-secondary/40 p-3 sm:px-5">
              <div className="grid flex-1 grid-cols-2 gap-2 sm:max-w-[380px]">
                <ViewButton
                  active={view === "radial"}
                  onClick={() => setView("radial")}
                  icon={<CircleDot className="h-5 w-5" />}
                  label="Netz"
                  hint="گرافی"
                />
                <ViewButton
                  active={view === "tree"}
                  onClick={() => setView("tree")}
                  icon={<ListTree className="h-5 w-5" />}
                  label="Baum"
                  hint="درختی"
                />
              </div>

              <div className="ml-auto flex items-center gap-2">
                <span className="text-[11px] font-bold text-muted-foreground">
                  {members.length} / {root.members.length} Wörter
                </span>
                <button
                  type="button"
                  onClick={() => setShowFilters((v) => !v)}
                  aria-expanded={showFilters}
                  className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition ${
                    showFilters || activeFilters > 0
                      ? "border-[color:var(--section-accent)] bg-card"
                      : "border-border/60 text-muted-foreground hover:bg-card"
                  }`}
                >
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                  Filter
                  {activeFilters > 0 && (
                    <span
                      className="rounded-full px-1.5 text-[10px] font-black text-white"
                      style={{ background: "var(--section-primary)" }}
                    >
                      {activeFilters}
                    </span>
                  )}
                </button>
              </div>
            </div>

            {showFilters && (
              <div className="space-y-2 border-t border-border/60 p-3 sm:px-5">
                <div className="flex flex-wrap items-center gap-1.5">
                  {POS_FILTERS.map((f) => (
                    <button
                      key={f}
                      type="button"
                      onClick={() => setPosFilter(f)}
                      className={`rounded-full border px-2.5 py-1 text-[11px] font-bold transition ${
                        posFilter === f
                          ? "border-[color:var(--section-accent)] bg-secondary"
                          : "border-border/60 text-muted-foreground hover:bg-secondary"
                      }`}
                    >
                      {f === "all" ? "Alle" : POS_LABEL[f].de}
                    </button>
                  ))}
                  {prefixFilter && (
                    <button
                      type="button"
                      onClick={() => setPrefixFilter(null)}
                      className="inline-flex items-center gap-1 rounded-full border border-[color:var(--section-accent)] bg-secondary px-2.5 py-1 text-[11px] font-bold"
                    >
                      Präfix: {prefixFilter}- <X className="h-3 w-3" />
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  {LEVELS.map((l) => (
                    <button
                      key={l}
                      type="button"
                      onClick={() => setLevelFilter(l)}
                      className={`rounded-lg border px-2 py-1 text-[10px] font-black transition ${
                        levelFilter === l
                          ? "border-[color:var(--section-accent)] bg-secondary"
                          : "border-border/60 text-muted-foreground hover:bg-secondary"
                      }`}
                    >
                      {l === "all" ? "Alle Niveaus" : l}
                    </button>
                  ))}
                  <SearchField
                    value={memberQuery}
                    onValueChange={setMemberQuery}
                    size="sm"
                    placeholder="In dieser Familie suchen…"
                    className="ml-auto min-w-[160px] flex-1 sm:flex-none"
                  />
                  {activeFilters > 0 && (
                    <button
                      type="button"
                      onClick={resetFilters}
                      className="rounded-lg px-2 py-1 text-[11px] font-bold text-muted-foreground underline-offset-2 hover:underline"
                    >
                      Zurücksetzen
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {members.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-border/60 p-8 text-center text-sm text-muted-foreground">
              Keine Wörter mit diesem Filter.
              <FaHint className="mt-1">با این فیلتر واژه‌ای پیدا نشد.</FaHint>
            </div>
          ) : view === "radial" ? (
            <FamilyGraph
              root={root}
              members={members}
              selectedId={selectedId}
              onSelect={selectMember}
            />
          ) : (
            <FamilyTree
              root={root}
              members={members}
              selectedId={selectedId}
              onSelect={selectMember}
            />
          )}

          {/* Step 3 — details */}
          <div ref={detailRef} className="scroll-mt-20 space-y-2">
            <StepLabel n={3} de="Wort im Detail" fa="جزئیات واژه" />
            <NodeDetailPanel
              member={selected}
              inLeitner={selected ? leitner.has(`wf:${selected.id}`) : false}
              onToggleLeitner={() => selected && leitner.toggle(`wf:${selected.id}`, selected.word)}
              onOpenFamily={openRoot}
              siblings={root.members}
              onSelect={selectMember}
            />
          </div>

          <PrefixTable
            activePrefix={prefixFilter}
            onPickPrefix={(p) => {
              setPrefixFilter(p || null);
              setShowFilters(true);
            }}
          />
        </section>
      </div>
    </div>
  );
}

function StepLabel({ n, de, fa }: { n: number; de: string; fa: string }) {
  return (
    <div className="flex items-center gap-2">
      <span
        className="grid h-5 w-5 place-items-center rounded-full text-[10px] font-black text-white"
        style={{ background: "var(--section-primary)" }}
      >
        {n}
      </span>
      <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
        {de}
      </span>
      <span className="text-[11px] text-muted-foreground" dir="rtl">
        {fa}
      </span>
    </div>
  );
}

function HeroStat({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-xl bg-white/15 px-3 py-2 backdrop-blur">
      <div className="text-lg font-black leading-none">{value}</div>
      <div className="mt-1 text-[10px] font-bold uppercase tracking-wider opacity-80">{label}</div>
    </div>
  );
}

function ViewButton({
  active,
  onClick,
  icon,
  label,
  hint,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  hint: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`inline-flex items-center justify-center gap-2 rounded-xl border-2 px-3 py-2.5 text-sm font-black transition ${
        active
          ? "border-transparent text-white shadow-md"
          : "border-border/60 bg-card text-muted-foreground hover:text-foreground"
      }`}
      style={active ? { background: "var(--section-primary)" } : undefined}
    >
      {icon}
      <span className="flex flex-col items-start leading-tight">
        {label}
        <span className="text-[10px] font-bold opacity-80" dir="rtl">
          {hint}
        </span>
      </span>
    </button>
  );
}
