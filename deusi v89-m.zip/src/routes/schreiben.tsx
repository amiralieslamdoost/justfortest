import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { FaHint } from "@/components/deusi/FaHint";
import { SectionHero } from "@/components/deusi/SectionHero";
import { useWritingSubmissions } from "@/lib/api/useWriting";
import {
  Sparkles,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  BookOpen,
  Clock,
  Type,
  ListChecks,
  Save,
  Lightbulb,
  Target,
} from "lucide-react";

export const Route = createFileRoute("/schreiben")({
  component: SchreibenPage,
  head: () => ({
    meta: [
      { title: "Schreiben üben — DEUSI" },
      {
        name: "description",
        content:
          "Deutsche Texte schreiben und sofort KI-Feedback erhalten — Grammatik, Stil, Wortschatz.",
      },
      { property: "og:title", content: "DEUSI — Schreiben üben" },
      { property: "og:description", content: "Schreib. Sende. Verbessere." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type Level = "A2" | "B1" | "B2" | "C1";
type Prompt = {
  id: string;
  level: Level;
  category: string;
  title: string;
  titleFa: string;
  task: string;
  minWords: number;
  checklist: string[];
  phrases: string[];
};

const LEVELS: Level[] = ["A2", "B1", "B2", "C1"];

const PROMPTS: Prompt[] = [
  {
    id: "p1",
    level: "A2",
    category: "E-Mail",
    title: "Absage einer Einladung",
    titleFa: "رد کردن یک دعوت",
    task: "Schreibe eine kurze E-Mail an eine Freundin und sage höflich ab. Nenne einen Grund und schlage einen neuen Termin vor.",
    minWords: 40,
    checklist: ["Anrede & Gruß", "Grund nennen", "Neuen Termin vorschlagen"],
    phrases: ["Liebe …,", "leider kann ich", "weil ich", "Wie wäre es mit", "Liebe Grüße"],
  },
  {
    id: "p2",
    level: "A2",
    category: "Bericht",
    title: "Mein Wochenende",
    titleFa: "تعریف آخر هفته",
    task: "Erzähle, was du am Wochenende gemacht hast. Schreibe im Perfekt und nenne mindestens drei Aktivitäten.",
    minWords: 50,
    checklist: ["Perfekt verwenden", "Drei Aktivitäten", "Eigene Meinung am Ende"],
    phrases: ["Am Samstag habe ich", "Danach bin ich", "Besonders schön war", "Am Ende"],
  },
  {
    id: "p3",
    level: "B1",
    category: "Beschwerde",
    title: "Beschwerde an ein Hotel",
    titleFa: "شکایت از هتل",
    task: "Du warst in einem Hotel und viele Dinge waren nicht in Ordnung. Schreibe eine formelle Beschwerde. Nenne 3 Probleme und deine Erwartung.",
    minWords: 80,
    checklist: [
      "Formelle Anrede",
      "Drei konkrete Probleme",
      "Klare Forderung",
      "Höflicher Schluss",
    ],
    phrases: [
      "Sehr geehrte Damen und Herren,",
      "leider musste ich feststellen",
      "Darüber hinaus",
      "Ich erwarte",
      "Mit freundlichen Grüßen",
    ],
  },
  {
    id: "p4",
    level: "B1",
    category: "Forum",
    title: "Handy in der Schule",
    titleFa: "موبایل در مدرسه",
    task: "Schreibe einen Forumsbeitrag: Sollten Handys in der Schule erlaubt sein? Begründe deine Meinung mit zwei Argumenten.",
    minWords: 100,
    checklist: ["Eigene Position", "Zwei Argumente", "Beispiel", "Fazit"],
    phrases: [
      "Meiner Meinung nach",
      "Einerseits …, andererseits",
      "Zum Beispiel",
      "Zusammenfassend",
    ],
  },
  {
    id: "p5",
    level: "B2",
    category: "Argumentation",
    title: "Homeoffice: Vor- und Nachteile",
    titleFa: "دورکاری",
    task: "Diskutiere Vor- und Nachteile des Arbeitens von zu Hause. Gib deine Meinung mit Begründung.",
    minWords: 150,
    checklist: ["Einleitung", "Pro-Argumente", "Contra-Argumente", "Begründete Meinung"],
    phrases: [
      "Ein wesentlicher Vorteil",
      "Dem steht gegenüber",
      "Hinzu kommt, dass",
      "Abschließend lässt sich sagen",
    ],
  },
  {
    id: "p6",
    level: "C1",
    category: "Erörterung",
    title: "KI im Bildungssystem",
    titleFa: "هوش مصنوعی در آموزش",
    task: "Erörtere den Einsatz von künstlicher Intelligenz an Schulen und Universitäten. Wäge Chancen und Risiken sorgfältig ab.",
    minWords: 220,
    checklist: [
      "These formulieren",
      "Chancen differenziert",
      "Risiken differenziert",
      "Synthese & Ausblick",
    ],
    phrases: [
      "Zunächst ist festzuhalten",
      "Nicht zu unterschätzen ist",
      "Kritisch anzumerken bleibt",
      "Vor diesem Hintergrund",
    ],
  },
];

type Issue = { type: "grammar" | "style" | "vocab"; text: string; suggestion: string };
type Feedback = {
  score: number;
  wordCount: number;
  strengths: string[];
  issues: Issue[];
  metrics: { label: string; value: number }[];
};

function stats(text: string) {
  const trimmed = text.trim();
  const words = trimmed ? trimmed.split(/\s+/).filter(Boolean) : [];
  const sentences = trimmed
    ? trimmed.split(/[.!?]+\s|[.!?]+$/).filter((s) => s.trim().length > 0)
    : [];
  const connectors = (
    trimmed.match(
      /\b(weil|denn|obwohl|damit|wenn|dass|deshalb|allerdings|jedoch|außerdem|zudem|dennoch|trotzdem)\b/gi,
    ) ?? []
  ).length;
  return {
    words: words.length,
    chars: trimmed.length,
    sentences: sentences.length,
    avgSentence: sentences.length ? Math.round(words.length / sentences.length) : 0,
    minutes: Math.max(1, Math.round(words.length / 90)),
    connectors,
  };
}

function analyze(text: string, prompt: Prompt): Feedback {
  const s = stats(text);
  const issues: Issue[] = [];
  const strengths: string[] = [];

  if (s.words >= prompt.minWords)
    strengths.push(`Angemessener Umfang (${s.words} Wörter, Ziel ${prompt.minWords}).`);
  if (s.sentences >= 4) strengths.push(`Guter Textaufbau mit ${s.sentences} Sätzen.`);
  if (s.connectors >= 3)
    strengths.push(`Flüssige Verknüpfung: ${s.connectors} Konnektoren gefunden.`);
  if (/,/.test(text)) strengths.push("Nebensätze mit Komma erkannt.");

  if (s.words < prompt.minWords) {
    issues.push({
      type: "style",
      text: "Der Text ist zu kurz.",
      suggestion: `Erweitere auf mindestens ${prompt.minWords} Wörter — noch ${prompt.minWords - s.words} fehlen.`,
    });
  }
  if ((text.match(/ ich /gi) ?? []).length > 4) {
    issues.push({
      type: "vocab",
      text: "Häufige Wiederholung von „ich“.",
      suggestion: "Variiere Satzanfänge: „Meiner Meinung nach …“, „Persönlich halte ich …“.",
    });
  }
  if (text.trim() && !/[A-ZÄÖÜ]/.test(text.trim().charAt(0))) {
    issues.push({
      type: "grammar",
      text: "Erster Buchstabe kleingeschrieben.",
      suggestion: "Beginne Sätze mit einem Großbuchstaben.",
    });
  }
  if (s.connectors < 2 && prompt.level !== "A2") {
    issues.push({
      type: "style",
      text: "Wenige Konnektoren.",
      suggestion: "Nutze „weil“, „obwohl“, „deshalb“ für eine flüssigere Argumentation.",
    });
  }
  if (/\.\s+[a-zäöü]/.test(text)) {
    issues.push({
      type: "grammar",
      text: "Nach einem Punkt folgt ein Kleinbuchstabe.",
      suggestion: "Nach dem Satzende immer großschreiben.",
    });
  }
  if (s.avgSentence > 28) {
    issues.push({
      type: "style",
      text: "Sehr lange Sätze.",
      suggestion: "Teile lange Sätze — im Schnitt sind 12–20 Wörter gut lesbar.",
    });
  }
  if (!/[.!?]/.test(text)) {
    issues.push({
      type: "grammar",
      text: "Keine Satzzeichen erkannt.",
      suggestion: "Setze Punkte, Fragezeichen oder Ausrufezeichen.",
    });
  }

  const pct = (v: number) => Math.max(20, Math.min(100, Math.round(v)));
  const metrics = [
    { label: "Umfang", value: pct((s.words / prompt.minWords) * 100) },
    { label: "Struktur", value: pct(s.sentences * 18) },
    { label: "Verknüpfung", value: pct(s.connectors * 28) },
    {
      label: "Korrektheit",
      value: pct(100 - issues.filter((i) => i.type === "grammar").length * 22),
    },
  ];
  const score = Math.round(metrics.reduce((a, m) => a + m.value, 0) / metrics.length);

  return {
    score: Math.max(30, Math.min(100, score)),
    wordCount: s.words,
    strengths,
    issues,
    metrics,
  };
}

function taskTypeOf(prompt: Prompt): "email" | "essay" | "letter" | "description" | "free" {
  const c = `${prompt.category}`.toLowerCase();
  if (c.includes("mail")) return "email";
  if (c.includes("brief") || c.includes("letter")) return "letter";
  if (c.includes("essay") || c.includes("erört")) return "essay";
  if (c.includes("beschreib") || c.includes("descri")) return "description";
  return "free";
}

function SchreibenPage() {
  const [level, setLevel] = useState<Level | "Alle">("Alle");
  const [prompt, setPrompt] = useState<Prompt>(PROMPTS[2]);
  const [text, setText] = useState("");
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [saved, setSaved] = useState(false);
  const { submissions, saveDraft, submit } = useWritingSubmissions();

  const visible = useMemo(
    () => (level === "Alle" ? PROMPTS : PROMPTS.filter((p) => p.level === level)),
    [level],
  );

  // Restore a saved draft when switching tasks
  useEffect(() => {
    setText(submissions[prompt.id]?.body ?? "");
    setFeedback(null);
    setSaved(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prompt.id]);

  // Autosave
  useEffect(() => {
    if (!text) return;
    const t = setTimeout(() => {
      saveDraft({
        promptId: prompt.id,
        title: prompt.title,
        body: text,
        level: prompt.level,
        taskType: taskTypeOf(prompt),
        wordCount: stats(text).words,
        status: "draft",
        score: 0,
        feedback: null,
      });
      setSaved(true);
    }, 700);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, prompt.id]);

  const s = stats(text);
  const progress = Math.min(100, Math.round((s.words / prompt.minWords) * 100));

  const insert = (phrase: string) =>
    setText((prev) => (prev ? `${prev.replace(/\s+$/, "")} ${phrase} ` : `${phrase} `));

  return (
    <div className="space-y-6">
      <SectionHero sectionKey="writing" />

      <div className="grid gap-5 lg:grid-cols-[300px_minmax(0,1fr)]">
        {/* ---------- Task picker ---------- */}
        <aside className="space-y-4">
          <div className="glass-strong rounded-3xl p-4">
            <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
              Themen
            </div>
            <FaHint>موضوعات نوشتاری</FaHint>

            <div className="mt-3 flex flex-wrap gap-1.5">
              {(["Alle", ...LEVELS] as const).map((lv) => (
                <button
                  key={lv}
                  onClick={() => setLevel(lv)}
                  className={`rounded-full px-3 py-1 text-[11px] font-bold transition ${
                    level === lv
                      ? "text-white shadow-sm"
                      : "bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                  style={level === lv ? { background: "var(--section-primary)" } : undefined}
                >
                  {lv}
                </button>
              ))}
            </div>

            <div className="mt-3 space-y-2">
              {visible.map((p) => {
                const active = p.id === prompt.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => setPrompt(p)}
                    className={`w-full rounded-2xl border px-3 py-2.5 text-left transition ${
                      active
                        ? "bg-secondary shadow-sm"
                        : "border-border/60 bg-card hover:bg-secondary"
                    }`}
                    style={active ? { borderColor: "var(--section-primary)" } : undefined}
                  >
                    <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                      <span className="truncate">{p.category}</span>
                      <span className="shrink-0 rounded-full bg-secondary px-1.5 py-0.5">
                        {p.level}
                      </span>
                    </div>
                    <div className="mt-1 truncate text-sm font-semibold">{p.title}</div>
                    <div className="mt-0.5 text-[11px] text-muted-foreground">
                      {p.minWords}+ Wörter
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="glass-strong rounded-3xl p-4">
            <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
              <Lightbulb className="h-3.5 w-3.5" /> Schreibtipp
            </div>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Plane zuerst 3 Stichpunkte, schreibe dann durchgehend — korrigiere erst am Ende.
            </p>
            <FaHint>اول سه نکته یادداشت کن، بعد یک‌نفس بنویس و در پایان ویرایش کن.</FaHint>
          </div>
        </aside>

        {/* ---------- Editor ---------- */}
        <section className="space-y-4">
          <div className="glass-strong rounded-3xl p-5 sm:p-6">
            <div className="flex items-start gap-3">
              <div
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl"
                style={{
                  background: "color-mix(in oklab, var(--section-primary) 14%, transparent)",
                  color: "var(--section-primary)",
                }}
              >
                <BookOpen className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                  Aufgabe · {prompt.level} · {prompt.category}
                </div>
                <h2 className="mt-0.5 text-lg font-bold">{prompt.title}</h2>
                <FaHint>{prompt.titleFa}</FaHint>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{prompt.task}</p>

                <ul className="mt-3 flex flex-wrap gap-1.5">
                  {prompt.checklist.map((c) => (
                    <li
                      key={c}
                      className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-2.5 py-1 text-[11px] font-semibold text-muted-foreground"
                    >
                      <ListChecks className="h-3 w-3" /> {c}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="glass-strong rounded-3xl p-5 sm:p-6">
            {/* Live stats */}
            <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <StatChip
                icon={<Type className="h-3.5 w-3.5" />}
                label="Wörter"
                value={`${s.words}`}
              />
              <StatChip
                icon={<Target className="h-3.5 w-3.5" />}
                label="Ziel"
                value={`${prompt.minWords}`}
              />
              <StatChip
                icon={<ListChecks className="h-3.5 w-3.5" />}
                label="Sätze"
                value={`${s.sentences}`}
              />
              <StatChip
                icon={<Clock className="h-3.5 w-3.5" />}
                label="Lesezeit"
                value={`${s.minutes} Min`}
              />
            </div>

            <div className="mb-3 h-1.5 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${progress}%`,
                  background:
                    "linear-gradient(90deg, var(--section-primary), var(--section-accent))",
                }}
              />
            </div>

            <textarea
              value={text}
              onChange={(e) => {
                setText(e.target.value);
                setSaved(false);
              }}
              placeholder="Schreibe deinen Text hier…"
              className="min-h-[260px] w-full resize-y rounded-2xl border border-border/60 bg-card p-4 text-sm leading-relaxed outline-none focus:ring-2"
              style={{
                ["--tw-ring-color" as never]:
                  "color-mix(in oklab, var(--section-primary) 45%, transparent)",
              }}
            />

            {/* Phrase helpers */}
            <div className="mt-3 flex flex-wrap gap-1.5">
              {prompt.phrases.map((p) => (
                <button
                  key={p}
                  onClick={() => insert(p)}
                  className="rounded-full border border-border/60 bg-card px-2.5 py-1 text-[11px] font-semibold text-muted-foreground transition hover:bg-secondary hover:text-foreground"
                >
                  + {p}
                </button>
              ))}
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              <div className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                <Save className="h-3.5 w-3.5" />
                {saved
                  ? "Entwurf gespeichert"
                  : text
                    ? "Wird gespeichert …"
                    : "Automatisches Speichern aktiv"}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setText("");
                    setFeedback(null);
                  }}
                  className="inline-flex items-center gap-2 rounded-xl border border-border/60 bg-card px-4 py-2 text-sm font-semibold hover:bg-secondary"
                >
                  <RefreshCw className="h-4 w-4" /> Zurücksetzen
                </button>
                <button
                  disabled={text.trim().length < 20}
                  onClick={() => {
                    const fb = analyze(text, prompt);
                    setFeedback(fb);
                    submit({
                      promptId: prompt.id,
                      title: prompt.title,
                      body: text,
                      level: prompt.level,
                      taskType: taskTypeOf(prompt),
                      wordCount: stats(text).words,
                      score: fb.score ?? 0,
                      feedback: fb as unknown as Record<string, unknown>,
                    });
                  }}
                  className="inline-flex items-center gap-2 rounded-xl px-5 py-2 text-sm font-bold text-white shadow-lg transition disabled:opacity-40"
                  style={{
                    background:
                      "linear-gradient(135deg, var(--section-primary), var(--section-accent))",
                  }}
                >
                  <Sparkles className="h-4 w-4" /> KI-Feedback
                </button>
              </div>
            </div>
          </div>

          {feedback && (
            <div className="glass-strong rounded-3xl p-5 sm:p-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                    Bewertung
                  </div>
                  <h3 className="mt-1 text-lg font-bold">Dein Feedback</h3>
                  <FaHint>بازخورد متن تو</FaHint>
                </div>
                <div
                  className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-xl font-black text-white"
                  style={{
                    background:
                      "linear-gradient(135deg, var(--section-primary), var(--section-accent))",
                  }}
                >
                  {feedback.score}
                </div>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {feedback.metrics.map((m) => (
                  <div key={m.label}>
                    <div className="mb-1 flex items-center justify-between text-xs font-semibold">
                      <span className="text-muted-foreground">{m.label}</span>
                      <span className="tabular-nums">{m.value}%</span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full"
                        style={{ width: `${m.value}%`, background: "var(--section-primary)" }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {feedback.strengths.length > 0 && (
                <div className="mt-5">
                  <div className="mb-2 text-xs font-bold uppercase tracking-wider text-emerald-500">
                    Stärken
                  </div>
                  <ul className="space-y-1.5">
                    {feedback.strengths.map((st, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                        <span>{st}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {feedback.issues.length > 0 && (
                <div className="mt-5">
                  <div className="mb-2 text-xs font-bold uppercase tracking-wider text-amber-500">
                    Verbesserungen
                  </div>
                  <ul className="space-y-2">
                    {feedback.issues.map((iss, i) => (
                      <li
                        key={i}
                        className="rounded-2xl border border-border/60 bg-secondary/60 p-3"
                      >
                        <div className="flex items-start gap-2">
                          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
                          <div className="min-w-0">
                            <div className="text-sm font-semibold">
                              <span className="mr-2 rounded bg-secondary px-1.5 py-0.5 text-[10px] uppercase tracking-wider">
                                {iss.type}
                              </span>
                              {iss.text}
                            </div>
                            <div className="mt-1 text-xs text-muted-foreground">
                              {iss.suggestion}
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function StatChip({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2 rounded-2xl bg-secondary/60 px-3 py-2">
      <span className="text-muted-foreground">{icon}</span>
      <span className="min-w-0">
        <span className="block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <span className="block text-sm font-bold tabular-nums">{value}</span>
      </span>
    </div>
  );
}
