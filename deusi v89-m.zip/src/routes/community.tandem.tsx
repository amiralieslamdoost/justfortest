import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CommunityNav } from "@/components/deusi/community/CommunityNav";
import { TandemList } from "@/components/deusi/community/TandemList";
import { TandemAdModal } from "@/components/deusi/community/TandemAdModal";
import { useCommunity } from "@/lib/deusi/community/store";

const TITLE = "Sprechpartner finden — Community | DEUSI";
const DESC =
  "Gib eine eigene Anzeige auf oder antworte auf Anzeigen und finde deinen Tandem-Partner zum Deutschsprechen.";

export const Route = createFileRoute("/community/tandem")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TandemPage,
});

function TandemPage() {
  const { createAd } = useCommunity();
  const [open, setOpen] = useState(false);

  return (
    <div className="space-y-4 pb-16">
      <CommunityNav />
      <TandemList onCreate={() => setOpen(true)} />

      <TandemAdModal
        open={open}
        onClose={() => setOpen(false)}
        onCreate={(input) => {
          createAd(input);
          setOpen(false);
        }}
      />
    </div>
  );
}
