import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ExternalLink } from "lucide-react";
import { getExam } from "@/lib/deusi/exams/mockExams";
import { DownloadButton } from "@/components/deusi/exams/DownloadButton";
import { useExamDetail } from "@/lib/api/useExams";
import {
  Books,
  Centers,
  Experiences,
  FAQSection,
  Hero,
  Overview,
  PlanSection,
  Practice,
  QuickCentersCard,
  QuickFacts,
  Resources,
  StickyTabs,
  StructureCard,
} from "@/components/deusi/exams/ExamDetailsSections";

export const Route = createFileRoute("/pruefungen/$examId")({
  component: ExamDetailsPage,
  loader: ({ params }) => {
    const exam = getExam(params.examId);
    if (!exam) throw notFound();
    return { exam };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Prüfung nicht verfügbar | DEUSI" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const e = loaderData.exam;
    const title = `${e.name} – Bücher, Modelltests & Vorbereitung | DEUSI`;
    const description = `${e.description} Alle Bücher, Ressourcen, Modelltests, Erfahrungsberichte und Prüfungszentren für ${e.name} an einem Ort.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
      <h1 className="text-xl font-bold">Prüfung nicht gefunden</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Diese Prüfung existiert nicht oder ist noch nicht verfügbar.
      </p>
      <Link
        to="/pruefungen"
        className="mt-6 inline-block rounded-full bg-foreground px-5 py-2 text-xs font-semibold text-background"
      >
        Zurück zur Übersicht
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
      <h1 className="text-xl font-bold">Ein Fehler ist aufgetreten</h1>
      <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
    </div>
  ),
});

function ExamDetailsPage() {
  const { exam: fallbackExam } = Route.useLoaderData();
  const { exam: liveExam } = useExamDetail(fallbackExam.id, fallbackExam);
  const exam = liveExam ?? fallbackExam;

  return (
    <div className="space-y-5 pb-16 sm:space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <Link to="/pruefungen" className="btn-back">
          <span aria-hidden>←</span> Zurück
        </Link>
        <div className="flex flex-1 flex-wrap items-center justify-end gap-2">
          <a
            href={exam.officialWebsite}
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex items-center gap-1.5 rounded-full border border-border/70 bg-card/60 px-4 py-2 text-xs font-semibold transition hover:border-[color:var(--section-primary)]/50"
          >
            <ExternalLink className="h-4 w-4 shrink-0" aria-hidden /> Offizielle Website
          </a>
          <DownloadButton
            title={`${exam.shortName} Komplettpaket`}
            note="Bücher, Ressourcen und Modelltests"
            label="Alle Materialien"
          />
        </div>
      </div>
      <Hero exam={exam} />
      <StickyTabs />
      <div className="grid grid-cols-[minmax(0,1fr)] gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="min-w-0 space-y-6">
          <Overview exam={exam} />
          <Books exam={exam} />
          <Resources resources={exam.resources} />
          <Practice exam={exam} files={exam.practice} />
          <PlanSection exam={exam} />
          <Experiences items={exam.experiences} />
          <Centers centers={exam.centers} />
          <FAQSection faq={exam.faq} />
        </div>
        <div className="min-w-0 space-y-6 xl:sticky xl:top-20 xl:self-start">
          <StructureCard exam={exam} />
          <QuickFacts exam={exam} />
          <QuickCentersCard centers={exam.centers} />
        </div>
      </div>
    </div>
  );
}
