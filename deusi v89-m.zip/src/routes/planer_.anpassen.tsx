import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { PlannerSubPage } from "@/components/deusi/planner/PlannerSubPage";
import { PlannerSetup } from "@/components/deusi/planner/PlannerSetup";
import { usePlanner } from "@/lib/deusi/planner/usePlanner";

const TITLE = "Plan anpassen — DEUSI Smart Planner";
const DESCRIPTION =
  "Passe Niveau, Ziele, Lernzeit und Intensität an — DEUSI plant deine Woche danach neu.";

export const Route = createFileRoute("/planer_/anpassen")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PlannerSettingsPage,
});

function PlannerSettingsPage() {
  const planner = usePlanner();
  const navigate = useNavigate();
  const back = () => void navigate({ to: "/planer" });

  return (
    <PlannerSubPage
      title="Plan anpassen"
      titleFa="تنظیم برنامه"
      intro="Deine Angaben steuern, wie DEUSI die Woche verteilt. Nach dem Speichern wird die Woche neu geplant."
      introFa="این تنظیمات تعیین می‌کند که DEUSI چطور هفته‌ات را بچیند. بعد از ذخیره، برنامه‌ی هفته دوباره ساخته می‌شود."
    >
      <PlannerSetup
        prefs={planner.prefs}
        busy={planner.busy}
        submitLabel="Speichern & neu planen"
        onCancel={back}
        onSubmit={(input) => {
          void planner.savePrefs(input).then(back);
        }}
      />
    </PlannerSubPage>
  );
}
