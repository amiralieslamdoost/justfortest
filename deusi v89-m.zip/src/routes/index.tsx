import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect } from "react";
import { motion, useScroll, useSpring } from "framer-motion";

import { useDeusi } from "@/lib/deusi/store";
import { CursorSpotlight } from "@/components/deusi/landing/CursorSpotlight";
import { Nav } from "@/components/deusi/landing/Nav";
import { Hero } from "@/components/deusi/landing/Hero";
import { Manifest } from "@/components/deusi/landing/Manifest";
import { Marquee } from "@/components/deusi/landing/Marquee";
import { HorizontalFeatures } from "@/components/deusi/landing/HorizontalFeatures";
import { Features } from "@/components/deusi/landing/Features";
import { DeepDive } from "@/components/deusi/landing/DeepDive";
import { AppShowcase } from "@/components/deusi/landing/AppShowcase";
import { FlashcardShowcase } from "@/components/deusi/landing/FlashcardShowcase";
import { Stats } from "@/components/deusi/landing/Stats";
import { Journey } from "@/components/deusi/landing/Journey";
import { Pricing } from "@/components/deusi/landing/Pricing";
import { Testimonials } from "@/components/deusi/landing/Testimonials";
import { FinalCTA } from "@/components/deusi/landing/FinalCTA";
import { Footer } from "@/components/deusi/landing/Footer";
import { JsonLd, organizationJsonLd, websiteJsonLd } from "@/components/deusi/JsonLd";

const TITLE = "DEUSI — Deutsch lernen mit Leitner & FSRS";
const DESCRIPTION =
  "DEUSI ist die Lernplattform für Deutsch: Leitner-Boxen, FSRS-Wiederholung, Grammatik, Lesen, Prüfungen und ein KI-Coach — mit persischer Hilfe.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { currentUser } = useDeusi();
  const router = useRouter();
  useEffect(() => {
    if (currentUser) router.navigate({ to: "/dashboard" });
  }, [currentUser, router]);

  const { scrollYProgress } = useScroll();
  const barScale = useSpring(scrollYProgress, { stiffness: 140, damping: 30, restDelta: 0.001 });

  return (
    <div className="relative overflow-x-clip">
      <JsonLd data={organizationJsonLd} />
      <JsonLd data={websiteJsonLd} />
      {/* Scroll progress bar */}
      <motion.div
        aria-hidden
        style={{ scaleX: barScale, transformOrigin: "0% 50%" }}
        className="fixed inset-x-0 top-0 z-[60] h-[3px]"
      >
        <div
          className="h-full w-full"
          style={{ background: "linear-gradient(90deg, #1a1a1a, #DD2222 45%, #F7C948)" }}
        />
      </motion.div>

      <CursorSpotlight />
      <Nav />
      <Hero />
      <Manifest />
      <Marquee />
      <HorizontalFeatures />
      <Features />
      <DeepDive />
      <AppShowcase />
      <FlashcardShowcase />
      <Stats />
      <Journey />
      <Pricing />
      <Testimonials />
      <FinalCTA />

      <Footer />
    </div>
  );
}
