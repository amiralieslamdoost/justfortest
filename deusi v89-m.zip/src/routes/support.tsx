import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { sendContactMessage } from "@/lib/api/support";
import { useCurrentUserId } from "@/lib/api/useExams";
import { motion, AnimatePresence } from "framer-motion";
import {
  LifeBuoy,
  Mail,
  MessageCircle,
  BookOpen,
  Bug,
  Search,
  ChevronDown,
  Send,
  Sparkles,
  ExternalLink,
  Github,
  Twitter,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { SearchField } from "@/components/deusi/SearchField";

export const Route = createFileRoute("/support")({
  head: () => ({
    meta: [
      { title: "Hilfe & Support · DEUSI" },
      { name: "description", content: "FAQ, Kontakt und Fehlermeldung — wir sind für dich da." },
    ],
  }),
  component: SupportPage,
});

const FAQ = [
  {
    q: "Wie funktioniert das Leitner-Box-System?",
    fa: "سیستم جعبه لایتنر چطور کار می‌کند؟",
    a: "Jede Karte wandert bei richtiger Antwort in eine höhere Box (längeres Intervall). Falsche Antworten werfen die Karte zurück in Box 1. So wiederholst du genau das, was du brauchst.",
  },
  {
    q: "Kann ich DEUSI offline nutzen?",
    fa: "میشه از دِیوزی آفلاین استفاده کرد؟",
    a: "Ja — DEUSI Plus und Pro unterstützen Offline-Modus auf mobilen Geräten. Karten, Podcasts und Artikel werden lokal zwischengespeichert.",
  },
  {
    q: "Wie kündige ich mein Abo?",
    fa: "چطور اشتراکم رو لغو کنم؟",
    a: "Öffne Einstellungen → Abonnement → Abo kündigen. Dein Zugriff bleibt bis zum Ende der bezahlten Periode aktiv.",
  },
  {
    q: "Werden meine Lerndaten mit Dritten geteilt?",
    fa: "آیا داده‌های یادگیری‌ام با کسی به‌اشتراک گذاشته می‌شود؟",
    a: "Nein. Lerndaten sind privat und werden nur zur Personalisierung deines Erlebnisses verwendet. Details findest du in der Datenschutzerklärung.",
  },
  {
    q: "Auf welchen Geräten kann ich DEUSI verwenden?",
    fa: "روی چه دستگاه‌هایی می‌تونم استفاده کنم؟",
    a: "Web (Desktop & mobil), iOS und Android. Dein Fortschritt synchronisiert automatisch.",
  },
  {
    q: "Wie melde ich einen Fehler?",
    fa: "چطور یک باگ گزارش بدم؟",
    a: "Verwende das Formular auf dieser Seite (Kategorie \u201eFehler melden\u201c) oder schreibe uns direkt an support@deusi.app.",
  },
];

function SupportPage() {
  return (
    <div className="space-y-6 pb-10 animate-fade">
      <MiniHero />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <QuickCard
          Icon={Mail}
          title="E-Mail"
          fa="ایمیل"
          desc="support@deusi.app"
          href="mailto:support@deusi.app"
        />
        <QuickCard
          Icon={MessageCircle}
          title="Live-Chat"
          fa="چت زنده"
          desc="Mo–Fr, 9–18 Uhr"
          badge="Online"
        />
        <QuickCard
          Icon={BookOpen}
          title="Handbuch"
          fa="راهنما"
          desc="Alle Features erklärt"
          href="/docs"
        />
      </div>

      <FaqSection />

      <ContactForm />
    </div>
  );
}

function QuickCard({
  Icon,
  title,
  fa,
  desc,
  href,
  badge,
}: {
  Icon: typeof Mail;
  title: string;
  fa: string;
  desc: string;
  href?: string;
  badge?: string;
}) {
  const inner = (
    <div className="group relative h-full overflow-hidden rounded-3xl border border-border bg-card p-5 shadow-[0_1px_2px_rgba(0,0,0,0.04),0_18px_40px_-28px_rgba(0,0,0,0.35)] transition hover:-translate-y-1 hover:border-foreground/20 hover:shadow-[0_1px_2px_rgba(0,0,0,0.05),0_26px_50px_-24px_rgba(0,0,0,0.4)]">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-10 -top-12 h-32 w-32 rounded-full bg-[#2adfd2]/20 blur-2xl transition-opacity group-hover:opacity-80"
      />
      <div className="relative flex items-start gap-3">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[#0a746b] to-[#2adfd2] text-white shadow-lg shadow-[#0a746b]/25">
          <Icon className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-black">{title}</h3>
            {badge && (
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                {badge}
              </span>
            )}
          </div>
          <FaHint size="sm">{fa}</FaHint>
          <p className="mt-1.5 truncate text-xs font-medium text-muted-foreground">{desc}</p>
        </div>
        {href && (
          <ExternalLink className="h-4 w-4 shrink-0 text-foreground/35 transition group-hover:translate-x-0.5 group-hover:text-foreground" />
        )}
      </div>
    </div>
  );
  return href ? (
    <a href={href} className="block h-full">
      {inner}
    </a>
  ) : (
    inner
  );
}

function FaqSection() {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<number | null>(0);
  const filtered = FAQ.filter(
    (f) => !q || (f.q + f.a + f.fa).toLowerCase().includes(q.toLowerCase()),
  );
  return (
    <section className="glass-strong rounded-[28px] p-5 sm:p-6">
      <header className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5" />
          <div>
            <h2 className="text-sm font-bold">Häufig gestellte Fragen</h2>
            <FaHint>سؤال‌های پرتکرار</FaHint>
          </div>
        </div>
        <SearchField
          value={q}
          onValueChange={setQ}
          placeholder="In FAQ suchen…"
          className="w-full sm:w-72"
        />
      </header>

      <div className="divide-y divide-border">
        {filtered.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={f.q} className="py-2">
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex w-full items-center gap-3 py-2 text-left"
              >
                <span className="flex-1">
                  <span className="text-sm font-semibold">{f.q}</span>
                  <FaHint>{f.fa}</FaHint>
                </span>
                <ChevronDown
                  className={`h-4 w-4 shrink-0 text-foreground/60 transition ${isOpen ? "rotate-180" : ""}`}
                />
              </button>
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.p
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.22 }}
                    className="overflow-hidden pb-3 text-sm text-foreground/75"
                  >
                    {f.a}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="py-6 text-center text-sm text-muted-foreground">
            Keine passende Antwort — schreib uns unten. <FaHint>سؤالت را برای ما بفرست</FaHint>
          </div>
        )}
      </div>
    </section>
  );
}

function ContactForm() {
  const [cat, setCat] = useState<"frage" | "fehler" | "vorschlag" | "abrechnung">("frage");
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const userId = useCurrentUserId();
  const field = (k: keyof typeof form) => ({
    value: form[k],
    onChange: (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value })),
  });
  return (
    <section className="glass-strong rounded-[28px] p-5 sm:p-6">
      <header className="mb-4 flex items-center gap-2">
        <LifeBuoy className="h-5 w-5" />
        <div>
          <h2 className="text-sm font-bold">Wir helfen dir persönlich</h2>
          <FaHint>ما شخصاً کمکت می‌کنیم</FaHint>
        </div>
      </header>

      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {(
          [
            { k: "frage", l: "Frage", Icon: MessageCircle, fa: "پرسش" },
            { k: "fehler", l: "Fehler", Icon: Bug, fa: "باگ" },
            { k: "vorschlag", l: "Vorschlag", Icon: Sparkles, fa: "پیشنهاد" },
            { k: "abrechnung", l: "Abrechnung", Icon: Mail, fa: "پرداخت" },
          ] as const
        ).map((t) => (
          <button
            key={t.k}
            onClick={() => setCat(t.k)}
            className={`flex flex-col items-start gap-1 rounded-2xl border p-3 text-left transition ${
              cat === t.k
                ? "border-foreground bg-foreground/5"
                : "border-border hover:border-foreground/30"
            }`}
          >
            <t.Icon className="h-4 w-4" />
            <span className="text-sm font-semibold">{t.l}</span>
            <FaHint>{t.fa}</FaHint>
          </button>
        ))}
      </div>

      {sent ? (
        <div className="grid place-items-center gap-2 rounded-2xl border border-emerald-500/25 bg-emerald-500/5 py-10 text-center">
          <div className="text-2xl">✓</div>
          <div className="text-sm font-bold text-emerald-700">
            Wir haben deine Nachricht erhalten.
          </div>
          <FaHint>پیام تو رسید — به‌زودی پاسخ می‌دیم.</FaHint>
        </div>
      ) : (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (sending) return;
            setSending(true);
            setError(null);
            try {
              await sendContactMessage({ ...form, topic: cat, userId: userId || undefined });
              setSent(true);
            } catch {
              setError("Nachricht konnte nicht gesendet werden. Bitte später erneut versuchen.");
            } finally {
              setSending(false);
            }
          }}
          className="space-y-3"
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Name
              </span>
              <input
                required
                {...field("name")}
                className="w-full rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none focus:border-foreground/40"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
                E-Mail
              </span>
              <input
                required
                type="email"
                {...field("email")}
                className="w-full rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none focus:border-foreground/40"
              />
            </label>
          </div>
          <label className="block">
            <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Betreff
            </span>
            <input
              required
              {...field("subject")}
              className="w-full rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none focus:border-foreground/40"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Nachricht
            </span>
            <textarea
              required
              rows={5}
              {...field("message")}
              className="w-full resize-none rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm outline-none focus:border-foreground/40"
            />
          </label>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-foreground/60">
              <a
                href="https://x.com/deusi_app"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="DEUSI auf X"
                className="grid h-11 w-11 place-items-center rounded-lg hover:bg-foreground/5"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="https://github.com/deusi-app"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="DEUSI auf GitHub"
                className="grid h-11 w-11 place-items-center rounded-lg hover:bg-foreground/5"
              >
                <Github className="h-4 w-4" />
              </a>
            </div>
            <button
              type="submit"
              disabled={sending}
              className="inline-flex items-center gap-1.5 rounded-xl bg-foreground px-4 py-2 text-sm font-bold text-background transition hover:opacity-90 disabled:opacity-60"
            >
              <Send className="h-4 w-4" /> {sending ? "Senden …" : "Absenden"}
            </button>
          </div>
          {error ? <p className="text-xs font-semibold text-red-500">{error}</p> : null}
          <input type="hidden" value={cat} />
        </form>
      )}
    </section>
  );
}

function MiniHero() {
  const base = "#02332f",
    primary = "#0a746b",
    accent = "#2adfd2";
  return (
    <header
      className="relative overflow-hidden rounded-[2rem] p-6 text-white shadow-2xl sm:p-8"
      style={{
        backgroundImage: [
          `radial-gradient(110% 130% at 88% -20%, ${accent}66 0%, transparent 55%)`,
          `radial-gradient(90% 120% at 0% 115%, ${primary} 0%, transparent 60%)`,
          `linear-gradient(135deg, ${base} 0%, ${primary} 55%, ${accent} 130%)`,
        ].join(", "),
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/12 blur-3xl" />
        <div
          className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
          style={{ backgroundColor: accent, opacity: 0.35 }}
        />
        <motion.div
          className="absolute -inset-x-1/2 -top-1/2 h-[200%] w-[45%] rotate-12 bg-gradient-to-r from-transparent via-white/10 to-transparent"
          animate={{ x: ["-20%", "240%"] }}
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut", repeatDelay: 3 }}
        />
      </div>

      <div className="relative grid gap-6 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center">
        <div className="flex min-w-0 items-start gap-4">
          <div
            className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/40 sm:h-16 sm:w-16"
            style={{ color: primary }}
          >
            <LifeBuoy className="h-8 w-8" />
          </div>
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
              <Sparkles className="h-3 w-3" aria-hidden />
              Hilfe & Support
            </div>
            <h1 className="mt-2 text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
              Wir sind{" "}
              <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
                für dich da
              </span>
            </h1>
            <FaHint className="!text-white/85 !opacity-100">ما در کنارت هستیم</FaHint>
            <p className="mt-2 max-w-2xl text-sm text-white/80">
              Antworten aus der FAQ, direkter Kontakt oder Fehlermeldung.
            </p>
            <FaHint className="!text-white/75 !opacity-100">
              پاسخ‌های پرتکرار، تماس مستقیم یا گزارش خطا.
            </FaHint>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 rounded-2xl bg-white/12 p-3 backdrop-blur lg:min-w-[300px]">
          <HeroStat value="< 4 Std." label="Antwortzeit" />
          <HeroStat value="24/7" label="Hilfe-Center" />
          <HeroStat value="98%" label="Gelöst" />
        </div>
      </div>
    </header>
  );
}

function HeroStat({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center">
      <div className="text-sm font-black leading-tight sm:text-base">{value}</div>
      <div className="mt-0.5 text-[9px] font-semibold uppercase tracking-wider text-white/70">
        {label}
      </div>
    </div>
  );
}
