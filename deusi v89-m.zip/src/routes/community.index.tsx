import { createFileRoute } from "@tanstack/react-router";
import { MessagesSquare } from "lucide-react";
import { CommunityShell } from "@/components/deusi/community/CommunityShell";
import { FaHint } from "@/components/deusi/FaHint";

const TITLE = "Community — Chats für Deutschlernende | DEUSI";
const DESC =
  "Chatte in öffentlichen Talaren, gründe eigene Lerngruppen und schreibe privat mit anderen Deutschlernenden.";

export const Route = createFileRoute("/community/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CommunityIndex,
});

function CommunityIndex() {
  return (
    <CommunityShell showListOnMobile>
      <div className="neu-card grid h-full place-items-center p-10 text-center">
        <div>
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[color:var(--section-primary,#c2410c)]/10 text-[color:var(--section-primary,#c2410c)]">
            <MessagesSquare className="h-6 w-6" aria-hidden />
          </div>
          <h2 className="mt-3 text-base font-black">Wähle einen Chat</h2>
          <p className="mt-1 max-w-xs text-sm text-muted-foreground">
            Talare sind für alle offen, Gruppen für deine Freunde, private Chats nur für euch zwei.
          </p>
          <FaHint size="sm">یک گفت‌وگو را انتخاب کن</FaHint>
        </div>
      </div>
    </CommunityShell>
  );
}
