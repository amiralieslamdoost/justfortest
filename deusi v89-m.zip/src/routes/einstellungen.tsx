import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Settings2,
  User,
  Bell,
  Shield,
  Palette,
  Languages,
  KeyRound,
  Check,
  ChevronRight,
} from "lucide-react";
import { FaHint } from "@/components/deusi/FaHint";
import { SearchField } from "@/components/deusi/SearchField";
import { MiniHero, GhostBtn, PrimaryBtn } from "@/components/deusi/settings/SettingsPrimitives";
import {
  AccountPanel,
  NotifPanel,
  PrivacyPanel,
  AppearancePanel,
  LanguagePanel,
  SecurityPanel,
} from "@/components/deusi/settings/SettingsPanels";

export const Route = createFileRoute("/einstellungen")({
  head: () => ({
    meta: [
      { title: "Einstellungen · DEUSI" },
      {
        name: "description",
        content: "Verwalte dein Konto, Benachrichtigungen, Datenschutz und Erscheinungsbild.",
      },
    ],
  }),
  component: SettingsPage,
});

type TabKey =
  "konto" | "benachrichtigungen" | "datenschutz" | "erscheinung" | "sprache" | "sicherheit";

const TABS: { key: TabKey; label: string; fa: string; desc: string; Icon: typeof User }[] = [
  {
    key: "konto",
    label: "Konto",
    fa: "حساب کاربری",
    desc: "Profildaten & Konto-Aktionen",
    Icon: User,
  },
  {
    key: "benachrichtigungen",
    label: "Benachrichtigungen",
    fa: "اعلان‌ها",
    desc: "Erinnerungen, E-Mail & Push",
    Icon: Bell,
  },
  {
    key: "datenschutz",
    label: "Datenschutz",
    fa: "حریم خصوصی",
    desc: "Sichtbarkeit & geteilte Daten",
    Icon: Shield,
  },
  {
    key: "erscheinung",
    label: "Erscheinungsbild",
    fa: "ظاهر",
    desc: "Farbmodus, Dichte & Animationen",
    Icon: Palette,
  },
  {
    key: "sprache",
    label: "Sprache & Region",
    fa: "زبان و منطقه",
    desc: "Oberfläche, Zeitzone & CEFR-Ziel",
    Icon: Languages,
  },
  {
    key: "sicherheit",
    label: "Sicherheit",
    fa: "امنیت",
    desc: "Passwort, 2FA & Sitzungen",
    Icon: KeyRound,
  },
];

function SettingsPage() {
  const [tab, setTab] = useState<TabKey>("konto");
  const [dirty, setDirty] = useState(false);
  const [q, setQ] = useState("");
  const activeTab = TABS.find((t) => t.key === tab)!;
  const filtered = q.trim()
    ? TABS.filter((t) => (t.label + t.desc + t.fa).toLowerCase().includes(q.trim().toLowerCase()))
    : TABS;

  return (
    <div className="space-y-6 pb-10 animate-fade">
      <MiniHero
        Icon={Settings2}
        label="Einstellungen"
        title="Alles nach deinem Geschmack"
        highlight="Geschmack"
        fa="همه‌چیز طبق سلیقه‌ی تو"
        desc="Konto, Benachrichtigungen, Datenschutz und Erscheinung — an einem Ort."
        descFa="حساب، اعلان‌ها، حریم خصوصی و ظاهر — همه در یک صفحه."
        base="#1a1d24"
        primary="#3a3f4d"
        accent="#8b93a6"
      />

      {/* Mobile: horizontally scrollable segmented tabs */}
      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 lg:hidden [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {TABS.map((t) => {
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`inline-flex shrink-0 items-center gap-2 rounded-full px-3.5 py-2 text-xs font-bold transition ${
                active
                  ? "bg-foreground text-background shadow-sm"
                  : "border border-border bg-background/50 text-foreground/70"
              }`}
            >
              <t.Icon className="h-3.5 w-3.5" />
              {t.label}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[268px_minmax(0,1fr)]">
        <nav className="glass-strong sticky top-5 hidden h-fit rounded-[24px] p-2.5 lg:block">
          <SearchField
            value={q}
            onValueChange={setQ}
            size="sm"
            placeholder="Einstellung suchen…"
            className="mb-2"
          />

          {filtered.map((t) => {
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className="group relative flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition"
              >
                {active && (
                  <motion.span
                    layoutId="settings-active"
                    transition={{ type: "spring", stiffness: 520, damping: 40 }}
                    className="absolute inset-0 rounded-2xl bg-foreground shadow-sm"
                  />
                )}
                <span
                  className={`relative grid h-8 w-8 shrink-0 place-items-center rounded-xl transition ${active ? "bg-background/15 text-background" : "bg-foreground/5 text-foreground/70 group-hover:text-foreground"}`}
                >
                  <t.Icon className="h-4 w-4" />
                </span>
                <span className="relative min-w-0 flex-1">
                  <span
                    className={`block truncate text-sm font-semibold ${active ? "text-background" : "text-foreground/80 group-hover:text-foreground"}`}
                  >
                    {t.label}
                  </span>
                  <span
                    className={`block truncate text-[10px] ${active ? "text-background/70" : "text-muted-foreground"}`}
                  >
                    {t.desc}
                  </span>
                </span>
                <ChevronRight
                  className={`relative h-3.5 w-3.5 transition ${active ? "text-background opacity-100" : "opacity-0 group-hover:opacity-40"}`}
                />
              </button>
            );
          })}
          {filtered.length === 0 && (
            <div className="px-3 py-6 text-center text-xs text-muted-foreground">
              Nichts gefunden
            </div>
          )}
        </nav>

        <div className="min-w-0" onChangeCapture={() => setDirty(true)}>
          <header className="mb-4 flex items-center gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-foreground/5">
              <activeTab.Icon className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h2 className="truncate text-lg font-black tracking-tight">{activeTab.label}</h2>
              <FaHint>{activeTab.fa}</FaHint>
            </div>
          </header>
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              {tab === "konto" && <AccountPanel />}
              {tab === "benachrichtigungen" && <NotifPanel />}
              {tab === "datenschutz" && <PrivacyPanel />}
              {tab === "erscheinung" && <AppearancePanel />}
              {tab === "sprache" && <LanguagePanel />}
              {tab === "sicherheit" && <SecurityPanel />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Sticky save bar — appears as soon as something changes */}
      <AnimatePresence>
        {dirty && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            transition={{ type: "spring", stiffness: 420, damping: 36 }}
            className="glass-strong fixed inset-x-3 bottom-20 z-40 flex items-center justify-between gap-3 rounded-2xl px-4 py-3 shadow-xl lg:inset-x-auto lg:right-8 lg:bottom-8 lg:w-[420px]"
          >
            <div className="min-w-0">
              <div className="text-sm font-bold">Ungespeicherte Änderungen</div>
              <FaHint>تغییرات ذخیره‌نشده</FaHint>
            </div>
            <div className="flex shrink-0 gap-2">
              <GhostBtn onClick={() => setDirty(false)}>Verwerfen</GhostBtn>
              <PrimaryBtn onClick={() => setDirty(false)}>
                <Check className="h-4 w-4" /> Speichern
              </PrimaryBtn>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
