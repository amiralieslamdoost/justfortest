import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertCircle, Check, Eye, EyeOff, Loader2, Lock, Mail, Sparkles, User } from "lucide-react";
import { useDeusi } from "@/lib/deusi/store";
import { AuthShell, AuthField } from "@/components/deusi/AuthShell";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Registrieren — DEUSI" },
      {
        name: "description",
        content: "Kostenloses DEUSI-Konto erstellen und Deutsch lernen starten.",
      },
      { property: "og:title", content: "Registrieren — DEUSI" },
      {
        property: "og:description",
        content: "Kostenloses DEUSI-Konto erstellen und Deutsch lernen starten.",
      },
    ],
  }),
  component: RegisterPage,
});

function scorePassword(p: string) {
  let s = 0;
  if (p.length >= 8) s++;
  if (p.length >= 12) s++;
  if (/[A-Z]/.test(p) && /[a-z]/.test(p)) s++;
  if (/\d/.test(p)) s++;
  if (/[^A-Za-z0-9]/.test(p)) s++;
  return Math.min(s, 4);
}
const strengthLabels = ["Sehr schwach", "Schwach", "Okay", "Stark", "Ausgezeichnet"];
const strengthColors = ["#EF4444", "#F59E0B", "#F7C948", "#3B82F6", "#22C55E"];

function RegisterPage() {
  const { register } = useDeusi();
  const router = useRouter();
  const [u, setU] = useState("");
  const [email, setEmail] = useState("");
  const [p, setP] = useState("");
  const [show, setShow] = useState(false);
  const [accept, setAccept] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const score = useMemo(() => scorePassword(p), [p]);
  const checks = [
    { ok: p.length >= 8, label: "Mind. 8 Zeichen" },
    { ok: /[A-Z]/.test(p) && /[a-z]/.test(p), label: "Groß- & Kleinbuchstaben" },
    { ok: /\d/.test(p), label: "Eine Ziffer" },
  ];

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setErr(null);
    if (!accept) return setErr("Bitte akzeptiere die Nutzungsbedingungen.");
    setLoading(true);
    const r = await register(u, email, p);
    setLoading(false);
    if (!r.ok) return setErr(r.error ?? "Registrierung fehlgeschlagen");
    router.navigate({ to: "/onboarding" });
  };

  return (
    <AuthShell
      side="register"
      title="Konto erstellen"
      subtitle="Kostenlos starten — keine Kreditkarte, kein Kleingedrucktes."
      footer={
        <>
          Schon ein Konto?{" "}
          <Link to="/login" className="font-semibold" style={{ color: "var(--flag-red)" }}>
            Zur Anmeldung
          </Link>
        </>
      }
    >
      <form onSubmit={submit} className="space-y-4">
        <AuthField label="Benutzername">
          <div className="group relative">
            <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
            <input
              value={u}
              onChange={(e) => setU(e.target.value)}
              autoComplete="username"
              required
              placeholder="max.mustermann"
              className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-3 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
            />
          </div>
        </AuthField>

        <AuthField label="E-Mail">
          <div className="group relative">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
              placeholder="du@beispiel.de"
              className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-3 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
            />
          </div>
        </AuthField>

        <AuthField label="Passwort">
          <div className="group relative">
            <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
            <input
              type={show ? "text" : "password"}
              value={p}
              onChange={(e) => setP(e.target.value)}
              autoComplete="new-password"
              required
              placeholder="Mind. 8 Zeichen"
              className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-11 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              aria-label={show ? "Passwort verbergen" : "Passwort anzeigen"}
              className="absolute right-2 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground"
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </AuthField>

        {/* Password strength */}
        <div>
          <div className="flex gap-1.5">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                <motion.div
                  initial={false}
                  animate={{ width: score > i ? "100%" : "0%" }}
                  transition={{ duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
                  className="h-full rounded-full"
                  style={{ background: strengthColors[Math.max(score - 1, 0)] }}
                />
              </div>
            ))}
          </div>
          {p && (
            <div className="mt-2 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Passwortstärke</span>
              <span
                className="font-semibold"
                style={{ color: strengthColors[Math.max(score - 1, 0)] }}
              >
                {strengthLabels[score]}
              </span>
            </div>
          )}
          <ul className="mt-2 grid grid-cols-1 gap-1 sm:grid-cols-3">
            {checks.map((c) => (
              <li
                key={c.label}
                className={`flex items-center gap-1.5 text-xs ${c.ok ? "text-[color:var(--easy)]" : "text-muted-foreground"}`}
              >
                <span
                  className={`grid h-4 w-4 place-items-center rounded-full ${c.ok ? "bg-[color:var(--easy)]/15" : "bg-secondary"}`}
                >
                  <Check className={`h-3 w-3 ${c.ok ? "" : "opacity-30"}`} />
                </span>
                {c.label}
              </li>
            ))}
          </ul>
        </div>

        <label className="flex cursor-pointer items-start gap-2.5 text-sm text-muted-foreground">
          <input
            type="checkbox"
            checked={accept}
            onChange={(e) => setAccept(e.target.checked)}
            className="mt-0.5 h-4 w-4 shrink-0 rounded border-border accent-[var(--flag-red)]"
          />
          <span>
            Ich akzeptiere die{" "}
            <Link to="/agb" className="font-semibold text-foreground hover:underline">
              AGB
            </Link>{" "}
            und die{" "}
            <Link to="/datenschutz" className="font-semibold text-foreground hover:underline">
              Datenschutzerklärung
            </Link>
            .
          </span>
        </label>

        <AnimatePresence>
          {err && (
            <motion.div
              initial={{ opacity: 0, y: -6, height: 0 }}
              animate={{ opacity: 1, y: 0, height: "auto" }}
              exit={{ opacity: 0, y: -6, height: 0 }}
              className="flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-sm text-destructive"
            >
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{err}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          type="submit"
          disabled={loading}
          whileHover={{ y: -1 }}
          whileTap={{ scale: 0.98 }}
          className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl px-4 py-3 text-sm font-bold text-white shadow-lg transition disabled:opacity-60"
          style={{
            background: "linear-gradient(135deg, #1a1a1a 0%, #DD2222 60%, #F7C948 130%)",
            boxShadow: "0 20px 40px -18px rgba(221,34,34,0.65)",
          }}
        >
          <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Sparkles className="h-4 w-4" />
          )}
          <span className="relative">
            {loading ? "Konto wird erstellt…" : "Kostenlos loslegen"}
          </span>
        </motion.button>
      </form>
    </AuthShell>
  );
}
