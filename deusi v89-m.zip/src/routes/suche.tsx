import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { SearchField } from "@/components/deusi/SearchField";
import type { ReactElement } from "react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Clock, CornerDownLeft, Search, Sparkles, TrendingUp, X } from "lucide-react";
import {
  BookIcon,
  ChatIcon,
  FilmIcon,
  GrammarNavIcon,
  HeadphoneIcon,
  MusicNoteIcon,
  ReadIcon,
  SearchIcon,
  WordFamilyIcon,
  type NavIconProps,
} from "@/components/deusi/icons/NavIcons";
import { FaHint } from "@/components/deusi/FaHint";
import { useGlobalSearch } from "@/lib/api/useSearch";

export const Route = createFileRoute("/suche")({
  head: () => ({
    meta: [
      { title: "Suche · DEUSI" },
      {
        name: "description",
        content: "Durchsuche Wörter, Grammatik, Artikel, Podcasts, Musik und Filme.",
      },
      { property: "og:title", content: "Suche · DEUSI" },
      {
        property: "og:description",
        content: "Ein Suchfeld für Wortschatz, Grammatik, Lesetexte, Podcasts, Musik und Filme.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SearchPage,
});

type Kind = "wort" | "grammatik" | "artikel" | "podcast" | "musik" | "film";

type Hit = {
  id: string;
  kind: Kind;
  title: string;
  sub: string;
  excerpt?: string;
  level?: string;
  to: string;
};

const DATA: Hit[] = [
  {
    id: "1",
    kind: "wort",
    title: "die Verantwortung",
    sub: "n. · مسئولیت",
    excerpt: "Sie trägt große Verantwortung für das Projekt.",
    level: "B1",
    to: "/dictionary",
  },
  {
    id: "2",
    kind: "wort",
    title: "verantwortlich",
    sub: "adj. · مسئول",
    excerpt: "Er ist für die Sicherheit verantwortlich.",
    level: "B1",
    to: "/dictionary",
  },
  {
    id: "3",
    kind: "grammatik",
    title: "Konjunktiv II",
    sub: "Höflichkeit & irreale Bedingung",
    excerpt: "Ich würde gehen, wenn ich Zeit hätte.",
    level: "B1",
    to: "/grammatik",
  },
  {
    id: "4",
    kind: "grammatik",
    title: "Passiv Präsens",
    sub: "Vorgangspassiv",
    excerpt: "Der Brief wird geschrieben.",
    level: "B1",
    to: "/grammatik",
  },
  {
    id: "5",
    kind: "artikel",
    title: "Leben in Berlin",
    sub: "Kultur · 5 Min.",
    excerpt: "Berlin verändert sich Jahr für Jahr…",
    level: "B2",
    to: "/lesen",
  },
  {
    id: "6",
    kind: "podcast",
    title: "Slow German — Reisen",
    sub: "18 Min. · A2",
    excerpt: "Heute reden wir über eine Reise durch Bayern.",
    level: "A2",
    to: "/podcasts",
  },
  {
    id: "7",
    kind: "musik",
    title: "99 Luftballons — Nena",
    sub: "Neue Deutsche Welle · 3:56",
    excerpt: "Ein Klassiker aus den 80ern.",
    level: "B1",
    to: "/musik",
  },
  {
    id: "8",
    kind: "film",
    title: "Das Leben der Anderen",
    sub: "Drama · 137 Min.",
    excerpt: "Ein Stasi-Hauptmann überwacht ein Künstlerpaar.",
    level: "B2",
    to: "/kino",
  },
];

type KindMeta = {
  label: string;
  fa: string;
  Icon: (p: NavIconProps) => ReactElement;
  color: string;
  bg: string;
  to: string;
};

const META: Record<Kind, KindMeta> = {
  wort: {
    label: "Wörter",
    fa: "کلمه‌ها",
    Icon: BookIcon,
    color: "#3a1080",
    bg: "#eee0ff",
    to: "/dictionary",
  },
  grammatik: {
    label: "Grammatik",
    fa: "گرامر",
    Icon: GrammarNavIcon,
    color: "#1b3fbf",
    bg: "#dee6ff",
    to: "/grammatik",
  },
  artikel: {
    label: "Lesen",
    fa: "متن‌ها",
    Icon: ReadIcon,
    color: "#5c7a1c",
    bg: "#eaf5c9",
    to: "/lesen",
  },
  podcast: {
    label: "Podcasts",
    fa: "پادکست",
    Icon: HeadphoneIcon,
    color: "#9e1b3a",
    bg: "#ffe0e7",
    to: "/podcasts",
  },
  musik: {
    label: "Musik",
    fa: "موسیقی",
    Icon: MusicNoteIcon,
    color: "#1552c8",
    bg: "#d9e6ff",
    to: "/musik",
  },
  film: {
    label: "Filme",
    fa: "فیلم",
    Icon: FilmIcon,
    color: "#c73a1c",
    bg: "#ffdccd",
    to: "/kino",
  },
};

const KIND_ORDER: Kind[] = ["wort", "grammatik", "artikel", "podcast", "musik", "film"];

const TRENDING = ["Präteritum", "Nachhaltigkeit", "Rammstein", "Goethe B2"];

const SHORTCUTS: {
  to: string;
  label: string;
  fa: string;
  Icon: (p: NavIconProps) => ReactElement;
}[] = [
  { to: "/dictionary", label: "Wörterbuch", fa: "دیکشنری", Icon: BookIcon },
  { to: "/grammatik", label: "Grammatik", fa: "گرامر", Icon: GrammarNavIcon },
  { to: "/verben", label: "Wortfamilien", fa: "خانواده واژه‌ها", Icon: WordFamilyIcon },
  { to: "/lesen", label: "Lesen", fa: "خواندن", Icon: ReadIcon },
  { to: "/podcasts", label: "Podcasts", fa: "پادکست", Icon: HeadphoneIcon },
  { to: "/community", label: "Community", fa: "جامعه", Icon: ChatIcon },
];

const RECENT_KEY = "deusi.search.recent";

function loadRecent(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(RECENT_KEY);
    const list = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(list) ? list.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

/** Highlight every occurrence of the query inside a text. */
function Highlight({ text, q }: { text: string; q: string }) {
  if (!q.trim()) return <>{text}</>;
  const parts = text.split(new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "ig"));
  return (
    <>
      {parts.map((part, i) =>
        part.toLowerCase() === q.toLowerCase() ? (
          <mark
            key={i}
            className="rounded bg-foreground/10 px-0.5 text-foreground dark:bg-foreground/20"
          >
            {part}
          </mark>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </>
  );
}

function SearchPage() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [scope, setScope] = useState<Kind | "alle">("alle");
  const [recent, setRecent] = useState<string[]>([]);
  const [cursor, setCursor] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => setRecent(loadRecent()), []);

  const remember = useCallback((term: string) => {
    const t = term.trim();
    if (!t) return;
    setRecent((prev) => {
      const next = [t, ...prev.filter((x) => x.toLowerCase() !== t.toLowerCase())].slice(0, 8);
      try {
        window.localStorage.setItem(RECENT_KEY, JSON.stringify(next));
      } catch {
        /* storage blocked — keep it in memory only */
      }
      return next;
    });
  }, []);

  /* سشن ۹: نتایج از بک‌اند با فیلتر دامنه و صفحه‌بندی؛ در حالت MOCK دیتای محلی. */
  const [page, setPage] = useState(1);
  const {
    hits: remoteHits,
    totalByKind,
    hasMore,
    isLoading: searching,
  } = useGlobalSearch(q, scope, page);
  const [remoteAll, setRemoteAll] = useState<Hit[]>([]);

  useEffect(() => {
    setPage(1);
    setRemoteAll([]);
  }, [q, scope]);

  useEffect(() => {
    if (!remoteHits) return;
    setRemoteAll((prev) => {
      if (page === 1) return remoteHits as Hit[];
      const seen = new Set(prev.map((h) => `${h.kind}:${h.id}`));
      return [...prev, ...(remoteHits as Hit[]).filter((h) => !seen.has(`${h.kind}:${h.id}`))];
    });
  }, [remoteHits, page]);

  const matches = useMemo<Hit[]>(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    if (remoteHits) return remoteAll.length ? remoteAll : (remoteHits as Hit[]);
    return DATA.filter(
      (h) =>
        h.title.toLowerCase().includes(s) ||
        h.sub.toLowerCase().includes(s) ||
        h.excerpt?.toLowerCase().includes(s),
    );
  }, [q, remoteHits, remoteAll]);

  const counts = useMemo(() => {
    if (totalByKind) return totalByKind as Record<string, number>;
    const c: Record<string, number> = { alle: matches.length };
    matches.forEach((h) => {
      c[h.kind] = (c[h.kind] ?? 0) + 1;
    });
    return c;
  }, [matches, totalByKind]);

  /* در حالت بک‌اند فیلتر سمت سرور اعمال شده؛ در MOCK محلی فیلتر می‌کنیم. */
  const hits = useMemo(
    () => (remoteHits || scope === "alle" ? matches : matches.filter((h) => h.kind === scope)),
    [matches, scope, remoteHits],
  );

  useEffect(() => setCursor(0), [q, scope]);

  const grouped = useMemo(() => {
    const g = new Map<Kind, Hit[]>();
    hits.forEach((h) => g.set(h.kind, [...(g.get(h.kind) ?? []), h]));
    return KIND_ORDER.filter((k) => g.has(k)).map((k) => [k, g.get(k)!] as const);
  }, [hits]);

  // flat order matching the rendered order — used for ↑/↓ keyboard navigation
  const flat = useMemo(() => grouped.flatMap(([, list]) => list), [grouped]);

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!flat.length) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      setCursor((c) => (c + (e.key === "ArrowDown" ? 1 : -1) + flat.length) % flat.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      const hit = flat[cursor];
      if (hit) {
        remember(q);
        navigate({ to: hit.to as never });
      }
    } else if (e.key === "Escape") {
      setQ("");
    }
  };

  useEffect(() => {
    const el = listRef.current?.querySelector<HTMLElement>("[data-active='true']");
    el?.scrollIntoView({ block: "nearest" });
  }, [cursor]);

  return (
    <div className="animate-fade space-y-5 pb-12 sm:space-y-6">
      <Hero />

      {/* Sticky search bar so the query stays reachable while scrolling results */}
      <div className="sticky top-2 z-20 sm:top-3">
        <div className="glass-strong rounded-[24px] p-3 shadow-lg sm:rounded-[28px] sm:p-4">
          <SearchField
            value={q}
            onValueChange={setQ}
            onKeyDown={onKeyDown}
            size="lg"
            autoFocus
            placeholder="Wonach suchst du?"
            ariaLabel="Suche auf DEUSI"
            trailing={
              q ? (
                <span className="hidden shrink-0 items-center gap-1 rounded-md border border-border bg-background/70 px-1.5 py-0.5 text-[11px] font-semibold text-muted-foreground md:inline-flex">
                  <CornerDownLeft className="h-3 w-3" /> Öffnen
                </span>
              ) : null
            }
          />

          {/* Scope chips — swipeable on mobile, wrapping on larger screens */}
          <div className="-mx-3 mt-3 overflow-x-auto px-3 pb-1 [scrollbar-width:none] sm:mx-0 sm:overflow-visible sm:px-0">
            <div className="flex w-max gap-2 sm:w-auto sm:flex-wrap">
              {(["alle", ...KIND_ORDER] as ("alle" | Kind)[]).map((k) => {
                const active = scope === k;
                const meta = k === "alle" ? null : META[k];
                const count = counts[k] ?? 0;
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setScope(k)}
                    aria-pressed={active}
                    className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                      active
                        ? "bg-foreground text-background shadow-sm"
                        : "border border-border bg-background/50 text-foreground/70 hover:border-foreground/30 hover:text-foreground"
                    }`}
                  >
                    {meta ? (
                      <meta.Icon size={14} strokeWidth={2} />
                    ) : (
                      <Sparkles className="h-3.5 w-3.5" />
                    )}
                    {meta ? meta.label : "Alle"}
                    {q && (
                      <span
                        className={`rounded-full px-1.5 text-[10px] font-bold ${
                          active ? "bg-background/25" : "bg-foreground/8 text-muted-foreground"
                        }`}
                      >
                        {count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {!q.trim() ? (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Panel Icon={Clock} title="Zuletzt gesucht" fa="جست‌وجوهای اخیر">
              {recent.length ? (
                <div className="flex flex-wrap gap-2">
                  {recent.map((r) => (
                    <span
                      key={r}
                      className="group inline-flex items-center gap-1 rounded-full border border-border bg-background/60 pl-3 pr-1 text-xs font-semibold transition hover:border-foreground/30"
                    >
                      <button type="button" onClick={() => setQ(r)} className="py-1.5">
                        {r}
                      </button>
                      <button
                        type="button"
                        aria-label={`${r} entfernen`}
                        onClick={() => {
                          const next = recent.filter((x) => x !== r);
                          setRecent(next);
                          try {
                            window.localStorage.setItem(RECENT_KEY, JSON.stringify(next));
                          } catch {
                            /* ignore */
                          }
                        }}
                        className="grid h-6 w-6 place-items-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Noch keine Suchen — probier es unten mit einem beliebten Begriff.
                </p>
              )}
            </Panel>

            <Panel Icon={TrendingUp} title="Beliebt gerade" fa="پرجست‌وجوها">
              <div className="flex flex-wrap gap-2">
                {TRENDING.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setQ(r)}
                    className="rounded-full border border-border bg-background/60 px-3 py-1.5 text-xs font-semibold transition hover:border-foreground/30"
                  >
                    {r}
                  </button>
                ))}
              </div>
            </Panel>
          </div>

          <section className="glass-strong rounded-[24px] p-4 sm:p-5">
            <header className="mb-3">
              <h2 className="text-sm font-bold">Direkt zu einem Bereich</h2>
              <FaHint>رفتن مستقیم به یک بخش</FaHint>
            </header>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
              {SHORTCUTS.map((s) => (
                <Link
                  key={s.to}
                  to={s.to as never}
                  className="group flex min-w-0 items-center gap-2.5 rounded-2xl border border-border bg-background/60 p-3 transition hover:-translate-y-0.5 hover:border-foreground/25 hover:shadow-md"
                >
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-foreground/5">
                    <s.Icon size={18} strokeWidth={2} />
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-xs font-bold">{s.label}</span>
                    <FaHint size="sm">{s.fa}</FaHint>
                  </span>
                </Link>
              ))}
            </div>
          </section>
        </div>
      ) : hits.length === 0 ? (
        <div className="glass-strong grid place-items-center gap-2 rounded-[28px] px-5 py-16 text-center sm:py-20">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-foreground/5">
            <Search className="h-6 w-6 text-foreground/60" />
          </div>
          <div className="text-sm font-semibold">
            {searching ? "Suche läuft …" : `Keine Treffer für „${q}“`}
          </div>
          <FaHint>{searching ? "در حال جست‌وجو…" : "هیچ نتیجه‌ای پیدا نشد"}</FaHint>
          {scope !== "alle" && (
            <button
              type="button"
              onClick={() => setScope("alle")}
              className="mt-2 rounded-full bg-foreground px-4 py-2 text-xs font-bold text-background"
            >
              In allen Bereichen suchen
            </button>
          )}
        </div>
      ) : (
        <div ref={listRef} className="space-y-5">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 px-1 text-xs font-semibold text-muted-foreground">
            <span>
              {hits.length} {hits.length === 1 ? "Ergebnis" : "Ergebnisse"} für{" "}
              <span className="text-foreground">„{q}“</span>
            </span>
            <span className="hidden items-center gap-1 md:inline-flex">
              <kbd className="rounded border border-border px-1">↑</kbd>
              <kbd className="rounded border border-border px-1">↓</kbd>
              zum Blättern
            </span>
          </div>

          {grouped.map(([kind, list]) => {
            const meta = META[kind];
            return (
              <section key={kind} className="space-y-2">
                <header className="flex items-center gap-2 px-1">
                  <span
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-lg"
                    style={{ backgroundColor: meta.bg, color: meta.color }}
                  >
                    <meta.Icon size={16} strokeWidth={2} />
                  </span>
                  <h2 className="text-sm font-bold">{meta.label}</h2>
                  <span className="text-[11px] text-muted-foreground">{list.length}</span>
                  <Link
                    to={meta.to as never}
                    className="ml-auto inline-flex items-center gap-1 text-[11px] font-semibold text-muted-foreground transition hover:text-foreground"
                  >
                    Bereich öffnen <ArrowRight className="h-3 w-3" />
                  </Link>
                </header>
                <div className="grid grid-cols-1 gap-2 md:grid-cols-2 2xl:grid-cols-3">
                  {list.map((h, i) => {
                    const isActive = flat[cursor]?.id === h.id;
                    return (
                      <motion.div
                        key={h.id}
                        initial={{ opacity: 0, y: 4 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: i * 0.02 }}
                      >
                        <Link
                          to={h.to as never}
                          data-active={isActive}
                          onClick={() => remember(q)}
                          onMouseEnter={() => setCursor(flat.findIndex((f) => f.id === h.id))}
                          className={`group block h-full rounded-2xl border bg-background/60 p-4 transition hover:-translate-y-0.5 hover:shadow-md ${
                            isActive
                              ? "border-foreground/35 shadow-md ring-2 ring-foreground/10"
                              : "border-border hover:border-foreground/25"
                          }`}
                        >
                          <div className="flex items-baseline justify-between gap-3">
                            <h3 className="min-w-0 text-sm font-bold">
                              <Highlight text={h.title} q={q} />
                            </h3>
                            {h.level && (
                              <span
                                className="shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold"
                                style={{ backgroundColor: meta.bg, color: meta.color }}
                              >
                                {h.level}
                              </span>
                            )}
                          </div>
                          <p className="mt-0.5 text-xs text-muted-foreground">{h.sub}</p>
                          {h.excerpt && (
                            <p className="mt-2 line-clamp-2 text-xs text-foreground/70">
                              <Highlight text={h.excerpt} q={q} />
                            </p>
                          )}
                        </Link>
                      </motion.div>
                    );
                  })}
                </div>
              </section>
            );
          })}

          {/* صفحه‌بندی سمت سرور: بارگذاری نتایج بیشتر در دامنهٔ انتخاب‌شده */}
          {hasMore && scope !== "alle" && (
            <div className="flex justify-center pt-1">
              <button
                type="button"
                onClick={() => setPage((p) => p + 1)}
                disabled={searching}
                className="rounded-full border border-border bg-background/60 px-5 py-2 text-xs font-semibold transition hover:border-foreground/30 disabled:opacity-60"
              >
                {searching ? "Lädt …" : "Mehr Ergebnisse laden"}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Panel({
  Icon,
  title,
  fa,
  children,
}: {
  Icon: typeof Search;
  title: string;
  fa: string;
  children: React.ReactNode;
}) {
  return (
    <section className="glass-strong rounded-[24px] p-4 sm:p-5">
      <header className="mb-3 flex items-center gap-2">
        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-foreground/5">
          <Icon className="h-4 w-4" />
        </span>
        <div className="min-w-0">
          <h2 className="truncate text-sm font-bold">{title}</h2>
          <FaHint>{fa}</FaHint>
        </div>
      </header>
      {children}
    </section>
  );
}

function Hero() {
  // Distinct teal identity so the global search never reads as the dictionary section.
  const base = "#032b2b",
    primary = "#0d7c74",
    accent = "#34e0c0";
  return (
    <header
      className="relative overflow-hidden rounded-3xl p-5 text-white shadow-xl sm:p-7"
      style={{
        backgroundImage: [
          `radial-gradient(110% 130% at 88% -20%, ${accent}66 0%, transparent 55%)`,
          `radial-gradient(90% 120% at 5% 115%, ${primary}88 0%, transparent 60%)`,
          `linear-gradient(135deg, ${base} 0%, ${primary} 55%, ${accent} 130%)`,
        ].join(", "),
      }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div
          className="absolute -bottom-20 -left-10 h-52 w-52 rounded-full blur-3xl"
          style={{ backgroundColor: accent, opacity: 0.4 }}
        />
      </div>
      <div className="relative flex min-w-0 items-center gap-3 sm:gap-4">
        <div
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/95 sm:h-16 sm:w-16 shadow-lg ring-1 ring-white/40"
          style={{ color: primary }}
        >
          <SearchIcon size={30} strokeWidth={2} />
        </div>
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
            Suche
          </div>
          <h1 className="mt-2 text-balance text-2xl font-black leading-tight sm:text-3xl md:text-4xl">
            Finde{" "}
            <span className="bg-gradient-to-r from-white via-white/90 to-white/70 bg-clip-text text-transparent">
              alles
            </span>{" "}
            auf einmal
          </h1>
          <FaHint className="!text-white/85">همه‌چیز را یکجا پیدا کن</FaHint>
          <p className="mt-2 max-w-2xl text-sm text-white/80">
            Wörter, Grammatik, Artikel, Podcasts, Musik, Filme — in einem Suchfeld.
          </p>
          <FaHint className="!text-white/70">
            کلمات، گرامر، مقاله، پادکست، موسیقی و فیلم در یک جست‌وجو.
          </FaHint>
        </div>
      </div>
    </header>
  );
}
