import { createFileRoute } from "@tanstack/react-router";
import { LegalShell } from "@/components/deusi/LegalShell";

export const Route = createFileRoute("/agb")({
  head: () => ({
    meta: [
      { title: "AGB · DEUSI" },
      {
        name: "description",
        content: "Allgemeine Geschäftsbedingungen für die Nutzung von DEUSI.",
      },
    ],
  }),
  component: AgbPage,
});

function AgbPage() {
  return (
    <LegalShell kind="agb" updated="29. Juli 2026">
      <h2>§ 1 Geltungsbereich</h2>
      <p>
        Diese Allgemeinen Geschäftsbedingungen (AGB) gelten für die Nutzung der Lernplattform DEUSI,
        betrieben von der DEUSI GmbH („Anbieter"). Mit der Registrierung erklärst du dich mit diesen
        Bedingungen einverstanden.
      </p>

      <h2>§ 2 Vertragsgegenstand</h2>
      <p>
        Der Anbieter stellt Nutzer:innen digitale Werkzeuge zum Erlernen der deutschen Sprache
        bereit — u. a. Karten, Podcasts, Grammatik­lektionen, KI-Coach und Prüfungs­simulationen.
      </p>

      <h2>§ 3 Registrierung und Konto</h2>
      <ul>
        <li>Die Registrierung ist ab 16 Jahren möglich; Jüngere brauchen elterliche Zustimmung.</li>
        <li>Deine Zugangs­daten sind vertraulich zu behandeln.</li>
        <li>Ein Konto ist personen­bezogen und nicht übertragbar.</li>
      </ul>

      <h2>§ 4 Kostenlose und kostenpflichtige Leistungen</h2>
      <p>
        DEUSI bietet eine kostenlose Grund­version sowie kostenpflichtige Pläne (Plus, Pro). Preise,
        Leistungs­umfang und Abrechnungs­intervall ergeben sich aus der Bestell­seite.
      </p>

      <h2>§ 5 Widerrufsrecht für Verbraucher</h2>
      <p>
        Verbraucher:innen steht ein 14-tägiges Widerrufs­recht ab Vertrags­abschluss zu, sofern
        nichts anderes vereinbart wurde. Der Widerruf kann formfrei an
        <a href="mailto:widerruf@deusi.app"> widerruf@deusi.app</a> erklärt werden.
      </p>

      <h2>§ 6 Laufzeit und Kündigung</h2>
      <ul>
        <li>Monats­abos verlängern sich automatisch um jeweils einen Monat.</li>
        <li>Jahres­abos verlängern sich um jeweils ein Jahr.</li>
        <li>Kündigung jederzeit über Einstellungen → Abonnement.</li>
      </ul>

      <h2>§ 7 Pflichten der Nutzer:innen</h2>
      <p>Du verpflichtest dich, DEUSI nicht in gesetzes- oder sittenwidriger Weise zu nutzen.</p>
      <ul>
        <li>Keine automatisierten Zugriffe ohne Zustimmung.</li>
        <li>Keine Verbreitung rechts­widriger Inhalte.</li>
        <li>Keine Umgehung von Sicherheits- oder Zugriffs­beschränkungen.</li>
      </ul>

      <h2>§ 8 Rechte an Inhalten</h2>
      <p>
        Alle Inhalte (Texte, Audio, Video, Grafiken, Karten) sind urheber­rechtlich geschützt.
        Nutzer:innen erhalten ein einfaches, nicht übertragbares Nutzungs­recht für den privaten
        Lern­gebrauch.
      </p>

      <h2>§ 9 Verfügbarkeit</h2>
      <p>
        Wir bemühen uns um eine hohe Verfügbarkeit, garantieren aber keine ununterbrochene Nutzung.
        Wartungs­arbeiten werden nach Möglichkeit angekündigt.
      </p>

      <h2>§ 10 Haftung</h2>
      <p>
        Der Anbieter haftet unbeschränkt bei Vorsatz und grober Fahrlässigkeit. Bei leichter
        Fahrlässigkeit haftet der Anbieter nur bei Verletzung wesentlicher Vertrags­pflichten und
        begrenzt auf den vorhersehbaren, typischen Schaden.
      </p>

      <h2>§ 11 Änderungen der AGB</h2>
      <p>
        Der Anbieter kann diese AGB mit Wirkung für die Zukunft anpassen. Änderungen werden
        rechtzeitig per E-Mail oder in der App angekündigt.
      </p>

      <h2>§ 12 Schlussbestimmungen</h2>
      <p>
        Es gilt deutsches Recht. Sollten einzelne Bestimmungen unwirksam sein, bleibt die
        Wirksamkeit der übrigen Bestimmungen unberührt.
      </p>
    </LegalShell>
  );
}
