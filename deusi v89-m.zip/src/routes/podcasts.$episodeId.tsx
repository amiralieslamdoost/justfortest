import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { AudioPlayer } from "@/components/deusi/podcasts/AudioPlayer";
import { PodcastCover } from "@/components/deusi/podcasts/PodcastCover";
import { InteractiveTranscript } from "@/components/deusi/podcasts/InteractiveTranscript";
import { EpisodeQuiz } from "@/components/deusi/podcasts/EpisodeQuiz";
import { Fa } from "@/components/deusi/Fa";
import { ErrorCard } from "@/components/deusi/ErrorCard";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";
import { type PodcastEpisode, type PodcastVocab } from "@/lib/deusi/mockPodcasts";
import { getEpisode } from "@/lib/api/media";
import {
  useEpisode,
  useEpisodes,
  useMediaProgress,
  useMediaVocab,
  usePodcastShows,
} from "@/lib/api/useMedia";

export const Route = createFileRoute("/podcasts/$episodeId")({
  loader: async ({ params }) => {
    const episode = await getEpisode(params.episodeId);
    if (!episode) throw notFound();
    return { episode };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Folge nicht gefunden | DEUSI" }, { name: "robots", content: "noindex" }],
      };
    }
    const { episode } = loaderData;
    const title = `${episode.title} — Podcast-Folge | DEUSI`;
    const desc = `Deutsch hören mit „${episode.title}“: interaktives Transkript, Vokabeln und Quiz auf Niveau ${episode.level}.`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  errorComponent: ({ error, reset }) => <ErrorCard error={error} reset={reset} />,
  notFoundComponent: EpisodeNotFound,
  component: EpisodeDetail,
});

function EpisodeNotFound() {
  return (
    <div className="neu-card p-8 text-center">
      <h1 className="text-xl font-black">Folge nicht gefunden</h1>
      <Fa className="fa-hint-xs mt-1">این قسمت پیدا نشد.</Fa>
      <Link
        to="/podcasts"
        className="mt-4 inline-block rounded-xl bg-secondary px-4 py-2 text-sm font-bold"
      >
        Zurück zu den Podcasts
      </Link>
    </div>
  );
}

function EpisodeDetail() {
  const { episode: loaderEpisode } = Route.useLoaderData();
  const { episode: liveEpisode } = useEpisode(loaderEpisode.id);
  const episode = liveEpisode ?? loaderEpisode;
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  const { shows } = usePodcastShows();
  const { episodes: allEpisodes } = useEpisodes({ perPage: 200 });
  const { state: progressState, patch: patchProgress } = useMediaProgress("episode", episode.id);
  const { saveWord } = useMediaVocab({ type: "episode", mediaId: episode.id });

  const [currentTime, setCurrentTime] = useState(0);
  const [seekTo, setSeekTo] = useState(0);
  const [savedVocab, setSavedVocab] = useState<PodcastVocab[]>([]);
  const [showQuiz, setShowQuiz] = useState(false);
  const [showTranscript, setShowTranscript] = useState(true);

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);
  useEffect(() => {
    setCurrentTime(0);
    setSeekTo(0);
    setSavedVocab([]);
    setShowQuiz(false);
  }, [episode.id]);
  // ذخیرهٔ پیشرفت شنیدن هر ۱۵ ثانیه.
  const bucket = Math.floor(currentTime / 15);
  useEffect(() => {
    if (!currentTime || !episode.durationSec) return;
    patchProgress({
      positionSec: currentTime,
      progress: Math.min(100, Math.round((currentTime / episode.durationSec) * 100)),
      finished: currentTime / episode.durationSec >= 0.98,
      plays: Math.max(1, progressState.plays),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bucket, episode.id]);
  if (!currentUser) return null;

  const show = shows.find((s) => s.id === episode.showId);
  const related = allEpisodes
    .filter(
      (e) =>
        e.id !== episode.id && (e.showId === episode.showId || e.category === episode.category),
    )
    .slice(0, 4);

  /** ذخیرهٔ واژه در `media_vocab` + وضعیت محلی. */
  function persistVocab(v: PodcastVocab) {
    setSavedVocab((list) => (list.some((x) => x.id === v.id) ? list : [...list, v]));
    saveWord({
      type: "episode",
      mediaId: episode.id,
      word: { text: v.word, translation: v.meaning },
      context: v.example,
      timestampSec: currentTime,
    });
  }

  return (
    <div className="space-y-5 animate-fade">
      <Link
        to="/podcasts"
        className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5 text-xs font-bold text-muted-foreground hover:text-foreground"
      >
        ← Alle Podcasts
      </Link>

      {/* Player header */}
      <section
        className="relative overflow-hidden rounded-[2rem] p-5 text-white shadow-[0_40px_90px_-40px_rgba(0,0,0,.8)] ring-1 ring-white/10 sm:p-8"
        style={{
          backgroundImage: [
            `radial-gradient(110% 130% at 88% -20%, ${episode.accent}88 0%, transparent 55%)`,
            `radial-gradient(90% 120% at 0% 118%, ${episode.accent}55 0%, transparent 60%)`,
            `linear-gradient(135deg, #0d0918 0%, #1d1734 55%, ${episode.accent} 200%)`,
          ].join(", "),
        }}
      >
        {/* ambient motion + texture */}
        <motion.div
          aria-hidden
          animate={{ scale: [1, 1.18, 1], opacity: [0.35, 0.6, 0.35] }}
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
          className="pointer-events-none absolute -right-24 -top-28 h-80 w-80 rounded-full blur-3xl"
          style={{ background: episode.accent }}
        />
        <motion.div
          aria-hidden
          animate={{ scale: [1.1, 1, 1.1], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 11, repeat: Infinity, ease: "easeInOut" }}
          className="pointer-events-none absolute -bottom-32 -left-20 h-72 w-72 rounded-full blur-3xl"
          style={{ background: episode.accent }}
        />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage: "radial-gradient(#fff 1px, transparent 1px)",
            backgroundSize: "24px 24px",
          }}
        />

        <div className="relative grid gap-6 grid-cols-[minmax(0,1fr)] md:grid-cols-[230px_minmax(0,1fr)] md:items-start">
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
            className="relative mx-auto w-40 sm:w-48 md:mx-0 md:w-full"
          >
            <div
              aria-hidden
              className="absolute -inset-3 rounded-[2rem] opacity-60 blur-2xl"
              style={{ background: episode.accent }}
            />
            <PodcastCover
              title={episode.title}
              publisher={show?.publisher}
              background={episode.cover}
              size="lg"
              className="relative aspect-square w-full rounded-3xl shadow-2xl ring-1 ring-white/20 transition-transform duration-500 hover:scale-[1.03]"
            />
            {/* now-playing equalizer */}
            <div className="relative mx-auto mt-3 flex items-end justify-center gap-1" aria-hidden>
              {[0, 1, 2, 3, 4].map((i) => (
                <motion.span
                  key={i}
                  className="w-1 rounded-full bg-white/70"
                  animate={{ height: [6, 18, 9, 22, 7] }}
                  transition={{
                    duration: 1.4 + i * 0.15,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: i * 0.1,
                  }}
                />
              ))}
            </div>
          </motion.div>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold uppercase tracking-widest">
              <span className="rounded-full bg-white/15 px-2.5 py-1 backdrop-blur ring-1 ring-white/15">
                Folge {episode.number}
              </span>
              <span
                className="rounded-full px-2.5 py-1 text-[#0d0918]"
                style={{ background: episode.accent }}
              >
                {episode.level}
              </span>
              {show?.title && (
                <span className="rounded-full bg-white/10 px-2.5 py-1 normal-case tracking-normal text-white/80 backdrop-blur">
                  {show.title}
                </span>
              )}
            </div>
            <h1 className="mt-3 bg-gradient-to-br from-white via-white to-white/60 bg-clip-text text-2xl font-black leading-tight text-transparent md:text-[2.6rem]">
              {episode.title}
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-white/75">
              {episode.description}
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
              <MetaChip icon="⏱" label={`${Math.round(episode.durationSec / 60)} Min`} />
              <MetaChip
                icon="📅"
                label={new Date(episode.publishedAt).toLocaleDateString("de-DE", {
                  day: "2-digit",
                  month: "short",
                })}
              />
              <MetaChip icon="📻" label={show?.publisher ?? "DEUSI"} />
              <BookmarkButton
                type="podcast"
                id={episode.id}
                title={episode.title}
                sub={episode.description}
                level={episode.level}
                to={`/podcasts/${episode.id}`}
                variant="chip"
                className="bg-white/15 text-white hover:bg-white/25"
              />
            </div>
            <div className="mt-5 rounded-[1.5rem] border border-white/15 bg-white/10 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,.18)] backdrop-blur-xl">
              <AudioPlayer
                waveform={episode.waveform}
                durationSec={episode.durationSec}
                accent={episode.accent}
                initialSec={seekTo}
                onSeek={setSeekTo}
                onTimeUpdate={setCurrentTime}
              />
            </div>
          </div>
        </div>

        <div className="sr-only" aria-live="polite">
          {Math.round(currentTime)} Sekunden
        </div>
      </section>

      {/* Transcript / Quiz */}
      <section className="neu-card p-4 sm:p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-[color:var(--flag-red)]">
              Interaktives Transkript
            </div>
            <Fa className="fa-hint-xs">متن تعاملی قسمت</Fa>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowTranscript((v) => !v)}
              className="rounded-xl border border-border bg-card px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary"
            >
              {showTranscript ? "👁 Transkript ausblenden" : "👁‍🗨 Transkript einblenden"}
            </button>
            <button
              onClick={() => setShowQuiz(false)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold ${!showQuiz ? "bg-[color:var(--flag-red)] text-white" : "bg-secondary text-muted-foreground"}`}
            >
              Transkript
            </button>
            <button
              onClick={() => setShowQuiz(true)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold ${showQuiz ? "bg-[color:var(--flag-red)] text-white" : "bg-secondary text-muted-foreground"}`}
            >
              Verständnis-Quiz
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {showQuiz ? (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <EpisodeQuiz questions={episode.quiz} />
            </motion.div>
          ) : showTranscript ? (
            <motion.div
              key="tx"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="grid gap-4 grid-cols-[minmax(0,1fr)] lg:grid-cols-[minmax(0,1fr)_260px]"
            >
              <InteractiveTranscript
                episode={episode}
                currentTime={currentTime}
                onSeek={(s) => {
                  setSeekTo(s);
                  setCurrentTime(s);
                }}
                onSaveWord={(v) => persistVocab(v)}
              />
              <VocabPanel
                vocab={episode.vocab}
                saved={savedVocab}
                onSave={(v) => persistVocab(v)}
              />
            </motion.div>
          ) : (
            <motion.div
              key="tx-hidden"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="rounded-2xl border border-dashed border-border bg-secondary/40 p-8 text-center"
            >
              <div className="mb-2 text-2xl">🙈</div>
              <div className="text-sm font-semibold">Transkript ist ausgeblendet</div>
              <p className="mt-1 text-xs text-muted-foreground">Konzentriere dich aufs Hören.</p>
              <button
                onClick={() => setShowTranscript(true)}
                className="mt-3 rounded-xl bg-[color:var(--flag-red)] px-4 py-2 text-xs font-semibold text-white"
              >
                Transkript einblenden
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <AISummary summary={episode.summary} />
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="neu-card p-4 sm:p-5">
          <h2 className="mb-3 text-lg font-black">Weitere Folgen</h2>
          <Fa className="fa-hint-xs -mt-2 mb-3 block">قسمت‌های مرتبط</Fa>
          <ul className="grid gap-3 sm:grid-cols-2">
            {related.map((e) => (
              <RelatedRow key={e.id} episode={e} />
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function RelatedRow({ episode }: { episode: PodcastEpisode }) {
  return (
    <li>
      <Link
        to="/podcasts/$episodeId"
        params={{ episodeId: episode.id }}
        className="flex items-center gap-3 rounded-2xl bg-card p-3 ring-1 ring-border transition hover:shadow-lg"
      >
        <PodcastCover
          title={episode.title}
          background={episode.cover}
          className="h-14 w-14 shrink-0"
          size="sm"
        />
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-black">{episode.title}</div>
          <div className="truncate text-[11px] text-muted-foreground">
            {episode.level} · {Math.round(episode.durationSec / 60)} Min
          </div>
        </div>
      </Link>
    </li>
  );
}

function MetaChip({ icon, label }: { icon: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/12 px-2.5 py-1 text-[11px] font-semibold text-white/90 backdrop-blur">
      <span>{icon}</span>
      {label}
    </span>
  );
}

function VocabPanel({
  vocab,
  saved,
  onSave,
}: {
  vocab: PodcastVocab[];
  saved: PodcastVocab[];
  onSave: (v: PodcastVocab) => void;
}) {
  return (
    <div className="rounded-2xl border border-border bg-secondary/40 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-bold">Vokabelextraktion</h3>
        <span className="text-[11px] text-muted-foreground">
          {saved.length} / {vocab.length} gespeichert
        </span>
      </div>
      <Fa className="fa-hint-xs -mt-2 mb-2 block">واژه‌های کلیدی این قسمت</Fa>
      <ul className="max-h-[320px] space-y-2 overflow-y-auto pr-1">
        {vocab.map((v) => {
          const isSaved = saved.some((s) => s.id === v.id);
          const articleColor =
            v.article === "der"
              ? "var(--der)"
              : v.article === "die"
                ? "var(--die)"
                : v.article === "das"
                  ? "var(--das)"
                  : "var(--muted-foreground)";
          return (
            <li key={v.id} className="flex items-start gap-3 rounded-xl bg-background p-2.5">
              {v.article ? (
                <span
                  className="rounded-md px-1.5 py-0.5 text-[10px] font-black text-white"
                  style={{ background: articleColor }}
                >
                  {v.article}
                </span>
              ) : (
                <span className="rounded-md bg-secondary px-1.5 py-0.5 text-[10px] font-black text-muted-foreground">
                  –
                </span>
              )}
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-semibold">{v.word}</div>
                <div className="truncate text-[11px] text-muted-foreground">{v.meaning}</div>
              </div>
              <button
                onClick={() => onSave(v)}
                disabled={isSaved}
                className="shrink-0 rounded-lg bg-[color:var(--flag-red)] px-2 py-1 text-[11px] font-semibold text-white disabled:opacity-50"
              >
                {isSaved ? "✓" : "+"}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function AISummary({ summary }: { summary: string }) {
  return (
    <div className="mt-5 rounded-2xl border border-border bg-gradient-to-br from-[color:var(--accent)]/60 to-secondary/40 p-4">
      <div className="mb-1 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-[color:var(--accent-foreground)]">
        <span>✦</span> KI-Zusammenfassung
      </div>
      <Fa className="fa-hint-xs mb-1 block">خلاصهٔ هوشمند</Fa>
      <p className="text-sm text-foreground">{summary}</p>
    </div>
  );
}
