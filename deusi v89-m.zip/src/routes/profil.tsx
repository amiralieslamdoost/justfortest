import { createFileRoute } from "@tanstack/react-router";
import { SectionHero } from "@/components/deusi/SectionHero";
import { LearnerProfilePrompt } from "@/components/deusi/onboarding/LearnerProfilePrompt";
import {
  BadgesCard,
  CertificatesCard,
  DailyGoalCard,
  HeatmapCard,
  LanguageRoadmap,
  PlacementTestEntry,
  ProfileHeader,
  RecentActivityCard,
  SettingsCard,
  StatisticsCard,
  SubscriptionCard,
} from "@/components/deusi/profile/ProfileRouteSections";

export const Route = createFileRoute("/profil")({
  head: () => ({
    meta: [
      { title: "Mein Profil · DEUSI" },
      { name: "description", content: "Dein persönliches Lern-Cockpit auf DEUSI." },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  return (
    <div className="space-y-6 pb-10 animate-fade">
      <SectionHero sectionKey="profile" />
      <LearnerProfilePrompt />
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-6">
          <ProfileHeader />
          <SubscriptionCard />
          <PlacementTestEntry />
          <LanguageRoadmap />
          <SettingsCard />
          <StatisticsCard />
          <HeatmapCard />
        </div>
        <aside className="space-y-6">
          <RecentActivityCard />
          <BadgesCard />
          <CertificatesCard />
          <DailyGoalCard />
        </aside>
      </div>
    </div>
  );
}
