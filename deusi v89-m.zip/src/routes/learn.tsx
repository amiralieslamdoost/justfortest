import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { Modal } from "@/components/deusi/Modal";
import type { VerbWord } from "@/lib/deusi/types";
import type { Rating } from "@/lib/deusi/fsrs";
import { LeitnerBoxBar } from "@/components/deusi/learn/LeitnerBoxBar";
import { FaHint } from "@/components/deusi/FaHint";
import { accentColor } from "@/components/deusi/learn/learnHelpers";
import { RateBtn } from "@/components/deusi/learn/RateBtn";
import { CenterStage } from "@/components/deusi/learn/CenterStage";
import { SideColumn } from "@/components/deusi/learn/SideColumn";
import { NodeBox } from "@/components/deusi/learn/NodeBox";
import { attributesFor } from "@/components/deusi/learn/NodeBox";
import { ConjTable } from "@/components/deusi/learn/ConjTable";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "Lernen — DEUSI" },
      {
        name: "description",
        content: "Vokabeln mit Karteikarten und Spaced Repetition effektiv lernen.",
      },
      { property: "og:title", content: "Lernen — DEUSI" },
      {
        property: "og:description",
        content: "Vokabeln mit Karteikarten und Spaced Repetition effektiv lernen.",
      },
    ],
  }),
  component: Learn,
});

/* -------------- page -------------- */

function Learn() {
  const { currentUser, hydrated, dueCards, rate, ensureDeckFor } = useDeusi();
  const router = useRouter();
  const [conjOpen, setConjOpen] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [hoverRating, setHoverRating] = useState<Rating | null>(null);

  useEffect(() => {
    if (!hydrated) return;
    if (!currentUser) router.navigate({ to: "/login" });
    else ensureDeckFor(currentUser.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, currentUser?.id]);

  const queue = dueCards();
  const current = queue[0];
  const total = currentUser?.deck.length ?? 0;
  const done = total - queue.length;

  useEffect(() => {
    setRevealed(false);
    setHoverRating(null);
  }, [current?.word.id]);

  const onRate = (r: Rating) => {
    if (!current) return;
    if (!revealed) {
      setRevealed(true);
      return;
    }
    setRevealed(false);
    setTimeout(() => rate(current.word.id, r), 220);
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!current) return;
      if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        setRevealed((v) => !v);
        return;
      }
      if (e.key === "1") onRate("again");
      if (e.key === "2") onRate("hard");
      if (e.key === "3") onRate("good");
      if (e.key === "4") onRate("easy");
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.word.id, revealed]);

  if (!currentUser) return null;

  if (!current) {
    return (
      <div className="mx-auto mt-16 max-w-xl neu-card p-10 text-center animate-fade">
        <div className="mb-3 text-5xl">🎉</div>
        <h1 className="mb-2 text-2xl font-bold">Fantastisch — alles erledigt!</h1>
        <FaHint size="sm" className="!mb-2 block">
          عالی بود — کارِ امروز تمام شد!
        </FaHint>
        <p className="mb-6 text-muted-foreground">
          Alle heutigen Karten sind wiederholt. Komm morgen wieder oder füge neue Vokabeln hinzu.
        </p>
        <FaHint size="sm" className="!mb-4 block">
          همهٔ کارت‌های امروز مرور شدند. فردا برگرد یا واژهٔ جدید اضافه کن.
        </FaHint>
        <div className="flex justify-center gap-3">
          <Link
            to="/dashboard"
            className="rounded-xl border border-border bg-card px-5 py-2.5 font-semibold hover:bg-secondary"
          >
            Zum Dashboard
          </Link>
          <Link
            to="/dictionary"
            className="rounded-xl px-5 py-2.5 font-semibold text-white"
            style={{ background: "var(--flag-black)" }}
          >
            + Neue Vokabel
          </Link>
        </div>
      </div>
    );
  }

  const w = current.word;
  const pct = Math.round(((done + 1) / (total || 1)) * 100);
  const accent = accentColor(w);

  return (
    <div className="mx-auto flex min-h-[calc(100vh-2.5rem)] max-w-6xl flex-col gap-4 py-2 sm:gap-6 lg:gap-8">
      <h1 className="sr-only">Lernen — Karteikarten wiederholen</h1>
      {/* Header: Zurück links, Fortschritt Mitte */}
      <header className="flex items-center gap-3 sm:gap-4">
        <Link to="/dashboard" className="btn-back">
          <span aria-hidden>←</span>
          <span>Zurück</span>
        </Link>

        <div className="flex flex-1 items-center gap-3">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${pct}%`, background: accent }}
            />
          </div>
          <div className="text-xs font-semibold text-muted-foreground tabular-nums whitespace-nowrap">
            {done + 1} / {total}
          </div>
        </div>
      </header>

      {/* Live Leitner box overview */}
      <LeitnerBoxBar
        deck={currentUser.deck}
        current={current.card}
        previewRating={revealed ? hoverRating : null}
      />

      {/* Stage: on mobile pin to top so the card never shifts when content grows below.
          On desktop keep it visually centered. */}
      <div className="flex flex-1 flex-col items-center justify-start lg:justify-center">
        <div className="relative w-full">
          {/* Desktop (≥lg): 3 Spalten mit Verbindungslinien */}
          <div className="hidden lg:grid lg:grid-cols-[220px_minmax(0,1fr)_220px] lg:items-center lg:gap-x-14 xl:grid-cols-[240px_minmax(0,1fr)_240px] xl:gap-x-20">
            <SideColumn side="left" word={w} revealed={revealed} accent={accent} />
            <CenterStage
              word={w}
              revealed={revealed}
              onFlip={() => setRevealed((v) => !v)}
              onOpenConj={() => setConjOpen(true)}
            />
            <SideColumn side="right" word={w} revealed={revealed} accent={accent} />
          </div>

          {/* Mobile & Tablet: Karte → Aktionen → Nodes */}
          <div className="flex flex-col items-center gap-3 sm:gap-4 lg:hidden">
            <CenterStage
              word={w}
              revealed={revealed}
              onFlip={() => setRevealed((v) => !v)}
              onOpenConj={() => setConjOpen(true)}
            />

            {/* Aktionszone mit stabiler Höhe, damit die Karte beim Umdrehen nicht springt */}
            <div className="w-full min-h-[60px] sm:min-h-[64px]">
              {!revealed ? (
                <button
                  onClick={() => setRevealed(true)}
                  className="group relative mx-auto block w-full max-w-sm overflow-hidden rounded-2xl px-6 py-3.5 text-sm font-bold text-white shadow-lg transition-transform duration-200 active:scale-[0.98] sm:py-4 sm:text-base"
                  style={{
                    background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 70%, #000))`,
                    boxShadow: `0 14px 32px -12px ${accent}88`,
                  }}
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    <span>Antwort zeigen</span>
                    <span aria-hidden className="text-lg">
                      ↻
                    </span>
                  </span>
                </button>
              ) : (
                <div className="grid w-full grid-cols-4 gap-1.5 sm:gap-2">
                  <RateBtn
                    kind="again"
                    title="Nochmal"
                    onClick={() => onRate("again")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="hard"
                    title="Schwer"
                    onClick={() => onRate("hard")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="good"
                    title="Gut"
                    onClick={() => onRate("good")}
                    onHover={setHoverRating}
                    compact
                  />
                  <RateBtn
                    kind="easy"
                    title="Einfach"
                    onClick={() => onRate("easy")}
                    onHover={setHoverRating}
                    compact
                  />
                </div>
              )}
            </div>

            {revealed && (
              <div className="grid w-full grid-cols-2 gap-2.5 sm:grid-cols-3">
                {[...attributesFor(w, "left"), ...attributesFor(w, "right")].map((n, i) => (
                  <NodeBox key={i} spec={n} delay={i * 70} accent={accent} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Reveal button or Rating pills — nur Desktop (≥lg) */}
      {!revealed ? (
        <div className="mx-auto hidden w-full max-w-2xl flex-col items-center gap-2 lg:flex">
          <button
            onClick={() => setRevealed(true)}
            className="group relative w-full max-w-sm overflow-hidden rounded-2xl px-6 py-4 text-base font-bold text-white shadow-lg transition hover:-translate-y-0.5 hover:shadow-xl active:scale-[0.98]"
            style={{
              background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 65%, #000))`,
              boxShadow: `0 18px 40px -12px ${accent}88`,
            }}
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              <span>Antwort zeigen</span>
              <span aria-hidden className="text-lg transition group-hover:translate-x-0.5">
                ↻
              </span>
            </span>
            <span
              aria-hidden
              className="absolute inset-0 bg-white/10 opacity-0 transition group-hover:opacity-100"
            />
          </button>
          <p className="text-center text-[11px] text-muted-foreground">
            Tippe die Karte oder <b>Leertaste</b> zum Umdrehen
          </p>
        </div>
      ) : (
        <div className="mx-auto hidden w-full max-w-2xl flex-col items-center gap-2 lg:flex">
          <div className="flex w-full flex-wrap items-center justify-center gap-3">
            <RateBtn
              kind="again"
              title="Nochmal"
              onClick={() => onRate("again")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="hard"
              title="Schwer"
              onClick={() => onRate("hard")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="good"
              title="Gut"
              onClick={() => onRate("good")}
              onHover={setHoverRating}
            />
            <RateBtn
              kind="easy"
              title="Einfach"
              onClick={() => onRate("easy")}
              onHover={setHoverRating}
            />
          </div>
          <p className="text-center text-xs text-muted-foreground">
            Bewerte, wie gut du dich erinnert hast · Tasten <b>1–4</b>
          </p>
        </div>
      )}

      {w.pos === "verb" && (
        <Modal
          open={conjOpen}
          onClose={() => setConjOpen(false)}
          title={`Konjugation · ${(w as VerbWord).infinitive}`}
          wide
        >
          <ConjTable v={w as VerbWord} />
        </Modal>
      )}
    </div>
  );
}
