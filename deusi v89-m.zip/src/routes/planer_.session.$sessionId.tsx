import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PlannerSubPage } from "@/components/deusi/planner/PlannerSubPage";
import { SessionEditForm } from "@/components/deusi/planner/SessionForms";
import { formatDayLong } from "@/lib/deusi/planner/date";
import { usePlanner } from "@/lib/deusi/planner/usePlanner";

const TITLE = "Session bearbeiten — DEUSI Smart Planner";
const DESCRIPTION =
  "Verschiebe einen Lernblock auf einen anderen Tag, ändere Startzeit und Dauer oder entferne ihn aus der Woche.";

export const Route = createFileRoute("/planer_/session/$sessionId")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: EditSessionPage,
});

function EditSessionPage() {
  const { sessionId } = Route.useParams();
  const planner = usePlanner();
  const navigate = useNavigate();
  const back = () => void navigate({ to: "/planer" });

  const session = planner.sessions.find((s) => s.id === sessionId);

  if (!session) {
    return (
      <PlannerSubPage
        title="Session nicht gefunden"
        titleFa="این جلسه پیدا نشد"
        intro="Dieser Lernblock gehört nicht zur aktuell geöffneten Woche."
        introFa="این بلوک در هفته‌ی باز شده وجود ندارد. به برنامه برگرد و دوباره انتخابش کن."
      >
        <Link
          to="/planer"
          className="inline-flex rounded-full bg-[color:var(--section-primary)] px-5 py-2 text-sm font-bold text-white"
        >
          Zum Wochenplan
        </Link>
      </PlannerSubPage>
    );
  }

  const isVocab = session.skill === "vocabulary";
  const dueCount = planner.dueVocabCount;

  return (
    <PlannerSubPage
      title={session.title}
      titleFa="ویرایش جلسه"
      intro={formatDayLong(session.date)}
      introFa="می‌توانی روز، ساعت و مدت این بلوک را تغییر دهی یا آن را از هفته حذف کنی."
    >
      {isVocab ? (
        <section
          aria-label="Wortschatz-Wiederholung"
          className="neu-card mb-4 flex flex-col gap-3 p-4 sm:p-5"
        >
          <div>
            <h2 className="text-sm font-black tracking-tight">Fällige Karten · {dueCount}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Dieser Block ist mit deiner FSRS-/Leitner-Warteschlange verbunden. Wiederhole die
              fälligen Karten und schließe den Block danach ab — die Anzahl landet in deinem
              Lernprotokoll.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link
              to="/leitner"
              className="rounded-full bg-[color:var(--section-primary)] px-5 py-2 text-sm font-bold text-white"
            >
              Wiederholung starten
            </Link>
            <button
              type="button"
              disabled={planner.busy || session.status === "done"}
              onClick={() => {
                void planner.completeVocabSession(session.id, dueCount).then(back);
              }}
              className="rounded-full border border-border px-5 py-2 text-sm font-bold transition-colors hover:bg-muted disabled:opacity-60"
            >
              {session.status === "done" ? "Bereits erledigt" : "Block abschließen"}
            </button>
          </div>
        </section>
      ) : null}

      <SessionEditForm
        session={session}
        weekStart={planner.weekStart}
        onCancel={back}
        onSave={(patch) => {
          void planner.updateSession(session.id, patch).then(back);
        }}
        onRemove={() => {
          void planner.removeSession(session.id).then(back);
        }}
      />
    </PlannerSubPage>
  );
}
