import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, ChevronLeft, ChevronRight, Clock, Send } from "lucide-react";
import { getExam } from "@/lib/deusi/exams/mockExams";
import type { ExamQuestion, ModelltestSection } from "@/lib/deusi/exams/mockModelltests";
import { QuestionCard } from "@/components/deusi/exams/QuestionCard";
import { useAttempt, useExamRunner, useExamSections } from "@/lib/api/useExams";
import { useExamTimer } from "@/lib/deusi/exams/useExamTimer";

export const Route = createFileRoute("/pruefungen_/$examId/test")({
  validateSearch: (search: Record<string, unknown>) => ({
    section: typeof search.section === "string" ? search.section : "",
  }),
  loader: ({ params }) => {
    const exam = getExam(params.examId);
    if (!exam) throw notFound();
    return { exam };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Test nicht verfügbar | DEUSI" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.exam.shortName} Modelltest online üben | DEUSI`;
    const description = `Absolviere einen ${loaderData.exam.name} Modelltest online – mit Timer, Auto-Speicherung und sofortiger Auswertung.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "robots", content: "noindex" },
      ],
    };
  },
  component: ExamTestPage,
  notFoundComponent: () => (
    <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
      <h1 className="text-xl font-bold">Prüfung nicht gefunden</h1>
      <Link to="/pruefungen" className="mt-6 inline-block text-sm underline">
        Zurück zur Übersicht
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
      <h1 className="text-xl font-bold">Ein Fehler ist aufgetreten</h1>
      <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
    </div>
  ),
});

function ExamTestPage() {
  const { exam } = Route.useLoaderData();
  const { section: sectionId } = Route.useSearch();
  const navigate = useNavigate();
  const { sections } = useExamSections(exam.id);

  const section = useMemo<ModelltestSection | null>(
    () => sections.find((s) => s.id === sectionId) ?? sections[0] ?? null,
    [sections, sectionId],
  );

  const { attempt, answer, submit, ping } = useExamRunner(exam.id, section);
  const { answers } = useAttempt(attempt?.id ?? "");
  const [values, setValues] = useState<Record<string, unknown>>({});
  const [index, setIndex] = useState(0);
  const [confirm, setConfirm] = useState(false);
  const submittedRef = useRef(false);

  // بازیابی پاسخ‌های ذخیره‌شده بعد از رفرش
  useEffect(() => {
    if (!attempt) return;
    setValues((prev) => {
      if (Object.keys(prev).length) return prev;
      const restored: Record<string, unknown> = {};
      for (const [qid, a] of Object.entries(answers)) restored[qid] = a.value;
      return restored;
    });
  }, [attempt, answers]);

  const doSubmit = useCallback(() => {
    if (!attempt || submittedRef.current) return;
    submittedRef.current = true;
    submit.mutate(attempt.id, {
      onSuccess: (a) =>
        navigate({
          to: "/pruefungen/$examId/ergebnis/$attemptId",
          params: { examId: exam.id, attemptId: a.id },
        }),
      onError: () => {
        submittedRef.current = false;
      },
    });
  }, [attempt, submit, navigate, exam.id]);

  const timer = useExamTimer(attempt?.deadlineAt, attempt?.startedAt, doSubmit);

  // heartbeat هر ۳۰ ثانیه
  useEffect(() => {
    if (!attempt) return;
    const id = setInterval(() => ping(attempt, timerRef.current), 30_000);
    return () => clearInterval(id);
  }, [attempt, ping]);
  const timerRef = useRef(0);
  timerRef.current = timer.secondsLeft;

  // هشدار هنگام بستن تب
  useEffect(() => {
    if (!attempt || submittedRef.current) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [attempt]);

  const questions = section?.questions ?? [];
  const current: ExamQuestion | undefined = questions[index];
  const answeredCount = questions.filter(
    (q) => values[q.id] !== undefined && values[q.id] !== "",
  ).length;

  const onChange = (question: ExamQuestion, value: unknown) => {
    setValues((prev) => ({ ...prev, [question.id]: value }));
    if (attempt) answer.mutate({ attempt, question, value });
  };

  if (!section) {
    return (
      <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
        <h1 className="text-xl font-bold">Kein Modelltest verfügbar</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Für diese Prüfung gibt es aktuell keinen Online-Modelltest.
        </p>
        <Link
          to="/pruefungen/$examId"
          params={{ examId: exam.id }}
          className="mt-6 inline-block text-sm underline"
        >
          Zurück zur Prüfung
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-5 pb-24">
      <header className="glass-strong sticky top-2 z-20 rounded-2xl p-3 sm:top-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="truncate text-sm font-bold">{section.title}</div>
            <div className="text-xs text-muted-foreground">
              {exam.shortName} · {answeredCount}/{questions.length} beantwortet
            </div>
          </div>
          <div
            className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-bold tabular-nums ${
              timer.warning === "one"
                ? "bg-rose-500/15 text-rose-500"
                : timer.warning === "five"
                  ? "bg-amber-500/15 text-amber-600"
                  : "bg-secondary/70"
            }`}
            aria-live="polite"
          >
            <Clock className="h-4 w-4" aria-hidden /> {timer.label}
          </div>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary/70">
          <div
            className="h-full rounded-full bg-[color:var(--section-primary)] transition-all"
            style={{
              width: `${questions.length ? ((index + 1) / questions.length) * 100 : 0}%`,
            }}
          />
        </div>
      </header>

      {section.intro ? (
        <p className="glass rounded-2xl p-4 text-sm leading-relaxed text-muted-foreground">
          {section.intro}
        </p>
      ) : null}

      {current ? (
        <QuestionCard
          key={current.id}
          question={current}
          index={index}
          total={questions.length}
          value={values[current.id]}
          onChange={(v) => onChange(current, v)}
        />
      ) : null}

      <div className="flex flex-wrap items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => setIndex((i) => Math.max(0, i - 1))}
          disabled={index === 0}
          className="inline-flex items-center gap-1.5 rounded-full border border-border/70 px-4 py-2 text-xs font-semibold transition disabled:opacity-40"
        >
          <ChevronLeft className="h-4 w-4" aria-hidden /> Zurück
        </button>

        <div className="flex flex-wrap justify-center gap-1.5">
          {questions.map((q, i) => (
            <button
              key={q.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Frage ${i + 1}`}
              aria-current={i === index ? "true" : undefined}
              className={`h-7 w-7 rounded-lg text-[11px] font-bold transition ${
                i === index
                  ? "bg-[color:var(--section-primary)] text-white"
                  : values[q.id] !== undefined && values[q.id] !== ""
                    ? "bg-emerald-500/20 text-emerald-600"
                    : "bg-secondary/70 text-muted-foreground"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>

        {index < questions.length - 1 ? (
          <button
            type="button"
            onClick={() => setIndex((i) => Math.min(questions.length - 1, i + 1))}
            className="inline-flex items-center gap-1.5 rounded-full bg-[color:var(--section-primary)] px-4 py-2 text-xs font-semibold text-white transition hover:opacity-90"
          >
            Weiter <ChevronRight className="h-4 w-4" aria-hidden />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setConfirm(true)}
            className="inline-flex items-center gap-1.5 rounded-full bg-emerald-600 px-4 py-2 text-xs font-semibold text-white transition hover:opacity-90"
          >
            <Send className="h-4 w-4" aria-hidden /> Abgeben
          </button>
        )}
      </div>

      {confirm ? (
        <div className="glass rounded-2xl border border-amber-500/40 p-4">
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" aria-hidden />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">Test wirklich abgeben?</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {questions.length - answeredCount} Frage(n) sind noch unbeantwortet.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={doSubmit}
                  disabled={submit.isPending}
                  className="rounded-full bg-emerald-600 px-4 py-2 text-xs font-semibold text-white disabled:opacity-60"
                >
                  {submit.isPending ? "Wird ausgewertet…" : "Ja, abgeben"}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirm(false)}
                  className="rounded-full border border-border/70 px-4 py-2 text-xs font-semibold"
                >
                  Weiter üben
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
