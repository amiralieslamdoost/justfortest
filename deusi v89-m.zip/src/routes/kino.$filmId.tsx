import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Pause,
  Play,
  Volume2,
  VolumeX,
  SkipBack,
  SkipForward,
  Eye,
  EyeOff,
  Maximize,
  X,
  BookmarkPlus,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { findFilm, type SubtitleCue, type SubtitleWord } from "@/lib/deusi/mockKino";
import { useFilm, useMediaProgress, useMediaVocab } from "@/lib/api/useMedia";
import { useDeusi } from "@/lib/deusi/store";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";

export const Route = createFileRoute("/kino/$filmId")({
  component: FilmPage,
  head: ({ params }) => {
    const f = findFilm(params.filmId);
    return {
      meta: [
        { title: f ? `${f.title} — Deutsches Kino` : "Film — DEUSI" },
        { name: "description", content: f?.synopsis ?? "Deutscher Film mit Untertiteln." },
      ],
    };
  },
});

function fmt(t: number) {
  if (!isFinite(t)) return "0:00";
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60)
    .toString()
    .padStart(2, "0");
  return `${m}:${s}`;
}

function FilmPage() {
  const { filmId } = Route.useParams();
  const router = useRouter();
  const { currentUser, hydrated } = useDeusi();
  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  // فیلم از لایهٔ API (بک‌اند یا fallback محلی) — سشن ۵.
  const { film } = useFilm(filmId);
  const { state: progressState, patch: patchProgress } = useMediaProgress("film", filmId);
  const { saveWord } = useMediaVocab({ type: "film", mediaId: filmId });
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.9);
  const [rate, setRate] = useState(1);
  const [showDE, setShowDE] = useState(true);
  const [showFA, setShowFA] = useState(true);
  const [activeWord, setActiveWord] = useState<SubtitleWord | null>(null);
  const [savedWords, setSavedWords] = useState<SubtitleWord[]>([]);
  const [showCueList, setShowCueList] = useState(true);
  const [videoError, setVideoError] = useState(false);

  const activeCue: SubtitleCue | undefined = useMemo(
    () => film?.cues.find((c) => current >= c.start && current <= c.end),
    [current, film],
  );

  // sync media state
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => setCurrent(v.currentTime);
    const onMeta = () => setDuration(v.duration);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    v.addEventListener("timeupdate", onTime);
    v.addEventListener("loadedmetadata", onMeta);
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    return () => {
      v.removeEventListener("timeupdate", onTime);
      v.removeEventListener("loadedmetadata", onMeta);
      v.removeEventListener("play", onPlay);
      v.removeEventListener("pause", onPause);
    };
  }, []);

  useEffect(() => {
    if (videoRef.current) videoRef.current.playbackRate = rate;
  }, [rate]);
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume;
      videoRef.current.muted = muted;
    }
  }, [volume, muted]);

  // ذخیرهٔ پیشرفت تماشا هر ۱۵ ثانیه.
  const bucket = Math.floor(current / 15);
  useEffect(() => {
    if (!current || !duration) return;
    patchProgress({
      positionSec: current,
      progress: Math.min(100, Math.round((current / duration) * 100)),
      finished: current / duration >= 0.98,
      plays: Math.max(1, progressState.plays),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bucket, filmId]);

  if (!currentUser || !film) return null;

  function toggle() {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play();
    else v.pause();
  }
  function seek(t: number) {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = Math.max(0, Math.min(t, v.duration || t));
  }
  function jumpToCue(cue: SubtitleCue) {
    seek(cue.start);
    videoRef.current?.play();
  }
  function fullscreen() {
    const el = wrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen?.();
  }

  function renderInteractive(cue: SubtitleCue) {
    if (!cue.words || cue.words.length === 0) {
      return <span>{cue.de}</span>;
    }
    // split by spaces, punctuation preserved
    const tokens = cue.de.split(/(\s+)/);
    return tokens.map((tok, i) => {
      if (!tok.trim()) return <span key={i}>{tok}</span>;
      const clean = tok.replace(/[.,!?;:„"«»]/g, "");
      const match = cue.words!.find((w) => w.de.toLowerCase() === clean.toLowerCase());
      if (!match) return <span key={i}>{tok}</span>;
      return (
        <button
          key={i}
          onClick={(e) => {
            e.stopPropagation();
            setActiveWord(match);
          }}
          className="mx-0.5 inline-block rounded-md bg-[color:var(--flag-yellow)]/25 px-1 py-0.5 font-bold text-white underline decoration-[color:var(--flag-yellow)] decoration-2 underline-offset-4 transition hover:bg-[color:var(--flag-yellow)]/50"
        >
          {tok}
        </button>
      );
    });
  }

  return (
    <div className="space-y-5 animate-fade">
      <div className="flex items-center justify-between gap-3">
        <Link
          to="/kino"
          className="neu-pill inline-flex items-center gap-2 px-3 py-2 text-sm font-semibold"
        >
          <ArrowLeft className="h-4 w-4" /> Zurück zum Kino
        </Link>
        <div className="flex items-center gap-2">
          <div className="text-right">
            <div className="text-lg font-black">{film.title}</div>
            <div className="text-xs text-muted-foreground" dir="rtl">
              {film.titleFa} · {film.director} · {film.year}
            </div>
          </div>
          <BookmarkButton
            type="film"
            id={film.id}
            title={film.title}
            sub={`${film.genre.join(" · ")} · ${film.duration}`}
            level={film.level}
            to={`/kino/${film.id}`}
            variant="chip"
          />
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        {/* Player */}
        <div>
          <div ref={wrapRef} className="relative overflow-hidden rounded-3xl bg-black shadow-2xl">
            <video
              ref={videoRef}
              src={film.videoUrl}
              onClick={toggle}
              className="aspect-video w-full bg-black"
              playsInline
              onError={() => setVideoError(true)}
              onLoadedData={() => setVideoError(false)}
            />

            {videoError && (
              <div className="absolute inset-0 grid place-items-center bg-black/80 px-6 text-center">
                <div>
                  <p className="text-sm font-semibold text-white">
                    Das Video konnte nicht geladen werden.
                  </p>
                  <p className="mt-1 text-xs text-white/70">
                    ویدیو در دسترس نیست — زیرنویس‌ها و واژگان همچنان قابل استفاده هستند.
                  </p>
                </div>
              </div>
            )}

            {/* Subtitles overlay */}
            <div className="pointer-events-none absolute inset-x-0 bottom-16 flex flex-col items-center gap-2 px-6">
              <AnimatePresence mode="popLayout">
                {activeCue && showDE && (
                  <motion.div
                    key={activeCue.id + "-de"}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    className="pointer-events-auto max-w-[92%] rounded-2xl bg-black/70 px-4 py-2 text-center text-lg font-bold text-white shadow-2xl backdrop-blur-md md:text-xl"
                  >
                    {renderInteractive(activeCue)}
                  </motion.div>
                )}
                {activeCue && showFA && (
                  <motion.div
                    key={activeCue.id + "-fa"}
                    dir="rtl"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    className="pointer-events-auto max-w-[92%] rounded-2xl bg-[color:var(--flag-red)]/85 px-4 py-1.5 text-center text-base font-semibold text-white shadow-lg backdrop-blur md:text-lg"
                  >
                    {activeCue.fa}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Controls */}
            <div className="absolute inset-x-0 bottom-0 space-y-2 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-3">
              {/* seek bar */}
              <div className="flex items-center gap-3">
                <span className="w-10 text-right text-[11px] font-mono text-white/80">
                  {fmt(current)}
                </span>
                <input
                  type="range"
                  min={0}
                  max={duration || 0}
                  step={0.1}
                  value={current}
                  onChange={(e) => seek(Number(e.target.value))}
                  className="film-range flex-1"
                />
                <span className="w-10 text-[11px] font-mono text-white/80">{fmt(duration)}</span>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <IconBtn onClick={() => seek(current - 5)} label="-5s">
                    <SkipBack className="h-4 w-4" />
                  </IconBtn>
                  <IconBtn onClick={toggle} label={playing ? "Pause" : "Play"} big>
                    {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                  </IconBtn>
                  <IconBtn onClick={() => seek(current + 5)} label="+5s">
                    <SkipForward className="h-4 w-4" />
                  </IconBtn>
                  <IconBtn onClick={() => setMuted((m) => !m)} label="Ton">
                    {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  </IconBtn>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={volume}
                    onChange={(e) => setVolume(Number(e.target.value))}
                    className="film-range w-20"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  <select
                    value={rate}
                    onChange={(e) => setRate(Number(e.target.value))}
                    className="rounded-full bg-white/15 px-2 py-1 text-[11px] font-bold text-white outline-none"
                  >
                    {[0.75, 1, 1.25, 1.5].map((r) => (
                      <option key={r} value={r} className="text-black">
                        {r}×
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => setShowDE((v) => !v)}
                    className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold transition ${
                      showDE ? "bg-white text-black" : "bg-white/15 text-white"
                    }`}
                    title="Deutsche Untertitel"
                  >
                    {showDE ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />} DE
                  </button>
                  <button
                    onClick={() => setShowFA((v) => !v)}
                    className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold transition ${
                      showFA ? "bg-[color:var(--flag-red)] text-white" : "bg-white/15 text-white"
                    }`}
                    title="زیرنویس فارسی"
                  >
                    {showFA ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />} FA
                  </button>
                  <IconBtn onClick={fullscreen} label="Vollbild">
                    <Maximize className="h-4 w-4" />
                  </IconBtn>
                </div>
              </div>
            </div>
          </div>

          {/* Meta */}
          <div className="mt-4 glass-strong rounded-3xl p-5">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-[color:var(--flag-red)] px-2.5 py-1 text-[10px] font-bold text-white">
                {film.level}
              </span>
              {film.genre.map((g) => (
                <span
                  key={g}
                  className="rounded-full bg-secondary px-2.5 py-1 text-[10px] font-semibold"
                >
                  {g}
                </span>
              ))}
              <span className="ml-auto text-xs text-muted-foreground">{film.duration}</span>
            </div>
            <p className="text-sm leading-relaxed">{film.synopsis}</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground" dir="rtl">
              {film.synopsisFa}
            </p>
          </div>
        </div>

        {/* Transcript sidebar */}
        <aside className="glass-strong flex max-h-[80vh] min-h-[400px] flex-col overflow-hidden rounded-3xl">
          <div className="flex items-center justify-between border-b border-border/50 p-4">
            <div>
              <div className="text-sm font-black">Untertitel-Transkript</div>
              <div className="text-[11px] text-muted-foreground">
                Klicke auf ein Wort für die Übersetzung
              </div>
            </div>
            <button
              onClick={() => setShowCueList((v) => !v)}
              className="rounded-full bg-secondary p-1.5 text-xs font-bold"
              title="Umschalten"
            >
              {showCueList ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
          </div>
          {showCueList && (
            <div className="flex-1 overflow-y-auto p-3">
              <ul className="space-y-2">
                {film.cues.map((cue) => {
                  const isActive = activeCue?.id === cue.id;
                  return (
                    <li key={cue.id}>
                      <button
                        onClick={() => jumpToCue(cue)}
                        className={`block w-full rounded-2xl border p-3 text-left transition ${
                          isActive
                            ? "border-[color:var(--flag-red)] bg-[color:var(--flag-red)]/10 shadow-md"
                            : "border-border/40 hover:-translate-y-0.5 hover:bg-secondary/50"
                        }`}
                      >
                        <div className="mb-1 flex items-center justify-between text-[10px] font-mono text-muted-foreground">
                          <span>{fmt(cue.start)}</span>
                          {isActive && (
                            <span className="rounded-full bg-[color:var(--flag-red)] px-2 py-0.5 text-white">
                              ▶
                            </span>
                          )}
                        </div>
                        <div className="text-sm font-semibold leading-snug">{cue.de}</div>
                        <div className="mt-1 text-xs text-muted-foreground" dir="rtl">
                          {cue.fa}
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
          {savedWords.length > 0 && (
            <div className="border-t border-border/50 p-3">
              <div className="mb-1 text-[11px] font-bold text-muted-foreground">
                Gespeicherte Wörter ({savedWords.length})
              </div>
              <div className="flex flex-wrap gap-1">
                {savedWords.map((w, i) => (
                  <span
                    key={i}
                    className="rounded-full bg-[color:var(--flag-yellow)]/30 px-2 py-0.5 text-[11px] font-bold"
                  >
                    {w.de}
                  </span>
                ))}
              </div>
            </div>
          )}
        </aside>
      </div>

      {/* Word popup */}
      <AnimatePresence>
        {activeWord && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/40 backdrop-blur-[3px]"
              onClick={() => setActiveWord(null)}
            />
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.98 }}
              transition={{ type: "spring", stiffness: 300, damping: 26 }}
              className="glass-strong fixed left-1/2 top-1/2 z-50 w-[min(92vw,400px)] -translate-x-1/2 -translate-y-1/2 rounded-3xl p-5 shadow-2xl"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-3xl font-black">{activeWord.de}</div>
                  {activeWord.pos && (
                    <span className="mt-1 inline-block rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold">
                      {activeWord.pos}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => setActiveWord(null)}
                  className="grid h-8 w-8 place-items-center rounded-full hover:bg-secondary"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="mt-4 rounded-2xl bg-secondary/60 p-3">
                <div className="text-[10px] font-bold uppercase text-muted-foreground">
                  Übersetzung
                </div>
                <div className="mt-0.5 text-lg font-bold" dir="rtl">
                  {activeWord.fa}
                </div>
              </div>
              {activeWord.note && (
                <div className="mt-2 rounded-2xl bg-[color:var(--flag-yellow)]/15 p-3 text-xs">
                  💡 {activeWord.note}
                </div>
              )}
              <div className="mt-4 flex gap-2">
                <button
                  onClick={() =>
                    window.speechSynthesis?.speak(new SpeechSynthesisUtterance(activeWord.de))
                  }
                  className="flex-1 rounded-2xl bg-secondary px-4 py-2.5 text-sm font-bold transition hover:bg-muted"
                >
                  <Volume2 className="mr-1 inline h-4 w-4" /> Aussprache
                </button>
                <button
                  onClick={() => {
                    setSavedWords((s) =>
                      s.some((x) => x.de === activeWord.de) ? s : [...s, activeWord],
                    );
                    saveWord({
                      type: "film",
                      mediaId: filmId,
                      word: { text: activeWord.de, translation: activeWord.fa },
                      context: activeCue?.de,
                      timestampSec: current,
                    });
                    setActiveWord(null);
                  }}
                  className="flex-1 rounded-2xl bg-[color:var(--flag-red)] px-4 py-2.5 text-sm font-bold text-white shadow-lg transition hover:-translate-y-0.5"
                >
                  <BookmarkPlus className="mr-1 inline h-4 w-4" /> Speichern
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  label,
  big,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
  big?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className={`grid place-items-center rounded-full bg-white/15 text-white transition hover:bg-white/25 ${
        big ? "h-10 w-10" : "h-8 w-8"
      }`}
    >
      {children}
    </button>
  );
}
