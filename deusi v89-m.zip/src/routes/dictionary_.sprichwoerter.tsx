import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { SectionHero } from "@/components/deusi/SectionHero";
import { HeroSearch } from "@/components/deusi/HeroSearch";
import { ProverbCard } from "@/components/deusi/dictionary/ProverbCard";
import { useProverbs } from "@/lib/api/useVocabulary";

export const Route = createFileRoute("/dictionary_/sprichwoerter")({
  head: () => ({
    meta: [
      { title: "Sprichwörter & Redewendungen — DEUSI" },
      {
        name: "description",
        content:
          "Alle deutschen Sprichwörter und Redewendungen mit wörtlicher Übersetzung, Bedeutung und persischer Entsprechung.",
      },
      { property: "og:title", content: "Sprichwörter & Redewendungen — DEUSI" },
      {
        property: "og:description",
        content: "Deutsche Redewendungen lernen: Bedeutung, Beispiel und persische Entsprechung.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProverbsPage,
});

const ACCENT = "#14B8A6";
const KINDS = ["all", "sprichwort", "redewendung"] as const;
const LEVELS = ["Alle", "A2", "B1", "B2", "C1"] as const;
const PAGE = 12;

function ProverbsPage() {
  const { proverbs: PROVERBS } = useProverbs();
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState<(typeof KINDS)[number]>("all");
  const [level, setLevel] = useState<(typeof LEVELS)[number]>("Alle");
  const [visible, setVisible] = useState(PAGE);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PROVERBS.filter((p) => {
      if (kind !== "all" && p.kind !== kind) return false;
      if (level !== "Alle" && p.cefr !== level) return false;
      if (q && !`${p.de} ${p.literal} ${p.meaning} ${p.fa}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [query, kind, level]);

  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return PROVERBS.filter((p) =>
      `${p.de} ${p.literal} ${p.meaning} ${p.fa}`.toLowerCase().includes(q),
    ).slice(0, 6);
  }, [query]);

  const scrollToList = () => {
    document.getElementById("proverb-list")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const shown = filtered.slice(0, visible);

  return (
    <div className="space-y-6 pb-16 animate-fade">
      <Link
        to="/dictionary"
        className="inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-card px-3 py-1.5 text-xs font-semibold text-muted-foreground transition hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Zurück zum Wörterbuch
      </Link>

      <SectionHero
        sectionKey="dictionary"
        allowOverflow
        titleDe="Sprichwörter & Redewendungen"
        titleFa="ضرب‌المثل‌ها و اصطلاحات آلمانی"
        highlight="Redewendungen"
        descDe="Idiomatische Ausdrücke mit wörtlicher Übersetzung, Bedeutung und persischer Entsprechung."
        descFa=""
        right={
          <HeroSearch
            value={query}
            onValueChange={setQuery}
            placeholder="Redewendung, Bedeutung oder Wort…"
            ariaLabel="Sprichwörter durchsuchen"
            emptyText="Keine Ausdrücke"
            className="flex-1"
            items={suggestions.map((p) => ({
              id: p.id,
              title: p.de,
              sub: p.meaning,
              badge: p.cefr,
              glyph: p.icon,
              color: p.color,
            }))}
            totalCount={filtered.length}
            onSelect={(id) => {
              const p = PROVERBS.find((x) => x.id === id);
              if (p) setQuery(p.de);
              scrollToList();
            }}
            onSubmit={scrollToList}
          />
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 rounded-full bg-secondary/60 p-1 text-[11px]">
          {KINDS.map((k) => (
            <button
              key={k}
              onClick={() => {
                setKind(k);
                setVisible(PAGE);
              }}
              className={`rounded-full px-3 py-1.5 font-semibold transition ${
                kind === k
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {k === "all" ? "Alle" : k === "sprichwort" ? "Sprichwörter" : "Redewendungen"}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {LEVELS.map((l) => (
            <button
              key={l}
              onClick={() => {
                setLevel(l);
                setVisible(PAGE);
              }}
              className={`rounded-full border px-3 py-1.5 text-[11px] font-semibold transition ${
                level === l
                  ? "border-transparent text-white shadow-sm"
                  : "border-border/60 bg-card text-muted-foreground hover:text-foreground"
              }`}
              style={level === l ? { background: ACCENT } : undefined}
            >
              {l}
            </button>
          ))}
        </div>
        <span className="ml-auto text-xs text-muted-foreground">
          {filtered.length} von {PROVERBS.length}
        </span>
      </div>

      <section id="proverb-list" className="scroll-mt-24">
        {shown.length === 0 ? (
          <div className="rounded-3xl border-2 border-dashed border-border/60 bg-muted/30 px-6 py-14 text-center">
            <div className="text-4xl">🔍</div>
            <p className="mt-3 text-sm font-semibold">Keine passenden Ausdrücke gefunden</p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {shown.map((p) => (
              <ProverbCard key={p.id} p={p} />
            ))}
          </div>
        )}
        {visible < filtered.length && (
          <div className="mt-6 flex justify-center">
            <button
              onClick={() => setVisible((v) => v + PAGE)}
              className="rounded-2xl px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:-translate-y-0.5"
              style={{ background: `linear-gradient(135deg, ${ACCENT}, ${ACCENT}cc)` }}
            >
              Weitere anzeigen
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
