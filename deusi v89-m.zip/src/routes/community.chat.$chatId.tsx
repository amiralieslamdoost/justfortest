import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { CommunityShell } from "@/components/deusi/community/CommunityShell";
import { ChatWindow } from "@/components/deusi/community/ChatWindow";
import { useCommunity } from "@/lib/deusi/community/store";

export const Route = createFileRoute("/community/chat/$chatId")({
  head: () => ({
    meta: [
      { title: "Chat — Community | DEUSI" },
      { name: "description", content: "Schreibe mit anderen Deutschlernenden in Echtzeit." },
      { property: "og:title", content: "Chat — Community | DEUSI" },
      {
        property: "og:description",
        content: "Schreibe mit anderen Deutschlernenden in Echtzeit.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChatPage,
});

function ChatPage() {
  const { chatId } = Route.useParams();
  const { chats, sendMessage, markRead, toggleJoined, deleteMessage, addMember } = useCommunity();
  const chat = chats.find((c) => c.id === chatId);

  useEffect(() => {
    if (chat) markRead(chat.id);
  }, [chat, markRead]);

  return (
    <CommunityShell activeChatId={chatId} showListOnMobile={false}>
      {chat ? (
        <ChatWindow
          chat={chat}
          onSend={(draft) => sendMessage(chat.id, draft)}
          onToggleJoined={() => toggleJoined(chat.id)}
          onDeleteMessage={(id) => deleteMessage(chat.id, id)}
          onAddMember={(userId) => addMember(chat.id, userId)}
        />
      ) : (
        <div className="neu-card grid h-full place-items-center p-10 text-center">
          <div>
            <h2 className="text-base font-black">Chat nicht gefunden</h2>
            <Link
              to="/community"
              className="mt-3 inline-flex rounded-2xl bg-[color:var(--section-primary,#c2410c)] px-4 py-2 text-sm font-bold text-white"
            >
              Zurück zur Übersicht
            </Link>
          </div>
        </div>
      )}
    </CommunityShell>
  );
}
