import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import { forwardRef, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { findTopic, grammarTopics, nodeKindMeta, type RoadmapNode } from "@/lib/deusi/mockGrammar";
import { FaHint } from "@/components/deusi/FaHint";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";
import { useGrammarTopic } from "@/lib/api/useGrammar";

export const Route = createFileRoute("/grammatik/$topicId/")({
  head: ({ params }) => {
    const t = findTopic(params.topicId);
    return {
      meta: [
        { title: `${t?.name ?? "Grammatik"} – DEUSI` },
        { name: "description", content: t?.subtitle ?? "Grammatik Lernpfad" },
      ],
    };
  },
  component: RoadmapPage,
  notFoundComponent: () => (
    <div className="grid min-h-[60vh] place-items-center text-muted-foreground">
      Thema nicht gefunden.
    </div>
  ),
});

function RoadmapPage() {
  const { topicId } = Route.useParams();
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  const { topic, topics } = useGrammarTopic(topicId);
  const nextTopics = useMemo(
    () =>
      topic
        ? topics.filter((t) => t.category === topic.category && t.id !== topic.id).slice(0, 3)
        : [],
    [topic, topics],
  );

  if (!currentUser) return null;
  if (!topic) return null;

  const doneCount = topic.nodes.filter((n) => n.status === "done").length;
  const currentNode =
    topic.nodes.find((n) => n.status === "current") ??
    topic.nodes.find((n) => n.status === "available") ??
    topic.nodes[0];

  return (
    <div className="mx-auto w-full max-w-[1200px] px-4 py-5 md:px-8 md:py-8">
      {/* Top bar */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <Link to="/grammatik" className="btn-back">
          <span aria-hidden>←</span> Zurück
        </Link>
        <nav
          className="hidden items-center gap-1.5 text-xs text-muted-foreground sm:flex"
          aria-label="Breadcrumb"
        >
          <Link to="/grammatik" className="hover:text-foreground">
            Grammatik
          </Link>
          <span>›</span>
          <span className="font-semibold text-foreground">{topic.name}</span>
        </nav>
      </div>

      {/* Hero + progress */}
      <div className="mb-10 grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="glass relative overflow-hidden rounded-[2rem] p-6 md:p-8"
          style={{ background: `linear-gradient(135deg, ${topic.accent}18, transparent 65%)` }}
        >
          <div
            className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full opacity-40 blur-3xl"
            style={{ background: topic.accent }}
          />
          <div className="relative grid items-center gap-6 md:grid-cols-[1fr_auto]">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
                <span>Lernpfad</span>
                <span
                  className="rounded-full px-2 py-0.5 text-[10px] font-black"
                  style={{ background: `${topic.accent}22`, color: topic.accent }}
                >
                  {topic.difficulty}
                </span>
                <BookmarkButton
                  type="grammar"
                  id={topic.id}
                  title={topic.name}
                  sub={topic.subtitle}
                  level={topic.difficulty}
                  to={`/grammatik/${topic.id}`}
                  variant="chip"
                />
              </div>
              <h1 className="mt-2 text-3xl font-black leading-tight tracking-tight text-foreground md:text-5xl">
                <span
                  className="bg-clip-text text-transparent"
                  style={{ backgroundImage: `linear-gradient(135deg, ${topic.accent}, #ec4899)` }}
                >
                  {topic.name}
                </span>
              </h1>
              <div className="mt-1 text-base font-semibold text-muted-foreground md:text-lg">
                {topic.subtitle}
              </div>
              <FaHint>مسیر یادگیری {topic.name}</FaHint>
              <p className="mt-3 max-w-md text-sm text-muted-foreground md:text-base">
                Entdecke <b>{topic.name}</b> Schritt für Schritt. Folge dem Pfad und meistere jeden
                Baustein.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Link
                  to="/grammatik/$topicId/$lessonId"
                  params={{ topicId: topic.id, lessonId: `${currentNode.id}-l` }}
                  className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-bold text-white shadow-lg transition-transform hover:scale-[1.02] active:scale-[0.98]"
                  style={{
                    background: topic.accent,
                    boxShadow: `0 12px 30px -12px ${topic.accent}`,
                  }}
                >
                  {topic.completion > 0 ? "Fortsetzen" : "Jetzt starten"} →
                </Link>
                <span className="rounded-full bg-background/70 px-3 py-2 text-xs font-semibold text-foreground ring-1 ring-black/5">
                  ⏱ {topic.duration} Min gesamt
                </span>
                <span className="rounded-full bg-background/70 px-3 py-2 text-xs font-semibold text-foreground ring-1 ring-black/5">
                  {topic.nodes.length} Bausteine
                </span>
              </div>
            </div>
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="hidden h-40 w-40 shrink-0 place-items-center rounded-full text-7xl md:grid md:h-52 md:w-52 md:text-8xl"
              style={{
                background: `radial-gradient(circle at 30% 30%, ${topic.accent}55, transparent 70%)`,
              }}
            >
              {topic.emoji}
            </motion.div>
          </div>
        </motion.div>

        {/* Progress card */}
        <motion.aside
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass rounded-[2rem] p-5 md:p-6"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-foreground">Dein Fortschritt</h3>
            <FaHint size="sm" inline>
              پیشرفت تو
            </FaHint>
          </div>
          <div className="mt-4 flex justify-center">
            <ProgressRing value={topic.completion} accent={topic.accent} />
          </div>
          <dl className="mt-5 space-y-2.5 text-sm">
            <StatRow
              label="Bausteine abgeschlossen"
              value={`${doneCount} / ${topic.nodes.length}`}
            />
            <StatRow label="Zeit gesamt" value={`${topic.duration} Min`} />
            <StatRow label="Niveau" value={topic.difficulty} />
            <StatRow label="Aktueller Schritt" value={currentNode.title} />
          </dl>
        </motion.aside>
      </div>

      {/* Roadmap section header */}
      <div className="mb-5 flex items-end justify-between">
        <div>
          <h2 className="text-xl font-black text-foreground md:text-2xl">Deine Roadmap</h2>
          <FaHint size="sm">مسیر گام‌به‌گام</FaHint>
        </div>
        <div className="hidden text-xs text-muted-foreground sm:block">
          Klicke auf einen freigeschalteten Baustein, um zu starten.
        </div>
      </div>

      {/* Roadmap - zigzag with scroll-animated curved path */}
      <RoadmapList nodes={topic.nodes} accent={topic.accent} topicId={topic.id} />

      {/* Legend */}
      <div className="mt-10 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        {Object.entries(nodeKindMeta).map(([k, m]) => (
          <span key={k} className="rounded-full bg-muted px-3 py-1">
            <span className="mr-1">{m.emoji}</span>
            {m.label}
          </span>
        ))}
      </div>

      {/* What's next */}
      {nextTopics.length > 0 && (
        <div className="mt-16">
          <div className="mb-4">
            <h2 className="text-xl font-black text-foreground md:text-2xl">
              Was kommt als Nächstes?
            </h2>
            <FaHint size="sm">مرحله بعدی چیه؟</FaHint>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {nextTopics.map((n) => (
              <Link
                key={n.id}
                to="/grammatik/$topicId"
                params={{ topicId: n.id }}
                className="glass group relative overflow-hidden rounded-3xl p-5 transition-transform hover:-translate-y-1"
              >
                <div
                  className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full opacity-30 blur-2xl"
                  style={{ background: n.accent }}
                />
                <div className="relative flex items-center gap-4">
                  <div
                    className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-3xl"
                    style={{ background: `${n.accent}18`, color: n.accent }}
                  >
                    {n.emoji}
                  </div>
                  <div className="min-w-0 flex-1">
                    <span
                      className="rounded-full px-2 py-0.5 text-[10px] font-black"
                      style={{ background: `${n.accent}22`, color: n.accent }}
                    >
                      {n.difficulty}
                    </span>
                    <h3 className="mt-1 truncate text-sm font-bold text-foreground">{n.name}</h3>
                    <p className="line-clamp-1 text-xs text-muted-foreground">{n.subtitle}</p>
                    <div className="mt-1 text-[11px] text-muted-foreground">
                      {n.nodes.length} Bausteine · ⏱ {n.duration} Min
                    </div>
                  </div>
                  <span className="ml-auto text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100">
                    →
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────

// (Legacy RoadmapCard removed — replaced by RoadmapRow + RoadmapNodeCard below.)

function StatusBadge({ status, accent }: { status: RoadmapNode["status"]; accent: string }) {
  if (status === "done") {
    return (
      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-emerald-500 text-white">
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M20 6L9 17l-5-5" />
        </svg>
      </div>
    );
  }
  if (status === "current") {
    return (
      <motion.div
        className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-white shadow-md"
        style={{ background: accent }}
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        ▶
      </motion.div>
    );
  }
  if (status === "locked") {
    return (
      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-muted text-muted-foreground">
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
        >
          <rect x="4" y="11" width="16" height="10" rx="2" />
          <path d="M8 11V7a4 4 0 0 1 8 0v4" />
        </svg>
      </div>
    );
  }
  return (
    <div className="h-8 w-8 shrink-0 rounded-full border-2 border-dashed border-muted-foreground/40" />
  );
}

function StatRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="truncate text-right font-bold text-foreground">{value}</dd>
    </div>
  );
}

function ProgressRing({ value, accent }: { value: number; accent: string }) {
  const size = 140;
  const stroke = 12;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = (value / 100) * c;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="rotate-[-90deg]">
      <defs>
        <linearGradient id={`ring-grad-${accent.replace("#", "")}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={accent} />
          <stop offset="100%" stopColor="#ec4899" />
        </linearGradient>
      </defs>
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        stroke="currentColor"
        className="text-muted opacity-40"
        strokeWidth={stroke}
        fill="none"
      />
      <motion.circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        stroke={`url(#ring-grad-${accent.replace("#", "")})`}
        strokeWidth={stroke}
        strokeLinecap="round"
        fill="none"
        strokeDasharray={c}
        initial={{ strokeDashoffset: c }}
        animate={{ strokeDashoffset: c - dash }}
        transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
      />
      <g style={{ transformOrigin: "center" }}>
        <text
          x={size / 2}
          y={size / 2 - 4}
          textAnchor="middle"
          className="fill-foreground"
          style={{ fontSize: 26, fontWeight: 900 }}
          transform={`rotate(90 ${size / 2} ${size / 2})`}
        >
          {value}%
        </text>
        <text
          x={size / 2}
          y={size / 2 + 16}
          textAnchor="middle"
          className="fill-muted-foreground"
          style={{ fontSize: 11, fontWeight: 600 }}
          transform={`rotate(90 ${size / 2} ${size / 2})`}
        >
          Meisterschaft
        </text>
      </g>
    </svg>
  );
}

function RoadmapList({
  nodes,
  accent,
  topicId,
}: {
  nodes: RoadmapNode[];
  accent: string;
  topicId: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const rowRefs = useRef<Array<HTMLDivElement | null>>([]);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 75%", "end 25%"] });
  const smooth = useSpring(scrollYProgress, { stiffness: 80, damping: 26, mass: 0.5 });
  const dashOffset = useTransform(smooth, (v) => 1 - Math.min(1, Math.max(0, v)));

  // Build a smooth cubic-bezier snake between card anchor points.
  const [layout, setLayout] = useState<{
    h: number;
    w: number;
    d: string;
    anchors: { x: number; y: number }[];
  }>({
    h: 0,
    w: 0,
    d: "",
    anchors: [],
  });

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const compute = () => {
      const box = el.getBoundingClientRect();
      const w = box.width;
      const h = el.scrollHeight;
      const anchors = rowRefs.current
        .filter((r): r is HTMLDivElement => !!r)
        .map((r, i) => {
          const rb = r.getBoundingClientRect();
          const y = rb.top - box.top + rb.height / 2;
          // side = left => card on left, anchor attaches to the card's right edge
          const side = i % 2 === 0 ? "left" : "right";
          const x = side === "left" ? rb.right - box.left : rb.left - box.left;
          return { x, y };
        });
      // Build path with vertical cubic beziers giving a soft snake curve.
      let d = "";
      anchors.forEach((p, i) => {
        if (i === 0) {
          d += `M ${p.x} ${p.y}`;
          return;
        }
        const prev = anchors[i - 1];
        const midY = (prev.y + p.y) / 2;
        d += ` C ${prev.x} ${midY}, ${p.x} ${midY}, ${p.x} ${p.y}`;
      });
      setLayout({ h, w, d, anchors });
    };
    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(el);
    window.addEventListener("resize", compute);
    // recompute after fonts/animations settle
    const t = window.setTimeout(compute, 250);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", compute);
      window.clearTimeout(t);
    };
  }, [nodes.length]);

  const gradId = `rm-snake-${accent.replace("#", "")}`;

  return (
    <div ref={ref} className="relative">
      {/* Curved snake path — desktop only */}
      {layout.w > 0 && (
        <svg
          className="pointer-events-none absolute inset-0 z-0 hidden md:block"
          width={layout.w}
          height={layout.h}
          viewBox={`0 0 ${layout.w} ${layout.h}`}
          aria-hidden
        >
          <defs>
            <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={accent} stopOpacity="0.95" />
              <stop offset="100%" stopColor="#ec4899" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          {/* Base dashed track */}
          <path
            d={layout.d}
            fill="none"
            stroke={accent}
            strokeOpacity="0.22"
            strokeWidth={1.4}
            strokeDasharray="4 6"
            strokeLinecap="round"
          />
          {/* Animated progress */}
          <motion.path
            d={layout.d}
            fill="none"
            stroke={`url(#${gradId})`}
            strokeWidth={1.6}
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray={1}
            style={{ strokeDashoffset: dashOffset, filter: `drop-shadow(0 0 3px ${accent}66)` }}
          />
          {/* Anchor dots */}
          {layout.anchors.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r={2.4} fill={accent} opacity={0.7} />
          ))}
        </svg>
      )}

      <div className="relative z-[1] space-y-6 md:space-y-14">
        {nodes.map((n, i) => (
          <RoadmapRow
            key={n.id}
            ref={(el: HTMLDivElement | null) => {
              rowRefs.current[i] = el;
            }}
            node={n}
            index={i}
            side={i % 2 === 0 ? "left" : "right"}
            accent={accent}
            topicId={topicId}
          />
        ))}
      </div>
    </div>
  );
}

const RoadmapRow = forwardRef<
  HTMLDivElement,
  {
    node: RoadmapNode;
    index: number;
    side: "left" | "right";
    accent: string;
    topicId: string;
  }
>(function RoadmapRow({ node, index, side, accent, topicId }, ref) {
  const meta = nodeKindMeta[node.kind];
  const locked = node.status === "locked";

  const card = locked ? (
    <div className="pointer-events-none">
      <RoadmapNodeCard node={node} index={index} accent={accent} meta={meta} />
    </div>
  ) : (
    <Link
      to="/grammatik/$topicId/$lessonId"
      params={{ topicId, lessonId: `${node.id}-l` }}
      className="block"
    >
      <RoadmapNodeCard node={node} index={index} accent={accent} meta={meta} />
    </Link>
  );

  return (
    <div className={`md:flex ${side === "left" ? "md:justify-start" : "md:justify-end"}`}>
      <div ref={ref} className="w-full md:w-[calc(50%-2.5rem)]">
        {card}
      </div>
    </div>
  );
});

function RoadmapNodeCard({
  node,
  index,
  accent,
  meta,
}: {
  node: RoadmapNode;
  index: number;
  accent: string;
  meta: (typeof nodeKindMeta)[keyof typeof nodeKindMeta];
}) {
  const locked = node.status === "locked";
  const current = node.status === "current";
  const done = node.status === "done";
  const numberColor = meta.hue;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      whileHover={locked ? undefined : { y: -3 }}
      className={`glass relative overflow-hidden rounded-[1.75rem] p-5 shadow-sm md:p-6 ${
        locked ? "opacity-60" : ""
      } ${current ? "ring-2" : ""}`}
      style={{
        boxShadow: current ? `0 20px 60px -20px ${accent}66, 0 0 0 2px ${accent}` : undefined,
      }}
    >
      <div
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-30 blur-3xl"
        style={{ background: numberColor }}
      />
      <div className="relative">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-2xl shadow-inner md:h-14 md:w-14"
              style={{ background: `${numberColor}22`, color: numberColor }}
            >
              {meta.emoji}
            </div>
            <div className="min-w-0">
              <div className="text-[11px] font-bold uppercase tracking-[0.15em] text-muted-foreground">
                Schritt {index + 1} · {meta.label}
              </div>
              <h3 className="truncate text-base font-bold text-foreground md:text-lg">
                {node.title}
              </h3>
              <FaHint size="sm">گام {index + 1}</FaHint>
            </div>
          </div>
          <StatusBadge status={node.status} accent={accent} />
        </div>
        <p className="mt-3 text-sm text-muted-foreground">{node.description}</p>
        <div className="mt-4 flex flex-wrap items-center gap-1.5 text-[11px]">
          <span className="rounded-full bg-muted px-2.5 py-1 font-semibold">
            ⏱ {node.duration} Min
          </span>
          <span className="rounded-full bg-muted px-2.5 py-1 font-semibold">{node.difficulty}</span>
          {done && (
            <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 font-bold text-emerald-600">
              ✓ انجام شد
            </span>
          )}
          {current && (
            <span
              className="rounded-full px-2.5 py-1 font-bold"
              style={{ background: `${accent}22`, color: accent }}
            >
              نوبت شما
            </span>
          )}
          {locked && (
            <span className="rounded-full bg-muted px-2.5 py-1 font-semibold text-muted-foreground">
              🔒 قفل
            </span>
          )}
        </div>
      </div>
      <div
        className="pointer-events-none absolute -bottom-6 -right-2 text-8xl font-black leading-none opacity-[0.06] md:text-9xl"
        style={{ color: numberColor }}
      >
        {index + 1}
      </div>
    </motion.div>
  );
}
