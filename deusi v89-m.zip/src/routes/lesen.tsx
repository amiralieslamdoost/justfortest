import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  Search,
  Bell,
  BookOpen,
  Clock,
  TrendingUp,
  Flame,
  ChevronRight,
  Sparkles,
  ArrowRight,
  X,
  Filter,
} from "lucide-react";
import { readingCategories, cefrLevels, readingStats, type CEFR } from "@/lib/deusi/mockReading";
import { ArticleCard } from "@/components/deusi/reading/ArticleCard";
import { Fa } from "@/components/deusi/Fa";
import { SectionHero } from "@/components/deusi/SectionHero";
import { HeroSearch } from "@/components/deusi/HeroSearch";
import { useArticles, useReadingProgressMap } from "@/lib/api/useReading";

export const Route = createFileRoute("/lesen")({
  head: () => ({
    meta: [
      { title: "Lesen — DEUSI" },
      { name: "description", content: "Deutsche Texte lesen und dein Leseverständnis verbessern." },
    ],
  }),
  component: LesenPage,
});

function LesenPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("fuerdich");
  const [level, setLevel] = useState<CEFR | "alle">("alle");
  const [visible, setVisible] = useState(6);
  const [mobileFilters, setMobileFilters] = useState(false);

  const { articles: liveArticles } = useArticles({
    q,
    category: cat as never,
    level,
    perPage: 100,
  });
  const { progress: readingProgress } = useReadingProgressMap();
  const filtered = liveArticles;

  const navigate = useNavigate();
  const suggestions = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return liveArticles
      .filter((a) => `${a.title} ${a.description}`.toLowerCase().includes(s))
      .slice(0, 6);
  }, [q, liveArticles]);

  const withProgress = useMemo(
    () =>
      liveArticles.map((a) => ({
        ...a,
        progress: readingProgress[a.id]?.progress ?? a.progress ?? 0,
      })),
    [liveArticles, readingProgress],
  );
  const cont = useMemo(
    () => withProgress.find((a) => a.progress > 0 && a.progress < 100),
    [withProgress],
  );
  const recent = useMemo(
    () => withProgress.filter((a) => a.progress > 0).slice(0, 3),
    [withProgress],
  );
  const activeFiltersCount = (cat !== "fuerdich" ? 1 : 0) + (level !== "alle" ? 1 : 0);

  return (
    <div className="space-y-5 pb-16 animate-fade">
      {/* Unified section header */}
      <SectionHero
        sectionKey="reading"
        allowOverflow
        right={
          <>
            <HeroSearch
              value={q}
              onValueChange={setQ}
              placeholder="Texte, Themen oder Übungen suchen…"
              ariaLabel="Texte durchsuchen"
              emptyText="Keine Texte"
              className="flex-1 sm:min-w-[260px]"
              items={suggestions.map((a) => ({
                id: a.id,
                title: a.title,
                sub: a.description,
                badge: a.level,
                glyph: "📖",
                color: "#DD2222",
              }))}
              totalCount={filtered.length}
              onSelect={(id) => navigate({ to: "/lesen/$articleId", params: { articleId: id } })}
              onSubmit={() =>
                document
                  .getElementById("lesen-results")
                  ?.scrollIntoView({ behavior: "smooth", block: "start" })
              }
            />
            <button
              onClick={() => setMobileFilters(true)}
              className="relative grid h-11 w-11 place-items-center rounded-2xl bg-white/15 text-white ring-1 ring-white/20 backdrop-blur hover:bg-white/25 lg:hidden"
              aria-label="Filter"
            >
              <Filter className="h-4 w-4" />
              {activeFiltersCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 w-4 place-items-center rounded-full bg-white text-[10px] font-bold text-[color:var(--section-primary)]">
                  {activeFiltersCount}
                </span>
              )}
            </button>
            <button
              className="grid h-11 w-11 place-items-center rounded-2xl bg-white/15 text-white ring-1 ring-white/20 backdrop-blur hover:bg-white/25"
              aria-label="Benachrichtigungen"
            >
              <Bell className="h-4 w-4" />
            </button>
          </>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="min-w-0 space-y-5">
          {/* KPI row */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <KpiCard
              label="Mein Niveau"
              fa="سطح من"
              value={readingStats.level}
              sub={`Ziel: ${readingStats.nextLevel} · ${readingStats.levelProgress}%`}
              color="#DD2222"
              tint="#FEE9E7"
              pct={readingStats.levelProgress}
              icon={<span className="text-base font-black">A2</span>}
              big
            />
            <KpiCard
              icon={<BookOpen className="h-4 w-4" />}
              label="Texte"
              fa="متن‌های خوانده‌شده"
              value={readingStats.textsRead}
              sub="gelesen"
              delta={`+${readingStats.textsReadDelta} Woche`}
              color="#8B5CF6"
              tint="#F3ECFF"
            />
            <KpiCard
              icon={<span className="text-sm font-black">Aa</span>}
              label="Wörter"
              fa="واژه‌های آموخته"
              value={readingStats.wordsLearned}
              sub="gelernt"
              delta={`+${readingStats.wordsLearnedDelta} Woche`}
              color="#22C55E"
              tint="#E7F8EE"
            />
            <KpiCard
              icon={<Clock className="h-4 w-4" />}
              label="Lesezeit"
              fa="زمان مطالعه"
              value={`${Math.floor(readingStats.readingMinutes / 60)}h ${readingStats.readingMinutes % 60}m`}
              sub="Gesamt"
              delta={`+${Math.floor(readingStats.readingMinutesDelta / 60)}h${readingStats.readingMinutesDelta % 60}m`}
              color="#EAB308"
              tint="#FFF5D6"
            />
            <KpiCard
              icon={<TrendingUp className="h-4 w-4" />}
              label="Verständnis"
              fa="درک مطلب"
              value={`${readingStats.comprehension}%`}
              sub="Ø"
              delta={`+${readingStats.comprehensionDelta}%`}
              color="#3B82F6"
              tint="#E6F2FF"
            />
          </div>

          {/* Continue reading — hero card */}
          {cont && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="neu-card group relative overflow-hidden"
            >
              <div className="absolute inset-0" aria-hidden>
                <img
                  loading="lazy"
                  decoding="async"
                  src={cont.cover}
                  alt=""
                  className="h-full w-full object-cover opacity-25 transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-card via-card/95 to-card/50" />
              </div>
              <div className="relative flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:gap-5 sm:p-5">
                <div className="relative h-36 w-full shrink-0 overflow-hidden rounded-2xl shadow-md sm:h-28 sm:w-44">
                  <img
                    loading="lazy"
                    decoding="async"
                    src={cont.cover}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-black/50 to-transparent sm:hidden" />
                  <span className="absolute bottom-2 left-2 rounded-md bg-white/95 px-1.5 py-0.5 text-[10px] font-black text-foreground shadow ring-1 ring-black/5 sm:hidden">
                    {cont.progress}%
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 rounded-full bg-[var(--flag-red)]/12 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-[var(--flag-red)]">
                      <Flame className="h-3 w-3" /> Weiterlesen
                    </span>
                    <Fa className="fa-hint-xs">ادامهٔ خواندن</Fa>
                  </div>
                  <div className="mt-2 text-lg font-black leading-tight sm:text-xl">
                    {cont.title}
                  </div>
                  <div className="mt-1 line-clamp-1 text-sm text-muted-foreground">
                    {cont.description}
                  </div>
                  <div className="mt-3 flex items-center gap-3">
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${cont.progress}%` }}
                        transition={{ duration: 0.7 }}
                        className="h-full rounded-full"
                        style={{ background: "var(--flag-red)" }}
                      />
                    </div>
                    <span className="text-xs font-bold tabular-nums text-muted-foreground">
                      {cont.progress}%
                    </span>
                  </div>
                </div>
                <Link
                  to="/lesen/$articleId"
                  params={{ articleId: cont.id }}
                  className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-2xl px-5 py-3 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg"
                  style={{ background: "var(--flag-black)" }}
                >
                  Fortsetzen <ChevronRight className="h-4 w-4" />
                </Link>
              </div>
            </motion.div>
          )}

          {/* Category chips + level toolbar */}
          <div className="rounded-2xl bg-card p-2 ring-1 ring-border sm:p-3">
            <div className="flex flex-wrap items-center gap-1.5">
              {readingCategories.map((c) => (
                <button
                  key={c.key}
                  onClick={() => setCat(c.key)}
                  className={`rounded-full px-3 py-1.5 text-xs font-semibold transition sm:text-sm ${
                    cat === c.key
                      ? "bg-[var(--flag-black)] text-white shadow-sm"
                      : "text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  {c.label}
                </button>
              ))}
              {/* Level tabs — inline separator, desktop only */}
              <div className="mx-1 hidden h-6 w-px bg-border lg:block" aria-hidden />
              <div className="hidden items-center gap-1 lg:flex">
                <span className="mr-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Niveau
                </span>
                <button
                  onClick={() => setLevel("alle")}
                  className={`rounded-full px-2.5 py-1 text-xs font-semibold transition ${
                    level === "alle"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  Alle
                </button>
                {cefrLevels.map((l) => (
                  <button
                    key={l}
                    onClick={() => setLevel(l)}
                    className={`rounded-full px-2.5 py-1 text-xs font-semibold transition ${
                      level === l
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-secondary"
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Recommended list */}
          <div id="lesen-results" className="neu-card scroll-mt-24 p-4 sm:p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <div className="font-bold">
                  {q ? `Suchergebnisse (${filtered.length})` : "Empfohlene Texte für dich"}
                </div>
                <Fa className="fa-hint-xs">{q ? "نتایج جستجو" : "متن‌های پیشنهادی برای شما"}</Fa>
              </div>
              {filtered.length > 3 && !q && (
                <span className="rounded-full bg-secondary px-2.5 py-0.5 text-[11px] font-semibold text-muted-foreground">
                  {filtered.length} Texte
                </span>
              )}
            </div>
            {filtered.length === 0 ? (
              <div className="rounded-2xl bg-secondary/50 p-8 text-center">
                <div className="text-sm font-semibold">Keine Texte gefunden</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  Versuche einen anderen Filter oder Suchbegriff.
                </div>
                <button
                  onClick={() => {
                    setQ("");
                    setCat("fuerdich");
                    setLevel("alle");
                  }}
                  className="mt-3 rounded-full bg-secondary px-4 py-1.5 text-xs font-semibold hover:bg-muted"
                >
                  Filter zurücksetzen
                </button>
              </div>
            ) : (
              <>
                <div className="space-y-3">
                  {filtered.slice(0, visible).map((a) => (
                    <ArticleCard key={a.id} article={a} />
                  ))}
                </div>
                {visible < filtered.length && (
                  <div className="mt-4 grid place-items-center">
                    <button
                      onClick={() => setVisible((v) => v + 6)}
                      className="rounded-full bg-secondary px-5 py-2 text-sm font-semibold hover:bg-muted"
                    >
                      Mehr Texte laden ({filtered.length - visible})
                    </button>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Recently read */}
          {recent.length > 0 && (
            <div className="neu-card p-4 sm:p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="font-bold">Zuletzt gelesen</div>
                  <Fa className="fa-hint-xs">اخیراً خوانده‌شده</Fa>
                </div>
              </div>
              <motion.div
                className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3"
                initial="hidden"
                animate="show"
                variants={{ hidden: {}, show: { transition: { staggerChildren: 0.06 } } }}
              >
                {recent.map((a) => (
                  <motion.div
                    key={a.id}
                    variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}
                  >
                    <ArticleCard article={a} variant="grid" />
                  </motion.div>
                ))}
              </motion.div>
            </div>
          )}
        </div>

        {/* Right column */}
        <aside className="min-w-0 space-y-4">
          {/* Reading progress chart */}
          <div className="neu-card p-5">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <div className="font-bold">Lese-Fortschritt</div>
                <Fa className="fa-hint-xs">پیشرفت مطالعه</Fa>
              </div>
              <span className="rounded-full bg-secondary px-2.5 py-0.5 text-[11px] font-semibold text-muted-foreground">
                Diese Woche
              </span>
            </div>
            <MiniAreaChart data={readingStats.weeklyProgress} />
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <Stat label="Diese Woche" fa="این هفته" value={`${readingStats.weeklyTexts} Texte`} />
              <Stat
                label="Verständnis"
                fa="درک مطلب"
                value={`${readingStats.weeklyComprehension}%`}
              />
              <Stat label="Wörter" fa="واژه‌ها" value={`${readingStats.weeklyWords}`} />
            </div>
          </div>

          {/* Streak card */}
          <div
            className="neu-card overflow-hidden p-5"
            style={{ background: "linear-gradient(160deg,#FEE9E7,#FFD1CC)" }}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold uppercase tracking-widest text-[#DD2222]">
                  Streak
                </div>
                <div className="mt-1 text-3xl font-black">
                  {readingStats.streakDays}
                  <span className="ml-1 text-sm font-semibold">Tage</span>
                </div>
                <Fa className="fa-hint-xs">روز پیاپی</Fa>
              </div>
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-white/70 text-[#DD2222] shadow-inner">
                <Flame className="h-8 w-8" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Lies heute einen Text, um deinen Streak zu behalten.
            </p>
          </div>

          {/* Übung des Tages */}
          <div
            className="neu-card p-5"
            style={{ background: "linear-gradient(160deg,#FFF8E6,#FEF0D8)" }}
          >
            <div className="flex items-center gap-2 text-sm font-bold">
              <Sparkles className="h-4 w-4" /> Übung des Tages
            </div>
            <Fa className="fa-hint-xs">تمرین روز</Fa>
            <div className="mt-3 text-sm font-semibold">{readingStats.exerciseOfTheDay.prompt}</div>
            <ExerciseOfTheDay />
          </div>

          {/* Daily challenge */}
          <div className="neu-card p-5">
            <div className="flex items-center gap-2">
              <div className="grid h-10 w-10 place-items-center rounded-2xl bg-[#FEE9E7] text-[#DD2222]">
                <Flame className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-bold">{readingStats.dailyChallenge.title}</div>
                <div className="line-clamp-2 text-xs text-muted-foreground">
                  {readingStats.dailyChallenge.description}
                </div>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${readingStats.dailyChallenge.progress}%`,
                    background: "var(--flag-red)",
                  }}
                />
              </div>
              <span className="text-[11px] font-bold tabular-nums text-muted-foreground">
                {readingStats.dailyChallenge.progress}%
              </span>
            </div>
          </div>

          {/* Vocabulary */}
          <div className="neu-card p-5">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <div className="font-bold">Wortschatz aus deinen Texten</div>
                <Fa className="fa-hint-xs">واژگان از متن‌های شما</Fa>
              </div>
              <button className="text-xs font-semibold text-[var(--flag-red)] hover:underline">
                Alle
              </button>
            </div>
            <div className="divide-y divide-border">
              {readingStats.vocabularyOfTheDay.map((w) => (
                <div key={w.word} className="flex items-center justify-between py-2 text-sm">
                  <span className="font-semibold">{w.word}</span>
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold text-muted-foreground">
                    {w.pos}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>

      {/* Mobile filter sheet */}
      {mobileFilters && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setMobileFilters(false)}
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="absolute inset-x-0 bottom-0 rounded-t-3xl bg-card p-5 shadow-2xl"
          >
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-muted" />
            <div className="mb-4 flex items-center justify-between">
              <div className="text-lg font-black">Filter</div>
              <button
                onClick={() => setMobileFilters(false)}
                className="grid h-9 w-9 place-items-center rounded-full hover:bg-secondary"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <div className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  Niveau
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setLevel("alle")}
                    className={`rounded-full px-4 py-2 text-sm font-semibold ${level === "alle" ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
                  >
                    Alle
                  </button>
                  {cefrLevels.map((l) => (
                    <button
                      key={l}
                      onClick={() => setLevel(l)}
                      className={`rounded-full px-4 py-2 text-sm font-semibold ${level === l ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  Kategorie
                </div>
                <div className="flex flex-wrap gap-2">
                  {readingCategories.map((c) => (
                    <button
                      key={c.key}
                      onClick={() => setCat(c.key)}
                      className={`rounded-full px-4 py-2 text-sm font-semibold ${
                        cat === c.key
                          ? "bg-[var(--flag-black)] text-white"
                          : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-6 flex gap-2">
              <button
                onClick={() => {
                  setCat("fuerdich");
                  setLevel("alle");
                }}
                className="flex-1 rounded-2xl bg-secondary px-4 py-3 text-sm font-bold hover:bg-muted"
              >
                Zurücksetzen
              </button>
              <button
                onClick={() => setMobileFilters(false)}
                className="flex-[2] rounded-2xl bg-[var(--flag-red)] px-4 py-3 text-sm font-bold text-white shadow-md"
              >
                {filtered.length} Texte anzeigen
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

function ExerciseOfTheDay() {
  const [pick, setPick] = useState<string | null>(null);
  const ex = readingStats.exerciseOfTheDay;
  const answered = pick !== null;
  return (
    <>
      <div className="mt-3 space-y-2">
        {ex.options.map((o) => {
          const isPick = pick === o.key;
          const isRight = o.key === ex.correctKey;
          const cls = !answered
            ? "bg-white/60 hover:bg-white dark:bg-white/5 dark:hover:bg-white/10"
            : isRight
              ? "bg-green-100 ring-1 ring-green-300 dark:bg-green-500/15"
              : isPick
                ? "bg-red-100 ring-1 ring-red-300 dark:bg-red-500/15"
                : "bg-white/40 dark:bg-white/5 opacity-70";
          return (
            <button
              key={o.key}
              disabled={answered}
              onClick={() => setPick(o.key)}
              className={`flex w-full items-center gap-3 rounded-2xl px-3 py-2 text-left text-sm transition ${cls}`}
            >
              <span className="grid h-6 w-6 place-items-center rounded-full bg-white text-xs font-bold shadow-sm">
                {o.key}
              </span>
              <span className="flex-1">{o.label}</span>
              {answered && isRight && <span className="text-green-600">✓</span>}
              {answered && isPick && !isRight && <span className="text-red-600">✗</span>}
            </button>
          );
        })}
      </div>
      <button
        onClick={() => setPick(null)}
        className={`mt-3 inline-flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:-translate-y-0.5 ${
          answered ? "bg-[var(--flag-black)]" : "bg-[var(--flag-gold)]"
        }`}
      >
        {answered ? "Nochmal versuchen" : "Übung starten"} <ArrowRight className="h-4 w-4" />
      </button>
    </>
  );
}

function KpiCard({
  icon,
  label,
  fa,
  value,
  sub,
  delta,
  color,
  tint,
  pct,
  big,
}: {
  icon: React.ReactNode;
  label: string;
  fa?: string;
  value: React.ReactNode;
  sub?: string;
  delta?: string;
  color: string;
  tint: string;
  pct?: number;
  big?: boolean;
}) {
  return (
    <motion.div
      whileHover={{ y: -3 }}
      className="neu-card cat-glow group relative overflow-hidden p-3 sm:p-4"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-70"
        style={{ background: `radial-gradient(circle, ${color}55, transparent 60%)` }}
      />
      <div className="relative flex items-center justify-between gap-2">
        <div
          className="grid h-8 w-8 shrink-0 place-items-center rounded-xl shadow-inner sm:h-9 sm:w-9"
          style={{ background: tint, color }}
        >
          {icon}
        </div>
        <div className="min-w-0 text-right">
          <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground sm:text-[11px]">
            {label}
          </div>
          {fa && <Fa className="fa-hint-xs hidden sm:block">{fa}</Fa>}
        </div>
      </div>
      <div
        className={`relative mt-2 font-black leading-none tabular-nums ${big ? "text-xl sm:text-2xl" : "text-lg sm:text-xl"}`}
      >
        {value}
      </div>
      {(sub || delta) && (
        <div className="relative mt-1.5 flex flex-wrap items-baseline gap-x-1.5 gap-y-0.5 text-[10px] sm:text-[11px]">
          {sub && <span className="text-muted-foreground">{sub}</span>}
          {delta && <span className="font-semibold text-green-600">{delta}</span>}
        </div>
      )}
      {typeof pct === "number" && (
        <div className="relative mt-2.5 h-1.5 overflow-hidden rounded-full bg-secondary">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.9 }}
            className="h-full rounded-full"
            style={{ background: color }}
          />
        </div>
      )}
    </motion.div>
  );
}

function Stat({ label, fa, value }: { label: string; fa?: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
      {fa && <Fa className="fa-hint-xs">{fa}</Fa>}
      <div className="text-sm font-bold">{value}</div>
    </div>
  );
}

function MiniAreaChart({ data }: { data: { label: string; value: number }[] }) {
  const w = 260,
    h = 100,
    pad = 6;
  const max = Math.max(...data.map((d) => d.value), 1);
  const step = (w - pad * 2) / (data.length - 1);
  const pts = data.map(
    (d, i) => [pad + i * step, h - pad - (d.value / max) * (h - pad * 2)] as const,
  );
  const path = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(" ");
  const area = `${path} L${pts[pts.length - 1][0]},${h - pad} L${pts[0][0]},${h - pad} Z`;
  return (
    <div>
      <svg viewBox={`0 0 ${w} ${h}`} className="h-24 w-full">
        <defs>
          <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#DD2222" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#DD2222" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#areaGrad)" />
        <path
          d={path}
          stroke="#DD2222"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {pts.map((p, i) => (
          <circle key={i} cx={p[0]} cy={p[1]} r={3} fill="#fff" stroke="#DD2222" strokeWidth="2" />
        ))}
      </svg>
      <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
        {data.map((d) => (
          <span key={d.label}>{d.label}</span>
        ))}
      </div>
    </div>
  );
}
