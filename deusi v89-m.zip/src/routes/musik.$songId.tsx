import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { Fa } from "@/components/deusi/Fa";
import { MusicPlayer, fmtTime } from "@/components/deusi/music/MusicPlayer";
import { KaraokeLyrics } from "@/components/deusi/music/KaraokeLyrics";
import { SongCard } from "@/components/deusi/music/SongCard";
import { SongCover } from "@/components/deusi/music/SongCover";
import { SongVocabList } from "@/components/deusi/music/SongVocabList";
import { songVocabToWord } from "@/lib/deusi/musicVocab";
import { type LyricLine, type SongVocab } from "@/lib/deusi/mockMusic";
import { getSong } from "@/lib/api/media";
import { useArtists, useMediaProgress, useMediaVocab, useSong, useSongs } from "@/lib/api/useMedia";
import { ErrorCard } from "@/components/deusi/ErrorCard";
import { BookmarkButton } from "@/components/deusi/BookmarkButton";

export const Route = createFileRoute("/musik/$songId")({
  loader: async ({ params }) => {
    const song = await getSong(params.songId);
    if (!song) throw notFound();
    return { song };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Song nicht gefunden | DEUSI" }, { name: "robots", content: "noindex" }],
      };
    }
    const { song } = loaderData;
    const title = `${song.title} — Songtext & Vokabeln | DEUSI`;
    const desc = `Deutsch lernen mit „${song.title}“: synchroner Songtext, Übersetzung und Vokabeln auf Niveau ${song.level}.`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "music.song" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  errorComponent: ({ error, reset }) => <ErrorCard error={error} reset={reset} />,
  notFoundComponent: SongNotFound,
  component: SongDetail,
});

function SongNotFound() {
  return (
    <div className="neu-card p-8 text-center">
      <h1 className="text-xl font-black">Song nicht gefunden</h1>
      <Fa className="fa-hint-xs mt-1">این آهنگ پیدا نشد.</Fa>
      <Link
        to="/musik"
        className="mt-4 inline-block rounded-xl bg-secondary px-4 py-2 text-sm font-bold"
      >
        Zurück zur Musik
      </Link>
    </div>
  );
}

function SongDetail() {
  const { song: loaderSong } = Route.useLoaderData();
  // دادهٔ تازه از API؛ در نبود بک‌اند همان دادهٔ loader می‌ماند.
  const { song: liveSong } = useSong(loaderSong.id);
  const song = liveSong ?? loaderSong;
  const { currentUser, hydrated, addCustomWord } = useDeusi();
  const router = useRouter();
  const { artists } = useArtists();
  const { songs } = useSongs({ perPage: 200 });
  const { state: progressState, patch: patchProgress } = useMediaProgress("song", song.id);
  const { saveWord } = useMediaVocab({ type: "song", mediaId: song.id });

  const [currentTime, setCurrentTime] = useState(0);
  const [seekTo, setSeekTo] = useState(0);
  const [seekNonce, setSeekNonce] = useState(0);
  const [showTranslation, setShowTranslation] = useState(true);
  const [loopLine, setLoopLine] = useState<LyricLine | null>(null);
  const [savedIds, setSavedIds] = useState<string[]>([]);

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);
  useEffect(() => {
    setCurrentTime(0);
    setSeekTo(0);
    setSeekNonce((n) => n + 1);
    setLoopLine(null);
    setSavedIds([]);
  }, [song.id]);
  // ذخیرهٔ پیشرفت پخش هر ۱۰ ثانیه (خوش‌بینانه + صف آفلاین).
  const bucket = Math.floor(currentTime / 10);
  useEffect(() => {
    if (!currentTime || !song.durationSec) return;
    patchProgress({
      positionSec: currentTime,
      progress: Math.min(100, Math.round((currentTime / song.durationSec) * 100)),
      finished: currentTime / song.durationSec >= 0.98,
      plays: Math.max(1, progressState.plays),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bucket, song.id]);
  if (!currentUser) return null;

  const artist = artists.find((a) => a.id === song.artistId);
  const related = songs
    .filter((s) => s.id !== song.id && (s.artistId === song.artistId || s.genre === song.genre))
    .slice(0, 4);

  function seek(sec: number) {
    setSeekTo(sec);
    setSeekNonce((n) => n + 1);
    setCurrentTime(sec);
  }

  function saveVocab(v: SongVocab) {
    if (savedIds.includes(v.id)) return;
    const word = songVocabToWord(v, song.title);
    addCustomWord(word);
    saveWord({
      type: "song",
      mediaId: song.id,
      word,
      context: v.example,
      timestampSec: currentTime,
    });
    setSavedIds((prev) => [...prev, v.id]);
  }

  function saveAllVocab() {
    song.vocab.forEach((v: SongVocab) => {
      if (!savedIds.includes(v.id)) addCustomWord(songVocabToWord(v, song.title));
    });
    setSavedIds((prev) => [...new Set([...prev, ...song.vocab.map((v: SongVocab) => v.id)])]);
  }

  return (
    <div className="space-y-6 animate-fade">
      <div className="flex items-center justify-between gap-2">
        <Link to="/musik" className="btn-back" aria-label="Zurück zur Songliste">
          <svg
            viewBox="0 0 24 24"
            width="14"
            height="14"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m15 18-6-6 6-6" />
          </svg>
          Zurück
          <Fa inline className="!text-white/80">
            بازگشت
          </Fa>
        </Link>
        <nav className="hidden items-center gap-2 text-xs font-semibold text-muted-foreground sm:flex">
          <Link to="/musik" className="hover:text-foreground">
            Musik
          </Link>
          <span>/</span>
          <span className="text-foreground">{song.title}</span>
        </nav>
      </div>

      {/* Combined cover + player: one connected card */}
      <section
        className="relative overflow-hidden rounded-3xl border border-border/60 bg-card shadow-sm"
        style={{
          background: `linear-gradient(120deg, ${song.accent}22 0%, transparent 55%), var(--card)`,
        }}
      >
        <div className="grid gap-5 p-4 sm:grid-cols-[auto_minmax(0,1fr)] sm:items-end sm:gap-6 sm:p-6">
          <div className="w-36 shrink-0 sm:w-48">
            <SongCover
              cover={song.cover}
              url={song.coverUrl}
              alt={`${song.title} — Cover`}
              className="shadow-2xl ring-1 ring-black/5"
            />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              <span
                className="inline-block h-1.5 w-1.5 rounded-full"
                style={{ background: song.accent }}
                aria-hidden
              />
              {song.genre}
              <Fa inline className="!text-muted-foreground/80">
                {artist?.name}
              </Fa>
            </div>
            <h1 className="mt-1.5 text-2xl font-black leading-tight sm:text-4xl">{song.title}</h1>
            <p className="mt-1 truncate text-sm font-semibold text-muted-foreground">
              {artist?.name} · {song.album} · {song.year}
            </p>
            <Fa className="fa-hint-xs mt-1 line-clamp-2">{song.noteFa}</Fa>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span
                className="rounded-full px-2.5 py-1 text-[11px] font-black text-white"
                style={{ background: song.accent, boxShadow: `0 8px 20px -10px ${song.accent}` }}
              >
                {song.level}
              </span>
              <span className="rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-black tabular-nums text-muted-foreground">
                {fmtTime(song.durationSec)}
              </span>
              <span className="rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-black text-muted-foreground">
                {song.plays}
              </span>
              <BookmarkButton
                type="music"
                id={song.id}
                title={song.title}
                sub={`${artist?.name ?? ""} · ${song.album}`}
                level={song.level}
                to={`/musik/${song.id}`}
                variant="chip"
              />
            </div>
          </div>
        </div>

        {/* Player attached to bottom, no gap */}
        <div className="border-t border-border/60 bg-background/60 px-4 pb-4 pt-3 backdrop-blur-sm sm:px-6 sm:pb-5">
          <MusicPlayer
            waveform={song.waveform}
            durationSec={song.durationSec}
            accent={song.accent}
            seekTo={seekTo}
            seekNonce={seekNonce}
            onTimeUpdate={setCurrentTime}
            loopRange={loopLine ? { start: loopLine.start, end: loopLine.end } : null}
          />
        </div>
      </section>

      <div className="grid gap-5 grid-cols-[minmax(0,1fr)] lg:grid-cols-[minmax(0,1fr)_320px]">
        <section className="neu-card p-4 sm:p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black">Songtext</h2>
              <Fa className="fa-hint-xs">متن همگام آهنگ</Fa>
            </div>
            <button
              onClick={() => setShowTranslation((v) => !v)}
              aria-pressed={showTranslation}
              className="rounded-xl border border-border bg-card px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary"
            >
              {showTranslation ? "Übersetzung aus" : "Übersetzung an"}
            </button>
          </div>
          <KaraokeLyrics
            song={song}
            currentTime={currentTime}
            onSeekLine={seek}
            showTranslation={showTranslation}
            loopLineId={loopLine?.id ?? null}
            onToggleLoop={setLoopLine}
            savedIds={savedIds}
            onSaveVocab={saveVocab}
          />
        </section>

        <aside className="space-y-5">
          <section className="neu-card p-4">
            <div className="mb-3">
              <h2 className="text-sm font-black">Wortschatz</h2>
              <Fa className="fa-hint-xs">واژگان این آهنگ</Fa>
            </div>
            <SongVocabList
              song={song}
              savedIds={savedIds}
              onSave={saveVocab}
              onSaveAll={saveAllVocab}
            />
            <Link
              to="/leitner"
              className="mt-3 block rounded-xl px-3 py-2 text-center text-sm font-bold text-white"
              style={{ background: song.accent }}
            >
              Zur Leitner-Box
            </Link>
          </section>

          {related.length > 0 && (
            <section className="space-y-3">
              <div>
                <h2 className="text-sm font-black">Ähnliche Songs</h2>
                <Fa className="fa-hint-xs">آهنگ‌های مشابه</Fa>
              </div>
              <div className="space-y-3">
                {related.map((s) => (
                  <SongCard key={s.id} song={s} />
                ))}
              </div>
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}
