import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AtSign, Eye, EyeOff, Loader2, Lock, LogIn, AlertCircle } from "lucide-react";
import { useDeusi } from "@/lib/deusi/store";
import { AuthShell, AuthField } from "@/components/deusi/AuthShell";

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>): { returnTo?: string } => ({
    returnTo:
      typeof search.returnTo === "string" && search.returnTo.startsWith("/")
        ? search.returnTo
        : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Anmelden — DEUSI" },
      {
        name: "description",
        content: "Melde dich bei DEUSI an und setze dein Deutschlernen fort.",
      },
      { property: "og:title", content: "Anmelden — DEUSI" },
      {
        property: "og:description",
        content: "Melde dich bei DEUSI an und setze dein Deutschlernen fort.",
      },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { login } = useDeusi();
  const { returnTo } = Route.useSearch();
  const router = useRouter();
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    const r = await login(id, pw);
    setLoading(false);
    if (!r.ok) return setErr(r.error ?? "Anmeldung fehlgeschlagen");
    router.navigate({ to: returnTo ?? "/dashboard", replace: true });
  };

  return (
    <AuthShell
      side="login"
      title="Anmelden"
      subtitle="Weiter, wo du aufgehört hast — deine Karten warten schon."
      footer={
        <>
          Noch kein Konto?{" "}
          <Link
            to="/register"
            className="font-semibold text-foreground hover:underline"
            style={{ color: "var(--flag-red)" }}
          >
            Jetzt kostenlos registrieren
          </Link>
        </>
      }
    >
      <form onSubmit={submit} className="space-y-4">
        <AuthField label="Benutzername oder E-Mail">
          <div className="group relative">
            <AtSign className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
            <input
              value={id}
              onChange={(e) => setId(e.target.value)}
              autoComplete="username"
              required
              placeholder="max.mustermann"
              className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-3 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
            />
          </div>
        </AuthField>

        <AuthField
          label="Passwort"
          hint={
            <Link
              to="/passwort-vergessen"
              className="text-xs font-semibold text-muted-foreground hover:text-[var(--flag-red)]"
            >
              Passwort vergessen?
            </Link>
          }
        >
          <div className="group relative">
            <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-[var(--flag-red)]" />
            <input
              type={show ? "text" : "password"}
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              autoComplete="current-password"
              required
              placeholder="••••••••"
              className="w-full rounded-2xl border border-border bg-card/80 py-3 pl-10 pr-11 text-sm text-foreground shadow-sm outline-none transition focus:border-[var(--flag-red)] focus:ring-4 focus:ring-[color-mix(in_oklab,var(--flag-red)_18%,transparent)]"
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              aria-label={show ? "Passwort verbergen" : "Passwort anzeigen"}
              className="absolute right-2 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground"
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </AuthField>

        <label className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
          <input
            type="checkbox"
            checked={remember}
            onChange={(e) => setRemember(e.target.checked)}
            className="h-4 w-4 rounded border-border accent-[var(--flag-red)]"
          />
          Angemeldet bleiben
        </label>

        <AnimatePresence>
          {err && (
            <motion.div
              initial={{ opacity: 0, y: -6, height: 0 }}
              animate={{ opacity: 1, y: 0, height: "auto" }}
              exit={{ opacity: 0, y: -6, height: 0 }}
              className="flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-sm text-destructive"
            >
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{err}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          type="submit"
          disabled={loading}
          whileHover={{ y: -1 }}
          whileTap={{ scale: 0.98 }}
          className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl px-4 py-3 text-sm font-bold text-white shadow-lg transition disabled:opacity-60"
          style={{
            background: "linear-gradient(135deg, #1a1a1a 0%, #DD2222 60%, #F7C948 130%)",
            boxShadow: "0 20px 40px -18px rgba(221,34,34,0.65)",
          }}
        >
          <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
          <span className="relative">{loading ? "Anmelden…" : "Anmelden"}</span>
        </motion.button>

        <div className="flex items-center gap-3 pt-1">
          <div className="h-px flex-1 bg-border" />
          <span className="text-xs uppercase tracking-widest text-muted-foreground">oder</span>
          <div className="h-px flex-1 bg-border" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            className="flex items-center justify-center gap-2 rounded-2xl border border-border bg-card/70 py-2.5 text-sm font-semibold text-foreground transition hover:bg-secondary"
          >
            <GoogleIcon /> Google
          </button>
          <button
            type="button"
            className="flex items-center justify-center gap-2 rounded-2xl border border-border bg-card/70 py-2.5 text-sm font-semibold text-foreground transition hover:bg-secondary"
          >
            <AppleIcon /> Apple
          </button>
        </div>
      </form>
    </AuthShell>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
      <path
        fill="#EA4335"
        d="M12 10.2v3.9h5.5c-.24 1.4-1.7 4.1-5.5 4.1-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.2.8 3.9 1.5l2.7-2.6C16.9 3.3 14.7 2.4 12 2.4 6.9 2.4 2.8 6.5 2.8 11.6S6.9 20.8 12 20.8c6.9 0 9.1-4.8 9.1-7.2 0-.5 0-.9-.1-1.4H12z"
      />
    </svg>
  );
}
function AppleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden>
      <path d="M16.5 12.6c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.5-.2-2.9.9-3.6.9-.7 0-1.9-.8-3.1-.8-1.6 0-3.1.9-4 2.4-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.8 2.5 3.1 2.5 1.2 0 1.7-.8 3.2-.8s1.9.8 3.1.8c1.3 0 2.1-1.2 2.9-2.4.9-1.4 1.3-2.8 1.3-2.8-.1 0-2.7-1-2.7-4.3zM14 5.2c.6-.8 1.1-1.8.9-2.9-.9.1-2 .6-2.7 1.4-.5.6-1.1 1.7-.9 2.8 1 .1 2.1-.5 2.7-1.3z" />
    </svg>
  );
}
