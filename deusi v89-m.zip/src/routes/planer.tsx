import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { EmptyState } from "@/components/deusi/EmptyState";
import { Fa } from "@/components/deusi/Fa";
import { SectionHero } from "@/components/deusi/SectionHero";
import { DayView } from "@/components/deusi/planner/DayView";
import { PlannerSetup } from "@/components/deusi/planner/PlannerSetup";
import { LearnerProfilePrompt } from "@/components/deusi/onboarding/LearnerProfilePrompt";
import { SessionCard } from "@/components/deusi/planner/SessionCard";
import { WeekView } from "@/components/deusi/planner/WeekView";
import { SessionHistory } from "@/components/deusi/planner/SessionHistory";
import { Segmented, SkillBalance, StatTile } from "@/components/deusi/planner/parts";

import { GOAL_LABEL, LEVEL_LABEL } from "@/lib/deusi/planner/config";
import {
  addDays,
  formatMinutes,
  formatWeekRange,
  todayISO,
  weekStartOf,
} from "@/lib/deusi/planner/date";
import { usePlanner } from "@/lib/deusi/planner/usePlanner";
import type { PlannerSession } from "@/lib/deusi/planner/types";

const TITLE = "Smart Planner — DEUSI";
const DESCRIPTION =
  "Dein persönlicher Wochenplan für Deutsch: DEUSI verteilt Wortschatz, Grammatik, Hören, Sprechen, Lesen und Schreiben auf deine echte Lernzeit.";

export const Route = createFileRoute("/planer")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
    ],
  }),
  component: PlannerPage,
});

function PlannerPage() {
  const planner = usePlanner();
  const { status, busy, error, prefs, week, weekStart, sessions, stats, today, todaySessions } =
    planner;

  const [view, setView] = useState<"week" | "day">("week");
  const [activeDay, setActiveDay] = useState(today);
  const navigate = useNavigate();

  const openSession = (session: PlannerSession) =>
    void navigate({ to: "/planer/session/$sessionId", params: { sessionId: session.id } });
  const openAdd = (date: string) => void navigate({ to: "/planer/neu", search: { date } });

  const isCurrentWeek = weekStart === weekStartOf(today);
  const goalText = useMemo(
    () => (prefs?.goals ?? []).map((g) => GOAL_LABEL[g].de).join(" · "),
    [prefs],
  );

  /** Der „Heute“-Zähler zeigt bewusst nur den heutigen Tag, nicht die Woche. */
  const todayDone = useMemo(
    () => todaySessions.filter((s) => s.status === "done").length,
    [todaySessions],
  );

  const openDay = (date: string) => {
    setActiveDay(date);
    setView("day");
  };

  /* ------------------------------------------------------------- Zustände */

  if (status === "loading") {
    return (
      <div className="flex flex-col gap-5">
        <SectionHero sectionKey="planner" />
        <div className="neu-card h-40 animate-pulse" />
        <div className="neu-card h-64 animate-pulse" />
      </div>
    );
  }

  if (status === "anonymous") {
    return (
      <div className="flex flex-col gap-5">
        <SectionHero sectionKey="planner" />
        <EmptyState
          title="Melde dich an, um deinen Plan zu erstellen"
          description="Der Smart Planner speichert deinen Wochenplan in deinem DEUSI-Konto — damit er auf jedem Gerät gleich aussieht."
          action={
            <Link
              to="/login"
              className="rounded-full bg-[color:var(--section-primary)] px-5 py-2 text-sm font-bold text-white"
            >
              Anmelden
            </Link>
          }
        />
      </div>
    );
  }

  if (status === "onboarding") {
    return (
      <div className="flex flex-col gap-5">
        <SectionHero
          sectionKey="planner"
          titleDe="In 1 Minute zum Wochenplan"
          titleFa="در یک دقیقه به برنامه‌ی هفتگی"
          highlight="Wochenplan"
          descDe="Sag DEUSI, wo du stehst und wie viel Zeit du hast. Den Rest planen wir."
          descFa="بگو کجا ایستاده‌ای و چقدر وقت داری، بقیه‌اش با DEUSI."
        />
        <LearnerProfilePrompt />
        <div className="neu-card p-5 sm:p-7">
          <PlannerSetup prefs={prefs} busy={busy} onSubmit={planner.savePrefs} />
        </div>
      </div>
    );
  }

  /* ---------------------------------------------------------------- Ready */

  return (
    <div className="flex flex-col gap-5">
      <SectionHero
        sectionKey="planner"
        right={
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => planner.regenerate("keep-edits")}
              disabled={busy}
              className="rounded-full bg-white/15 px-4 py-2 text-sm font-bold text-white ring-1 ring-inset ring-white/25 backdrop-blur transition-colors hover:bg-white/25 disabled:opacity-60"
            >
              {busy ? "Wird geplant …" : "Woche neu planen"}
            </button>
            <Link
              to="/planer/anpassen"
              className="rounded-full px-4 py-2 text-sm font-bold text-white/90 ring-1 ring-inset ring-white/25 transition-colors hover:bg-white/15"
            >
              Plan anpassen
            </Link>
          </div>
        }
      >
        <p className="text-sm text-white/85">
          {LEVEL_LABEL[prefs!.level]} · {goalText} · {formatMinutes(prefs!.dailyMinutes)} pro
          Lerntag
        </p>
      </SectionHero>

      {error ? (
        <p role="alert" className="neu-card p-4 text-sm text-destructive">
          {error}
        </p>
      ) : null}

      <div className="flex flex-col gap-5">
        {/* --------------------------------------------------- Kalender */}
        <section aria-label="Wochenplan" className="neu-card w-full min-w-0 p-4 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
            <div className="flex min-w-0 items-center justify-between gap-2 sm:justify-start">
              <button
                type="button"
                onClick={() => planner.goToWeek(addDays(weekStart, -7))}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-border text-sm font-bold hover:bg-muted sm:h-9 sm:w-9"
                aria-label="Vorherige Woche"
              >
                ‹
              </button>
              <div className="min-w-0 text-center">
                <div className="truncate text-sm font-black tracking-tight">
                  {formatWeekRange(weekStart)}
                </div>
                {isCurrentWeek ? (
                  <div className="text-[11px] font-semibold text-[color:var(--section-primary)]">
                    Diese Woche · این هفته
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => planner.goToWeek(todayISO())}
                    className="text-[11px] font-semibold text-muted-foreground underline"
                  >
                    Zur aktuellen Woche
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => planner.goToWeek(addDays(weekStart, 7))}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-border text-sm font-bold hover:bg-muted sm:h-9 sm:w-9"
                aria-label="Nächste Woche"
              >
                ›
              </button>
            </div>

            <div className="w-full sm:w-auto">
              <Segmented
                fullWidth
                ariaLabel="Ansicht"
                value={view}
                onChange={setView}
                options={[
                  { value: "week", label: "Woche" },
                  { value: "day", label: "Tag" },
                ]}
              />
            </div>
          </div>

          <div className="mt-4">
            {!sessions.length ? (
              <EmptyState
                compact
                title="Für diese Woche ist noch nichts geplant"
                description="Erzeuge einen Plan aus deinem Profil — oder füge einzelne Sessions selbst hinzu."
                action={
                  <button
                    type="button"
                    onClick={() => planner.regenerate("fresh")}
                    disabled={busy}
                    className="rounded-full bg-[color:var(--section-primary)] px-5 py-2 text-sm font-bold text-white disabled:opacity-60"
                  >
                    Woche planen
                  </button>
                }
              />
            ) : view === "week" ? (
              <WeekView
                weekStart={weekStart}
                sessions={sessions}
                today={today}
                onOpenDay={openDay}
                onOpenSession={openSession}
                onAddAt={openAdd}
              />
            ) : (
              <DayView
                date={activeDay}
                sessions={sessions}
                onStatus={planner.setSessionStatus}
                onEdit={openSession}
                onRemove={planner.removeSession}
                onAdd={openAdd}
                dueVocabCount={planner.dueVocabCount}
              />
            )}
          </div>
        </section>

        {/* ------------------------------- Heute + Kennzahlen nebeneinander */}
        <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
          <section aria-label="Heute" className="neu-card min-w-0 p-4 sm:p-5">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3">
              <div className="min-w-0">
                <h2 className="text-base font-black tracking-tight">Heute</h2>
                <Fa>برنامه‌ی امروز</Fa>
              </div>
              <span className="shrink-0 rounded-full bg-[color:var(--section-primary)]/12 px-2.5 py-1 text-[11px] font-bold tabular-nums text-[color:var(--section-primary)]">
                {todayDone}/{todaySessions.length}
              </span>
            </div>

            <div className="mt-3 flex flex-col gap-3">
              {todaySessions.length ? (
                todaySessions.map((s) => (
                  <SessionCard
                    key={s.id}
                    session={s}
                    onToggleDone={() =>
                      planner.setSessionStatus(s.id, s.status === "done" ? "planned" : "done")
                    }
                    onSkip={() =>
                      planner.setSessionStatus(s.id, s.status === "skipped" ? "planned" : "skipped")
                    }
                    onEdit={() => openSession(s)}
                  />
                ))
              ) : (
                <button
                  type="button"
                  onClick={() => openAdd(today)}
                  className="w-full rounded-2xl border border-dashed border-border px-4 py-6 text-sm font-semibold text-muted-foreground transition-colors hover:border-[color:var(--section-primary)] hover:text-foreground"
                >
                  + Session für heute
                </button>
              )}
            </div>
          </section>

          <aside aria-label="Wochenüberblick" className="flex min-w-0 flex-col gap-4">
            <div className="grid grid-cols-2 gap-3">
              <StatTile
                compact
                label="Geplant"
                labelFa="برنامه‌ریزی‌شده"
                value={formatMinutes(stats.plannedMinutes)}
              />
              <StatTile
                compact
                label="Erledigt"
                labelFa="انجام‌شده"
                value={formatMinutes(stats.doneMinutes)}
              />
              <StatTile compact label="Fortschritt" labelFa="پیشرفت" value={`${stats.progress}%`} />
              <StatTile
                compact
                label="Wochenziel"
                labelFa="هدف هفته"
                value={formatMinutes(week?.targetMinutes ?? stats.plannedMinutes)}
              />
            </div>

            <SkillBalance distribution={stats.distribution} progress={stats.progress} />

            <SessionHistory logs={planner.logs} summary={planner.logSummary} />
          </aside>
        </div>
      </div>
    </div>
  );
}
