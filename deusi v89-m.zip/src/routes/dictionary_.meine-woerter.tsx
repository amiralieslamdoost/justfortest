import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { SectionHero } from "@/components/deusi/SectionHero";
import { MyWordsWorkspace } from "@/components/deusi/dictionary/MyWordsWorkspace";
import { WordDetailPanel } from "@/components/deusi/dictionary/WordDetailPanel";
import { ALL_WORDS, findById } from "@/lib/deusi/dictionary/mockWords";
import type { DictWord } from "@/lib/deusi/dictionary/types";
import { useCustomWords } from "@/lib/deusi/dictionary/customWords";
import { useLeitnerQueue } from "@/lib/deusi/dictionary/leitnerQueue";
import { useInteractions } from "@/lib/deusi/interactions";
import { useDeusi } from "@/lib/deusi/store";

export const Route = createFileRoute("/dictionary_/meine-woerter")({
  head: () => ({
    meta: [
      { title: "Meine Wörter — DEUSI Wörterbuch" },
      {
        name: "description",
        content:
          "Deine persönliche Wortsammlung: eigene Einträge, Lesezeichen und Favoriten an einem Ort.",
      },
      { property: "og:title", content: "Meine Wörter — DEUSI" },
      {
        property: "og:description",
        content: "Eigene Wörter, Lesezeichen und Favoriten in deiner persönlichen Sammlung.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MyWordsPage,
});

function MyWordsPage() {
  const router = useRouter();
  const { currentUser, hydrated } = useDeusi();
  const { words: customWords } = useCustomWords();
  const leitner = useLeitnerQueue();
  const { isBookmarked, toggleBookmark, isFavorited, toggleFavorite } = useInteractions();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  const resolveWord = (id: string): DictWord | undefined =>
    findById(id) ?? customWords.find((w) => w.id === id);
  const selectedWord = selectedId ? (resolveWord(selectedId) ?? null) : null;

  const meta = (id: string) => {
    const w = resolveWord(id);
    return {
      title: w?.headword ?? id,
      sub: [w?.pos, w?.meanings?.[0]?.fa ?? w?.meanings?.[0]?.de].filter(Boolean).join(" · "),
      level: w?.cefr,
      to: "/dictionary/meine-woerter",
    };
  };

  if (!currentUser) return null;

  return (
    <div className="space-y-6 pb-16 animate-fade">
      <Link
        to="/dictionary"
        className="inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-card px-3 py-1.5 text-xs font-semibold text-muted-foreground transition hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Zurück zum Wörterbuch
      </Link>

      <SectionHero
        sectionKey="dictionary"
        titleDe="Meine Wörter"
        titleFa="واژه‌های من"
        highlight="Wörter"
        descDe="Deine eigene Sammlung: selbst angelegte Wörter, Lesezeichen und Favoriten."
        descFa=""
      />

      <MyWordsWorkspace
        masterWords={ALL_WORDS}
        onOpen={(id) => setSelectedId(id)}
        onToggleBookmark={(id) => toggleBookmark("word", id, meta(id))}
        bookmarks={(id) => isBookmarked("word", id)}
        inLeitner={(id) => leitner.has(id)}
        onToggleLeitner={(id, label) => leitner.toggle(id, label ?? resolveWord(id)?.headword)}
      />

      <AnimatePresence>
        {selectedWord && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-black/45 backdrop-blur-[2px]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedId(null)}
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 460, damping: 42, mass: 0.7 }}
              className="fixed inset-y-0 right-0 z-50 flex w-full max-w-[520px] flex-col overflow-hidden bg-card shadow-2xl ring-1 ring-border/70"
            >
              <WordDetailPanel
                word={selectedWord}
                favorite={isFavorited("word", selectedWord.id)}
                inLeitner={leitner.has(selectedWord.id)}
                bookmarked={isBookmarked("word", selectedWord.id)}
                onClose={() => setSelectedId(null)}
                onToggleFavorite={() =>
                  toggleFavorite("word", selectedWord.id, meta(selectedWord.id))
                }
                onToggleLeitner={() => leitner.toggle(selectedWord.id, selectedWord.headword)}
                onToggleBookmark={() =>
                  toggleBookmark("word", selectedWord.id, meta(selectedWord.id))
                }
                onOpenWord={(id) => setSelectedId(id)}
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
