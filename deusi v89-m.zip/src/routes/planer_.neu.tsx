import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { PlannerSubPage } from "@/components/deusi/planner/PlannerSubPage";
import { SessionAddForm } from "@/components/deusi/planner/SessionForms";
import { formatDayLong, todayISO } from "@/lib/deusi/planner/date";
import { usePlanner } from "@/lib/deusi/planner/usePlanner";

const TITLE = "Session hinzufügen — DEUSI Smart Planner";
const DESCRIPTION =
  "Wähle eine Aktivität aus dem DEUSI-Katalog oder lege eine komplett eigene Lerneinheit in deinen Wochenplan.";

export const Route = createFileRoute("/planer_/neu")({
  validateSearch: (search: Record<string, unknown>) => ({
    date: typeof search["date"] === "string" ? (search["date"] as string) : todayISO(),
  }),
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NewSessionPage,
});

function NewSessionPage() {
  const { date } = Route.useSearch();
  const planner = usePlanner();
  const navigate = useNavigate();
  const back = () => void navigate({ to: "/planer" });

  return (
    <PlannerSubPage
      title="Session hinzufügen"
      titleFa="افزودن جلسه"
      intro={formatDayLong(date)}
      introFa="یا از فعالیت‌های آمادهٔ DEUSI انتخاب کن، یا فعالیت مطالعهٔ دلخواه خودت را با عنوان و توضیح دلخواه بساز."
    >
      <SessionAddForm
        date={date}
        defaultStart={planner.prefs?.startHour ?? "19:00"}
        onCancel={back}
        onAdd={(input) => {
          void planner.addSession(input).then(back);
        }}
        onAddCustom={(input) => {
          void planner.addCustomSession(input).then(back);
        }}
      />
    </PlannerSubPage>
  );
}
