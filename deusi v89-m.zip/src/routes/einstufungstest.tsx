import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { PlacementTest } from "@/components/deusi/profile/PlacementTest";

export const Route = createFileRoute("/einstufungstest")({
  head: () => ({
    meta: [
      { title: "Einstufungstest · DEUSI" },
      {
        name: "description",
        content: "Finde in 10 kurzen Fragen dein Deutsch-Niveau von A1 bis C1.",
      },
      { property: "og:title", content: "Einstufungstest · DEUSI" },
      {
        property: "og:description",
        content: "Finde in 10 kurzen Fragen dein Deutsch-Niveau von A1 bis C1.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PlacementTestPage,
});

function PlacementTestPage() {
  return (
    <div className="space-y-6 pb-10 animate-fade">
      <h1 className="sr-only">Einstufungstest — dein Deutschniveau bestimmen</h1>
      <Link
        to="/profil"
        className="inline-flex items-center gap-2 rounded-xl border border-border/60 bg-card px-4 py-2 text-sm font-semibold transition hover:bg-secondary"
      >
        <ArrowLeft className="h-4 w-4" /> Zurück zum Profil
      </Link>
      <PlacementTest />
    </div>
  );
}
