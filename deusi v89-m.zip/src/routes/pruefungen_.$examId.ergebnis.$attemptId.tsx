import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Award, RefreshCw, Sparkles } from "lucide-react";
import { getExam } from "@/lib/deusi/exams/mockExams";
import { QuestionCard } from "@/components/deusi/exams/QuestionCard";
import {
  useApplyExamLevel,
  useAttempt,
  useExamSections,
  useManualRating,
} from "@/lib/api/useExams";
import { percentOf, verdictOf, type Cefr } from "@/lib/deusi/examScoring";

export const Route = createFileRoute("/pruefungen_/$examId/ergebnis/$attemptId")({
  loader: ({ params }) => {
    const exam = getExam(params.examId);
    if (!exam) throw notFound();
    return { exam };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Ergebnis nicht verfügbar | DEUSI" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.exam.shortName} Modelltest – dein Ergebnis | DEUSI`;
    const description = `Detaillierte Auswertung deines ${loaderData.exam.name} Modelltests: Punkte, Fertigkeiten und Niveau-Empfehlung.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "robots", content: "noindex" },
      ],
    };
  },
  component: ExamResultPage,
  notFoundComponent: () => (
    <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
      <h1 className="text-xl font-bold">Ergebnis nicht gefunden</h1>
      <Link to="/pruefungen" className="mt-6 inline-block text-sm underline">
        Zurück zur Übersicht
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
      <h1 className="text-xl font-bold">Ein Fehler ist aufgetreten</h1>
      <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
    </div>
  ),
});

const SKILL_FA: Record<string, string> = {
  Lesen: "خواندن",
  Hoeren: "شنیدن",
  Schreiben: "نوشتن",
  Sprechen: "صحبت کردن",
  Modelltest: "آزمون کامل",
};

function ExamResultPage() {
  const { exam } = Route.useLoaderData();
  const { attemptId } = Route.useParams();
  const { attempt, answers, isLoading } = useAttempt(attemptId);
  const { sections } = useExamSections(exam.id);
  const section = useMemo(
    () => sections.find((s) => s.id === attempt?.sectionId) ?? null,
    [sections, attempt],
  );
  const rate = useManualRating(section);
  const applyLevel = useApplyExamLevel();
  const [levelApplied, setLevelApplied] = useState(false);

  if (isLoading) {
    return <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">…</div>;
  }

  if (!attempt || !section) {
    return (
      <div className="glass mx-auto mt-24 max-w-lg rounded-3xl p-10 text-center">
        <h1 className="text-xl font-bold">Ergebnis nicht gefunden</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Dieser Versuch existiert auf diesem Gerät nicht mehr.
        </p>
        <Link
          to="/pruefungen/$examId"
          params={{ examId: exam.id }}
          className="mt-6 inline-block text-sm underline"
        >
          Zurück zur Prüfung
        </Link>
      </div>
    );
  }

  const percent = percentOf(attempt.score, attempt.maxScore);
  const verdict = verdictOf(percent);
  const manualQuestions = section.questions.filter((q) => q.kind === "free");

  return (
    <div className="mx-auto max-w-3xl space-y-5 pb-20">
      <Link to="/pruefungen/$examId" params={{ examId: exam.id }} className="btn-back">
        <span aria-hidden>←</span> Zurück zur Prüfung
      </Link>

      <section className="glass-strong rounded-3xl p-6 text-center">
        <div className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
          {exam.shortName} · {section.title}
        </div>
        <div className="mt-3 text-5xl font-black tabular-nums">{percent}%</div>
        <p className="mt-1 text-sm text-muted-foreground">
          {attempt.score} von {attempt.maxScore} Punkten ·{" "}
          <strong
            className={
              verdict.tone === "good"
                ? "text-emerald-600"
                : verdict.tone === "ok"
                  ? "text-amber-600"
                  : "text-rose-500"
            }
          >
            {verdict.label}
          </strong>
        </p>

        {attempt.resultLevel ? (
          <div className="mt-5 inline-flex flex-wrap items-center justify-center gap-3 rounded-2xl border border-border/60 bg-card/50 p-4">
            <span className="inline-flex items-center gap-2 text-sm">
              <Award className="h-4 w-4 text-[color:var(--section-primary)]" aria-hidden />
              Empfohlenes Niveau: <strong>{attempt.resultLevel}</strong>
            </span>
            <button
              type="button"
              disabled={applyLevel.isPending || levelApplied}
              onClick={() =>
                applyLevel.mutate(attempt.resultLevel as Cefr, {
                  onSuccess: () => setLevelApplied(true),
                })
              }
              className="inline-flex items-center gap-1.5 rounded-full bg-[color:var(--section-primary)] px-4 py-2 text-xs font-semibold text-white transition hover:opacity-90 disabled:opacity-60"
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden />
              {levelApplied ? "Niveau übernommen" : "Mein Niveau aktualisieren"}
            </button>
          </div>
        ) : null}

        <div className="mt-5 flex flex-wrap justify-center gap-2">
          <Link
            to="/pruefungen/$examId/test"
            params={{ examId: exam.id }}
            search={{ section: section.id }}
            className="inline-flex items-center gap-1.5 rounded-full border border-border/70 px-4 py-2 text-xs font-semibold transition hover:border-[color:var(--section-primary)]/60"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden /> Erneut versuchen
          </Link>
        </div>
      </section>

      {Object.keys(attempt.sectionScores).length > 1 ? (
        <section className="glass rounded-3xl p-5">
          <h2 className="text-sm font-bold">Fertigkeiten im Überblick</h2>
          <div className="mt-3 space-y-2.5">
            {Object.entries(attempt.sectionScores).map(([skill, value]) => (
              <div key={skill}>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold">
                    {skill} <span className="text-muted-foreground">{SKILL_FA[skill] ?? ""}</span>
                  </span>
                  <span className="tabular-nums text-muted-foreground">{value}%</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-secondary/70">
                  <div
                    className="h-full rounded-full bg-[color:var(--section-primary)]"
                    style={{ width: `${value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {manualQuestions.length ? (
        <section className="glass rounded-3xl p-5">
          <h2 className="text-sm font-bold">Selbsteinschätzung (freie Texte)</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Vergleiche deinen Text mit der Musterlösung und vergib Punkte – dein Ergebnis wird
            sofort neu berechnet.
          </p>
          <div className="mt-3 space-y-3">
            {manualQuestions.map((q) => {
              const given = answers[q.id]?.points ?? 0;
              return (
                <div key={q.id} className="rounded-2xl border border-border/60 bg-card/50 p-3">
                  <div className="text-sm font-semibold leading-snug">{q.prompt}</div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {Array.from({ length: q.points + 1 }, (_, i) => i).map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() =>
                          rate.mutate({ attemptId: attempt.id, questionId: q.id, points: p })
                        }
                        className={`h-8 min-w-8 rounded-lg px-2 text-xs font-bold transition ${
                          given === p
                            ? "bg-[color:var(--section-primary)] text-white"
                            : "bg-secondary/70 text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                    <span className="self-center text-xs text-muted-foreground">
                      von {q.points} Punkten
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      ) : null}

      <section className="space-y-4">
        <h2 className="text-sm font-bold">Alle Fragen im Detail</h2>
        {section.questions.map((q, i) => (
          <QuestionCard
            key={q.id}
            question={q}
            index={i}
            total={section.questions.length}
            value={answers[q.id]?.value}
            review
            earnedPoints={answers[q.id]?.points ?? 0}
          />
        ))}
      </section>
    </div>
  );
}
