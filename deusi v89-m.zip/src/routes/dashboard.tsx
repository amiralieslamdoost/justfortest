import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo } from "react";
import { useDeusi } from "@/lib/deusi/store";
import type { DeusiEvent } from "@/lib/deusi/events/mockEvents";
import { useQuery } from "@tanstack/react-query";
import { loadEvents } from "@/lib/api/events";
import { queryKeys } from "@/lib/api/queryKeys";
import { SectionHero } from "@/components/deusi/SectionHero";
import { useGamification } from "@/lib/api/useGamification";
import { useStudyStats } from "@/lib/api/useStats";
import { useSettings } from "@/lib/api/useSettings";
import { HeroChip, BlockHeader } from "@/components/deusi/dashboard/Shared";
import { ContinueLearningCard } from "@/components/deusi/dashboard/ContinueLearningCard";
import { DailyGoalRingCard } from "@/components/deusi/dashboard/DailyGoalRingCard";
import { MiniStatTile } from "@/components/deusi/dashboard/MiniStatTile";
import { LearningActivityCard } from "@/components/deusi/dashboard/LearningActivityCard";
import { FeatureAchievementCard } from "@/components/deusi/dashboard/FeatureAchievementCard";
import { SectionBento } from "@/components/deusi/dashboard/SectionBento";
import { ActionCallCard } from "@/components/deusi/dashboard/ActionCallCard";
import { NextEventCard } from "@/components/deusi/dashboard/NextEventCard";
import { SpotlightCard } from "@/components/deusi/dashboard/SpotlightCard";
import { AchievementsCard } from "@/components/deusi/dashboard/AchievementsCard";
import { LevelProgressCard } from "@/components/deusi/dashboard/LevelProgressCard";
import { DailyTipCard } from "@/components/deusi/dashboard/DailyTipCard";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — DEUSI" },
      {
        name: "description",
        content:
          "Dein DEUSI Lern-Dashboard mit Tagesziel, Streak, XP und persönlichem Fortschritt.",
      },
      { property: "og:title", content: "Dashboard — DEUSI" },
      {
        property: "og:description",
        content: "Behalte Tagesziel, Streak, XP und Lernfortschritt in DEUSI im Blick.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

/* ---------- Utilities ---------- */

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return { de: "Gute Nacht", fa: "شب بخیر" };
  if (h < 12) return { de: "Guten Morgen", fa: "صبح بخیر" };
  if (h < 18) return { de: "Guten Tag", fa: "روز بخیر" };
  return { de: "Guten Abend", fa: "عصر بخیر" };
}

/* ============================================================
 * Dashboard
 * ========================================================== */

function Dashboard() {
  const { currentUser, hydrated, dueCards, ensureDeckFor } = useDeusi();
  const router = useRouter();

  useEffect(() => {
    if (!hydrated) return;
    if (!currentUser) router.navigate({ to: "/login" });
    else ensureDeckFor(currentUser.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, currentUser?.id]);

  const hello = useMemo(greeting, []);
  const today = useMemo(
    () =>
      new Date().toLocaleDateString("de-DE", {
        weekday: "long",
        day: "numeric",
        month: "long",
      }),
    [],
  );
  /* سشن ۹: رویداد بعدی از بک‌اند (در MOCK_MODE همان دیتای محلی). */
  const { data: eventList } = useQuery({
    queryKey: queryKeys.community.events(),
    queryFn: loadEvents,
    staleTime: 300_000,
  });
  const nextEvent = useMemo(() => {
    const list = eventList ?? [];
    const now = Date.now();
    const upcoming = list.filter((e) => {
      const t = Date.parse(e.dateShort);
      return Number.isNaN(t) ? true : t >= now;
    });
    return (upcoming[0] ?? list[0]) as DeusiEvent | undefined;
  }, [eventList]);
  /* سشن ۹: XP، سطح و استریک از بک‌اند. */
  const { summary } = useGamification();
  const { settings } = useSettings();
  const { totals } = useStudyStats(90);
  const dailyGoal = settings.daily_goal_minutes || 45;

  if (!currentUser) return null;

  const learned = currentUser.deck.filter((c) => c.box >= 3).length;
  const due = dueCards().length;
  const streak = summary?.streak.current ?? Math.max(currentUser.streak, 14);
  const goal = 20;
  const doneToday = Math.min(goal, 8);
  const goalPct = Math.round((doneToday / goal) * 100);
  const xp = summary?.todayXp ?? 125;
  const xpGoal = Math.max(dailyGoal * 10, 100);
  const wordsLearned = Math.max(learned + 200, 356);
  const wordsGoal = 1500;
  const levelPct = summary?.levelPct ?? 55;

  const firstName = currentUser.username.split(" ")[0];

  return (
    <div className="animate-fade space-y-6 pb-10">
      {/* ============================ HERO ============================ */}
      <SectionHero
        sectionKey="dashboard"
        titleDe={`${hello.de}, ${firstName}`}
        titleFa={`${hello.fa} · ${today}`}
        highlight={firstName}
        descDe="Dein Lernüberblick — alle wichtigen Module und Fortschritte an einem Ort."
        descFa="نمای کلی یادگیری‌ات — همه‌ی ماژول‌ها و پیشرفت‌ها در یک صفحه."
        right={
          <div className="hidden items-center gap-2 md:flex">
            <HeroChip label="Streak" value={`${streak} Tage`} />
            <HeroChip label="XP heute" value={`+${xp}`} />
            <HeroChip label="Level" value={`Level ${summary?.level ?? 1}`} />
          </div>
        }
      />

      {/* ============ ROW 1 — CONTINUE LEARNING + DAILY GOAL ============ */}
      <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
        {/* Continue Learning — Hero card */}
        <ContinueLearningCard due={due} className="col-span-12 lg:col-span-8" />

        {/* Right column: Daily Goal ring + Streak + XP mini tiles */}
        <div className="col-span-12 grid grid-cols-2 gap-4 md:gap-5 lg:col-span-4">
          <DailyGoalRingCard done={doneToday} goal={goal} pct={goalPct} className="col-span-2" />
          <MiniStatTile
            emoji="⚡"
            value={`+${xp}`}
            label="XP heute"
            labelFa="امتیاز امروز"
            gradient="var(--stat-xp-gradient)"
            glow="var(--stat-xp-glow)"
            dot="var(--stat-xp-dot)"
          />
          <MiniStatTile
            emoji="🔥"
            value={streak}
            label="Streak"
            labelFa="روز پیاپی"
            gradient="var(--stat-streak-gradient)"
            glow="var(--stat-streak-glow)"
            dot="var(--stat-streak-dot)"
          />
        </div>
      </div>

      {/* ============ ROW 2 — LERNAKTIVITÄT + ACHIEVEMENT ============ */}
      <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
        <LearningActivityCard className="col-span-12 lg:col-span-9" />
        <FeatureAchievementCard className="col-span-12 lg:col-span-3" />
      </div>

      {/* ============ THEMENBEREICHE (Section shortcuts bento) ============ */}
      <section className="dash-rise">
        <BlockHeader
          title="Themenbereiche"
          fa="بخش‌های آموزشی"
          subtitle="Alle Lernmodule auf einen Blick"
        />
        <SectionBento />
      </section>

      {/* ============ HEUTE ZU TUN — Due / AI Coach / Next Event ============ */}
      <section className="dash-rise">
        <BlockHeader
          title="Heute dran"
          fa="کارهای امروز"
          subtitle="Wiederholungen, Empfehlungen und dein nächstes Event"
        />
        <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
          <ActionCallCard
            className="col-span-12 md:col-span-6 lg:col-span-4"
            sectionKey="leitner"
            eyebrow="Fällig heute"
            eyebrowFa="امروز باید مرور شود"
            title={`${Math.max(due, 12)} Karten warten`}
            subtitle="Kurze Runde reicht — halte deine Serie."
            subtitleFa="یک نوبت کوتاه کافی است."
            cta={{ to: "/leitner", label: "Jetzt üben" }}
            emoji="📚"
            chips={["Box 2 · 7", "Box 3 · 5", "≈ 6 Min."]}
            progress={{ label: "Heute wiederholt", pct: 35 }}
          />
          <ActionCallCard
            className="col-span-12 md:col-span-6 lg:col-span-4"
            sectionKey="ai-coach"
            eyebrow="KI Coach · Empfehlung"
            eyebrowFa="پیشنهاد مربی"
            title="Präpositionen üben"
            subtitle="Dein schwächster Bereich diese Woche."
            subtitleFa="ضعیف‌ترین حوزه‌ی این هفته."
            cta={{ to: "/grammatik", label: "Los geht’s" }}
            emoji="🎯"
            chips={["Dativ", "Akkusativ", "≈ 10 Min."]}
            progress={{ label: "Beherrschung", pct: 58 }}
          />

          {nextEvent && <NextEventCard event={nextEvent} className="col-span-12 lg:col-span-4" />}
        </div>
      </section>
      {/* ============ ROW 5 — ACTIVITY FEED + ACHIEVEMENTS ============ */}
      <section>
        <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
          <SpotlightCard className="col-span-12 h-full lg:col-span-7" />
          <AchievementsCard className="col-span-12 lg:col-span-5" />
        </div>
      </section>

      {/* ============ LEVEL PROGRESS + TIPP DES TAGES ============ */}
      <section>
        <div className="dash-stagger grid grid-cols-12 gap-4 md:gap-5">
          <LevelProgressCard
            className="col-span-12 lg:col-span-7"
            levelPct={levelPct}
            wordsLearned={wordsLearned}
            wordsGoal={wordsGoal}
            xp={xp}
            xpGoal={xpGoal}
            totalHours={Math.round(totals.totalMinutes / 60)}
            activeDays={0}
          />
          <DailyTipCard className="col-span-12 lg:col-span-5" />
        </div>
      </section>
    </div>
  );
}
