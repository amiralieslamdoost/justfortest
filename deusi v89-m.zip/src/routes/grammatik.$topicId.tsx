import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/grammatik/$topicId")({
  head: ({ params }) => ({
    meta: [
      { title: `Grammatik: ${params.topicId} · DEUSI` },
      {
        name: "description",
        content: "Deutsch-Grammatik mit Lektionen, Übungen und verständlichen Erklärungen.",
      },
      { property: "og:title", content: `Grammatik: ${params.topicId} · DEUSI` },
    ],
  }),
  component: () => <Outlet />,
});
