import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { motion, useScroll, useSpring } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { useDeusi } from "@/lib/deusi/store";
import { findLesson, findTopic } from "@/lib/deusi/mockGrammar";
import { InteractiveSentence } from "@/components/deusi/grammar/InteractiveSentence";
import { ExerciseBlock } from "@/components/deusi/grammar/Exercise";
import { AITools } from "@/components/deusi/grammar/AITools";
import { FaHint } from "@/components/deusi/FaHint";
import { useGrammarLesson, useLessonProgressMutations } from "@/lib/api/useGrammar";

export const Route = createFileRoute("/grammatik/$topicId/$lessonId")({
  head: ({ params }) => {
    const l = findLesson(params.topicId, params.lessonId);
    return {
      meta: [
        { title: `${l?.title ?? "Lektion"} – DEUSI` },
        { name: "description", content: l?.subtitle ?? "Grammatik Lektion" },
      ],
    };
  },
  component: LessonPage,
  notFoundComponent: () => (
    <div className="grid min-h-[60vh] place-items-center text-muted-foreground">
      Lektion nicht gefunden.
    </div>
  ),
});

function LessonPage() {
  const { topicId, lessonId } = Route.useParams();
  const { currentUser, hydrated } = useDeusi();
  const router = useRouter();
  useEffect(() => {
    if (hydrated && !currentUser) router.navigate({ to: "/login" });
  }, [hydrated, currentUser, router]);

  const { topic, lesson } = useGrammarLesson(topicId, lessonId);
  const { saveProgress, markDone, saveAnswer } = useLessonProgressMutations(topicId, lessonId);

  useEffect(() => {
    if (currentUser && lesson) saveProgress({ status: "in-progress" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser?.id, topicId, lessonId, Boolean(lesson)]);

  const { prev, next } = useMemo(() => {
    if (!topic || !lesson) return { prev: undefined, next: undefined };
    const idx = topic.lessons.findIndex((l) => l.id === lesson.id);
    return { prev: topic.lessons[idx - 1], next: topic.lessons[idx + 1] };
  }, [topic, lesson]);

  const { scrollYProgress } = useScroll();
  const progressX = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });

  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!currentUser || !topic || !lesson) return null;
  const accent = topic.accent;

  return (
    <div className="mx-auto w-full max-w-[900px] p-4 md:p-8">
      {/* Sticky reading progress bar — portaled to body so ancestor transforms don't break `position: fixed` */}
      {mounted &&
        createPortal(
          <motion.div
            aria-hidden
            className="pointer-events-none fixed left-0 right-0 top-0 z-[100] h-1.5 origin-left"
            style={{
              scaleX: progressX,
              background: `linear-gradient(90deg, ${accent}, #ec4899)`,
              boxShadow: `0 2px 12px ${accent}66`,
            }}
          />,
          document.body,
        )}

      {/* Top bar with breadcrumb */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <Link
          to="/grammatik/$topicId"
          params={{ topicId }}
          className="inline-flex items-center gap-1 rounded-full bg-muted px-3 py-1.5 text-xs font-semibold hover:bg-accent"
        >
          ← Zum Lernpfad ·{" "}
          <FaHint size="sm" inline>
            بازگشت به مسیر
          </FaHint>
        </Link>
        <nav
          className="hidden items-center gap-1.5 text-xs text-muted-foreground sm:flex"
          aria-label="Breadcrumb"
        >
          <Link to="/grammatik" className="hover:text-foreground">
            Grammatik
          </Link>
          <span>›</span>
          <Link to="/grammatik/$topicId" params={{ topicId }} className="hover:text-foreground">
            {topic.name}
          </Link>
          <span>›</span>
          <span className="max-w-[220px] truncate font-semibold text-foreground">
            {lesson.title}
          </span>
        </nav>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="rounded-full bg-muted px-3 py-1 font-semibold">{lesson.difficulty}</span>
          <span className="rounded-full bg-muted px-3 py-1 font-semibold">
            ⏱ {lesson.duration} Min
          </span>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-16">
        {lesson.sections.map((s, i) => (
          <motion.section
            key={s.id}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            {s.kind === "hero" && (
              <div
                className="glass relative overflow-hidden rounded-3xl p-8"
                style={{ background: `linear-gradient(135deg, ${accent}22, transparent 60%)` }}
              >
                <div
                  className="absolute -right-16 -top-16 h-56 w-56 rounded-full opacity-40 blur-3xl"
                  style={{ background: accent }}
                />
                <div className="relative flex items-center gap-4">
                  <motion.div
                    animate={{ y: [0, -8, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    className="grid h-24 w-24 shrink-0 place-items-center rounded-3xl text-5xl"
                    style={{ background: `${accent}33` }}
                  >
                    {lesson.emoji}
                  </motion.div>
                  <div className="min-w-0">
                    <div className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                      Lektion · {i + 1}/{lesson.sections.length}
                    </div>
                    <h1 className="truncate text-2xl font-black md:text-4xl">{lesson.title}</h1>
                    <FaHint size="sm">درس گرامر</FaHint>
                    <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
                  </div>
                </div>
              </div>
            )}
            {s.kind === "what-is" && (
              <SectionHead index={i} title={s.title} accent={accent}>
                <p className="text-base leading-relaxed text-foreground">{s.body}</p>
                {s.bullets && (
                  <ul className="mt-4 space-y-2">
                    {s.bullets.map((b, j) => (
                      <motion.li
                        key={j}
                        initial={{ opacity: 0, x: -8 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: j * 0.08 }}
                        className="flex items-start gap-2"
                      >
                        <span style={{ color: accent }}>✦</span>
                        <span>{b}</span>
                      </motion.li>
                    ))}
                  </ul>
                )}
              </SectionHead>
            )}
            {s.kind === "visual" && (
              <SectionHead index={i} title={s.title} accent={accent}>
                <p className="mb-4 text-sm text-muted-foreground">{s.body}</p>
                <div className="space-y-3">
                  {s.sentences?.map((sent) => (
                    <InteractiveSentence key={sent.id} sentence={sent} accent={accent} />
                  ))}
                </div>
              </SectionHead>
            )}
            {s.kind === "real-life" && (
              <SectionHead index={i} title={s.title} accent={accent}>
                <p className="mb-4 text-sm text-muted-foreground">{s.body}</p>
                <div className="grid gap-3 md:grid-cols-2">
                  {s.sentences?.map((sent) => (
                    <div key={sent.id} className="glass rounded-2xl p-4">
                      <div className="mb-2 flex items-center gap-2">
                        <div
                          className="grid h-8 w-8 place-items-center rounded-full text-white"
                          style={{ background: accent }}
                        >
                          💬
                        </div>
                        <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                          Alltag
                        </span>
                      </div>
                      <InteractiveSentence sentence={sent} accent={accent} />
                    </div>
                  ))}
                </div>
              </SectionHead>
            )}
            {s.kind === "exercise" && s.exercise && (
              <SectionHead index={i} title={s.title} accent={accent}>
                <ExerciseBlock
                  exercise={s.exercise}
                  accent={accent}
                  onResult={(correct, value) => saveAnswer(s.exercise!.id, value, correct)}
                />
              </SectionHead>
            )}
            {s.kind === "mistakes" && (
              <SectionHead index={i} title={s.title} accent="#ef4444">
                <div className="space-y-3">
                  {s.compare?.map((c, j) => (
                    <motion.div
                      key={j}
                      initial={{ opacity: 0, y: 12 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: j * 0.08 }}
                      className="grid gap-3 md:grid-cols-2"
                    >
                      <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4">
                        <div className="mb-1 flex items-center gap-2 text-xs font-bold text-rose-600">
                          ❌ Falsch
                        </div>
                        <p className="text-sm">{c.wrong}</p>
                      </div>
                      <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4">
                        <div className="mb-1 flex items-center gap-2 text-xs font-bold text-emerald-600">
                          ✅ Richtig
                        </div>
                        <p className="text-sm">{c.right}</p>
                        <p className="mt-1 text-xs text-emerald-700/80">💡 {c.why}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </SectionHead>
            )}
            {s.kind === "tips" && (
              <SectionHead index={i} title={s.title} accent="#f59e0b">
                <div
                  className="glass rounded-3xl p-5"
                  style={{ background: "linear-gradient(135deg, #f59e0b22, transparent)" }}
                >
                  <ul className="space-y-2">
                    {s.bullets?.map((b, j) => (
                      <li key={j} className="flex items-start gap-2">
                        <span>💡</span>
                        <span className="text-sm">{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </SectionHead>
            )}
            {s.kind === "summary" && (
              <SectionHead index={i} title={s.title} accent="#22c55e">
                <div className="grid gap-2 sm:grid-cols-2">
                  {s.bullets?.map((b, j) => (
                    <motion.div
                      key={j}
                      initial={{ opacity: 0, scale: 0.95 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: j * 0.08 }}
                      className="flex items-start gap-2 rounded-2xl bg-emerald-500/10 p-3 text-sm"
                    >
                      <span className="text-emerald-600">✓</span>
                      <span>{b}</span>
                    </motion.div>
                  ))}
                </div>
              </SectionHead>
            )}
            {s.kind === "quiz" && s.exercise && (
              <SectionHead index={i} title={s.title} accent="#0ea5e9">
                <ExerciseBlock
                  exercise={s.exercise}
                  accent="#0ea5e9"
                  onResult={(correct, value) => {
                    saveAnswer(s.exercise!.id, value, correct);
                    if (correct) markDone();
                  }}
                />
              </SectionHead>
            )}
            {s.kind === "next" && (
              <SectionHead index={i} title={s.title} accent={accent}>
                <div className="glass flex flex-col items-start gap-4 rounded-3xl p-5 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{s.body}</p>
                    {next && <div className="mt-1 text-lg font-bold">{next.title}</div>}
                  </div>
                  {next ? (
                    <Link
                      to="/grammatik/$topicId/$lessonId"
                      params={{ topicId, lessonId: next.id }}
                      className="rounded-full px-5 py-3 text-sm font-bold text-white shadow-lg transition-transform hover:scale-105"
                      style={{ background: accent }}
                    >
                      Weiterlernen →
                    </Link>
                  ) : (
                    <Link
                      to="/grammatik/$topicId"
                      params={{ topicId }}
                      className="rounded-full bg-muted px-5 py-3 text-sm font-bold"
                    >
                      Zurück zum Lernpfad
                    </Link>
                  )}
                </div>
              </SectionHead>
            )}
          </motion.section>
        ))}

        {/* AI tools always at the end */}
        <motion.section
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <AITools accent={accent} />
        </motion.section>

        {/* Prev/Next lesson footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6">
          {prev ? (
            <Link
              to="/grammatik/$topicId/$lessonId"
              params={{ topicId, lessonId: prev.id }}
              className="rounded-full bg-muted px-4 py-2 text-sm font-semibold hover:bg-accent"
            >
              ← {prev.title}
            </Link>
          ) : (
            <span />
          )}
          {next && (
            <Link
              to="/grammatik/$topicId/$lessonId"
              params={{ topicId, lessonId: next.id }}
              className="rounded-full px-4 py-2 text-sm font-bold text-white"
              style={{ background: accent }}
            >
              {next.title} →
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

function SectionHead({
  index,
  title,
  accent,
  children,
}: {
  index: number;
  title: string;
  accent: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="mb-4 flex items-center gap-3">
        <div
          className="grid h-10 w-10 place-items-center rounded-full text-sm font-black text-white shadow-md"
          style={{ background: accent }}
        >
          {index + 1}
        </div>
        <h2 className="text-2xl font-black">{title}</h2>
      </div>
      {children}
    </div>
  );
}
