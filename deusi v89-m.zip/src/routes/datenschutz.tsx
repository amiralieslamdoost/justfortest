import { createFileRoute } from "@tanstack/react-router";
import { LegalShell } from "@/components/deusi/LegalShell";

export const Route = createFileRoute("/datenschutz")({
  head: () => ({
    meta: [
      { title: "Datenschutzerklärung · DEUSI" },
      {
        name: "description",
        content: "Wie DEUSI mit deinen Daten umgeht — transparent nach DSGVO.",
      },
    ],
  }),
  component: DatenschutzPage,
});

function DatenschutzPage() {
  return (
    <LegalShell kind="datenschutz" updated="29. Juli 2026">
      <p>
        Der Schutz deiner persönlichen Daten ist uns wichtig. Diese Datenschutzerklärung erläutert,
        welche Daten wir erheben, wie wir sie verwenden und welche Rechte du hast.
      </p>

      <h2>1. Verantwortlicher</h2>
      <p>
        DEUSI GmbH, Sonnenallee 123, 12045 Berlin, Deutschland. Kontakt:{" "}
        <a href="mailto:datenschutz@deusi.app">datenschutz@deusi.app</a>.
      </p>

      <h2>2. Welche Daten wir verarbeiten</h2>
      <ul>
        <li>Konto­daten: Name, E-Mail, Passwort (verschlüsselt), Sprache, Zeitzone.</li>
        <li>Lerndaten: Fortschritt, Karten, Wiederholungs­historie, Einstellungen.</li>
        <li>Nutzungsdaten: Log-Dateien, Geräte­typ, IP-Adresse (anonymisiert).</li>
        <li>Zahlungsdaten: verarbeitet ausschließlich durch unsere Zahlungs­dienstleister.</li>
      </ul>

      <h2>3. Zwecke der Verarbeitung</h2>
      <ul>
        <li>Bereitstellung und Personalisierung des Dienstes.</li>
        <li>Vertragliche Abwicklung, Rechnungs­stellung, Support.</li>
        <li>Sicherheit, Missbrauchs­prävention und rechtliche Verpflichtungen.</li>
        <li>Anonymisierte Statistiken zur Produkt­verbesserung.</li>
      </ul>

      <h2>4. Rechtsgrundlagen (Art. 6 DSGVO)</h2>
      <p>
        Vertragserfüllung (Art. 6 Abs. 1 lit. b), berechtigte Interessen (lit. f) und deine
        Einwilligung (lit. a), soweit erforderlich.
      </p>

      <h2>5. Speicherdauer</h2>
      <p>
        Wir speichern personen­bezogene Daten nur so lange, wie es für die genannten Zwecke
        erforderlich ist oder gesetzliche Aufbewahrungs­fristen bestehen.
      </p>

      <h2>6. Empfänger und Auftragsverarbeiter</h2>
      <ul>
        <li>Hosting-Anbieter innerhalb der EU/EWR.</li>
        <li>Zahlungs­dienstleister für Abrechnung.</li>
        <li>E-Mail-Versender für Transaktions­mails.</li>
        <li>Analyse­tools ausschließlich in anonymisierter Form.</li>
      </ul>

      <h2>7. Deine Rechte</h2>
      <ul>
        <li>Recht auf Auskunft, Berichtigung, Löschung und Einschränkung.</li>
        <li>Recht auf Daten­übertragbarkeit.</li>
        <li>Widerrufs- und Widerspruchsrecht gegen die Verarbeitung.</li>
        <li>Beschwerde­recht bei der zuständigen Datenschutz­aufsichts­behörde.</li>
      </ul>

      <h2>8. Cookies und ähnliche Technologien</h2>
      <p>
        Wir verwenden technisch notwendige Cookies für Session- und Sicherheits­funktionen.
        Optionale Cookies (z. B. Analyse) werden erst nach deiner Einwilligung gesetzt und können
        jederzeit widerrufen werden.
      </p>

      <h2>9. Sicherheit</h2>
      <p>
        Wir verwenden TLS-Verschlüsselung, sichere Passwort-Hashes (Argon2) sowie regelmäßige
        Sicherheits­audits.
      </p>

      <h2>10. Kontakt und Änderungen</h2>
      <p>
        Bei Fragen erreichst du uns unter{" "}
        <a href="mailto:datenschutz@deusi.app">datenschutz@deusi.app</a>. Wir behalten uns vor,
        diese Erklärung anzupassen — die aktuelle Version findest du stets auf dieser Seite.
      </p>
    </LegalShell>
  );
}
