import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";
import { tanstackRouter } from "@tanstack/router-plugin/vite";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  base: "/",
  plugins: [
    tanstackRouter({
      target: "react",
      autoCodeSplitting: true,
      routesDirectory: "src/routes",
      generatedRouteTree: "src/routeTree.gen.ts",
    }),
    react(),
    tailwindcss(),
    tsConfigPaths(),
    // PWA / آفلاین — سرویس‌ورکر فقط در بیلد پروडاکشن ساخته و ثبت می‌شود.
    VitePWA({
      strategies: "generateSW",
      registerType: "autoUpdate",
      // ثبت سرویس‌ورکر فقط از طریق src/lib/pwa/register.ts انجام می‌شود.
      injectRegister: null,
      devOptions: { enabled: false },
      filename: "sw.js",
      // مانیفست دستی در public/manifest.webmanifest نگه‌داری می‌شود.
      manifest: false,
      includeAssets: ["favicon.ico", "robots.txt", "manifest.webmanifest"],
      workbox: {
        globPatterns: ["**/*.{js,css,html,ico,png,svg,webp,woff2}"],
        maximumFileSizeToCacheInBytes: 6 * 1024 * 1024,
        navigateFallback: "/index.html",
        navigateFallbackDenylist: [/^\/api\//, /^\/_\//, /^\/ai\//, /^\/~oauth/],
        cleanupOutdatedCaches: true,
        clientsClaim: true,
        skipWaiting: true,
        runtimeCaching: [
          {
            // ناوبری صفحات: همیشه اول شبکه، آفلاین از کش.
            urlPattern: ({ request }) => request.mode === "navigate",
            handler: "NetworkFirst",
            options: {
              cacheName: "deusi-pages",
              networkTimeoutSeconds: 4,
              expiration: { maxEntries: 40, maxAgeSeconds: 60 * 60 * 24 * 7 },
            },
          },
          {
            urlPattern: ({ url, sameOrigin }) => sameOrigin && url.pathname.startsWith("/fonts/"),
            handler: "CacheFirst",
            options: {
              cacheName: "deusi-fonts",
              expiration: { maxEntries: 20, maxAgeSeconds: 60 * 60 * 24 * 365 },
            },
          },
          {
            urlPattern: ({ url, request, sameOrigin }) =>
              sameOrigin && request.destination === "image" && !url.pathname.startsWith("/api/"),
            handler: "StaleWhileRevalidate",
            options: {
              cacheName: "deusi-images",
              expiration: { maxEntries: 120, maxAgeSeconds: 60 * 60 * 24 * 30 },
            },
          },
          {
            // داده‌های PocketBase: اول شبکه، در آفلاین آخرین پاسخ موفق.
            urlPattern: ({ url }) => url.pathname.startsWith("/api/collections/"),
            handler: "NetworkFirst",
            options: {
              cacheName: "deusi-api",
              networkTimeoutSeconds: 6,
              expiration: { maxEntries: 200, maxAgeSeconds: 60 * 60 * 24 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
        ],
      },
    }),
  ],
  server: { host: "::", port: 8080 },
  build: { outDir: "dist", sourcemap: false },
});
