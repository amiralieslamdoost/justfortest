# سشن ۱۰ — اتصال واقعی KI-Coach به هوش مصنوعی

## چه چیزی اضافه شد

### ۱) سرویس پروکسی هوش مصنوعی — `backend/ai-proxy/`

- `server.js`: سرور Node بدون وابستگی خارجی.
  - احراز هویت کاربر با توکن PocketBase (`/api/collections/users/auth-refresh`).
  - پرامپت سیستمی ویژهٔ DEUSI (توضیح آلمانی + راهنمای فارسی، متناسب با سطح CEFR کاربر).
  - استریم پاسخ به‌صورت SSE (`event: delta`) روی مسیر `POST /chat`.
  - ذخیرهٔ پیام کاربر و پاسخ مدل در `ai_messages` و به‌روزرسانی `ai_threads.last_message_at`
    با توکن ادمین (کلاینت اجازهٔ نوشتن در این کالکشن‌ها را ندارد).
  - ثبت مصرف روزانه در `ai_usage` و محدودیت نرخ (سقف درخواست روزانه و دقیقه‌ای).
  - `POST /import`: انتقال یک‌بارهٔ تاریخچهٔ محلی قدیمی به سرور.
  - `GET /health` برای مانیتورینگ.
- `package.json`، `.env.example`، `deusi-ai.service` (systemd) و `README-FA.md`.

### ۲) لایهٔ داده در فرانت‌اند

- `src/lib/api/config.ts`: متغیرهای `AI_PROXY_URL` و `AI_ENABLED`.
- `src/lib/api/ai.ts`: `listThreads` / `createThread` / `renameThread` / `deleteThread` /
  `listMessages` و `streamChat` (خوانندهٔ SSE با پشتیبانی از AbortController و خطاهای فارسی).
- `src/lib/api/useAiCoach.ts`: یک هوک واحد با دو حالت خودکار:
  - **حالت بک‌اند**: تاریخچه از PocketBase، پاسخ استریمی، انتقال خودکار تاریخچهٔ محلی.
  - **حالت MOCK**: دقیقاً رفتار قبلی (localStorage + پاسخ‌های نمونه).

### ۳) رابط کاربری

- `src/routes/ki-coach.tsx` بازنویسی شد و فقط با هوک کار می‌کند؛ متن پاسخ به‌صورت
  زنده تایپ می‌شود، دکمهٔ **Stopp** برای قطع پاسخ و نوار خطا با «تلاش دوباره» اضافه شد.
- منطق پاسخ نمونه به `src/lib/deusi/kiCoachMock.ts` منتقل شد.

## سازگاری

بدون تنظیم `VITE_AI_PROXY_URL` هیچ رفتاری تغییر نمی‌کند و برنامه مثل قبل کار می‌کند.

## وضعیت بررسی

- `bunx tsc --noEmit` بدون خطا.
- `bunx vite build` موفق.
- `node --check backend/ai-proxy/server.js` موفق.

## نکته برای سشن ۱۱

مسیرهای پیشنهادی بعدی: اتصال Schreiben/Sprechen به همان پروکسی (تصحیح متن و
بازخورد تلفظ)، صفحهٔ مصرف AI در پروفایل، و تست‌های end-to-end.
