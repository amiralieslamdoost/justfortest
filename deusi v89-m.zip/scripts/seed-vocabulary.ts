/**
 * اسکریپت مهاجرت واژگان (تکمیل سشن ۳): انتقال دیکشنری، ضرب‌المثل‌ها، افعال و
 * خانواده‌های واژه از داده‌های mock به PocketBase.
 *
 * اجرا:
 *   PB_URL=http://127.0.0.1:8090 PB_ADMIN_EMAIL=... PB_ADMIN_PASSWORD=... bun scripts/seed-vocabulary.ts
 *
 * idempotent است: رکوردها بر اساس slug/شناسه یکتا به‌روزرسانی می‌شوند.
 * بدون اجرای این اسکریپت، همگام‌سازی FSRS/Leitner روی سرور ذخیره نمی‌شود،
 * چون رکورد `words` برای اتصال `srs_cards.word` وجود ندارد.
 */
import PocketBase from "pocketbase";
import { ALL_WORDS } from "../src/lib/deusi/dictionary/mockWords";
import { PROVERBS } from "../src/lib/deusi/dictionary/proverbs";
import { WORD_ROOTS } from "../src/lib/deusi/wordfamilies/mockFamilies";
import { PREFIXES, SUFFIXES } from "../src/lib/deusi/wordfamilies/prefixes";

const PB_URL = process.env["PB_URL"] ?? "http://127.0.0.1:8090";
const EMAIL = process.env["PB_ADMIN_EMAIL"];
const PASSWORD = process.env["PB_ADMIN_PASSWORD"];

if (!EMAIL || !PASSWORD) {
  console.error("PB_ADMIN_EMAIL و PB_ADMIN_PASSWORD لازم است.");
  process.exit(1);
}

const pb = new PocketBase(PB_URL);
pb.autoCancellation(false);

const esc = (v: string) => v.replace(/'/g, "\\'");

async function upsert(collection: string, filter: string, data: Record<string, unknown>) {
  const existing = await pb
    .collection(collection)
    .getFirstListItem(filter)
    .catch(() => null);
  if (existing) return pb.collection(collection).update(existing.id, data);
  return pb.collection(collection).create(data);
}

async function seedWords() {
  const wordIdBySlug = new Map<string, string>();
  let n = 0;
  for (const w of ALL_WORDS) {
    const slug = w.id;
    const rec = await upsert("words", `slug='${esc(slug)}'`, {
      headword: w.headword,
      lemma: w.lemma,
      slug,
      pos: w.pos,
      cefr: w.cefr,
      category: w.category ?? "",
      frequency: w.frequency ?? 0,
      difficulty: w.difficulty ?? 1,
      ipa: w.ipa ?? "",
      short_meaning: w.shortMeaning ?? "",
      meanings: w.meanings ?? [],
      usage: w.usage ?? "",
      examples: w.examples ?? [],
      family: w.family ?? {},
      memory_tip: w.memoryTip ?? "",
      image_prompt: w.imagePrompt ?? "",
      noun_grammar: w.nounGrammar ?? null,
      verb_grammar: w.verbGrammar ?? null,
      adjective_grammar: w.adjectiveGrammar ?? null,
      adverb_grammar: w.adverbGrammar ?? null,
      preposition_grammar: w.prepositionGrammar ?? null,
      book_ids: [],
      published: true,
    });
    wordIdBySlug.set(slug, rec.id);
    n++;
  }
  console.log(`✓ words: ${n}`);
  return wordIdBySlug;
}

async function seedVerbs(wordIdBySlug: Map<string, string>) {
  let n = 0;
  for (const w of ALL_WORDS) {
    const g = w.verbGrammar;
    if (w.pos !== "verb" || !g) continue;
    await upsert("verbs", `infinitive='${esc(w.lemma)}'`, {
      word: wordIdBySlug.get(w.id) ?? "",
      infinitive: w.lemma,
      separable: g.separable ?? false,
      regular: g.regular ?? true,
      aux: g.aux ?? "haben",
      praeteritum: g.praeteritum ?? "",
      perfekt: g.perfekt ?? "",
      partizip_ii: g.partizipII ?? "",
      praesens_conj: g.praesens ?? {},
      praeteritum_conj: g.praeteritumConj ?? {},
      perfekt_conj: (g as { perfektConj?: unknown }).perfektConj ?? {},
      governed_prepositions: (g as { governedPrepositions?: unknown[] }).governedPrepositions ?? [],
      object_case: (g as { objectCase?: string }).objectCase ?? "none",
      reflexive: (g as { reflexive?: boolean }).reflexive ?? false,
    });
    n++;
  }
  console.log(`✓ verbs: ${n}`);
}

async function seedProverbs() {
  let n = 0;
  for (const p of PROVERBS) {
    await upsert("proverbs", `de='${esc(p.de)}'`, {
      kind: p.kind,
      de: p.de,
      literal: p.literal ?? "",
      fa: p.fa ?? "",
      meaning: p.meaning ?? "",
      example: p.example ?? "",
      cefr: p.cefr ?? "B1",
      icon: p.icon ?? "",
      color: p.color ?? "",
    });
    n++;
  }
  console.log(`✓ proverbs: ${n}`);
}

async function seedFamilies() {
  const allPrefixes = [...PREFIXES, ...SUFFIXES];
  let n = 0;
  for (const r of WORD_ROOTS) {
    const used = allPrefixes.filter((p) =>
      r.members.some((m) => m.prefix === p.prefix || m.suffix === p.prefix),
    );
    await upsert("word_families", `root='${esc(r.root)}'`, {
      root: r.root,
      label: r.label,
      meaning_de: r.meaningDe ?? "",
      meaning_fa: r.meaningFa ?? "",
      cefr: r.cefr ?? "A2",
      note_de: r.noteDe ?? "",
      note_fa: r.noteFa ?? "",
      members: r.members ?? [],
      prefixes: used,
    });
    n++;
  }
  console.log(`✓ word_families: ${n}`);
}

async function main() {
  await pb.collection("_superusers").authWithPassword(EMAIL!, PASSWORD!);
  const map = await seedWords();
  await seedVerbs(map);
  await seedProverbs();
  await seedFamilies();
  console.log("پایان seed واژگان.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
