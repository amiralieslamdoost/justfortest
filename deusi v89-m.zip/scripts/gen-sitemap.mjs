import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";

/**
 * تولید public/sitemap.xml از روی روت‌های عمومی برنامه.
 * اجرا: node scripts/gen-sitemap.mjs
 *
 * آدرس دامنه از متغیر محیطی SITE_URL خوانده می‌شود.
 */
const BASE_URL = (process.env.SITE_URL ?? "").replace(/\/$/, "");

/** فقط صفحاتی که بدون ورود قابل مشاهده و ارزش ایندکس شدن دارند. */
const PUBLIC_ROUTES = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/login", changefreq: "yearly", priority: "0.3" },
  { path: "/register", changefreq: "yearly", priority: "0.5" },
  { path: "/impressum", changefreq: "yearly", priority: "0.2" },
  { path: "/datenschutz", changefreq: "yearly", priority: "0.2" },
  { path: "/agb", changefreq: "yearly", priority: "0.2" },
  { path: "/support", changefreq: "monthly", priority: "0.4" },
  { path: "/docs", changefreq: "monthly", priority: "0.5" },
];

function buildSitemap() {
  const urls = PUBLIC_ROUTES.map((entry) =>
    [
      "  <url>",
      `    <loc>${BASE_URL}${entry.path}</loc>`,
      entry.changefreq ? `    <changefreq>${entry.changefreq}</changefreq>` : null,
      entry.priority ? `    <priority>${entry.priority}</priority>` : null,
      "  </url>",
    ]
      .filter(Boolean)
      .join("\n"),
  );

  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    ...urls,
    "</urlset>",
    "",
  ].join("\n");
}

const target = resolve(process.cwd(), "public/sitemap.xml");
mkdirSync(dirname(target), { recursive: true });
writeFileSync(target, buildSitemap(), "utf8");

if (!BASE_URL) {
  console.warn(
    "[sitemap] SITE_URL تنظیم نشده است؛ آدرس‌ها نسبی نوشته شدند. برای انتشار حتماً SITE_URL را ست کنید.",
  );
}
console.log(`[sitemap] ${PUBLIC_ROUTES.length} آدرس در public/sitemap.xml نوشته شد.`);
