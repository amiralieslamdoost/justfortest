import { useState } from "react";
import { motion } from "@/lib/motion-lite";
import { ArrowLeft, ArrowRight, RotateCcw, Volume2, Check, X } from "lucide-react";
import type { VocabItem } from "@/lib/deusi/mockReading";

interface Props {
  vocab: VocabItem[];
  onFinish?: (summary: { known: number; learning: number; total: number }) => void;
}

const ARTICLE_BG: Record<string, string> = {
  der: "linear-gradient(160deg,#DBEAFE,#BFDBFE)",
  die: "linear-gradient(160deg,#FEE2E2,#FECACA)",
  das: "linear-gradient(160deg,#FEF3C7,#FDE68A)",
};

export function Flashcards({ vocab, onFinish }: Props) {
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<Set<string>>(new Set());
  const [learning, setLearning] = useState<Set<string>>(new Set());

  if (vocab.length === 0) {
    return (
      <div className="neu-card p-8 text-center">
        <div className="text-lg font-bold">Kein Wortschatz vorhanden</div>
        <p className="mt-2 text-sm text-muted-foreground">
          Speichere Wörter beim Lesen, um Karteikarten zu üben.
        </p>
      </div>
    );
  }

  const card = vocab[i];
  const total = vocab.length;
  const done = known.size + learning.size;
  const progress = Math.round((done / total) * 100);

  function mark(kind: "known" | "learning") {
    const set = kind === "known" ? new Set(known) : new Set(learning);
    set.add(card.word);
    if (kind === "known") setKnown(set);
    else setLearning(set);
    setFlipped(false);
    if (i < total - 1) setI(i + 1);
    else
      onFinish?.({
        known: kind === "known" ? set.size : known.size,
        learning: kind === "learning" ? set.size : learning.size,
        total,
      });
  }

  function nav(dir: 1 | -1) {
    setFlipped(false);
    setI((v) => Math.min(total - 1, Math.max(0, v + dir)));
  }

  return (
    <div className="neu-card p-5 sm:p-6">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <div className="text-lg font-bold">Wörter lernen</div>
          <div className="text-xs text-muted-foreground">
            Karte {i + 1} von {total}
          </div>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="rounded-full bg-green-100 px-2 py-0.5 font-semibold text-green-700 dark:bg-green-500/15 dark:text-green-300">
            ✓ {known.size}
          </span>
          <span className="rounded-full bg-amber-100 px-2 py-0.5 font-semibold text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">
            ↻ {learning.size}
          </span>
        </div>
      </div>

      <div className="mb-5 h-1.5 overflow-hidden rounded-full bg-secondary">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.4 }}
          className="h-full rounded-full bg-[var(--flag-red)]"
        />
      </div>

      {/* Card */}
      <div className="flip-scene relative mx-auto aspect-[4/3] w-full max-w-md">
        <button
          type="button"
          onClick={() => setFlipped((f) => !f)}
          className={`flip-card h-full w-full ${flipped ? "is-flipped" : ""}`}
          aria-label="Karte umdrehen"
        >
          <div
            className="flip-face front flex flex-col items-center justify-center rounded-3xl p-6 text-center shadow-lg ring-1 ring-border"
            style={{
              background: card.article
                ? ARTICLE_BG[card.article]
                : "linear-gradient(160deg,#FFF,#F5F5F5)",
            }}
          >
            {card.article && (
              <span className="mb-2 rounded-full bg-white/70 px-3 py-1 text-xs font-bold uppercase tracking-widest">
                {card.article}
              </span>
            )}
            <div className="text-3xl font-black sm:text-4xl">{card.word}</div>
            <div className="mt-2 font-mono text-xs text-muted-foreground">{card.pronunciation}</div>
            <div className="mt-4 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              Zum Umdrehen tippen
            </div>
          </div>

          <div
            className="flip-face back flex flex-col items-center justify-center rounded-3xl p-6 text-center shadow-lg ring-1 ring-border"
            style={{ background: "linear-gradient(160deg,#F3ECFF,#EDE4FF)" }}
          >
            <div className="text-[11px] font-semibold uppercase tracking-widest text-[#6D28D9]">
              Übersetzung
            </div>
            <div className="mt-2 text-2xl font-black sm:text-3xl">{card.translation}</div>
            <div className="mt-4 max-w-xs text-sm italic text-muted-foreground">
              „{card.example}“
            </div>
          </div>
        </button>
      </div>

      {/* Controls */}
      <div className="mt-5 flex items-center justify-between gap-2">
        <button
          onClick={() => nav(-1)}
          disabled={i === 0}
          className="grid h-11 w-11 place-items-center rounded-full bg-secondary text-muted-foreground transition hover:bg-muted disabled:opacity-40"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>

        <div className="flex flex-1 items-center justify-center gap-2">
          <button
            onClick={() => window.speechSynthesis?.speak(new SpeechSynthesisUtterance(card.word))}
            className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-2 text-xs font-semibold hover:bg-muted"
          >
            <Volume2 className="h-4 w-4" /> Aussprache
          </button>
          <button
            onClick={() => setFlipped((f) => !f)}
            className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-2 text-xs font-semibold hover:bg-muted"
          >
            <RotateCcw className="h-4 w-4" /> Umdrehen
          </button>
        </div>

        <button
          onClick={() => nav(1)}
          disabled={i === total - 1}
          className="grid h-11 w-11 place-items-center rounded-full bg-secondary text-muted-foreground transition hover:bg-muted disabled:opacity-40"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <button
          onClick={() => mark("learning")}
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-amber-100 px-4 py-3 text-sm font-bold text-amber-800 shadow-sm ring-1 ring-amber-200 transition hover:-translate-y-0.5 dark:bg-amber-500/15 dark:text-amber-200 dark:ring-amber-500/30"
        >
          <X className="h-4 w-4" /> Noch lernen
        </button>
        <button
          onClick={() => mark("known")}
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-green-100 px-4 py-3 text-sm font-bold text-green-800 shadow-sm ring-1 ring-green-200 transition hover:-translate-y-0.5 dark:bg-green-500/15 dark:text-green-200 dark:ring-green-500/30"
        >
          <Check className="h-4 w-4" /> Kenne ich
        </button>
      </div>
    </div>
  );
}
