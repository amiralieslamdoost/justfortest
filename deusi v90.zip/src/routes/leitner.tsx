import { createFileRoute, useRouter } from "@tanstack/react-router";
import { motion } from "@/lib/motion-lite";
import { useEffect, useMemo, useState } from "react";
import { useDeusi } from "@/lib/deusi/store";
import { SectionHero } from "@/components/deusi/SectionHero";
import { CEFR_LEVELS, POS_SHORT, CEFR_COLOR, POS_COLOR } from "@/lib/deusi/dictionary/categories";
import type { CEFR, DictPos } from "@/lib/deusi/dictionary/types";
import {
  LEITNER_BOXES,
  LEITNER_STATS,
  WEEKLY_ACTIVITY,
  REVIEW_HEATMAP,
  TODAY_QUEUE,
  AI_INSIGHTS,
  PRESETS,
  DEFAULT_SETTINGS,
  computePreview,
  type PresetId,
  type ReviewOrder,
  type SessionSettings,
  type LeitnerBoxNumber,
} from "@/lib/deusi/leitner/mockLeitner";
import {
  Counter,
  Ring,
  StatGlass,
  BoxCard,
  PresetCard,
  WeeklyBars,
  Heatmap,
  QueueRow,
  InsightCard,
  SessionPreviewCard,
  Toggle,
  ChipGroup,
  NumberField,
  Select,
} from "@/components/deusi/leitner/parts";
import { MasteredWordsCard } from "@/components/deusi/leitner/MasteredWords";
import { useLeitnerQueue } from "@/lib/deusi/dictionary/leitnerQueue";
import { ALL_WORDS } from "@/lib/deusi/dictionary/mockWords";
import { Fa } from "@/components/deusi/Fa";

export const Route = createFileRoute("/leitner")({
  head: () => ({
    meta: [
      { title: "Leitner-Box — DEUSI" },
      {
        name: "description",
        content: "Vokabeln mit dem Leitner-System in Boxen wiederholen und festigen.",
      },
      { property: "og:title", content: "Leitner-Box — DEUSI" },
      {
        property: "og:description",
        content: "Vokabeln mit dem Leitner-System in Boxen wiederholen und festigen.",
      },
    ],
  }),
  component: LeitnerPage,
});

const LS_KEY = "deusi.leitner.settings.v1";

function loadSettings(): SessionSettings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function LeitnerPage() {
  const { currentUser, hydrated, ensureDeckFor } = useDeusi();
  const router = useRouter();

  const [settings, setSettings] = useState<SessionSettings>(DEFAULT_SETTINGS);
  const [preset, setPreset] = useState<PresetId | null>("balanced");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (!hydrated) return;
    if (!currentUser) router.navigate({ to: "/login" });
    else ensureDeckFor(currentUser.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, currentUser?.id]);

  useEffect(() => {
    setSettings(loadSettings());
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted) {
      try {
        localStorage.setItem(LS_KEY, JSON.stringify(settings));
      } catch {
        /* noop */
      }
    }
  }, [settings, mounted]);

  const preview = useMemo(() => computePreview(settings), [settings]);

  const leitner = useLeitnerQueue();
  const wordsByBox = useMemo(() => {
    const map: Record<number, string[]> = { 1: [], 2: [], 3: [], 4: [], 5: [] };
    // words the user pushed from the dictionary (default box 1, or moved later)
    for (const item of leitner.items) {
      const w = ALL_WORDS.find((x) => x.id === item.id);
      map[item.box].push(w?.headword ?? item.id);
    }
    // static demo queue items belonging to each box
    for (const q of TODAY_QUEUE) {
      if (!map[q.box].includes(q.headword)) map[q.box].push(q.headword);
    }
    return map;
  }, [leitner.items]);

  const applyPreset = (id: PresetId) => {
    const p = PRESETS.find((x) => x.id === id)!;
    setPreset(id);
    setSettings((s) => p.apply(s));
  };

  const update = <K extends keyof SessionSettings>(k: K, v: SessionSettings[K]) => {
    setPreset(null);
    setSettings((s) => ({ ...s, [k]: v }));
  };

  const startLearning = () => {
    try {
      localStorage.setItem(
        "deusi.leitner.pendingSession",
        JSON.stringify({ settings, preview, startedAt: Date.now() }),
      );
    } catch {
      /* noop */
    }
    router.navigate({ to: "/learn" });
  };

  if (!currentUser) return null;

  return (
    <div className="space-y-6 animate-fade">
      {/* Unified section header */}
      <SectionHero
        sectionKey="leitner"
        right={
          <>
            <div className="rounded-2xl bg-white/15 px-3 py-2 text-xs font-semibold text-white ring-1 ring-white/20 backdrop-blur">
              🔥 Streak:{" "}
              <span className="tabular-nums font-black">
                <Counter to={LEITNER_STATS.streak} />
              </span>{" "}
              Tage
            </div>
            <div className="rounded-2xl bg-white/15 px-3 py-2 text-xs font-semibold text-white ring-1 ring-white/20 backdrop-blur">
              📅 Heute fällig:{" "}
              <span className="tabular-nums font-black">
                <Counter to={LEITNER_STATS.dueToday} />
              </span>
            </div>
          </>
        }
      />

      {/* Prominent Start CTA — near top for high visibility */}
      <motion.button
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.05 }}
        whileHover={{ y: -2, boxShadow: "0 30px 60px -20px rgba(139,92,246,.55)" }}
        whileTap={{ scale: 0.995 }}
        onClick={startLearning}
        className="relative flex w-full items-center justify-between gap-4 overflow-hidden rounded-[1.75rem] px-6 py-5 text-left shadow-[0_20px_50px_-20px_rgba(139,92,246,.5)]"
        style={{ background: "linear-gradient(135deg, #8B5CF6, #EC4899)" }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/20 blur-2xl"
        />
        <div className="relative flex items-center gap-4">
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/25 text-2xl text-white backdrop-blur">
            ▶
          </span>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-white/85">
              Bereit für heute?
            </div>
            <div className="text-2xl font-black text-white md:text-3xl">Lernen starten</div>
          </div>
        </div>
        <div className="relative hidden items-center gap-2 sm:flex">
          <div className="rounded-2xl bg-white/15 px-3 py-2 text-center text-white backdrop-blur">
            <div className="text-[9px] font-semibold uppercase tracking-wider text-white/80">
              Karten
            </div>
            <div className="text-lg font-black tabular-nums">{preview.totalCards}</div>
          </div>
          <div className="rounded-2xl bg-white/15 px-3 py-2 text-center text-white backdrop-blur">
            <div className="text-[9px] font-semibold uppercase tracking-wider text-white/80">
              Min
            </div>
            <div className="text-lg font-black tabular-nums">≈{preview.estimatedMinutes}</div>
          </div>
          <div className="rounded-2xl bg-white/15 px-3 py-2 text-center text-white backdrop-blur">
            <div className="text-[9px] font-semibold uppercase tracking-wider text-white/80">
              XP
            </div>
            <div className="text-lg font-black tabular-nums">+{preview.estimatedXp}</div>
          </div>
        </div>
      </motion.button>

      {/* KPI grid */}
      <section className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatGlass
          icon={<span>🧠</span>}
          label="Memory Health"
          fa="سلامت حافظه"
          value={<Counter to={LEITNER_STATS.memoryHealth} suffix="%" />}
          sub="Sehr gut"
          color="#8B5CF6"
          tint="#F3ECFF"
          delay={0.05}
        />
        <StatGlass
          icon={<span>📚</span>}
          label="Karten gesamt"
          fa="کل کارت‌ها"
          value={<Counter to={LEITNER_STATS.totalCards} />}
          sub={`+${LEITNER_STATS.learning} lernend`}
          color="#3B82F6"
          tint="#E7F0FF"
          delay={0.1}
        />
        <StatGlass
          icon={<span>🏆</span>}
          label="Gemeistert"
          fa="تسلط‌یافته"
          value={<Counter to={LEITNER_STATS.mastered} />}
          sub={`${Math.round((LEITNER_STATS.mastered / LEITNER_STATS.totalCards) * 100)}% Fortschritt`}
          color="#22C55E"
          tint="#E7F8EE"
          delay={0.15}
        />
        <StatGlass
          icon={<span>🎯</span>}
          label="Erfolgsrate"
          fa="نرخ موفقیت"
          value={<Counter to={LEITNER_STATS.successRate} suffix="%" />}
          sub={`Retention ${LEITNER_STATS.retentionRate}%`}
          color="#F59E0B"
          tint="#FFF4D6"
          delay={0.2}
        />
        <StatGlass
          icon={<span>📈</span>}
          label="Wöchentlich"
          fa="هفتگی"
          value={<Counter to={LEITNER_STATS.weeklyReviews} />}
          sub={`Monat: ${LEITNER_STATS.monthlyReviews}`}
          color="#EF4444"
          tint="#FEE9E7"
          delay={0.25}
        />
      </section>

      {/* Leitner boxes — FULL WIDTH */}
      <section className="relative overflow-hidden rounded-[2rem] border border-border/70 bg-gradient-to-br from-card via-card to-secondary/30 p-5 md:p-8 shadow-[0_20px_60px_-30px_rgba(0,0,0,0.15)]">
        <div
          aria-hidden
          className="pointer-events-none absolute -left-24 -top-24 h-64 w-64 rounded-full bg-[#8B5CF6]/10 blur-3xl"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -bottom-24 h-64 w-64 rounded-full bg-[#EC4899]/10 blur-3xl"
        />

        <div className="relative mb-6 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="mb-1 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">
              Spaced Repetition · 5 Stufen
            </div>
            <h2 className="text-2xl font-black md:text-3xl">Deine Leitner Boxen</h2>
            <Fa className="fa-hint-xs">جعبه‌های لایتنر شما</Fa>
            <p className="mt-1 text-sm text-muted-foreground">
              Fortschritt pro Kompetenzstufe – von neu bis gemeistert.
            </p>
          </div>
          <div className="flex items-center gap-4 rounded-2xl border border-border/60 bg-background/60 px-4 py-3 backdrop-blur">
            <div className="text-right">
              <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Gesamt
              </div>
              <div className="text-lg font-black tabular-nums">
                <Counter to={LEITNER_BOXES.reduce((s, b) => s + b.cards, 0)} />
              </div>
            </div>
            <div className="h-8 w-px bg-border" />
            <div className="text-right">
              <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Ø Fortschritt
              </div>
              <div className="text-lg font-black tabular-nums text-[#8B5CF6]">
                <Counter
                  to={Math.round(
                    LEITNER_BOXES.reduce((s, b) => s + b.progress, 0) / LEITNER_BOXES.length,
                  )}
                  suffix="%"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Modern distribution bar */}
        <div className="relative mb-8">
          <div
            className="relative flex h-3 w-full overflow-hidden rounded-full shadow-inner"
            style={{ background: "color-mix(in oklab, var(--secondary) 80%, transparent)" }}
          >
            {(() => {
              const total = LEITNER_BOXES.reduce((s, b) => s + b.cards, 0) || 1;
              return LEITNER_BOXES.map((b, idx) => (
                <motion.div
                  key={b.box}
                  initial={{ width: 0 }}
                  animate={{ width: `${(b.cards / total) * 100}%` }}
                  transition={{ duration: 1, delay: 0.05 * idx, ease: [0.2, 0.8, 0.2, 1] }}
                  className="relative h-full"
                  style={{ background: b.color }}
                  title={`Box ${b.box} · ${b.cards} Karten`}
                />
              ));
            })()}
          </div>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-[11px] font-semibold text-muted-foreground">
            {LEITNER_BOXES.map((b) => (
              <div key={b.box} className="flex items-center gap-1.5">
                <span
                  className="inline-block h-2.5 w-2.5 rounded-full ring-2 ring-background"
                  style={{ background: b.color, boxShadow: `0 0 0 1px ${b.color}55` }}
                />
                <span className="text-foreground/80">{b.label}</span>
                <span className="tabular-nums">{b.cards}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {LEITNER_BOXES.map((b, i) => (
            <BoxCard key={b.box} b={b} i={i} words={wordsByBox[b.box] ?? []} />
          ))}
        </div>
      </section>

      {/* Main grid (rest of page) */}
      <section className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_380px]">
        <div className="space-y-5">
          {/* Mastered words */}
          <MasteredWordsCard
            headwords={wordsByBox[5] ?? []}
            totalCards={LEITNER_BOXES.reduce((s, b) => s + b.cards, 0)}
          />

          {/* Settings */}
          <div className="glass-strong rounded-[1.75rem] p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black">Lern-Einstellungen</h2>
                <Fa className="fa-hint-xs">تنظیمات یادگیری</Fa>
                <p className="text-xs text-muted-foreground">Feintuning für die heutige Sitzung.</p>
              </div>
              <button
                onClick={() => {
                  setPreset(null);
                  setSettings(DEFAULT_SETTINGS);
                }}
                className="rounded-xl border border-border px-3 py-1.5 text-xs font-semibold hover:bg-secondary"
              >
                Zurücksetzen
              </button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-3">
                <NumberField
                  label="Neue Karten / Tag"
                  value={settings.dailyNewLimit}
                  onChange={(v) => update("dailyNewLimit", v)}
                  max={100}
                />
                <NumberField
                  label="Wiederholungen / Tag"
                  value={settings.dailyReviewLimit}
                  onChange={(v) => update("dailyReviewLimit", v)}
                  max={200}
                  step={5}
                />
                <NumberField
                  label="Antwort-Verzögerung (Sek)"
                  value={settings.revealDelaySec}
                  onChange={(v) => update("revealDelaySec", v)}
                  max={15}
                />
                <Select<ReviewOrder>
                  label="Reihenfolge"
                  value={settings.reviewOrder}
                  onChange={(v) => update("reviewOrder", v)}
                  options={[
                    { value: "due-first", label: "Fällige zuerst" },
                    { value: "hardest-first", label: "Schwierigste zuerst" },
                    { value: "by-box", label: "Nach Box" },
                    { value: "random", label: "Zufällig" },
                  ]}
                />
              </div>

              <div className="space-y-2">
                <Toggle
                  on={settings.shuffle}
                  onChange={(v) => update("shuffle", v)}
                  label="Karten mischen"
                />
                <Toggle
                  on={settings.autoPlayPronunciation}
                  onChange={(v) => update("autoPlayPronunciation", v)}
                  label="Aussprache automatisch abspielen"
                />
                <Toggle
                  on={settings.showTranslation}
                  onChange={(v) => update("showTranslation", v)}
                  label="Übersetzung anzeigen"
                />
                <Toggle
                  on={settings.showExample}
                  onChange={(v) => update("showExample", v)}
                  label="Beispielsatz anzeigen"
                />
                <Toggle
                  on={settings.showGrammar}
                  onChange={(v) => update("showGrammar", v)}
                  label="Grammatik-Notizen anzeigen"
                />
                <Toggle
                  on={settings.showHints}
                  onChange={(v) => update("showHints", v)}
                  label="Hinweise anzeigen"
                />
                <Toggle
                  on={settings.onlyDueToday}
                  onChange={(v) => update("onlyDueToday", v)}
                  label="Nur heute fällige Karten"
                />
                <Toggle
                  on={settings.includeDifficult}
                  onChange={(v) => update("includeDifficult", v)}
                  label="Schwierige Wörter einbeziehen"
                />
                <Toggle
                  on={settings.includeFavorites}
                  onChange={(v) => update("includeFavorites", v)}
                  label="Lieblingswörter einbeziehen"
                />
              </div>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <div>
                <div className="mb-2 text-[11px] font-semibold text-muted-foreground">
                  CEFR-Stufen
                </div>
                <ChipGroup<CEFR>
                  options={[...CEFR_LEVELS]}
                  value={settings.cefrLevels}
                  onChange={(v) => update("cefrLevels", v)}
                  colors={CEFR_COLOR}
                />
              </div>
              <div>
                <div className="mb-2 text-[11px] font-semibold text-muted-foreground">
                  Wortarten
                </div>
                <ChipGroup<DictPos>
                  options={[
                    "noun",
                    "verb",
                    "adjective",
                    "adverb",
                    "preposition",
                    "conjunction",
                    "pronoun",
                  ]}
                  value={settings.wordTypes}
                  onChange={(v) => update("wordTypes", v)}
                  colors={Object.fromEntries(Object.entries(POS_COLOR).map(([k, v]) => [k, v]))}
                />
                <div className="mt-2 flex flex-wrap gap-1 text-[10px] text-muted-foreground">
                  {settings.wordTypes.map((t) => (
                    <span key={t}>{POS_SHORT[t]}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Intervals */}
            <div className="mt-5">
              <div className="mb-2 text-[11px] font-semibold text-muted-foreground">
                Wiederholungsintervalle (Tage)
              </div>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                {([1, 2, 3, 4, 5] as LeitnerBoxNumber[]).map((box) => (
                  <NumberField
                    key={box}
                    label={`Box ${box}`}
                    value={settings.intervals[box]}
                    onChange={(v) => update("intervals", { ...settings.intervals, [box]: v })}
                    max={365}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Statistics — bewusst schlank: ein Verlauf + vier Kennzahlen */}
          <div className="glass-strong rounded-[1.75rem] p-4 sm:p-5">
            <div className="mb-4 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h2 className="text-lg font-black">Statistiken</h2>
                <Fa className="fa-hint-xs">آمار</Fa>
              </div>
              <span className="shrink-0 text-[11px] text-muted-foreground">letzte 12 Wochen</span>
            </div>

            <div className="glass rounded-2xl p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-semibold">Wöchentliche Aktivität</span>
                <span className="text-[11px] text-muted-foreground">Reviews / Tag</span>
              </div>
              <WeeklyBars data={WEEKLY_ACTIVITY} />
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <MiniStat
                label="Behalten"
                value={LEITNER_STATS.retentionRate}
                color="#22C55E"
                suffix="%"
              />
              <MiniStat label="Richtig" value={LEITNER_STATS.correctAnswers} color="#0EA5E9" />
              <MiniStat
                label="Ø Zeit"
                value={LEITNER_STATS.avgResponseSec}
                color="#8B5CF6"
                suffix="s"
                decimals={1}
              />
              <MiniStat label="Gelernt" value={LEITNER_STATS.mastered} color="#F59E0B" />
            </div>
          </div>
        </div>

        {/* Right column */}
        <aside className="space-y-5">
          <SessionPreviewCard p={preview} />

          {/* Today queue */}
          <div className="glass-strong rounded-[1.75rem] p-5">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black">Heutige Warteschlange</h3>
                <Fa className="fa-hint-xs">صف امروز</Fa>
              </div>
              <span className="rounded-xl bg-[color:var(--flag-red)] px-2 py-0.5 text-[10px] font-bold text-white">
                {TODAY_QUEUE.length}
              </span>
            </div>
            <ul className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {TODAY_QUEUE.map((q) => (
                <QueueRow key={q.id} q={q} />
              ))}
            </ul>
          </div>

          {/* AI Insights */}
          <div className="glass-strong rounded-[1.75rem] p-5">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black">✨ KI-Einblicke</h3>
                <Fa className="fa-hint-xs">بینش‌های هوش مصنوعی</Fa>
              </div>
              <span className="text-[10px] text-muted-foreground">personalisiert</span>
            </div>
            <div className="space-y-2.5">
              {AI_INSIGHTS.map((i) => (
                <InsightCard key={i.id} i={i} />
              ))}
            </div>
          </div>
        </aside>
      </section>
    </div>
  );
}

function MiniStat({
  label,
  value,
  color,
  suffix,
  decimals,
}: {
  label: string;
  value: number;
  color: string;
  suffix?: string;
  decimals?: number;
}) {
  return (
    <div className="rounded-xl bg-secondary/50 p-2">
      <div className="text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className="text-sm font-black tabular-nums" style={{ color }}>
        <Counter to={value} suffix={suffix} decimals={decimals} />
      </div>
    </div>
  );
}
