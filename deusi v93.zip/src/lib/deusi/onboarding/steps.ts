import type { CefrLevel, GoalKey } from "@/lib/deusi/planner/types";
import type {
  InterestKey,
  LearningPreference,
  OnboardingAnswers,
  ReviewLoad,
  ReviewStyle,
} from "./types";

/**
 * Schritt-Kennungen des Onboardings.
 *
 * Bewusst wenige, dafür zusammengehörige Schritte: die Fragen werden innerhalb
 * eines Schritts in kleine Abschnitte gruppiert.
 */
export type StepId = "level" | "goals" | "schedule" | "pace" | "skills" | "style";

/**
 * Titel, persische Übersetzung und ein kurzer persischer Hinweis.
 * Bewusst knapp gehalten — das Onboarding soll ruhig wirken.
 */
export const STEP_TITLE: Record<StepId, { de: string; fa: string; hintFa?: string; accent: string }> =
  {
    level: {
      de: "Wie gut ist dein Deutsch?",
      fa: "آلمانی‌ات در چه سطحی است؟",
      hintFa: "مطمئن نیستی؟ «هنوز نمی‌دانم» را بزن.",
      accent: "#6366f1",
    },
    goals: {
      de: "Warum lernst du Deutsch?",
      fa: "چرا آلمانی یاد می‌گیری؟",
      hintFa: "می‌توانی چند هدف را با هم انتخاب کنی.",
      accent: "#ec4899",
    },
    schedule: {
      de: "Wann lernst du?",
      fa: "چه زمانی یاد می‌گیری؟",
      hintFa: "واقع‌بین باش؛ نظم از طول جلسه مهم‌تر است.",
      accent: "#0ea5e9",
    },
    pace: {
      de: "Wie schnell willst du vorankommen?",
      fa: "با چه سرعتی پیش بروی؟",
      hintFa: "هر زمان می‌توانی این را عوض کنی.",
      accent: "#14b8a6",
    },
    skills: {
      de: "Wo bist du stark, wo schwach?",
      fa: "در کدام مهارت قوی یا ضعیفی؟",
      hintFa: "مهارت‌های ضعیف زمان بیشتری در برنامه می‌گیرند.",
      accent: "#f97316",
    },
    style: {
      de: "Wie lernst du am liebsten?",
      fa: "چطور دوست داری یاد بگیری؟",
      hintFa: "بر این اساس محتوا و کارت‌های روزانه‌ات انتخاب می‌شود.",
      accent: "#a855f7",
    },
  };

export const LEVEL_OPTIONS: {
  value: CefrLevel;
  label: string;
  desc: string;
  descFa: string;
}[] = [
  {
    value: "unknown",
    label: "Noch unbekannt",
    desc: "Ich bin mir nicht sicher",
    descFa: "هنوز نمی‌دانم",
  },
  {
    value: "A1",
    label: "A1",
    desc: "Erste Wörter und Sätze",
    descFa: "اولین کلمه‌ها و جمله‌ها",
  },
  {
    value: "A2",
    label: "A2",
    desc: "Alltag in einfachen Sätzen",
    descFa: "روزمره با جمله‌های ساده",
  },
  { value: "B1", label: "B1", desc: "Selbstständig im Alltag", descFa: "مستقل در زندگی روزمره" },
  {
    value: "B2",
    label: "B2",
    desc: "Sicher in Beruf und Studium",
    descFa: "مطمئن در کار و دانشگاه",
  },
  { value: "C1", label: "C1", desc: "Fließend und differenziert", descFa: "روان و دقیق" },
  { value: "C2", label: "C2", desc: "Nahezu muttersprachlich", descFa: "در حد زبان مادری" },
];

export const GOAL_OPTIONS: { value: GoalKey; desc: string; descFa: string }[] = [
  {
    value: "general",
    desc: "Solide Grundlagen in allen Fertigkeiten",
    descFa: "پایه‌ی محکم در همه‌ی مهارت‌ها",
  },
  {
    value: "migration",
    desc: "Behörden, Arzt, Nachbarschaft, Alltag",
    descFa: "اداره‌ها، پزشک و زندگی روزمره",
  },
  {
    value: "university",
    desc: "Lesen, Schreiben, akademischer Wortschatz",
    descFa: "خواندن، نوشتن و واژگان دانشگاهی",
  },
  {
    value: "work",
    desc: "Bewerbung, Meetings, Fachsprache",
    descFa: "رزومه، جلسه‌ها و زبان تخصصی",
  },
  {
    value: "goethe",
    desc: "Zielgerichtet auf das Goethe-Zertifikat",
    descFa: "آمادگی برای مدرک گوته",
  },
  { value: "testdaf", desc: "Vorbereitung auf TestDaF", descFa: "آمادگی برای تست‌داف" },
  { value: "conversation", desc: "Frei sprechen und verstehen", descFa: "صحبت آزاد و درک گفتار" },
  { value: "travel", desc: "Unterwegs zurechtkommen", descFa: "برای سفر" },
];

export const MINUTE_OPTIONS = [20, 30, 45, 60, 90, 120];

export const MINUTE_HINT_FA: Record<number, string> = {
  20: "کوتاه ولی هر روز",
  30: "متعادل و قابل‌دوام",
  45: "پیشرفت محسوس",
  60: "یک ساعت کامل",
  90: "برای هدف‌های فشرده",
  120: "آماده‌سازی جدی آزمون",
};

export const PREFERENCE_LABEL: Record<LearningPreference, { de: string; fa: string }> = {
  vocabulary: { de: "Wortschatz", fa: "واژگان" },
  grammar: { de: "Grammatik", fa: "گرامر" },
  listening: { de: "Hören", fa: "شنیدن" },
  speaking: { de: "Sprechen", fa: "صحبت کردن" },
  reading: { de: "Lesen", fa: "خواندن" },
  podcasts: { de: "Podcasts", fa: "پادکست" },
  movies: { de: "Filme & Serien", fa: "فیلم و سریال" },
  "ai-coach": { de: "KI-Coach", fa: "مربی هوش مصنوعی" },
};

export const PREFERENCE_ORDER: LearningPreference[] = [
  "vocabulary",
  "grammar",
  "listening",
  "speaking",
  "reading",
  "podcasts",
  "movies",
  "ai-coach",
];

/** Interessengebiete — Grundlage für Inhalts-Empfehlungen im ganzen Produkt. */
export const INTEREST_LABEL: Record<InterestKey, { de: string; fa: string }> = {
  travel: { de: "Reisen", fa: "سفر" },
  work: { de: "Beruf & Business", fa: "کار و کسب‌وکار" },
  technology: { de: "Technik", fa: "فناوری" },
  health: { de: "Gesundheit & Sport", fa: "سلامت و ورزش" },
  culture: { de: "Kultur & Kunst", fa: "فرهنگ و هنر" },
  study: { de: "Studium", fa: "تحصیل و دانشگاه" },
  news: { de: "Nachrichten", fa: "اخبار و جامعه" },
  everyday: { de: "Alltag & Kochen", fa: "زندگی روزمره و آشپزی" },
  nature: { de: "Natur & Umwelt", fa: "طبیعت و محیط‌زیست" },
  history: { de: "Geschichte", fa: "تاریخ" },
  music: { de: "Musik", fa: "موسیقی" },
  film: { de: "Film & Serien", fa: "فیلم و سریال" },
};

export const INTEREST_ORDER: InterestKey[] = [
  "travel",
  "work",
  "technology",
  "health",
  "culture",
  "study",
  "news",
  "everyday",
  "nature",
  "history",
  "music",
  "film",
];

/** Neue Karten pro Tag — direkte Vorgabe für Leitner/FSRS. */
export const NEW_CARD_OPTIONS: { value: number; de: string; fa: string }[] = [
  { value: 5, de: "5 Karten", fa: "آرام و بی‌فشار" },
  { value: 10, de: "10 Karten", fa: "پیشنهاد ما" },
  { value: 20, de: "20 Karten", fa: "پیشرفت سریع" },
  { value: 30, de: "30 Karten", fa: "فشرده" },
];

export const REVIEW_LOAD_OPTIONS: {
  value: ReviewLoad;
  de: string;
  fa: string;
  limit: number;
}[] = [
  { value: "light", de: "Wenig", fa: "سبک — تا ۵۰ مرور", limit: 50 },
  { value: "balanced", de: "Ausgewogen", fa: "متعادل — تا ۱۰۰ مرور", limit: 100 },
  { value: "heavy", de: "Viel", fa: "زیاد — تا ۲۰۰ مرور", limit: 200 },
];

export const REVIEW_LOAD_LIMIT: Record<ReviewLoad, number> = {
  light: 50,
  balanced: 100,
  heavy: 200,
};

export const REVIEW_STYLE_OPTIONS: {
  value: ReviewStyle;
  de: string;
  fa: string;
  desc: string;
  descFa: string;
}[] = [
  {
    value: "leitner",
    de: "Leitner",
    fa: "لایتنر",
    desc: "Klassische Boxen, einfach nachvollziehbar",
    descFa: "جعبه‌های کلاسیک و ساده",
  },
  {
    value: "fsrs",
    de: "FSRS",
    fa: "هوشمند",
    desc: "Adaptive Intervalle nach deiner Leistung",
    descFa: "بازه‌های مرور بر اساس عملکرد تو",
  },
];

const EXAM_GOALS: GoalKey[] = ["goethe", "testdaf"];

/** Ob dieser Nutzer Prüfungsziele hat — steuert die Prüfungs-Felder im Ziel-Schritt. */
export function hasExamGoal(answers: OnboardingAnswers): boolean {
  return answers.goals.some((g) => EXAM_GOALS.includes(g));
}

/** Welche Schritte dieser Nutzer sieht. */
export function stepsFor(_answers: OnboardingAnswers): StepId[] {
  return ["level", "goals", "schedule", "pace", "skills", "style"];
}

/** Ein Schritt darf übersprungen werden, wenn er nichts Pflichtiges abfragt. */
export function isStepOptional(step: StepId): boolean {
  return step === "skills" || step === "style";
}

export function hasAnswer(step: StepId, a: OnboardingAnswers): boolean {
  switch (step) {
    case "goals":
      return a.goals.length > 0;
    case "schedule":
      return a.studyDays.length > 0;
    default:
      return true;
  }
}
