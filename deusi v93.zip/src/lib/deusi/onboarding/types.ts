import type { CefrLevel, GoalKey, Intensity, SkillKey } from "@/lib/deusi/planner/types";

/**
 * Lernprofil des Onboardings.
 *
 * Bewusst mit den Typen des bestehenden Smart Planners gebaut: Es gibt genau
 * EIN Vokabular für Niveau, Ziele, Fertigkeiten und Intensität. Das Onboarding
 * ist nur die Vorkonfigurations-Schicht — geplant wird ausschließlich in
 * `@/lib/deusi/planner/engine`.
 */

/** Was der Lernende gern macht — steuert Empfehlungen, nicht die Engine-Mathematik. */
export type LearningPreference =
  | "vocabulary"
  | "grammar"
  | "listening"
  | "speaking"
  | "reading"
  | "podcasts"
  | "movies"
  | "ai-coach";

/** Interessengebiete — steuern Empfehlungen für Lesen, Podcasts, Filme, Musik. */
export type InterestKey =
  | "travel"
  | "work"
  | "technology"
  | "health"
  | "culture"
  | "study"
  | "news"
  | "everyday"
  | "nature"
  | "history"
  | "music"
  | "film";

/** Wie viel Wiederholung der Lernende täglich verkraftet (Leitner/FSRS). */
export type ReviewLoad = "light" | "balanced" | "heavy";

/** Wiederholungs-Algorithmus der Karten. */
export type ReviewStyle = "leitner" | "fsrs";

export type LearnerProfile = {
  /** Schema-Version — erleichtert eine spätere Backend-Migration. */
  version: 2;
  level: CefrLevel;
  goals: GoalKey[];
  /** Zielniveau bei Prüfungszielen (Goethe / TestDaF). */
  targetLevel: CefrLevel | null;
  dailyMinutes: number;
  /** Wochentage, 0 = Sonntag … 6 = Samstag (gleiches Modell wie der Planer). */
  studyDays: number[];
  /** "auto" = DEUSI darf einen Ruhetag einplanen. */
  restDays: "auto" | "none";
  /** HH:MM */
  preferredStartTime: string;
  /** ISO-Datum oder null — nie erfinden. */
  targetDate: string | null;
  intensity: Intensity;
  weakSkills: SkillKey[];
  strongSkills: SkillKey[];
  preferences: LearningPreference[];
  /** Themen, die den Lernenden interessieren. */
  interests: InterestKey[];
  /** Neue Karten pro Tag (Leitner/FSRS). */
  newCardsPerDay: number;
  /** Tägliches Wiederholungs-Limit. */
  reviewLoad: ReviewLoad;
  reviewStyle: ReviewStyle;
  completedAt: string;
};

/** Alles, was während des Onboardings gesammelt wird (Teilstand erlaubt). */
export type OnboardingAnswers = Omit<LearnerProfile, "version" | "completedAt">;

export type OnboardingStatus = "pending" | "draft" | "skipped" | "completed";

/** Persistierter Zustand des Onboardings für einen Nutzer. */
export type OnboardingState = {
  version: 1;
  status: OnboardingStatus;
  /** Zwischenstand, damit ein Abbruch nicht von vorn beginnt. */
  answers: OnboardingAnswers;
  /** Zuletzt gesehener Schritt. */
  stepId: string | null;
  profile: LearnerProfile | null;
  updatedAt: string;
};

/**
 * Service-Vertrag der Profil-Schicht.
 * Heute lokal implementiert, später ohne UI-Änderung gegen ein Backend tauschbar.
 */
export interface LearnerProfileService {
  load(userId: string): Promise<OnboardingState>;
  save(userId: string, state: OnboardingState): Promise<void>;
  clear(userId: string): Promise<void>;
}
