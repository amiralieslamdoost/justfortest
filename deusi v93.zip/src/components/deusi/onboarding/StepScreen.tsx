import { Fa } from "@/components/deusi/Fa";
import { SKILL_COLOR } from "@/components/deusi/planner/parts";
import {
  GOAL_LABEL,
  INTENSITY,
  LEVEL_LABEL,
  SKILL_LABEL,
  SKILL_ORDER,
  WEEKDAY_LABEL,
} from "@/lib/deusi/planner/config";
import { formatMinutes, todayISO } from "@/lib/deusi/planner/date";
import type { CefrLevel, Intensity, SkillKey } from "@/lib/deusi/planner/types";
import {
  GOAL_OPTIONS,
  INTEREST_LABEL,
  INTEREST_ORDER,
  LEVEL_OPTIONS,
  MINUTE_HINT_FA,
  MINUTE_OPTIONS,
  NEW_CARD_OPTIONS,
  PREFERENCE_LABEL,
  PREFERENCE_ORDER,
  REVIEW_LOAD_OPTIONS,
  REVIEW_STYLE_OPTIONS,
  STEP_TITLE,
  hasExamGoal,
  type StepId,
} from "@/lib/deusi/onboarding/steps";
import {
  GOAL_ICON,
  INTENSITY_ICON,
  INTEREST_ICON,
  LEVEL_ICON,
  PREFERENCE_ICON,
  SKILL_ICON,
  minuteIcon,
  startIcon,
} from "@/lib/deusi/onboarding/icons";
import type { OnboardingAnswers } from "@/lib/deusi/onboarding/types";
import { X } from "lucide-react";
import { OptionCard, QuestionShell, SkillRatingRow, SubSection } from "./parts";

const DAY_ORDER = [6, 0, 1, 2, 3, 4, 5];
const START_PRESETS = [
  { h: "06:30", fa: "صبح زود" },
  { h: "08:00", fa: "صبح" },
  { h: "12:30", fa: "ظهر" },
  { h: "17:00", fa: "بعدازظهر" },
  { h: "19:00", fa: "عصر" },
  { h: "21:00", fa: "شب" },
];

function toggle<T>(list: T[], value: T): T[] {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

const inputClass =
  "w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm font-semibold tabular-nums outline-none transition-colors focus:border-[color:var(--section-primary)] focus:ring-2 focus:ring-[color:var(--section-primary)]/20";

const ic = "h-[18px] w-[18px]";

/**
 * Eine Onboarding-Frage. Alle Werte gehören zum Vokabular des bestehenden
 * Smart Planners — hier wird nur gefragt, nicht geplant.
 */
export function StepScreen({
  step,
  answers,
  patch,
}: {
  step: StepId;
  answers: OnboardingAnswers;
  patch: (a: Partial<OnboardingAnswers>) => void;
}) {
  const t = STEP_TITLE[step];
  const shell = { title: t.de, fa: t.fa, hintFa: t.hintFa, accent: t.accent };

  switch (step) {
    case "level":
      return (
        <QuestionShell {...shell}>
          <div role="radiogroup" aria-label={t.de} className="grid auto-rows-fr gap-2 sm:grid-cols-2">
            {LEVEL_OPTIONS.map((o) => {
              const Icon = LEVEL_ICON[o.value];
              return (
                <OptionCard
                  key={o.value}
                  accent={t.accent}
                  icon={<Icon className={ic} />}
                  active={answers.level === o.value}
                  onClick={() => patch({ level: o.value })}
                  title={o.label}
                  desc={o.desc}
                  descFa={o.descFa}
                />
              );
            })}
          </div>
        </QuestionShell>
      );

    case "goals": {
      const exam = hasExamGoal(answers);
      return (
        <QuestionShell {...shell}>
          <div role="group" aria-label={t.de} className="grid auto-rows-fr gap-2 sm:grid-cols-2">
            {GOAL_OPTIONS.map((o) => {
              const Icon = GOAL_ICON[o.value];
              return (
                <OptionCard
                  key={o.value}
                  multi
                  accent={t.accent}
                  icon={<Icon className={ic} />}
                  active={answers.goals.includes(o.value)}
                  onClick={() => patch({ goals: toggle(answers.goals, o.value) })}
                  title={
                    <>
                      {GOAL_LABEL[o.value].de}
                      <Fa inline>{GOAL_LABEL[o.value].fa}</Fa>
                    </>
                  }
                  desc={o.desc}
                />
              );
            })}
          </div>

          {exam ? (
            <SubSection title="Prüfungsziel" fa="هدف آزمون — اختیاری">
              <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_15rem]">
                <div
                  role="radiogroup"
                  aria-label="Zielniveau"
                  className="grid auto-rows-fr grid-cols-3 gap-2 sm:grid-cols-5"
                >
                  {(["A2", "B1", "B2", "C1", "C2"] as CefrLevel[]).map((l) => (
                    <OptionCard
                      key={l}
                      compact
                      accent={t.accent}
                      active={answers.targetLevel === l}
                      onClick={() => patch({ targetLevel: answers.targetLevel === l ? null : l })}
                      title={LEVEL_LABEL[l]}
                    />
                  ))}
                </div>
                <div>
                  <label
                    htmlFor="onb-exam-date"
                    className="mb-1.5 block text-[11px] font-semibold text-muted-foreground"
                  >
                    Prüfungstermin · تاریخ آزمون
                  </label>
                  <input
                    id="onb-exam-date"
                    type="date"
                    min={todayISO()}
                    value={answers.targetDate ?? ""}
                    onChange={(e) => patch({ targetDate: e.target.value || null })}
                    className={inputClass}
                  />
                </div>
              </div>
            </SubSection>
          ) : null}
        </QuestionShell>
      );
    }

    case "schedule":
      return (
        <QuestionShell {...shell}>
          <SubSection title="Zeit pro Lerntag" fa="زمان هر روز">
            <div
              role="radiogroup"
              aria-label="Zeit pro Lerntag"
              className="grid auto-rows-fr gap-2 sm:grid-cols-3"
            >
              {MINUTE_OPTIONS.map((m) => {
                const Icon = minuteIcon(m);
                return (
                  <OptionCard
                    key={m}
                    compact
                    accent={t.accent}
                    icon={<Icon className={ic} />}
                    active={answers.dailyMinutes === m}
                    onClick={() => patch({ dailyMinutes: m })}
                    title={formatMinutes(m)}
                    descFa={MINUTE_HINT_FA[m]}
                  />
                );
              })}
            </div>
          </SubSection>

          <SubSection title="Lerntage" fa="روزهای یادگیری">
            <div
              role="group"
              aria-label="Lerntage"
              className="grid auto-rows-fr grid-cols-2 gap-2 sm:grid-cols-4"
            >
              {DAY_ORDER.map((d) => (
                <OptionCard
                  key={d}
                  multi
                  compact
                  accent={t.accent}
                  active={answers.studyDays.includes(d)}
                  onClick={() => patch({ studyDays: toggle(answers.studyDays, d) })}
                  title={
                    <>
                      {WEEKDAY_LABEL[d]!.de}
                      <Fa inline>{WEEKDAY_LABEL[d]!.fa}</Fa>
                    </>
                  }
                />
              ))}
            </div>
            <div
              role="radiogroup"
              aria-label="Ruhetag"
              className="grid auto-rows-fr gap-2 sm:grid-cols-2"
            >
              <OptionCard
                compact
                accent={t.accent}
                active={answers.restDays === "auto"}
                onClick={() => patch({ restDays: "auto" })}
                title="Ruhetag erlauben"
                descFa="اگر هفته پر باشد، یک روز آزاد می‌ماند."
              />
              <OptionCard
                compact
                accent={t.accent}
                active={answers.restDays === "none"}
                onClick={() => patch({ restDays: "none" })}
                title="Jeden gewählten Tag lernen"
                descFa="بدون روز استراحت خودکار."
              />
            </div>
          </SubSection>

          <SubSection title="Startzeit" fa="ساعت شروع">
            <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_14rem]">
              <div
                role="radiogroup"
                aria-label="Startzeit"
                className="grid auto-rows-fr gap-2 sm:grid-cols-3"
              >
                {START_PRESETS.map((p) => {
                  const Icon = startIcon(p.h);
                  return (
                    <OptionCard
                      key={p.h}
                      compact
                      accent={t.accent}
                      icon={<Icon className={ic} />}
                      active={answers.preferredStartTime === p.h}
                      onClick={() => patch({ preferredStartTime: p.h })}
                      title={`${p.h}`}
                      descFa={p.fa}
                    />
                  );
                })}
              </div>
              <div>
                <label
                  htmlFor="onb-start"
                  className="mb-1.5 block text-[11px] font-semibold text-muted-foreground"
                >
                  Eigene Uhrzeit · ساعت دلخواه
                </label>
                <input
                  id="onb-start"
                  type="time"
                  value={answers.preferredStartTime}
                  onChange={(e) => patch({ preferredStartTime: e.target.value || "19:00" })}
                  className={inputClass}
                />
              </div>
            </div>
          </SubSection>
        </QuestionShell>
      );

    case "pace":
      return (
        <QuestionShell {...shell}>
          <SubSection title="Intensität" fa="شدت یادگیری">
            <div
              role="radiogroup"
              aria-label="Intensität"
              className="grid auto-rows-fr gap-2 sm:grid-cols-3"
            >
              {(Object.keys(INTENSITY) as Intensity[]).map((i) => {
                const Icon = INTENSITY_ICON[i];
                return (
                  <OptionCard
                    key={i}
                    accent={t.accent}
                    icon={<Icon className={ic} />}
                    active={answers.intensity === i}
                    onClick={() => patch({ intensity: i })}
                    title={
                      <>
                        {INTENSITY[i].label}
                        <Fa inline>{INTENSITY[i].fa}</Fa>
                      </>
                    }
                    descFa={
                      i === "light"
                        ? "سبک و منعطف"
                        : i === "steady"
                          ? "منظم و پیوسته — پیشنهادی"
                          : "فشرده و سریع"
                    }
                  />
                );
              })}
            </div>
          </SubSection>

          {hasExamGoal(answers) ? null : (
            <SubSection title="Ziel-Datum" fa="تاریخ هدف — اختیاری">
              <div className="flex max-w-sm flex-col gap-2">
                <input
                  id="onb-target"
                  type="date"
                  min={todayISO()}
                  value={answers.targetDate ?? ""}
                  onChange={(e) => patch({ targetDate: e.target.value || null })}
                  className={inputClass}
                />
                {answers.targetDate ? (
                  <button
                    type="button"
                    onClick={() => patch({ targetDate: null })}
                    className="inline-flex items-center gap-1.5 self-start rounded-md px-2 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                  >
                    <X className="h-3.5 w-3.5" />
                    Datum entfernen · حذف تاریخ
                  </button>
                ) : null}
              </div>
            </SubSection>
          )}
        </QuestionShell>
      );

    case "skills": {
      const rate = (s: SkillKey): "weak" | "ok" | "strong" =>
        answers.weakSkills.includes(s)
          ? "weak"
          : answers.strongSkills.includes(s)
            ? "strong"
            : "ok";
      const set = (s: SkillKey, v: "weak" | "ok" | "strong") =>
        patch({
          weakSkills:
            v === "weak"
              ? [...new Set([...answers.weakSkills, s])]
              : answers.weakSkills.filter((x) => x !== s),
          strongSkills:
            v === "strong"
              ? [...new Set([...answers.strongSkills, s])]
              : answers.strongSkills.filter((x) => x !== s),
        });
      return (
        <QuestionShell {...shell}>
          <SubSection title="Selbsteinschätzung" fa="خودارزیابی مهارت‌ها">
            <div className="grid auto-rows-fr gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {SKILL_ORDER.map((s) => {
                const Icon = SKILL_ICON[s];
                return (
                  <SkillRatingRow
                    key={s}
                    label={SKILL_LABEL[s].de}
                    labelFa={SKILL_LABEL[s].fa}
                    color={SKILL_COLOR[s]}
                    icon={<Icon className="h-4 w-4" />}
                    value={rate(s)}
                    onChange={(v) => set(s, v)}
                  />
                );
              })}
            </div>
          </SubSection>

          <SubSection title="Themen, die dich interessieren" fa="موضوعات مورد علاقه — اختیاری">
            <div
              role="group"
              aria-label="Interessen"
              className="grid auto-rows-fr gap-2 sm:grid-cols-3 lg:grid-cols-4"
            >
              {INTEREST_ORDER.map((k) => {
                const Icon = INTEREST_ICON[k];
                return (
                  <OptionCard
                    key={k}
                    multi
                    compact
                    accent={t.accent}
                    icon={<Icon className={ic} />}
                    active={answers.interests.includes(k)}
                    onClick={() => patch({ interests: toggle(answers.interests, k) })}
                    title={
                      <>
                        {INTEREST_LABEL[k].de}
                        <Fa inline>{INTEREST_LABEL[k].fa}</Fa>
                      </>
                    }
                  />
                );
              })}
            </div>
          </SubSection>
        </QuestionShell>
      );
    }

    case "style":
      return (
        <QuestionShell {...shell}>
          <SubSection title="Lieblingsformate" fa="قالب‌های مورد علاقه">
            <div
              role="group"
              aria-label="Lieblingsformate"
              className="grid auto-rows-fr gap-2 sm:grid-cols-2 lg:grid-cols-4"
            >
              {PREFERENCE_ORDER.map((p) => {
                const Icon = PREFERENCE_ICON[p];
                return (
                  <OptionCard
                    key={p}
                    multi
                    compact
                    accent={t.accent}
                    icon={<Icon className={ic} />}
                    active={answers.preferences.includes(p)}
                    onClick={() => patch({ preferences: toggle(answers.preferences, p) })}
                    title={
                      <>
                        {PREFERENCE_LABEL[p].de}
                        <Fa inline>{PREFERENCE_LABEL[p].fa}</Fa>
                      </>
                    }
                  />
                );
              })}
            </div>
          </SubSection>

          <SubSection title="Neue Karten pro Tag" fa="کارت جدید در روز">
            <div
              role="radiogroup"
              aria-label="Neue Karten pro Tag"
              className="grid auto-rows-fr grid-cols-2 gap-2 sm:grid-cols-4"
            >
              {NEW_CARD_OPTIONS.map((o) => (
                <OptionCard
                  key={o.value}
                  compact
                  accent={t.accent}
                  active={answers.newCardsPerDay === o.value}
                  onClick={() => patch({ newCardsPerDay: o.value })}
                  title={o.de}
                  descFa={o.fa}
                />
              ))}
            </div>
          </SubSection>

          <SubSection title="Wiederholungen pro Tag" fa="حجم مرور روزانه">
            <div
              role="radiogroup"
              aria-label="Wiederholungen pro Tag"
              className="grid auto-rows-fr gap-2 sm:grid-cols-3"
            >
              {REVIEW_LOAD_OPTIONS.map((o) => (
                <OptionCard
                  key={o.value}
                  compact
                  accent={t.accent}
                  active={answers.reviewLoad === o.value}
                  onClick={() => patch({ reviewLoad: o.value })}
                  title={o.de}
                  descFa={o.fa}
                />
              ))}
            </div>
          </SubSection>

          <SubSection title="Wiederholungs-Methode" fa="سبک مرور">
            <div
              role="radiogroup"
              aria-label="Wiederholungs-Methode"
              className="grid auto-rows-fr gap-2 sm:grid-cols-2"
            >
              {REVIEW_STYLE_OPTIONS.map((o) => (
                <OptionCard
                  key={o.value}
                  accent={t.accent}
                  active={answers.reviewStyle === o.value}
                  onClick={() => patch({ reviewStyle: o.value })}
                  title={
                    <>
                      {o.de}
                      <Fa inline>{o.fa}</Fa>
                    </>
                  }
                  desc={o.desc}
                  descFa={o.descFa}
                />
              ))}
            </div>
          </SubSection>
        </QuestionShell>
      );
  }
}
