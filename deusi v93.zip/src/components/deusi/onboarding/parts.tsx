import type { ReactNode } from "react";
import { motion } from "@/lib/motion-lite";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

/** Segmentierte Fortschritts-Anzeige — ein Balken-Stück pro Schritt. */
export function OnboardingProgress({
  current,
  total,
  accent = "var(--section-primary)",
  labels,
}: {
  current: number;
  total: number;
  accent?: string;
  labels?: string[];
}) {
  const pct = Math.round(((current + 1) / total) * 100);
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between text-[11px] font-semibold text-muted-foreground">
        <span className="tabular-nums">
          Schritt {current + 1}/{total}
        </span>
        <span className="tabular-nums" style={{ color: accent }}>
          {pct}%
        </span>
      </div>
      <div
        className="flex w-full gap-1"
        role="progressbar"
        aria-valuemin={1}
        aria-valuemax={total}
        aria-valuenow={current + 1}
        aria-label="Fortschritt im Lernprofil"
      >
        {Array.from({ length: total }).map((_, i) => {
          const done = i < current;
          const active = i === current;
          const isLast = current === total - 1;
          return (
            <span
              key={i}
              className="relative h-1 flex-1 overflow-hidden rounded-sm bg-muted"
              title={labels?.[i]}
            >
              <motion.span
                className="absolute inset-y-0 left-0 rounded-sm"
                style={{ background: done || active ? accent : "transparent" }}
                initial={false}
                animate={{ width: done ? "100%" : active ? (isLast ? "100%" : "55%") : "0%" }}
                transition={{ duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
              />
            </span>
          );
        })}
      </div>
    </div>
  );
}

/** Kleiner Abschnitts-Titel innerhalb eines Schritts. */
export function SubSection({
  title,
  fa,
  children,
}: {
  title: string;
  fa?: string;
  children: ReactNode;
}) {
  return (
    <section className="flex flex-col gap-2">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-[13px] font-semibold tracking-tight text-foreground">{title}</h2>
        {fa ? (
          <span lang="fa" dir="rtl" className="text-[11px] text-muted-foreground">
            {fa}
          </span>
        ) : null}
      </div>
      {children}
    </section>
  );
}

/** Antwort-Karte — Touch-freundlich, klarer Auswahl-Zustand, ruhige Optik. */
export function OptionCard({
  active,
  onClick,
  title,
  desc,
  descFa,
  multi,
  compact,
  accent = "var(--section-primary)",
  icon,
}: {
  active: boolean;
  onClick: () => void;
  title: ReactNode;
  desc?: string;
  descFa?: string;
  multi?: boolean;
  compact?: boolean;
  accent?: string;
  icon?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      role={multi ? "checkbox" : "radio"}
      aria-checked={active}
      style={
        active
          ? {
              borderColor: accent,
              backgroundColor: `color-mix(in oklab, ${accent} 7%, transparent)`,
            }
          : undefined
      }
      className={cn(
        "group relative flex h-full w-full items-center gap-3 rounded-lg border p-3 text-left outline-none transition-colors",
        "min-h-[3rem] focus-visible:ring-2 focus-visible:ring-[color:var(--section-primary)]/30",
        active ? "" : "border-border/70 bg-card hover:border-border hover:bg-muted/40",
      )}
    >
      {icon ? (
        <span
          aria-hidden
          style={{ color: accent }}
          className={cn("grid shrink-0 place-items-center", compact ? "h-5 w-5" : "h-6 w-6")}
        >
          {icon}
        </span>
      ) : null}

      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-baseline gap-x-2 text-[14px] font-medium leading-tight tracking-tight text-foreground">
          {title}
        </span>
        {desc ? (
          <span className="mt-0.5 block text-[11px] leading-snug text-muted-foreground">
            {desc}
          </span>
        ) : null}
        {descFa ? (
          <span
            lang="fa"
            dir="rtl"
            className="mt-0.5 block text-right text-[11px] leading-relaxed text-muted-foreground/90"
          >
            {descFa}
          </span>
        ) : null}
      </span>

      <span
        aria-hidden
        style={active ? { backgroundColor: accent, borderColor: "transparent" } : undefined}
        className={cn(
          "grid h-[18px] w-[18px] shrink-0 place-items-center border transition-colors",
          multi ? "rounded-[4px]" : "rounded-full",
          active ? "text-white" : "border-border bg-background",
        )}
      >
        {active ? <Check className="h-3 w-3" /> : null}
      </span>
    </button>
  );
}

/** Zusammenfassungs-Kachel im Profil-Review. */
export function SummaryTile({
  label,
  labelFa,
  value,
  accent = "var(--section-primary)",
  icon,
}: {
  label: string;
  labelFa?: string;
  value: ReactNode;
  accent?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border/70 bg-card p-3.5">
      <div className="flex items-start gap-3">
        {icon ? (
          <span aria-hidden className="mt-0.5 shrink-0" style={{ color: accent }}>
            {icon}
          </span>
        ) : null}
        <div className="min-w-0">
          <div className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/80">
            {label}
            {labelFa ? (
              <span lang="fa" dir="rtl" className="ml-1.5 normal-case tracking-normal">
                · {labelFa}
              </span>
            ) : null}
          </div>
          <div className="mt-0.5 text-balance text-[14px] font-bold leading-tight tracking-tight">
            {value}
          </div>
        </div>
      </div>
    </div>
  );
}

/** Rahmen einer Onboarding-Frage — Titel, persische Zeile, ein kurzer Hinweis. */
export function QuestionShell({
  title,
  fa,
  hintFa,
  accent = "var(--section-primary)",
  children,
}: {
  title: string;
  fa: string;
  hintFa?: string;
  accent?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-4">
      <div className="min-w-0 pt-2 sm:pt-3">
        <h1 className="text-balance text-lg font-bold leading-tight tracking-tight sm:text-[21px]">
          {title}
        </h1>
        <p lang="fa" dir="rtl" className="mt-0.5 text-[13px] font-semibold" style={{ color: accent }}>
          {fa}
        </p>
        {hintFa ? (
          <p
            lang="fa"
            dir="rtl"
            className="mt-1 text-right text-[11.5px] leading-6 text-muted-foreground"
          >
            {hintFa}
          </p>
        ) : null}
      </div>

      <div className="flex flex-col gap-4 pb-6">{children}</div>
    </div>
  );
}

/** Einheitliche, logische Farben der Selbsteinschätzung. */
const RATING_COLOR: Record<"weak" | "ok" | "strong", string> = {
  weak: "#ef4444",
  ok: "#f59e0b",
  strong: "#22c55e",
};

/** Dreistufige Selbsteinschätzung einer Fertigkeit. */
export function SkillRatingRow({
  label,
  labelFa,
  color,
  value,
  onChange,
  icon,
}: {
  label: string;
  labelFa: string;
  color: string;
  value: "weak" | "ok" | "strong";
  onChange: (v: "weak" | "ok" | "strong") => void;
  icon?: ReactNode;
}) {
  const options: { value: "weak" | "ok" | "strong"; de: string; fa: string }[] = [
    { value: "weak", de: "Schwach", fa: "ضعیف" },
    { value: "ok", de: "Geht so", fa: "متوسط" },
    { value: "strong", de: "Stark", fa: "قوی" },
  ];
  return (
    <div className="flex h-full flex-col justify-between gap-2.5 rounded-lg border border-border/70 bg-card p-3">
      <div className="flex min-w-0 items-center gap-2">
        {icon ? (
          <span aria-hidden className="shrink-0" style={{ color }}>
            {icon}
          </span>
        ) : (
          <span aria-hidden className="h-2 w-2 shrink-0 rounded-sm" style={{ background: color }} />
        )}
        <span className="truncate text-sm font-medium tracking-tight">{label}</span>
        <span lang="fa" dir="rtl" className="ml-auto shrink-0 text-xs text-muted-foreground">
          {labelFa}
        </span>
      </div>
      <div
        role="radiogroup"
        aria-label={label}
        className="grid grid-cols-3 gap-1 rounded-md bg-muted/70 p-1"
      >
        {options.map((o) => {
          const active = o.value === value;
          const tone = RATING_COLOR[o.value];
          return (
            <button
              key={o.value}
              type="button"
              role="radio"
              aria-checked={active}
              aria-label={`${label}: ${o.de}`}
              onClick={() => onChange(o.value)}
              style={active ? { background: tone } : undefined}
              className={cn(
                "rounded-[5px] px-2 py-1.5 text-center text-[11px] font-medium transition-colors",
                active ? "text-white" : "text-muted-foreground hover:text-foreground",
              )}
            >
              <span lang="fa" dir="rtl">
                {o.fa}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
