import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { AnimatePresence, motion } from "@/lib/motion-lite";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CalendarRange,
  Clock,
  GaugeCircle,
  Languages,
  Loader2,
  Sparkles,
  Spline,
  Sunrise,
  Target,
} from "lucide-react";
import { Fa } from "@/components/deusi/Fa";
import { Logo } from "@/components/deusi/Logo";
import { SkelPage } from "@/components/deusi/Skeletons";
import { OnboardingProgress, SummaryTile } from "@/components/deusi/onboarding/parts";
import { StepScreen } from "@/components/deusi/onboarding/StepScreen";
import { SkillDot } from "@/components/deusi/planner/parts";
import { useLearnerProfile } from "@/lib/deusi/onboarding/useLearnerProfile";
import { plannerPrefsFromProfile } from "@/lib/deusi/onboarding/mapping";
import {
  PREFERENCE_LABEL,
  STEP_TITLE,
  hasAnswer,
  isStepOptional,
  stepsFor,
  type StepId,
} from "@/lib/deusi/onboarding/steps";
import type { OnboardingAnswers } from "@/lib/deusi/onboarding/types";
import { GOAL_LABEL, LEVEL_LABEL, INTENSITY, SKILL_LABEL } from "@/lib/deusi/planner/config";
import { formatDayLong, formatMinutes, weekdayLabel } from "@/lib/deusi/planner/date";
import { usePlanner } from "@/lib/deusi/planner/usePlanner";
import { useDeusi } from "@/lib/deusi/store";

const TITLE = "Dein Lernprofil — DEUSI";
const DESCRIPTION =
  "In wenigen Schritten lernt DEUSI dich kennen: Niveau, Ziel, Lernzeit und Fertigkeiten — daraus entsteht dein persönlicher Wochenplan im Smart Planner.";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
    ],
  }),
  component: OnboardingPage,
});

type Phase = "questions" | "review" | "generating" | "done" | "failed";

function OnboardingPage() {
  const router = useRouter();
  const { currentUser, hydrated } = useDeusi();
  const profileApi = useLearnerProfile();
  const planner = usePlanner();

  const [answers, setAnswers] = useState<OnboardingAnswers | null>(null);
  const [index, setIndex] = useState(0);
  const [phase, setPhase] = useState<Phase>("questions");
  const [dir, setDir] = useState(1);

  /* Entwurf laden — angefangenes Onboarding wird fortgesetzt. */
  useEffect(() => {
    if (profileApi.loading || answers) return;
    setAnswers(profileApi.answers);
    const steps = stepsFor(profileApi.answers);
    const saved = profileApi.state?.stepId as StepId | null | undefined;
    if (saved) {
      const i = steps.indexOf(saved);
      if (i >= 0) setIndex(i);
    }
  }, [answers, profileApi.answers, profileApi.loading, profileApi.state]);

  const steps = useMemo(() => (answers ? stepsFor(answers) : []), [answers]);
  const step = steps[Math.min(index, Math.max(steps.length - 1, 0))];

  if (!hydrated || profileApi.loading || !answers) {
    return (
      <main className="mx-auto min-h-screen w-full max-w-3xl px-4 py-8">
        <SkelPage />
      </main>
    );
  }

  if (!currentUser) return null;

  const patch = (a: Partial<OnboardingAnswers>) =>
    setAnswers((prev) => ({ ...(prev as OnboardingAnswers), ...a }));

  const goTo = (next: number, direction: number) => {
    setDir(direction);
    setIndex(next);
    void profileApi.saveDraft(answers, steps[next] ?? null);
  };

  const next = () => {
    if (index + 1 < steps.length) return goTo(index + 1, 1);
    void profileApi.saveDraft(answers, null);
    setDir(1);
    setPhase("review");
  };

  const back = () => {
    if (phase === "review") {
      setPhase("questions");
      setDir(-1);
      return;
    }
    if (index > 0) goTo(index - 1, -1);
  };

  const skipOnboarding = async () => {
    await profileApi.skip();
    router.navigate({ to: "/dashboard" });
  };

  const createPlan = async () => {
    setPhase("generating");
    try {
      const profile = await profileApi.complete(answers);
      await planner.savePrefs(plannerPrefsFromProfile(profile));
      setPhase("done");
    } catch (err) {
      console.error("[onboarding] plan generation failed", err);
      setPhase("failed");
    }
  };

  const canContinue = step ? isStepOptional(step) || hasAnswer(step, answers) : true;

  const accent = step ? STEP_TITLE[step].accent : "var(--section-primary)";

  return (
    <main className="mx-auto flex min-h-[100dvh] w-full max-w-3xl flex-col gap-3 px-3 py-4 sm:gap-4 sm:px-6 sm:py-6">
      <div
        aria-hidden
        className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-64 opacity-[0.16] transition-colors duration-500"
        style={{ background: `radial-gradient(60% 100% at 50% 0%, ${accent}, transparent 70%)` }}
      />
      <header className="flex shrink-0 items-center justify-between gap-4">
        <Logo />
        {phase === "questions" || phase === "review" ? (
          <button
            type="button"
            onClick={skipOnboarding}
            className="flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold text-muted-foreground underline-offset-4 outline-none transition-colors hover:text-foreground focus-visible:ring-4 focus-visible:ring-[color:var(--section-primary)]/20"
          >
            <span>Überspringen</span>
            <span lang="fa" dir="rtl" className="hidden sm:inline">
              بعداً پروفایلم را می‌سازم
            </span>
          </button>
        ) : null}
      </header>

      {phase === "questions" && step ? (
        <>
          <div className="shrink-0">
            <OnboardingProgress
              current={index}
              total={steps.length}
              accent={accent}
              labels={steps.map((s) => STEP_TITLE[s].de)}
            />
          </div>

          <div className="neu-card flex flex-col overflow-hidden p-0">
            <div className="flex max-h-[calc(100dvh-13rem)] flex-col overflow-y-auto overscroll-contain p-3 sm:p-4">
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: dir * 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: dir * -20 }}
                  transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
                  className="flex min-h-full flex-col"
                >
                  <StepScreen step={step} answers={answers} patch={patch} />
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          <div className="flex shrink-0 items-center justify-between gap-2">
            <button
              type="button"
              onClick={back}
              disabled={index === 0}
              className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2.5 text-sm font-semibold outline-none transition-colors hover:bg-muted disabled:opacity-40 focus-visible:ring-4 focus-visible:ring-[color:var(--section-primary)]/20"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Zurück</span>
            </button>
            <div className="flex min-w-0 flex-1 items-center justify-end gap-2">
              {isStepOptional(step) ? (
                <button
                  type="button"
                  onClick={next}
                  className="rounded-lg px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:text-foreground"
                >
                  Später · بعداً
                </button>
              ) : null}
              <button
                type="button"
                onClick={next}
                disabled={!canContinue}
                style={{ backgroundColor: accent, boxShadow: `0 12px 26px -16px ${accent}` }}
                className="inline-flex min-w-0 flex-1 items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-bold text-white outline-none sm:flex-none sm:py-2.5 transition-transform hover:-translate-y-px disabled:translate-y-0 disabled:opacity-50 focus-visible:ring-4 focus-visible:ring-[color:var(--section-primary)]/25"
              >
                {index + 1 === steps.length ? "Profil ansehen" : "Weiter"}
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </>
      ) : null}

      {phase === "review" ? (
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain pb-1">
          <ReviewScreen
            answers={answers}
            onEdit={() => {
              setPhase("questions");
              setIndex(0);
            }}
            onCreate={createPlan}
          />
        </div>
      ) : null}

      {phase === "generating" ? (
        <div className="neu-card flex flex-1 flex-col items-center justify-center gap-3 p-10 text-center">
          <Loader2 className="h-7 w-7 animate-spin text-[color:var(--section-primary)]" />
          <p className="text-lg font-black tracking-tight">Dein Lernplan entsteht …</p>
          <Fa>برنامه‌ی یادگیری‌ات در حال ساخت است</Fa>
        </div>
      ) : null}

      {phase === "failed" ? (
        <div className="neu-card flex flex-1 flex-col items-center justify-center gap-4 p-10 text-center">
          <p className="text-lg font-black tracking-tight">
            Wir konnten deinen Plan gerade nicht erstellen.
          </p>
          <p className="max-w-md text-sm text-muted-foreground">
            Dein Lernprofil ist gespeichert. Du kannst es sofort erneut versuchen oder später im
            Smart Planner starten.
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            <button
              type="button"
              onClick={createPlan}
              className="rounded-lg bg-[color:var(--section-primary)] px-5 py-2.5 text-sm font-bold text-white"
            >
              Nochmal versuchen
            </button>
            <Link
              to="/dashboard"
              className="rounded-lg border border-border px-5 py-2.5 text-sm font-semibold hover:bg-muted"
            >
              Später erstellen
            </Link>
          </div>
        </div>
      ) : null}

      {phase === "done" ? (
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain pb-1">
          <DoneScreen answers={answers} planner={planner} />
        </div>
      ) : null}
    </main>
  );
}

/* ------------------------------------------------------------------ Review */

function ReviewScreen({
  answers,
  onEdit,
  onCreate,
}: {
  answers: OnboardingAnswers;
  onEdit: () => void;
  onCreate: () => void;
}) {
  const goals = answers.goals.length ? answers.goals : (["general"] as const);
  const focus = answers.weakSkills.map((s) => SKILL_LABEL[s].de).join(" + ");
  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="neu-card flex flex-col gap-6 p-5 sm:p-8"
      aria-label="Dein DEUSI-Profil"
    >
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[color:var(--section-primary)]">
          Dein DEUSI-Profil
        </p>
        <h1 className="mt-1 text-2xl font-black tracking-tight sm:text-3xl">
          Passt das so für dich?
        </h1>
        <Fa>پروفایل یادگیری تو</Fa>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <SummaryTile
          accent="#6366f1"
          icon={<Languages className="h-[18px] w-[18px]" />}
          label="Dein Niveau"
          labelFa="سطح"
          value={LEVEL_LABEL[answers.level]}
        />
        <SummaryTile
          accent="#ec4899"
          icon={<Target className="h-[18px] w-[18px]" />}
          label="Dein Ziel"
          labelFa="هدف"
          value={goals.map((g) => GOAL_LABEL[g].de).join(" · ")}
        />
        <SummaryTile
          accent="#10b981"
          icon={<Clock className="h-[18px] w-[18px]" />}
          label="Pro Lerntag"
          labelFa="در هر روز"
          value={formatMinutes(answers.dailyMinutes)}
        />
        <SummaryTile
          accent="#0ea5e9"
          icon={<CalendarDays className="h-[18px] w-[18px]" />}
          label="Pro Woche"
          labelFa="در هفته"
          value={`${answers.studyDays.length} Tage`}
        />
        <SummaryTile
          accent="#8b5cf6"
          icon={<Sunrise className="h-[18px] w-[18px]" />}
          label="Deine Startzeit"
          labelFa="ساعت شروع"
          value={answers.preferredStartTime}
        />
        <SummaryTile
          accent="#f97316"
          icon={<Spline className="h-[18px] w-[18px]" />}
          label="Dein Fokus"
          labelFa="تمرکز"
          value={focus || "Ausgewogen"}
        />
        <SummaryTile
          accent="#14b8a6"
          icon={<GaugeCircle className="h-[18px] w-[18px]" />}
          label="Deine Intensität"
          labelFa="شدت"
          value={INTENSITY[answers.intensity].label}
        />
        <SummaryTile
          accent="#f43f5e"
          icon={<CalendarRange className="h-[18px] w-[18px]" />}
          label="Ziel-Datum"
          labelFa="تاریخ هدف"
          value={answers.targetDate ? formatDayLong(answers.targetDate) : "Offen"}
        />
      </div>

      {answers.preferences.length ? (
        <p className="text-sm text-muted-foreground">
          Lieblingsformate: {answers.preferences.map((p) => PREFERENCE_LABEL[p].de).join(" · ")}
        </p>
      ) : null}

      <div className="flex flex-col-reverse gap-2 border-t border-border/70 pt-4 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between sm:gap-3">
        <button
          type="button"
          onClick={onEdit}
          className="rounded-lg border border-border px-4 py-3 text-sm font-semibold hover:bg-muted sm:py-2.5"
        >
          Profil bearbeiten
        </button>
        <button
          type="button"
          onClick={onCreate}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-[color:var(--section-primary)] px-5 py-3 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-px sm:py-2.5"
        >
          <Sparkles className="h-4 w-4" />
          Meinen Lernplan erstellen
        </button>
      </div>
    </motion.section>
  );
}

/* -------------------------------------------------------------------- Done */

function DoneScreen({
  answers,
  planner,
}: {
  answers: OnboardingAnswers;
  planner: ReturnType<typeof usePlanner>;
}) {
  const byDay = useMemo(() => {
    const map = new Map<string, typeof planner.sessions>();
    for (const s of planner.sessions) {
      map.set(s.date, [...(map.get(s.date) ?? []), s]);
    }
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0])).slice(0, 4);
  }, [planner.sessions]);

  const goalText = (answers.goals.length ? answers.goals : (["general"] as const))
    .map((g) => GOAL_LABEL[g].de)
    .join(" · ");

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-5"
      aria-label="Dein Lernplan ist bereit"
    >
      <div className="neu-card p-6 sm:p-8">
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[color:var(--section-primary)]">
          Willkommen bei DEUSI
        </p>
        <h1 className="mt-1 text-3xl font-black tracking-tight">Dein Lernplan ist bereit.</h1>
        <Fa>برنامه‌ی یادگیری‌ات آماده است</Fa>
        <p className="mt-3 text-sm font-semibold text-muted-foreground">
          {LEVEL_LABEL[answers.level]} · {formatMinutes(answers.dailyMinutes)} pro Tag ·{" "}
          {answers.studyDays.length} Lerntage · {goalText}
          {answers.weakSkills.length
            ? ` · Fokus: ${answers.weakSkills.map((s) => SKILL_LABEL[s].de).join(" + ")}`
            : ""}
        </p>
      </div>

      {byDay.length ? (
        <div className="grid gap-3 sm:grid-cols-2">
          {byDay.map(([date, sessions]) => (
            <div key={date} className="neu-card p-4">
              <div className="flex items-baseline justify-between">
                <h2 className="text-sm font-black tracking-tight">{weekdayLabel(date).de}</h2>
                <span className="text-xs text-muted-foreground">
                  {formatMinutes(sessions.reduce((a, s) => a + s.minutes, 0))}
                </span>
              </div>
              <ul className="mt-2 flex flex-col gap-1.5">
                {sessions.map((s) => (
                  <li key={s.id} className="flex items-center gap-2 text-sm">
                    <SkillDot skill={s.skill} />
                    <span className="min-w-0 truncate font-semibold">{s.title}</span>
                    <span className="ml-auto shrink-0 text-xs tabular-nums text-muted-foreground">
                      {s.start}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      ) : null}

      <div className="flex flex-wrap gap-2">
        <Link
          to="/planer"
          className="rounded-lg bg-[color:var(--section-primary)] px-5 py-2.5 text-sm font-bold text-white shadow-sm"
        >
          Meinen Plan öffnen
        </Link>
        <Link
          to="/dashboard"
          className="rounded-lg border border-border px-5 py-2.5 text-sm font-semibold hover:bg-muted"
        >
          Zum Dashboard
        </Link>
      </div>
    </motion.section>
  );
}
